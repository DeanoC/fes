from pathlib import Path
import subprocess,tempfile,time,json
root=Path.cwd();o=root/'out/line-completion-control'
with tempfile.TemporaryDirectory(prefix='fes-1274-line-control-') as tmp:
 endpoint=Path(tmp)/'socket'
 with (o/'server.log').open('wb') as log:
  server=subprocess.Popen([str(o/'server'),str(endpoint),'+verilator+rand+reset+2','+verilator+seed+41'],cwd=root/'out/internal-final3/rtl',stdout=log,stderr=subprocess.STDOUT)
  try:
   while not endpoint.exists():
    assert server.poll() is None;time.sleep(.01)
   client=subprocess.run([str(o/'client'),str(endpoint),'session','9e73d6d51866d75050e13fc8f7773680'],capture_output=True,timeout=900)
   (o/'client.log').write_bytes(client.stdout+client.stderr)
   (o/'control.json').write_text(json.dumps({'client':client.returncode,'server':server.wait(timeout=10),'classification':'diagnostic initial program storage only; 160M observation and PC trace, no final proof claim'},indent=2)+'\n')
  finally:
   if server.poll() is None:server.terminate();server.wait(timeout=5)
