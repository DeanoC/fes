from pathlib import Path
import subprocess,time,tempfile,shutil,json,hashlib
root=Path.cwd();old=root.parent/'de25-zx81-frame-ownership/out/frame-client-final-02';source=old/'source';board=source/'sources/misteross/boards/de25nano/zx81-hps';runtime=source/'sources/libmister-runtime';out=root/'out/cdflag-control-final4';out.mkdir()
s=(board/'cosim/client.cpp').read_text();anchor='''                const auto before_stall = io.retired();''';assert anchor in s;s=s.replace(anchor,'''                image.at(0x403b-0x4009) &= 0x7f; // Diagnostic control only: emulate SAVE's FAST flag.
'''+anchor)
anchor='''keyboard(computer, io, {}, 0xffffffffffull);
                okay(computer.EjectTape''';assert anchor in s;s=s.replace(anchor,'''keyboard(computer, io, {}, 0xffffffffffull);
                io.command(wire::WaitEditor, 160000000);
                okay(computer.EjectTape''');(out/'client.cpp').write_text(s)
subprocess.run(['c++','-std=c++14','-O2','-pthread','-I'+str(runtime/'src'),'-I'+str(runtime/'include'),'-I'+str(board/'cosim'),str(out/'client.cpp'),str(runtime/'src/native/de25_computer.cpp'),'-o',str(out/'client')],check=True)
server=(board/'cosim/server.cpp').read_text().replace('#include "../computer_sim.hpp"','#include "'+str(board/'computer_sim.hpp')+'"')
server=server.replace('b.expected_load = captured;', 'b.expected_load = captured; b.expected_load.at(0x403b-0x4009) &= 0x7f;')
(out/'server.cpp').write_text(server)
subprocess.run(['c++','-O3','-pthread','-I'+str(old/'obj'),'-I'+str(old/'rtl'),'-I'+str(old/'rtl/generated'),'-I/usr/share/verilator/include','-I/usr/share/verilator/include/vltstd','-I'+str(board),'-I'+str(board/'generated'),'-I'+str(board/'cosim'),str(out/'server.cpp'),str(old/'obj/Vfes_de25_computer__ALL.a'),str(old/'obj/verilated.o'),str(old/'obj/verilated_threads.o'),str(old/'obj/verilated_dpi.o'),'-latomic','-o',str(out/'server')],check=True)
shutil.copyfile(old/'rtl/zx8x.hex',out/'zx8x.hex')
with tempfile.TemporaryDirectory(prefix='fes-1274-cdflag-') as tmp:
 endpoint=Path(tmp)/'socket'
 with (out/'server.log').open('wb') as log:
  worker=subprocess.Popen([str(out/'server'),str(endpoint),'+verilator+rand+reset+2','+verilator+seed+41'],cwd=out,stdout=log,stderr=subprocess.STDOUT)
  try:
   while not endpoint.exists():
    if worker.poll() is not None:raise ValueError('server startup')
    time.sleep(.01)
   result=subprocess.run([str(out/'client'),str(endpoint),'session','00112233445566778899aabbccddeeff'],cwd=out,capture_output=True,timeout=1200);(out/'client.log').write_bytes(result.stdout+result.stderr);code=worker.wait(timeout=10)
  finally:
   if worker.poll() is None:worker.terminate();worker.wait(timeout=5)
record={'control':'unchanged internal 16K model and native client; only copied CDFLAG bit7 cleared and post-LOAD editor observation added','client_returncode':result.returncode,'server_returncode':code,'client_source_sha256':hashlib.sha256(s.encode()).hexdigest(),'classification':'diagnostic control only; final proof must use actual ROM SAVE output, not patched bytes'};(out/'control.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
