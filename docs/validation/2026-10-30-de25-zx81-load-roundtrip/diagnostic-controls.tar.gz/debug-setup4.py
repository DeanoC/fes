from pathlib import Path
import subprocess,tempfile,time
root=Path.cwd();model=root/'out/debug-model4';source=model/'functional-source';bench=source/'sources/misteross/boards/de25nano/link-proof/zx81-computer';shared=source/'sources/misteross/boards/de25nano/zx81-hps/cosim';runtime=source/'sources/libmister-runtime';out=root/'out/debug-setup4';out.mkdir(exist_ok=True)
header=(shared/'basic.hpp').read_text().replace('submit();command(WaitLine,1,0xf5);editor();','submit();command(WaitLine,1,0xf5);editor();return evidence;');(out/'basic-setup.hpp').write_text(header)
s=(bench/'client.cpp').read_text().replace('#include "../../zx81-hps/cosim/basic.hpp"','#include "basic-setup.hpp"');start=s.index('                okay(computer.Hold(io.deadline()),"HOLD before RAM selection");');end=s.index('                basic::Session session',start);s=s[:start]+s[end:];s=s.replace('roundtrip=session.roundtrip();loaded=roundtrip.image.size();unsigned size=loaded;', 'roundtrip=session.roundtrip();io.call(wire::Done);std::cout<<"{\\\"phase\\\":\\\"store-program\\\",\\\"result\\\":\\\"passed\\\"}\\n";return 0;unsigned size=0;');(out/'client.cpp').write_text(s)
subprocess.run(['c++','-std=c++14','-O2','-pthread','-I'+str(runtime/'src'),'-I'+str(runtime/'include'),'-I'+str(bench),str(out/'client.cpp'),str(runtime/'src/native/de25_computer.cpp'),str(runtime/'src/native/de25_pr_control.cpp'),'-o',str(out/'client')],check=True)
with tempfile.TemporaryDirectory(prefix='fes-1274-setup-') as tmp:
 endpoint=Path(tmp)/'socket'
 with (out/'server.log').open('wb') as log:
  worker=subprocess.Popen([str(model/'obj/Vfes_de25_combined_sim'),str(endpoint),'+verilator+rand+reset+2','+verilator+seed+41'],cwd=model/'hps/project',stdout=log,stderr=subprocess.STDOUT)
  try:
   while not endpoint.exists():
    if worker.poll() is not None:raise ValueError('server startup')
    time.sleep(.01)
   result=subprocess.run([str(out/'client'),str(endpoint),'session','00112233445566778899aabbccddeeff'],capture_output=True,timeout=300);(out/'client.log').write_bytes(result.stdout+result.stderr);print('client',result.returncode,'server',worker.wait(timeout=10))
  finally:
   if worker.poll() is None:worker.terminate();worker.wait(timeout=5)
