// SPDX-License-Identifier: MIT
// fes_i386_cpu as far as Phase 1 has built it (docs/i386-cpu-design.md): the
// front end (F1 to Q) behind the L1I, then D, AG, M1, M2, EX and WB for the
// real-mode instructions fes_i386_decode lists, with their memory forms on
// the L1D, and the bus interface on HPS DDR port 0 (fes_i386_l1i,
// fes_i386_l1d, fes_i386_biu). There is no L2 or paging yet.
//
//   DC  decode (fes_i386_decode, fes_i386_amode) from Q's output register
//   D   the GPR file and segment registers read; forwarding for data
//       operands (fes_i386_dops) and LEA's address (fes_i386_dfwd); EIP
//   AG  a memory operand's or LEA's address, a branch's target (fes_i386_agu)
//   M1  the segment limit check; the data port's address
//   M2  the loaded bytes, aligned and merged with older stores not yet written
//   EX  ALU, shifter, flags, branch resolution (fes_i386_ex); multiply and
//       divide (fes_i386_muldiv), over several cycles
//   WB  in-order commit, stores and I/O accesses included
//
// Branch prediction. The front end's BTB (fes_i386_btb) predicts Jcc, LOOP,
// LOOPE, LOOPNE, JCXZ and JMP and CALL rel, and JMP and CALL r/m to the
// target they last went to: F2 sends F1 to a taken entry's
// target, and Q goes on there after the branch (fes_i386_fetchbuf,
// fes_i386_qalign). D gives the instruction after such a branch (pt) the
// branch's target EIP, which it works out from the branch's own
// displacement, so the target uops issue behind the branch. EX resolves
// every branch as before; a branch WB finds taken when it was not predicted
// so, or not taken when it was, redirects F1 from WB and flushes every
// younger uop, which costs 10 cycles. WB writes each direct branch's
// outcome to the BTB.
//
// An indirect near JMP or CALL (JMP r/m, CALL r/m) gets an always-taken
// entry whose target is where it last went, and a CALL's pushes the return
// stack as a CALL rel's does. D gives the instruction after a predicted one
// the EIP of the target's linear address less CS.base, as after a RET
// (below), and EX compares it with the EIP the JMP or CALL computes: a
// target that differs redirects, and WB writes the new target.
//
// The return stack (fes_i386_ras) predicts near RET (C3h, C2h): the BTB
// keeps an entry for each RET and CALL rel, F2 pushes a predicted CALL rel's
// return address and sends a predicted RET to the top it pops. D gives the
// instruction after such a RET (rpt) the EIP of the target's linear address
// less CS.base, and EX compares it with the EIP the RET pops: a RET whose
// target differs redirects as a mispredicted branch does. On every
// redirect WB sets the stack's pointer back to its committed count (see
// "The return stack"). Every other branch is predicted not taken.
//
// Nothing the BTB holds is trusted. The fetch check: AG compares each
// instruction's fetched linear address with CS.base plus the EIP D gave it,
// and an instruction whose bytes ran into a half holding a predicted
// target instead of its continuation is flagged by Q (xbad). Either is
// marked FAULT_REPLAY at once, so it touches no memory, and replays at WB
// as an uncached load's does, without serial issue; the BTB set that sent
// fetch there is cleared. So a wrong target, an entry left by code since
// changed, a branch found where the entry says none ends, or an entry
// from the other code size costs a replay, never a result. The instruction
// after a predicted RET passes this check by construction, as its EIP comes
// from its linear address: for a RET's or an indirect JMP's or CALL's
// target, EX's compare is the check.
// Under queue16 nothing is predicted.
//
// A load whose bytes have not arrived when it is in M2 freezes D to WB: every
// stage behind DC keeps its uop, and nothing retires, until they do (freeze).
// Nothing moves relative to anything else, so the forwarding distances, AG's
// late operands, the store merge and D's forwarding tables all hold as they
// are; the tables only need clearing on a flush. A multiply or divide in EX
// freezes them the same way while it works, an I/O access in WB until the
// machine completes it, and a store in WB until the write buffer has room.
//
// An uncached load (MMIO) reads its device only as the oldest uop, with
// nothing in EX or WB, so never on a wrong path. One that reaches M2 behind
// older uops takes no data: the L1D marks it (FAULT_REPLAY), and when it
// reaches WB, WB flushes everything younger and restarts the front end at
// its instruction, which then issues one uop at a time (serial) until it
// ends. Microcode writes nothing architectural before its last uop that can
// fault, so restarting an instruction is safe wherever a fault is.
//
// A store or DMA write into the bytes the front end has fetched restarts the
// instruction after the one in WB the same way, once that one ends, so it
// runs the new bytes (self-modifying code, the coherent profile; queue16
// leaves the 16 bytes after a storing instruction as fetched).
//
// A fault (#UD, #GP, #SS, #NP, #NM, #DE, #BR) is taken at WB with nothing of
// its instruction retired: WB flushes, and DC takes the exception's entry
// into the microcode routine INT uses, which pushes FLAGS, CS and the
// faulting instruction's IP and jumps through the vector table, or in
// protected mode through an interrupt or trap gate of the IDT (see
// Protected-mode delivery). A fault while one is delivered is delivered in
// its place, as a double fault when both are contributory, and a fault in a
// double fault's delivery shuts the CPU down (shutdown), which the machine
// turns into a reset. An encoding this build does not implement stops the
// CPU at WB. HLT halts it until an interrupt.
//
// INTR and NMI are taken at an instruction boundary, or in HLT: WB flushes as
// for a fault, with nothing of the next instruction retired, and DC takes the
// same routine's entry with the interrupt's vector, from INTA for INTR, so
// the routine pushes the next instruction's IP.
//
// Protected mode (CR0.PE) with privilege levels and paging (README.md,
// "Protected mode" and "Paging"): MOV CRn and DRn, LMSW, SMSW, LGDT, SGDT,
// LIDT, SIDT, LLDT, SLDT, LTR and STR; segment loads from the GDT's and the
// LDT's descriptors, with their checks, error codes and accessed bit, in
// microcode; far JMP, CALL (through call gates too) and RETF; exceptions,
// INTR, NMI, INT n, INT3 and INTO through interrupt and trap gates, and
// IRET, across privileges on the TSS's stacks; LAR, LSL, VERR, VERW and
// ARPL; I/O through the TSS's permission bitmap. V86 mode (EFLAGS.VM, "V86
// mode"): real-mode segment loads with V86 caches at CPL 3, the IOPL-
// sensitive forms, deliveries to CPL 0 and IRETD back. A real-mode segment
// load keeps a data segment's cached limit and attributes (unreal mode),
// and sets CS's to the 386's real-mode values. What is not built (task
// gates and switches) stops the CPU as not built (trace_unimplemented),
// with its reason (trace_unbuilt).
//
// The speed governor (fes_i386_governor) charges each instruction and REP
// element WB retires its reference cost, with the period ISA bus time of its
// I/O and MMIO accesses, and holds D at the next one's first uop while the
// debt is over its window; under max it never holds. Holding
// D is all it does, so no result depends on it.
//
// init_* is the architectural state reset loads. A machine ties it to the
// 386 reset state; the lockstep harness loads a test's initial state.
// trace_* and arch_* show each retirement: on the edge an instruction
// retires, trace_retire rises and arch_* hold the state after it.
module fes_i386_cpu #(
    parameter logic [31:0] RAM_BASE = 32'h3400_0000, // the HPS address of guest physical 0
    parameter integer GOV_N = 1, GOV_D = 1000,        // 100 kHz as a fraction of clk (fes_i386_governor)
    parameter bit GOV_REFERENCE_DIAGNOSTIC = 1'b0    // simulation-only experimental 286 timing model
) (
    input  logic             clk,
    input  logic             cold_reset,   // the machine's start: also empties the write buffer
    input  logic             reset,
    input  logic [7:0][31:0] init_gpr,
    input  logic [31:0]      init_eflags,
    input  logic [31:0]      init_cr0,     // of which this build holds PE, MP, EM, TS, ET and PG
    input  logic [31:0]      init_cr2,
    input  logic [31:0]      init_cr3,
    input  logic [3:0][31:0] init_dr,      // DR0-DR3
    input  logic [31:0]      init_dr6,     // of which this build holds bits 15-12 and 3-0, the rest ones
    input  logic [31:0]      init_dr7,
    input  logic [31:0]      init_gdtr_base,
    input  logic [15:0]      init_gdtr_limit,
    input  logic [31:0]      init_idtr_base,
    input  logic [15:0]      init_idtr_limit,
    input  logic [31:0]      init_eip,
    input  logic [5:0][15:0] init_sel,     // fes_i386_pkg::seg_e order
    input  logic [5:0][31:0] init_base,
    input  logic [5:0][31:0] init_limit,
    input  logic [5:0][15:0] init_ar,      // descriptor bits 8-23, the limit nibble clear
    input  logic [15:0]      init_ldtr_sel,  // LDTR and TR with their caches; LDTR's valid bit
    input  logic [31:0]      init_ldtr_base, // is 0 after a null LLDT, when no TI=1 selector passes
    input  logic [31:0]      init_ldtr_limit,
    input  logic [15:0]      init_ldtr_ar,
    input  logic             init_ldtr_valid,
    input  logic [15:0]      init_tr_sel,
    input  logic [31:0]      init_tr_base,
    input  logic [31:0]      init_tr_limit,
    input  logic [15:0]      init_tr_ar,
    // A20M, and the attribute map: 640 KiB to 1 MiB in 16 KiB slots
    // (fes_i386_pkg::attr_e), RAM elsewhere below ram_top MiB.
    input  logic             a20m,
    input  logic [23:0][1:0] attr_upper,
    input  logic [6:0]       ram_top,
    // The self-modifying-code profile, sampled at reset: coherent (0) or
    // queue16 (1); see Self-modifying code.
    input  logic             queue16,
    // The speed governor's settings, sampled at reset (fes_i386_governor):
    // the preset (fes.pc386.machine word 0: 0 max, 1 286-12 to 7 486DX2-66),
    // its frequency in 100 kHz units (0 the preset's own) and turbo (1 runs
    // at max).
    input  logic [2:0]       gov_preset,
    input  logic [9:0]       gov_frequency,
    input  logic             gov_turbo,
    // HPS DDR port 0 (fes.memory.hps-ddr), guest physical 0 at RAM_BASE.
    output logic [27:0]      ddr_address,
    output logic [7:0]       ddr_burstcount,
    output logic             ddr_read,
    output logic             ddr_write,
    output logic [127:0]     ddr_writedata,
    output logic [15:0]      ddr_byteenable,
    input  logic             ddr_waitrequest,
    input  logic [127:0]     ddr_readdata,
    input  logic             ddr_readdatavalid,
    // MMIO: blocking dword reads with byte enables and posted writes, in
    // order (fes_i386_biu), at physical dword addresses.
    output logic             mmio_valid,
    output logic             mmio_write,
    output logic [fes_i386_pkg::PA-3:0] mmio_address,
    output logic [3:0]       mmio_byteenable,
    output logic [31:0]      mmio_wdata,
    input  logic             mmio_ready,
    input  logic             mmio_rvalid,
    input  logic [31:0]      mmio_rdata,
    // Machine DMA: one physical byte through the write buffer's order,
    // coherent with both L1s; held until dma_done.
    input  logic             dma_valid,
    input  logic             dma_write,
    input  logic [23:0]      dma_address,
    input  logic [7:0]       dma_wdata,
    output logic             dma_done,
    output logic [7:0]       dma_rdata,
    // FLUSH: empty the write buffer and invalidate both L1s; held until done.
    input  logic             flush_request,
    output logic             flush_done,
    // I/O: the access of the uop in WB, at commit (io_req), held until the
    // machine completes it (io_ack, IN's data in io_rdata on that edge). The
    // port, the size (a byte, word or dword: 0, 1, 2) and OUT's data stay put
    // while io_req is high; a request after an ack is the next access.
    output logic             io_req,
    output logic             io_write,
    output logic [15:0]      io_port,
    output logic [1:0]       io_size,
    output logic [31:0]      io_wdata,
    input  logic             io_ack,
    input  logic [31:0]      io_rdata,
    // Interrupts: INTR, a level the machine's PICs hold until the CPU
    // acknowledges it, and NMI, taken on its rising edge. Taking INTR, the
    // CPU asks for the vector (inta_req) and holds the request until the
    // machine returns it (inta_ack, the vector in inta_vector on that edge).
    input  logic             intr,
    input  logic             nmi,
    output logic             inta_req,
    input  logic             inta_ack,
    input  logic [7:0]       inta_vector,
    output logic             trace_retire,
    output logic             trace_exception,      // the retirement delivered exception trace_vector
    output logic [7:0]       trace_vector,
    output logic             trace_halt,           // stopped: in HLT, until an interrupt wakes it, or ...
    output logic             trace_unimplemented,  // ... for good: something not built yet (fes_i386_pkg why_e in
    output logic [3:0]       trace_unbuilt,        // trace_unbuilt), or ...
    output logic             shutdown,             // ... a fault in a double fault's delivery, until reset
    output logic [15:0]      trace_error,          // the delivered exception's error code
    output logic             trace_issue,          // D issued this cycle (lockstep observability)
    output logic             trace_fe_wait,        // D has no instruction from the front end (ditto)
    output logic             trace_md_wait,        // D to WB wait for a multiply or divide in EX (ditto)
    output logic             trace_fetch,          // F1 sent a block to the L1I (ditto) ...
    output logic [27:0]      trace_fetch_block,    // ... this one, linear address / 16
    output logic             trace_dread,          // M1 sent a load to the L1D (ditto)
    output logic [31:0]      trace_dread_addr,     // ... its linear byte address
    output logic             trace_mem_wait,       // D to WB wait for the L1D or the write buffer, or F2 for the L1I
    output logic             trace_mem_idle,       // the bus interface has nothing to do or finish
    output logic             trace_replay,         // WB restarts an instruction for an uncached load
    output logic             trace_smc,            // ... for self-modifying code (see Self-modifying code)
    output logic             trace_smc_open,       // a DMA write into fetched bytes now restarts the next instruction (ditto)
    output logic             trace_ex_store,       // a store in EX, one stage before it can retire
    output logic             trace_gov_hold,       // the governor's debt is over its window: D starts nothing
    output logic [11:0]      trace_gov_debt,       // ... the debt, in whole reference clocks
    output logic [12:0]      trace_gov_charge,     // ... what it adds this cycle: a retirement's cost, 3 cycles on
    // The store WB commits: the bytes trace_store_mask names of the eight
    // from trace_store_addr's dword, at linear addresses.
    output logic             trace_store,
    output logic [31:0]      trace_store_addr,
    output logic [7:0][7:0]  trace_store_data,
    output logic [7:0]       trace_store_mask,
    // ... and the physical pages of trace_store_addr's page and of the next
    // (PA bits 25:12 with phys's above bit: fes_i386_pkg::phys); the
    // walker's A/D store (a dword at a physical address, not a retirement).
    output logic [fes_i386_pkg::PA-12:0] trace_store_pg0,
    output logic [fes_i386_pkg::PA-12:0] trace_store_pg1,
    output logic             trace_pw,
    output logic [fes_i386_pkg::PA-1:0] trace_pw_addr,
    output logic [31:0]      trace_pw_data,
    // The i386dx+387 identity, and the AT board's coprocessor controls,
    // which the machine decodes at ports F0h and F1h (fes_i386_x87). With
    // the identity clear the CPU is a 386 with an empty 387 socket, exactly
    // as before the unit existed.
    input  logic             x87_present,
    input  logic             x87_f0,       // a write to port F0h: clear the board's BUSY# latch
    input  logic             x87_f1,       // a write to port F1h: reset the coprocessor
    output logic             x87_irq13,    // the 387's ERROR#, IRQ 13's level on an AT board
    // BUSY#, for the bench: a load's work finishes after the instruction
    // has retired, so the lockstep compares the 387's state once this is
    // clear, as a program would after WAIT.
    output logic             trace_x87_busy,
    output logic             trace_x87_latched,  // ... and the board's BUSY# latch
    output logic [4:0]       trace_x87_seq,      // ... and the unit's sequencer state
    output logic [15:0]      arch_x87_cw,
    output logic [15:0]      arch_x87_sw,
    output logic [15:0]      arch_x87_tw,
    output logic [10:0]      arch_x87_opcode,
    output logic [639:0]     arch_x87_regs,
    output logic [31:0]      arch_x87_ip,
    output logic [15:0]      arch_x87_cs,
    output logic [31:0]      arch_x87_dp,
    output logic [15:0]      arch_x87_ds,
    output logic [7:0][31:0] arch_gpr,
    output logic [31:0]      arch_eflags,
    output logic [31:0]      arch_cr0,     // as MOV r32, CR0 reads it: bits 30-5 ones, as Bochs's 386
    output logic [31:0]      arch_cr2,
    output logic [31:0]      arch_cr3,
    output logic [3:0][31:0] arch_dr,
    output logic [31:0]      arch_dr6,
    output logic [31:0]      arch_dr7,
    output logic [31:0]      arch_gdtr_base,
    output logic [15:0]      arch_gdtr_limit,
    output logic [31:0]      arch_idtr_base,
    output logic [15:0]      arch_idtr_limit,
    output logic [31:0]      arch_eip,
    output logic [5:0][15:0] arch_sel,
    output logic [5:0][31:0] arch_base,
    output logic [5:0][31:0] arch_limit,
    output logic [5:0][15:0] arch_ar,
    output logic [15:0]      arch_ldtr_sel,
    output logic [31:0]      arch_ldtr_base,
    output logic [31:0]      arch_ldtr_limit,
    output logic [15:0]      arch_ldtr_ar,
    output logic             arch_ldtr_valid,
    output logic [15:0]      arch_tr_sel,
    output logic [31:0]      arch_tr_base,
    output logic [31:0]      arch_tr_limit,
    output logic [15:0]      arch_tr_ar,
    output logic [1:0]       arch_cpl
);
    typedef fes_i386_pkg::pipe_t pipe_t;
    typedef fes_i386_pkg::uop_t uop_t;
    typedef fes_i386_pkg::fetched_t fetched_t;
    typedef fes_i386_pkg::decoded_t decoded_t;
    typedef fes_i386_pkg::btb_write_t btb_write_t;

    localparam logic [1:0] EARLY = 2'd0, LOAD = 2'd1, LATE = 2'd2;
    localparam int SEG_CS = 1, SEG_SS = 2;
    localparam int PA = fes_i386_pkg::PA;

    // The L1I's fetch port: mem_data is the block at the address registered on
    // the last edge with mem_load, once mem_valid says it is there. The L1D's
    // port: M1 drives a load's address, the L1D registers it on the edge M1
    // advances, and the 8 bytes from the address's dword arrive in M2 once
    // dmem_valid says so. A retiring store writes the bytes dmem_wmask names,
    // from its address's dword, on the edge it retires; the L1D reads before
    // it writes on the same edge.
    logic [27:0]      mem_block;
    logic             mem_load;
    logic [15:0][7:0] mem_data;
    logic             mem_valid;
    logic [31:0]      dmem_addr;
    logic             dmem_read;
    logic [7:0][7:0]  dmem_rdata;
    logic             dmem_valid;
    logic             dmem_write;
    logic [31:0]      dmem_waddr;
    logic [7:0][7:0]  dmem_wdata;
    logic [7:0]       dmem_wmask;

    // ---- Architectural state, written at WB -------------------------------------
    logic [7:0][31:0] gpr;
    logic [17:0]      eflags;
    logic [31:0]      eip;
    // The CPL: CS's RPL once a protected-mode load has written CS, 3 in V86
    // mode, and 0 in real mode and on protected-mode entry, whatever CS's
    // selector, as Bochs keeps it. Only a protected-mode CS load or a jump
    // into or out of V86 mode changes it, a far transfer that flushes
    // everything younger, so D's decode and the staged descriptor's checks
    // read it as it stands.
    logic [1:0]       cpl;
    logic [5:0][15:0] seg_sel, seg_ar, seg_hi1;  // seg_hi1: base[31:16] + 1
    logic [5:0][31:0] seg_base, seg_limit;
    // Microcode temporaries: a far transfer's selector (T0) and offset (T1),
    // a segment load's selector (T0) and descriptor (T2, T3), IRET's EFLAGS
    // image (T4).
    logic [15:0]      t0;
    logic [31:0]      t1, t2, t3, t4;
    // T5: a privilege transition's new ESP (an outer IRET's from its frame,
    // a delivery's from the TSS).
    logic [31:0]      t5;
    // A privilege transition's held CS (see "Privilege transitions"): the
    // staged descriptor WB keeps at the uop that checks CS (uop_t hold),
    // with its selector, its access byte as read (the accessed bit's
    // store) and the CPL the transfer goes to, while T0-T3 take the new SS.
    logic [15:0]      hs_sel, hs_ar, hs_hi1;
    logic [31:0]      hs_base, hs_limit;
    logic [7:0]       hs_acc;
    logic [1:0]       hs_cpl;
    fes_i386_pkg::seg_chk_t hs_chk;
    // The staged descriptor (see "Protected mode: a segment load's
    // descriptor"), which D reads for a new-stack access.
    logic                   ds_null;
    logic [31:0]            ds_base, ds_limit, ds_lar;
    logic [15:0]            ds_ar, ds_sar, ds_hi1;
    logic [1:0]             ds_rpl;
    fes_i386_pkg::seg_chk_t ds_chk;
    // CR0 as this build holds it: PE, MP, EM, TS, ET and PG. WAIT raises
    // #NM when MP and TS are both set, CLTS clears TS, and MOV CR0 and LMSW
    // write it (SYSOP_CR0, SYSOP_LMSW). CR0 reads with bits 30-5 set, as
    // Bochs's 386 (cr0_rd). CR2 holds what MOV writes and a #PF's linear
    // address; CR3 the page directory (see Paging).
    logic             cr0_pe, cr0_mp, cr0_em, cr0_ts, cr0_et, cr0_pg;
    logic [31:0]      cr0_rd, cr2, cr3;
    assign cr0_rd = {cr0_pg, 26'h3ff_ffff, cr0_et, cr0_ts, cr0_em, cr0_mp, cr0_pe};
    // The debug registers (see "Debug registers"): DR0-DR3; DR6's bits 15-12
    // and 3-0, the only ones a 386 writes (the rest read as ones, as Bochs's
    // 386 keeps them); DR7, whose bit 10 is always set. DR7.GD (bit 13)
    // makes a MOV to or from DRn raise #DB; its enables arm the breakpoints
    // (see "Breakpoints").
    logic [3:0][31:0] dr;
    logic [3:0]       dr6_lo, dr6_hi;
    logic [31:0]      dr6_rd, dr7;
    assign dr6_rd = {16'hffff, dr6_hi, 8'hff, dr6_lo};
    // TR4-TR7 (#1730), which MOV TRn writes and reads: the 386's decoder
    // runs MOV to and from each (microcode_notes.txt 391, 3B6). They keep
    // what is written; TR6's TLB test command does nothing
    // (docs/i386-cpu-design.md, Architecture).
    logic [3:0][31:0] trn;
    // ---- Breakpoints ----------------------------------------------------------------
    // DR7's fields for each of DR0-DR3: enabled (Ln or Gn: bp_en), R/W 00
    // (an instruction breakpoint: bp_x), 01 (data writes: bp_w) or 11 (data
    // reads and writes: bp_rw; 10 matches nothing, as in Bochs), and LEN's
    // mask of low address bits (bp_m: 00 one byte, 01 two, 11 four; the
    // undefined 10 eight, as Bochs takes it, for data and instructions
    // alike, LEN other than 00 on an instruction breakpoint being undefined
    // on the 386 too). Nothing is compared while no breakpoint is enabled
    // (bp_any), as in Bochs's hwdebug_compare; once one is, every
    // breakpoint whose address and kind match is reported in DR6's B bits,
    // enabled or not (the 386 manual's 12.2.3).
    logic [3:0]       bp_en, bp_x, bp_w, bp_rw;
    logic [3:0][2:0]  bp_m;
    logic             bp_any;
    for (genvar n = 0; n < 4; n++) begin : g_bp
        assign bp_en[n] = dr7[2 * n] || dr7[2 * n + 1];
        assign bp_x[n] = dr7[16 + 4 * n + 1 : 16 + 4 * n] == 2'b00;
        assign bp_w[n] = dr7[16 + 4 * n + 1 : 16 + 4 * n] == 2'b01;
        assign bp_rw[n] = dr7[16 + 4 * n + 1 : 16 + 4 * n] == 2'b11;
        assign bp_m[n] = dr7[18 + 4 * n + 1 : 18 + 4 * n] == 2'b00 ? 3'd0
                       : dr7[18 + 4 * n + 1 : 18 + 4 * n] == 2'b01 ? 3'd1
                       : dr7[18 + 4 * n + 1 : 18 + 4 * n] == 2'b11 ? 3'd3 : 3'd7;
    end
    assign bp_any = bp_en != 4'd0;
    // The instruction breakpoints an instruction at linear address lin
    // matches: its address equal to DRn's but for LEN's low bits.
    function automatic logic [3:0] ibp_match(input logic [31:0] lin, input logic [3:0][31:0] k_dr, input logic k_bp_any,
                                              input logic [3:0] k_bp_x, input logic [3:0][2:0] k_bp_m);
        for (int n = 0; n < 4; n++)
            ibp_match[n] = k_bp_any && k_bp_x[n] && (lin[31:3] == k_dr[n][31:3])
                        && ((lin[2:0] ^ k_dr[n][2:0]) & ~k_bp_m[n]) == 3'd0;
    endfunction
    // The data breakpoints an access of bytes bytes (1 to 8) at linear
    // address a matches, a read (rd) or a write (wr; a read-modify-write is
    // both): any byte of the access within DRn's field, as Bochs's
    // hwdebug_compare and the 386 manual's 12.2.4 have it. The field lies in
    // one 8-byte block; the access in its own block and the next, which is
    // compared carry-free (a + 8 == the field's block).
    function automatic logic [3:0] dbp_match(input logic [31:0] a, input logic [3:0] bytes, input logic rd,
                                              input logic wr, input logic [3:0][31:0] k_dr, input logic k_bp_any,
                                              input logic [3:0] k_bp_w, input logic [3:0] k_bp_rw,
                                              input logic [3:0][2:0] k_bp_m);
        logic [15:0] am;
        logic [7:0]  fm;
        logic [31:0] k_in, k_out, blk;
        for (int n = 0; n < 4; n++) begin
            am = ((16'd1 << bytes) - 16'd1) << a[2:0];
            fm = ((8'd2 << k_bp_m[n]) - 8'd1) << (k_dr[n][2:0] & ~k_bp_m[n]);
            blk = {k_dr[n][31:3], 3'd0};
            k_in = {a[31:3], 3'd0} ^ 32'd8 ^ blk;
            k_out = ({a[31:3], 3'd0} & 32'd8) | (({a[31:3], 3'd0} ^ 32'd8) & ~blk);
            dbp_match[n] = k_bp_any && (rd && k_bp_rw[n] || wr && (k_bp_rw[n] || k_bp_w[n]))
                        && (a[31:3] == k_dr[n][31:3] && (am[7:0] & fm) != 8'd0
                            || k_in == {k_out[30:0], 1'b0} && (am[15:8] & fm) != 8'd0);
        end
    endfunction
    // The x87 pointers, which the 386 keeps for the 387 and FNSTENV and
    // FNSAVE store ("x87 pointers"): the instruction pointer (CS's selector
    // and the instruction's EIP) and the data pointer (the memory operand's
    // segment selector and offset), and each as the real-mode layouts give
    // it, the selector times 16 plus the offset.
    logic [31:0]      fpu_ip, fpu_dp, fpu_lip, fpu_ldp;
    logic [15:0]      fpu_cs, fpu_ds;
    // GDTR and IDTR, with GDTR's limit less 7 (a descriptor's last byte) and
    // IDTR's less 3 (a real-mode vector's) and 7 (a gate's), and whether
    // those are below zero.
    logic [31:0]      gdtr_base, idtr_base;
    logic [15:0]      gdtr_limit, idtr_limit, gdt_lim7, idt_lim3, idt_lim7;
    logic             gdt_tiny7, idt_tiny3, idt_tiny7;
    // LDTR and TR (LLDT, LTR), with LDTR's limit less 7 for a TI=1
    // selector's descriptor, which LDTR's valid bit (clear after a null LLDT)
    // gates. TR is only held: no task switch is built.
    logic [15:0]      ldtr_sel, ldtr_ar, tr_sel, tr_ar;
    logic [31:0]      ldtr_base, ldtr_limit, ldt_lim7, tr_base, tr_limit;
    logic             ldtr_valid, ldt_tiny7;
    // The TSS's checks, as TR is written: its stack slots' (ESP's offset
    // against TR's limit less 7 in a 386 TSS, 3 in a 286 one), its I/O
    // permission bitmap's word (less 1), and whether it has a bitmap (a 386
    // TSS of 104 bytes or more).
    logic [31:0]      tss_lim_sp, tss_lim_bm;
    logic             tss_tiny_sp, tss_tiny_bm, tss_iomap;
    function automatic logic [66:0] tss_chk(input logic [31:0] limit, input logic [15:0] ar);
        tss_chk = {limit - (ar[3] ? 32'd7 : 32'd3), limit < (ar[3] ? 32'd7 : 32'd3), limit - 32'd1, limit == 32'd0,
                   ar[3] && !ar[2] && ar[0] && limit >= 32'd103};
    endfunction
    // Each segment's access check, so the check in M1 is one compare or two
    // (fes_i386_pkg::seg_chk): the limit less 0, 1 and 3 for 1-, 2- and
    // 4-byte accesses, or an expand-down segment's upper bound so less, and
    // whether that is below zero (lim, tiny); an expand-down segment's limit
    // (low, expd); and whether it refuses reads (not present, or execute-only
    // code) or writes (not present, code, or read-only data) (rbad, wbad).
    // A real-mode load keeps a segment's limit and type, setting P and S.
    logic [5:0][2:0][31:0] seg_lim;
    logic [5:0][2:0]       seg_tiny;
    logic [5:0][31:0]      seg_low;
    logic [5:0]            seg_expd, seg_rbad, seg_wbad;
    fes_i386_pkg::seg_chk_t [5:0] init_chk;  // reset's, from init_limit and init_ar
    // D's fetch check of CS's limit (see D): the limit plus one's bits 32:4,
    // those less 1, and its bits 3:0, as CS is written.
    logic [61:0]           cs_fl;
    function automatic logic [61:0] fetch_lim(input logic [31:0] limit);
        logic [32:0] end1, end15;
        end1 = {1'b0, limit} + 33'd1;
        end15 = {1'b0, limit} - 33'd15;
        fetch_lim = {end1[32:4], end15[32:4], end1[3:0]};
    endfunction
    always_comb for (int k = 0; k < 6; k++) init_chk[k] = fes_i386_pkg::seg_chk(init_limit[k], init_ar[k]);
    logic             code32;
    assign code32 = seg_ar[SEG_CS][14];
    // EX's running EFLAGS (see EX), which D reads for a string's DF.
    logic [17:0]      ex_flags;

    // ---- Pipeline registers -------------------------------------------------------
    pipe_t ag_s, m1_s, m2_s, ex_s, wb_s;
    // halted: in HLT (hlt) or stopped for good (trace_unimplemented), kept as a
    // register of its own, which D's issue and the ports read.
    logic  wb_flush, wb_stop, halted, hlt;
    // A uop that retires, faults or stops in WB this cycle, and whether it
    // flushes everything younger.
    assign wb_stop = wb_s.valid && (wb_s.uop.ctl.fault != fes_i386_pkg::FAULT_NONE
                                    || (wb_s.uop.cls == fes_i386_pkg::UOP_SPECIAL && wb_s.uop.op == 5'd1));

    // A load in M2 waiting for its bytes freezes D to WB (m2_load: M2 holds a
    // load, registered as it enters; one that fails the limit check in M1
    // waits too, then faults). WB waits as well, so a taken branch or a fault
    // there takes effect, and flushes, once the bytes arrive, even when the
    // load is on the wrong path. So does a multiply or divide while it works
    // in EX (md_busy, registered as it enters EX; see EX), an I/O access in
    // WB until the machine has completed it (io_wait, set as the uop enters
    // WB and cleared on the completing edge; see WB), and an INTR being taken
    // until the machine has returned its vector (int_wait, set at the
    // boundary and cleared on the returning edge; see Interrupts), and a
    // store in WB while the write buffer has no room for it (st_wait, see
    // WB). Each wait is one register, so the freeze stays one LUT of six.
    logic freeze, m2_load, md_busy, io_wait, int_take, int_nmi, int_wait, st_wait;
    logic       int_dbg;  // the event int_take delivers is a #DB (see Interrupts)
    logic [1:0] int_ph;   // ... and how far its choice has got
    logic int_next;  // an interrupt is taken on this edge (see Interrupts)
    assign freeze = m2_load && !dmem_valid || md_busy || io_wait || int_wait || st_wait;

    // A fault in WB is delivered (exc_take): WB flushes, the front end and DC
    // restart, and DC takes the exception's entry the cycle after
    // (exc_inject). exc_active holds until the delivery's last uop retires. A
    // fault before then is delivered in its place, as Bochs's exception()
    // does: as a double fault (vector 8, error code 0) when the delivery's
    // exception and the fault are both contributory (#DE, #NP, #SS, #GP), and
    // a fault in a double fault's delivery shuts the CPU down (wb_shut). What
    // is delivered (see Protected-mode delivery): exc_vec, its error code
    // (exc_err, with EXT, bit 0, set for a fault in an exception's or
    // interrupt's delivery), whether it pushes one (exc_haserr, in protected
    // mode), its class (exc_class: benign, contributory, double fault), and
    // the RF its EFLAGS image takes (del_rf: set for a fault, and for an
    // interrupt between a REP string's elements or after an IRETD that set
    // RF).
    // A #PF is its own class: a contributory fault or another #PF in its
    // delivery is a double fault, and a #PF in a contributory fault's is
    // delivered (Bochs's is_exception_OK).
    localparam logic [1:0] EXC_BENIGN = 2'd0, EXC_CONTRIB = 2'd1, EXC_DF = 2'd2, EXC_PF = 2'd3;
    logic       exc_take, exc_active, exc_inject;
    // A task switch's commit retires (tsw_go): DC takes the new task's
    // descriptor loads the cycle after, as a fault's entry (tsw_inj; see
    // Task switches).
    logic       tsw_go, tsw_inj, ts_krf;
    logic [7:0] exc_vec;
    logic [15:0] exc_err;
    logic [1:0] exc_class;
    logic       exc_haserr, del_rf;

    // What WB does with its uop once D to WB are not frozen, decided as the
    // uop enters WB (see WB): wb_flushes, flush everything younger (a taken
    // branch, a fault, HLT); wb_redir, restart the front end and DC (a taken
    // branch, or a fault it delivers); wb_deliver, deliver its fault. So each
    // of these is one gate from freeze. An interrupt being taken (int_take)
    // flushes and restarts them in place of the uop's own decisions
    // (int_go).
    logic wb_flushes, wb_redir, wb_deliver, wb_nested, wb_df, wb_shut, int_go;
    assign wb_flush = !freeze && (wb_flushes || int_take);
    assign exc_take = !freeze && wb_deliver && !int_take;
    assign int_go = !freeze && int_take && int_ph == 2'd2;
    // A replay in WB (rp_go) flushes as a fault does but delivers nothing: the
    // front end restarts at its instruction through start, two cycles on,
    // when start_linear holds CS.base + EIP, and D issues nothing until then.
    logic rp_go;
    assign rp_go = !freeze && wb_flushes && !int_take && wb_s.valid
                && wb_s.uop.ctl.fault == fes_i386_pkg::FAULT_REPLAY;
    // A replay of an instruction after a store into the bytes the front end
    // holds (see Self-modifying code): smc_due once the storing instruction
    // has ended, smc_defer while queue16 waits for an instruction past its
    // window, smc_mark as the instruction's first uop enters WB, wb_smc while
    // it is there, smc_go as WB restarts it.
    logic smc_due, smc_defer, smc_mark, wb_smc, smc_go;
    // wb_frp: the uop in WB replays for the fetch check.
    logic wb_frp;

    // ---- Start and redirect -------------------------------------------------------
    // After reset the front end starts at CS.base + EIP, one cycle after the
    // sum is registered.
    logic [1:0]  start;
    logic [31:0] cs_eip, start_linear;
    logic        redirect;
    logic [31:0] redirect_linear, redirect_eip;
    assign cs_eip = seg_base[SEG_CS] + eip;
    always_ff @(posedge clk) begin
        if (reset || rp_go) begin
            start <= 2'd1;
        end else if (start != 2'd0) begin
            start <= start + 2'd1;
        end
        start_linear <= cs_eip;
    end
    // A delivery refetches from the faulting instruction, or the one before
    // (start_linear is a cycle old), which the delivery's far jump discards.
    // D's EIP is the faulting instruction's, a fetch fault's too (its first
    // byte, which may be under the limit when the instruction runs past it),
    // and the delivery's entry fetches nothing, so it is not checked against
    // CS's limit. Every real-mode delivery's redirect restarts at the low 16
    // bits of EIP, the IP its frame pushes. An interrupt's EIP is the next
    // instruction's. The address selects key on WB's fault field and int_take,
    // registers (a taken branch has neither), so
    // the fetch address stays off exc_take's path.
    // A branch's redirect goes to its target, or for one predicted taken
    // that was not, to the next instruction: wb_rlin and wb_reip, chosen as
    // the uop enters WB (see EX).
    logic wb_faulted;
    logic [31:0] wb_rlin, wb_reip, wb_fall;
    assign wb_faulted = wb_s.uop.ctl.fault != fes_i386_pkg::FAULT_NONE;
    assign redirect = start == 2'd2 || !freeze && (wb_redir || int_take);
    assign redirect_linear = start == 2'd2 || wb_faulted || int_take ? start_linear : wb_rlin;
    // Real-mode interrupt and exception frames carry only the low IP, and
    // their delivery entry must restart at that same 16-bit offset. Keep the
    // full EIP for protected-mode deliveries.
    assign redirect_eip = start == 2'd2 ? eip : wb_faulted || int_take ? {cr0_pe ? eip[31:16] : 16'd0, eip[15:0]}
                        : wb_reip;

    // ---- F1 to Q ------------------------------------------------------------------
    logic        q_valid, d_ready, fe_mem_load, pred_on;
    fetched_t    q;
    btb_write_t  btb_wr;
    logic [3:0]  ras_set_ptr;
    logic        ras_set_wr;
    logic [31:0] ras_set_lin;
    logic [6:0][27:0] fe_block;
    logic [6:0]       fe_valid;
    logic [6:0][7:0]  fe_pp;
    logic [6:0]       fe_pk;
    fes_i386_pkg::ftag_t mem_tag;
    always_ff @(posedge clk) if (reset) pred_on <= !queue16;
    fes_i386_frontend frontend (
        .clk, .reset, .redirect, .redirect_linear, .code32, .mem_block, .mem_load(fe_mem_load),
        .mem_data, .mem_valid, .mem_tag, .q_valid, .q, .d_ready, .pred_en(pred_on), .btb_wr, .ras_set_ptr, .ras_set_wr,
        .ras_set_lin, .held_block(fe_block), .held_valid(fe_valid), .held_pp(fe_pp), .held_pk(fe_pk)
    );
    assign mem_load = fe_mem_load && !halted && !wb_stop;

    // ---- DC ---------------------------------------------------------------------
    // Q's output register is decoded into a two-entry buffer: dc holds the
    // instruction D issues, and dc_skid takes Q's instruction when dc cannot.
    // Q may load its output whenever dc_skid is empty, so D's stall stays out
    // of Q's loop, and everything D's issue waits on starts from a register.
    decoded_t dc, dc_skid, dc_q;
    logic     dc_valid, dc_skid_valid;
    logic     d_stop;   // D issued a uop nothing after which can retire
    logic     issue;
    logic     dc_load;  // dc takes the next instruction
    logic     dc_branch, dc_stack;  // dc_branch: not used yet
    logic     q_two;                // a two-byte opcode: the ModRM is byte 2
    assign q_two = q.bytes[0] == 8'h0f;
    logic [7:0] q_modrm;
    assign q_modrm = q_two ? q.bytes[2] : q.bytes[1];
    logic [2:0] q_stk;              // dc_q.stk and .seq, apart so no field of dc_q reads another
    logic [4:0] q_seq;
    logic       q_direct, q_xlat;   // no base or index (a moffs, the vector's entry); XLAT's [BX + AL]
    logic [8:0] q_upc;              // the decoder's routine address (dc_q.upc), read for tsw too
    uop_t       q_uop;              // dc_q.uop, .lea and the address registers, for dc_q.rd_str
    logic       q_lea, q_has_base, q_has_index, q_opsize32;
    logic [2:0] q_base, q_index;
    logic [31:0] q_lea_disp;
    logic        q_b_sys;
    logic [3:0]  q_slot;
    fes_i386_decode decode (
        .q, .code32, .stack(dc_stack), .wait_nm(cr0_mp && cr0_ts), .esc_nm(cr0_em || cr0_ts), .x87(x87_present),
        .x87_insn(dc_q.x87), .x87_wait(dc_q.x87_wait), .x87_fmt(dc_q.x87_fmt), .x87_op(dc_q.x87_op), .x87_part(dc_q.x87_part), .pe(cr0_pe), .vm(eflags[17]), .cpl, .iopl(eflags[13:12]), .nt(eflags[14]), .dr_gd(dr7[13]), .uop(q_uop), .opsize32(q_opsize32), .lea(q_lea), .lea_early(dc_q.lea_early),
        .lea_disp(q_lea_disp), .branch(dc_branch), .consumes(dc_q.consumes), .reads_seg(dc_q.reads_seg),
        .seg_index(dc_q.seg_index), .stop(dc_q.stop), .stk(q_stk), .push_eip(dc_q.push_eip),
        .cs_base(dc_q.cs_base), .seq(q_seq), .sel_part(dc_q.sel_part), .far_jmp(dc_q.far_jmp), .far_chk(dc_q.far_chk),
        .far_sel(dc_q.far_sel), .wseg(dc_q.wseg), .upc(q_upc), .direct(q_direct), .xlat(q_xlat),
        .m_seg(dc_q.m_seg), .slot(q_slot), .str_op(dc_q.str_op), .str_rep(dc_q.str_rep), .ecnt(dc_q.ecnt),
        .b_sys(q_b_sys), .sys_idx(dc_q.sys_idx), .moff(dc_q.moff)
    );
    // A stack operation's address is ESP, or EBP for LEAVE, with no index:
    // chosen here, so D's operand lookups start from dc's register.
    logic       am_has_base, am_has_index;
    logic [2:0] am_base, am_index;
    logic [1:0] am_scale;
    fes_i386_amode amode (
        .modrm(q_modrm), .sib(q_two ? q.bytes[3] : q.bytes[2]), .addr32(q_uop.mem.addr32), .has_base(am_has_base),
        .base(am_base), .has_index(am_has_index), .index(am_index), .scale(am_scale), .stack(dc_stack)
    );
    assign dc_q.uop = q_uop;
    assign dc_q.opsize32 = q_opsize32;
    assign dc_q.lea = q_lea;
    assign dc_q.stk = q_stk;
    // The early ALU's uops (decoded_t ealu): a one-uop ADD, INC, DEC or MOV
    // to a GPR, of GPRs and an immediate, with no memory operand, at a 32-bit
    // operand size; at a 16-bit one, ADD r, imm, INC and DEC. AG's adder
    // gives its result as base + index + displacement: ADD r, imm is r + imm,
    // ADD r, r2 is r + r2, INC and DEC are r + 1 and r - 1, MOV r, imm is imm
    // and MOV r, r2 is r2. At 16 bits the sum wraps as a 16-bit address does
    // and keeps r's high half, as a 16-bit stack's ESP does. The second
    // operand of a MOV or ADD is src2, else imm; D's other sources of its b
    // (a system register, a far selector) leave it out.
    logic q_ealu, q_add, q_inc, q_dec, q_mov, q_gpr2;
    assign q_add = q_uop.op == 5'(fes_i386_pkg::ALU_ADD);
    assign q_inc = q_uop.op == 5'(fes_i386_pkg::ALU_INC);
    assign q_dec = q_uop.op == 5'(fes_i386_pkg::ALU_DEC);
    assign q_mov = q_uop.op == 5'(fes_i386_pkg::ALU_MOV);
    assign q_gpr2 = q_uop.src2.space == fes_i386_pkg::RS_GPR;
    assign q_ealu = q_seq == fes_i386_pkg::SEQ_NONE && q_uop.cls == fes_i386_pkg::UOP_ALU && !q_lea
                 && q_uop.mem.kind == fes_i386_pkg::MEM_NONE && q_stk == fes_i386_pkg::STK_NONE
                 && (q_uop.size == fes_i386_pkg::SIZE_32
                     || q_uop.size == fes_i386_pkg::SIZE_16 && (q_inc || q_dec || q_add && !q_uop.src2.valid))
                 && !q_uop.sp_write && !q_uop.seg2 && q_uop.io == 2'd0
                 && q_uop.dst.valid && q_uop.dst.space == fes_i386_pkg::RS_GPR && !q_b_sys
                 && (q_mov || (q_add || q_inc || q_dec) && q_uop.src1.valid && q_uop.src1.space == fes_i386_pkg::RS_GPR
                              && q_uop.src1.index == q_uop.dst.index)
                 && (q_inc || q_dec || !q_uop.src2.valid || q_gpr2);
    assign dc_q.ealu = q_ealu;
    assign dc_q.b_sys = q_b_sys;
    assign dc_q.lea_disp = !q_ealu ? q_lea_disp : q_inc ? 32'd1 : q_dec ? 32'hffff_ffff
                         : q_uop.src2.valid ? 32'd0 : q_uop.imm;
    // XLAT's address is BX (or EBX) plus AL, zero-extended (index8).
    assign q_has_base = q_ealu ? !q_mov || q_uop.src2.valid
                      : q_stk != fes_i386_pkg::STK_NONE || am_has_base && !q_direct || q_xlat;
    assign q_base = q_ealu ? (q_mov ? q_uop.src2.index[2:0] : q_uop.src1.index[2:0])
                  : q_stk == fes_i386_pkg::STK_LEAVE ? 3'd5 : q_stk != fes_i386_pkg::STK_NONE ? 3'd4
                  : q_xlat ? 3'd3 : am_base;
    assign q_has_index = q_ealu ? q_add && q_uop.src2.valid
                       : q_stk == fes_i386_pkg::STK_NONE && (am_has_index && !q_direct || q_xlat);
    assign q_index = q_ealu ? q_uop.src2.index[2:0] : q_xlat ? 3'd0 : am_index;
    assign dc_q.has_base = q_has_base;
    assign dc_q.base = q_base;
    assign dc_q.has_index = q_has_index;
    assign dc_q.index = q_index;
    assign dc_q.rd_str = fes_i386_pkg::str_reads(q_uop, q_lea, q_has_base, q_base, q_has_index, q_index);
    assign dc_q.scale = q_stk == fes_i386_pkg::STK_NONE && !q_xlat && !q_ealu ? am_scale : 2'd0;
    assign dc_q.index8 = q_xlat;
    // The ModRM operand's address registers, kept for a later uop when a
    // stack uop holds the fields above (POP r/m).
    assign dc_q.m_has_base = am_has_base && !q_direct;
    assign dc_q.m_base = am_base;
    assign dc_q.m_has_index = am_has_index && !q_direct;
    assign dc_q.m_scale = am_scale;
    assign dc_q.esp_adj = 6'd0;
    assign dc_q.esp_wrap = 4'd0;
    assign dc_q.length = q.length;
    // The governor's fields; ea3 is an address of base, index and an 8- or
    // 16/32-bit displacement (ModRM mod 1 or 2).
    assign dc_q.gov = '{two: q_two, op: q_two ? q.bytes[1] : q.bytes[0], mreg: q_modrm[5:3],
                        rm_reg: q_modrm[7:6] == 2'b11, o32: q_opsize32, rep: q.prefixes.rep != 2'b00,
                        ea3: am_has_base && am_has_index && q_modrm[7] != q_modrm[6] && !q_direct,
                        ref_test_excluded: GOV_REFERENCE_DIAGNOSTIC && (code32 || q.prefix_count != 4'd0),
                        prefix286: q.prefix286};
    assign dc_q.seq = q_seq;
    assign dc_q.step = 3'd0;
    assign dc_q.more = q_seq != fes_i386_pkg::SEQ_NONE;
    assign dc_q.far_t = 1'b0;
    assign dc_q.a_t1 = 1'b0;
    assign dc_q.b_t1 = 1'b0;
    assign dc_q.disp_t1 = 1'b0;
    assign dc_q.t_rd = 1'b0;
    assign dc_q.popad_esp = 1'b0;
    assign dc_q.b_far = 1'b0;
    assign dc_q.b_t4 = 1'b0;
    assign dc_q.nochk = 1'b0;
    assign dc_q.gsz = 1'b0;
    assign dc_q.errp = 1'b0;
    assign dc_q.dmode = 2'd0;
    assign dc_q.xc = 4'd0;
    assign dc_q.xs = 1'b0;
    assign dc_q.tss = 3'd0;
    assign dc_q.pm = 2'd0;
    assign dc_q.pk = 5'd0;
    assign dc_q.pdrop = 1'b0;
    assign dc_q.zx = 1'b0;
    assign dc_q.pimm = 1'b0;
    assign dc_q.vgo = 1'b0;
    // A routine DC starts is IRET's kind of task switch, should it be one
    // (an IRET with NT set, UC_TSSAVE); a tgo word sets another's.
    assign dc_q.tgo = 1'b0;
    assign dc_q.tgk = 2'd0;
    assign dc_q.tsk = 2'(fes_i386_pkg::TSK_IRET);
    assign dc_q.tsf = 5'd0;
    assign dc_q.upc = q_upc;
    assign dc_q.tsw = q_seq == fes_i386_pkg::SEQ_UCODE && q_upc == fes_i386_ucode_pkg::UC_TSSAVE;
    assign dc_q.slot = {{3{q_slot[3]}}, q_slot};
    // The string engine's first uop loads D's copies; the rest are
    // fes_i386_seq's.
    assign dc_q.str_load = q_seq == fes_i386_pkg::SEQ_STRING || q_seq == fes_i386_pkg::SEQ_ENTER;
    assign dc_q.str_a = 1'b0;
    assign dc_q.str_b = 1'b0;
    assign dc_q.str_two = 1'b0;
    assign dc_q.str_fin = 1'b0;
    assign dc_q.str_cnt = 1'b0;
    assign dc_q.b_fp = 1'b0;
    assign dc_q.x_prev = 1'b0;
    assign dc_q.fetched = 1'b1;
    assign dc_q.lin = q.linear;
    assign dc_q.bm = q.bm;
    assign dc_q.bway = q.bway;
    assign dc_q.bctr = q.bctr;
    assign dc_q.tk = q.tk;
    assign dc_q.xbad = q.xbad;
    assign dc_q.ptgt = q.ptgt;
    assign dc_q.pp0 = q.pp0;
    assign dc_q.pp1 = q.pp1;
    assign dc_q.tm0 = q.tm0;
    assign dc_q.tm1 = q.tm1;
    assign dc_q.ts0 = q.ts0;
    assign dc_q.ts1 = q.ts1;
    assign d_ready = !dc_skid_valid;
    // A fixed sequence's uops issue from dc in turn: as each but the last
    // issues, dc takes the next (fes_i386_seq), whose rewritten fields come
    // from the instruction's first uop, which dc0 keeps, so none of dc's is
    // held at some steps and not others.
    // A microcode routine's next uop is the ROM's word at dc.upc, read as an
    // M10K with a registered output: it is there the cycle after dc settles
    // (rom_ok: dc held over the last edge), so D waits a cycle for each
    // (uc_wait). Both are registers, off the M10K's pins.
    decoded_t dc_next, dc0;
    fes_i386_pkg::ucode_t rom_q;
    logic       rom_ok, uc_wait;
    fes_i386_ucode_rom ucode (.clk, .addr(dc.upc), .q(rom_q));
    always_ff @(posedge clk) rom_ok <= dc_valid && !issue;
    assign uc_wait = dc.seq == fes_i386_pkg::SEQ_UCODE && dc.more && !rom_ok;
    logic [2:0] str_cnt3;  // the string engine's count is 2, 1, 0 (D)
    logic       gate32, gate_trap;  // a protected-mode delivery's gate: a 386 gate, a trap gate (WB, SYSOP_GATE)
    logic       xp, cg;             // the held transfer changes privilege; a far CALL is through a call gate (WB)
    logic [4:0] pcnt;               // a call gate's parameter count (WB, SYSOP_GATE)
    // An IRETD at CPL 0 whose EFLAGS image (T4) has VM set returns to V86
    // mode (see V86 mode): read where IRET's vgo word issues, after T4's
    // load has retired.
    logic       vret;
    assign vret = t4[17] && cpl == 2'd0 && dc0.opsize32;
    // A far JMP's or CALL's descriptor, or a delivery's gate, in T3 is an
    // available TSS (tsw_tss) or a task gate (tsw_tg): its tgo word, which
    // waits for T3, goes on at the task switch (see Task switches).
    logic       tsw_tss, tsw_tg;
    assign tsw_tss = !t3[12] && (t3[11:8] == 4'd1 || t3[11:8] == 4'd9);
    assign tsw_tg = !t3[12] && t3[11:8] == 4'd5;
    // ---- The x87 unit (fes_i386_x87). ----
    // The uop at D's head drives its issue side, and WB its commit side.
    // A uop's part is the environment field fpn names, a save image's chunk
    // (fpn 7: register fpj[4:2]'s chunk fpj[1:0]), or an operand's chunk,
    // which the uop's offset gives: 0, 4 and 8 bytes on.
    logic        x87_hold, x87_nx, x87_iss, x87_clr_pointers;
    logic [31:0] x87_sval;
    assign x87_iss = cur_valid && dc.x87;
    // FLDENV and FRSTOR load the environment's fields 3 to 6 back into the
    // x87 pointers and the opcode, the inverse of the words SYS_RD_FIP to
    // SYS_RD_FDS store. In real mode the layouts hold one linear address a
    // pointer, with the opcode beside its high bits and no selector, so the
    // selector reads back zero, as Bochs's FLDENV leaves it; in protected
    // mode they hold the offset and the selector, and only the 32-bit
    // layout has room for the opcode (387 PRM, the FLDENV layouts;
    // bochs/cpu/fpu/fpu.cc's FLDENV).
    logic        x87_ld_env;
    logic [15:0] x87_ld_hi;      // a real-mode pointer's high half
    logic [10:0] x87_ld_opcode;
    assign x87_ld_env = wb_commit && wb_s.x87 && wb_s.uop.mem.kind == fes_i386_pkg::MEM_LOAD
                     && !wb_s.x87_part[5] && wb_s.x87_part[2:0] >= 3'd3;
    assign x87_ld_hi = wb_s.uop.size == fes_i386_pkg::SIZE_32 ? wb_s.result[27:12]
                                                              : {12'd0, wb_s.result[15:12]};
    assign x87_ld_opcode = !cr0_pe ? wb_s.result[10:0]
                         : wb_s.uop.size == fes_i386_pkg::SIZE_32 ? wb_s.result[26:16] : 11'd0;
    fes_i386_x87 x87 (
        .clk, .reset, .present(x87_present), .f0(x87_f0), .f1(x87_f1),
        .error(x87_irq13), .latched(trace_x87_latched),
        .iss(x87_iss), .iss_wait(dc.x87_wait), .iss_op(dc.x87_op), .iss_fmt(dc.x87_fmt),
        .iss_first(d_first), .iss_fire(issue), .iss_last(dc.uop.ctl.end_of_instruction),
        .iss_part(dc.x87_part),
        .hold(x87_hold), .sval(x87_sval), .nx(x87_nx),
        .wb(wb_commit && wb_s.x87), .wb_last(wb_commit && wb_s.x87 && wb_s.uop.ctl.end_of_instruction),
        .wb_val(wb_s.result), .wb_part(wb_s.x87_part), .flush(wb_flush),
        .wb_opcode_set(x87_ld_env && wb_s.x87_part[2:0] == 3'd4), .wb_opcode(x87_ld_opcode),
        .cw_o(arch_x87_cw), .sw_o(arch_x87_sw), .tw_o(arch_x87_tw), .opcode_o(arch_x87_opcode),
        .clr_pointers(x87_clr_pointers),
        .busy_o(trace_x87_busy), .trace_seq(trace_x87_seq), .regs_o(arch_x87_regs)
    );
    assign arch_x87_ip = fpu_ip;
    assign arch_x87_cs = fpu_cs;
    assign arch_x87_dp = fpu_dp;
    assign arch_x87_ds = fpu_ds;

    fes_i386_seq seq (.d(dc), .d0(dc0), .w(rom_q), .cnt(str_cnt3), .gate32, .xp, .cg, .pcnt, .vret, .tsw_tss, .tsw_tg,
                      .n(dc_next));
    // An exception's entry: a NOP that starts the ROM's vector routine with
    // the fault's vector, at length 0, so the routine pushes D's EIP, the
    // faulting instruction's. It goes in through dc_skid the cycle after the
    // fault's flush, which has emptied DC and Q. In protected mode the
    // routine is the delivery through the IDT, from V86 mode its own (VM
    // changes only at a far jump, which flushes, so EFLAGS has the faulting
    // instruction's). After a task switch's commit (tsw_inj), the same entry
    // starts the new task's descriptor loads, tsload, or tsv86 for a V86
    // task, at the new EIP (see Task switches).
    decoded_t dc_exc;
    always_comb begin
        dc_exc = '0;
        dc_exc.uop.cls = fes_i386_pkg::UOP_SPECIAL;  // SPECIAL_NOP
        dc_exc.far_sel = {6'd0, exc_vec, 2'b00};
        dc_exc.upc = tsw_inj ? (eflags[17] ? fes_i386_ucode_pkg::UC_TSV86 : fes_i386_ucode_pkg::UC_TSLOAD)
                   : eflags[17] ? fes_i386_ucode_pkg::UC_VVEC
                   : cr0_pe ? fes_i386_ucode_pkg::UC_PVEC : fes_i386_ucode_pkg::UC_VECTOR;
        dc_exc.seq = fes_i386_pkg::SEQ_UCODE;
        dc_exc.more = 1'b1;
        dc_exc.tsw = tsw_inj;
        dc_exc.gov.op = 8'hcd;  // the governor charges a delivery as INT
    end
    // A string's first element ends the instruction when its count is 0 or 1
    // (s_end1, see the string engine), which seq does not know when it
    // builds that element.
    logic dc_more, s_end1, s_kill1;
    assign dc_more = dc.more && !s_end1;
    assign dc_load = !dc_valid || (issue && !dc_more);
    always_ff @(posedge clk) begin
        if (reset || redirect) begin
            dc_valid <= 1'b0;
            dc_skid_valid <= 1'b0;
        end else begin
            if (dc_load) dc_valid <= dc_skid_valid || q_valid;
            if (exc_inject) begin
                dc_skid_valid <= 1'b1;
            end else if (dc_skid_valid) begin
                if (dc_load) dc_skid_valid <= 1'b0;
            end else if (q_valid && !dc_load) begin
                dc_skid_valid <= 1'b1;
            end
        end
        if (!dc_valid || issue) dc <= dc_valid && dc_more ? dc_next : dc_skid_valid ? dc_skid : dc_q;
        if (dc_load) dc0 <= dc_skid_valid ? dc_skid : dc_q;
        if (exc_inject) dc_skid <= dc_exc;
        else if (!dc_skid_valid) dc_skid <= dc_q;
    end

    // ---- D ------------------------------------------------------------------------
    logic cur_valid;
    assign cur_valid = dc_valid && !d_stop;

    // EIP of the instruction in D, and of the next: EIP plus the length, in
    // 16-bit code too, so an instruction that ends at offset FFFFh leaves
    // EIP 10000h, as Bochs's does. An instruction that starts or runs past
    // CS's limit raises #GP(0) at its fetch, at its first byte, before
    // anything its decode found (cs_gp): when EIP plus the length passes
    // the limit plus one. A delivery's entry (dc_exc) and its routine fetch
    // nothing (fetched clear), so they are not checked: an IRETD in V86 mode
    // may leave EIP past FFFFh, where only the next fetch faults, as in
    // Bochs. Real-mode delivery redirects use the low 16-bit IP. The
    // compare is split at bit 4 so it runs beside d_eip_next's adder: the
    // low nibble plus the length carries at most 1 into EIP's upper 28
    // bits, which are compared with the limit plus one's upper bits (cs_lh)
    // and those less 1 (cs_lh1), both registered as CS is written (cs_fl).
    // A faulting uop keeps its destination, which nothing reads: it stops
    // at WB, which writes nothing for a fault, and D issues nothing after
    // it (d_stop).
    logic [31:0] d_eip, d_eip_next;
    logic [4:0]  eip_lo;
    logic [28:0] cs_lh, cs_lh1, eip_hi;
    logic [3:0]  cs_ll;
    logic        cs_gt, cs_eq, cs_eq1, cs_gp, seg_ss_rm, seg_ss_big;
    assign cs_lh = cs_fl[61:33];
    assign cs_lh1 = cs_fl[32:4];
    assign cs_ll = cs_fl[3:0];
    assign eip_hi = {1'b0, d_eip[31:4]};
    assign eip_lo = {1'b0, d_eip[3:0]} + {1'b0, dc.length};
    assign cs_gt = eip_hi > cs_lh;
    assign cs_eq = eip_hi == cs_lh;
    assign cs_eq1 = eip_hi == cs_lh1;
    assign cs_gp = dc.fetched && (eip_lo[4] ? cs_gt || cs_eq || cs_eq1 && eip_lo[3:0] > cs_ll
                                            : cs_gt || cs_eq && eip_lo[3:0] > cs_ll);
    assign d_eip_next = d_eip + {28'd0, dc.length};
    // A direct branch the front end predicted taken (pt): Jcc, LOOP and its
    // kin, JCXZ, JMP rel, and CALL rel's jump. The next instruction's EIP is
    // the branch's target: EIP + length + displacement, wrapped by operand
    // size, as AG works it out. A three-input add beside d_eip_next's.
    logic        d_dbr, d_pt;
    logic [31:0] d_tgt_sum, d_tgt;
    assign d_dbr = dc.uop.cls == fes_i386_pkg::UOP_BRANCH && !dc.far_jmp && !dc.uop.eoi_taken
                && (dc.uop.op == 5'(fes_i386_pkg::BR_JCC) || dc.uop.op == 5'(fes_i386_pkg::BR_JMP)
                    || dc.uop.op == 5'(fes_i386_pkg::BR_LOOP) || dc.uop.op == 5'(fes_i386_pkg::BR_LOOPE)
                    || dc.uop.op == 5'(fes_i386_pkg::BR_LOOPNE) || dc.uop.op == 5'(fes_i386_pkg::BR_JCXZ))
                && (dc.seq == fes_i386_pkg::SEQ_NONE || dc.seq == fes_i386_pkg::SEQ_CALL);
    assign d_pt = dc.tk && d_dbr;
    assign d_tgt_sum = (dc.opsize32 ? d_eip : {16'd0, d_eip[15:0]}) + {28'd0, dc.length} + dc.uop.imm;
    assign d_tgt = dc.opsize32 ? d_tgt_sum : {16'd0, d_tgt_sum[15:0]};
    // A near RET (op 10, BR_RET) the return stack predicted, or an indirect
    // near JMP or CALL (nind, below) the BTB predicted to its last target
    // (ipt): the next instruction's EIP is the predicted target's linear
    // address less CS.base, not wrapped by operand size, so a prediction with
    // the wrong upper bits fails EX's compare. A near CALL's jump (ncall):
    // CALL rel's (SEQ_CALL) or CALL r/m's (SEQ_CALLI, op 11, BR_JMP_IND).
    logic        d_nret, d_ipt, d_ncall, d_nind;
    logic [31:0] d_ieip;
    assign d_nret = dc.uop.cls == fes_i386_pkg::UOP_BRANCH && dc.uop.op == 5'd10 && dc.seq == fes_i386_pkg::SEQ_NONE;
    assign d_ipt = dc.tk && (d_nret || d_nind);
    assign d_ieip = dc.ptgt - seg_base[SEG_CS];
    assign d_ncall = dc.uop.cls == fes_i386_pkg::UOP_BRANCH
                  && (dc.seq == fes_i386_pkg::SEQ_CALL || dc.seq == fes_i386_pkg::SEQ_CALLI && dc.uop.op == 5'd11);
    // An indirect near JMP's or CALL's jump (nind): JMP r/m (op 11) or CALL
    // r/m's last uop. Only that uop is ipt: the instruction's EIP moves at
    // its last uop.
    assign d_nind = dc.uop.cls == fes_i386_pkg::UOP_BRANCH && dc.uop.op == 5'd11
                 && (dc.seq == fes_i386_pkg::SEQ_NONE || dc.seq == fes_i386_pkg::SEQ_CALLI);

    // A task switch's TSS field (decoded_t tsf; see Task switches), of TR's
    // TSS (TSS_FLD) or the new one, the descriptor in T2 and T3 (TSS_NFLD),
    // in that TSS's layout: f 0 the back link, 1 CR3, 2 EIP, 3 EFLAGS, 4-11
    // EAX to EDI, 12-17 ES, CS, SS, DS, FS and GS, 18 the LDT, 31 the last
    // byte (a 386 TSS's 67h, a 286 one's 2Bh). A 386 TSS's are dwords at 4f
    // + 18h, its selectors words there; a 286 one's words at 2f + 0Ah (its
    // LDT at 2Ah). A 286 TSS's word into a GPR reads ones above (ones).
    logic        tsf_any, tsf_new, tsf_32;
    logic [4:0]  tsf;
    logic [6:0]  tsf_off;
    logic [3:0]  tsf_bytes;
    assign tsf_new = dc.tss == 3'(fes_i386_pkg::TSS_NFLD);
    assign tsf_any = dc.tss == 3'(fes_i386_pkg::TSS_FLD) || tsf_new;
    assign tsf_32 = tsf_new ? t3[11] : tr_ar[3];
    assign tsf = dc.tsf;
    assign tsf_off = tsf == 5'd0 ? 7'h00 : tsf == 5'd31 ? (tsf_32 ? 7'h67 : 7'h2b)
                   : tsf_32 ? {tsf, 2'b00} + 7'h18 : tsf == 5'd18 ? 7'h2a : {1'b0, tsf, 1'b0} + 7'h0a;
    assign tsf_bytes = tsf == 5'd31 ? 4'd1 : tsf_32 && tsf != 5'd0 && tsf <= 5'd11 ? 4'd4 : 4'd2;
    uop_t        u;
    logic        opsize32, lea, lea_early, consumes, reads_seg, stop;
    logic        d_next_instruction;
    assign d_next_instruction = u.eoi_taken
                             || u.cls == fes_i386_pkg::UOP_SYSTEM && !fes_i386_pkg::sys_nojmp(u.op);
    // The string engine's copies (see below).
    logic [31:0] r_src, r_dst, r_fp, r_cnt, s_tgt;
    logic        s_down;
    logic [2:0]  seg_index;
    logic [31:0] lea_disp;

    // A stack operation addresses SS:ESP, or SS:EBP for LEAVE, at the stack's
    // width (SS.B), and writes ESP from AG: ESP less the size for a push, ESP
    // plus it (and RET's imm16) for a pop, EBP plus it for LEAVE.
    logic [2:0]  stk;
    logic        ss32, stack_wait;
    logic [31:0] st_size, st_disp, st_sp_disp;
    assign stk = dc.stk;
    assign ss32 = seg_ar[SEG_SS][14];
    // The stack's width for this uop: SS.B, but for a protected-mode POP
    // Sreg's step of ESP (nochk) the width its read of the selector had (a
    // STK_PEEK uop, the last before it), as Bochs pops before the load.
    logic sst, pop_ss32;
    assign sst = dc.nochk ? pop_ss32 : ss32;
    always_ff @(posedge clk) if (issue && stk == fes_i386_pkg::STK_PEEK) pop_ss32 <= ss32;
    assign st_size = dc.opsize32 ? 32'd4 : 32'd2;
    // A protected-mode delivery without an error code drops the uops of its
    // slot (errp): the probe and the store, and its jump steps ESP one slot
    // less. An INT n's never has one.
    logic        no_err;
    logic [6:0]  slot_eff;
    logic [31:0] slot_off;
    // A privilege transition (see "Privilege transitions"): xp, WB's hold
    // says the transfer changes privilege, and cg a far CALL's goes through
    // a call gate; a uop for the other case is a NOP (x_drop), as is a call
    // gate's parameter copy past its count (pdrop); a new-stack access
    // (d_nstk, the ROM's); a delivery's or call gate's jump with xp steps
    // ESP two slots further (xs: the old SS and ESP), which slot_x gives
    // apart, off the address's path.
    logic        x_drop, d_nstk, t0_null;
    logic [6:0]  slot_x;
    logic [31:0] slot_xoff;
    // pdrop overrides every xc: the copy's uops are XC_XP ones. An IRETD
    // into V86 mode drops IRET's vgo word too (and seq the word after it).
    logic x_drop_xc;
    always_comb
        case (dc.xc)
            4'(fes_i386_pkg::XC_XP): x_drop_xc = !xp;
            4'(fes_i386_pkg::XC_SAME): x_drop_xc = xp;
            4'(fes_i386_pkg::XC_DIRECT): x_drop_xc = cg;
            4'(fes_i386_pkg::XC_GATE): x_drop_xc = !cg;
            4'(fes_i386_pkg::XC_GSAME): x_drop_xc = !cg || xp;
            // A task switch's (see Task switches): by its kind, by TR's TSS
            // (the old one until TSTR has retired, the new one after, which
            // these uops wait for, t_rd), by the delivery's error code, or
            // by T0's selector.
            4'(fes_i386_pkg::XC_NEST): x_drop_xc = dc.tsk == 2'(fes_i386_pkg::TSK_JMP) || dc.tsk == 2'(fes_i386_pkg::TSK_IRET);
            4'(fes_i386_pkg::XC_UNNEST): x_drop_xc = dc.tsk == 2'(fes_i386_pkg::TSK_CALL) || dc.tsk == 2'(fes_i386_pkg::TSK_INT);
            4'(fes_i386_pkg::XC_IRET): x_drop_xc = dc.tsk != 2'(fes_i386_pkg::TSK_IRET);
            4'(fes_i386_pkg::XC_T32): x_drop_xc = !tr_ar[3];
            4'(fes_i386_pkg::XC_T16): x_drop_xc = tr_ar[3];
            4'(fes_i386_pkg::XC_T32PG): x_drop_xc = !tr_ar[3] || !cr0_pg;
            4'(fes_i386_pkg::XC_ERR): x_drop_xc = no_err;
            4'(fes_i386_pkg::XC_NNULL): x_drop_xc = t0_null;
            default: x_drop_xc = 1'b0;
        endcase
    assign x_drop = x_drop_xc || dc.pdrop || dc.vgo && vret;
    assign d_nstk = dc.uop.nstk;
    assign no_err = !(exc_active && exc_haserr);
    assign slot_eff = dc.slot + 7'(dc.errp && no_err && stk == fes_i386_pkg::STK_RETF);
    assign slot_x = slot_eff - 7'd2;
    assign slot_xoff = dc.opsize32 ? {{23{slot_x[6]}}, slot_x, 2'b00} : {{24{slot_x[6]}}, slot_x, 1'b0};
    // A slot, as a shift of the signed slot (no carry chain).
    assign slot_off = dc.opsize32 ? {{23{slot_eff[6]}}, slot_eff, 2'b00} : {{24{slot_eff[6]}}, slot_eff, 1'b0};
    always_comb begin
        st_disp = 32'd0;
        st_sp_disp = st_size;
        case (stk)
            fes_i386_pkg::STK_PUSH: begin
                st_disp = -st_size;
                st_sp_disp = -st_size;
            end
            fes_i386_pkg::STK_RET_IMM: st_sp_disp = st_size + dc.uop.imm;
            // Its step of ESP goes past the eight slots, down from below ESP.
            fes_i386_pkg::STK_PEEK: begin
                st_disp = slot_off;
                st_sp_disp = dc.slot[6] ? -(st_size << 3) : st_size << 3;
            end
            // A probe reads the lowest slot: INT's three words, or a far
            // call's two pushes below ESP; or, given a slot, that slot (a
            // protected-mode transfer probes each of its slots).
            fes_i386_pkg::STK_PROBE: st_disp = dc.uop.probe == fes_i386_pkg::PROBE_INT ? -32'd6
                                             : dc.slot != 7'd0 ? slot_off : -(st_size << 1);
            // A far transfer's step by its slots, and RETF's imm16.
            fes_i386_pkg::STK_RETF: st_sp_disp = slot_off + dc.uop.imm;
            default: ;
        endcase
        if (!sst) begin
            st_disp = {16'b0, st_disp[15:0]};
            st_sp_disp = {16'b0, st_sp_disp[15:0]};
        end
    end
    // The memory operand: whether it reads and writes, its segment, and the
    // limit check's operands for its size.
    logic        mem, mem_reads, mem_writes, addr_use, a_addr, a_addr32, d_unimpl;
    logic [2:0]  mseg;
    logic [1:0]  msize;  // 1, 2 or 4 bytes as 0, 1, 2
    fes_i386_pkg::mem_kind_e mkind;
    assign mkind = dc.uop.mem.kind;
    assign a_addr = dc.lea || mkind != fes_i386_pkg::MEM_NONE;
    assign a_addr32 = stk != fes_i386_pkg::STK_NONE ? sst : dc.uop.mem.addr32;
    assign mem = mkind != fes_i386_pkg::MEM_NONE;
    assign mem_reads = mkind == fes_i386_pkg::MEM_LOAD || mkind == fes_i386_pkg::MEM_RMW;
    assign mem_writes = mkind == fes_i386_pkg::MEM_STORE || mkind == fes_i386_pkg::MEM_RMW;
    // XCHG m's load of its operand (into T1, before its store): checked
    // against the segment as a write, and translated as one (wx), as Bochs
    // reads it for a read-modify-write, so a segment its store cannot write
    // raises #GP(0) or #SS(0) before the load's #PF (#1644).
    logic xchg_ld;
    assign xchg_ld = mkind == fes_i386_pkg::MEM_LOAD && !dc.gov.two && (dc.gov.op == 8'h86 || dc.gov.op == 8'h87);
    assign addr_use = a_addr;
    assign mseg = 3'(dc.uop.mem.seg);
    assign msize = dc.uop.mem.bytes[2] ? 2'd2 : dc.uop.mem.bytes[1] ? 2'd1 : 2'd0;
    // INT's probe assumes SS's real-mode limit, FFFFh, under which only a
    // slot that straddles the 64 KiB wrap faults.
    logic str_ss, str_expd;  // the string engine's second address is SS's (ENTER), else ES's; expand-down
    logic [2:0] str_dseg;
    assign str_ss = dc.seq == fes_i386_pkg::SEQ_ENTER;
    assign str_dseg = str_ss ? 3'(SEG_SS) : 3'(fes_i386_pkg::SEG_ES);
    assign str_expd = seg_expd[str_dseg];
    // A count-zero REP's first element is rewritten to a NOP below. Its
    // unused addresses must not raise an unsupported-segment or wrap fault.
    // INT's probe is built for a 16-bit stack under SS's real-mode limit
    // (seg_ss_rm), or one whose limit passes 10000h (seg_ss_big), where no
    // slot can fault.
    assign d_unimpl = !s_kill1 && dc.uop.probe != fes_i386_pkg::PROBE_NONE && !seg_ss_rm && !seg_ss_big;

    // A far transfer's selector and offset, from the instruction or from T0
    // and T1. An offset past CS's limit, the limit before the transfer as
    // Bochs checks a real-mode one, raises #GP(0) at the uop that checks it
    // (far_chk), before anything is written: at a far CALL's probe, ahead of
    // the probe's own check, as Bochs checks before it pushes; at any other
    // uop (RETF's jump, IRET's FLAGS read) after the uop's own checks, at M1
    // (cs_late), as Bochs pops first. CALL r/m's push checks T1, a near
    // call's target, the same way, but only to leave ESP as it was (cpast):
    // it pushes, and its jump raises the #GP(0). A protected-mode transfer
    // checks its offset against the held descriptor's limit (CHK_HOFF).
    logic [15:0] far_sel;
    logic [31:0] far_off;
    logic        far_bad, t_busy, t_wait;
    assign far_sel = dc.far_t ? t0 : dc.far_sel;
    // The jump into V86 mode (v86 without xfer) takes T1's low word, as
    // Bochs's EIP = new_eip & 0xffff.
    assign far_off = dc.far_t ? {dc.uop.v86 && !dc.uop.xfer ? 16'd0 : t1[31:16], t1[15:0]} : dc.uop.imm;
    assign far_bad = dc.far_chk && far_off > seg_limit[SEG_CS];
    // CALL r/m's push checks T1 only to keep ESP (cpast): no fault, no stop.
    logic chk_calli;
    assign chk_calli = dc.seq == fes_i386_pkg::SEQ_CALLI;
    assign t_wait = dc.t_rd && t_busy;
    // A protected-mode segment load reads nothing for a null selector, and
    // writes the accessed bit only when the descriptor's is clear (T3's bit
    // 8); LAR's kin read nothing for a selector past its table (t0_oor),
    // LLDT and LTR nothing for a TI=1 one. A CR0 write (T1) with PG set and
    // PE clear raises #GP(0).
    logic t0_oor, cr0_gp, desc_t0, desc_drop, arpl_adj;
    assign t0_null = t0[15:2] == 14'd0;
    assign t0_oor = t0[2] ? !ldtr_valid || ldt_tiny7 || {16'd0, t0[15:3], 3'd0} > ldt_lim7
                          : gdt_tiny7 || {t0[15:3], 3'd0} > gdt_lim7;
    assign desc_t0 = dc.uop.desc == 4'(fes_i386_pkg::DESC_LO) || dc.uop.desc == 4'(fes_i386_pkg::DESC_HI)
                  || dc.uop.desc == 4'(fes_i386_pkg::DESC_ACC) || dc.uop.desc == 4'(fes_i386_pkg::DESC_BUSY);
    assign desc_drop = desc_t0 && (t0_null || dc.uop.desc == 4'(fes_i386_pkg::DESC_ACC) && t3[8]
                                   || dc.dmode == 2'(fes_i386_pkg::DM_PROBE) && t0_oor
                                   || dc.dmode == 2'(fes_i386_pkg::DM_GDT) && t0[2])
                    || dc.uop.desc == 4'(fes_i386_pkg::DESC_HACC) && hs_acc[0];
    // ARPL writes its destination, and sets ZF, only when it raises the RPL.
    assign arpl_adj = t1[1:0] < t2[1:0];
    assign cr0_gp = dc.uop.cls == fes_i386_pkg::UOP_SYSTEM && dc.uop.op == 5'(fes_i386_pkg::SYSOP_CR0) && t1[31]
                 && !t1[0];
    // An instruction fetched with a paging mark (fes_i386_l1i): a block
    // whose page the ITLB did not hold (tm), or a supervisor page at CPL 3
    // (ts), in its first byte's block or the one it runs into. Its first uop
    // becomes the walk of that page (d_ifw, pipe_t ifw), which ends in a
    // replay or #PF, whatever its bytes decoded to: they are a hole's. CR2
    // for the second is that block's first byte, the next page's.
    logic        d_need0, d_need1, d_ifw;
    logic [31:0] d_ifw_lin;
    assign d_need0 = dc.tm0 || cpl == 2'd3 && dc.ts0;
    assign d_need1 = dc.tm1 || cpl == 2'd3 && dc.ts1;
    // A fetch past CS's limit is #GP(0) before any page is translated, as
    // Bochs checks the limit first (an IRETD in V86 mode can leave EIP past
    // FFFFh on a page the ITLB does not hold): the walk uop then carries
    // that #GP(0), and M1 starts no walk for a uop with a fault. d_ifw stays
    // a function of registers, off cs_gp's compare, since it selects the
    // whole uop.
    assign d_ifw = dc.fetched && !dc.xbad && (d_need0 || d_need1);
    assign d_ifw_lin = d_need0 ? dc.lin : {dc.lin[31:4] + 28'd1, 4'd0};
    always_comb begin
        u = dc.uop;
        if (stk != fes_i386_pkg::STK_NONE) u.mem.addr32 = sst;
        if (desc_drop || dc.errp && no_err && stk != fes_i386_pkg::STK_RETF) u.mem.kind = fes_i386_pkg::MEM_NONE;
        // LAR, LSL, VERR, VERW and ARPL (SEGOP_ZF): which, in imm[3:1], for
        // M1's result; ARPL's own in imm[0].
        if (dc.b_sys && dc.sys_idx == 5'(fes_i386_pkg::SYS_RD_ARPL)) begin
            u.imm[0] = arpl_adj;
            if (!arpl_adj) begin
                u.dst.valid = 1'b0;
                u.mem.kind = fes_i386_pkg::MEM_NONE;
            end
        end
        if (dc.b_sys && dc.sys_idx >= 5'(fes_i386_pkg::SYS_RD_LAR))
            u.imm[3:1] = 3'(dc.sys_idx - 5'(fes_i386_pkg::SYS_RD_LAR) + 4'd1);
        // A protected-mode delivery's EFLAGS image: its RF, and whether the
        // gate is a trap gate, which keeps IF.
        if (dc.uop.cls == fes_i386_pkg::UOP_ALU && dc.uop.op == 5'(fes_i386_pkg::ALU_FLAGS)
            && dc.uop.imm[3:0] == 4'(fes_i386_pkg::FLAG_READ_PM))
            u.imm[5:4] = {gate_trap, exc_active && del_rf};
        // A task switch's (see Task switches): the old task's EFLAGS image,
        // its RF as a delivery's frame takes it, NT clear for IRET's; the
        // new task's flags, NT set for a nesting switch; the commit of a
        // return from a nested task unblocks NMI, as IRET does.
        if (dc.uop.cls == fes_i386_pkg::UOP_ALU && dc.uop.op == 5'(fes_i386_pkg::ALU_FLAGS)
            && dc.uop.imm[3:0] == 4'(fes_i386_pkg::FLAG_READ_TSS))
            u.imm[6:4] = {dc.tsk == 2'(fes_i386_pkg::TSK_IRET), 1'b0, exc_active && del_rf};
        if (dc.uop.cls == fes_i386_pkg::UOP_ALU && dc.uop.op == 5'(fes_i386_pkg::ALU_FLAGS)
            && dc.uop.imm[3:0] == 4'(fes_i386_pkg::FLAG_LOAD_TSS))
            u.imm[6] = dc.tsk == 2'(fes_i386_pkg::TSK_CALL) || dc.tsk == 2'(fes_i386_pkg::TSK_INT);
        if (dc.uop.tcom) u.iret = dc.tsk == 2'(fes_i386_pkg::TSK_IRET);
        // POPAD's ESP image counts only on a 16-bit stack.
        if (dc.popad_esp && !(dc.opsize32 && !ss32)) u.dst.valid = 1'b0;
        // A privilege transition: a new-stack access's offset is whole (D
        // wraps it), and so is a TSS read's; the TSS's ESP is a 286 TSS's
        // word, zero-extended. The far jump with xp steps no ESP: WB loads
        // it from T5 plus imm, a delivery's pushes (its slot).
        if (d_nstk) begin
            u.mem.addr32 = 1'b1;
            u.nstk = 1'b1;
        end
        if (dc.tss == 3'(fes_i386_pkg::TSS_ESP)) u.mem.bytes = tr_ar[3] ? 4'd4 : 4'd2;
        if (tsf_any) u.mem.bytes = tsf_bytes;
        // The I/O permission bitmap needs a 386 TSS (available or busy) of
        // at least 104 bytes: else #GP(0), before its base is read.
        if (dc.tss == 3'(fes_i386_pkg::TSS_IOMAP) && !tss_iomap
            && u.ctl.fault == fes_i386_pkg::FAULT_NONE)
            u.ctl.fault = fes_i386_pkg::FAULT_GP0;
        // With xp, ESP from T5 plus imm: a delivery's or call gate's pushes
        // (xs, its slot), or RETF imm16's.
        if (dc.uop.xfer && xp) begin
            u.sp_add = 1'b0;
            u.imm = dc.xs ? slot_xoff : dc.uop.imm;
        end
        // A call gate's store of the old ESP or the return EIP (zx): SP from
        // a 16-bit stack, IP from 16-bit code, zero-extended.
        if (dc.zx && !(dc.push_eip ? code32 : ss32)) begin
            u.op = 5'(fes_i386_pkg::ALU_MOVZX);
            u.src_size = fes_i386_pkg::SIZE_16;
        end
        // The case the transfer is not: a NOP, which writes nothing at WB,
        // a jump's segments, ESP and hold included.
        if (x_drop) begin
            u.cls = fes_i386_pkg::UOP_SPECIAL;  // SPECIAL_NOP
            u.op = 5'd0;
            u.mem.kind = fes_i386_pkg::MEM_NONE;
            u.mem.system = 1'b0;
            u.dst.valid = 1'b0;
            u.flags = '0;
            u.segchk = 5'd0;
            u.desc = 4'd0;
            u.nstk = 1'b0;
            u.hold = 1'b0;
            u.xfer = 1'b0;
            u.seg2 = 1'b0;
            u.seg2_pm = 1'b0;
            u.sp_add = 1'b0;
            u.sp_write = 1'b0;
        end
        if (!s_kill1 && d_unimpl && dc.uop.ctl.fault == fes_i386_pkg::FAULT_NONE) begin
            u.ctl.fault = fes_i386_pkg::FAULT_UNIMPLEMENTED;
            u.ctl.why = fes_i386_pkg::WHY_STACK64K;
        end
        if (far_bad && stk == fes_i386_pkg::STK_PROBE && dc.uop.ctl.fault == fes_i386_pkg::FAULT_NONE)
            u.ctl.fault = fes_i386_pkg::FAULT_GP0;
        if (!s_kill1 && cs_gp) begin
            u.ctl.fault = fes_i386_pkg::FAULT_GP0;
            u.ice = 1'b0;
        end
        if (cr0_gp && u.ctl.fault == fes_i386_pkg::FAULT_NONE) u.ctl.fault = fes_i386_pkg::FAULT_GP0;
        u.str_down = s_down;
        // A fetch walk is a NOP that ends the instruction, with nothing else.
        if (d_ifw) begin
            u = '0;
            u.cls = fes_i386_pkg::UOP_SPECIAL;  // SPECIAL_NOP
            u.ctl.end_of_instruction = 1'b1;
            u.ctl.fault = cs_gp ? fes_i386_pkg::FAULT_GP0 : fes_i386_pkg::FAULT_NONE;
        end
    end
    assign opsize32 = dc.opsize32;
    assign lea = dc.lea;
    assign lea_early = dc.lea_early;
    // Whether the uop in D gives its result at the end of AG: a 32-bit LEA,
    // or an early-ALU uop whose operands AG will have (lea_stall clear). An
    // early-ALU uop that would wait for them never does: it runs at EX, as
    // it would without the early ALU.
    logic d_early;
    // A far pointer's selector is past its offset by the operand size,
    // wrapped by address size.
    // The interrupt vector's entry is at vector * 4 (far_sel), its selector
    // at + 2.
    // POP m's store through ESP reads ESP after the pop, which has not
    // moved it: the store waits for T1, so every older uop has retired and
    // ESP is the register file's. The displacement gains the operand size,
    // scaled as ESP is (esp_adj), less 10000h so scaled (esp_wrap) when a
    // 16-bit stack's SP wraps, which it does only from the top slot, since
    // a slot past FFFFh faults first.
    logic        sp_wraps;
    logic [31:0] disp_add;
    assign sp_wraps = !ss32 && (dc.opsize32 ? &gpr[4][15:2] : &gpr[4][15:1]);
    // A descriptor's part is at its selector's index times 8 in the table:
    // its low dword, its high dword (+4, LTR's busy store too) or its access
    // byte (+5); a delivery's gate at the vector times 8 in the IDT. LGDT's
    // and SGDT's base, a part of an x87 operand and an x87 environment's
    // field are moff bytes past the ModRM operand.
    logic [31:0] desc_disp;
    always_comb
        case (dc.uop.desc)  // not cast to desc_e: DeanoC/yosys#72
            4'(fes_i386_pkg::DESC_HI), 4'(fes_i386_pkg::DESC_BUSY): desc_disp = {16'b0, t0[15:3], 3'd4};
            4'(fes_i386_pkg::DESC_ACC): desc_disp = {16'b0, t0[15:3], 3'd5};
            4'(fes_i386_pkg::DESC_IDT_LO): desc_disp = {21'b0, dc.far_sel[9:2], 3'd0};
            4'(fes_i386_pkg::DESC_IDT_HI): desc_disp = {21'b0, dc.far_sel[9:2], 3'd4};
            // TR's descriptor's high dword (a task switch's old TSS).
            4'(fes_i386_pkg::DESC_TRHI), 4'(fes_i386_pkg::DESC_UNBUSY): desc_disp = {16'b0, tr_sel[15:3], 3'd4};
            default: desc_disp = {16'b0, t0[15:3], 3'd0};
        endcase
    assign disp_add = dc.moff != 7'd0 ? {25'd0, dc.moff} : dc.sel_part ? st_size
                    : {sp_wraps ? -{12'd0, dc.esp_wrap} : 16'd0, 10'd0, dc.esp_adj};
    // The new stack in the TSS for the held CS's DPL: a 386 TSS's ESP and SS
    // at 8 * DPL + 4 and + 8, a 286 TSS's SP and SS at 4 * DPL + 2 and + 4.
    logic [31:0] tss_disp;
    // An I/O access's permission bitmap: its base at 66h, then the word for
    // the port (T5) at that base (T4) plus the port's byte.
    logic        tss_ss;
    assign tss_ss = dc.tss == 3'(fes_i386_pkg::TSS_SS);
    assign tss_disp = tsf_any ? {25'd0, tsf_off} : dc.tss == 3'(fes_i386_pkg::TSS_IOMAP) ? 32'h0000_0066
                    : dc.tss == 3'(fes_i386_pkg::TSS_BITMAP) ? t4 + {19'd0, t5[15:3]}
                    : tr_ar[3] ? {27'd0, hs_ar[6:5], 3'b000} + {28'd0, tss_ss, !tss_ss, 2'b00}
                    : {28'd0, hs_ar[6:5], 2'b00} + {29'd0, tss_ss, !tss_ss, 1'b0};
    assign lea_disp = dc.uop.desc != 4'd0 ? desc_disp
                    : dc.uop.mem.system ? {16'b0, dc.far_sel[15:2], dc.sel_part, 1'b0}
                    : !dc.sel_part && dc.moff == 7'd0 && dc.esp_adj == 6'd0 ? dc.lea_disp
                    : dc.uop.mem.addr32 ? dc.lea_disp + disp_add : {16'b0, dc.lea_disp[15:0] + disp_add[15:0]};
    assign consumes = dc.consumes;
    assign reads_seg = dc.reads_seg;
    assign seg_index = dc.seg_index;
    // A far transfer's offset past CS's limit faults at this uop, so D
    // issues nothing after it; CALL r/m's push past it (cpast) does not, and
    // its jump issues.
    assign stop = dc.xbad || d_ifw || !s_kill1 && (dc.stop || d_unimpl || cs_gp || far_bad && !chk_calli || cr0_gp);

    // The producers in AG, M1, M2 and EX.
    logic [3:0]       prod_valid, prod_early, prod_sp;
    logic [3:0][2:0]  prod_dst;
    logic [3:0][1:0]  prod_kind;
    logic [3:0][31:0] stage_value;
    pipe_t            prod_ag, prod_m1, prod_m2, prod_ex;  // whole records: DeanoC/yosys#52
    assign prod_ag = ag_s;
    assign prod_m1 = m1_s;
    assign prod_m2 = m2_s;
    assign prod_ex = ex_s;
    always_comb begin
        prod_valid = {prod_ex.valid && prod_ex.uop.dst.valid && prod_ex.uop.dst.space == fes_i386_pkg::RS_GPR,
                      prod_m2.valid && prod_m2.uop.dst.valid && prod_m2.uop.dst.space == fes_i386_pkg::RS_GPR,
                      prod_m1.valid && prod_m1.uop.dst.valid && prod_m1.uop.dst.space == fes_i386_pkg::RS_GPR,
                      prod_ag.valid && prod_ag.uop.dst.valid && prod_ag.uop.dst.space == fes_i386_pkg::RS_GPR};
        prod_dst = {prod_ex.uop.dst.index[2:0], prod_m2.uop.dst.index[2:0], prod_m1.uop.dst.index[2:0],
                    prod_ag.uop.dst.index[2:0]};
        prod_early = {prod_ex.early, prod_m2.early, prod_m1.early, prod_ag.early};
        prod_kind = {prod_ex.early ? EARLY : prod_ex.ldfwd ? LOAD : LATE, prod_m2.early ? EARLY : prod_m2.ldfwd ? LOAD : LATE,
                     prod_m1.early ? EARLY : prod_m1.ldfwd ? LOAD : LATE, prod_ag.early ? EARLY : prod_ag.ldfwd ? LOAD : LATE};
        stage_value = {wb_s.result, ex_s.result, m2_s.result, m1_s.result};
    end
    // ESP from a stack operation, unless its destination is ESP too (POP ESP).
    function automatic logic writes_sp(input pipe_t s);
        writes_sp = s.valid && s.uop.sp_write
                 && !(s.uop.dst.valid && s.uop.dst.space == fes_i386_pkg::RS_GPR && s.uop.dst.index[2:0] == 3'd4);
    endfunction
    assign prod_sp = {writes_sp(prod_ex), writes_sp(prod_m2), writes_sp(prod_m1), writes_sp(prod_ag)};

    logic d_writes;
    assign d_writes = cur_valid && u.dst.valid && u.dst.space == fes_i386_pkg::RS_GPR && !s_kill1;

    // Data operands.
    logic [31:0] a_val, b_val, c_val;
    logic        a_pend, b_pend, c_pend;
    logic [7:0]  d_pend;
    logic [7:0][31:0] d_value;
    logic [2:0]  a_dist, b_dist, c_dist;
    fes_i386_dops dops (
        .clk, .reset(reset || wb_flush), .a_reg(u.src1.index[2:0]), .b_reg(u.src2.index[2:0]), .d_writes,
        .d_dst(u.dst.index[2:0]), .d_early, .advance(issue), .hold(freeze), .prod_valid, .prod_dst,
        .prod_early, .prod_sp, .gpr, .stage_value, .wb_sp(wb_s.sp_new), .a(a_val), .b(b_val), .c(c_val), .pend_a(a_pend), .pend_b(b_pend),
        .pend_c(c_pend), .dist_a(a_dist), .dist_b(b_dist), .dist_c(c_dist), .pend_all(d_pend), .value_all(d_value)
    );

    // A memory operand's or LEA's address; a stack operation's is ESP or EBP.
    logic        lea_stall, sp_wait, d_sp;
    logic [1:0]  late, late_hi;
    logic [31:0] row, last;
    logic [15:0] sp_hi, base_hi;
    assign d_sp = cur_valid && u.sp_write;
    fes_i386_dfwd dfwd (
        .clk, .reset(reset || wb_flush), .has_base((a_addr || dc.ealu) && dc.has_base), .base(dc.base),
        .has_index((a_addr || dc.ealu) && dc.has_index), .index(dc.index), .index8(dc.index8), .scale(dc.scale),
        .addr32(dc.ealu ? opsize32 : a_addr32), .d_writes, .d_dst(u.dst.index[2:0]), .d_kind(d_early ? EARLY : LATE), .d_sp,
        .advance(issue), .hold(freeze), .prod_valid, .prod_dst, .prod_kind, .prod_sp, .gpr, .stage_value,
        .wb_sp(wb_s.sp_new), .ex_ld(ex_s.ld), .row, .last, .late, .late_hi, .stall(lea_stall), .sp_hi, .base_hi, .sp_wait
    );
    assign d_early = lea && lea_early || dc.ealu && !lea_stall;

    // ---- The string engine ----------------------------------------------------
    // While a string instruction or ENTER runs, D keeps copies of the next
    // source and destination offsets (r_src, r_dst), of the count (r_cnt)
    // and of ENTER's frame pointer (r_fp), so each step's address is a
    // register here and its uops issue without forwarding (fes_i386_seq).
    // A string's first uop loads them from ESI, EDI and ECX (CX by address
    // size), which it waits for, with DF: the elements then step by the
    // access's bytes, down when DF is set. It also keeps the next
    // instruction's linear address (s_tgt), where a REPE or REPNE element
    // that ends the instruction branches. ENTER's first uop, the push of
    // EBP, loads them from ESP and EBP. An offset wraps at its address's
    // width (a_addr32: the instruction's for a string, the stack's for
    // ENTER), keeping the copy's high half.
    logic [31:0] str_step, str_fin_off, str_off, str_daddr, str_dlim, c_count;
    logic        str_dbad;
    function automatic logic [31:0] keep_hi(input logic [31:0] old, input logic [31:0] v, input logic w32);
        keep_hi = w32 ? v : {old[31:16], v[15:0]};
    endfunction
    assign str_step = s_down ? -{28'd0, dc.uop.mem.bytes} : {28'd0, dc.uop.mem.bytes};
    // ENTER's last uop: ESP from the next push slot plus imm (the size less
    // imm16), which is also the slot its check reads.
    assign str_fin_off = keep_hi(r_dst, r_dst + dc.uop.imm, a_addr32);
    always_comb begin
        str_off = dc.str_a ? r_src : dc.str_fin ? str_fin_off : r_dst;
        if (!a_addr32) str_off = {16'b0, str_off[15:0]};
    end
    // A second address (st2): the destination copy's, in ES (SS for ENTER),
    // with its limit checked here; M1 raises that after the first's.
    logic [31:0] str_doff;
    assign str_doff = a_addr32 ? r_dst : {16'b0, r_dst[15:0]};
    assign str_daddr = seg_base[str_dseg] + str_doff;
    assign str_dlim = seg_lim[str_dseg][msize];
    assign str_dbad = str_doff > str_dlim || seg_tiny[str_dseg][msize] || seg_wbad[str_dseg]
                   || str_expd && str_doff <= seg_low[str_dseg];
    // The count, for fes_i386_seq, from registers: whether the copy is 0, 1
    // or 2 (r_c0, r_c1, r_c2, kept with it), or at ENTER's first uop its
    // level. A string's first element is built without it: when the string's
    // first uop issues, the count is ECX (CX by address size) through D's
    // forwarding, on its way into the copy. So that uop latches whether the
    // first element ends the instruction (s_end1: the count is 0, or 1 but
    // for CMPS, whose first load is not an element's end) and whether it does
    // nothing (s_kill1: 0). D then issues that element as the instruction's
    // last, or as a NOP that ends it, in the cycle it would anyway.
    logic r_c0, r_c1, r_c2;
    assign c_count = dc.uop.mem.addr32 ? d_value[1] : {16'b0, d_value[1][15:0]};
    assign str_cnt3 = dc.str_load && str_ss ? {dc.ecnt == 5'd2, dc.ecnt == 5'd1, dc.ecnt == 5'd0} : {r_c2, r_c1, r_c0};
    always_ff @(posedge clk) begin
        // The copies come from their registers' values, which are fixed:
        // ESP and EBP, or ESI and EDI, with no select by register number.
        if (issue && dc.str_load && str_ss) begin
            r_src <= keep_hi(d_value[5], d_value[5] - st_size, ss32);
            r_dst <= keep_hi(d_value[4], d_value[4] - (st_size << 1), ss32);
            r_fp <= keep_hi(d_value[4], d_value[4] - st_size, ss32);
            r_cnt <= {27'd0, dc.ecnt} - 32'd1;
            {r_c2, r_c1, r_c0} <= {dc.ecnt == 5'd3, dc.ecnt == 5'd2, dc.ecnt == 5'd1};
            s_down <= 1'b1;
        end else if (issue && dc.str_load) begin
            r_src <= dc.uop.mem.addr32 ? d_value[6] : {16'b0, d_value[6][15:0]};
            r_dst <= dc.uop.mem.addr32 ? d_value[7] : {16'b0, d_value[7][15:0]};
            r_cnt <= c_count;
            {r_c2, r_c1, r_c0} <= {c_count == 32'd2, c_count == 32'd1, c_count == 32'd0};
            s_down <= ex_flags[10];
            s_tgt <= seg_base[SEG_CS] + d_eip_next;
        end else if (issue) begin
            if (dc.str_a) r_src <= keep_hi(r_src, r_src + str_step, a_addr32);
            if (dc.str_b || dc.str_two) r_dst <= keep_hi(r_dst, r_dst + str_step, a_addr32);
            if (dc.str_cnt) begin
                r_cnt <= r_cnt - 32'd1;
                {r_c2, r_c1, r_c0} <= {r_cnt == 32'd3, r_cnt == 32'd2, r_cnt == 32'd1};
            end
        end
    end
    logic s_rep;  // the string in dc repeats
    assign s_rep = dc.str_rep != 2'd0;
    always_ff @(posedge clk) begin
        if (reset || redirect) begin
            s_end1 <= 1'b0;
            s_kill1 <= 1'b0;
        end else if (issue) begin
            s_kill1 <= dc.str_load && !str_ss && s_rep && c_count == 32'd0;
            s_end1 <= dc.str_load && !str_ss && s_rep
                   && (c_count == 32'd0 || c_count == 32'd1 && dc.str_op != 3'(fes_i386_pkg::STR_CMPS));
        end
    end

    // A string's first uop waits until ESI, EDI and ECX are in registers,
    // no older uop that writes DF is in AG to EX (EX's running flags then
    // hold the DF the string runs with), and neither its segment nor ES is
    // being written. Its elements then wait on nothing D checks, which
    // keeps a CMPS element's compare a cycle behind its first load.
    // ENTER's waits until ESP and EBP are. The registers are fixed, so each
    // wait reads dops' bit for its register, with no select.
    logic df_busy, str_wait;
    assign str_wait = dc.str_load && (str_ss ? d_pend[4] || d_pend[5]
                                             : dc.uop.src1.valid && d_pend[6] || dc.uop.src2.valid && d_pend[7]
                                               || dc.uop.count_cl && d_pend[1] || df_busy || d_seg_busy[mseg]
                                               || d_seg_busy[fes_i386_pkg::SEG_ES]);
    // A uop that reads ESI, EDI or ECX (dc.rd_str, decoded) waits while a
    // string element that steps it is in AG to WB: WB makes the step, which
    // no forwarding sees.
    logic [2:0] str_busy;  // ESI, EDI, ECX
    function automatic logic [2:0] str_steps(input pipe_t s);
        str_steps = s.valid ? {s.uop.str_cx, s.uop.str_di, s.uop.str_si} : 3'd0;
    endfunction
    function automatic logic writes_df(input uop_t v);
        writes_df = v.cls == fes_i386_pkg::UOP_ALU && v.op == 5'd30
                 && (v.imm[3:0] == 4'd5 || v.imm[3:0] == 4'd6 || v.imm[3:0] == 4'd9);  // CLD, STD, LOAD
    endfunction
    logic str_hazard;
    assign str_hazard = |(dc.rd_str & str_busy);

    // A protected-mode IRET's routine is picked in DC by NT as it stands
    // (fes_i386_decode: UC_TSSAVE with NT set, else the stack return). An
    // older POPF, IRET, delivery or task switch may still be writing NT, so
    // the IRET's first uop (ntchk) waits in D while any uop that may write
    // EFLAGS from a load, a delivery's clear or a TSS (nt_busy) is in AG to
    // WB; it then issues with NT committed, and replays, touching nothing,
    // when that is not what DC saw (ntset). The task return reads no stack
    // and the stack return reads no TSS, so no access of the wrong path, nor
    // its page walk, is ever made.
    logic nt_busy;
    function automatic logic writes_nt(input uop_t v);
        writes_nt = v.cls == fes_i386_pkg::UOP_ALU && v.op == 5'd30
                 && (v.imm[3:0] == 4'd9 || v.imm[3:0] == 4'd11 || v.imm[3:0] == 4'd12 || v.imm[3:0] == 4'd13
                     || v.imm[3:0] == 4'd15);  // LOAD, READ_INT, LOAD_RF, READ_PM, LOAD_TSS
    endfunction

    // An I/O instruction's access is at WB, and IN's data reaches only WB, so
    // nothing younger issues until it has retired (io_busy, as t_busy): no
    // load reads memory an OUT may remap, and nothing reads IN's data before
    // it is in the register file. A REP INS or OUTS's own elements stream;
    // the next instruction's first uop, never an element, waits.
    logic io_busy, io_hazard;
    function automatic logic does_io(input pipe_t s);
        does_io = s.valid && s.uop.io != 2'd0;
    endfunction
    assign io_hazard = io_busy && !(dc.str_a || dc.str_b);

    // What AG's uop is, for the holds below, registered as it enters AG: a
    // store, a shift or rotate, a stack operation that writes ESP.
    logic ag_store, ag_shift, ag_wsp;

    // ESP as data waits while a stack operation that writes it is in AG: its
    // value reaches the M1 register next cycle. LEAVE on a 16-bit stack waits
    // for ESP's high half, which it keeps.
    logic sp_hazard;
    assign sp_hazard = ag_wsp && (u.src1.valid && u.src1.index[2:0] == 3'd4
                                  || u.src2.valid && u.src2.index[2:0] == 3'd4);
    assign stack_wait = stk == fes_i386_pkg::STK_LEAVE && !ss32 && sp_wait;

    // A selector read waits for an older write of that segment register, and
    // a memory operand for its segment's base, which a real-mode load sets
    // at WB. d_seg_busy names the segments an older uop in AG to WB writes,
    // registered from what will be there next cycle, so each wait is one
    // select.
    function automatic logic writes_seg(input pipe_t s, input int seg);
        writes_seg = s.valid && (s.uop.dst.valid && s.uop.dst.space == fes_i386_pkg::RS_SEG
                                 && s.uop.dst.index[2:0] == 3'(seg) || s.uop.seg2 && s.uop.seg2_idx == 3'(seg));
    endfunction
    logic [5:0] d_seg_busy;
    // A privilege transition's hold counts as a temporary's write, and so do
    // a task switch's TR and LDTR writes, which its TSS field accesses and
    // descriptor reads use in D (see Task switches).
    function automatic logic writes_temp_u(input uop_t v);
        writes_temp_u = v.dst.valid && v.dst.space == fes_i386_pkg::RS_TEMP || v.hold
                     || v.cls == fes_i386_pkg::UOP_SYSTEM && (v.op == 5'(fes_i386_pkg::SYSOP_TSTR)
                                                             || v.op == 5'(fes_i386_pkg::SYSOP_TSLDTD));
    endfunction
    function automatic logic writes_temp(input pipe_t s);
        writes_temp = s.valid && writes_temp_u(s.uop);
    endfunction
    // An ESC instruction's last uop writes the x87 pointers at WB too.
    function automatic logic writes_x87p(input pipe_t s);
        writes_x87p = s.valid && s.uop.x87p != 2'd0;
    endfunction
    logic       seg_hazard, mseg_hazard;
    assign seg_hazard = d_seg_busy[seg_index];
    assign mseg_hazard = d_seg_busy[mseg];

    // A load waits one cycle behind a store that may write a byte it reads:
    // EX computes the store's data in the cycle the load would be in M2, and
    // one cycle later the store is in WB, where M2 takes its bytes from the
    // WB register. A load whose bytes the store cannot write follows it
    // directly (st_near, below the D/AG register).
    logic store_hazard, st_near;
    assign store_hazard = ag_store && mem_reads && st_near;

    // A flag reader waits one cycle behind a shift or rotate, whose flags
    // reach EX's running copy a cycle after the shift leaves EX (fes_i386_ex).
    logic flag_hazard;
    assign flag_hazard = ag_shift && consumes;

    // A flush needs no term here: it clears AG and the forwarding tables, a
    // taken branch's redirect resets DC and D's EIP on the same edge, and a
    // fault or HLT stops the CPU. Once it has (halted), D issues nothing; in
    // the cycle the fault or HLT is in WB, its flush clears what D issues.
    // After a replay, D issues the instruction one uop at a time (serial),
    // each once nothing is left in AG to WB (ser_wait), so its uncached load
    // reaches M2 as the oldest uop. A CMPS element's second load issues right
    // behind its first, whose result it takes one stage ahead (x_prev); it
    // then counts as the oldest behind it (oldest).
    logic serial, ser_wait;
    // The governor holds D only at an instruction's first uop or a REP
    // element's (d_first: after a redirect, or once D has issued the last
    // uop of either), so no sequence's uops are split, and the hold is a
    // cycle late (gov_block, one register).
    logic d_first, d_first_next, gov_hold, gov_block;
    assign issue = cur_valid && !(addr_use && lea_stall) && !(reads_seg && seg_hazard) && !(mem && mseg_hazard)
                && !store_hazard && !flag_hazard && !sp_hazard && !stack_wait && !t_wait && !uc_wait && !str_wait
                && !str_hazard && !io_hazard && !(ser_wait && !dc.x_prev) && !(dc.uop.ntchk && nt_busy) && !freeze
                && !halted && !gov_block && !x87_hold;
    assign d_first_next = reset || redirect || (issue ? !dc_more || u.str_cx : d_first);
    always_ff @(posedge clk) begin
        d_first <= d_first_next;
        gov_block <= gov_hold && d_first_next;
    end
    assign trace_gov_hold = gov_hold;
    assign trace_issue = issue;
    assign trace_fe_wait = !dc_valid;
    assign trace_md_wait = md_busy;

    always_ff @(posedge clk) begin
        if (reset || wb_flush) begin
            d_seg_busy <= 6'd0;
            t_busy <= 1'b0;
            str_busy <= 3'd0;
            df_busy <= 1'b0;
            io_busy <= 1'b0;
            ser_wait <= 1'b0;
            nt_busy <= 1'b0;
        end else if (!freeze) begin
            nt_busy <= issue && !s_kill1 && writes_nt(u) || ag_s.valid && writes_nt(ag_s.uop)
                    || m1_s.valid && writes_nt(m1_s.uop) || m2_s.valid && writes_nt(m2_s.uop)
                    || ex_s.valid && writes_nt(ex_s.uop) || wb_s.valid && writes_nt(wb_s.uop);
            io_busy <= issue && u.io != 2'd0 && !s_kill1 || does_io(ag_s) || does_io(m1_s) || does_io(m2_s)
                    || does_io(ex_s);
            // A delivery under paging issues one uop at a time too, so each
            // uop the DTLB cannot serve is the oldest and walks: a delivery
            // cannot replay.
            // So does a task switch, whose replay would restart its
            // instruction with part of the switch written.
            ser_wait <= (serial || pg && (exc_active || dc.tsw)) && (issue || ag_s.valid || m1_s.valid || m2_s.valid || ex_s.valid);
            str_busy <= (issue && !s_kill1 ? {u.str_cx, u.str_di, u.str_si} : 3'd0) | str_steps(ag_s) | str_steps(m1_s) | str_steps(m2_s) | str_steps(ex_s);
            df_busy <= issue && writes_df(u) || ag_s.valid && writes_df(ag_s.uop) || m1_s.valid && writes_df(m1_s.uop)
                    || m2_s.valid && writes_df(m2_s.uop);
            // T0 and T1 are written at WB, so a uop that reads them in D waits
            // for every older one that writes either to retire; so are the
            // x87 pointers, which FNSTENV and FNSAVE read.
            t_busy <= issue && (writes_temp_u(u) || u.x87p != 2'd0) || writes_temp(ag_s) || writes_temp(m1_s)
                   || writes_temp(m2_s) || writes_temp(ex_s) || writes_x87p(ag_s) || writes_x87p(m1_s)
                   || writes_x87p(m2_s) || writes_x87p(ex_s);
            for (int k = 0; k < 6; k++)
                d_seg_busy[k] <= issue && dc.wseg[k]
                                || writes_seg(ag_s, k) || writes_seg(m1_s, k) || writes_seg(m2_s, k) || writes_seg(ex_s, k);
        end
        if (reset) begin
            d_stop <= 1'b0;
        end else if (redirect) begin
            d_stop <= 1'b0;
            d_eip <= redirect_eip;
        end else if (rp_go) begin
            d_stop <= 1'b1;  // until the restart's redirect
        end else if (issue) begin
            d_stop <= stop;
            if (!dc_more) d_eip <= d_pt ? d_tgt : d_ipt ? d_ieip : d_eip_next;
        end
    end

    // ---- D/AG register --------------------------------------------------------------
    logic        ag_addr32;
    logic [31:0] ag_row, ag_last, ag_disp, ag_seg_term;
    logic [15:0] ag_seg_hi, ag_seg_hi_plus1;
    logic [1:0]  ag_late, ag_late_hi;
    logic        ag_stack, ag_ss32, ag_leave, ag_call, ag_o32, ag_e16;
    logic [31:0] ag_sp_disp;
    logic [15:0] ag_sp_hi;
    pipe_t       d_out;
    // A string engine uop has no address registers: its offset is the
    // displacement. A bit test's displacement is T1 (disp_t1, far_off with
    // far_t). The segment term: a system access's table base (GDTR's for a
    // descriptor, or LDTR's for a TI=1 selector; IDTR's for a real-mode
    // vector or a gate), with no wrap; a protected-mode far jump's
    // descriptor base, from T2 and T3.
    // A new-stack access (d_nstk) is at T5 plus its slot, wrapped by the
    // staged SS's width, in the staged SS; a TSS read at TR's base; the
    // held CS's accessed bit in its table; a privilege transition's far
    // jump to the held CS's base.
    // These rare uops' address terms (d_xaddr) come in after the
    // store-to-load check's (d_lo), which takes them as unknown: a load
    // among them waits for an older store, and a store among them makes a
    // younger load wait (st_near, ag_slo_ok).
    logic [31:0] d_mdisp, d_mseg_term, d_mdisp_lo, d_mseg_lo, nst_off, x_mdisp, x_mseg;
    logic        d_xaddr;
    // RETF imm16's SS and ESP slots, to an outer privilege (pimm): the slot
    // past imm16 too, wrapped by the stack's width.
    logic [31:0] pimm_off, pimm_disp;
    assign pimm_off = slot_off + dc.uop.imm;
    assign pimm_disp = sst ? pimm_off : {16'b0, pimm_off[15:0]};
    assign d_xaddr = d_nstk || dc.tss != 3'd0 || dc.uop.desc == 4'(fes_i386_pkg::DESC_HACC) || dc.uop.xfer || dc.pimm;
    assign nst_off = t5 + slot_off;
    assign d_mdisp_lo = dc.far_jmp || dc.disp_t1 ? far_off : dc.str_a || dc.str_b || dc.str_fin ? str_off
                      : stk != fes_i386_pkg::STK_NONE ? st_disp : lea_disp;
    assign d_mseg_lo = dc.far_jmp ? (dc.uop.seg2_pm ? {t3[31:24], t3[7:0], t2[31:16]} : {12'd0, far_sel, 4'd0})
                     : lea ? 32'd0 : dc.uop.mem.system ? (desc_t0 ? (t0[2] ? ldtr_base : gdtr_base)
                                                          : dc.uop.desc[3] ? gdtr_base : idtr_base)
                     : u.mem.addr32 ? seg_base[mseg] : {16'b0, seg_base[mseg][15:0]};
    assign x_mdisp = d_nstk ? (ds_ar[14] ? nst_off : {16'b0, nst_off[15:0]}) : dc.tss != 3'd0 ? tss_disp
                   : dc.pimm ? pimm_disp
                   : dc.uop.desc == 4'(fes_i386_pkg::DESC_HACC) ? {16'b0, hs_sel[15:3], 3'd5} : d_mdisp_lo;
    assign x_mseg = dc.uop.xfer ? hs_base : d_nstk ? ds_base : tsf_new ? {t3[31:24], t3[7:0], t2[31:16]}
                  : dc.tss != 3'd0 ? tr_base
                  : dc.uop.desc == 4'(fes_i386_pkg::DESC_HACC) ? (hs_sel[2] ? ldtr_base : gdtr_base) : d_mseg_lo;
    assign d_mdisp = d_xaddr ? x_mdisp : d_mdisp_lo;
    assign d_mseg_term = d_xaddr ? x_mseg : d_mseg_lo;

    // The store-to-load check (store_hazard). Two bytes are the same physical
    // byte only if their linear addresses agree in bits 11:0: A20M masks bit
    // 20, the reset alias moves bits 31:16, and a page keeps its offset. A
    // memory operand's linear address is AG's sum of its segment term, row,
    // last and displacement, so D works out its bits 11:0 from the operands
    // it hands AG (d_lo), unless a late value from M1, EX or WB replaces
    // last. A store keeps its own in AG (ag_slo). The load at D may then
    // meet the store in AG only if L + i == S + k (mod 4096) for one of its
    // bytes i < nl and one of the store's k < ns: L - S is in
    // [-(nl - 1), ns - 1], so e = L - S + nl - 1 is at most nl + ns - 2.
    // Modulo 4096, a misaligned access, one that crosses a line or a page,
    // and an offset that wraps at 64 KiB (a multiple of 4096) all count each
    // byte where it lands. Unknown bits 11:0, on either side, wait.
    logic [11:0] d_lo, ag_slo, st_e;
    logic [3:0]  ag_sbytes, st_span;
    logic        ag_slo_ok;
    assign d_lo = d_mseg_lo[11:0] + row[11:0] + last[11:0] + d_mdisp_lo[11:0];
    assign st_e = d_lo - ag_slo + 12'(dc.uop.mem.bytes) - 12'd1;
    assign st_span = dc.uop.mem.bytes + ag_sbytes - 4'd2;
    assign st_near = late != 2'd0 || !ag_slo_ok || d_xaddr || st_e[11:4] == 8'd0 && st_e[3:0] <= st_span;
    always_ff @(posedge clk) if (!freeze) begin
        ag_slo <= d_lo;
        ag_slo_ok <= late == 2'd0 && !d_xaddr;
        ag_sbytes <= dc.uop.mem.bytes;
    end
    // A system register as src2's value (decoded_t b_sys). LAR's kin take
    // theirs in M1, from the staged descriptor. The x87 pointers' words are
    // the 387's layouts' ("x87 pointers"), by CR0.PE; a 16-bit layout
    // stores their low halves.
    logic [31:0] sys_val;
    always_comb begin
        case (dc.sys_idx)  // not cast to sys_rd_e: DeanoC/yosys#72
            5'(fes_i386_pkg::SYS_RD_CR0): sys_val = cr0_rd;
            5'(fes_i386_pkg::SYS_RD_CR2): sys_val = cr2;
            5'(fes_i386_pkg::SYS_RD_CR3): sys_val = cr3;
            5'(fes_i386_pkg::SYS_RD_GDTL): sys_val = {16'd0, gdtr_limit};
            5'(fes_i386_pkg::SYS_RD_GDTB): sys_val = gdtr_base;
            5'(fes_i386_pkg::SYS_RD_IDTL): sys_val = {16'd0, idtr_limit};
            5'(fes_i386_pkg::SYS_RD_IDTB): sys_val = idtr_base;
            5'(fes_i386_pkg::SYS_RD_LDTR): sys_val = {16'd0, ldtr_sel};
            5'(fes_i386_pkg::SYS_RD_TR): sys_val = {16'd0, tr_sel};
            5'(fes_i386_pkg::SYS_RD_ERR): sys_val = {16'd0, exc_err};
            // With a 387 fitted the unit's word, and its opcode, stand
            // where an empty socket gives all ones: the 387's control,
            // status and tag words for an environment's first three fields,
            // its value for a store, and the opcode in the field that
            // carries it. The layouts are otherwise the same.
            5'(fes_i386_pkg::SYS_RD_ONES): sys_val = x87_present ? x87_sval : 32'hffff_ffff;
            5'(fes_i386_pkg::SYS_RD_FIP): sys_val = cr0_pe ? fpu_ip : {16'hffff, fpu_lip[15:0]};
            5'(fes_i386_pkg::SYS_RD_FCS): sys_val = cr0_pe ? {5'd0, x87_present ? arch_x87_opcode : 11'h7ff, fpu_cs}
                                                 : {4'd0, fpu_lip[31:16], 1'b0,
                                                    x87_present ? arch_x87_opcode : 11'h7ff};
            5'(fes_i386_pkg::SYS_RD_FDP): sys_val = cr0_pe ? fpu_dp : {16'hffff, fpu_ldp[15:0]};
            5'(fes_i386_pkg::SYS_RD_FDS): sys_val = cr0_pe ? {16'hffff, fpu_ds}
                                                 : {4'd0, fpu_ldp[31:16], 12'd0};
            5'(fes_i386_pkg::SYS_RD_ARPL): sys_val = {16'd0, t1[15:2], t2[1:0]};
            5'(fes_i386_pkg::SYS_RD_DR0): sys_val = dr[0];
            5'(fes_i386_pkg::SYS_RD_DR1): sys_val = dr[1];
            5'(fes_i386_pkg::SYS_RD_DR2): sys_val = dr[2];
            5'(fes_i386_pkg::SYS_RD_DR3): sys_val = dr[3];
            5'(fes_i386_pkg::SYS_RD_DR6): sys_val = dr6_rd;
            5'(fes_i386_pkg::SYS_RD_DR7): sys_val = dr7;
            5'(fes_i386_pkg::SYS_RD_TR4): sys_val = trn[0];
            5'(fes_i386_pkg::SYS_RD_TR5): sys_val = trn[1];
            5'(fes_i386_pkg::SYS_RD_TR6): sys_val = trn[2];
            5'(fes_i386_pkg::SYS_RD_TR7): sys_val = trn[3];
            default: sys_val = 32'd0;
        endcase
    end
    always_comb begin
        d_out = '0;
        d_out.valid = issue;
        d_out.uop = u;
        // With the identity clear nothing carries the flag, so the uop's
        // commit touches no x87 state and FLDENV and FRSTOR load and
        // discard, as the empty socket does. WAIT takes nothing either.
        d_out.x87 = x87_present && dc.x87 && !dc.x87_wait;
        d_out.x87_part = dc.x87_part;
        d_out.gov = dc.gov;
        d_out.eip = d_eip;
        d_out.eip_next = d_eip_next;
        d_out.a = dc.cs_base ? seg_base[SEG_CS] : dc.a_t1 ? t1 : a_val;
        d_out.b = reads_seg ? {16'b0, seg_sel[seg_index]} : dc.push_eip ? d_eip_next : dc.b_t1 ? t1 : dc.b_t4 ? t4
                : dc.b_fp ? r_fp : dc.b_sys ? sys_val : dc.b_far ? {16'b0, dc.far_sel}
                : dc.uop.desc == 4'(fes_i386_pkg::DESC_ACC) ? {24'b0, t3[15:9], 1'b1}
                : dc.uop.desc == 4'(fes_i386_pkg::DESC_HACC) ? {24'b0, hs_acc[7:1], 1'b1}
                : dc.uop.desc == 4'(fes_i386_pkg::DESC_BUSY) ? t3 | 32'h0000_0200
                : dc.uop.desc == 4'(fes_i386_pkg::DESC_UNBUSY) ? t4 & 32'hffff_fdff : u.src2.valid ? b_val : u.imm;
        d_out.c = dc.far_jmp ? {16'b0, far_sel} : c_val;
        // A CMPS element's compare takes its first load's result one stage
        // ahead (x_prev).
        d_out.pend_a = dc.x_prev || u.src1.valid && a_pend;
        d_out.pend_b = u.src2.valid && b_pend;
        d_out.pend_c = u.count_cl && c_pend;
        d_out.dist_a = dc.x_prev ? 3'd1 : a_dist;
        d_out.dist_b = b_dist;
        d_out.dist_c = c_dist;
        d_out.early = d_early;
        // A load whose result is its load data, whole, so D's address
        // forwarding takes it from the loaded value (pipe_t ld) from the
        // cycle the load is in EX, or late into AG while it is in M2
        // (fes_i386_dfwd's LOAD kind): MOV r32 and POP r32 from memory, and
        // MOVZX r32, whose load data is zero above its size. A 16-bit load
        // keeps its register's high half, and MOVSX and a load-op change the
        // value in EX.
        d_out.ldfwd = u.cls == fes_i386_pkg::UOP_ALU && (u.op == 5'(fes_i386_pkg::ALU_MOV) || u.op == 5'(fes_i386_pkg::ALU_MOVZX))
                   && mkind == fes_i386_pkg::MEM_LOAD && !u.mem.in_a && u.size == fes_i386_pkg::SIZE_32 && !u.dst.hi8;
        // A system access (mem.system) is checked against its table's limit,
        // at its first read: a real-mode vector's offset against IDTR's
        // limit less 3, a gate's against IDTR's less 7, a descriptor's low
        // dword against GDTR's less 7, or the LDT's for a TI=1 selector,
        // which fails when LDTR is not valid. Its other parts, and POP Sreg's
        // step of ESP (nochk), are not checked. Any other access is checked
        // against its segment (seg_chk_t).
        // A new-stack access is checked against the staged SS; the TSS's
        // read of ESP against TR's limit less the stack's slots (7 bytes
        // on from it in a 386 TSS, 3 in a 286 TSS), its read of SS not.
        d_out.mlimit = dc.uop.desc == 4'(fes_i386_pkg::DESC_LO) ? (t0[2] ? ldt_lim7 : {16'b0, gdt_lim7})
                     : dc.uop.desc == 4'(fes_i386_pkg::DESC_IDT_LO) ? {16'b0, idt_lim7}
                     : d_nstk ? ds_chk.lim[msize]
                     : dc.tss == 3'(fes_i386_pkg::TSS_ESP) ? tss_lim_sp
                     : dc.tss == 3'(fes_i386_pkg::TSS_BITMAP) ? tss_lim_bm
                     : dc.uop.mem.system && dc.uop.desc == 4'd0 && !dc.sel_part && dc.tss == 3'd0
                       ? {16'b0, idt_lim3} : dc.uop.mem.system || dc.nochk ? 32'hffff_ffff : seg_lim[mseg][msize];
        d_out.mtiny = dc.uop.desc == 4'(fes_i386_pkg::DESC_LO) ? (t0[2] ? ldt_tiny7 || !ldtr_valid : gdt_tiny7)
                    : dc.uop.desc == 4'(fes_i386_pkg::DESC_IDT_LO) ? idt_tiny7
                    : d_nstk ? ds_chk.tiny[msize] || mem_reads && ds_chk.rbad || mem_writes && ds_chk.wbad
                    : dc.tss == 3'(fes_i386_pkg::TSS_ESP) ? tss_tiny_sp
                    : dc.tss == 3'(fes_i386_pkg::TSS_BITMAP) ? tss_tiny_bm
                    : dc.uop.mem.system && dc.uop.desc == 4'd0 && !dc.sel_part && dc.tss == 3'd0
                      ? idt_tiny3 : !dc.uop.mem.system && !dc.nochk
                        && (seg_tiny[mseg][msize] || mem_reads && seg_rbad[mseg] || (mem_writes || xchg_ld) && seg_wbad[mseg]);
        d_out.mlow = d_nstk ? ds_chk.low : seg_low[mseg];
        d_out.mexpd = d_nstk ? ds_chk.expd : !dc.uop.mem.system && !dc.nochk && seg_expd[mseg];
        // Loads whose data nothing uses: probes, ENTER's last check, POP m's
        // pop into nothing, and the multiply and divide unit's LOAD and HI.
        d_out.sdisp = dc.pimm ? pimm_off[17:0] : {{10{st_disp[7]}}, st_disp[7:0]};
        d_out.nodata = dc.stk == fes_i386_pkg::STK_PROBE || dc.str_fin || dc.nochk
                    || dc.seq == 5'(fes_i386_pkg::SEQ_POPM) && dc.stk == fes_i386_pkg::STK_POP
                    || (u.op == 5'd4 || u.op == 5'd5) && (u.cls == fes_i386_pkg::UOP_MUL || u.cls == fes_i386_pkg::UOP_DIV);
        // A st2 uop's store address and its fault; the next instruction for
        // a REPE or REPNE element. AG keeps them.
        d_out.target = dc.str_two ? str_daddr : s_tgt;
        d_out.dfault = dc.str_two && str_dbad && !s_kill1 ? (str_ss ? fes_i386_pkg::FAULT_SS0 : fes_i386_pkg::FAULT_GP0)
                                                          : fes_i386_pkg::FAULT_NONE;
        // The uops whose target M1 checks against CS's limit (tchk): a near
        // branch by a displacement (Jcc, JMP, LOOP and its kin, JCXZ; not a
        // far jump, nor INTO's JNO to the next instruction), and CALL rel's
        // push, whose target AG works out (ag_call). A far transfer's offset
        // past the limit at a uop other than a probe, #GP(0) after the uop's
        // own checks (cs_late). CALL r/m's push, whose target T1 is past the
        // limit, faults on none of it (cpast; see M1).
        d_out.tchk = u.cls == fes_i386_pkg::UOP_BRANCH && u.op < 5'd10 && !dc.far_jmp && !u.eoi_taken
                  || dc.seq == fes_i386_pkg::SEQ_CALL && dc.step == 3'd0;
        d_out.cs_late = far_bad && stk != fes_i386_pkg::STK_PROBE && !chk_calli;
        d_out.cpast = far_bad && chk_calli;
        // A string's first element with a count of 1 is the last, with no
        // REPE or REPNE exit; with a count of 0, a NOP that ends the
        // instruction.
        if (s_end1) begin
            d_out.uop.ctl.end_of_instruction = 1'b1;
            d_out.uop.rep_stop = 2'd0;
            d_out.uop.eoi_taken = 1'b0;
        end
        // The fetch check's fields: the instruction's linear address and
        // length, checked at its first uop (not an exception's entry), and
        // its BTB match for WB.
        d_out.lin = dc.lin;
        d_out.ilen = dc.length;
        d_out.fchk = d_first && dc.fetched;
        d_out.dbr = d_dbr;
        d_out.pt = d_pt || d_ipt;
        d_out.ncall = d_ncall;
        d_out.nret = d_nret;
        d_out.nind = d_nind;
        d_out.peip = d_ieip;
        d_out.bm = dc.bm;
        d_out.bway = dc.bway;
        d_out.bctr = dc.bctr;
        if (s_kill1) begin
            d_out.uop.cls = fes_i386_pkg::UOP_SPECIAL;  // SPECIAL_NOP
            d_out.uop.op = 5'd0;
            d_out.uop.ctl.fault = fes_i386_pkg::FAULT_NONE;
            d_out.uop.mem.kind = fes_i386_pkg::MEM_NONE;
            d_out.uop.dst.valid = 1'b0;
            d_out.uop.flags = '0;
            d_out.uop.str_si = 1'b0;
            d_out.uop.str_di = 1'b0;
            d_out.uop.str_cx = 1'b0;
            d_out.uop.st2 = 1'b0;
            d_out.uop.io = 2'd0;
        end
        // An instruction whose bytes ran into a predicted target's half
        // (xbad) replays, whatever its decode made of them.
        if (dc.xbad) begin
            d_out.uop.ctl.fault = fes_i386_pkg::FAULT_REPLAY;
            d_out.fbad = 1'b1;
        end
        // A protected-mode IRET decoded by a stale NT (above, nt_busy).
        if (!s_kill1 && dc.uop.ntchk && eflags[14] != dc.uop.ntset) begin
            d_out.uop.ctl.fault = fes_i386_pkg::FAULT_REPLAY;
            d_out.uop.mem.kind = fes_i386_pkg::MEM_NONE;
        end
        // Paging: the physical page bits 19:12 of the instruction's lines
        // (self-modifying code); a fetch walk, of the page at pf_lin, and
        // nothing else; whether a load whose data nothing uses translates
        // (nx: all but a probe of a slot to be pushed and ENTER's last check,
        // Bochs's tickle_write_virtual, each a write's: wx). A probe so
        // faults as the push it stands for, in the pushes' order, as Bochs
        // pushes and faults. XCHG's load translates as a write (wx).
        // ARPL's initial load is a read; only an RPL adjustment writes,
        // so that separate store performs the write translation (#1665).
        d_out.ipp0 = dc.pp0;
        d_out.ipp1 = dc.pp1;
        d_out.nx = d_out.nodata && !dc.str_fin && dc.stk != fes_i386_pkg::STK_PROBE
                || dc.x87 && x87_nx;
        d_out.wx = dc.str_fin || dc.stk == fes_i386_pkg::STK_PROBE || xchg_ld;
        d_out.ones = tsf_any && !tsf_32 && u.dst.valid && u.dst.space == fes_i386_pkg::RS_GPR;
        d_out.iret0 = d_first && dc.fetched && !d_ifw && !cs_gp
                   && u.ctl.fault == fes_i386_pkg::FAULT_NONE && dc.seq == fes_i386_pkg::SEQ_UCODE
                   && (dc.upc == fes_i386_ucode_pkg::UC_IRET || dc.upc == fes_i386_ucode_pkg::UC_VIRET
                    || dc.upc == fes_i386_ucode_pkg::UC_PIRET || dc.upc == fes_i386_ucode_pkg::UC_TSSAVE);
        d_out.ice0 = d_first && dc.fetched && !d_ifw && u.ice && u.ctl.fault == fes_i386_pkg::FAULT_NONE;
        if (d_ifw) begin
            d_out.ifw = 1'b1;
            d_out.pf_lin = d_ifw_lin;
            d_out.nodata = 1'b0;
            d_out.nx = 1'b0;
            d_out.wx = 1'b0;
            d_out.cs_late = 1'b0;
            d_out.cpast = 1'b0;
            d_out.tchk = 1'b0;
            d_out.dfault = fes_i386_pkg::FAULT_NONE;
            d_out.dbr = 1'b0;
            d_out.pt = 1'b0;
            d_out.ncall = 1'b0;
            d_out.nret = 1'b0;
            d_out.nind = 1'b0;
            d_out.bm = 1'b0;
        end
    end
    always_ff @(posedge clk) begin
        if (reset || wb_flush) begin
            ag_s.valid <= 1'b0;
            ag_store <= 1'b0;
            ag_shift <= 1'b0;
            ag_wsp <= 1'b0;
        end else if (!freeze) begin
            ag_s <= d_out;
            ag_store <= issue && mem_writes && !s_kill1;
            ag_shift <= issue && u.cls == fes_i386_pkg::UOP_SHIFT;
            ag_wsp <= writes_sp(d_out);
        end
        if (!freeze) begin
            ag_stack <= stk != fes_i386_pkg::STK_NONE;
            ag_ss32 <= sst;
            ag_leave <= stk == fes_i386_pkg::STK_LEAVE;
            ag_call <= dc.seq == fes_i386_pkg::SEQ_CALL && dc.step == 3'd0;
            ag_o32 <= opsize32;
            // ENTER's last uop: ESP from the engine's offset, its high half
            // the copy's.
            ag_sp_disp <= dc.str_fin ? str_off : st_sp_disp;
            ag_sp_hi <= dc.str_fin ? r_dst[31:16] : dc.ealu ? base_hi : sp_hi;
            ag_e16 <= dc.ealu && !opsize32;
        end
        if (freeze) begin
            // AG keeps its uop's operands.
        end else if (addr_use || dc.far_jmp || dc.ealu) begin
            // LEA's offset, or a memory operand's address: its segment's
            // base, wrapped like the offset by address size. A far jump's
            // target: the new CS's base, selector * 16, plus the offset,
            // which is already its operand size's; with no base or index
            // looked up, the rows are zero.
            ag_addr32 <= dc.ealu ? opsize32 : dc.far_jmp || u.mem.addr32 || dc.uop.mem.system;
            ag_row <= row;
            ag_last <= last;
            ag_late <= late;
            ag_late_hi <= late_hi;
            ag_disp <= d_mdisp;  // and the segment term: see d_mdisp
            ag_seg_term <= d_mseg_term;
            ag_seg_hi <= lea || dc.uop.mem.system ? 16'd0 : seg_base[mseg][31:16];
            ag_seg_hi_plus1 <= lea || dc.uop.mem.system ? 16'd0 : seg_hi1[mseg];
        end else begin
            // A branch's target: CS.base + EIP + length + displacement,
            // wrapped by operand size. System uops and INTO's JNO target
            // the next instruction with full EIP, regardless of operand size.
            ag_addr32 <= opsize32 || d_next_instruction;
            ag_row <= opsize32 || d_next_instruction ? d_eip : {16'b0, d_eip[15:0]};
            ag_last <= {28'd0, dc.length};
            ag_late <= 2'd0;
            ag_late_hi <= 2'd0;
            ag_disp <= d_next_instruction ? 32'd0 : u.imm;
            ag_seg_term <= opsize32 || d_next_instruction ? seg_base[SEG_CS]
                                                          : {16'b0, seg_base[SEG_CS][15:0]};
            ag_seg_hi <= seg_base[SEG_CS][31:16];
            ag_seg_hi_plus1 <= seg_hi1[SEG_CS];
        end
    end

    // ---- AG -----------------------------------------------------------------------
    // A pending operand whose producer is now in WB is taken from the WB
    // register (dist 4 at AG, 3 at M1, 2 at M2; at dist 1 EX selects it).
    function automatic pipe_t capture(input pipe_t s, input logic [2:0] at, input logic [31:0] wb_value);
        pipe_t t;
        t = s;
        if (s.pend_a && s.dist_a == at) begin t.a = wb_value; t.pend_a = 1'b0; end
        if (s.pend_b && s.dist_b == at) begin t.b = wb_value; t.pend_b = 1'b0; end
        if (s.pend_c && s.dist_c == at) begin t.c = wb_value; t.pend_c = 1'b0; end
        capture = t;
    endfunction

    logic [31:0] linear, offset, base_op;
    fes_i386_agu agu (
        .addr32(ag_addr32), .seg_term(ag_seg_term), .seg_hi(ag_seg_hi), .seg_hi_plus1(ag_seg_hi_plus1),
        .row(ag_row), .last(ag_last), .disp(ag_disp), .late(ag_late), .late_hi(ag_late_hi),
        .late_m1(m1_s.result), .late_ex(ex_s.ld), .late_wb(wb_s.result), .linear, .offset, .base_op
    );

    // A stack operation's new ESP: a third chain beside the AGU's two, on the
    // stack register as the AGU takes it (its low half on a 16-bit stack, a
    // late value included). A 16-bit stack keeps ESP's high half: the late
    // value's, else D's register value. LEAVE's is ESP's, not EBP's.
    logic [31:0] sp_sum, sp_new;
    logic [15:0] sp_hi_ag;
    assign sp_sum = base_op + ag_sp_disp;
    always_comb begin
        case (ag_late)
            2'd1: sp_hi_ag = m1_s.result[31:16];
            2'd2: sp_hi_ag = ex_s.ld[31:16];
            2'd3: sp_hi_ag = wb_s.result[31:16];
            default: sp_hi_ag = ag_sp_hi;
        endcase
        if (ag_leave) sp_hi_ag = ag_sp_hi;
    end
    assign sp_new = ag_ss32 ? sp_sum : {sp_hi_ag, sp_sum[15:0]};

    // CALL rel's push: its target, the next EIP (b) plus the displacement
    // (imm), wrapped by operand size, for M1's check (tchk), beside the
    // AGU's chains.
    logic [31:0] call_tgt;
    assign call_tgt = ag_s.b + ag_s.uop.imm;

    pipe_t ag_out;
    logic ag_next_instruction;
    assign ag_next_instruction = ag_s.uop.rep_stop != 2'd0 || ag_s.uop.eoi_taken
                              || ag_s.uop.cls == fes_i386_pkg::UOP_SYSTEM && !fes_i386_pkg::sys_nojmp(ag_s.uop.op);
    // The fetch check (see Branch prediction): the instruction's fetched
    // linear address is CS.base + EIP. a + b == c without a carry chain: the
    // carries a + b would need to give c, bit by bit, must be those it makes.
    function automatic logic sum_is(input logic [31:0] a, input logic [31:0] b, input logic [31:0] c);
        logic [31:0] k_in, k_out;
        k_in = a ^ b ^ c;
        k_out = (a & b) | ((a ^ b) & ~c);
        sum_is = k_in == {k_out[30:0], 1'b0};
    endfunction
    logic ag_fbad;
    assign ag_fbad = ag_s.fchk && !sum_is(seg_base[SEG_CS], ag_s.eip, ag_s.lin);
    always_comb begin
        ag_out = capture(ag_s, 3'd4, wb_s.result);
        // A stack operation's result until EX is its new ESP, so ESP forwards
        // from the M1, M2 and EX registers like any early result.
        // A 16-bit early-ALU result keeps its register's high half (sp_hi_ag:
        // the late value's, else D's), as a 16-bit stack's ESP does.
        ag_out.result = ag_stack ? sp_new : ag_e16 ? {sp_hi_ag, offset[15:0]} : offset;
        ag_out.sp_new = sp_new;
        // D's target for a st2 uop (its store) or a REPE or REPNE element
        // (the next instruction, also its EIP); CALL rel's push's target EIP.
        ag_out.target = ag_s.uop.st2 || ag_s.uop.rep_stop != 2'd0 ? ag_s.target : linear;
        ag_out.target_eip = ag_next_instruction ? ag_s.eip_next
                          : ag_call ? {ag_o32 ? call_tgt[31:16] : 16'd0, call_tgt[15:0]} : offset;
        ag_out.maddr = linear;
        ag_out.moff = offset;
        // An instruction's first uop: the instruction breakpoints its fetched
        // linear address matches (see Breakpoints), which EX turns into the
        // fault (FAULT_DBI) while RF is clear.
        ag_out.ibp = ag_s.fchk && !ibp_skip ? ibp_match(ag_s.lin, dr, bp_any, bp_x, bp_m) : 4'd0;
        ag_out.ibp_en = (ag_out.ibp & bp_en) != 4'd0;
        // Its bytes are not those at its EIP: it replays, touching nothing.
        if (ag_fbad) begin
            ag_out.uop.ctl.fault = fes_i386_pkg::FAULT_REPLAY;
            ag_out.fbad = 1'b1;
        end
    end
    always_ff @(posedge clk) begin
        if (reset || wb_flush) begin
            m1_s.valid <= 1'b0;
        end else if (!freeze) begin
            m1_s <= ag_out;
        end
    end

    // ---- M1 -----------------------------------------------------------------------
    // The segment limit check: the offset against the limit less the access's
    // bytes but one, which D picked (#SS(0) for SS, #GP(0) otherwise). A load
    // sends its address to the data port.
    function automatic logic reads_mem(input pipe_t s);
        reads_mem = s.uop.mem.kind == fes_i386_pkg::MEM_LOAD || s.uop.mem.kind == fes_i386_pkg::MEM_RMW;
    endfunction
    function automatic logic writes_mem(input pipe_t s);
        writes_mem = s.uop.mem.kind == fes_i386_pkg::MEM_STORE || s.uop.mem.kind == fes_i386_pkg::MEM_RMW || s.uop.st2;
    endfunction
    // Where a store writes: its memory operand, or for a st2 uop (which
    // loads there) its second address.
    function automatic logic [31:0] saddr(input pipe_t s);
        saddr = s.uop.st2 ? s.target : s.maddr;
    endfunction
    pipe_t m1_out;
    logic  m1_limit;
    // INT's probe reads its lowest slot. Under SS's limit of FFFFh a slot
    // faults only by straddling the 64 KiB wrap, which one of INT's three
    // words does when they wrap (the lowest past FFFAh) at an odd offset:
    // then the probe faults, before INT writes anything. M1 records it
    // (pbad) and M2 raises #SS(0) from that register, off M1's fault path;
    // a probe writes nothing and never branches, so a stage later is as good.
    // Under a limit past 10000h (seg_ss_big) no slot faults. SS is current:
    // the probe waits in D for an older write of it.
    logic m1_probe_bad;
    assign m1_probe_bad = m1_s.uop.probe == fes_i386_pkg::PROBE_INT && !m1_s.uop.mem.addr32
                       && m1_s.moff[15:0] > 16'hfffa && m1_s.moff[0] && seg_ss_rm;
    logic [31:0] m1_bound_low;
    logic        m1_bound_wrap;
    // BOUND's first load is the upper slot, addressed one operand past the
    // lower slot. Check the whole pair before touching either slot: the lower
    // offset may have wrapped while forming this upper address, and reading
    // the upper slot first could otherwise cause an MMIO side effect before
    // the lower slot raises #GP/#SS.
    assign m1_bound_low = m1_s.uop.mem.addr32 ? m1_s.moff - 32'(m1_s.uop.mem.bytes)
                                               : {16'd0, m1_s.moff[15:0] - 16'(m1_s.uop.mem.bytes)};
    assign m1_bound_wrap = m1_bound_low > m1_s.mlimit || m1_s.mtiny || m1_s.mexpd && m1_bound_low <= m1_s.mlow;
    assign m1_limit = m1_s.uop.mem.kind != fes_i386_pkg::MEM_NONE
                   && (m1_s.moff > m1_s.mlimit || m1_s.mtiny || m1_s.mexpd && m1_s.moff <= m1_s.mlow
                       || m1_s.uop.bound_pair && m1_bound_wrap);
    // A protected-mode segment load's, far transfer's or delivery's checks
    // (segchk) come from the staged descriptor (ds_fault_*); what each
    // stops on as not built, and why, follows from the check.
    fes_i386_pkg::fault_e m1_segchk;
    fes_i386_pkg::why_e   m1_why;
    always_comb begin
        m1_why = fes_i386_pkg::WHY_GATE;
        case (m1_s.uop.segchk)  // not cast to segchk_e: DeanoC/yosys#72
            5'(fes_i386_pkg::CHK_DATA): m1_segchk = ds_fault_data;
            5'(fes_i386_pkg::CHK_SS): m1_segchk = ds_fault_ss;
            5'(fes_i386_pkg::CHK_JMP): m1_segchk = ds_fault_cs;
            // A software interrupt's gate (no delivery under way) is checked
            // against CPL too, but ICEBP's (ice).
            5'(fes_i386_pkg::CHK_GATE): m1_segchk = exc_active || m1_s.uop.ice ? ds_fault_gate : ds_fault_sgate;
            5'(fes_i386_pkg::CHK_INTCS): m1_segchk = ds_fault_intcs;
            // A delivery from V86 mode: its CS, and once the TSS's stack is
            // read, that CS's DPL (the held CPL), which must be 0.
            5'(fes_i386_pkg::CHK_V86CS): m1_segchk = ds_fault_v86cs;
            5'(fes_i386_pkg::CHK_V86DPL): m1_segchk = hs_cpl != 2'd0 ? fes_i386_pkg::FAULT_GP_SEL : fes_i386_pkg::FAULT_NONE;
            5'(fes_i386_pkg::CHK_CALL): m1_segchk = ds_fault_call;
            5'(fes_i386_pkg::CHK_RET): m1_segchk = ds_fault_ret;
            5'(fes_i386_pkg::CHK_SSRET): m1_segchk = ds_fault_ssret;
            5'(fes_i386_pkg::CHK_SSINT): m1_segchk = ds_fault_ssint;
            5'(fes_i386_pkg::CHK_HOFF): m1_segchk = ds_fault_hoff;
            // The port's bits for the access's size in the bitmap's word:
            // any set, #GP(0).
            5'(fes_i386_pkg::CHK_IOBM):
                m1_segchk = |(t2[15:0] >> t5[2:0] & (m1_s.uop.size == fes_i386_pkg::SIZE_8 ? 16'h0001
                                                     : m1_s.uop.size == fes_i386_pkg::SIZE_16 ? 16'h0003 : 16'h000f))
                          ? fes_i386_pkg::FAULT_GP0 : fes_i386_pkg::FAULT_NONE;
            5'(fes_i386_pkg::CHK_LDT): m1_segchk = ds_fault_ldt;
            5'(fes_i386_pkg::CHK_TSS): m1_segchk = ds_fault_tss;
            // A task switch's (see Task switches).
            5'(fes_i386_pkg::CHK_TSW): m1_segchk = ds_fault_tsw;
            5'(fes_i386_pkg::CHK_TSGATE): m1_segchk = ds_fault_tsgate;
            5'(fes_i386_pkg::CHK_TSRET): m1_segchk = ds_fault_tsret;
            5'(fes_i386_pkg::CHK_TSLDT): m1_segchk = ds_fault_tsldt;
            5'(fes_i386_pkg::CHK_TSSS): m1_segchk = ds_fault_tsss;
            5'(fes_i386_pkg::CHK_TSCS): m1_segchk = ds_fault_tscs;
            5'(fes_i386_pkg::CHK_TSDATA): m1_segchk = ds_fault_tsdata;
            5'(fes_i386_pkg::CHK_TSOLD): m1_segchk = ds_fault_tsold;
            default: m1_segchk = fes_i386_pkg::FAULT_NONE;
        endcase
    end
    // A protected-mode far CALL's, RETF's or IRET's slot on a 16-bit stack
    // (nwrap) is at SP plus or less its displacement without the 64 KiB
    // wrap, as Bochs reads and writes it: one that wraps is past an
    // expand-down stack's top or a 64 KiB limit (#SS(0)), and under a
    // larger limit at an offset this build does not address, which stops it
    // as not built.
    logic m1_wrap, m1_ss_far;
    assign m1_wrap = m1_s.uop.nwrap && !m1_s.uop.mem.addr32 && m1_s.uop.mem.kind != fes_i386_pkg::MEM_NONE
                  && (m1_s.sdisp[17] ? {1'b0, m1_s.moff[15:0]} + 17'(-m1_s.sdisp) > 17'h0_ffff
                                     : {1'b0, m1_s.moff[15:0]} < m1_s.sdisp[16:0]);
    assign m1_ss_far = seg_limit[SEG_SS][31:16] != 16'd0 && !seg_expd[SEG_SS];
    // LAR, LSL, VERR and VERW (SEGOP_ZF, imm[3:1]): ZF in imm[0] and LAR's
    // and LSL's result in b, from the staged descriptor.
    logic [2:0] m1_zk;
    // A near branch's target, or CALL rel's push's, past CS's limit (tchk):
    // EX raises #GP(0) for a branch that is taken. A near CALL's push whose
    // target is past it (cpast: CALL rel's here, CALL r/m's from D) faults
    // on none of it: it stores its slot, leaving ESP as it was (WB), and the
    // CALL's jump, which checks the same target, raises the #GP(0). So the
    // push's own faults come first and its bytes are written, as on the 386,
    // whose microcode writes the slot (CALL cw: 075 OPR_W = EIP; WR) before
    // it forms the target through CS's descriptor (076 DESCOD) and then
    // writes ESP (077), and as in Bochs (#1510).
    logic m1_tpast;
    assign m1_tpast = m1_s.tchk && m1_s.target_eip > seg_limit[SEG_CS];
    assign m1_zk = m1_s.uop.cls == fes_i386_pkg::UOP_SEGMENT && m1_s.uop.op == 5'(fes_i386_pkg::SEGOP_ZF)
                 ? m1_s.uop.imm[3:1] : 3'd0;
    always_comb begin
        m1_out = capture(m1_s, 3'd3, wb_s.result);
        m1_out.pbad = m1_probe_bad;
        // A st2 uop's second address faults after its first. A descriptor
        // past its table's limit raises #GP(selector), a gate past IDTR's
        // #GP with its IDT entry, a vector's entry past it #GP(0).
        if ((m1_limit || m1_wrap) && m1_s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE) begin
            m1_out.uop.ctl.fault = m1_s.uop.desc == 4'(fes_i386_pkg::DESC_IDT_LO) ? fes_i386_pkg::FAULT_GP_IDT
                                 : m1_s.uop.desc != 4'd0 ? (m1_s.uop.sflt == 2'(fes_i386_pkg::SFLT_TS)
                                                            ? fes_i386_pkg::FAULT_TS_SEL : fes_i386_pkg::FAULT_GP_SEL)
                                 : m1_s.uop.sflt == 2'(fes_i386_pkg::SFLT_TR) ? fes_i386_pkg::FAULT_TS_TR
                                 : m1_s.uop.sflt == 2'(fes_i386_pkg::SFLT_GP0) ? fes_i386_pkg::FAULT_GP0
                                 : m1_s.uop.nstk ? fes_i386_pkg::FAULT_SS_SEL
                                 : m1_wrap && !m1_limit && m1_ss_far ? fes_i386_pkg::FAULT_UNIMPLEMENTED
                                 : !m1_s.uop.mem.system && m1_s.uop.mem.seg == fes_i386_pkg::SEG_SS ? fes_i386_pkg::FAULT_SS0
                                 : fes_i386_pkg::FAULT_GP0;
            m1_out.uop.ctl.why = fes_i386_pkg::WHY_STACK64K;
        end else if (m1_s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE && m1_s.uop.segchk != 5'd0) begin
            m1_out.uop.ctl.fault = m1_segchk;
            m1_out.uop.ctl.why = m1_why;
        end else if (m1_s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE) begin
            m1_out.uop.ctl.fault = m1_s.cs_late ? fes_i386_pkg::FAULT_GP0 : m1_s.dfault;
            m1_out.dfl = !m1_s.cs_late && m1_s.dfault != fes_i386_pkg::FAULT_NONE;
        end
        // The data breakpoints the uop's accesses match (see Breakpoints): its
        // memory operand's, read, written or both, a descriptor's, gate's or
        // TSS's too (Bochs's system_read and system_write check a page that
        // holds a data breakpoint as any access), and a st2 uop's store at
        // its second address. The walker's page-table accesses are physical.
        m1_out.dbp = m1_s.uop.mem.kind == fes_i386_pkg::MEM_NONE ? 4'd0
                   : dbp_match(m1_s.maddr, m1_s.uop.mem.bytes, reads_mem(m1_s),
                               m1_s.uop.mem.kind == fes_i386_pkg::MEM_STORE || m1_s.uop.mem.kind == fes_i386_pkg::MEM_RMW,
                               dr, bp_any, bp_w, bp_rw, bp_m)
                     | (m1_s.uop.st2 ? dbp_match(m1_s.target, m1_s.uop.mem.bytes, 1'b0, 1'b1, dr, bp_any, bp_w, bp_rw, bp_m)
                                     : 4'd0);
        m1_out.dbp_en = (m1_out.dbp & bp_en) != 4'd0;
        // An enabled instruction breakpoint's uop touches nothing from here
        // on (no read, no walk, no fault of its own): EX makes it the #DB or,
        // when RF or a MOV SS suppresses that, a replay (see EX).
        if (m1_s.ibp_en) begin
            m1_out.uop.ctl.fault = fes_i386_pkg::FAULT_DBI;
            m1_out.dfl = 1'b0;
        end
        m1_out.tchk = m1_tpast && m1_s.uop.cls == fes_i386_pkg::UOP_BRANCH;
        m1_out.cpast = m1_s.cpast || m1_tpast && m1_s.uop.cls != fes_i386_pkg::UOP_BRANCH;
        case (m1_zk)
            3'd1: begin
                m1_out.uop.imm[0] = ds_lar_ok;
                m1_out.b = ds_lar;
            end
            3'd2: begin
                m1_out.uop.imm[0] = ds_lsl_ok;
                m1_out.b = ds_limit;
            end
            3'd3: m1_out.uop.imm[0] = ds_verr_ok;
            3'd4: m1_out.uop.imm[0] = ds_verw_ok;
            default: ;
        endcase
    end
    // ---- Paging: the DTLB at M1 -------------------------------------------------
    // CR0.PG turns paging on (pg); the TLBs are flushed on a CR3 write, a CR0
    // write that changes PG, and anything that changes what an entry's
    // physical page and attribute were made with (A20M, the attribute map).
    // M1 looks up the memory operand's page (port A) and, on port B, a st2
    // store's page or the operand's next, which a page-crossing access uses.
    // A uop the DTLB cannot serve goes to the walker (tx, fes_i386_l1d) as
    // the oldest uop: a page it does not hold, a user access to a supervisor
    // page (CPL 3, not a system access or a new stack's), a user write to a
    // read-only one, a write to a page whose D is clear, a st2 uop that
    // crosses a page (a third page), a load that may meet an older store
    // through an alias (below), or an instruction's fetch walk (ifw). A load
    // whose data nothing uses translates only as ENTER's last check (wx), a
    // write. Segment checks come first: a uop that faults here walks
    // nothing. With paging off, the pages are phys's (ppage).
    logic pg, pg_ifl, wb_tlbx, tlb_flush, a20m_q;
    logic [23:0][1:0] attr_q;
    logic [6:0] top_q;
    assign pg = cr0_pg;
    function automatic logic [PA-12:0] ppage(input logic [19:0] lp, input logic a20m_in);
        logic [PA:0] p;
        p = fes_i386_pkg::phys({lp, 12'd0}, a20m_in);
        ppage = p[PA:12];
    endfunction
    logic [1:0][19:0] dt_lp;
    logic [1:0]       dt_hit;
    logic [1:0][15:0] dt_match;
    fes_i386_pkg::tlb_entry_t [1:0] dt_q;
    logic [15:0][PA-12:0] dt_pages;
    logic             tf_valid, tf_itlb;
    fes_i386_pkg::tlb_entry_t tf_e;
    fes_i386_tlb #(.N(16), .P(2)) dtlb (
        .clk, .flush(tlb_flush), .lk_lp(dt_lp), .hit(dt_hit), .match(dt_match), .q(dt_q), .pages(dt_pages),
        .fill(tf_valid && !tf_itlb), .fill_ent(tf_e)
    );
    function automatic logic rights(input fes_i386_pkg::tlb_entry_t e, input logic w, input logic user);
        rights = (!user || e.u && (!w || e.w)) && (!w || e.d);
    endfunction
    logic        m1_st2, m1_acc, m1_wr, m1_xa, m1_xt, m1_user, m1_okA, m1_okB, m1_alias, m1_tx;
    logic [12:0] m1_enda, m1_endt;
    logic [3:0][PA-12:0] m1_pg;
    fes_i386_pkg::attr_e m1_at0, m1_at1;
    assign m1_st2 = m1_s.uop.st2;
    assign m1_acc = m1_s.uop.mem.kind != fes_i386_pkg::MEM_NONE && !m1_s.nx;
    assign m1_wr = !m1_st2 && (m1_s.uop.mem.kind == fes_i386_pkg::MEM_STORE || m1_s.uop.mem.kind == fes_i386_pkg::MEM_RMW)
                || m1_s.wx;
    assign m1_enda = {1'b0, m1_s.maddr[11:0]} + 13'(m1_s.uop.mem.bytes) - 13'd1;
    assign m1_endt = {1'b0, m1_s.target[11:0]} + 13'(m1_s.uop.mem.bytes) - 13'd1;
    assign m1_xa = m1_enda[12];
    assign m1_xt = m1_st2 && m1_endt[12];
    assign m1_user = cpl == 2'd3 && !m1_s.uop.mem.system && !m1_s.uop.nstk;
    assign dt_lp[0] = m1_s.maddr[31:12];
    assign dt_lp[1] = m1_st2 ? m1_s.target[31:12] : m1_s.maddr[31:12] + 20'd1;
    assign m1_okA = dt_hit[0] && rights(dt_q[0], m1_wr, m1_user);
    assign m1_okB = dt_hit[1] && rights(dt_q[1], m1_st2 || m1_wr, m1_user);
    // A st2 uop whose store's segment check fails (dfl) still translates
    // its load's pages, whose #PF comes first, as Bochs reads first.
    assign m1_tx = pg && m1_s.valid && !m1_probe_bad
                && (m1_out.uop.ctl.fault == fes_i386_pkg::FAULT_NONE
                    && (m1_s.ifw || m1_acc && (!m1_okA || (m1_xa || m1_st2) && !m1_okB || m1_st2 && (m1_xa || m1_xt)
                                               || m1_alias && reads_mem(m1_s)))
                    || m1_out.dfl && m1_acc && (!m1_okA || m1_xa));
    always_comb begin
        if (pg) begin
            m1_pg = {ppage(m1_s.target[31:12] + 20'd1, a20m), dt_q[1].pp, dt_q[1].pp, dt_q[0].pp};
            m1_at0 = dt_q[0].at;
            m1_at1 = m1_s.maddr[11:5] == 7'h7f ? dt_q[1].at : dt_q[0].at;
        end else begin
            m1_pg = {ppage(m1_s.target[31:12] + 20'd1, a20m), ppage(m1_s.target[31:12], a20m),
                     ppage(m1_s.maddr[31:12] + 20'd1, a20m), ppage(m1_s.maddr[31:12], a20m)};
            m1_at0 = fes_i386_pkg::attr({m1_pg[0], 12'd0}, attr_upper, ram_top);
            m1_at1 = fes_i386_pkg::attr({m1_s.maddr[11:5] == 7'h7f ? m1_pg[1] : m1_pg[0], 12'd0}, attr_upper, ram_top);
        end
    end
    // The flushes, and the ITLB's view of the edge a CR3 write, or a CR0
    // write that changes PG, commits on: F1 loads the next instruction's
    // block on that edge, so it looks it up with the new PG (pg_ifl) and
    // finds no entry (wb_tlbx). T1 holds the CR0 write's value by then.
    always_ff @(posedge clk) begin
        a20m_q <= a20m;
        attr_q <= attr_upper;
        top_q <= ram_top;
    end
    logic wb_sys_cr3, wb_sys_cr0, tsw_cr3;
    // A task switch's commit with a 386 TSS's CR3 (T2) under paging, when
    // it is not CR3, loads it (see Task switches).
    assign tsw_cr3 = wb_s.uop.tcom && tr_ar[3] && cr0_pg && t2 != cr3;
    assign wb_sys_cr3 = wb_s.valid && (wb_s.uop.cls == fes_i386_pkg::UOP_SYSTEM && wb_s.uop.op == 5'(fes_i386_pkg::SYSOP_CR3)
                                       || tsw_cr3);
    assign wb_sys_cr0 = wb_s.valid && wb_s.uop.cls == fes_i386_pkg::UOP_SYSTEM && wb_s.uop.op == 5'(fes_i386_pkg::SYSOP_CR0);
    assign tlb_flush = reset || wb_commit && (wb_sys_cr3 || wb_sys_cr0 && t1[31] != cr0_pg) || a20m != a20m_q
                    || attr_upper != attr_q || ram_top != top_q;
    assign pg_ifl = wb_sys_cr0 ? t1[31] : cr0_pg;
    assign wb_tlbx = wb_sys_cr3 || wb_sys_cr0 && t1[31] != cr0_pg;

    assign dmem_addr = m1_s.maddr;
    assign dmem_read = m1_s.valid && reads_mem(m1_s) && !freeze && !halted && !wb_stop;
    // The load touches nothing in the L1D when it faults here, or when it
    // uses nothing it reads (nodata), so it never reads a device twice or
    // for nothing, and a probe never replays a delivery.
    logic dmem_fault, l1d_replay, l1d_pf, l1d_walked;
    logic [31:0] l1d_pf_lin;
    logic [2:0]  l1d_pf_err;
    logic [3:0][PA-12:0] l1d_pg;
    assign dmem_fault = m1_out.uop.ctl.fault != fes_i386_pkg::FAULT_NONE || m1_probe_bad || m1_s.nodata;

    // Stores older than the load that have not written when the port reads:
    // the store now in EX, which will be in WB when the load is in M2, and
    // the store now in WB, which writes on the edge the port reads and so
    // is missed (the retired store, rt_*, in M2). D keeps a load from
    // following a store directly (store_hazard), unless that store is a
    // st2 uop's (a MOVS element's), whose data is its own load: then the
    // store in M2 is older too, and in EX, beside the load in M2, it holds
    // its data (pipe_t ld). M1 takes each one's distance from the load's
    // address; M2 decodes it. Both are physical, as the L1D and DDR see
    // them, so a store and a load through two aliases of a byte (A20M, the
    // reset alias) meet. A store's byte is taken only if it writes RAM (ram_bytes,
    // worked out as the store is in EX, or in M2 for a st2 uop): one to
    // read-only RAM or a hole is dropped, and MMIO is the device's, so the
    // load reads the memory or the device. An access that crosses a 1 MiB
    // boundary under A20M, or into the reset alias, translates every byte
    // independently so the bytes after the wrap still match.
    // A store's bytes that write RAM, from its pages (pg0 its own, pg1 the
    // next, which a store into the page's last line runs into).
    function automatic logic [3:0] ram_bytes(input logic [31:0] a, input logic [PA-12:0] pg0, input logic [PA-12:0] pg1,
                                             input logic [23:0][1:0] upper, input logic [6:0] top);
        fes_i386_pkg::attr_e at0, at1;
        at0 = fes_i386_pkg::attr({pg0, 12'd0}, upper, top);
        at1 = fes_i386_pkg::attr({a[11:5] == 7'h7f ? pg1 : pg0, 12'd0}, upper, top);
        for (int k = 0; k < 4; k++)
            ram_bytes[k] = (6'(a[4:0]) + 6'(k) > 6'd31 ? at1 : at0) == fes_i386_pkg::ATTR_RAM;
    endfunction
    logic        m2_ve, m2_vw, m2_vr;
    logic [3:0]  m2_re, m2_rw, m2_rr;  // the store's bytes that write RAM
    logic [3:0]  ex_ram, wb_ram;       // ... for the store in EX, and in WB
    logic [3:0][3:0] m2_hit_e, m2_hit_w, m2_hit_r;
    logic [3:0][3:0] hit_e, hit_w, hit_r;
    // With paging on, the load and the store meet when their linear
    // addresses do; two linear pages that map to one physical page are an
    // alias, which M1 cannot see: a load whose byte has a store's offset in
    // the page in another linear page goes to the walker as the oldest uop
    // (m1_alias), so nothing older is in flight to meet.
    function automatic logic same_page(input logic [31:0] l, input logic [31:0] st, input logic pg_in, input logic a20m_in);
        same_page = pg_in ? l[31:12] == st[31:12]
                          : fes_i386_pkg::phys({l[31:12], 12'd0}, a20m_in) == fes_i386_pkg::phys({st[31:12], 12'd0}, a20m_in);
    endfunction
    logic [3:0][3:0] al_e, al_w, al_r;
    logic [3:0]      m1_lb, ex_sb, wb_sb, m2_sb;  // the load's bytes, and each store's
    logic [31:0]     ld_a, st_ea, st_wa, st_ra;
    logic            pe, pw, pr;
    function automatic logic [3:0] lanes(input logic [3:0] bytes);
        lanes = {{2{bytes[2]}}, |bytes[2:1], 1'b1};
    endfunction
    always_comb begin
        for (int i = 0; i < 4; i++) begin
            for (int k = 0; k < 4; k++) begin
                ld_a = m1_s.maddr + 32'(i);
                st_ea = m2_s.target + 32'(k);
                st_wa = saddr(ex_s) + 32'(k);
                st_ra = saddr(wb_s) + 32'(k);
                pe = same_page(ld_a, st_ea, pg, a20m);
                pw = same_page(ld_a, st_wa, pg, a20m);
                pr = same_page(ld_a, st_ra, pg, a20m);
                hit_e[i][k] = ld_a[11:0] == st_ea[11:0] && pe;
                hit_w[i][k] = ld_a[11:0] == st_wa[11:0] && pw;
                hit_r[i][k] = ld_a[11:0] == st_ra[11:0] && pr;
                al_e[i][k] = pg && ld_a[11:0] == st_ea[11:0] && !pe;
                al_w[i][k] = pg && ld_a[11:0] == st_wa[11:0] && !pw;
                al_r[i][k] = pg && ld_a[11:0] == st_ra[11:0] && !pr;
            end
        end
        m1_lb = lanes(m1_s.uop.mem.bytes);
        m2_sb = m2_s.valid && m2_s.uop.st2 ? lanes(m2_s.uop.mem.bytes) : 4'd0;
        ex_sb = ex_s.valid && writes_mem(ex_s) ? lanes(ex_s.uop.mem.bytes) : 4'd0;
        wb_sb = wb_s.valid && writes_mem(wb_s) ? lanes(wb_s.uop.mem.bytes) : 4'd0;
        m1_alias = 1'b0;
        for (int i = 0; i < 4; i++)
            for (int k = 0; k < 4; k++)
                if (m1_lb[i] && (al_e[i][k] && m2_sb[k] || al_w[i][k] && ex_sb[k] || al_r[i][k] && wb_sb[k]))
                    m1_alias = 1'b1;
    end
    assign ex_ram = ram_bytes(saddr(ex_s), ex_s.uop.st2 ? ex_s.pg_t0 : ex_s.pg_a0, ex_s.uop.st2 ? ex_s.pg_t1 : ex_s.pg_a1,
                              attr_upper, ram_top);
    always_ff @(posedge clk) if (!freeze) begin
        m2_hit_e <= hit_e;
        m2_hit_w <= hit_w;
        m2_hit_r <= hit_r;
        m2_ve <= m2_s.valid && m2_s.uop.st2;
        m2_vw <= ex_s.valid && writes_mem(ex_s);
        m2_vr <= wb_s.valid && writes_mem(wb_s) && wb_s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE;
        m2_re <= ram_bytes(m2_s.target, l1d_pg[2], l1d_pg[3], attr_upper, ram_top);
        m2_rw <= ex_ram;
        m2_rr <= wb_ram;
        wb_ram <= ex_ram;
    end

    // ---- M2 -----------------------------------------------------------------------
    // The loaded bytes from the port, aligned to the access, with each byte an
    // older store writes taken from that store: a st2 store in EX first,
    // then the store in WB, then the retired one. EX takes the value through its bypass selects. M2 also
    // decodes EX's controls and prepares its operands (fes_i386_exctl).
    logic [31:0] rt_data;     // the store that retired on the last edge
    logic [3:0]  rt_bytes;
    logic        rt_valid;
    logic [3:0][7:0] ld_bytes;

    // The hit matrices compare each byte's translated physical address, so
    // A20M and the reset shadow are handled even when an access wraps.
    // long_*: the store writes byte k, to RAM.
    logic [3:0] long_e, long_w, long_r;  // the store writes byte k
    assign long_e = {{2{ex_s.uop.mem.bytes[2]}}, |ex_s.uop.mem.bytes[2:1], 1'b1} & m2_re;
    assign long_w = {{2{wb_s.uop.mem.bytes[2]}}, |wb_s.uop.mem.bytes[2:1], 1'b1} & m2_rw;
    assign long_r = {{2{rt_bytes[2]}}, |rt_bytes[2:1], 1'b1} & m2_rr;
    for (genvar i = 0; i < 4; i++) begin : g_ld
        logic [3:0] he, hw, hr;
        logic [7:0] port, from_e, from_w, from_r;
        for (genvar k = 0; k < 4; k++) begin : g_k
            assign he[k] = m2_ve && long_e[k] && m2_hit_e[i][k];
            assign hw[k] = m2_vw && long_w[k] && m2_hit_w[i][k];
            assign hr[k] = rt_valid && long_r[k] && m2_hit_r[i][k];
        end
        assign port = dmem_rdata[3'(m2_s.maddr[1:0]) + 3'(i)];
        assign from_e = ({8{he[0]}} & ex_s.ld[7:0]) | ({8{he[1]}} & ex_s.ld[15:8])
                      | ({8{he[2]}} & ex_s.ld[23:16]) | ({8{he[3]}} & ex_s.ld[31:24]);
        assign from_w = ({8{hw[0]}} & wb_s.result[7:0]) | ({8{hw[1]}} & wb_s.result[15:8])
                      | ({8{hw[2]}} & wb_s.result[23:16]) | ({8{hw[3]}} & wb_s.result[31:24]);
        assign from_r = ({8{hr[0]}} & rt_data[7:0]) | ({8{hr[1]}} & rt_data[15:8])
                      | ({8{hr[2]}} & rt_data[23:16]) | ({8{hr[3]}} & rt_data[31:24]);
        assign ld_bytes[i] = i >= m2_s.uop.mem.bytes ? {8{m2_s.ones}} : l1d_walked ? port : |he ? from_e : |hw ? from_w : |hr ? from_r : port;
    end

    pipe_t                m2_cap, m2_out;
    fes_i386_pkg::exctl_t m2_exc;
    logic [31:0]          m2_x, m2_y;
    // A replayed load changes nothing in EX (fes_i386_exctl's ok), as a
    // fault does.
    // A walk's #PF likewise, with CR2's address and the error code; every
    // uop takes its physical pages from the L1D (M1's, or the walker's).
    always_comb begin
        m2_cap = capture(m2_s, 3'd2, wb_s.result);
        // A dfl uop the walker would have walked for, not the oldest,
        // replays too: its #PF may come before its fault.
        if (l1d_replay && (m2_cap.uop.ctl.fault == fes_i386_pkg::FAULT_NONE || m2_cap.dfl)) begin
            m2_cap.uop.ctl.fault = fes_i386_pkg::FAULT_REPLAY;
            m2_cap.txr = l1d_walked;
        end
        if (l1d_pf && (m2_cap.uop.ctl.fault == fes_i386_pkg::FAULT_NONE || m2_cap.dfl)) begin
            m2_cap.uop.ctl.fault = fes_i386_pkg::FAULT_PF;
            m2_cap.pf_lin = l1d_pf_lin;
            m2_cap.pf_err = l1d_pf_err;
        end
        m2_cap.pg_a0 = l1d_pg[0];
        m2_cap.pg_a1 = l1d_pg[1];
        m2_cap.pg_t0 = l1d_pg[2];
        m2_cap.pg_t1 = l1d_pg[3];
    end
    fes_i386_exctl exctl (.s(m2_cap), .exc(m2_exc), .x(m2_x), .y(m2_y));
    always_comb begin
        m2_out = m2_cap;
        m2_out.exc = m2_exc;
        m2_out.x = m2_x;
        m2_out.y = m2_y;
        m2_out.ld = ld_bytes;
        // A HI uop's result is the half the multiply and divide unit kept
        // (fes_i386_muldiv), done before the HI leaves M2.
        if (m2_cap.uop.op == 5'd4 && (m2_cap.uop.cls == fes_i386_pkg::UOP_MUL || m2_cap.uop.cls == fes_i386_pkg::UOP_DIV))
            m2_out.result = md_hi;
        if (m2_cap.pbad && m2_cap.uop.ctl.fault == fes_i386_pkg::FAULT_NONE) m2_out.uop.ctl.fault = fes_i386_pkg::FAULT_SS0;
    end
    always_ff @(posedge clk) begin
        if (reset || wb_flush) begin
            m2_s.valid <= 1'b0;
            m2_load <= 1'b0;
            ex_s.valid <= 1'b0;
        end else if (!freeze) begin
            m2_s <= m1_out;
            m2_load <= m1_s.valid && (reads_mem(m1_s) || m1_tx) && m1_s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE;
            ex_s <= m2_out;
        end else if (md_last) begin
            // The multiply's or divide's result, and #DE for a divide whose
            // quotient overflows or whose divisor is zero, with the flags it
            // has changed.
            ex_s.result <= md_result;
            if (ex_s.exc.md_de && md_de) ex_s.uop.ctl.fault <= fes_i386_pkg::FAULT_DE;
        end
    end

    // ---- EX -----------------------------------------------------------------------
    // EFLAGS after every uop that has passed EX: no younger uop changes it,
    // and a flush only kills uops younger than WB, which have not. A shift
    // in WB still owes its flags (wb_flags): ex_flags lacks them for that
    // cycle, which no flag reader sees (flag_hazard), and takes them at its
    // end. A normal faulting uop changes no flags in EX; a divide error is
    // raised after the multiply/divide unit's flags reach this running copy.
    logic [17:0] ex_flags_ex, ex_flags_out, wb_flags, flags_keep;
    logic [31:0] ex_result;
    logic [31:0] md_result, md_hi;
    logic [11:0] md_flags;
    logic        md_last, md_de, md_load;
    assign md_load = ex_s.valid && ex_s.exc.md && ex_s.uop.op == 5'd5;  // MULDIV_LOAD
    fes_i386_muldiv muldiv (
        .clk, .go(md_busy), .u(ex_s.uop), .ar(ex_s.a), .byp_a(ex_s.exc.byp_a), .yr(ex_s.y), .wb(wb_s.result), .ld(ex_s.ld),
        .yw({ex_s.exc.yw32, ex_s.exc.yw16, ex_s.exc.yw_lo, ex_s.exc.yw_hi, ex_s.exc.yl}), .ld_en(md_load), .last(md_last), .result(md_result),
        .de(md_de), .flags(md_flags), .hi(md_hi)
    );
    logic        ex_taken, ex_br, ex_sh_out0, ex_sh_outn, ex_sh_cfw, ex_sh_wide, ex_def_co, ex_def_szap;
    logic [31:0] ex_ind_target, ex_ind_eip;
    pipe_t       ex_out;
    logic        ex_ibp, ex_dbi, ibp_sup, ibp_skip;

    logic [7:0] wb_r8;
    logic       wb_sh_cf, wb_sh_of;
    assign wb_r8 = wb_s.uop.dst.hi8 ? wb_s.result[15:8] : wb_s.result[7:0];
    fes_i386_shflags shflags (
        .c(wb_s.exc.sh), .hi8(wb_s.uop.dst.hi8), .result(wb_s.result), .out0(wb_s.sh_out0), .outn(wb_s.sh_outn),
        .cfw(wb_s.sh_cfw), .wide(wb_s.sh_wide), .cf(wb_sh_cf), .of(wb_sh_of)
    );
    always_comb begin
        wb_flags = wb_s.eflags;
        if (wb_s.def_co) begin
            wb_flags[0] = wb_sh_cf;
            wb_flags[11] = wb_sh_of;
        end
        if (wb_s.def_szap) begin
            wb_flags[2] = ~^wb_r8;
            wb_flags[4] = 1'b1;
            wb_flags[6] = wb_s.exc.size8 ? wb_r8 == 8'd0 : wb_s.exc.size16 ? wb_s.result[15:0] == 16'd0
                                                                            : wb_s.result == 32'd0;
            wb_flags[7] = wb_s.exc.size8 ? wb_r8[7] : wb_s.exc.size16 ? wb_s.result[15] : wb_s.result[31];
        end
    end
    assign flags_keep = wb_s.valid && (wb_s.def_co || wb_s.def_szap) ? wb_flags : ex_flags;

    // A multiply or divide works in EX over several cycles (fes_i386_muldiv),
    // from EX's operands, which stay put while D to WB freeze. md_busy is set
    // as the uop enters EX and holds until the unit's last cycle, which
    // writes the unit's result into the uop's record (EX takes it through
    // LEA's select) and #DE into its fault; the uop leaves on the cycle after,
    // with the unit's flags. A flush waiting in WB cuts the wait short: the
    // uop is on the wrong path. A 16- or 32-bit DIV's LOAD uop hands the unit
    // EDX while it is in EX.
    always_ff @(posedge clk) begin
        if (reset || wb_flush) md_busy <= 1'b0;
        else if (md_busy) md_busy <= !md_last && !wb_flushes && !int_take;
        else if (!freeze)
            md_busy <= m2_out.valid && m2_out.exc.md_wait && m2_out.uop.ctl.fault == fes_i386_pkg::FAULT_NONE;
    end

    // An operand whose producer is one stage ahead (exc.byp_a, xw_*, yw_*,
    // byp_c) comes from the WB result register beside EX's operand, and a
    // memory operand from the loaded value (xl, yl). An early
    // LEA's offset is its whole result, which EX's LEA select passes.
    fes_i386_ex ex (
        .u(ex_s.uop), .exc(ex_s.exc), .a(ex_s.a), .xr(ex_s.x), .yr(ex_s.y), .wb(wb_s.result), .ld(ex_s.ld),
        .ag_result(ex_s.result), .flags_in(ex_flags), .flags_keep, .md_flags, .cpl, .ts_krf, .result(ex_result),
        .flags_out(ex_flags_ex),
.taken(ex_taken), .br(ex_br), .ind_target(ex_ind_target), .ind_eip(ex_ind_eip), .sh_out0(ex_sh_out0), .sh_outn(ex_sh_outn), .sh_cfw(ex_sh_cfw), .sh_wide(ex_sh_wide),
        .def_co(ex_def_co), .def_szap(ex_def_szap)
    );
    // VM changes only at a far jump, which flushes everything after it: the
    // jump into V86 mode sets it, a delivery's out of it (xfer) clears it.
    // A fault before the jump, in the routine, leaves VM as the instruction
    // found it, so its own delivery is from V86 mode again, as Bochs's.
    always_comb begin
        ex_flags_out = ex_flags_ex;
        if (ex_s.uop.v86 && ex_s.uop.cls == fes_i386_pkg::UOP_BRANCH) ex_flags_out[17] = !ex_s.uop.xfer;
    end
    always_comb begin
        ex_out = ex_s;
        ex_out.result = ex_result;
        ex_out.eflags = ex_flags_out;
        // An I/O uop's port (b) and OUT's data or IN's merge (a) are used at
        // WB, from its record: one its producer a stage ahead has just
        // computed is taken from the WB register here, as EX's operands are.
        if (ex_s.uop.io != 2'd0) begin
            if (ex_s.pend_a && ex_s.dist_a == 3'd1) ex_out.a = wb_s.result;
            if (ex_s.pend_b && ex_s.dist_b == 3'd1) ex_out.b = wb_s.result;
        end
        // RET and JMP r/m: EX's adder gives the target.
        if (ex_s.exc.b_ind) begin
            ex_out.target = ex_ind_target;
            ex_out.target_eip = ex_ind_eip;
        end
        // A branch whose target is past CS's limit raises #GP(0) at the
        // branch, as Bochs's branch_near does: RET or JMP r/m's (b_ind)
        // here, a taken one by a displacement from M1's check (tchk). So
        // does a real-mode INT's probe whose vector's offset, in T1, is past
        // it: T1's load, two uops ahead, has retired. A fault M1 found
        // stands.
        if ((ex_s.exc.b_ind && ex_ind_eip > seg_limit[SEG_CS] || ex_s.tchk && ex_taken
             || ex_s.uop.probe == fes_i386_pkg::PROBE_INT && t1 > seg_limit[SEG_CS])
            && ex_s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE)
            ex_out.uop.ctl.fault = fes_i386_pkg::FAULT_GP0;
        // A faulting branch terminates the pipeline without redirecting to its
        // rejected target. This also covers faults already found in M1.
        ex_out.taken = ex_taken && ex_out.uop.ctl.fault == fes_i386_pkg::FAULT_NONE;
        // BOUND's #BR, after the taken select, which a compare never sets.
        if (ex_br && ex_s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE) ex_out.uop.ctl.fault = fes_i386_pkg::FAULT_BR;
        ex_out.sh_out0 = ex_sh_out0;
        ex_out.sh_outn = ex_sh_outn;
        ex_out.sh_cfw = ex_sh_cfw;
        ex_out.sh_wide = ex_sh_wide;
        ex_out.def_co = ex_def_co;
        ex_out.def_szap = ex_def_szap;
        // An enabled instruction breakpoint (see Breakpoints) on an
        // instruction's first uop (ex_ibp), while RF is clear (EX's EFLAGS,
        // RF after the instruction before) and not after a MOV SS or POP SS
        // (ibp_sup), faults ahead of anything its instruction found: the
        // 386's instruction breakpoint comes before the faults of fetching
        // and decoding the instruction. Suppressed, the uop, which M1 kept
        // from touching memory, replays, and AG then skips the breakpoint
        // once (ibp_skip).
        if (ex_ibp) begin
            ex_out.uop.ctl.fault = ex_dbi ? fes_i386_pkg::FAULT_DBI : fes_i386_pkg::FAULT_REPLAY;
            ex_out.taken = 1'b0;
            ex_out.def_co = 1'b0;
            ex_out.def_szap = 1'b0;
        end
        // A fetch check's replay stands over anything found since.
        if (ex_s.fbad) begin
            ex_out.uop.ctl.fault = fes_i386_pkg::FAULT_REPLAY;
            ex_out.taken = 1'b0;
        end
    end
    // A branch predicted taken (pt) that EX finds not taken redirects to the
    // next instruction, CS.base + the next EIP; one predicted taken that is
    // taken does not redirect.
    // A RET the return stack predicted, or an indirect near JMP or CALL the
    // BTB predicted, is always taken: it redirects to its target when the EIP
    // it popped or computed is not the one D gave the next instruction (peip).
    logic        ex_pt, ex_mis;
    logic [31:0] ex_fall;
    assign ex_pt = ex_s.pt && ex_out.uop.ctl.fault == fes_i386_pkg::FAULT_NONE;
    assign ex_mis = ex_out.taken ^ ex_pt || ex_pt && (ex_s.nret || ex_s.nind) && ex_ind_eip != ex_s.peip;
    assign ex_fall = seg_base[SEG_CS] + ex_s.eip_next;
    always_ff @(posedge clk) begin
        if (reset) begin
            ex_flags <= {init_eflags[17:2], 1'b1, init_eflags[0]};
        end else if (freeze) begin
            // EX's running copy waits with the uops.
        end else if (int_take || smc_go) begin
            // An interrupt, or a restart for self-modifying code, discards
            // the uops EX has run since the boundary.
            ex_flags <= eflags;
        end else if (ex_s.valid && !wb_flush) begin
            // An instruction breakpoint's uop (ex_ibp) runs nothing of its
            // instruction: EX's copy takes EFLAGS before it (flags_keep, an
            // older shift's flags in WB included).
            ex_flags <= ex_ibp ? flags_keep : ex_flags_out;
        end else begin
            ex_flags <= flags_keep;
        end
        if (!freeze) begin
            wb_rlin <= ex_pt && !ex_out.taken ? ex_fall : ex_out.target;
            wb_reip <= ex_pt && !ex_out.taken ? ex_s.eip_next : ex_out.target_eip;
            wb_fall <= ex_fall;
        end
        if (reset || wb_flush) begin
            wb_s.valid <= 1'b0;
            wb_smc <= 1'b0;
            wb_frp <= 1'b0;
            io_wait <= 1'b0;
        end else if (!freeze) begin
            wb_s <= ex_out;
            wb_frp <= ex_s.valid && ex_s.fbad && !smc_mark;
            // The next instruction's first uop after a store into the bytes
            // the front end holds restarts, whatever it was to do.
            if (smc_mark) begin
                wb_s.uop.ctl.fault <= fes_i386_pkg::FAULT_REPLAY;
                wb_s.taken <= 1'b0;
            end
            wb_smc <= smc_mark && ex_s.valid;
            io_wait <= ex_s.valid && ex_out.uop.io != 2'd0 && ex_out.uop.ctl.fault == fes_i386_pkg::FAULT_NONE && !int_next
                    && !smc_mark;
        end else if (io_wait && io_ack) begin
            io_wait <= 1'b0;
        end
    end

    // ---- WB -----------------------------------------------------------------------
    logic [4:0] wb_fault;
    // The segment register WB writes: the destination, or a second one with
    // the selector in T0 (a far pointer load) or c.
    logic        seg_w;
    logic [2:0]  seg_w_idx;
    logic [15:0] seg_w_sel;
    // A task switch's selector alone (SEGOP_TSEL) is not a load.
    logic        seg_tsel;
    assign seg_tsel = wb_s.uop.cls == fes_i386_pkg::UOP_SEGMENT && wb_s.uop.op == 5'(fes_i386_pkg::SEGOP_TSEL);
    assign seg_w = (wb_s.uop.dst.valid && wb_s.uop.dst.space == fes_i386_pkg::RS_SEG || wb_s.uop.seg2) && !seg_tsel;
    assign seg_w_idx = wb_s.uop.seg2 ? wb_s.uop.seg2_idx : wb_s.uop.dst.index[2:0];
    assign seg_w_sel = !wb_s.uop.seg2 ? wb_s.result[15:0] : wb_s.uop.seg2_t ? t0 : wb_s.c[15:0];
    assign wb_fault = wb_s.uop.ctl.fault;
    // The uop ends its instruction: its last, or INTO's JNO when taken.
    logic wb_eoi;
    assign wb_eoi = wb_s.uop.ctl.end_of_instruction || wb_s.taken && wb_s.uop.eoi_taken;

    // A store writes its bytes on the edge it retires: the result's low
    // bytes, moved to the address's place in its dword and the next.
    // The I/O access, while the uop that makes it is in WB and until the
    // machine completes it; the uop retires on the edge after, with IN's
    // data from io_data. The port is DX or imm8, OUT's data eAX (a) or, for
    // OUTS, the loaded value (its result). It goes to the machine once the
    // write buffer is empty, so every older store has reached memory or its
    // device first (a DMA buffer written before the OUT that starts the DMA,
    // a VGA store before a VGA register write).
    logic [31:0] io_data;
    logic        wb_empty;
    assign io_req = io_wait && wb_empty;
    assign io_write = wb_s.uop.io == 2'(fes_i386_pkg::IO_OUT);
    assign io_port = wb_s.uop.src2.valid ? wb_s.b[15:0] : wb_s.uop.imm[15:0];
    assign io_size = 2'(wb_s.uop.size);
    assign io_wdata = wb_s.uop.mem.kind == fes_i386_pkg::MEM_LOAD ? wb_s.result : wb_s.a;
    always_ff @(posedge clk) if (io_wait && io_ack) io_data <= io_rdata;
    // IN's data: merged into eAX's old value by size, or stored (INS).
    logic [31:0] wb_in, wb_sdata;
    assign wb_in = wb_s.uop.size == fes_i386_pkg::SIZE_8 ? {wb_s.a[31:8], io_data[7:0]}
                 : wb_s.uop.size == fes_i386_pkg::SIZE_16 ? {wb_s.a[31:16], io_data[15:0]} : io_data;
    assign wb_sdata = wb_s.uop.io == 2'(fes_i386_pkg::IO_IN) ? io_data : wb_s.result;

    logic wb_store;
    assign wb_store = wb_s.valid && !reset && !freeze && !halted && !int_take && wb_fault == fes_i386_pkg::FAULT_NONE && writes_mem(wb_s);
    logic [31:0] wb_saddr;
    assign wb_saddr = saddr(wb_s);
    assign dmem_write = wb_store;
    assign dmem_waddr = wb_saddr;
    always_comb begin
        dmem_wdata = 64'(wb_sdata) << {wb_saddr[1:0], 3'b000};
        dmem_wmask = (wb_s.uop.mem.bytes[2] ? 8'h0f : wb_s.uop.mem.bytes[1] ? 8'h03 : 8'h01) << wb_saddr[1:0];
    end
    assign trace_store = dmem_write;
    assign trace_store_addr = dmem_waddr;
    assign trace_store_data = dmem_wdata;
    assign trace_store_mask = dmem_wmask;

    // The store's physical line and the next one's, with their attributes,
    // registered as it enters WB; whether its lanes run into the next line.
    // wb_mp: the memory operand's physical address, which differs from the
    // store's for a st2 uop (the governor's MMIO charge).
    // From the store's pages (its own, and the next for a store into the
    // page's last line), so paging changes nothing here.
    logic [PA:0]          wb_p0, wb_p1, wb_mp;
    logic [PA-12:0]       wb_pg1, ex_spg0, ex_spg1;
    fes_i386_pkg::attr_e  wb_at0, wb_at1;
    logic                 wb_cross;
    logic [31:0]          ex_saddr;
    assign ex_saddr = saddr(ex_s);
    assign ex_spg0 = ex_s.uop.st2 ? ex_s.pg_t0 : ex_s.pg_a0;
    assign ex_spg1 = ex_s.uop.st2 ? ex_s.pg_t1 : ex_s.pg_a1;
    always_ff @(posedge clk) if (!freeze) begin
        wb_p0 <= {ex_spg0, ex_saddr[11:0]};
        wb_p1 <= ex_saddr[11:5] == 7'h7f ? {ex_spg1, 12'd0} : {ex_spg0, ex_saddr[11:5] + 7'd1, 5'd0};
        wb_pg1 <= ex_spg1;
        wb_mp <= {ex_s.pg_a0, ex_s.maddr[11:0]};
    end
    assign trace_store_pg0 = wb_p0[PA:12];
    assign trace_store_pg1 = wb_pg1;
    assign wb_at0 = fes_i386_pkg::attr(wb_p0, attr_upper, ram_top);
    assign wb_at1 = fes_i386_pkg::attr(wb_p1, attr_upper, ram_top);
    assign wb_cross = wb_saddr[4:2] == 3'd7 && dmem_wmask[7:4] != 4'd0;

    // The store in WB waits while the write buffer will not have room for it
    // (two entries) once the store committing on this edge has entered it
    // (fes_i386_biu): st_wait, one register, as the store enters WB or while
    // it waits.
    logic wb_room_next, st_next;
    assign st_next = !(reset || wb_flush) && (freeze ? wb_s.valid && writes_mem(wb_s) : ex_s.valid && writes_mem(ex_s));
    always_ff @(posedge clk) st_wait <= st_next && !wb_room_next;
    always_ff @(posedge clk) if (reset || !freeze) begin
        rt_valid <= wb_store;
        rt_data <= wb_sdata;
        rt_bytes <= wb_s.uop.mem.bytes;
    end

    // A uop that enters WB faulting is delivered. While a delivery is under
    // way (exc_busy: exc_active, unless the delivery's last uop retires now)
    // it is a nested fault (wb_nested), with EXT in its error code: a double
    // fault in its place when the delivery's exception and it are both
    // contributory (wb_df), and the CPU shuts down when the delivery is a
    // double fault's (wb_shut). A flush clears what enters WB, so a
    // delivery starting now needs no term. Once halted, nothing enters WB.
    logic ex_deliver, exc_busy, ex_shut;
    function automatic logic contributory(input logic [4:0] f);  // not fault_e: DeanoC/yosys#72
        contributory = f == 5'(fes_i386_pkg::FAULT_DE) || f == 5'(fes_i386_pkg::FAULT_GP0)
                    || f == 5'(fes_i386_pkg::FAULT_GP_SEL) || f == 5'(fes_i386_pkg::FAULT_GP_IDT)
                    || f == 5'(fes_i386_pkg::FAULT_SS0) || f == 5'(fes_i386_pkg::FAULT_SS_SEL)
                    || f == 5'(fes_i386_pkg::FAULT_NP_SEL) || f == 5'(fes_i386_pkg::FAULT_NP_IDT)
                    || f == 5'(fes_i386_pkg::FAULT_TS_SEL) || f == 5'(fes_i386_pkg::FAULT_TS_TR);
    endfunction
    assign ex_deliver = ex_out.uop.ctl.fault != fes_i386_pkg::FAULT_NONE
                     && ex_out.uop.ctl.fault != fes_i386_pkg::FAULT_UNIMPLEMENTED
                     && ex_out.uop.ctl.fault != fes_i386_pkg::FAULT_REPLAY;
    assign exc_busy = exc_active && !(wb_s.valid && wb_fault == fes_i386_pkg::FAULT_NONE && wb_eoi);
    assign ex_shut = exc_busy && exc_class == EXC_DF;
    always_ff @(posedge clk) begin
        if (reset || wb_flush) begin
            wb_flushes <= 1'b0;
            wb_redir <= 1'b0;
            wb_deliver <= 1'b0;
            wb_shut <= 1'b0;
        end else if (!freeze) begin
            wb_flushes <= ex_s.valid && (smc_mark || ex_mis || ex_out.uop.ctl.fault != fes_i386_pkg::FAULT_NONE
                                         || ex_s.uop.cls == fes_i386_pkg::UOP_SPECIAL && ex_s.uop.op == 5'd1);
            wb_redir <= ex_s.valid && !smc_mark && (ex_mis || ex_deliver && !ex_shut);
            wb_deliver <= ex_s.valid && !smc_mark && ex_deliver && !ex_shut;
            wb_shut <= ex_s.valid && !smc_mark && ex_deliver && ex_shut;
        end
        if (!freeze) begin
            wb_nested <= exc_busy || ex_out.uop.ice;
            wb_df <= exc_busy && (exc_class == EXC_CONTRIB && contributory(5'(ex_out.uop.ctl.fault))
                                  || exc_class == EXC_PF && (contributory(5'(ex_out.uop.ctl.fault))
                                                             || ex_out.uop.ctl.fault == fes_i386_pkg::FAULT_PF));
        end
    end

    // A string register's step at WB, wrapped by address size: ESI and EDI
    // by the access's bytes, down or up; ECX down by one.
    logic [31:0] wb_str_by;
    assign wb_str_by = wb_s.uop.str_down ? -{28'd0, wb_s.uop.mem.bytes} : {28'd0, wb_s.uop.mem.bytes};
    function automatic logic [31:0] str_wb_step(input logic [31:0] r, input logic [31:0] by, input logic w32);
        str_wb_step = w32 ? r + by : {r[31:16], r[15:0] + by[15:0]};
    endfunction

    // ---- Interrupts ---------------------------------------------------------------
    // INTR and NMI are taken at an instruction boundary: on the edge an
    // instruction's last uop retires, a delivery's included, or a REP
    // string element's last uop (str_cx), or while the CPU is in HLT. NMI
    // comes first, unless one is being handled (blocked
    // until an IRET starts: iret_start); INTR if IF is set after the
    // instruction. Neither is taken after MOV SS or POP SS, unless that one
    // follows another, nor after an STI that set IF: the shadow, as Bochs
    // keeps it. int_take holds from that edge until the delivery starts. An
    // INTR first asks the machine for its vector (inta_req), D to WB frozen
    // until it answers. Then WB flushes, as for a fault, with nothing of the
    // uop in it retired, and DC takes the vector routine's entry with D's EIP
    // the next instruction's (int_go). Between a REP string's elements that
    // is the string's own, since WB moves EIP only as an instruction ends:
    // the elements done have stepped ESI, EDI and ECX, so IRET returns to
    // the string, which runs on from there. An NMI's vector is 2. In
    // protected mode the delivery goes through the IDT (dc_exc), its EFLAGS
    // image with RF set between a REP string's elements (int_rep), as
    // Bochs's REP sets it when an event stops one.
    // A debug trap (see Breakpoints) is taken at an instruction boundary
    // too, ahead of NMI and INTR, and is not held off by STI's shadow, only
    // by MOV SS's and POP SS's (sh_ss). From that edge (int_take) the CPU
    // takes two cycles to choose what it delivers (int_ph): it compares the
    // next instruction's linear address, CS.base + EIP once the edge has
    // written them, with the instruction breakpoints (int_cbp), then takes
    // #DB if a trap is pending or the next instruction hits an enabled
    // breakpoint with RF clear and outside a REP string, the 386 manual's
    // table 9-2 order (debug traps of this instruction, then debug faults of
    // the next, then NMI, then INTR), else NMI, else INTR, whose vector it
    // then asks the machine for. A #DB leaves NMI and INTR pending.
    logic       nmi_q, nmi_pend, nmi_edge, nmi_block, movss_sh, int_rep;
    logic [7:0] int_vec;
    logic       wb_commit, at_boundary, in_hlt, wb_ss_load, wb_sti, sh_ss, int_shadow, nmi_ok, int_if;
    logic       int_cnmi, int_cnmi_n, int_trap, int_bt;
    logic [3:0] int_cbp, int_b;
    logic [5:0] dbg_dr6;  // the #DB's DR6 bits: BT, BS, B3-B0
    logic       int_cbp_ok, int_cbp_hit;
    logic       iret_start;
    assign wb_commit = wb_s.valid && !halted && !freeze && !int_take && wb_fault == fes_i386_pkg::FAULT_NONE;
    // An ESC memory form's offset, the x87 data pointer's: 16 bits under a
    // 16-bit address size, zero-extended.
    logic [31:0] wb_fdp;
    assign wb_fdp = wb_s.uop.mem.addr32 ? wb_s.moff : {16'd0, wb_s.moff[15:0]};
    assign at_boundary = wb_commit && (wb_eoi || wb_s.uop.str_cx);
    assign in_hlt = hlt && !int_take;
    assign wb_ss_load = wb_s.uop.dst.valid && wb_s.uop.dst.space == fes_i386_pkg::RS_SEG
                     && wb_s.uop.dst.index[2:0] == 3'(SEG_SS) || wb_s.uop.shadow;
    assign wb_sti = wb_s.uop.cls == fes_i386_pkg::UOP_ALU && wb_s.uop.op == 5'd30 && wb_s.uop.imm[3:0] == 4'd4;
    assign sh_ss = wb_ss_load && !movss_sh;
    assign int_shadow = sh_ss || wb_sti && !eflags[9];
    assign nmi_edge = nmi && !nmi_q;
    // IRET starts when its first uop reaches WB as the oldest (iret0),
    // whether it commits or faults there; one that replays starts again.
    // A fetch fault in its place (the walk of its page, or CS's limit) is
    // not the IRET: D leaves iret0 clear on those, as the 386 faults the
    // fetch before IRET's microcode, and its CLRNMI, runs.
    // Every instruction before it has completed then, as on the 386, whose
    // CLRNMI (674) runs once the IRET starts.
    assign iret_start = wb_s.valid && wb_s.iret0 && !halted && !freeze && !int_take
                     && wb_fault != fes_i386_pkg::FAULT_REPLAY;
    assign nmi_ok = (nmi_pend || nmi_edge) && (!nmi_block || at_boundary && wb_s.uop.iret);
    assign int_if = at_boundary ? wb_flags[9] : eflags[9];

    // ---- ICEBP ------------------------------------------------------------------------
    // ICEBP (F1h, #1730) runs INT 1 through INT n's routines (fes_i386_decode),
    // each of its uops marked ice. The 386's ICEBP (microcode_notes.txt
    // 93C) goes to BREAKPOINT_CMN, which clears DR7.GD (94C) and enters
    // INTERRUPT_X, an exception's delivery, without the IOPL check of INT n
    // in V86 mode. So its gate is not checked against CPL (CHK_GATE), a
    // fault in its delivery has EXT set (wb_nested), as in Bochs's INT1
    // (BX_PRIVILEGED_SOFTWARE_INTERRUPT, EXT = 1), and its first uop (ice0)
    // clears GD as it reaches WB. It sets no DR6 bit. Its far jump is never
    // predicted, so what follows it decodes with GD clear. DR7 bit 12 sends
    // the 386's #DB, ICEBP's included, to an ICE (946-949); FES has none,
    // and ignores the bit.

    // ---- Debug traps ------------------------------------------------------------------
    // What the trap after an instruction reports, gathered as its uops
    // commit (Bochs's debug_trap): the data breakpoints its accesses matched
    // (dbg_b; dbg_en, an enabled one among them), single step (dbg_bs: TF
    // was set as the instruction began, ss_arm, latched at each boundary),
    // and the task switch's T bit (dbg_bt: the new TSS's, a 386 one's, at
    // its commit). A delivery's start (a fault's, a trap's or interrupt's,
    // and an INT's TF-clearing uop, dbg_nobs) drops single step, as
    // Bochs's interrupt() drops debug_trap, so neither an exception's
    // handler nor INT n's traps; a task switch's commit drops it too
    // (Bochs's task_switch), and the new task's TF steps after its first
    // instruction. At an edge MOV SS or POP SS shadows, the trap waits for
    // the next instruction's end, which reports both.
    logic       ss_arm, dbg_bs, dbg_bt, dbg_en, dbg_nobs, dbg_clr;
    logic [3:0] dbg_b;
    logic       b_bs, b_en, dbg_fire;
    logic [3:0] b_b;
    assign dbg_clr = wb_s.exc.f_clrit || wb_s.exc.f_clrpm;
    assign b_bs = dbg_bs || ss_arm && !dbg_nobs && !dbg_clr;
    assign b_en = dbg_en || wb_s.dbp_en;
    assign b_b = dbg_b | wb_s.dbp;
    assign dbg_fire = (b_bs || dbg_bt || b_en) && !sh_ss;
    always_ff @(posedge clk) begin
        if (reset || exc_take || int_go) begin
            ss_arm <= reset && init_eflags[8];
            dbg_bs <= 1'b0;
            dbg_bt <= 1'b0;
            dbg_en <= 1'b0;
            dbg_b <= 4'd0;
            dbg_nobs <= 1'b0;
        end else if (tsw_go) begin
            ss_arm <= 1'b0;
            dbg_bs <= 1'b0;
            dbg_bt <= tr_ar[3] && t5[0];
        end else if (at_boundary) begin
            ss_arm <= wb_flags[8];
            dbg_nobs <= 1'b0;
            {dbg_bs, dbg_en, dbg_b} <= sh_ss ? {b_bs, b_en, b_b} : '0;
            if (!sh_ss) dbg_bt <= 1'b0;
        end else if (wb_commit && dbg_clr) begin
            // An INT's delivery drops what a MOV SS or POP SS before it
            // carried, as Bochs's interrupt() drops debug_trap.
            dbg_bs <= 1'b0;
            dbg_en <= wb_s.dbp_en;
            dbg_b <= wb_s.dbp;
            dbg_nobs <= 1'b1;
        end else if (wb_commit) begin
            dbg_en <= b_en;
            dbg_b <= b_b;
        end
    end
    // The in-pipe instruction breakpoint's checks at EX (see EX): not on the
    // instruction after a shadowing MOV SS or POP SS (Bochs's
    // BX_INHIBIT_DEBUG), whose last uop may be in WB yet.
    assign ibp_sup = wb_s.valid && wb_eoi ? sh_ss : movss_sh;
    assign ex_ibp = ex_s.valid && ex_s.ibp_en;
    assign ex_dbi = ex_ibp && !ex_flags[16] && !ibp_sup;
    // A suppressed breakpoint's replay (not the fetch check's or
    // self-modifying code's, which refetch the instruction's bytes): the
    // instruction's next pass by AG matches nothing.
    always_ff @(posedge clk)
        if (reset) ibp_skip <= 1'b0;
        else if (rp_go && wb_s.ibp_en && !wb_frp && !wb_smc) ibp_skip <= 1'b1;
        else if (!freeze && !wb_flush && ag_s.valid && ag_s.fchk) ibp_skip <= 1'b0;

    // The board's BUSY# latch holds an ESC instruction or WAIT in D and
    // nothing retires behind it, so an interrupt is taken as it is in HLT:
    // the delivery pushes D's EIP, which is the held instruction's, and the
    // handler's write to port F0h clears the latch, after which the held
    // instruction runs (387 PRM Appendix F.2; slice 0's if1 and held-nmi
    // cases). Only the latch can hold for ever -- the unit's own work is a
    // few cycles -- so the wait is on the latch with the pipeline drained.
    logic x87_stalled;
    assign x87_stalled = x87_hold && trace_x87_latched && !int_take
                      && !ag_s.valid && !m1_s.valid && !m2_s.valid && !ex_s.valid && !wb_s.valid;
    assign int_next = at_boundary && (dbg_fire || !int_shadow && (nmi_ok || intr && int_if))
                   || (in_hlt || x87_stalled) && (nmi_ok || intr && int_if);
    assign int_cnmi_n = nmi_ok && (in_hlt || x87_stalled || !int_shadow);
    assign inta_req = int_wait;
    always_ff @(posedge clk) begin
        nmi_q <= nmi;
        if (reset) begin
            nmi_pend <= 1'b0;
            nmi_block <= 1'b0;
            movss_sh <= 1'b0;
            int_take <= 1'b0;
            int_nmi <= 1'b0;
            int_wait <= 1'b0;
            int_dbg <= 1'b0;
            int_ph <= 2'd0;
        end else begin
            if (at_boundary) movss_sh <= sh_ss;
            // The 386 clears the NMI block when IRET starts, before it checks
            // a nested task's back link; a faulting return still unblocks it.
            if (iret_start) nmi_block <= 1'b0;
            // An edge stays pending until an NMI is taken; one that comes
            // while another is pending, or as it is taken, is that one. One
            // that comes while the CPU chooses is another; a #DB chosen in
            // its place leaves the NMI pending.
            if (int_next && int_cnmi_n) nmi_pend <= 1'b0;
            else if (nmi_edge || int_take && int_ph == 2'd1 && (int_trap || int_cbp_hit) && int_cnmi) nmi_pend <= 1'b1;
            if (int_next) begin
                int_take <= 1'b1;
                int_ph <= 2'd0;
                int_trap <= at_boundary && dbg_fire;
                int_bt <= at_boundary && dbg_bt;
                int_cnmi <= int_cnmi_n;
                int_rep <= at_boundary && !wb_eoi;
                dbg_dr6 <= at_boundary ? {dbg_bt, b_bs, b_b} : 6'd0;
            end else if (int_take && int_ph == 2'd0) begin
                int_ph <= 2'd1;
                int_cbp <= ibp_match(cs_eip, dr, bp_any, bp_x, bp_m);
            end else if (int_take && int_ph == 2'd1) begin
                int_ph <= 2'd2;
                int_dbg <= int_trap || int_cbp_hit;
                int_nmi <= !(int_trap || int_cbp_hit) && int_cnmi;
                int_wait <= !(int_trap || int_cbp_hit) && !int_cnmi;
                if (!(int_trap || int_cbp_hit) && int_cnmi) nmi_block <= 1'b1;
                if (int_cbp_ok) dbg_dr6[3:0] <= dbg_dr6[3:0] | int_cbp;
            end else if (int_go) begin
                int_take <= 1'b0;
            end
            if (int_wait && inta_ack) begin
                int_wait <= 1'b0;
                int_vec <= inta_vector;
            end
        end
    end
    // The next instruction's breakpoints count unless RF is set, the edge is
    // between a REP string's elements (where Bochs's REP sets RF) or the
    // trap is a task switch's T bit's, which Bochs takes before it compares.
    assign int_cbp_ok = !eflags[16] && !int_rep && !int_bt;
    assign int_cbp_hit = int_cbp_ok && (int_cbp & bp_en) != 4'd0;

    // ---- The speed governor ---------------------------------------------------------
    // It charges what WB retires (see fes_i386_governor): each instruction's
    // or REP element's end (at_boundary), with WB's taken branch other than
    // a far jump, and each committed uop's memory bus cycles: a load or
    // store one, a read-modify-write two, and a st2 store one more. A load
    // whose data nothing uses (nodata: a probe) reads nothing. Its ISA bus
    // time: the uop's I/O access, and which of its memory accesses are MMIO,
    // the operand's at maddr (wb_mp) and a st2 store's at target (wb_p0),
    // with the 16-bit halves each touches.
    logic [1:0] gov_accesses, gov_mmio;
    logic       gov_mmio_st2;
    assign gov_accesses = !wb_commit || wb_s.nodata ? 2'd0
                        : 2'(wb_s.uop.mem.kind == fes_i386_pkg::MEM_RMW) + 2'(wb_s.uop.mem.kind != fes_i386_pkg::MEM_NONE)
                          + 2'(wb_s.uop.st2);
    assign gov_mmio = !wb_commit || wb_s.nodata || fes_i386_pkg::attr(wb_mp, attr_upper, ram_top) != fes_i386_pkg::ATTR_MMIO
                    ? 2'd0
                    : 2'(wb_s.uop.mem.kind == fes_i386_pkg::MEM_RMW) + 2'(wb_s.uop.mem.kind != fes_i386_pkg::MEM_NONE);
    assign gov_mmio_st2 = wb_commit && !wb_s.nodata && wb_s.uop.st2 && wb_at0 == fes_i386_pkg::ATTR_MMIO;
    function automatic logic [2:0] halves(input logic a0, input logic [3:0] bytes);
        halves = 3'((4'(a0) + bytes + 4'd1) >> 1);
    endfunction
    fes_i386_governor #(.GOV_N(GOV_N), .GOV_D(GOV_D), .REFERENCE_DIAGNOSTIC(GOV_REFERENCE_DIAGNOSTIC)) governor (
        .clk, .reset, .preset(gov_preset), .frequency(gov_frequency), .turbo(gov_turbo),
        .boundary(at_boundary), .eoi(wb_eoi), .element(wb_s.uop.str_cx), .taken(wb_s.taken && !wb_s.uop.seg2),
        .gov(wb_s.gov), .ilen(wb_s.ilen), .redirect(wb_s.taken && wb_s.uop.rep_stop == 2'd0),
        .abandon(exc_take || int_go || tsw_go), .replay(rp_go),
        .accesses(gov_accesses), .dword(wb_s.uop.mem.bytes[2] || wb_s.uop.mem.bytes[3]),
        .io(wb_commit && wb_s.uop.io != 2'd0), .io_port, .io_size,
        .mmio(gov_mmio), .mmio_halves(halves(wb_s.maddr[0], wb_s.uop.mem.bytes)),
        .mmio_st2(gov_mmio_st2), .mmio_st2_halves(halves(wb_s.target[0], wb_s.uop.mem.bytes)),
        .hold(gov_hold), .debt_clocks(trace_gov_debt), .charge(trace_gov_charge)
    );

    // trace_vector: the delivered fault's or interrupt's vector; trace_error:
    // the delivered fault's error code.
    assign tsw_go = wb_commit && wb_s.uop.tcom;
    always_ff @(posedge clk) begin
        exc_inject <= !reset && (exc_take || int_go || tsw_go);
        tsw_inj <= tsw_go;
        // From a task switch's commit to its last uop, RF keeps the new
        // task's (ts_krf; fes_i386_ex), as Bochs loads it with EFLAGS.
        if (reset || exc_take || int_go || wb_commit && wb_eoi) ts_krf <= 1'b0;
        else if (tsw_go) ts_krf <= 1'b1;
    end
    assign trace_vector = exc_vec;
    assign trace_error = exc_err;
    function automatic logic [7:0] fault_vector(input logic [4:0] f);  // not fault_e: DeanoC/yosys#72
        case (f)
            5'(fes_i386_pkg::FAULT_UD): fault_vector = 8'd6;
            5'(fes_i386_pkg::FAULT_GP0), 5'(fes_i386_pkg::FAULT_GP_SEL), 5'(fes_i386_pkg::FAULT_GP_IDT): fault_vector = 8'd13;
            5'(fes_i386_pkg::FAULT_NM): fault_vector = 8'd7;
            5'(fes_i386_pkg::FAULT_DE): fault_vector = 8'd0;
            5'(fes_i386_pkg::FAULT_BR): fault_vector = 8'd5;
            5'(fes_i386_pkg::FAULT_NP_SEL), 5'(fes_i386_pkg::FAULT_NP_IDT): fault_vector = 8'd11;
            5'(fes_i386_pkg::FAULT_TS_SEL), 5'(fes_i386_pkg::FAULT_TS_TR): fault_vector = 8'd10;
            5'(fes_i386_pkg::FAULT_PF): fault_vector = 8'd14;
            5'(fes_i386_pkg::FAULT_DB), 5'(fes_i386_pkg::FAULT_DBI): fault_vector = 8'd1;
            default: fault_vector = 8'd12;  // FAULT_SS0, FAULT_SS_SEL
        endcase
    endfunction
    // The vector a delivery's gate was read for, kept from its first read
    // for the gate's checks' error code (vector * 8 + 2) and the vector of a
    // delivery that stops as not built.
    logic [7:0] idt_vec, wb_idt_vec;
    assign wb_idt_vec = wb_s.uop.desc == 4'(fes_i386_pkg::DESC_IDT_LO) ? wb_s.moff[10:3] : idt_vec;
    always_ff @(posedge clk)
        if (wb_s.valid && !freeze && !int_take && wb_s.uop.desc == 4'(fes_i386_pkg::DESC_IDT_LO)) idt_vec <= wb_s.moff[10:3];
    // A fault's error code, which a protected-mode delivery pushes for #DF,
    // #TS, #NP, #SS, #GP and #PF: a selector's, the IDT entry's, a #PF's
    // (P, W/R, U/S), or 0; EXT (bit 0) is set for a fault in a delivery
    // (wb_nested), but for a #PF's, and a double fault's is 0.
    logic [15:0] wb_err;
    logic [7:0]  wb_vec;
    always_comb begin
        case (wb_fault)
            5'(fes_i386_pkg::FAULT_GP_SEL), 5'(fes_i386_pkg::FAULT_NP_SEL), 5'(fes_i386_pkg::FAULT_SS_SEL),
            5'(fes_i386_pkg::FAULT_TS_SEL):
                wb_err = {t0[15:2], 2'b00};
            5'(fes_i386_pkg::FAULT_TS_TR): wb_err = {tr_sel[15:2], 2'b00};
            5'(fes_i386_pkg::FAULT_GP_IDT), 5'(fes_i386_pkg::FAULT_NP_IDT): wb_err = {5'd0, wb_idt_vec, 3'b010};
            5'(fes_i386_pkg::FAULT_PF): wb_err = {13'd0, wb_s.pf_err};
            default: wb_err = 16'd0;
        endcase
        if (wb_fault != 5'(fes_i386_pkg::FAULT_PF)) wb_err[0] = wb_nested;
        wb_vec = fault_vector(wb_fault);
    end
    // The exceptions a protected-mode delivery pushes an error code for.
    function automatic logic pushes_error(input logic [7:0] v);
        pushes_error = v == 8'd8 || v == 8'd10 || v == 8'd11 || v == 8'd12 || v == 8'd13 || v == 8'd14;
    endfunction
    // SS can take INT's probe: a writable, expand-up 16-bit stack under the
    // real-mode limit FFFFh (the probe's wrap rule), or a limit past 10000h,
    // where no slot of a 16-bit stack can fault.
    function automatic logic ss_rm(input logic [31:0] limit, input logic [15:0] ar);
        ss_rm = limit == 32'h0000_ffff && ar[7] && ar[4] && !ar[3] && !ar[2] && ar[1] && !ar[14];
    endfunction
    function automatic logic ss_big(input logic [31:0] limit, input logic [15:0] ar);
        ss_big = limit[31:16] != 16'd0 && ar[7] && ar[4] && !ar[3] && !ar[2] && ar[1] && !ar[14];
    endfunction
    // A real-mode segment load's new access rights: P and S set, the rest
    // kept, as Bochs's load_seg_reg; for CS the 386's real-mode values,
    // limit FFFFh and access rights 93h (docs/i386-cpu-design.md,
    // "Compatibility contract").
    // A protected-mode CS load's CPL, which its selector's RPL takes: the
    // CPL a transfer to the same privilege keeps.
    logic [1:0]  wb_cpl;
    assign wb_cpl = cpl;
    // In V86 mode, or for a V86 return's loads (uop v86), every such load
    // gives the segment limit FFFFh and access rights F3h (DPL 3, writable
    // data, accessed; G and D/B clear), as Bochs's load_seg_reg and
    // init_v8086_mode, CS too (seg_v86).
    logic [15:0] rm_ar;
    logic [31:0] seg_w_limit;
    logic [15:0] seg_w_ar;
    logic        seg_v86, seg_fixed;
    assign seg_v86 = eflags[17] || wb_s.uop.v86;
    assign seg_fixed = seg_w_idx == 3'(SEG_CS) || seg_v86;
    assign rm_ar = seg_ar[seg_w_idx] | 16'h0090;
    assign seg_w_limit = wb_s.uop.seg2_pm ? ds_limit : seg_fixed ? 32'h0000_ffff : seg_limit[seg_w_idx];
    assign seg_w_ar = wb_s.uop.seg2_pm ? ds_ar : seg_v86 ? 16'h00f3 : seg_w_idx == 3'(SEG_CS) ? 16'h0093 : rm_ar;
    always_ff @(posedge clk) begin
        trace_retire <= 1'b0;
        trace_exception <= 1'b0;
        if (reset) begin
            gpr <= init_gpr;
            eflags <= {init_eflags[17:2], 1'b1, init_eflags[0]};
            eip <= init_eip;
            cpl <= !init_cr0[0] ? 2'd0 : init_eflags[17] ? 2'd3 : init_sel[SEG_CS][1:0];
            cr0_pe <= init_cr0[0];
            cr0_mp <= init_cr0[1];
            cr0_em <= init_cr0[2];
            cr0_ts <= init_cr0[3];
            cr0_et <= init_cr0[4];
            cr0_pg <= init_cr0[31];
            cr2 <= init_cr2;
            cr3 <= init_cr3;
            dr <= init_dr;
            trn <= '0;
            {dr6_hi, dr6_lo} <= {init_dr6[15:12], init_dr6[3:0]};
            dr7 <= init_dr7 | 32'h0000_0400;
            fpu_ip <= 32'd0;
            fpu_cs <= 16'd0;
            fpu_dp <= 32'd0;
            fpu_ds <= 16'd0;
            fpu_lip <= 32'd0;
            fpu_ldp <= 32'd0;
            gdtr_base <= init_gdtr_base;
            gdtr_limit <= init_gdtr_limit;
            gdt_lim7 <= init_gdtr_limit - 16'd7;
            gdt_tiny7 <= init_gdtr_limit < 16'd7;
            idtr_base <= init_idtr_base;
            idtr_limit <= init_idtr_limit;
            idt_lim3 <= init_idtr_limit - 16'd3;
            idt_tiny3 <= init_idtr_limit < 16'd3;
            seg_sel <= init_sel;
            seg_base <= init_base;
            seg_limit <= init_limit;
            seg_ar <= init_ar;
            for (int k = 0; k < 6; k++) seg_hi1[k] <= init_base[k][31:16] + 16'd1;
            cs_fl <= fetch_lim(init_limit[SEG_CS]);
            seg_ss_rm <= ss_rm(init_limit[SEG_SS], init_ar[SEG_SS]);
            seg_ss_big <= ss_big(init_limit[SEG_SS], init_ar[SEG_SS]);
            for (int k = 0; k < 6; k++) begin
                seg_lim[k] <= init_chk[k].lim;
                seg_tiny[k] <= init_chk[k].tiny;
                seg_low[k] <= init_chk[k].low;
                seg_expd[k] <= init_chk[k].expd;
                seg_rbad[k] <= init_chk[k].rbad;
                seg_wbad[k] <= init_chk[k].wbad;
            end
            ldtr_sel <= init_ldtr_sel;
            ldtr_base <= init_ldtr_base;
            ldtr_limit <= init_ldtr_limit;
            ldtr_ar <= init_ldtr_ar;
            ldtr_valid <= init_ldtr_valid;
            ldt_lim7 <= init_ldtr_limit - 32'd7;
            ldt_tiny7 <= init_ldtr_limit < 32'd7;
            idt_lim7 <= init_idtr_limit - 16'd7;
            idt_tiny7 <= init_idtr_limit < 16'd7;
            tr_sel <= init_tr_sel;
            tr_base <= init_tr_base;
            tr_limit <= init_tr_limit;
            tr_ar <= init_tr_ar;
            {tss_lim_sp, tss_tiny_sp, tss_lim_bm, tss_tiny_bm, tss_iomap} <= tss_chk(init_tr_limit, init_tr_ar);
            hlt <= 1'b0;
            halted <= 1'b0;
            shutdown <= 1'b0;
            trace_unimplemented <= 1'b0;
            trace_unbuilt <= 4'd0;
            exc_active <= 1'b0;
            exc_vec <= 8'd0;
            exc_err <= 16'd0;
            exc_class <= EXC_BENIGN;
            exc_haserr <= 1'b0;
            del_rf <= 1'b0;
        end else if (int_go) begin
            // An INTR or NMI: benign, with no error code; its EFLAGS image's
            // RF is EFLAGS', or set between a REP string's elements.
            exc_active <= 1'b1;
            exc_vec <= int_dbg ? 8'd1 : int_nmi ? 8'd2 : int_vec;
            exc_err <= 16'd0;
            exc_class <= EXC_BENIGN;
            exc_haserr <= 1'b0;
            del_rf <= eflags[16] || int_rep;
            hlt <= 1'b0;
            halted <= 1'b0;
            // A debug trap, or the next instruction's breakpoint: DR6 takes
            // its B, BS and BT bits on top of what it holds, which the 386
            // never clears (its microcode only ORs DR6: 93F, 7E0), and GD is
            // cleared for the handler (94C), as for every #DB.
            if (int_dbg) begin
                dr6_lo <= dr6_lo | dbg_dr6[3:0];
                dr6_hi[3:2] <= dr6_hi[3:2] | dbg_dr6[5:4];
                dr7[13] <= 1'b0;
            end
        end else if (wb_s.valid && !halted && !freeze && !int_take) begin
            // ICEBP (see ICEBP): its first uop clears DR7.GD as it reaches
            // WB, whether it commits or faults, as the 386 clears GD (94C)
            // before INTERRUPT_X reads the gate.
            if (wb_s.ice0 && wb_fault != fes_i386_pkg::FAULT_REPLAY) dr7[13] <= 1'b0;
            if (exc_take) begin
                // A fault, or one in a delivery in that delivery's place: a
                // double fault when both are contributory.
                exc_active <= 1'b1;
                exc_vec <= wb_df ? 8'd8 : wb_vec;
                exc_err <= wb_df ? 16'd0 : wb_err;
                exc_class <= wb_df ? EXC_DF : contributory(wb_fault) ? EXC_CONTRIB
                           : wb_fault == 5'(fes_i386_pkg::FAULT_PF) ? EXC_PF : EXC_BENIGN;
                exc_haserr <= cr0_pe && (wb_df || pushes_error(wb_vec));
                // Every fault's EFLAGS image has RF set (the 386's FAULT,
                // 893-899) but #DB's: the 386 reaches INTERRUPT_X from
                // BREAKPOINT_CMN without it, so a #DB's image has RF as it
                // is, which an RF-suppressed instruction's GD keeps set
                // (Bochs clears RF before the instruction runs).
                del_rf <= wb_fault == 5'(fes_i386_pkg::FAULT_DB) || wb_fault == 5'(fes_i386_pkg::FAULT_DBI) ? eflags[16] : 1'b1;
                // #DB from DR7.GD sets DR6.BD, an instruction breakpoint
                // DR6's B bits for the breakpoints it matched, on top of what
                // DR6 holds (the 386 never clears it: GD_HIT's 3A3 ORs BD in),
                // and either clears GD, so the handler can use the debug
                // registers (94C).
                if (wb_fault == 5'(fes_i386_pkg::FAULT_DB)) begin
                    dr6_hi[1] <= 1'b1;
                    dr7[13] <= 1'b0;
                end
                if (wb_fault == 5'(fes_i386_pkg::FAULT_DBI)) begin
                    dr6_lo <= dr6_lo | wb_s.ibp;
                    dr7[13] <= 1'b0;
                end
                // A #PF's linear address, before its delivery, as Bochs's
                // page_fault writes it (even when it becomes a double fault).
                if (wb_fault == 5'(fes_i386_pkg::FAULT_PF)) cr2 <= wb_s.pf_lin;
            end else if (wb_fault == fes_i386_pkg::FAULT_REPLAY) begin
                // A replay: nothing retires, and the front end restarts (rp_go).
            end else if (wb_shut) begin
                // A fault in a double fault's delivery: shutdown, which the
                // machine turns into a reset.
                halted <= 1'b1;
                shutdown <= 1'b1;
                if (wb_fault == 5'(fes_i386_pkg::FAULT_PF)) cr2 <= wb_s.pf_lin;
            end else if (wb_fault != fes_i386_pkg::FAULT_NONE) begin
                // Something not built (FAULT_UNIMPLEMENTED), and why.
                halted <= 1'b1;
                trace_unimplemented <= 1'b1;
                trace_unbuilt <= wb_s.uop.ctl.why;
                exc_vec <= 8'd0;
            end else begin
                trace_retire <= wb_eoi;
                trace_exception <= wb_eoi && exc_active;
                if (wb_eoi) exc_active <= 1'b0;
                eflags <= wb_flags;
                // EIP moves at an instruction's last uop, so a sequence that
                // faults part way leaves it at the instruction.
                if (wb_eoi || wb_s.uop.tcom) eip <= wb_s.taken ? wb_s.target_eip : wb_s.eip_next;
                // A stack operation's ESP, which a destination of ESP overrides;
                // RETF's step, at the stack's width. A near CALL's push whose
                // target is past CS's limit (cpast) leaves ESP as it was for
                // its jump's #GP(0).
                if (wb_s.uop.sp_write && !wb_s.cpast) gpr[4] <= wb_s.sp_new;
                if (wb_s.uop.sp_add)
                    gpr[4] <= ss32 ? gpr[4] + wb_s.sp_new : {gpr[4][31:16], gpr[4][15:0] + wb_s.sp_new[15:0]};
                if (wb_s.uop.dst.valid && wb_s.uop.dst.space == fes_i386_pkg::RS_GPR)
                    gpr[wb_s.uop.dst.index[2:0]] <= wb_s.uop.io == 2'(fes_i386_pkg::IO_IN) ? wb_in : wb_s.result;
                // A string element's steps of ESI, EDI and ECX (CX by
                // address size).
                if (wb_s.uop.str_si) gpr[6] <= str_wb_step(gpr[6], wb_str_by, wb_s.uop.mem.addr32);
                if (wb_s.uop.str_di) gpr[7] <= str_wb_step(gpr[7], wb_str_by, wb_s.uop.mem.addr32);
                if (wb_s.uop.str_cx) gpr[1] <= str_wb_step(gpr[1], 32'hffff_ffff, wb_s.uop.mem.addr32);
                // FLDENV's and FRSTOR's fields 3 to 6.
                if (x87_ld_env) begin
                    case (wb_s.x87_part[2:0])
                        3'd3: if (cr0_pe) fpu_ip <= wb_s.result;
                              else fpu_lip[15:0] <= wb_s.result[15:0];
                        3'd4: if (cr0_pe) fpu_cs <= wb_s.result[15:0];
                              else begin
                                  fpu_lip[31:16] <= x87_ld_hi;
                                  fpu_ip <= {x87_ld_hi, fpu_lip[15:0]};
                                  fpu_cs <= 16'd0;
                              end
                        3'd5: if (cr0_pe) fpu_dp <= wb_s.result;
                              else fpu_ldp[15:0] <= wb_s.result[15:0];
                        default: if (cr0_pe) fpu_ds <= wb_s.result[15:0];
                                 else begin
                                     fpu_ldp[31:16] <= x87_ld_hi;
                                     fpu_dp <= {x87_ld_hi, fpu_ldp[15:0]};
                                     fpu_ds <= 16'd0;
                                 end
                    endcase
                end
                // FINIT clears the x87 pointers with the words (387 PRM,
                // FINIT), and FNSAVE leaves the unit as FINIT does: the
                // unit says so in the cycle they commit, so the write below
                // for the next ESC, which is later, still wins.
                if (x87_clr_pointers) begin
                    fpu_ip <= 32'd0;
                    fpu_cs <= 16'd0;
                    fpu_lip <= 32'd0;
                    fpu_dp <= 32'd0;
                    fpu_ds <= 16'd0;
                    fpu_ldp <= 32'd0;
                end
                // An ESC instruction's last uop: the x87 instruction pointer,
                // and a memory form's data pointer ("x87 pointers").
                if (wb_s.uop.x87p != 2'd0) begin
                    fpu_ip <= wb_s.eip;
                    fpu_cs <= seg_sel[SEG_CS];
                    fpu_lip <= {12'd0, seg_sel[SEG_CS], 4'd0} + wb_s.eip;
                end
                if (wb_s.uop.x87p == 2'(fes_i386_pkg::X87P_IPDP)) begin
                    fpu_dp <= wb_fdp;
                    fpu_ds <= seg_sel[wb_s.uop.mem.seg];
                    fpu_ldp <= {12'd0, seg_sel[wb_s.uop.mem.seg], 4'd0} + wb_fdp;
                end
                // The system uops: CLTS, the CR0, CR2 and CR3 writes from T1,
                // LMSW's (which cannot clear PE), and GDTR's and IDTR's from T0
                // and T1.
                if (wb_s.uop.cls == fes_i386_pkg::UOP_SYSTEM) begin
                    case (wb_s.uop.op)
                        5'(fes_i386_pkg::SYSOP_CR0): begin
                            {cr0_pg, cr0_et, cr0_ts, cr0_em, cr0_mp, cr0_pe} <= {t1[31], t1[4:0]};
                            // Back to real mode, CS becomes a writable data
                            // segment (P, S, type 3), its DPL, limit, G and
                            // D/B kept, as Bochs's handleCpuModeChange makes it.
                            if (cr0_pe && !t1[0]) begin
                                seg_ar[SEG_CS] <= {seg_ar[SEG_CS][15:8], 1'b1, seg_ar[SEG_CS][6:5], 5'b10011};
                                seg_rbad[SEG_CS] <= 1'b0;
                                seg_wbad[SEG_CS] <= 1'b0;
                            end
                        end
                        5'(fes_i386_pkg::SYSOP_LMSW): begin
                            {cr0_ts, cr0_em, cr0_mp} <= t1[3:1];
                            cr0_pe <= cr0_pe || t1[0];
                        end
                        5'(fes_i386_pkg::SYSOP_CR2): cr2 <= t1;
                        5'(fes_i386_pkg::SYSOP_CR3): cr3 <= t1;
                        5'(fes_i386_pkg::SYSOP_GDTR): begin
                            gdtr_limit <= t0;
                            gdtr_base <= {wb_s.uop.size == fes_i386_pkg::SIZE_32 ? t1[31:24] : 8'd0, t1[23:0]};
                            gdt_lim7 <= t0 - 16'd7;
                            gdt_tiny7 <= t0 < 16'd7;
                        end
                        5'(fes_i386_pkg::SYSOP_IDTR): begin
                            idtr_limit <= t0;
                            idtr_base <= {wb_s.uop.size == fes_i386_pkg::SIZE_32 ? t1[31:24] : 8'd0, t1[23:0]};
                            idt_lim3 <= t0 - 16'd3;
                            idt_tiny3 <= t0 < 16'd3;
                            idt_lim7 <= t0 - 16'd7;
                            idt_tiny7 <= t0 < 16'd7;
                        end
                        // LLDT: a null selector leaves LDTR's cache and
                        // clears its valid bit, as Bochs does.
                        5'(fes_i386_pkg::SYSOP_LDTR): begin
                            ldtr_sel <= t0;
                            ldtr_valid <= !ds_null;
                            if (!ds_null) begin
                                ldtr_base <= ds_base;
                                ldtr_limit <= ds_limit;
                                ldtr_ar <= ds_sar;
                                ldt_lim7 <= ds_limit - 32'd7;
                                ldt_tiny7 <= ds_limit < 32'd7;
                            end
                        end
                        // LTR: TR from its descriptor, marked busy.
                        5'(fes_i386_pkg::SYSOP_TR): begin
                            tr_sel <= t0;
                            tr_base <= ds_base;
                            tr_limit <= ds_limit;
                            tr_ar <= ds_sar | 16'h0002;
                            {tss_lim_sp, tss_tiny_sp, tss_lim_bm, tss_tiny_bm, tss_iomap} <= tss_chk(ds_limit, ds_sar | 16'h0002);
                        end
                        // A delivery's gate (T1 its low dword, T3 its high):
                        // T0 its selector, T1 its offset, a 286 gate's 16 bits.
                        // A far CALL's call gate (imm[0]) is in T2 and T3, with
                        // its parameter count.
                        5'(fes_i386_pkg::SYSOP_GATE): begin
                            t0 <= wb_s.uop.imm[0] ? t2[31:16] : t1[31:16];
                            t1 <= {t3[11] ? t3[31:16] : 16'd0, wb_s.uop.imm[0] ? t2[15:0] : t1[15:0]};
                            gate32 <= t3[11];
                            gate_trap <= t3[8];
                            pcnt <= t3[4:0];
                        end
                        // MOV DRn, r32: DR6 takes bits 15-12 and 3-0, DR7
                        // keeps bit 10 set. MOV TRn, r32 (imm 8 + n, TR4-
                        // TR7): the whole register.
                        5'(fes_i386_pkg::SYSOP_DR): begin
                            if (wb_s.uop.imm[3]) trn[wb_s.uop.imm[1:0]] <= t1;
                            else
                                case (wb_s.uop.imm[2:0])
                                    3'd0, 3'd1, 3'd2, 3'd3: dr[wb_s.uop.imm[1:0]] <= t1;
                                    3'd4, 3'd6: {dr6_hi, dr6_lo} <= {t1[15:12], t1[3:0]};
                                    default: dr7 <= t1 | 32'h0000_0400;
                                endcase
                        end
                        // A task switch's (see Task switches): TR from the
                        // new TSS's descriptor, busy, as LTR's; LDTR's
                        // selector from T5, its cache not valid; the new
                        // task's LDT from its descriptor.
                        5'(fes_i386_pkg::SYSOP_TSTR): begin
                            tr_sel <= t0;
                            tr_base <= ds_base;
                            tr_limit <= ds_limit;
                            tr_ar <= ds_sar | 16'h0002;
                            {tss_lim_sp, tss_tiny_sp, tss_lim_bm, tss_tiny_bm, tss_iomap} <= tss_chk(ds_limit, ds_sar | 16'h0002);
                        end
                        5'(fes_i386_pkg::SYSOP_TSLDT): begin
                            ldtr_sel <= t5[15:0];
                            ldtr_valid <= 1'b0;
                        end
                        5'(fes_i386_pkg::SYSOP_TSLDTD): begin
                            ldtr_valid <= 1'b1;
                            ldtr_base <= ds_base;
                            ldtr_limit <= ds_limit;
                            ldtr_ar <= ds_sar;
                            ldt_lim7 <= ds_limit - 32'd7;
                            ldt_tiny7 <= ds_limit < 32'd7;
                        end
                        default: cr0_ts <= 1'b0;  // SYSOP_CLTS
                    endcase
                end
                if (wb_s.uop.dst.valid && wb_s.uop.dst.space == fes_i386_pkg::RS_TEMP
                    && wb_s.uop.cls != fes_i386_pkg::UOP_SYSTEM) begin
                    if (!wb_s.uop.dst.index[3]) t0 <= wb_s.result[15:0];
                    else
                        case (wb_s.uop.dst.index[2:0])
                            3'd0: t1 <= wb_s.result;
                            3'd1: t2 <= wb_s.result;
                            3'd2: t3 <= wb_s.result;
                            3'd3: t4 <= wb_s.result;
                            default: t5 <= wb_s.result;
                        endcase
                end
                if (seg_w) begin
                    // Protected mode: the segment from T0's descriptor (the
                    // staged ds_*), a CS selector's RPL 0 (CPL). Real mode: the
                    // base is selector * 16; the limit and type stay (unreal
                    // mode) with P and S set, but CS's are the 386's (rm_ar).
                    if (wb_s.uop.seg2_pm) begin
                        seg_sel[seg_w_idx] <= seg_w_idx == 3'(SEG_CS) ? {t0[15:2], wb_cpl} : t0;
                        seg_base[seg_w_idx] <= ds_base;
                        seg_hi1[seg_w_idx] <= ds_hi1;
                        // One target per statement: DeanoC/yosys#73.
                        seg_lim[seg_w_idx] <= ds_chk.lim;
                        seg_tiny[seg_w_idx] <= ds_chk.tiny;
                        seg_low[seg_w_idx] <= ds_chk.low;
                        seg_expd[seg_w_idx] <= ds_chk.expd;
                        seg_rbad[seg_w_idx] <= ds_chk.rbad;
                        seg_wbad[seg_w_idx] <= ds_chk.wbad;
                    end else begin
                        seg_sel[seg_w_idx] <= seg_w_sel;
                        seg_base[seg_w_idx] <= {12'd0, seg_w_sel, 4'd0};
                        seg_hi1[seg_w_idx] <= {11'd0, 5'(seg_w_sel[15:12]) + (* no_carry *) 5'd1};
                        if (seg_fixed) begin
                            // seg_chk of limit FFFFh and access rights 93h
                            // or F3h.
                            seg_lim[seg_w_idx] <= {32'h0000_fffc, 32'h0000_fffe, 32'h0000_ffff};
                            seg_tiny[seg_w_idx] <= 3'b000;
                            seg_low[seg_w_idx] <= 32'h0000_ffff;
                            seg_expd[seg_w_idx] <= 1'b0;
                            seg_rbad[seg_w_idx] <= 1'b0;
                            seg_wbad[seg_w_idx] <= 1'b0;
                        end else begin
                            seg_rbad[seg_w_idx] <= rm_ar[3] && !rm_ar[1];
                            seg_wbad[seg_w_idx] <= rm_ar[3] || !rm_ar[1];
                        end
                    end
                    seg_limit[seg_w_idx] <= seg_w_limit;
                    seg_ar[seg_w_idx] <= seg_w_ar;
                    if (seg_w_idx == 3'(SEG_CS)) begin
                        cs_fl <= wb_s.uop.seg2_pm ? fetch_lim(ds_limit) : fetch_lim(32'h0000_ffff);
                        if (wb_s.uop.seg2_pm) cpl <= wb_cpl;
                    end
                    // The jump into V86 mode: CPL 3 and ESP from T5, whole.
                    if (wb_s.uop.v86 && wb_s.uop.cls == fes_i386_pkg::UOP_BRANCH && !wb_s.uop.xfer) begin
                        cpl <= 2'd3;
                        gpr[4] <= t5;
                    end
                    if (seg_w_idx == 3'(SEG_SS)) begin
                        seg_ss_rm <= ss_rm(seg_w_limit, seg_w_ar);
                        seg_ss_big <= ss_big(seg_w_limit, seg_w_ar);
                    end
                end
                // A privilege transition (see "Privilege transitions"). The
                // CS check's uop holds the staged CS, and whether the
                // transfer changes privilege (xp): IRET's to an RPL above
                // CPL, which becomes the CPL; a delivery's to a
                // nonconforming CS below CPL, whose DPL does.
                if (wb_s.uop.hold) begin
                    hs_sel <= t0;
                    hs_base <= ds_base;
                    hs_limit <= ds_limit;
                    hs_ar <= ds_ar;
                    hs_hi1 <= ds_hi1;
                    hs_chk <= ds_chk;
                    hs_acc <= t3[15:8];
                    if (wb_s.uop.segchk == 5'(fes_i386_pkg::CHK_RET)) begin
                        xp <= ds_rpl != cpl;
                        hs_cpl <= ds_rpl;
                    end else if (wb_s.uop.segchk == 5'(fes_i386_pkg::CHK_TSCS)) begin
                        // A task switch's new CS: CPL its RPL, no stack.
                        xp <= 1'b0;
                        hs_cpl <= ds_rpl;
                    end else if (wb_s.uop.segchk == 5'(fes_i386_pkg::CHK_CALL)) begin
                        // A far CALL's descriptor: a code segment, held for
                        // the jump at CPL, or a call gate (cg), whose own CS
                        // is held next. Its pushes take the operand size
                        // until the gate's GATE uop gives the gate's.
                        xp <= 1'b0;
                        hs_cpl <= cpl;
                        cg <= !ds_ar[4];
                        gate32 <= wb_s.uop.size == fes_i386_pkg::SIZE_32;
                    end else begin
                        xp <= !ds_ar[2] && ds_ar[6:5] < cpl;
                        hs_cpl <= !ds_ar[2] && ds_ar[6:5] < cpl ? ds_ar[6:5] : cpl;
                    end
                end
                // Its far jump: CS from the hold, its RPL the new CPL; with
                // xp, SS from the staged descriptor and ESP from T5 plus imm
                // (by the new SS's width: a 16-bit one keeps ESP's high
                // half, as Bochs's SP = does), and on a return to an outer
                // privilege ES, DS, FS and GS nulled where their DPL is
                // below the new CPL and they are not conforming code
                // (validate_seg_regs): the selector 0 and every access
                // refused, the rest of the cache kept, as Bochs keeps it.
                if (wb_s.uop.xfer) begin
                    seg_sel[SEG_CS] <= {hs_sel[15:2], hs_cpl};
                    seg_base[SEG_CS] <= hs_base;
                    seg_hi1[SEG_CS] <= hs_hi1;
                    seg_lim[SEG_CS] <= hs_chk.lim;
                    seg_tiny[SEG_CS] <= hs_chk.tiny;
                    seg_low[SEG_CS] <= hs_chk.low;
                    seg_expd[SEG_CS] <= hs_chk.expd;
                    seg_rbad[SEG_CS] <= hs_chk.rbad;
                    seg_wbad[SEG_CS] <= hs_chk.wbad;
                    seg_limit[SEG_CS] <= hs_limit;
                    seg_ar[SEG_CS] <= hs_ar;
                    cs_fl <= fetch_lim(hs_limit);
                    cpl <= hs_cpl;
                    if (xp) begin
                        seg_sel[SEG_SS] <= t0;
                        seg_base[SEG_SS] <= ds_base;
                        seg_hi1[SEG_SS] <= ds_hi1;
                        seg_lim[SEG_SS] <= ds_chk.lim;
                        seg_tiny[SEG_SS] <= ds_chk.tiny;
                        seg_low[SEG_SS] <= ds_chk.low;
                        seg_expd[SEG_SS] <= ds_chk.expd;
                        seg_rbad[SEG_SS] <= ds_chk.rbad;
                        seg_wbad[SEG_SS] <= ds_chk.wbad;
                        seg_limit[SEG_SS] <= ds_limit;
                        seg_ar[SEG_SS] <= ds_ar;
                        seg_ss_rm <= ss_rm(ds_limit, ds_ar);
                        seg_ss_big <= ss_big(ds_limit, ds_ar);
                        gpr[4] <= ds_ar[14] ? t5 + wb_s.uop.imm : {gpr[4][31:16], t5[15:0] + wb_s.uop.imm[15:0]};
                        if (hs_cpl > cpl)
                            for (int k = 0; k < 6; k++)
                                if (k != SEG_CS && k != SEG_SS && seg_ar[k][6:5] < hs_cpl
                                    && !(seg_ar[k][7] && seg_ar[k][4] && seg_ar[k][3] && seg_ar[k][2])) begin
                                    seg_sel[k] <= 16'd0;
                                    seg_rbad[k] <= 1'b1;
                                    seg_wbad[k] <= 1'b1;
                                end
                        // A delivery out of V86 mode nulls ES, DS, FS and GS
                        // the same way (Bochs clears their valid bits).
                        if (wb_s.uop.v86)
                            for (int k = 0; k < 6; k++)
                                if (k != SEG_CS && k != SEG_SS) begin
                                    seg_sel[k] <= 16'd0;
                                    seg_rbad[k] <= 1'b1;
                                    seg_wbad[k] <= 1'b1;
                                end
                    end
                end
                // A task switch's selector alone, its cache kept and every
                // access refused until tsload loads it, as Bochs's
                // task_switch leaves the cache not valid.
                if (seg_tsel) begin
                    seg_sel[wb_s.uop.dst.index[2:0]] <= wb_s.result[15:0];
                    seg_rbad[wb_s.uop.dst.index[2:0]] <= 1'b1;
                    seg_wbad[wb_s.uop.dst.index[2:0]] <= 1'b1;
                end
                // The commit (see Task switches): CS's selector from T0, its
                // cache kept until tsload loads it; CPL 3 until the new
                // SS is loaded (tscpl), as Bochs's task_switch runs the
                // LDT's and SS's loads; CR0.TS; DR7's local enables
                // cleared (L0-L3, LE), as the 386's 7D7-7DE and Bochs's;
                // a 386 TSS's CR3 under paging, when it is not CR3 (the
                // 386's 77F-794, Bochs's: no flush for the same); and the
                // gate's size, the new TSS's, for a delivery's error code.
                if (wb_s.uop.tcom) begin
                    seg_sel[SEG_CS] <= t0;
                    cpl <= 2'd3;
                    cr0_ts <= 1'b1;
                    dr7 <= dr7 & 32'hffff_feaa;
                    gate32 <= tr_ar[3];
                    if (tsw_cr3) cr3 <= t2;
                end
                if (wb_s.uop.tscpl) cpl <= seg_sel[SEG_CS][1:0];
                if (wb_stop) begin
                    hlt <= 1'b1;
                    halted <= 1'b1;
                end
            end
        end
    end
    assign trace_halt = halted;

    // ---- Protected mode: a segment load's descriptor ---------------------------------
    // A protected-mode segment load's selector is in T0, its descriptor's
    // dwords in T2 and T3, a far jump's offset in T1 (fes_i386_ucode.toml).
    // Each cycle registers what the load writes and the checks it raises
    // from them (ds_*), at CPL 0: the uops that use them issue only once
    // those temporaries' writers have retired (t_rd), and no younger uop
    // writes one before they retire, so these registers hold the load's
    // descriptor when its check reaches M1 and its write reaches WB. A null
    // selector (index 0, TI 0) loads a null cache, base and limit 0 and
    // access rights 10h (S set, not present), as Bochs's load_null_selector.
    // The checks follow Bochs's load_seg_reg (data segments and SS) and
    // jump_protected with check_cs and branch_far (CS):
    //   data: none for null; a system descriptor or execute-only code,
    //         #GP(selector); data or non-conforming code with DPL below RPL,
    //         #GP(selector); not present, #NP(selector).
    //   SS:   null, #GP(0); RPL not 0, a system descriptor, code or read-only
    //         data, DPL not 0, #GP(selector); not present, #SS(selector).
    //   CS:   null, #GP(0); a system descriptor with DPL below CPL or RPL,
    //         #GP(selector), else an available TSS with TI=1 #GP(selector)
    //         and not present #NP(selector), a task gate not present
    //         #NP(selector) (each else a task switch, its tgo word's), a
    //         call gate not built, anything else #GP(selector); data,
    //         #GP(selector);
    //         non-conforming with DPL or RPL not 0, or conforming with DPL
    //         not 0, #GP(selector); not present, #NP(selector); an offset
    //         past the limit, #GP(0).
    //   CALL: a far CALL's (call_protected): a code segment as a far
    //         jump's, its offset checked apart (CHK_HOFF); a system
    //         descriptor with DPL below CPL or RPL, #GP(selector); a call
    //         gate not present, #NP(selector); a TSS or task gate as a far
    //         jump's; any other, #GP(selector).
    //   RET:  RETF's and IRET's CS (return_protected, iret_protected,
    //         check_cs against the RPL): null, #GP(0); system or data,
    //         #GP(selector); non-conforming with DPL not RPL, or conforming
    //         with DPL above RPL, #GP(selector); not present, #NP(selector);
    //         RPL above CPL is a return to an outer privilege (hold's xp);
    //         the offset is checked apart (CHK_HOFF).
    //   GATE: a delivery's gate in T3 (protected_mode_int): an interrupt,
    //         trap or task gate (a task switch: its tgo word's); anything
    //         else #GP, not present #NP, each with the IDT entry. The gate's
    //         DPL is never below CPL 0.
    //   INTCS: a delivery's or call gate's CS: null, #GP(0); system, data
    //         or DPL above CPL, #GP(selector); not present, #NP(selector);
    //         its offset (T1, from SYSOP_GATE) is checked apart (CHK_HOFF).
    //   LDT:  LLDT's: none for null; TI=1 or not an LDT, #GP(selector); not
    //         present, #NP(selector). TSS: LTR's: null, #GP(0); TI=1 or not
    //         an available TSS, #GP(selector); not present, #NP(selector).
    // A task switch's (see Task switches): TSW, the new TSS's limit below
    // 67h (a 286 TSS's 2Bh), #TS(selector), then the old one's below 5Fh
    // (29h), #TS(TR); TSGATE, a task gate's TSS: null, TI=1 or not an
    // available TSS #GP(selector), not present #NP(selector); TSRET, IRET's
    // back link: null, TI=1 or not a busy TSS #TS(selector), not present
    // #NP(selector); the new task's LDT (TSLDT: TI=1, not an LDT or not
    // present, #TS(selector)), SS (TSSS: null, a system descriptor, code or
    // read-only data, RPL or DPL not CS's RPL, #TS(selector), then not
    // present #SS(selector), the 386's order, TST_DES_SS, where Bochs tests
    // present before the DPL), CS (TSCS: null, not code, nonconforming with
    // DPL not RPL or conforming with DPL above RPL, #TS(selector); not
    // present #NP(selector)) and data segments (TSDATA: none for null; a
    // system descriptor or execute-only code, data or nonconforming code
    // with DPL below CPL or RPL, #TS(selector); not present, #NP(selector)).
    // And for LAR, LSL, VERR and VERW (Bochs's LAR_GvEw and its kin, at
    // CPL 0) whether the descriptor passes, ZF: not for a null selector or
    // one past its table (ds_oor); LAR takes code and data with DPL at
    // least RPL, conforming code at any, and LDTs, TSSs, call gates and
    // task gates with DPL at least RPL; LSL the same but no gates; VERR
    // readable code and data, DPL at least RPL unless conforming; VERW
    // writable data, DPL at least RPL.
    logic        dd_null, dd_p, dd_s, dd_code, dd_conf, dd_rw, dd_gate, dd_cgate;
    logic [1:0]  dd_dpl, dd_rpl;
    logic [3:0]  dd_type;
    logic [19:0] dd_lim20;
    logic [31:0] dd_limit, dd_base;
    logic [15:0] dd_ar;
    assign dd_null = t0[15:2] == 14'd0;
    assign dd_rpl = t0[1:0];
    assign dd_p = t3[15];
    assign dd_dpl = t3[14:13];
    assign dd_s = t3[12];
    assign dd_type = t3[11:8];
    assign dd_code = dd_type[3];
    assign dd_conf = dd_type[2];
    assign dd_rw = dd_type[1];
    assign dd_gate = dd_type == 4'd1 || dd_type == 4'd9 || dd_type == 4'd5 || dd_type == 4'd4 || dd_type == 4'd12;
    assign dd_cgate = dd_type == 4'd4 || dd_type == 4'd12;
    assign dd_lim20 = {t3[19:16], t2[15:0]};
    assign dd_limit = t3[23] ? {dd_lim20, 12'hfff} : {12'd0, dd_lim20};
    assign dd_base = {t3[31:24], t3[7:0], t2[31:16]};
    // The 386 has no L bit (descriptor bit 21): Bochs's cache drops it.
    assign dd_ar = {t3[23:22], 1'b0, t3[20], 4'd0, t3[15:9], 1'b1};
    logic        dd_cs_bad, dd_ret_bad, dd_igate, dd_lar, dd_lsl;
    // A code segment for a far jump or call, as check_cs(RPL, CPL); for a
    // return, as check_cs(0, RPL).
    assign dd_cs_bad = !dd_code || (dd_conf ? dd_dpl > cpl : dd_dpl != cpl || dd_rpl > cpl);
    assign dd_ret_bad = !dd_s || !dd_code || (dd_conf ? dd_dpl > dd_rpl : dd_dpl != dd_rpl);
    assign dd_igate = dd_type == 4'd6 || dd_type == 4'd7 || dd_type == 4'd14 || dd_type == 4'd15;
    assign dd_lar = dd_type == 4'd1 || dd_type == 4'd2 || dd_type == 4'd3 || dd_type == 4'd4 || dd_type == 4'd5
                 || dd_type == 4'd9 || dd_type == 4'd11 || dd_type == 4'd12;
    assign dd_lsl = dd_type == 4'd1 || dd_type == 4'd2 || dd_type == 4'd3 || dd_type == 4'd9 || dd_type == 4'd11;
    logic                   ds_lar_ok, ds_lsl_ok, ds_verr_ok, ds_verw_ok;
    // dd_priv: the descriptor's DPL is at least CPL and RPL, as a data
    // segment's, a gate's or LAR's kin's check wants it.
    logic                   dd_priv;
    assign dd_priv = dd_dpl >= dd_rpl && dd_dpl >= cpl;
    fes_i386_pkg::fault_e   ds_fault_data, ds_fault_ss, ds_fault_cs, ds_fault_gate, ds_fault_intcs, ds_fault_v86cs, ds_fault_call,
                            ds_fault_ret, ds_fault_ldt, ds_fault_tss, ds_fault_sgate, ds_fault_ssret, ds_fault_ssint,
                            ds_fault_hoff, ds_fault_tsw, ds_fault_tsgate, ds_fault_tsret, ds_fault_tsldt, ds_fault_tsss,
                            ds_fault_tscs, ds_fault_tsdata, ds_fault_tsold;
    // An available TSS's descriptor (types 1 and 9), a busy one's (3, 11).
    logic                   dd_atss, dd_btss;
    assign dd_atss = !dd_s && (dd_type == 4'd1 || dd_type == 4'd9);
    assign dd_btss = !dd_s && (dd_type == 4'd3 || dd_type == 4'd11);
    always_ff @(posedge clk) begin
        ds_null <= dd_null;
        ds_rpl <= dd_rpl;
        // A system descriptor's access rights as LDTR and TR keep them.
        ds_sar <= {t3[23:22], 1'b0, t3[20], 4'd0, t3[15:8]};
        ds_lar <= t3 & 32'h00ff_ff00;
        ds_lar_ok <= !dd_null && !t0_oor && (dd_s ? dd_code && dd_conf || dd_priv : dd_lar && dd_priv);
        ds_lsl_ok <= !dd_null && !t0_oor && (dd_s ? dd_code && dd_conf || dd_priv : dd_lsl && dd_priv);
        ds_verr_ok <= !dd_null && !t0_oor && dd_s && (dd_code ? dd_rw && (dd_conf || dd_priv) : dd_priv);
        ds_verw_ok <= !dd_null && !t0_oor && dd_s && !dd_code && dd_rw && dd_priv;
        ds_fault_gate <= dd_s || !(dd_igate || dd_type == 4'd5) ? fes_i386_pkg::FAULT_GP_IDT
                       : !dd_p ? fes_i386_pkg::FAULT_NP_IDT : fes_i386_pkg::FAULT_NONE;
        // A software interrupt's (INT n, INT3, INTO): its gate's DPL below
        // CPL is #GP with the IDT entry, before the present check.
        ds_fault_sgate <= dd_s || !(dd_igate || dd_type == 4'd5) || dd_dpl < cpl ? fes_i386_pkg::FAULT_GP_IDT
                        : !dd_p ? fes_i386_pkg::FAULT_NP_IDT : fes_i386_pkg::FAULT_NONE;
        ds_fault_intcs <= dd_null ? fes_i386_pkg::FAULT_GP0
                        : !dd_s || !dd_code || dd_dpl > cpl ? fes_i386_pkg::FAULT_GP_SEL
                        : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        // A delivery from V86 mode's CS: the same, then #GP(selector) for
        // conforming code or DPL 3, which would keep CPL 3 (Bochs's
        // same-privilege path in V86 mode).
        ds_fault_v86cs <= dd_null ? fes_i386_pkg::FAULT_GP0
                        : !dd_s || !dd_code || dd_dpl > cpl ? fes_i386_pkg::FAULT_GP_SEL
                        : !dd_p ? fes_i386_pkg::FAULT_NP_SEL
                        : dd_conf || dd_dpl == 2'd3 ? fes_i386_pkg::FAULT_GP_SEL : fes_i386_pkg::FAULT_NONE;
        // A far CALL's (call_protected): a system descriptor with DPL below
        // CPL or RPL, #GP(selector); a call gate not present, #NP(selector);
        // a TSS or task gate as a far JMP's; any other, #GP(selector).
        ds_fault_call <= dd_null ? fes_i386_pkg::FAULT_GP0
                       : !dd_s ? (!dd_priv ? fes_i386_pkg::FAULT_GP_SEL
                                  : dd_cgate || dd_type == 4'd5 ? (!dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE)
                                  : dd_atss ? (t0[2] ? fes_i386_pkg::FAULT_GP_SEL : !dd_p ? fes_i386_pkg::FAULT_NP_SEL
                                                                                     : fes_i386_pkg::FAULT_NONE)
                                  : fes_i386_pkg::FAULT_GP_SEL)
                       : dd_cs_bad ? fes_i386_pkg::FAULT_GP_SEL : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_ret <= dd_null ? fes_i386_pkg::FAULT_GP0 : dd_rpl < cpl || dd_ret_bad ? fes_i386_pkg::FAULT_GP_SEL
                      : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        // A privilege transition's new SS against the held CPL
        // (fetch_ss_descriptor): an outer IRET's, #GP; a delivery's, #TS,
        // null too; either not present, #SS. Then the offset against the
        // held CS's limit (branch_far, the gate's).
        ds_fault_ssret <= dd_null ? fes_i386_pkg::FAULT_GP0
                        : dd_rpl != hs_cpl || !dd_s || dd_code || !dd_rw || dd_dpl != hs_cpl ? fes_i386_pkg::FAULT_GP_SEL
                        : !dd_p ? fes_i386_pkg::FAULT_SS_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_ssint <= dd_null || dd_rpl != hs_cpl || !dd_s || dd_code || !dd_rw || dd_dpl != hs_cpl
                        ? fes_i386_pkg::FAULT_TS_SEL : !dd_p ? fes_i386_pkg::FAULT_SS_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_hoff <= t1 > hs_limit ? fes_i386_pkg::FAULT_GP0 : fes_i386_pkg::FAULT_NONE;
        ds_fault_ldt <= dd_null ? fes_i386_pkg::FAULT_NONE : t0[2] || dd_s || dd_type != 4'd2 ? fes_i386_pkg::FAULT_GP_SEL
                      : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_tss <= dd_null ? fes_i386_pkg::FAULT_GP0
                      : t0[2] || dd_s || dd_type != 4'd1 && dd_type != 4'd9 ? fes_i386_pkg::FAULT_GP_SEL
                      : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_tsold <= tr_limit < (tr_ar[3] ? 32'h5f : 32'h29) ? fes_i386_pkg::FAULT_TS_TR : fes_i386_pkg::FAULT_NONE;
        ds_fault_tsw <= dd_limit < (dd_type[3] ? 32'h67 : 32'h2b) ? fes_i386_pkg::FAULT_TS_SEL
                      : tr_limit < (tr_ar[3] ? 32'h5f : 32'h29) ? fes_i386_pkg::FAULT_TS_TR : fes_i386_pkg::FAULT_NONE;
        ds_fault_tsgate <= dd_null || t0[2] || !dd_atss ? fes_i386_pkg::FAULT_GP_SEL
                         : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_tsret <= dd_null || t0[2] || !dd_btss ? fes_i386_pkg::FAULT_TS_SEL
                        : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_tsldt <= dd_null ? fes_i386_pkg::FAULT_NONE
                        : t0[2] || dd_s || dd_type != 4'd2 || !dd_p ? fes_i386_pkg::FAULT_TS_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_tsss <= dd_null || !dd_s || dd_code || !dd_rw || dd_rpl != seg_sel[SEG_CS][1:0]
                         || dd_dpl != seg_sel[SEG_CS][1:0] ? fes_i386_pkg::FAULT_TS_SEL
                       : !dd_p ? fes_i386_pkg::FAULT_SS_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_tscs <= dd_null || !dd_s || !dd_code || (dd_conf ? dd_dpl > dd_rpl : dd_dpl != dd_rpl)
                       ? fes_i386_pkg::FAULT_TS_SEL : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_tsdata <= dd_null ? fes_i386_pkg::FAULT_NONE
                         : !dd_s || dd_code && !dd_rw || (!dd_code || !dd_conf) && !dd_priv ? fes_i386_pkg::FAULT_TS_SEL
                         : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_base <= dd_null ? 32'd0 : dd_base;
        ds_limit <= dd_null ? 32'd0 : dd_limit;
        ds_ar <= dd_null ? 16'h0010 : dd_ar;
        ds_hi1 <= (dd_null ? 16'd0 : dd_base[31:16]) + 16'd1;
        ds_chk <= fes_i386_pkg::seg_chk(dd_null ? 32'd0 : dd_limit, dd_null ? 16'h0010 : dd_ar);
        ds_fault_data <= dd_null ? fes_i386_pkg::FAULT_NONE
                       : !dd_s || dd_code && !dd_rw || (!dd_code || !dd_conf) && !dd_priv ? fes_i386_pkg::FAULT_GP_SEL
                       : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE;
        ds_fault_ss <= dd_null ? fes_i386_pkg::FAULT_GP0
                     : dd_rpl != cpl || !dd_s || dd_code || !dd_rw || dd_dpl != cpl ? fes_i386_pkg::FAULT_GP_SEL
                     : !dd_p ? fes_i386_pkg::FAULT_SS_SEL : fes_i386_pkg::FAULT_NONE;
        // A far JMP to an available TSS: DPL below CPL or RPL, then TI=1
        // (the 386's TST_DES_JGATE, then TST_SEL_TASKGT, ahead of AVAIL_TSS_NP's
        // #NP), #GP(selector); not present #NP(selector). To a task gate:
        // not present #NP(selector); through a call gate, not built.
        ds_fault_cs <= dd_null ? fes_i386_pkg::FAULT_GP0
                     : !dd_s ? (!dd_priv ? fes_i386_pkg::FAULT_GP_SEL
                                : dd_atss ? (t0[2] ? fes_i386_pkg::FAULT_GP_SEL : !dd_p ? fes_i386_pkg::FAULT_NP_SEL
                                                                                   : fes_i386_pkg::FAULT_NONE)
                                : dd_type == 4'd5 ? (!dd_p ? fes_i386_pkg::FAULT_NP_SEL : fes_i386_pkg::FAULT_NONE)
                                : dd_cgate ? fes_i386_pkg::FAULT_UNIMPLEMENTED : fes_i386_pkg::FAULT_GP_SEL)
                     : dd_cs_bad ? fes_i386_pkg::FAULT_GP_SEL
                     : !dd_p ? fes_i386_pkg::FAULT_NP_SEL : t1 > dd_limit ? fes_i386_pkg::FAULT_GP0 : fes_i386_pkg::FAULT_NONE;
    end

    // Serial issue after a replay for an uncached load, until its
    // instruction ends or anything else flushes; after one for the walker
    // (txr), until its REP element ends, so a REP string that crosses into a
    // page the DTLB does not hold runs on pipelined once that page's walk is
    // done.
    logic serial_el;
    always_ff @(posedge clk) begin
        if (reset || wb_flush && !rp_go) serial <= 1'b0;
        else if (rp_go) serial <= !wb_smc && !wb_frp && !wb_s.ifw;
        else if (wb_commit && (wb_eoi || serial_el && wb_s.uop.str_cx)) serial <= 1'b0;
        if (rp_go) serial_el <= wb_s.txr;
    end

    // ---- Memory: L1I, L1D and the bus interface -------------------------------------
    logic              st_ex, st_wb, oldest, unc_start;
    logic [PA-6:0]     inv_line;
    logic              inv_valid, inv_all;
    logic              d_req, d_mmio, d_beat, i_req, i_beat;
    logic [PA-3:0]     d_addr;
    logic [3:0]        d_be;
    logic [PA-6:0]     i_line;
    logic [127:0]      bus_rdata;
    assign st_ex = ex_s.valid && writes_mem(ex_s);
    assign st_wb = wb_s.valid && writes_mem(wb_s);
    // An uncached load may read its device once nothing older can flush it
    // or still has a store to make: EX and WB hold nothing, or only earlier
    // uops of its own instruction that neither store, end an instruction or
    // element (no interrupt boundary), branch, fault, nor multiply or divide
    // (IRET's or POPA's loads after its first). Nor while the instruction
    // the load is part of may restart for self-modifying code (smc_due,
    // smc_defer), which would read the device again; a load that replays
    // meanwhile ends queue16's wait, as any flush does.
    function automatic logic own_load(input pipe_t s);
        own_load = !s.uop.ctl.end_of_instruction && !s.uop.str_cx && !writes_mem(s) && s.uop.io == 2'd0
                && s.uop.ctl.fault == fes_i386_pkg::FAULT_NONE && s.uop.cls != fes_i386_pkg::UOP_BRANCH
                && s.uop.cls != fes_i386_pkg::UOP_MUL && s.uop.cls != fes_i386_pkg::UOP_DIV;
    endfunction
    assign oldest = !int_take && !smc_due && !smc_defer && (!ex_s.valid || own_load(ex_s))
                 && (!wb_s.valid || own_load(wb_s) && !wb_flushes);
    assign trace_fetch = mem_load;
    assign trace_fetch_block = mem_block;
    assign trace_dread = dmem_read;
    assign trace_dread_addr = dmem_addr;
    assign trace_mem_wait = m2_load && !dmem_valid || st_wait || !mem_valid;
    assign trace_replay = rp_go && !wb_smc && !wb_frp;
    assign trace_smc = smc_go;
    assign trace_smc_open = smc_open && !unc_start;
    assign trace_ex_store = st_ex;

    // The walker's A/D store (pw) takes the bus interface's store port while
    // D to WB are frozen, when WB commits nothing; it clears its line's set
    // in the L1D (there) and the L1I.
    logic                pw_valid;
    logic [PA-1:0]       pw_addr;
    logic [31:0]         pw_data;
    fes_i386_pkg::attr_e pw_at;
    assign trace_pw = pw_valid;
    assign trace_pw_addr = pw_addr;
    assign trace_pw_data = pw_data;
    fes_i386_l1i l1i (
        .clk, .reset, .a20m, .attr_upper, .ram_top, .mem_block, .mem_load, .mem_data, .mem_valid, .mem_tag,
        .pg(pg_ifl), .itlb_fill(tf_valid && tf_itlb), .itlb_e(tf_e), .itlb_flush(tlb_flush), .itlb_off(wb_tlbx),
        .st_advance(!freeze), .st_ex_addr(ex_saddr), .st_ex, .st_wb, .st_commit(wb_store),
        .st_line0(wb_p0[PA-1:5]), .st_line1(wb_p1[PA-1:5]), .st_cross(wb_cross),
        .pw_clr(pw_valid), .pw_line(pw_addr[PA-1:5]),
        .inv_valid, .inv_line, .inv_all, .i_req, .i_line, .i_beat, .rdata(bus_rdata)
    );

    fes_i386_l1d l1d (
        .clk, .reset, .a20m, .attr_upper, .ram_top, .advance(!freeze), .flush(wb_flush), .ag_index(linear[11:5]),
        .rd(dmem_read), .addr(dmem_addr), .bytes(m1_s.uop.mem.bytes), .fault(dmem_fault),
        .oldest, .valid(dmem_valid), .rdata(dmem_rdata), .replay(l1d_replay), .unc_start,
        .st_ex_addr(ex_saddr), .st_wb_addr(wb_saddr), .st_commit(wb_store),
        .st_line0(wb_p0[PA-1:5]), .st_line1(wb_p1[PA-1:5]), .st_attr0(wb_at0), .st_cross(wb_cross),
        .st_dword(wb_saddr[4:2]), .st_data(dmem_wdata), .st_mask(dmem_wmask),
        .inv_valid, .inv_line, .inv_all, .d_req, .d_mmio, .d_addr, .d_be, .d_beat, .bdata(bus_rdata),
        .pg, .cr3_pd(cr3[31:12]), .m1_pg, .m1_at0, .m1_at1, .tlb_pages(dt_pages), .tlb_ma(dt_match[0]),
        .tx(m1_tx && !halted && !wb_stop), .tx_a(m1_s.ifw ? m1_s.pf_lin : m1_s.maddr), .tx_t(m1_s.target),
        .tx_need(m1_s.ifw ? 4'b0001 : m1_out.dfl ? {2'b00, m1_xa, 1'b1} : {m1_xt, m1_st2, m1_xa, 1'b1}),
        .tx_wr(m1_st2 ? {2'b11, 2'b00} : {4{m1_wr}}), .tx_user(m1_s.ifw ? cpl == 2'd3 : m1_user), .tx_ifw(m1_s.ifw),
        .wb_empty, .pg_out(l1d_pg), .pf(l1d_pf), .pf_lin(l1d_pf_lin), .pf_err(l1d_pf_err), .walked(l1d_walked),
        .tf_valid, .tf_itlb, .tf_e, .pw_valid, .pw_addr, .pw_data, .pw_at
    );

    fes_i386_biu #(.RAM_BASE(RAM_BASE)) biu (
        .clk, .cold_reset, .reset, .attr_upper, .ram_top,
        .st_valid(wb_store || pw_valid), .st_line0(pw_valid ? pw_addr[PA-1:5] : wb_p0[PA-1:5]),
        .st_line1(pw_valid ? pw_addr[PA-1:5] : wb_p1[PA-1:5]), .st_attr0(pw_valid ? pw_at : wb_at0),
        .st_attr1(pw_valid ? pw_at : wb_at1), .st_dword(pw_valid ? pw_addr[4:2] : wb_saddr[4:2]),
        .st_data(pw_valid ? {32'd0, pw_data} : dmem_wdata), .st_mask(pw_valid ? 8'h0f : dmem_wmask), .wb_room_next, .wb_empty,
        .drain(io_wait), .d_req, .d_mmio, .d_addr, .d_be, .d_beat, .i_req, .i_line, .i_beat, .rdata(bus_rdata),
        .inv_valid, .inv_line, .inv_all,
        .ddr_address, .ddr_burstcount, .ddr_read, .ddr_write, .ddr_writedata, .ddr_byteenable, .ddr_waitrequest,
        .ddr_readdata, .ddr_readdatavalid,
        .mmio_valid, .mmio_write, .mmio_address, .mmio_byteenable, .mmio_wdata, .mmio_ready, .mmio_rvalid,
        .mmio_rdata,
        .dma_valid, .dma_write, .dma_address, .dma_wdata, .dma_done, .dma_rdata, .flush_request, .flush_done,
        .idle(trace_mem_idle)
    );

    // ---- BTB writes ----------------------------------------------------------------
    // A direct branch's retirement writes its entry: a taken one counts up
    // (from 2 when it was not matched, in a way taken in turn), a matched one
    // not taken counts down. A near RET's, and an indirect near JMP's or
    // CALL's, writes an always-taken entry; the indirect one's target is the
    // one it went to (EX's), so the entry predicts its last target. The entry is keyed by the block that holds the
    // branch's last byte (wb_blast, worked out as the uop enters WB). A
    // fetch check's replay clears both ways of the sets of the block before
    // the replayed instruction's start and of the block holding it: one of
    // them sent fetch to the wrong bytes (a branch's block whose entry ends
    // where no branch ends, or a block whose entry ends inside the
    // instruction). Under queue16 nothing is written, so nothing predicts.
    logic [31:0] wb_blast, frp_lin;
    logic [1:0]  frp_n;
    logic        btb_rr;
    logic [11:0] frp_prev;
    assign frp_prev = frp_lin[11:0] - 12'd1;
    always_ff @(posedge clk) begin
        if (!freeze) wb_blast <= ex_s.lin + {28'd0, ex_s.ilen} - 32'd1;
        if (reset) frp_n <= 2'd0;
        else if (rp_go && wb_frp && pred_on) frp_n <= 2'd2;
        else if (frp_n != 2'd0) frp_n <= frp_n - 2'd1;
        if (rp_go) frp_lin <= cs_eip;
        btb_wr <= '0;
        if (frp_n != 2'd0) begin
            btb_wr.valid <= 1'b1;
            btb_wr.ways <= 2'b11;
            btb_wr.index <= frp_n[1] ? frp_prev[11:4] : frp_lin[11:4];
        end else if (wb_commit && (wb_s.dbr && (wb_s.taken || wb_s.bm) || wb_s.nret || wb_s.nind) && pred_on && !reset) begin
            btb_wr.valid <= 1'b1;
            btb_wr.ways <= (wb_s.bm ? wb_s.bway : btb_rr) ? 2'b10 : 2'b01;
            btb_wr.index <= wb_blast[11:4];
            btb_wr.entry.valid <= 1'b1;
            btb_wr.entry.uncond <= wb_s.uop.op == 5'(fes_i386_pkg::BR_JMP) || wb_s.nret || wb_s.nind;
            btb_wr.entry.call <= wb_s.ncall;
            btb_wr.entry.ret <= wb_s.nret;
            btb_wr.entry.ctr <= !wb_s.taken ? (wb_s.bctr == 2'd0 ? 2'd0 : wb_s.bctr - 2'd1)
                              : !wb_s.bm ? 2'd2 : wb_s.bctr == 2'd3 ? 2'd3 : wb_s.bctr + 2'd1;
            btb_wr.entry.last <= wb_blast[3:0];
            btb_wr.entry.tag <= wb_blast[31:12];
            btb_wr.entry.target <= wb_s.target;
        end
        if (reset) btb_rr <= 1'b0;
        else if (wb_commit && (wb_s.dbr && wb_s.taken || wb_s.nret || wb_s.nind) && !wb_s.bm) btb_rr <= !btb_rr;
    end

    // ---- The return stack ------------------------------------------------------------
    // The front end's return stack (fes_i386_ras) moves as F2 predicts, so
    // on a redirect it is set back to what WB has committed: ras_c counts
    // the near CALLs less the near RETs committed, modulo 16. The uop in WB
    // when a branch redirects is that branch, which commits on the same
    // edge, so the pointer counts it; a fault's or an interrupt's redirect
    // commits nothing (the selects key on the registers redirect_linear's
    // do). A near CALL that redirects was not predicted, so the front end
    // never pushed its return address, or was an indirect CALL predicted to
    // another target, whose push this repeats: it is written here, CS.base +
    // the next EIP. The entries are not restored otherwise: a wrong path's push
    // over a live entry, a CALL whose return address a program drops (POP
    // then JMP, ADD SP), or more than 16 CALLs deep cost a later
    // misprediction, which EX's compare catches.
    logic [3:0] ras_c, ras_cw;
    assign ras_cw = ras_c + {3'd0, wb_s.valid && wb_s.ncall} - {3'd0, wb_s.valid && wb_s.nret};
    assign ras_set_ptr = start == 2'd2 || wb_faulted || int_take ? ras_c : ras_cw;
    assign ras_set_wr = !(start == 2'd2 || wb_faulted || int_take) && wb_s.valid && wb_s.ncall;
    assign ras_set_lin = wb_fall;
    always_ff @(posedge clk) begin
        if (reset) ras_c <= 4'd0;
        else if (wb_commit) ras_c <= ras_cw;
    end
    // The prediction's counts for machine_tb --cpu-profile (cpu_profile.vlt
    // reads them; nothing in the CPU does): a direct branch retiring, whether
    // it was predicted taken and was taken, and a fetch check's replay.
    logic prof_br, prof_pt, prof_taken, prof_frp, prof_ret, prof_ind, prof_redir;
    assign prof_br = wb_commit && wb_s.dbr;
    // A near RET or an indirect near CALL or JMP retiring (prof_ind), and
    // whether it redirects (prof_redir): not predicted, or to another target
    // than the one predicted.
    assign prof_ret = wb_commit && wb_s.nret;
    assign prof_ind = wb_commit && wb_s.nind;
    assign prof_redir = wb_redir;
    assign prof_pt = wb_s.pt;
    assign prof_taken = wb_s.taken;
    assign prof_frp = rp_go && wb_frp;
    // The address-interlock (AGI) split for machine_tb --cpu-profile (bench
    // only). prof_dcls is the uop in D's producer class (cpu_profile.h
    // AgiClass), prof_d32 whether it writes 32 bits, prof_dimm whether its
    // second operand is imm, and prof_ds1 and prof_ds2 whether each register
    // source's youngest producer is a late one in AG, M1 or M2, so that the
    // value is not in a register by the time the uop is in AG. prof_agi is
    // the stage (0 AG to 3 EX, 4 none) of the producer that holds D's address
    // operand: the youngest late producer of its base or index, else the
    // youngest early one (a late scaled index, or two late operands).
    logic [4:0] prof_dcls;
    logic       prof_d32, prof_dimm, prof_ds1, prof_ds2;
    logic [2:0] prof_agi;
    // The youngest producer of GPR r among AG to EX (0 to 3; 4 none), and
    // whether its value is early: an early-ALU result, or ESP from a stack
    // operation whose destination is not ESP.
    function automatic logic [2:0] prof_young(input logic [2:0] r);
        prof_young = 3'd4;
        for (int i = 3; i >= 0; i--)
            if (prod_valid[i] && prod_dst[i] == r || r == 3'd4 && prod_sp[i]) prof_young = 3'(i);
    endfunction
    function automatic logic prof_late(input logic [2:0] r, input logic [2:0] at);
        prof_late = at != 3'd4 && !(prod_early[at[1:0]]
                                    || r == 3'd4 && prod_sp[at[1:0]] && !(prod_valid[at[1:0]] && prod_dst[at[1:0]] == r));
    endfunction
    logic [2:0] prof_by, prof_iy, prof_s1y, prof_s2y;
    logic       prof_bl, prof_il, prof_ld;
    assign prof_by = a_addr && dc.has_base ? prof_young(dc.base) : 3'd4;
    assign prof_iy = a_addr && dc.has_index ? prof_young(dc.index) : 3'd4;
    assign prof_bl = prof_late(dc.base, prof_by);
    assign prof_il = prof_late(dc.index, prof_iy);
    assign prof_s1y = prof_young(u.src1.index[2:0]);
    assign prof_s2y = prof_young(u.src2.index[2:0]);
    assign prof_ds1 = u.src1.valid && u.src1.space == fes_i386_pkg::RS_GPR && prof_s1y < 3'd3
                   && prof_late(u.src1.index[2:0], prof_s1y);
    assign prof_ds2 = u.src2.valid && u.src2.space == fes_i386_pkg::RS_GPR && prof_s2y < 3'd3
                   && prof_late(u.src2.index[2:0], prof_s2y);
    assign prof_agi = prof_bl && (!prof_il || prof_by < prof_iy) ? prof_by
                    : prof_il ? prof_iy
                    : prof_by < prof_iy ? prof_by : prof_iy;
    assign prof_ld = mkind == fes_i386_pkg::MEM_LOAD || mkind == fes_i386_pkg::MEM_RMW;
    assign prof_d32 = u.size == fes_i386_pkg::SIZE_32;
    assign prof_dimm = !u.src2.valid;
    always_comb begin
        prof_dcls = 5'd13;  // other
        case (u.cls)
            fes_i386_pkg::UOP_ALU:
                if (lea) prof_dcls = lea_early ? 5'd14 : 5'd4;
                else if (u.sp_write && prof_ld) prof_dcls = 5'd8;
                else if (prof_ld) prof_dcls = u.op == 5'(fes_i386_pkg::ALU_MOV) || u.op == 5'(fes_i386_pkg::ALU_MOVZX)
                                         || u.op == 5'(fes_i386_pkg::ALU_MOVSX) ? 5'd6 : 5'd7;
                else if (mem) prof_dcls = 5'd13;
                else if ((u.op == 5'(fes_i386_pkg::ALU_XOR) || u.op == 5'(fes_i386_pkg::ALU_SUB)) && u.src2.valid
                         && u.src2.space == u.src1.space && u.src2.index == u.src1.index && u.src2.hi8 == u.src1.hi8)
                    prof_dcls = 5'd17;  // XOR or SUB of a register with itself: zero
                else case (u.op)
                    5'(fes_i386_pkg::ALU_MOV): prof_dcls = 5'd1;
                    5'(fes_i386_pkg::ALU_ADD), 5'(fes_i386_pkg::ALU_INC), 5'(fes_i386_pkg::ALU_DEC): prof_dcls = 5'd2;
                    5'(fes_i386_pkg::ALU_SUB): prof_dcls = 5'd15;
                    5'(fes_i386_pkg::ALU_ADC), 5'(fes_i386_pkg::ALU_SBB), 5'(fes_i386_pkg::ALU_NEG): prof_dcls = 5'd16;
                    5'(fes_i386_pkg::ALU_AND), 5'(fes_i386_pkg::ALU_OR), 5'(fes_i386_pkg::ALU_XOR),
                    5'(fes_i386_pkg::ALU_NOT): prof_dcls = 5'd3;
                    5'(fes_i386_pkg::ALU_MOVZX), 5'(fes_i386_pkg::ALU_MOVSX): prof_dcls = 5'd5;
                    default: prof_dcls = 5'd11;
                endcase
            fes_i386_pkg::UOP_SHIFT: prof_dcls = 5'd9;
            fes_i386_pkg::UOP_MUL, fes_i386_pkg::UOP_DIV: prof_dcls = 5'd10;
            fes_i386_pkg::UOP_BRANCH: prof_dcls = 5'd12;
            default: prof_dcls = prof_ld ? 5'd6 : 5'd13;
        endcase
    end

    // ---- Self-modifying code -------------------------------------------------------
    // The instructions after the one in WB came from the lines of the
    // instructions D to EX hold (each one's first line and the next, which
    // it may run into), of Q's record and DC's two, and of the blocks the
    // front end holds or loads next (fes_i386_fetchbuf held_block), among
    // them every block F2 may still read from the L1I before a clear of a
    // line there lands. With prediction they are not one run of lines. A
    // store committed into one of them, or a DMA write (inv_valid), may have
    // changed bytes the front end already holds. Then an instruction after
    // it restarts: its first uop
    // takes FAULT_REPLAY as it enters WB (smc_mark), WB flushes it and
    // everything younger, and the front end restarts at it through start,
    // as for an uncached load but without serial issue (smc_go). By then the
    // L1I has cleared the line, and its fill waits for the store's entry in
    // the write buffer, so the instruction runs the new bytes. The
    // instruction that stored completes as it was decoded.
    //
    // Which instruction: under the coherent profile, and for a DMA write,
    // the next one not begun. That is the next once the instruction in WB
    // ends (smc_pend until it does, smc_due after), or, while WB is empty
    // between instructions (smc_open), the one whose first uop enters WB
    // next: smc_first says the last uop WB took ended an instruction, and
    // uc_live that the next one's uncached load has not read its device. A
    // load that starts to read as the write lands (unc_start) has begun its
    // instruction too: it starts with D to WB frozen, so nothing enters WB
    // then, and the write waits for that instruction's end. A delivery's
    // uops are no instruction's, and an instruction restarted for
    // self-modifying code is not restarted again before it enters WB
    // (smc_first low after smc_go): a DMA write that lands meanwhile
    // restarts the one after it. So a stream of DMA writes into the run
    // cannot hold the CPU, and the restarted instruction may run bytes from
    // before the later write. Under queue16 the 16 bytes after the storing
    // instruction (from eip_next) keep what the front end holds: a store
    // with no byte past them (wb_q16, worked out in EX), which may lie
    // behind them, its own encoding among them, where nothing younger is,
    // needs nothing. One with a byte past them restarts the first
    // instruction to reach past them (smc_defer, the window's end plus one
    // in smc_t), checked as each instruction's first uop enters WB, at the
    // boundary before it or later (smc_chk), as a 386 refetches once it runs
    // past its queue. The instruction right after the storing one starts at
    // the window and is at most 15 bytes, so the check needs only the
    // registered smc_defer and smc_t.
    //
    // Lines compare by physical bits 19:5, modulo 1 MiB: each fetch block
    // carries its page's bits 19:12 from the ITLB (with paging off, the
    // linear ones, which agree with physical under A20M and for the shadow
    // at FFFF0000h), and each instruction its first line's page's and the
    // next block's (ipp0, ipp1), whose page its next line is in past its own
    // page's last. F1's next blocks have not been looked up: with paging on
    // they compare by bits 11:5 alone. An alias 1 MiB away, or such an F1
    // block in another page, restarts for nothing. Every input but unc_start is a register,
    // unc_start reaches only smc_pend and smc_due, and the decision reaches
    // only registers (smc_pend, smc_due, smc_defer, smc_chk, and WB's entry
    // through smc_mark), so the freeze and WB's flush keep their depth.
    logic        q16, wb_q16, smc_pend, smc_chk, smc_store, smc_dma, smc_bnd, smc_now, smc_late, smc_past;
    logic        smc_first, uc_live, smc_open;
    logic [19:0] ex_next_lin, wb_next_lin, ex_q16_off, smc_t, smc_reach;
    // The line is one the front end or an instruction after WB's holds.
    function automatic logic smc_held(input logic [14:0] line, input logic [6:0][27:0] blk, input logic [6:0] bv,
                                      input logic [6:0][7:0] bpp, input logic [6:0] bpk, input logic pg_in,
                                      input logic [6:0][31:0] lin, input logic [6:0][7:0] ipp0, input logic [6:0][7:0] ipp1,
                                      input logic [6:0] lv);
        logic [6:0] nl;
        smc_held = 1'b0;
        for (int i = 0; i < 7; i++) begin
            if (bv[i] && blk[i][7:1] == line[6:0] && (pg_in && !bpk[i] || (bpk[i] ? bpp[i] : blk[i][15:8]) == line[14:7]))
                smc_held = 1'b1;
            nl = lin[i][11:5] + 7'd1;
            if (lv[i] && ({ipp0[i], lin[i][11:5]} == line
                          || nl == line[6:0] && (lin[i][11:5] == 7'h7f ? ipp1[i] : ipp0[i]) == line[14:7]))
                smc_held = 1'b1;
        end
    endfunction
    logic [6:0][31:0] smc_ilin;
    logic [6:0][7:0]  smc_ipp0, smc_ipp1;
    logic [6:0]       smc_iv;
    assign smc_ilin = {q.linear, dc_skid.lin, dc.lin, ag_s.lin, m1_s.lin, m2_s.lin, ex_s.lin};
    assign smc_ipp0 = {q.pp0, dc_skid.pp0, dc.pp0, ag_s.ipp0, m1_s.ipp0, m2_s.ipp0, ex_s.ipp0};
    assign smc_ipp1 = {q.pp1, dc_skid.pp1, dc.pp1, ag_s.ipp1, m1_s.ipp1, m2_s.ipp1, ex_s.ipp1};
    // An exception's entry's uops, at length 0, fetched nothing.
    assign smc_iv = {q_valid, dc_skid_valid && dc_skid.fetched, dc_valid && dc.fetched, ag_s.valid && ag_s.ilen != 4'd0,
                     m1_s.valid && m1_s.ilen != 4'd0, m2_s.valid && m2_s.ilen != 4'd0, ex_s.valid && ex_s.ilen != 4'd0};
    assign smc_store = wb_store && !(q16 && wb_q16)
                    && (smc_held(wb_p0[19:5], fe_block, fe_valid, fe_pp, fe_pk, pg, smc_ilin, smc_ipp0, smc_ipp1, smc_iv)
                        || wb_cross && smc_held(wb_p1[19:5], fe_block, fe_valid, fe_pp, fe_pk, pg, smc_ilin, smc_ipp0, smc_ipp1,
                                                smc_iv));
    assign smc_dma = inv_valid && smc_held(inv_line[14:0], fe_block, fe_valid, fe_pp, fe_pk, pg, smc_ilin, smc_ipp0, smc_ipp1,
                                           smc_iv);
    assign smc_open = !wb_s.valid && smc_first && !uc_live;
    assign smc_bnd = wb_commit && wb_eoi || smc_open;
    assign smc_now = smc_pend || smc_dma || smc_store && !q16;
    assign smc_late = smc_defer || smc_store && q16;
    // The instruction in EX (its next instruction's linear address) reaches
    // past the window.
    assign ex_next_lin = seg_base[SEG_CS][19:0] + ex_s.eip_next[19:0];
    assign smc_reach = ex_next_lin - smc_t;
    assign smc_past = !smc_reach[19];
    assign smc_mark = smc_due || smc_bnd && smc_now || (smc_bnd || smc_chk) && smc_defer && ex_s.valid && smc_past;
    assign smc_go = rp_go && wb_smc;
    assign ex_q16_off = ex_saddr[19:0] - ex_next_lin;
    always_ff @(posedge clk) begin
        if (reset) q16 <= queue16;
        if (!freeze) begin
            wb_next_lin <= ex_next_lin;
            wb_q16 <= ex_q16_off[19]
                   || ex_q16_off[18:4] == 15'd0
                      && ex_q16_off[3:0] <= (ex_s.uop.mem.bytes[2] ? 4'd12 : ex_s.uop.mem.bytes[1] ? 4'd14 : 4'd15);
        end
        if (!smc_defer) smc_t <= wb_next_lin + 20'd17;
        // A mid-instruction branch's commit leaves smc_first low, as the uops
        // after it are its instruction's.
        if (reset) smc_first <= 1'b1;
        else if (exc_take || int_go || smc_go) smc_first <= 1'b0;
        else if (rp_go) smc_first <= 1'b1;
        else if (wb_commit) smc_first <= wb_eoi;
        if (reset || wb_flush || wb_commit && wb_eoi) uc_live <= 1'b0;
        else if (unc_start) uc_live <= 1'b1;
        if (reset || wb_flush) begin
            smc_pend <= 1'b0;
            smc_due <= 1'b0;
            smc_defer <= 1'b0;
            smc_chk <= 1'b0;
        end else begin
            smc_pend <= smc_now && (!smc_bnd || unc_start);
            smc_due <= smc_mark && !(!freeze && ex_s.valid) && !unc_start;
            smc_defer <= smc_late;
            smc_chk <= (smc_bnd || smc_chk) && smc_late && !(!freeze && ex_s.valid);
        end
    end

    assign arch_gpr = gpr;
    assign arch_eflags = {14'd0, eflags};
    assign arch_cr0 = cr0_rd;
    assign arch_cr2 = cr2;
    assign arch_cr3 = cr3;
    assign arch_dr = dr;
    assign arch_dr6 = dr6_rd;
    assign arch_dr7 = dr7;
    assign arch_gdtr_base = gdtr_base;
    assign arch_gdtr_limit = gdtr_limit;
    assign arch_idtr_base = idtr_base;
    assign arch_idtr_limit = idtr_limit;
    assign arch_eip = eip;
    assign arch_sel = seg_sel;
    assign arch_base = seg_base;
    assign arch_limit = seg_limit;
    assign arch_ar = seg_ar;
    assign arch_ldtr_sel = ldtr_sel;
    assign arch_ldtr_base = ldtr_base;
    assign arch_ldtr_limit = ldtr_limit;
    assign arch_ldtr_ar = ldtr_ar;
    assign arch_ldtr_valid = ldtr_valid;
    assign arch_tr_sel = tr_sel;
    assign arch_tr_base = tr_base;
    assign arch_tr_limit = tr_limit;
    assign arch_tr_ar = tr_ar;
    assign arch_cpl = cpl;
endmodule
