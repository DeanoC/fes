# Exact guide for the remaining ready1 address-register group

Root alone activates this new generator. It binds the closed current full
route83dd/run8fce, its complete original-path profile input/output/runtime
closure, the positive conditional prefix10016, and pure native/topology
definitions32fd/72131/local8601. It does not invoke a compiler, older helper
main, generator, authenticator, build, test, or physical evaluator.

The current complete lossless routed document and actual15,290-path report
are independently checked against the current full-cap predicted report for
all seven actual clock-pair endpoint/window sets. Actual Fmax and HIP/hold
flags must agree with the closed current run. The current original ready1
root must retain108 FF.ENA users; its first copy retains two and its second
copy one, all with the same current native clock. These are guide selection
checks, not an independent proof of the entire routed graph or physical
state. The pending full physical/native comparison supplies that separately.

Every original-root memory-to-memory ENA path must have the actual unchanged
inner.Q to outer.B and outer.Q to FF.ENA edges and exact image-local raw
connections. All108 actual root paths are grouped by their real exported FF
BEL. The uniquely worst remaining group is the actual six registers in
LAB24.12. The emitted guide preserves all six original path objects and
their original source-report order, with their actual clocks, locations,
windows and segment delays. All other source-report fields, including
Fmax and the emitted report cap, are preserved. This is a filtered search
guide; it is not a newly measured complete timing report.

Preparation is exclusive and every bound byte pathname is rehashed before
the guide and derivation are written. The derivation includes the complete
source closure and actual topology, selected endpoints and precise scope.
No LUT/FF is transformed, no new local/driver candidate is qualified, and
no native/Boolean/physical/STA/gain/RBF/hardware acceptance is inherited.
The future fifth stage must freshly qualify the added region while retaining
the original three stages, the old two-user copy and the existing one-user
second copy. Root will review/AST and obtain an independent static peer before
activation.
