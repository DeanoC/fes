"""Derive an exact guide for the worst remaining ready1 ENA LAB."""
import argparse
import builtins
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
ROUTE = RAW / "local-multicopy-ready1-route-264"
PREFIX = RAW / "local-multicopy-ready1-264"
PROFILE_SHA = "83ddcc2b29edb2ed1e6423860a65a3d9806d077dc33a349972ce2d17bf3afcdc"
RUN_SHA = "8fce72fda3635cc4a6521b8b279fb46826c269bba304f10524e7f8e674ba0c28"
PREFIX_SHA = "10016a0f227b801995eebc5c41a79c3b08d28bb6932b785349a60529d0048709"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE = SELECTED.parent / "freeze.py"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B"
INNER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q"
PAIR = ("posedge ram_clock.clocks[0]", "posedge ram_clock.clocks[0]")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure helper identity differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure helper path differs")
    return module


def derive(self_sha, scope_sha):
    guide, output = HERE / "ready-guide.json", HERE / "derivation.json"
    require(not guide.exists() and not output.exists(), "immutable guide or derivation exists")
    native = load(NATIVE, NATIVE_SHA, "ready_address_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha),
            (ROUTE / "source-identity.json", PROFILE_SHA), (ROUTE / "route-c0/run.json", RUN_SHA),
            (PREFIX / "baseline/comparison-prefix.json", PREFIX_SHA), (NATIVE, NATIVE_SHA),
            (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    profile, record, prefix = (native.read(path) for path in
        (ROUTE / "source-identity.json", ROUTE / "route-c0/run.json", PREFIX / "baseline/comparison-prefix.json"))
    for path, expected in profile["input_sha256"].items():
        audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
        record["final_original_input_output_runtime_hashes_stable"] is True and
        not any(key in record for key in ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")) and
        record["source_identity_sha256"] == PROFILE_SHA and
        all(record[key] == value for key, value in profile.items() if key != "input_sha256") and
        record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): PROFILE_SHA} and
        record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip" and
        record["final_reported_hold_violations"] is False and not record["last_signoff_hold_warning_lines"] and
        prefix["native_graph_proof_available"] is True and prefix["structural_rejection"] is None and
        profile["prefix_proof_sha256"] == PREFIX_SHA,
        "closed current route or conditional prefix role differs")
    for path, expected in record["execution"]["files"].items():
        audit.bind(Path(path), expected, execution=True)
    require(set(record["output_sha256"]) == {str(ROUTE / "route-c0" / name)
        for name in ("route.log", "routed.json", "timing.json", "core.rbf")}, "actual output set differs")
    for path, expected in record["output_sha256"].items():
        audit.bind(Path(path), expected)
    document = native.read_netlist(ROUTE / "route-c0/routed.json")
    top = document["modules"]["top"]
    report = native.read(ROUTE / "route-c0/timing.json")
    predicted = native.read(PREFIX / "baseline/timing.json")
    require(report["fmax"] == record["fmax"] and report["timing_report_paths"] == 16384,
        "actual final report Fmax/cap differs")
    frozen = load(FREEZE, FREEZE_SHA, "ready_address_freeze")
    selected = load(SELECTED, SELECTED_SHA, "ready_address_selected", frozen)
    topology = selected.report_topology(document, report, predicted)
    require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7,
        "actual complete report coverage differs")
    drivers, users = selected.native_tables(top)
    def output_bit(name):
        cell = top["cells"][name]
        require(cell["port_directions"]["Q"] == "output" and len(cell["connections"]["Q"]) == 1, "ordinary Q differs")
        bit = cell["connections"]["Q"][0]
        require(drivers.get(bit) == [(name, "Q", 0, 0)], "Q native driver is not unique")
        return bit
    root_q = output_bit(OUTER)
    inner_q = output_bit(INNER)
    old_q, added_q = output_bit(OUTER + "$local_remap"), output_bit(OUTER + "$local_remap$1")
    require((len(users[root_q]), len(users[old_q]), len(users[added_q])) == (108, 2, 1), "actual retained/additional cohort sizes differ")
    clock_bits = set()
    for slot in users[root_q] + users[old_q] + users[added_q]:
        cell = top["cells"][slot[0]]
        require(slot[1:] == ("ENA", 0, 0) and cell["type"] == "MISTRAL_FF" and len(cell["connections"]["CLK"]) == 1,
            "ready1 union is not scalar FF ENA")
        clock_bits.add(cell["connections"]["CLK"][0])
    require(len(clock_bits) == 1, "ready1 union clock differs")
    root_endpoints = {slot[0] for slot in users[root_q]}
    groups = {}
    chosen_paths = []
    for path in report["critical_paths"]:
        end = path["path"][-1]["to"]
        if (path["from"], path["to"]) != PAIR or end["port"] != "ENA" or end["cell"] not in root_endpoints:
            continue
        routes = [segment for segment in path["path"] if segment["type"] == "routing"]
        require(any(segment["from"] == {"cell": INNER, "port": "Q", "loc": segment["from"]["loc"]} and
            segment["to"]["cell"] == OUTER and segment["to"]["port"] == "B" for segment in routes) and
            routes[-1]["from"]["cell"] == OUTER and routes[-1]["from"]["port"] == "Q" and
            routes[-1]["to"]["cell"] == end["cell"] and routes[-1]["to"]["port"] == "ENA" and
            top["cells"][OUTER]["connections"]["B"] == [inner_q] and
            top["cells"][end["cell"]]["connections"]["ENA"] == [root_q], "actual unchanged inner/outer/ENA path differs")
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.(\d+)", top["cells"][end["cell"]]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "actual endpoint lacks a FF BEL")
        lab = tuple(map(int, match.groups()[:2]))
        total = math.fsum(segment["delay"] for segment in path["path"])
        require(math.isfinite(total), "actual complete delay is not finite")
        groups.setdefault(lab, []).append((path, total))
    require(sum(map(len, groups.values())) == 108, "actual root ENA report coverage differs")
    worst_lab = max(groups, key=lambda lab: (max(total for _, total in groups[lab]), lab))
    require(worst_lab == (24, 12) and len(groups[worst_lab]) == 6, "actual worst remaining LAB/cohort differs")
    cohort = {path["path"][-1]["to"]["cell"] for path, _ in groups[worst_lab]}
    chosen_paths = [path for path in report["critical_paths"] if
        (path["from"], path["to"]) == PAIR and path["path"][-1]["to"]["port"] == "ENA" and
        path["path"][-1]["to"]["cell"] in cohort]
    require(len(chosen_paths) == len(cohort) == 6 and all(math.fsum(segment["delay"] for segment in path["path"]) >
        path["max_delay"] for path in chosen_paths), "selected actual six paths are not distinct window violations")
    result = dict(report)
    result["critical_paths"] = chosen_paths
    audit.finish()
    with guide.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    audit.bind(guide, sha(guide))
    audit.finish()
    derived = {"schema": 1, "phase": "local-multicopy-ready1-worst-remaining-lab-exact-guide",
        "generator_sha256": self_sha, "scope_sha256": scope_sha, "route_profile_sha256": PROFILE_SHA,
        "current_full_run_sha256": RUN_SHA, "prefix_proof_sha256": PREFIX_SHA,
        "guide_path": str(guide), "guide_sha256": sha(guide), "selected_lab": list(worst_lab),
        "selected_endpoints": sorted(cohort), "selected_paths": len(chosen_paths), "all_current_root_paths": 108,
        "full_current_report_topology": topology, "source_fmax": report["fmax"],
        "exact_path_objects_and_original_source_order_preserved": True,
        "clock_terms_locations_sources_windows_or_segment_delays_modified": False,
        "search_guide_only_not_a_new_full_timing_report": True, "new_candidate_qualified": False,
        "independent_physical_equivalence_inherited": False, "routed_gain_accepted": False, "hardware_tested": False,
        "artifact_sha256": dict(sorted(audit.artifacts.items())),
        "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}
    with output.open("x") as stream:
        stream.write(json.dumps(derived, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"guide_sha256": sha(guide), "derivation_sha256": sha(output), "paths": 6}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    parser.add_argument("--scope-sha256", required=True)
    args = parser.parse_args()
    derive(args.self_sha256, args.scope_sha256)


if __name__ == "__main__":
    main()
