# Exact current ready0 skid-burst search guide

ROOT alone executes this derivation after whole-byte/hash/AST and independent
peer review. Explicit self/scope/full-proof/run hashes are mandatory. Source is
the completed tenth route1a6d4f7b/profileea033985/prefixbf9d312c. Its exported
native/physical V2 proofcd8ad7ff is positive with zero LAST signoff holds; its
116.80878448486328MHz result is a timing reject against accepted-five6dcf8c4b at
117.77175903320312MHz. Source d7e5c61f/baseec0a8d0c, ELF41c2afe1,
archive4fbebd5e, host0f3c11a5 and exact compiler control1cff85d6 remain bound.

The proof's explicit V2 wrapper/native/physical files and their six scope/code
hashes, unchanged current timing859052ff/scope5bbb3d7c, and original strict
rejectionfffb82ee are bound directly and required in its flat artifact map. That
strict native/physical failure and exact named mate-pin reason remain visible;
the V2 supplies its bounded paired-half proof. The unchanged current timing
diagnostic must equal the original strict record. No original proof is rewritten.

The derivation rehashes the closed flat source-proof and accepted-reference
artifact/runtime maps, current profile/record union, all original current inputs,
runtime files and four actual completed outputs. Pinned32fd supplies lossless
paired-PLL parsing/Audit/canonical;72131/8601 provide only native tables/current
report topology. No old generator, authenticator, prepare/run/main, evaluator or
source query is executed. Original paths are rehashed before publication and
after binding the new guide. Outputs ready0-guide.json and derivation.json are
exclusive. The historical compiler/header closure is preserved separately from
the current executed runtime; old binary paths are not substituted.

The guide keeps exactly current critical_paths[1]: HPS cmd_ready_0 to innerALUT2.A,
inner.Q to outerALUT3.B, outer.Q to port0 skid_burstcount FF1.ENA at LAB35.27.
This is the sole worst current memory path at8.561000108718872ns, with its actual
7.691999912261963ns window. The original path object, source index/order, full
report metadata, clock-skew cmd_port_clk_0 frame, sources, locations, segment
delays and setup term stay exact. Only critical_paths is filtered. This guide is
a search input, not a replacement full timing report or a timing acceptance.

Current15290/seven-pair topology and endpoint/window coverage are checked using
the complete routed lossless document and its own tenth predicted report. Root
Q105902 has168 scalar FF ENA users on actual CLK3549. Exactly one original-root
consumer belongs to whole target LAB35.27: skid_burstcount FF1 at FF35.27.26.
Other original FFs in that LAB use different ENA functions and remain recorded;
they are not silently added to this transfer cohort.

InnerALUT2 mask0xb/Q97446 and outerALUT3 mask0x32/Q105902 have four distinct
literal boundaries[98306,98311,5029,103525], each with one ordinary native driver.
All16 conditional plain-SIG rows independently match all three existing port0
ALUT4 mask0x4440 copies: base Q120712/ten ENAs, copy$1 Q120718/one ENA and copy$2
Q120722/three ENAs. This proves the existing conditional function only; no future
copy, chosen pin map, site or new physical mask is inferred.

All ten existing copies retain their actual full records, literal Qs120708..120726,
complete guarded trial dictionaries, actual BELs and disjoint cohorts
21/2/10/1/6/1/1/3/2/8. Their aliases are sole named private Q aliases with no
public-port slots. The next port0 outerALUT3$local_remap$3 owner and its $Q alias
must be free in both cell and net namespaces. No future Q/BEL/gain is guessed.

Cone/copy/target full typed pin snapshots, all relevant aliases and native
driver/users, complete FF records in all predeclared LABs and all8221 original
FF BELs are retained. The enumerated cone/copies and target CLK/ENA are plain
SIG; actual other FF control states are preserved. Clock buffer Q3549←A112726
has complete SIG A/Q pins; its driver is the second serialized outclk occurrence
in lossless paired PLL records112724/112726. That occurrence makes no logical
channel or frequency claim. No clock or data buffer is collapsed.

A future eleventh stage must preserve the existing ten descriptors/cohorts and
freshly qualify its new candidate, then independently prove the selected native
graph and actual routed physical scope/windows/holds. The guide changes no RTL,
constraints, pins, phase, routes, production policy or plan descriptor. Hidden
caches/GPU IDs, independent numerical STA/calibration, decoded RBF and hardware
are unproved; no 130MHz or new gain is claimed. Accepted117.771759MHz is retained.
