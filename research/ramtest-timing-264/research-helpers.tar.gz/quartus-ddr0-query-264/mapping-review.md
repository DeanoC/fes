# Exact retained-fit DDR0 error-enable structure

Read-only analysis, 2026-09-30. Root alone copied/hash-authenticated 176 retained project files and executed the two saved-fit queries. This agent read the new outputs and wrote only this new note; no Quartus, build, route, helper, tracked source or old artifact was executed or changed by this agent. Small 64-row mask arithmetic was evaluated directly during analysis, without running an artifact helper or compiler.

The retained fit demonstrates a two-LUT group_bad-to-errors ENA branch and concrete factoring of bad-data reduction, saturation and synchronous reset. It supports a generic reduction-mapping investigation; it does not predict an OSS physical timing gain. The newly listed OSS terminal two-LUT composition produced zero qualified candidates and supplies no routed result.

## Provenance and precise endpoint scope

`query-record.json` authenticates scripts, query outputs and the copied project manifest. Both queries exited zero (STA 1.721 s, CDB 1.019 s); no refit occurred. Retained source inputs and private critical fit inputs stayed unchanged. Only private `db/top.taw.rdb` and the slow I/O simulation cache changed.

Quartus BUILD_ID is `52991ce22369904849b68bdd900f9ae1`; the immutable OSS experiment uses `7168b508ab424b70f1c0f87b2035d821`. The fit is Quartus 17.0.2, fit seed 1, native PLL/SDC and native slow 1100 mV/100 C timing. OSS uses seed 2 and different wrapper/model elaboration, including `RAM_OSS_HIGH_SPEED`. This is structural evidence, not whole-design equivalence, matched physical calibration, a newly fitted compiler comparison or hardware acceptance.

The query uniquely selects logical Quartus `group_bad[11]` and `errors[18]|ena`: all queried and anchored enumerated counts are one. **The g8 OSS launch name suffix `_Q_11` is not its logical bus index.** Its actual routing alias is `ddr0_test.group_bad[15]`, raw bit 14581. The OSS endpoint `ddr0_errors_MISTRAL_FF_Q_18.Q`, raw4413, does alias `ddr0_errors[18]`. Thus the error bit matches, while the queried launch is a different bit of the same 16-bit reduction. The complete atom extraction includes both logical bad[11] and bad[15]; do not label the selected timing path an exact logical launch-bit match to g8.

## Exact fitted path and locality

`timing/group_bad11-errors18-ena.rpt` reports one setup path:

| Property | Value |
| --- | ---: |
| LUT logic levels | 2 |
| Data delay | 3.508 ns |
| Data routing | 2.637 ns |
| Setup relationship | 7.692 ns |
| Setup slack | +3.921 ns |
| Clock skew | -0.163 ns |

The actual data edges are:

```text
group_bad[11] FF_X30_Y57_N49
  -> Equal12~2.DATAF / COMBOUT   LABCELL_X29_Y53_N48
  -> errors[16]~7.DATAF / COMBOUT MLABCELL_X28_Y47_N12
  -> errors[18].ENA             FF_X29_Y47_N56
```

The LUT arcs on this path are 94 ps and 91 ps under the native Quartus model. The final ENA LUT is adjacent to the errors-register cluster at X29/Y46–47. The first wire and the partial-to-terminal wire still cross several rows; the path is not entirely one-LAB-local. Reported data delay also includes the sink's modeled 684 ps cell term, so it cannot be equated with the OSS sum without calibrating both timing models.

The three bad-data partial NOR outputs each have **131 direct consumers**, and the terminal ENA has **44 FF consumers** (32 original error bits plus twelve duplicates). Large partial fanout is compatible with this two-level fitted path; low logic depth and terminal locality are the evidence, not a rule that fanout alone predicts delay.

## Complete eleven-LUT ENA cone

The bounded atom extraction contains 61 atoms: eleven `LCELL_COMB` nodes and fifty FF leaves. The leaves are sixteen group_bad bits, one group_valid FF, one hold FF and thirty-two errors-bit representatives, some supplied by explicitly named routing duplicates. No LCELL input has an inversion, logical-VCC or logical-GND flag. Unconnected physical pins are unused dimensions of the padded truth table, not guessed constants.

All masks below were checked across their 64 physical rows using the retained convention:

```text
value(row) = (int(mask, 16) >> (63 - row)) & 1
row = DATAA + 2*DATAB + 4*DATAC + 8*DATAD + 16*DATAE + 32*DATAF
```

Leading zeroes in a returned short mask are significant padding to 64 bits. OSS `parameters.LUT` uses its separate LSB-first convention and must not be decoded this way.

Define `B0..B15 = group_bad[0..15]`, `E0..E31 = errors[0..31]` (with the actual fitted duplicate source where listed), `V = group_valid` and `H = p2_hold_sync[1]`. The complete fitted functions are:

| Atom / name | Connected DATAA..DATAF order (unused shown “–”) | Raw mask | Function | Location / fanout |
| --- | --- | --- | --- | --- |
| 10419 / Equal12~0 | B14, –, B12, B15, –, B13 | `A000A00000000000` | `P0 = ~B12 & ~B13 & ~B14 & ~B15` | LAB29,54,N51 / 131 |
| 10426 / Equal12~1 | B2, B1, B5, B4, B0, B3 | `8000000000000000` | `P1 = ~B0 & ... & ~B5` | MLAB28,53,N18 / 131 |
| 10433 / Equal12~2 | B6, B10, B8, B7, B9, B11 | `8000000000000000` | `P2 = ~B6 & ... & ~B11` | LAB29,53,N48 / 131 |
| 10434 / errors[16]~0 | –, –, E30, –, –, E31 duplicate | `000000000F0F0F0F` | `S0 = E30 & E31` | LAB29,46,N45 / 1 |
| 10435 / errors[16]~1 | E29, E26, E25, E28, E27, E24 duplicate | `0000000000000001` | `S1 = E24 & ... & E29` | LAB29,46,N54 / 1 |
| 10436 / errors[16]~2 | E21, E22 duplicate, E20 duplicate, E23, E19, E18 | `0000000000000001` | `S2 = E18 & ... & E23` | MLAB28,46,N33 / 1 |
| 10437 / errors[16]~3 | E17 duplicate, E14, E13 duplicate, E16 duplicate, E12, E15 duplicate | `0000000000000001` | `S3 = E12 & ... & E17` | MLAB28,47,N18 / 1 |
| 10438 / errors[16]~4 | E1 duplicate, E0, E3, E4, E2, E5 | `0000000000000001` | `S4 = E0 & ... & E5` | MLAB28,47,N30 / 1 |
| 10439 / errors[16]~5 | E10, E8, E7, E6, E9 duplicate, E11 | `0000000000000001` | `S5 = E6 & ... & E11` | MLAB28,47,N36 / 1 |
| 10440 / errors[16]~6 | S5, S0, S3, S4, S1, S2 | `0000000000000001` | `SAT = S0 & S1 & S2 & S3 & S4 & S5` | MLAB28,47,N54 / 1 |
| 10441 / errors[16]~7 | P0, P1, SAT, V, H, P2 | `FFFF00F0FFFF00E0` | `ENA = ~H | (V & ~SAT & ~(P0 & P1 & P2))` | MLAB28,47,N12 / 44 |

The root is a full six-essential-input function on its physical frontier. Quartus omits an intermediate aggregate bad/valid gate: the three partial “all good” products enter the terminal ENA directly. Bad-bit-to-ENA is two LUT levels. Errors-bit-to-ENA uses a product leaf, the saturation root and the final enable, three LUT levels; the selected report did not measure every error-bit path or every bad-bit path.

The thirty-two errors-bit inputs are partitioned 2+6+6+6+6+6 before the saturation AND6, not a serial saturation chain. Ten of those source representatives are duplicates in this cone; the final ENA also drives all twelve fitted duplicate error registers. Names from the fit's duplication table provide the logical association; this ENA-only traversal does not separately prove every duplicate's D/initial-state equivalence to its original.

## ENA, synchronous clear and the apparent Boolean difference

The exact errors[18] input inventory reports:

```text
CLK   <- atom13681, port0
D     <- atom2422, port1
SCLR  <- H (atom4098, port0), is_inverted=1
ENA   <- atom10441, port0, is_inverted=0
```

Thus `SCLR = ~H`. The terminal includes `~H` in ENA so the synchronous clear is enabled. The local Quartus17 `cyclonev_atoms.v` model requires an enabled rising edge before applying SCLR (lines531–535), then clears Q before selecting D. Its primitive table independently gives ENA=1/SCLR=1 as synchronous clear, and ENA=0 as hold. The fitted reset case is therefore coherent with the RTL synchronous reset, rather than an extra increment condition:

```text
if H == 0: synchronous clear is enabled
else:      enable iff V && (group_bad != 0) && (errors != all-ones)
```

The ENA atom traversal deliberately did not expand CLK, D or SCLR upstream inputs, so it is not a full register-transition proof of the adder or the global reset generator.

The OSS terminal six-input expression is `(~H | R) & ~(x0 & x1 & x2 & x3)`. Its saturation tree embeds hold in the first partial, while the enable FF also has its inverted SCLR. The following closure uses the actual g8 routed graph and its **LSB-first** LUT masks. All listed LUT logical input states are plain signals; nontrivial physical pin assignments do not change the logical mask indexing. Raw net numbers are export-specific: g8's hold input is raw4242, while the earlier parent export used raw4241 for the corresponding control.

| OSS output raw bit | Mask / input composition | Derived function |
| --- | --- | --- |
| 4969 | ALUT6 `0x8000000000000000`, A..F = E4,E3,E2,E1,E0,H | `x0 = H & AND(E0..E4)` |
| 15947 | ALUT4 `0x8000`, A..D = E8,E7,E6,E5 | `AND(E5..E8)` |
| 4970 | ALUT5 `0x80000000`, A..E = E12,E11,E10,E9,raw15947 | `x1 = AND(E5..E12)` |
| 15945 | ALUT4 `0x8000`, A..D = E20,E19,E18,E17 | `AND(E17..E20)` |
| 4971 | ALUT5 `0x80000000`, A..E = E16,E15,E14,E13,raw15945 | `x2 = AND(E13..E20)` |
| 15940 | ALUT6 `0x8000000000000000`, A..F = E21..E26 | `AND(E21..E26)` |
| 15942 | ALUT5 `0x80000000`, A..E = E27..E31 | `AND(E27..E31)` |
| 4972 | Retained placed11 root ALUT2 `0x8`, A..B = raw15940,raw15942 | `x3 = AND(E21..E31)` |
| 4973 | ALUT2 `0xd`, A..B = H,R | `~H | R` |
| 4300 | Errors ENA ALUT5 `0x7fff0000`, A..E = x0,x1,x2,x3,raw4973 | `(~H | R) & ~(x0 & x1 & x2 & x3)` |

The first eight product masks each have exactly the single all-one logical row set, so the four terminal products partition all thirty-two error bits with hold included exactly once: `x0*x1*x2*x3 = H*SAT`. For the bad-data branch, masks `0x1`, `0x00010000`, `0x00010000` form NOR12 of logical bad bits `{0,3,5,6,8,9,10,11,12,13,14,15}`. The following ALUT6 `0xfffe0000ffff0000` has A..F = bad7,bad4,bad2,bad1,V,NOR12 and computes `R = V*(A|B|C|D|~F) = V*ANYBAD`, covering the remaining four bad bits. Each local mask function can be established with at most 64 rows; substituting these exact product functions avoids enumerating the full fifty-variable cone.

Consequently the observed OSS enable simplifies exactly:

```text
ENA_OSS = (~H | (V & ANYBAD)) & ~(H & SAT)
        = ~H | (V & ANYBAD & ~SAT)
ENA_fit = ~H | (V & ~SAT & ~(P0 & P1 & P2))
        = ~H | (V & ANYBAD & ~SAT)
```

The final sixteen conceptual assignments close that comparison independently of the raw leaf count. Order is `[H,V,ANYBAD,SAT]`, with H as row bit0; both derived functions have LSB-first conceptual mask **`0x55d5`** and nine true rows:

| Row | H | V | ANYBAD | SAT | OSS ENA | Fitted ENA |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| 2 | 0 | 1 | 0 | 0 | 1 | 1 |
| 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| 4 | 0 | 0 | 1 | 0 | 1 | 1 |
| 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| 6 | 0 | 1 | 1 | 0 | 1 | 1 |
| 7 | 1 | 1 | 1 | 0 | 1 | 1 |
| 8 | 0 | 0 | 0 | 1 | 1 | 1 |
| 9 | 1 | 0 | 0 | 1 | 0 | 0 |
| 10 | 0 | 1 | 0 | 1 | 1 | 1 |
| 11 | 1 | 1 | 0 | 1 | 0 | 0 |
| 12 | 0 | 0 | 1 | 1 | 1 | 1 |
| 13 | 1 | 0 | 1 | 1 | 0 | 0 |
| 14 | 0 | 1 | 1 | 1 | 1 | 1 |
| 15 | 1 | 1 | 1 | 1 | 0 | 0 |

This proves the reset-aware terminal control algebra under the stated logical source/fit-duplicate associations; it does not prove global reset generation, duplicate register transitions, the adder or whole-design equivalence. The imported Quartus term `~H` is a synchronous-clear case, not a new data-error term. Comparing the six terminal boundary symbols before substituting their source functions would incorrectly suggest a Boolean difference.

## Small generic OSS opportunity and downstream graph

The measured g8 bad-data branch is:

```text
NOR4 mask0x1
 -> ALUT5 mask0x00010000 (four more zero literals + preceding product)
 -> ALUT5 mask0x00010000 (four more zero literals + preceding product)
 -> valid/anybad ALUT6 mask0xfffe0000ffff0000
 -> ALUT2 mask0xd
 -> errors ENA ALUT5 mask0x7fff0000
 -> errors FF ENA
```

The first three LUTs form a read-once **twelve-literal NOR cube**, with two private intermediates. Existing source6ad recognition accepts exactly eleven literals in a three-cell cone, so it excludes this twelve-literal case even though the symbolic single-assignment test succeeds. The narrow proposed extension is generic three-cell **7..12 distinct-literal** pure-cube recognition, with deterministic ceil/floor leaf sizes. It retains eleven as 6+5 exactly, makes twelve 6+6, retains all three cell/net owners, and keeps the public cube root and its user slots. It removes one logical level from the bad-data branch; it does not reproduce Quartus's direct-to-ENA partial-product factoring or guarantee a timing gain.

The actual NOR12 public root is
`ddr0_test.group_valid_MISTRAL_ALUT6_E_F_MISTRAL_ALUT5_Q.Q`, raw15930 at COMB17,16,43. Its only direct user is the valid/anybad ALUT6.F. That ALUT6.Q (raw15932) has two LUT users:

- `ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT2_B.B` -> raw4973, which drives 160 FF ENAs and the errors ALUT5.E.
- `ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT6_F.F` -> raw7416, which drives 35 FF ENAs.

The errors ALUT5.Q is raw4300 and drives the remaining 32 error-register ENAs. The five reachable output nets (15930,15932,4973,7416,4300) are distinct and have no combinational reconvergence or cycle. There are 227 downstream ENA endpoints; the existing two-leaf traversal's repeated-net rejection is not a barrier in this actual graph. All those endpoints, clocks, holds and affected-LAB legality still need qualification. Original FF BELs and outside physical pins/buffers must remain under the existing full-route preservation gates.

A broader future transformation could expose 4/6/6 bad-data products to an enable clone while retaining the shared public valid/anybad function, resembling the fitted frontier. That needs a separate generic structural proof and joint placement transaction: the whole bad cone has seventeen raw inputs, beyond the existing <=6 internal-cut and <=7 control-decomposition bounds. The failed terminal listing does not license bypassing those bounds or relaxing timing gates.

## Source identities used

| Input | SHA256 |
| --- | --- |
| New query record | `a2da4e1696d6d898c9e7481489a6e9da56f0eef6b2b0f1c0b3a235dcd0cbc929` |
| Exact timing report | `1e85467252b2f33b41710437847b0c9382e950a90712e22fe96eaa113210b077` |
| Atom inputs | `79a851939889909dc3c1329e414d0089fbe3c18b9e7d8416ca44b8ba34ced097` |
| Atom outputs | `0d98d5a0c05f49d05cef5307688df522cdcf30a85c8f28a87f8b9ae24f198218` |
| Quartus17 `eda/sim_lib/cyclonev_atoms.v` | `c05a72632ac99fc826c28372111a31a52959d54ec6fbc19656f559c8c90582bd` |
| Immutable g8 routed graph | `afb35eb2c43388d34c24a189b99ed283742cdb3d3375145b4d6dc66bcf2ae8bf` |
| Immutable g8 timing report | `483783b19557847b994e2ab0961c26fe0aec7b2b700d12691e92707fce006bd1` |
| Current `ddr_channel.v` RTL reference | `f0f6286143a292af490efa9d5ae5875d53690e9cc557127bf657050742710843` |

The record separately binds timing script `b344566b0165017fe96f25948c08e8937f774590a71850c89b214f1119166725`, atom script `5891bc3ed662ebe6b423f871f09b9e6e4b13f68f947785e9a22a507a1edba2ff`, both Quartus native binaries and all output artifacts. Existing sealed g8 routed JSON/report identities remain unchanged and are recorded in the prior full proof; this note adds no new routed measurement.
