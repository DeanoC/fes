# Exact retained-fit DDR0 group_bad[11] -> errors[18].ENA TimeQuest query.
# Run only against root's authenticated private copy; this does not refit.
# Usage: quartus_sta -t query-ddr0.tcl /absolute/project/top.qpf /new/output
if {[llength $quartus(args)] != 2} {
    error "Usage: query-ddr0.tcl project.qpf output-directory"
}
set project [file normalize [lindex $quartus(args) 0]]
set output [file normalize [lindex $quartus(args) 1]]
file mkdir $output
set expected_build_id 52991ce22369904849b68bdd900f9ae1
set oss_build_id 7168b508ab424b70f1c0f87b2035d821
set qsf [file rootname $project].qsf
set qsf_file [open $qsf r]
set qsf_text [read $qsf_file]
close $qsf_file
set observed_build_id MISSING
regexp {RAMTEST_BUILD_ID=128'h([0-9a-fA-F]{32})} $qsf_text ignored observed_build_id
set observed_build_id [string tolower $observed_build_id]
set identity [open [file join $output identity.txt] {WRONLY CREAT EXCL}]
puts $identity "script [file normalize [info script]]"
puts $identity "project $project"
puts $identity "project_manifest [file join [file dirname [file dirname $project]] project-inputs.json]"
puts $identity "expected_quartus_build_id $expected_build_id"
puts $identity "observed_quartus_build_id $observed_build_id"
puts $identity "frozen_oss_build_id $oss_build_id"
puts $identity "classification retained-fit mapping evidence; BUILD_IDs and native PLL/SDC/timing models differ; no OSS timing calibration or hardware acceptance"
puts $identity "model slow temperature_C=100 voltage_mV=1100"
if {[info exists quartus(version)]} {puts $identity "quartus_version $quartus(version)"}
set missing {}
foreach relative {top.qpf top.qsf clocks.sdc db/top.cmp.hdb db/top.routing.rdb db/top.sta_cmp.7_slow_1100mv_100c.tdb} {
    set path [file join [file dirname $project] $relative]
    if {![file isfile $path] || [file size $path] == 0} {
        lappend missing $relative
        puts $identity "input $relative MISSING_OR_EMPTY"
    } else {
        puts $identity "input $relative bytes=[file size $path] mtime=[file mtime $path]"
    }
}
close $identity
if {[llength $missing]} {error "Retained fitted inputs missing or empty: $missing"}
if {$observed_build_id != $expected_build_id} {error "Unexpected retained Quartus BUILD_ID: $observed_build_id"}

cd [file dirname $project]
project_open [file rootname [file tail $project]]
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist

# Enumerate the actual current-fit names before relying on any bus-index glob.
set registers [get_registers {*ddr0_test*}]
set register_file [open [file join $output registers.tsv] {WRONLY CREAT EXCL}]
puts $register_file "id\tname\texact_role"
set exact_launch_count 0
set exact_capture_register_count 0
set relevant_register_count 0
foreach_in_collection register $registers {
    set name [get_register_info -name $register]
    if {![regexp {ddr0_test\|(group_bad|errors)\[} $name]} {continue}
    incr relevant_register_count
    set role {}
    if {[regexp {ddr0_test\|group_bad\[11\]$} $name]} {
        incr exact_launch_count
        set role launch_group_bad11
    }
    if {[regexp {ddr0_test\|errors\[18\]$} $name]} {
        incr exact_capture_register_count
        set role capture_errors18
    }
    puts $register_file "$register\t$name\t$role"
}
close $register_file
set pins [get_pins -compatibility_mode {*ddr0_test*}]
set pin_file [open [file join $output pins.tsv] {WRONLY CREAT EXCL}]
puts $pin_file "id\tname\texact_role"
set exact_capture_pin_count 0
set relevant_pin_count 0
foreach_in_collection pin $pins {
    set name [get_pin_info -name $pin]
    if {![regexp {ddr0_test\|(group_bad|errors)\[} $name]} {continue}
    incr relevant_pin_count
    set role {}
    if {[regexp {ddr0_test\|errors\[18\]\|ena$} $name]} {
        incr exact_capture_pin_count
        set role capture_errors18_ENA
    }
    puts $pin_file "$pin\t$name\t$role"
}
close $pin_file

# '?' matches each literal bus bracket; this spelling worked in retained queries.
set launch [get_registers {*ddr0_test*group_bad?11?}]
set capture [get_pins -compatibility_mode {*ddr0_test*errors?18?|ena}]
set launch_count [get_collection_size $launch]
set capture_count [get_collection_size $capture]
set counts [open [file join $output counts.txt] {WRONLY CREAT EXCL}]
puts $counts "all_ddr0_registers [get_collection_size $registers]"
puts $counts "group_bad_errors_registers $relevant_register_count"
puts $counts "all_ddr0_pins [get_collection_size $pins]"
puts $counts "group_bad_errors_pins $relevant_pin_count"
puts $counts "enumerated_exact_launch_group_bad11 $exact_launch_count"
puts $counts "enumerated_exact_capture_errors18 $exact_capture_register_count"
puts $counts "enumerated_exact_capture_errors18_ENA $exact_capture_pin_count"
puts $counts "query_launch_count $launch_count"
puts $counts "query_capture_pin_count $capture_count"
foreach_in_collection register $launch {puts $counts "query_launch_name [get_register_info -name $register]"}
foreach_in_collection pin $capture {puts $counts "query_capture_name [get_pin_info -name $pin]"}
close $counts
post_message "DDR0 exact query: group_bad11 registers=$exact_launch_count; errors18 registers=$exact_capture_register_count; errors18 ENA pins=$exact_capture_pin_count; query launch=$launch_count capture=$capture_count"
if {$exact_launch_count != 1 || $exact_capture_register_count != 1 ||
    $exact_capture_pin_count != 1 || $launch_count != 1 || $capture_count != 1} {
    project_close
    error "Exact DDR0 endpoints did not resolve uniquely; inspect registers.tsv, pins.tsv and counts.txt"
}
set report [file join $output group_bad11-errors18-ena.rpt]
if {[file exists $report]} {
    project_close
    error "Refusing to overwrite prior timing report: $report"
}
report_timing -setup -from $launch -to $capture -npaths 8 -detail full_path -show_routing -file $report
project_close
