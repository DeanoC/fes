# Combined current-prefix driver qualification and full route

Root executes preparation and routing. The current closed 22-slot conditional
baseline proof, its original flat artifact/runtime closure and the exact
5dd compiler binary/source archive are rebound directly. No historical
comparator, generator, recursive source authenticator or build runs. The
existing frozen compiler path is retained; no copied source or tool alias is
needed. New helper and scope hashes are explicit preparation arguments, then
the resulting immutable source-identity hash authorizes the exact route.

The current baseline command changes only by removing --no-route, replacing
write/report output paths, and adding the fresh baseline report as driver
guide, candidate0 and a new RBF path. All other RTL, constraints, options,
8/8/1 local plan and original guides, seed, diagnostic environment and GPU1
remain exact. The actual complete runtime snapshot must equal the baseline.
The selected driver must freshly emit discovery/trial/candidate0/application;
its actual site comes from the guarded trial, never the old selected site.
The declared source-to-arithmetic.A edge remains the existing burst driver
case. Any different edge, missing qualifying candidate or failed route rejects.

Before execution, the new profile names all22 baseline ENA transfers and every
original FF in the eight affected whole LABs, with exported controls, data,
outputs, parameters, directions and fixed BELs. The later physical comparison
must validate the ready inner/outer/folded LUT banks and input polarity,
conditional equivalence of the redirected enable, shared controls/selectors
for all those LAB members, actual selected driver-copy source/clone/sink/carry
ALM closure, and all original cells/nets and late buffer aliases. A declared
scope is not an independent physical proof or acceptance waiver.

The recorder binds actual completion, fresh compiled driver guards, all four
full outputs, reported Fmax and the LAST signoff hold diagnostic. It grants
no numerical STA, physical Boolean, native graph, CRAM/pip/GPU-ID, RBF-byte,
gain or hardware acceptance. The independent full-result comparison must
require memory strictly above117.34334564208984MHz, the actual non-target
clock constraints and every non-target clock-pair window positive, zero last
signoff holds and the full structural/physical proof. A lower positive margin
is disclosed; the all-clock nonregression comparison remains diagnostic.
