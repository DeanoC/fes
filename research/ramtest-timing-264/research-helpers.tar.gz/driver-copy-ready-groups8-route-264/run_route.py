"""Frozen combined fresh-driver qualification/full route; recorder, not acceptance."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
BASELINE = HERE.parent / "driver-copy-ready-groups8-264"
PROOF = BASELINE / "baseline/comparison-changed.json"
FOLDER = HERE / "route-c0"
PROFILE = HERE / "source-identity.json"
COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"
IDENTITY_SHA = "a256b4d4cf5a6efa9fdf7b89bce6e1b46164445315fef1a6f1c4521f7d21383c"
BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
PURE = HERE.parent / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SOURCE = "ddr0_test.burst_MISTRAL_ALUT3_Q"
SINK = "ddr0_test.cmd_following_MISTRAL_ALUT_ARITH_SO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_SO_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_Q_C_MISTRAL_ALUT_ARITH_SO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON field: " + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected), "invalid SHA256")
    require(path not in inputs or inputs[path] == expected, "conflicting original pathname hash")
    require(sha(path) == expected, "original artifact changed: " + path)
    inputs[path] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "bound original pathname changed: " + path)


def command(baseline):
    result = list(baseline["command"])
    require(result.count("--no-route") == 1 and not any(flag in result for flag in
        ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "baseline selectors unexpected")
    result.remove("--no-route")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector")
        result[result.index(flag) + 1] = str(path)
    result += ["--remap-lut-driver-critical", str(BASELINE / "baseline/timing.json"),
        "--remap-lut-driver-candidate", "0", "--rbf", str(FOLDER / "core.rbf")]
    return result


def prepare(proof_sha, self_sha, scope_sha):
    require(not PROFILE.exists() and not FOLDER.exists(), "fresh route profile/output already exists")
    inputs = {}
    for path, expected in ((PROOF, proof_sha), (HERE / "run_route.py", self_sha), (HERE / "scope.md", scope_sha)):
        bind(inputs, path, expected)
    proof = read(PROOF)
    require(proof["schema"] == 1 and proof["phase"] == "ready-groups8-explicit-ena-slot-ledger" and
        proof["compiler_commit"] == COMMIT and proof["source_identity_sha256"] == IDENTITY_SHA and
        proof["candidate_completed"] is True and proof["serialized_native_graph_proof_available"] is True and
        proof["structural_rejection"] is None and proof["current_native_paths_valid"] is True and
        proof["explicit_22_slot_conditional_proof"] is True and
        proof["fresh_driver_guide_available_after_serialized_logical_proof"] is True and
        proof["declared_ena_redirect_count"] == 22 and proof["whole_selected_lab_group_count"] == 8 and
        proof["final_original_path_metadata_and_runtime_hashes_stable"] is True, "fresh baseline lacks its closed bounded proof")
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "runtime pathname is not absolute")
        bind(inputs, name, expected)
    identity, baseline = read(BASELINE / "source-identity.json"), read(BASELINE / "baseline/run.json")
    require(inputs[str(BASELINE / "source-identity.json")] == IDENTITY_SHA and
        inputs[str(BASELINE / "baseline/run.json")] == proof["current_baseline_run_sha256"] and
        identity["result_commit"] == baseline["compiler_commit"] == COMMIT and
        identity["binary_sha256"] == baseline["binary_sha256"] == BINARY_SHA and
        identity["source_archive_sha256"] == baseline["source_archive_sha256"] == ARCHIVE_SHA and
        baseline["completed"] is True and baseline["exit_code"] == 0 and baseline["compiler_read_audit_passed"] is True and
        all(inputs.get(path) == expected for path, expected in {**baseline["input_sha256"],
            **baseline["output_sha256"], **baseline["execution"]["files"]}.items()), "closed baseline/source/runtime identity differs")
    require(baseline["command"] == identity["command"] and baseline["diagnostic_environment"] == identity["diagnostic_environment"] and
        baseline["cwd"] == str(MODULE) and baseline["execution"]["gpu_device"] == 1 and
        baseline["command"][0] == str(BASELINE / "nextpnr-mistral") and
        inputs[str(BASELINE / "nextpnr-mistral")] == BINARY_SHA and
        inputs[str(BASELINE / "source.tar.gz")] == ARCHIVE_SHA, "current exact compiler invocation differs")
    require([SOURCE, SINK, "A"] in proof["reported_relevant_lut_to_arithmetic_edges"], "fresh guide lacks the declared driver edge")
    bind(inputs, PURE, PURE_SHA)
    spec = importlib.util.spec_from_file_location("ready_route_scope_native", PURE)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    top = native.read_netlist(BASELINE / "baseline/placed.json")["modules"]["top"]
    labs = {tuple(row["lab"]) for row in proof["local_model"]["whole_selected_lab_groups"]}
    require(labs == {(23, 12), (24, 12), (25, 20), (27, 21), (28, 21), (29, 12), (29, 20), (29, 21)}, "physical LAB scope changed")
    all_ffs = []
    for name, cell in top["cells"].items():
        if cell["type"] != "MISTRAL_FF":
            continue
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None, "original FF lacks its placed BEL")
        if tuple(map(int, match.groups()[:2])) in labs:
            all_ffs.append({"cell": name, "bel": cell["attributes"]["NEXTPNR_BEL"], "connections": cell["connections"],
                "parameters": cell["parameters"], "port_directions": cell["port_directions"]})
    require(set(row["cell"] for row in proof["declared_ena_redirects"]) <= {row["cell"] for row in all_ffs}, "ENA scope misses a FF")
    result = {"schema": 1, "phase": "ready-groups8-combined-fresh-driver-full-route", "compiler_commit": COMMIT,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "prefix_proof_sha256": proof_sha,
        "prefix_source_identity_sha256": IDENTITY_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "command": command(baseline), "cwd": baseline["cwd"], "diagnostic_environment": baseline["diagnostic_environment"],
        "baseline_execution": baseline["execution"], "input_sha256": dict(sorted(inputs.items())),
        "declared_driver_edge": [SOURCE, SINK, "A"], "driver_candidate": 0, "driver_site_must_qualify_freshly": True,
        "declared_ena_redirects": proof["declared_ena_redirects"], "affected_whole_labs": sorted(map(list, labs)),
        "all_original_ff_members_in_affected_labs": sorted(all_ffs, key=lambda row: row["cell"]),
        "minimum_accepted_memory_mhz": 117.34334564208984, "routed_graph_proof_available": False,
        "physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs)
    with PROFILE.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "affected_labs": result["affected_whole_labs"],
        "original_ffs_in_affected_labs": len(all_ffs)}, indent=2))


def qualification(log):
    discovery = re.findall(r"^Info: LUT driver copy discovery: (\d+) bounded data edges\.$", log, re.M)
    sources = re.findall(r"^Info: LUT driver copy discovery source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) users=(\d+) rows=(\d+)$", log, re.M)
    domains = re.findall(r"^Info: LUT driver copy domains source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) endpoints=(\d+) timed_pairs=(\d+) unrelated_pairs=(\d+) hold_pairs=(\d+) reference_free=([01])$", log, re.M)
    require(discovery == ["1"] and sources == [(SOURCE, SINK, "A", "49", "8")] and len(domains) == 1 and
        domains[0][:3] == (SOURCE, SINK, "A"), "fresh driver discovery/source/domain coverage differs")
    endpoint_count, timed, unrelated, hold, reference_free = map(int, domains[0][3:])
    require(endpoint_count > 0 and timed + unrelated >= endpoint_count and hold <= timed + unrelated and
        reference_free == int(unrelated > 0), "fresh driver pair coverage is incomplete")
    candidates = list(re.finditer(r"^Info: LUT driver copy candidate (\d+): source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps\.$", log, re.M))
    trials = list(re.finditer(r"^Info: LUT driver copy trial source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])$", log, re.M))
    applications = list(re.finditer(r"^Info: LUT driver copy applied candidate (\d+); full routing and signoff still required\.$", log, re.M))
    require(len(candidates) == len(applications) == 1 and trials and
        candidates[0].groups()[0:4] == ("0", SOURCE, SINK, "A") and applications[0][1] == "0" and
        trials[-1].end() < candidates[0].start() < applications[0].start(), "fresh selected driver qualification missing")
    chosen, trial = candidates[0].groups()[1:], trials[-1].groups()
    require(chosen == trial[:5] and trial[5:] == ("1", "1", "1", "1") and int(trial[4]) >= 250,
        "selected driver does not bind its fresh final guarded trial")
    return {"source": SOURCE, "sink": SINK, "port": "A", "candidate": 0, "bel": trial[3], "gain_ps": int(trial[4]),
        "actual_trial_count": len(trials), "domain_summary": list(domains[0][3:]),
        "compiler_model_guards_passed": True, "independent_sta_proved": False}


def route(profile_sha):
    inputs = {}
    bind(inputs, PROFILE, profile_sha)
    profile = read(PROFILE)
    require(profile["compiler_commit"] == COMMIT and not FOLDER.exists(), "route output exists or compiler identity changed")
    for path, expected in profile["input_sha256"].items():
        bind(inputs, path, expected)
    require(inputs[str(HERE / "run_route.py")] == profile["helper_sha256"] and
        inputs[str(HERE / "scope.md")] == profile["scope_sha256"], "frozen helper/scope differs")
    baseline = read(BASELINE / "baseline/run.json")
    require(profile["command"] == command(baseline) and profile["baseline_execution"] == baseline["execution"] and
        profile["diagnostic_environment"] == baseline["diagnostic_environment"], "frozen command/runtime differs")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    identity = f"base_commit={baseline['delta_base_commit']}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}"
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(Path(profile["command"][0]), identity)}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and
            not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual runtime/ambient diagnostics changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            result = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"],
                env={**invocation.env, **profile["diagnostic_environment"]}, stdout=output, stderr=subprocess.STDOUT,
                check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = result.returncode, True
        invocation.verify()
        require(result.returncode == 0, "full selected route failed")
        log = (FOLDER / "route.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            "Running the GPU router" in log and "Running signoff timing analysis..." in log and
            "Running predicted placed timing analysis for --report" not in log, "full GPU signoff provenance missing")
        record["actual_fresh_driver_qualification"] = qualification(log)
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0
                for row in report["fmax"].values() for value in row.values()), "fresh full timing report invalid")
        record["fmax"] = report["fmax"]
        record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "full actual output missing")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]})
        record["completed"] = True
        print(json.dumps({"completed": True, "fmax": record["fmax"], "driver": record["actual_fresh_driver_qualification"],
            "final_reported_hold_violations": record["final_reported_hold_violations"], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        record["elapsed_seconds"] = time.monotonic() - started
        if FOLDER.exists():
            (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "route"))
    parser.add_argument("--prefix-proof-sha256")
    parser.add_argument("--self-sha256")
    parser.add_argument("--scope-sha256")
    parser.add_argument("--profile-sha256")
    args = parser.parse_args()
    if args.phase == "prepare":
        require(all((args.prefix_proof_sha256, args.self_sha256, args.scope_sha256)), "prepare pins missing")
        prepare(args.prefix_proof_sha256, args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256 is not None, "route profile pin missing")
        route(args.profile_sha256)


if __name__ == "__main__":
    main()
