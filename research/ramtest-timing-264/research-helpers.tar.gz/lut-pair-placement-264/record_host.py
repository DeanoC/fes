"""Record completed isolated LUT-pair host checks without rerunning them."""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import re
import shlex
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TOOL = ROOT / "sources/misteross/build/toolchain-ramtest-timing"
SOURCE, BUILD = TOOL / "src/nextpnr-lut-pair-placement-264", TOOL / "build/nextpnr-lut-pair-placement-264"
MODEL = TOOL / "src/mistral"
BASE = "b3d036549c29a333e67c61bd1b23e705bce75d41"
MODEL_COMMIT = "7ed06e21c18b047ec5c6d6a7e85e5ea2c8827039"
CHANGED = {"mistral/CMakeLists.txt", "mistral/arch.h", "mistral/arch.cc", "mistral/lut_driver_copy.cc",
    "mistral/main.cc", "mistral/lut_pair_placement.cc", "mistral/lut_pair_placement.h", "mistral/remap_clock_guard.h",
    "mistral/tests/lut_pair_placement.cc", "mistral/tests/lut_pair_placement_cli.py", "mistral/lut_pair_placement.md"}
SUBMODULES = {"3rdparty/googletest": "52eb8108c5bdec04579160ae17225d66034bd723",
    "tests": "ce154121819a04ec921a4a6f6850c28f33c81b6c"}
NATIVE_FILTER = "LutPairPlacementTest.*:LutDriverCopyTest.*:LocalRemapPlanTest.*"
CLI_FILTER = "nextpnr-mistral-(lut-pair-placement-cli|lut-driver-copy-cli|remap-plan-cli)"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def clean():
    for repo, commit in ((SOURCE, COMMIT), (MODEL, MODEL_COMMIT), *((SOURCE / name, commit) for name, commit in SUBMODULES.items())):
        require(git(repo, "rev-parse", "HEAD").decode().strip() == commit and not git(repo, "status", "--porcelain").strip(),
            "live source/model/required submodule is not clean at its declared commit: " + str(repo))


def tar_manifest(archive):
    result = {}
    for member in archive.getmembers():
        require(member.name not in result and not Path(member.name).is_absolute() and ".." not in Path(member.name).parts,
            "archive has a duplicate or escaping member")
        require(member.isfile() or member.isdir() or member.issym(), "unsupported committed archive member")
        result[member.name] = {"type": "file" if member.isfile() else "directory" if member.isdir() else "symlink",
            "mode": member.mode, "link": member.linkname,
            "sha256": hashlib.sha256(archive.extractfile(member).read()).hexdigest() if member.isfile() else None}
    return result


def dependency_words(text):
    text = text.replace("\\\n", " ")
    target, separator, text = text.partition(":")
    require(separator and target.endswith(".o") and "\x00" not in text, "unsupported object dependency syntax")
    words, word, escaped = [], [], False
    for char in text:
        if escaped:
            word.append(char); escaped = False
        elif char == "\\": escaped = True
        elif char.isspace():
            if word: words.append("".join(word).replace("$$", "$")); word = []
        else: word.append(char)
    require(not escaped, "dangling dependency escape")
    if word: words.append("".join(word).replace("$$", "$"))
    require(words, "empty object dependency list")
    return words


def main():
    global COMMIT
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "binary-sha256", "archive-sha256", "test-binary-sha256", "check-results-sha256"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--compiler-commit", required=True)
    args = parser.parse_args()
    COMMIT = args.compiler_commit
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) is not None, "real compiler commit required")
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for key, value in vars(args).items() if key != "compiler_commit"), "explicit real SHA pins required")
    validation, output, bound = HERE / "validation", HERE / "validation/host-validation.json", {}
    require(not output.exists(), "exclusive host record already exists")
    def bind(path, expected=None):
        path = Path(path).absolute()
        if str(path) in bound:
            require(expected is None or bound[str(path)] == expected, "conflicting original file identity")
            return bound[str(path)]
        digest = sha(path)
        require(expected is None or digest == expected, "original file hash differs: " + str(path))
        bound[str(path)] = digest
        return digest
    bind(Path(__file__).resolve(), args.self_sha256); bind(HERE / "host-scope.md", args.scope_sha256)
    clean()
    require(git(SOURCE, "merge-base", BASE, COMMIT).decode().strip() == BASE and
        set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).decode().splitlines()) == CHANGED, "reviewed eleven-file delta differs")
    for name, commit in SUBMODULES.items():
        require(git(SOURCE, "ls-tree", COMMIT, name).decode().split()[0:3] == ["160000", "commit", commit], "required gitlink differs")
    bind(HERE / "nextpnr-mistral", args.binary_sha256); bind(BUILD / "nextpnr-mistral", args.binary_sha256)
    bind(HERE / "source.tar.gz", args.archive_sha256); bind(BUILD / "nextpnr-mistral-test", args.test_binary_sha256)
    with tarfile.open(HERE / "source.tar.gz", "r:gz") as archive: archived = tar_manifest(archive)
    with tarfile.open(fileobj=io.BytesIO(git(SOURCE, "archive", "--format=tar", COMMIT)), mode="r:") as archive:
        require(archived == tar_manifest(archive), "complete frozen archive differs from the committed Git manifest")
    archive_files = {name: row["sha256"] for name, row in archived.items() if row["type"] == "file"}
    sources, child_sources, model_sources = {}, {}, {}
    def selected_source(path, digest):
        if path.is_relative_to(SOURCE):
            for name, commit in SUBMODULES.items():
                repo = SOURCE / name
                if path.is_relative_to(repo):
                    require(hashlib.sha256(git(repo, "show", commit + ":" + str(path.relative_to(repo)))).hexdigest() == digest,
                        "dependency submodule source differs from its selected commit")
                    child_sources[str(path)] = digest; return
            relative = str(path.relative_to(SOURCE))
            require(archive_files.get(relative) == digest, "live main-repository source differs from committed archive: " + relative)
            sources[str(path)] = digest
        elif path.is_relative_to(MODEL):
            require(hashlib.sha256(git(MODEL, "show", MODEL_COMMIT + ":" + str(path.relative_to(MODEL)))).hexdigest() == digest,
                "external model dependency differs from its unchanged selected commit")
            model_sources[str(path)] = digest
    for relative in sorted(CHANGED | {"mistral/tests/lut_driver_copy.cc", "mistral/tests/lut_driver_copy_cli.py", "mistral/tests/remap_plan.cc", "mistral/tests/remap_plan_cli.py"}):
        selected_source(SOURCE / relative, bind(SOURCE / relative))
    bind(BUILD / "CMakeCache.txt"); cache = (BUILD / "CMakeCache.txt").read_text()
    required_cache = {"ARCH:STRING": "mistral", "BUILD_TESTS:BOOL": "ON", "CMAKE_BUILD_TYPE:STRING": "Release",
        "GPU_ROUTER:STRING": "HIP", "CMAKE_HIP_ARCHITECTURES:UNINITIALIZED": "gfx1100;gfx1201", "USE_IPO:BOOL": "ON",
        "USE_OPENMP:BOOL": "OFF", "CMAKE_HOME_DIRECTORY:INTERNAL": str(SOURCE), "MISTRAL_ROOT:STRING": str(MODEL)}
    require(all(key + "=" + value + "\n" in cache for key, value in required_cache.items()), "actual build/cache/model configuration differs")
    dependencies, dependency_files = {}, {}
    manifests = sorted(BUILD.rglob("*.o.d"))
    required_objects = ("mistral/CMakeFiles/nextpnr-mistral.dir/main.cc.o.d", "mistral/CMakeFiles/nextpnr-mistral.dir/arch.cc.o.d",
        "mistral/CMakeFiles/nextpnr-mistral.dir/remap_plan.cc.o.d", "mistral/CMakeFiles/nextpnr-mistral.dir/lut_driver_copy.cc.o.d",
        "mistral/CMakeFiles/nextpnr-mistral-test.dir/tests/remap_plan.cc.o.d", "mistral/CMakeFiles/nextpnr-mistral-test.dir/tests/lut_driver_copy.cc.o.d",
        "mistral/CMakeFiles/nextpnr-mistral.dir/lut_pair_placement.cc.o.d",
        "mistral/CMakeFiles/nextpnr-mistral-test.dir/tests/lut_pair_placement.cc.o.d")
    require(manifests and all(BUILD / relative in manifests for relative in required_objects), "current production/test object dependency manifests absent")
    for manifest in manifests:
        dependencies[str(manifest)] = bind(manifest)
        for word in dependency_words(manifest.read_text()):
            path = Path(word) if Path(word).is_absolute() else BUILD / word
            resolved = path.resolve(strict=True)
            require(resolved.is_file(), "object dependency is not a file")
            digest = bind(path); require(bind(resolved) == digest, "dependency original and resolved files differ")
            if str(resolved) not in dependency_files:
                dependency_files[str(resolved)] = digest; selected_source(resolved, digest)
    bind(validation / "check-results.json", args.check_results_sha256)
    exits = json.loads((validation / "check-results.json").read_text())
    require(exits.get("schema") == 1 and exits.get("compiler_commit") == COMMIT and isinstance(exits.get("commands"), dict),
        "actual check-result schema/commit differs")
    commands = exits["commands"]
    require(set(commands) == {"configure", "build", "native", "cli"}, "closed actual command set differs")
    logs = {}
    for name, row in commands.items():
        require(isinstance(row, dict) and type(row.get("exit_code")) is int and row["exit_code"] == 0 and
            isinstance(row.get("command"), list) and row["command"] and all(isinstance(arg, str) and "\x00" not in arg for arg in row["command"]) and
            isinstance(row.get("elapsed_seconds"), (int, float)) and not isinstance(row["elapsed_seconds"], bool) and
            math.isfinite(row["elapsed_seconds"]) and row["elapsed_seconds"] >= 0 and
            Path(row.get("log_path", "")).parent == validation, "command did not close successfully: " + name)
        bind(row["log_path"], row.get("log_sha256")); logs[name + ".log"] = Path(row["log_path"]).read_text()
    require(commands["build"]["compiler_commit"] == commands["native"]["compiler_commit"] == COMMIT, "current native build/source commit differs")
    require(commands["build"]["command"] == ["cmake", "--build", str(BUILD), "--parallel", "6", "--target", "nextpnr-mistral", "nextpnr-mistral-test"],
        "actual final build invocation differs")
    require("Configuring done" in logs["configure.log"] and "Generating done" in logs["configure.log"] and
        "CMake Error" not in logs["configure.log"] and str(BUILD) in logs["configure.log"], "actual configure did not pass")
    require(all("Built target " + target in logs["build.log"] for target in ("nextpnr-mistral", "nextpnr-mistral-test")) and
        not re.search(r"(?:fatal )?error:|\] Error \d", logs["build.log"]), "current build failed")
    require(commands["native"]["command"] == [str(BUILD / "nextpnr-mistral-test"), "--gtest_filter=" + NATIVE_FILTER],
        "actual full native invocation differs")
    require(commands["cli"]["compiler_commit"] == COMMIT, "current production CLI commit differs")
    for name, pins in (("initial-73fba978", {
        "nextpnr-mistral": "e52036a1f86ec8a4e02aaee86a886186ea7f05a31d1ee9871be5731e9bd2fbd5",
        "nextpnr-mistral-test": "6b96979b4d7106bc6a82a1c90ed09151c2d24ef7d6f3f3e7217c9809e2946f18",
        "source.tar.gz": "2d3c00768ad8c6b4f10f3963a4b11d12460d983f5a3c87faf3fa091472206a00"}),
        ("intermediate-9c1e22bb", {
        "nextpnr-mistral": "e52036a1f86ec8a4e02aaee86a886186ea7f05a31d1ee9871be5731e9bd2fbd5",
        "nextpnr-mistral-test": "008bc2f2fdc0abd4df739a07cfbacf25b9e24045b70b6c06420ee1dfaf7c3acb",
        "source.tar.gz": "e711522b4f6b8faa79636feff0b354f6517a3e5ee98d0890ddcb62c93455bb94"}),
        ("hold-seven-stage-4dc2067b", {
        "nextpnr-mistral": "1b4e45ac1adc5adf9be8edcfa67b922d7626504dc0bbc73f24ffb69b263f4b1f",
        "nextpnr-mistral-test": "678991bae712e90390b883554f75c31385d19b15b452f0c3f87492af8e2e3c41",
        "source.tar.gz": "0369673006011955a072abb2a4ace5450ea8858fc8d73e6f5a3e694690f78354"})):
        bind(validation / name / "artifacts.json")
        for filename, pin in pins.items(): bind(validation / name / filename, pin)
    failed = {}
    for name in exits.get("preserved_failed_attempts", []):
        path = validation / name
        require(path.parent == validation and path.name == name, "failed attempt path escapes validation")
        bind(path); row = json.loads(path.read_text())
        require(type(row.get("exit_code")) is int and row["exit_code"] != 0 and Path(row["log_path"]).parent == validation,
            "preserved failed attempt lacks actual failure")
        bind(row["log_path"], row["log_sha256"]); failed[name] = row
    require({"native-first-run.json", "native-second-run.json", "native-targeted-third-run.json"}.issubset(failed), "initial native failures must remain recorded")
    last_path, ctest_path = BUILD / "Testing/Temporary/LastTest.log", BUILD / "mistral/CTestTestfile.cmake"
    bind(last_path); bind(ctest_path); last = last_path.read_text()
    cli_command = commands["cli"]["command"]
    require(Path(cli_command[0]).name == "ctest", "actual CLI launcher is not CTest")
    cli_args = cli_command[1:]
    if "--test-dir" in cli_args:
        index = cli_args.index("--test-dir")
        require(cli_args[index:index + 2] == ["--test-dir", str(BUILD)], "actual CTest build directory differs")
        cli_args = cli_args[:index] + cli_args[index + 2:]
    else:
        require(commands["cli"].get("cwd") == str(BUILD), "implicit CTest build cwd is not bound")
    require(cli_args == ["-R", CLI_FILTER, "-j2", "--output-on-failure"], "actual three-script CTest invocation differs")
    expected, checks = [], {}
    for key, suite, relative in (("pair_backend", "LutPairPlacementTest", "mistral/tests/lut_pair_placement.cc"),
        ("native_plan", "LocalRemapPlanTest", "mistral/tests/remap_plan.cc"),
        ("driver_backend", "LutDriverCopyTest", "mistral/tests/lut_driver_copy.cc")):
        names = re.findall(r"\bTEST_F\s*\(\s*" + suite + r"\s*,\s*(\w+)\s*\)", (SOURCE / relative).read_text())
        names = [suite + "." + name for name in names]
        require(names and len(names) == len(set(names)), "committed native declaration names are absent or duplicated")
        expected.extend(names)
        elapsed = re.findall(r"\[----------\] " + str(len(names)) + " tests from " + suite + r" \((\d+) ms total\)", logs["native.log"])
        require(len(elapsed) == 1, "closed native suite duration absent: " + suite)
        checks[key] = {"passed": True, "exit_code": 0, "cases": len(names), "case_names": names, "reported_elapsed_seconds": int(elapsed[0]) / 1000}
    ran = re.findall(r"\[\s*RUN\s*\]\s+(\S+)", logs["native.log"])
    okay = re.findall(r"\[\s*OK\s*\]\s+(\S+) \(\d+ ms\)", logs["native.log"])
    elapsed = re.findall(r"\[==========\] " + str(len(expected)) + r" tests from 3 test suites ran\. \((\d+) ms total\)", logs["native.log"])
    require(len(ran) == len(okay) == len(expected) and set(ran) == set(okay) == set(expected) and
        "Google Test filter = " + NATIVE_FILTER in logs["native.log"] and "[  PASSED  ] " + str(len(expected)) + " tests." in logs["native.log"] and
        len(elapsed) == 1 and not re.search(r"\[\s*(?:FAILED|SKIPPED)\s*\]", logs["native.log"]), "native log does not close every current declared case")
    blocks = list(re.finditer(r"(?m)^\d+/\d+ Testing: (\S+)$", last))
    require(len(blocks) == 3 and "End testing:" in last and "100% tests passed, 0 tests failed out of 3" in logs["cli.log"], "actual three-script CTest completion absent")
    test_blocks = {match[1]: last[match.start():blocks[index + 1].start() if index + 1 < len(blocks) else len(last)] for index, match in enumerate(blocks)}
    require(set(test_blocks) == {"nextpnr-mistral-remap-plan-cli", "nextpnr-mistral-lut-driver-copy-cli", "nextpnr-mistral-lut-pair-placement-cli"}, "LastTest contains different scripts")
    registration = ctest_path.read_text()
    for key, test, filename, suite in (("pair_cli", "nextpnr-mistral-lut-pair-placement-cli", "lut_pair_placement_cli.py", "LutPairPlacementCliTest"),
        ("remap_plan_cli", "nextpnr-mistral-remap-plan-cli", "remap_plan_cli.py", "RemapPlanCliTest"),
        ("driver_cli", "nextpnr-mistral-lut-driver-copy-cli", "lut_driver_copy_cli.py", "LutDriverCopyCliTest")):
        script, block = SOURCE / "mistral/tests" / filename, test_blocks[test]
        names = re.findall(r"(?m)^\s+def (test_\w+)\(", script.read_text())
        okay = re.findall(r"(?m)^(test_\w+) \(__main__\." + suite + r"\.\1\) \.\.\. ok$", block)
        durations = re.findall(r"Ran " + str(len(names)) + r" tests in ([\d.]+)s\s+OK\s*<end of output>", block)
        command = re.findall(r"(?m)^Command: (.+)$", block)
        actual = shlex.split(command[0]) if len(command) == 1 else []
        require(names and len(names) == len(set(names)) == len(okay) and set(names) == set(okay) and len(durations) == 1 and
            actual == ["/usr/bin/python3", str(script), str(BUILD / "nextpnr-mistral"), "-v"] and
            block.count("Test Passed.") == 1 and "Test Failed." not in block and test in registration and str(script) in registration,
            "closed actual CLI invocation/cases/registration differ: " + test)
        checks[key] = {"passed": True, "exit_code": 0, "cases": len(names), "case_names": names,
            "reported_elapsed_seconds": float(durations[0]), "actual_command": actual}
    record = {"schema": 1, "compiler_commit": COMMIT, "result_commit": COMMIT, "delta_base_commit": BASE,
        "clean_committed_checkout": True, "build_passed": True, "binary_sha256": args.binary_sha256,
        "source_archive_sha256": args.archive_sha256, "test_binary_sha256": args.test_binary_sha256,
        "source_sha256": dict(sorted(sources.items())), "source_submodule_file_sha256": dict(sorted(child_sources.items())),
        "external_model_source_sha256": dict(sorted(model_sources.items())), "changed_source_files": sorted(CHANGED),
        "required_submodule_commits": SUBMODULES, "external_model_path": str(MODEL), "external_model_commit": MODEL_COMMIT,
        "build_configuration": required_cache, "build_warning_line_count": len(re.findall(r"(?m)^.*\bwarning:", logs["build.log"])),
        "build_dependency_manifest_sha256": dict(sorted(dependencies.items())), "build_dependency_file_sha256": dict(sorted(dependency_files.items())),
        "committed_archive_manifest_sha256": archive_files, "complete_committed_archive_manifest": archived,
        "checks": checks, "closed_check_commands": commands, "native_reported_total_elapsed_seconds": int(elapsed[0]) / 1000,
        "artifact_sha256": dict(sorted(bound.items())), "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256,
        "check_results_sha256": args.check_results_sha256, "preserved_failed_attempts": failed, "cli_reused_on_exact_production_bytes": False, "initial_configure_passed": True,
        "initial_build_failure_recorded": False, "other_suites_claimed": False, "sixteen_successful_transformations_proved": False,
        "loaded_build_or_test_runtime_authenticated": False, "new_sta_or_routing_gain_claimed": False,
        "native_routed_or_physical_equivalence_proved": False, "hardware_tested": False, "recorder_reran_builds_tests_or_old_entrypoints": False}
    clean()
    require(all(sha(path) == expected for path, expected in bound.items()), "original host input changed before publication")
    with output.open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(json.loads(output.read_text()) == record, "new host record differs")
    clean()
    require(all(sha(path) == expected for path, expected in bound.items()), "original host input changed after publication")
    print(json.dumps({"host_validation_sha256": sha(output), "compiler_commit": COMMIT, "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
