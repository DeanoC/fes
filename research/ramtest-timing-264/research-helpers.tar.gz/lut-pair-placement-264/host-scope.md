# Isolated LUT-pair host record scope

The new record_host.py reads completed configure/build/native/CLI records and
logs, current CMake dependency manifests/cache/CTest registration, selected
committed sources/submodules/model, and the frozen current source archive and
executables. It writes only a new validation/host-validation.json using exclusive
creation. It does not rerun build/tests, execute any old helper entrypoint, import
old helpers, use a GPU, route a design, program hardware, or publish remotely.

Its explicit arguments bind its whole bytes, this scope, the current compiler
commit, production ELF, committed Git source archive, current test ELF, and
check-results.json. It verifies a clean source tree and exact eleven-file delta
from b3d03654; exact Git archive manifests; current production/test object source
dependencies; unchanged selected Mistral and required submodule commits; actual
Release/HIP configuration; actual closed successful final build and tests at
the current compiler commit; every declared native case and every CLI method
in all three registered suites. Native counts are derived from source; current
design expects twelve pair cases plus ten driver and twenty-five plan cases.
CLI expects eleven pair plus ten driver and twenty-four plan methods.

Both initial native failures, their actual exit codes, elapsed times and logs,
and initial/intermediate frozen source archives and ELF/test binaries remain
bound in the record. No earlier CLI success is relabelled as current: after the
pair-only hold-coverage guard changed production code, all three CLI suites must
run successfully at the current selected compiler commit. Additional failed
attempts must be retained by check-results.json rather than overwritten.

Dependency hashes bind original and resolved paths and compare selected main,
submodule and external-model source bytes with their committed bytes. This is
a host build/source closure record; it does not authenticate actual loaded
build/test libraries, calibrate numerical STA or physical routing models,
prove RAM-test equivalence, claim a timing gain, or claim hardware acceptance.
All bound files and clean Git identities are rechecked before and after the
single exclusive output. Old frozen measurements and archives are unchanged.
