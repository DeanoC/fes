# Fresh explicit port1 composed-copy selection recorder

This new author-only recorder is inactive until the fresh ready1 composed-copy
listing has a closed run and positive independent reproduction. Listing profile
6616243a, helper18884eb7 and scope5ae7fce2 are actual. Listing run/proof/final
comparer and the chosen selection/BEL remain UNFROZEN. Actual compiler cae5eb9a,
ELF a2b5da93, archive c64eb65c and host84416288 are already closed; the host binds
the reviewed nine-file delta, source/submodule/model/dependency/archive bytes,
all58 native cases and51 CLI methods. Historical failed build/native attempts
remain separate. ROOT alone imports, AST-checks, prepares or executes helpers.

Preparation requires explicit actual self/scope, listing profile/run/proof,
compiler/archive/host hashes and a nonnegative --candidate value matching the
later frozen observed selection and BEL. There is no default index or assumed
candidate, site, mask or gain. The listing proof must have positive native/TEN/
71-metric/full-report reproduction against e137 diagnostic12a957, prior5a
listing94627 and disabled-control9498, plus the separate nonzero-qualified
fresh_selected_composed_copy_prerequisite_available gate. Zero-qualified,
rejected or absent candidates reject before publishing any profile. All three
reference flat closures remain bound; no old operational entrypoint runs.

The exact new ready1 guide ea8eb811 and origin c95af436 retain current routed
row1 and tied row2975 unchanged. Their source profile79e71/runb76ff/report826d
and selected graph11b385 are provenance of the guide alone. No timing gain or
physical state is inherited. Fresh TEN plan00bf and original source JSON remain
unchanged. The preceding extra ready0 copy is replaced by this guide selector;
it is absent from the fresh TEN graph. Only the proved listing candidate value
-1 and write/report output aliases change for selection. No-route and explicit
compose-copy remain; post-plan, driver, replay, RBF and routing are excluded.
FunctionalInvocation environment/runtime bytes including PATH remain exact.

Candidate inner/outer/FF.ENA identities must match the bound guide's final two
routing edges. Candidate BEL, gain, cohort and guarded trial come from the
actual re-parsed closed listing, including any rejected preceding trials and
nonzero candidate ordinals. The selected fresh log must reproduce its exact
listing prefix through that candidate, followed by the sole matching applied
line and no later copy event or fabricated listing summary.

Before execution, the recorder derives all root-Q consumers in the terminal
LAB from fresh listing native cells and requires exactly the two same-clock
FF.ENA users declared by the positive ready1 listing and tied-path origin.
Pair/terminal/cohort full records, root/clock bits, both complete path objects,
the 15 original target-LAB FF records, all8,221 FF BELs and every original FF
in source/target/actual listed clone LABs are saved. This declares native scope;
it does not prove selected graph, Boolean truth, physical pins or FF caches.
The independent selected comparator must derive and prove the changes itself.

Only current listing pinned definitions/complete qualification, its eight
lower TEN parsers and32fd lossless native reader are called. The input union
binds all called pure helpers, the exact five loaded project modules, current
host maps, original sources/library inputs/runtime and guide source closures.
Clean committed source/dependencies and all original-path hashes are checked
before and after preparation and execution. No prior prepare/execute/main/auth/
comparison/equivalence evaluator is invoked.

Outputs are exclusive source-identity.json and selected/{run.json,phase.log,
placed.json,timing.json}. Actual invocation/read audit/source/runtime/input/
output closure must pass before completed=true. Partial failures retain actual
exit status, any partial outputs and the final rehash/runtime/source result.
Fresh TEN10 complete models, all71 placement rows and all8,221 FF BELs must
remain exact. The predicted report retains cap16,384, 15,290 paths and all seven
actual pair/window cardinalities, with finite positive Fmax. Full report
equality is recorded only diagnostically; selected path topology is independently
proved later.

Fresh selected native/function proof must account for one new LUT/private Q,
only declared leaf loads and the whole two-FF ENA cohort, with all other raw
IDs/order/metadata exact and independent exhaustive conditional truth. Placed
JSON does not export PIN0/PIN1/PIN_INV, indexed-store holes or controller caches.
Physical pins, effective masks, shared banks, protected carry neighbors and
whole LAB FF controls require later fresh routed snapshots. No selected graph/
function/cache proof, routed gain, calibration, bitstream decoding or hardware
claim is granted. The accepted five-stage117.771759MHz frame remains separate.

