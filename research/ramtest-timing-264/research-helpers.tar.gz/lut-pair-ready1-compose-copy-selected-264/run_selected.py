"""Record an explicit fresh composed-copy selection after independent listing reproduction."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-compose-copy-264"
COMPILER, LISTING = RAW / "lut-pair-compose-copy-264", RAW / "lut-pair-ready1-compose-copy-listing-264"
COMMIT, BASE = "cae5eb9a326507b688414ba934421286f648a43b", "e137ca5bda7c5e68e6da65f37b5830d12f58727a"
BINARY, ARCHIVE, HOST = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz", COMPILER / "validation/host-validation.json"
BINARY_SHA = "a2b5da93a9a91cd95d411fb5773e86136ff62e1fce7896d371c97c756004885e"
ARCHIVE_SHA, HOST_SHA = "c64eb65c4e1ac01a277322bddc90172be836fddd60f2d3a0baf66bad62522dd2", "84416288f9a9b4f85c956ad32dc264efc14d007d2d3278c3abc952a006cc6a1e"
TEST_SHA, CHECKS_SHA = "b0e912b15ebd4ce11cb56cec7a356809ce4bf84ef347851fbcccfbf978a20484", "f0b694224d40ae6eb8c081d13fd0cc1fc75c1e337bd7093168a7a3759a3b6721"
HOST_HELPER_SHA, HOST_SCOPE_SHA = "e5cf3243801bcf13f4aed5086ad4914502ed1765bbff15eedf7cf4d589157439", "071a7d054e6dafd79d92962ad0f9466d5987da9aa793a38de2b1c41f019b95a3"
LISTING_PROFILE, LISTING_RUN = LISTING / "source-identity.json", LISTING / "listing/run.json"
LISTING_PROOF = LISTING / "listing/comparison-copy-listing.json"
LISTING_PROFILE_SHA, LISTING_RUN_SHA, LISTING_PROOF_SHA = "6616243ae94f8bd0963be660bc4b4b3cbc64873b68296bf2792480638b8c0019", "540bb108cc203685edc1afa0d3fbd1cbe72c38e5a30801a8f17ce349f99ba942", "cf485b65ec575a78fa4f517df2a19ac251e615d19e5c2b42b0762d8def827fa7"
LISTING_HELPER_SHA, LISTING_SCOPE_SHA = "18884eb7ca69b2c5ed4da3f40fd2992c67124de7cce1cbadd677c805f46f73a4", "5ae7fce2c094dca99d5cb0950d7a8a4243b5229b0ce890adb99a0517ca8f5ecc"
LISTING_COMPARER_SHA, LISTING_COMPARISON_SCOPE_SHA = "ee330f56b91e59f97d4839f8d2e868ff7659615f81f5af6f27f8c2069cb4b5fb", "c34e1fe6483e86fa39b98970c576ad21dfd721c7b0ef6850410a5a9bb91ba3d4"
EXPECTED_SELECTION, EXPECTED_CLONE_BEL = "0", "MISTRAL_COMB.27.20.6"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
GUIDE_HOME = RAW / "lut-pair-ready1-compose-copy-plan-264"
GUIDE, GUIDE_SHA = GUIDE_HOME / "ready1-guide.json", "ea8eb8119decde1de7e4437bdc96a22678145678228037c48dce08936d8a5c31"
GUIDE_ORIGIN, GUIDE_ORIGIN_SHA = GUIDE_HOME / "guide-origin.json", "c95af4366f8aeaf22e394618cd68d44fbced0b62bf93125d70662064a0c8f5e2"
GUIDE_SOURCE = RAW / "lut-pair-ready0-compose-copy-route-264"
GUIDE_SOURCE_PROFILE_SHA = "79e71f1ed628b0bb0f4f97432fd8bca62ccf18e1066403c613c056215096a27b"
GUIDE_SOURCE_RUN_SHA = "b76ff6967705654e9cb1a9d8756d3302f4a7db035f3fb4c4f6490c3f376a8f22"
GUIDE_SOURCE_REPORT_SHA = "826d4d19817d7df017ea36a65c335522f4f356ad69443ca10043155d5f94c785"
GUIDE_SOURCE_GRAPH = RAW / "lut-pair-ready0-compose-copy-selected-264/selected/placed.json"
GUIDE_SOURCE_GRAPH_SHA = "11b385756263d1db95809b15957b563c3607cb420ba46c3ccf026ba5fcef6cce"
PLAN = RAW / "local-plan16-ready1-command-stage-264/local-plan.json"
PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "selected"
PHASE = "lut-pair-ready1-compose-copy-explicit-predicted-selection"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
CHANGED = {"mistral/CMakeLists.txt", "mistral/arch.h", "mistral/lut_pair_copy.cc", "mistral/lut_pair_placement.cc",
    "mistral/lut_pair_placement.h", "mistral/lut_pair_placement.md", "mistral/main.cc",
    "mistral/tests/lut_pair_placement.cc", "mistral/tests/lut_pair_placement_cli.py"}
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch("[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original pathname hash")
    if path not in inputs:
        require(sha(path) == expected, "original input differs: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat runtime entry is not absolute"); bind(inputs, name, expected)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def definitions():
    listing = load(LISTING / "run_listing.py", LISTING_HELPER_SHA, "ready1_copy_selected_listing_pure")
    control, parsers = listing.definitions()
    return listing, control, parsers


def command(previous, selection):
    require(type(selection) is int and selection >= 0, "an explicit existing candidate index is required")
    result = list(previous["command"])
    require(result[0] == str(BINARY) and all(result.count(flag) == 1 for flag in
        ("--no-route", "--remap-plan", "--remap-lut-pair-critical", "--remap-lut-pair-candidate", "--remap-lut-pair-compose-copy")) and
        result[result.index("--remap-plan") + 1] == str(PLAN) and result[result.index("--remap-lut-pair-critical") + 1] == str(GUIDE) and
        result[result.index("--remap-lut-pair-candidate") + 1] == "-1" and not any(flag in result for flag in
        ("--no-pack", "--no-place", "--rbf", "--remap-post-plan", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "proved copy listing command role differs")
    result[result.index("--remap-lut-pair-candidate") + 1] = str(selection)
    for flag, name in (("--write", "placed.json"), ("--report", "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector"); result[result.index(flag) + 1] = str(FOLDER / name)
    return result


def expected_execution(previous):
    return copy.deepcopy(previous["execution"])


def validate_host(host):
    counts = {"pair_backend": 12, "copy_backend": 11, "native_plan": 25, "driver_backend": 10,
        "pair_cli": 17, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and
        host["check_results_sha256"] == CHECKS_SHA and host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and
        host["clean_committed_checkout"] is host["build_passed"] is True and set(host["changed_source_files"]) == CHANGED and
        set(host["checks"]) == set(counts) and all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
        all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"], "fresh copy host/source/check qualification differs")


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == CHANGED,
        "current copy source differs from the clean reviewed host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
        [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "current source dependency changed")


def closed_record(record, profile, path, expected):
    require(record["completed"] is True and record["exit_code"] == 0 and
        record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
        record["source_identity_sha256"] == expected and record["execution"] == profile["listing_execution"] and
        record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(canonical(record[key]) == canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "listing prerequisite is not closed")


def copy_prefix(parsed, selection):
    require(type(selection) is int and selection >= 0 and parsed["candidate_applied"] is False and
        selection < len(parsed["actual_qualified_candidates"]), "chosen candidate is absent from the actual closed listing")
    candidate = parsed["actual_qualified_candidates"][selection]
    require(candidate["candidate"] == selection and candidate["actual_guarded_trial"][5:10] == ["1"] * 5 and
        candidate["gain_ps"] >= 250 and candidate["cohort"] > 0, "chosen candidate is not its complete guarded actual trial")
    prefix = []
    marker = "Info: LUT pair copy candidate " + str(selection) + ":"
    for line in parsed["all_copy_diagnostic_lines"]:
        prefix.append(line)
        if line.startswith(marker): break
    require(prefix and prefix[-1].startswith(marker) and not any("no candidate applied" in line for line in prefix), "actual selected listing prefix absent")
    return candidate, prefix


def qualification(log, listing, control, parsers, expected_candidate, expected_copy_prefix):
    lines = [line for line in log.splitlines() if line.startswith("Info: LUT pair copy")]
    selected = expected_candidate["candidate"]
    applied = f"Info: LUT pair copy applied candidate {selected}; full routing and signoff still required."
    require(lines == [*expected_copy_prefix, applied] and not any(line.startswith("Info: LUT pair placement") for line in log.splitlines()),
        "fresh copy selection does not reproduce its exact guarded listing prefix and sole applied return")
    discovery = list(re.finditer(r"^Info: LUT pair copy discovery: (\d+) bounded cones\.$", log, re.M))
    require(len(discovery) == 1, "fresh selected copy discovery differs")
    models = control.qualification(log[:discovery[0].start()], parsers)
    trials = [line for line in expected_copy_prefix if line.startswith("Info: LUT pair copy trial ")]
    return models, {**expected_candidate, "candidate_applied": True, "actual_trial_count": len(trials),
        "all_copy_diagnostic_lines": lines, "exact_listing_prefix_reproduced": True,
        "selected_graph_or_functional_equivalence_proved": False, "selected_physical_or_cache_equivalence_proved": False,
        "routed_gain_accepted": False}


def lab(cell):
    match = re.fullmatch(r"MISTRAL_(?:M?COMB|FF)\.(\d+)\.(\d+)\.\d+", cell["attributes"]["NEXTPNR_BEL"])
    require(match, "expected ordinary LUT/FF BEL unavailable"); return [int(match[1]), int(match[2])]


def declared_scope(top, candidate):
    cells = top["cells"]; sink = candidate["sink"]
    require(sink.endswith(".ENA"), "selected terminal is not an FF enable"); terminal = sink[:-4]
    inner, outer, target = (cells[name] for name in (candidate["inner"], candidate["outer"], terminal))
    root, clock = outer["connections"]["Q"], target["connections"]["CLK"]
    require(target["type"] == "MISTRAL_FF" and len(root) == len(clock) == 1 and type(root[0]) is type(clock[0]) is int and
        target["connections"]["ENA"] == root, "selected native terminal/root/clock frame differs")
    cohort = []
    for name, cell in cells.items():
        for port, bits in cell["connections"].items():
            if cell["port_directions"][port] != "input" or root[0] not in bits: continue
            if lab(cell) != lab(target): continue
            require(cell["type"] == "MISTRAL_FF" and port == "ENA" and bits == root and cell["connections"]["CLK"] == clock,
                "whole selected LAB has an unsupported original root user")
            cohort.append({"cell": name, "port": "ENA", "index": 0, "bit": root[0], "record": cell})
    require(terminal in [row["cell"] for row in cohort] and len(cohort) == candidate["cohort"], "whole native cohort disagrees with the actual selected trial")
    clone = re.fullmatch(r"MISTRAL_M?COMB\.(\d+)\.(\d+)\.\d+", candidate["clone_bel"])
    require(clone, "actual listed clone BEL unavailable")
    labs = sorted({tuple(lab(inner)), tuple(lab(outer)), tuple(lab(target)), (int(clone[1]), int(clone[2]))})
    return {"declared_original_lut_pair": [{"cell": candidate[key], "record": cells[candidate[key]]} for key in ("inner", "outer")],
        "fixed_terminal_ff": {"cell": terminal, "record": target}, "declared_ena_cohort": sorted(cohort, key=lambda row: row["cell"]),
        "declared_root_q": root[0], "declared_clock_q": clock[0], "affected_whole_labs": [list(pair) for pair in labs],
        "all_original_ff_members_in_affected_labs": [{"cell": name, "record": cell} for name, cell in cells.items()
            if cell["type"] == "MISTRAL_FF" and tuple(lab(cell)) in labs]}


def guide_scope(top, previous, proof, scope, candidate):
    require(candidate["clone_bel"] == EXPECTED_CLONE_BEL and candidate["candidate"] == int(EXPECTED_SELECTION),
        "actual chosen candidate differs from the explicitly frozen selection/BEL")
    for key in ("declared_original_lut_pair", "declared_ena_cohort", "declared_root_q", "declared_clock_q"):
        require(canonical(scope[key]) == canonical(previous[key]), "fresh selected declaration differs from the positive ready1 listing: " + key)
    target_lab = "MISTRAL_FF." + ".".join(map(str, lab(scope["fixed_terminal_ff"]["record"])))
    whole = [{"cell": name, "record": cell} for name, cell in top["cells"].items()
        if cell["type"] == "MISTRAL_FF" and cell["attributes"]["NEXTPNR_BEL"].rsplit(".", 1)[0] == target_lab]
    origin, evidence = read(GUIDE_ORIGIN), proof["current_exact_guide_provenance"]
    require(len(scope["declared_ena_cohort"]) == candidate["cohort"] == 2 and len(whole) == 15 and
        target_lab == previous["target_whole_lab"] == origin["actual_target_lab"] == evidence["whole_target_lab"] and
        canonical(whole) == canonical(previous["all_original_ff_members_in_target_lab"]) and
        canonical(evidence["declared_original_lut_pair"]) == canonical(scope["declared_original_lut_pair"]) and
        canonical(evidence["declared_ena_cohort"]) == canonical(scope["declared_ena_cohort"]) and evidence["whole_original_ff_count"] == len(whole) and
        origin["actual_target_enable"] == [scope["declared_root_q"]] and origin["actual_target_clock"] == [scope["declared_clock_q"]] and
        set(origin["actual_native_ena_cohort"]) == {row["cell"] for row in scope["declared_ena_cohort"]} and
        origin["actual_critical_path_index"] == previous["actual_critical_path_index"] == evidence["exact_path_source_index"] == 1 and
        origin["actual_tied_cohort_path_index"] == previous["actual_tied_cohort_path_index"] == evidence["exact_tied_path_source_index"] == 2975 and
        origin["actual_complete_critical_path_preserved"] is origin["guide_contains_only_supported_critical_paths_field"] is True and
        origin["guide_clock_or_window_or_segment_changed"] is origin["routed_gain_accepted"] is False and
        evidence["previous_extra_ready0_copy_is_not_stacked"] is True and evidence["source_routed_gain_or_physical_frame_inherited"] is False,
        "whole two-FF cohort/original LAB/tied-path provenance differs")
    expected = {"guide_origin_path": str(GUIDE_ORIGIN), "guide_origin_sha256": GUIDE_ORIGIN_SHA,
        "guide_source_profile_sha256": GUIDE_SOURCE_PROFILE_SHA, "guide_source_run_sha256": GUIDE_SOURCE_RUN_SHA,
        "guide_source_report_sha256": GUIDE_SOURCE_REPORT_SHA, "guide_source_selected_graph_sha256": GUIDE_SOURCE_GRAPH_SHA}
    require(all(previous[key] == value for key, value in expected.items()) and
        origin["guide_path"] == str(GUIDE) and origin["guide_sha256"] == GUIDE_SHA and
        origin["complete_source_run"] == str(GUIDE_SOURCE / "route/run.json") and origin["complete_source_run_sha256"] == GUIDE_SOURCE_RUN_SHA and
        origin["complete_source_report"] == str(GUIDE_SOURCE / "route/timing.json") and origin["complete_source_report_sha256"] == GUIDE_SOURCE_REPORT_SHA and
        origin["actual_selected_graph"] == str(GUIDE_SOURCE_GRAPH) and origin["actual_selected_graph_sha256"] == GUIDE_SOURCE_GRAPH_SHA and
        evidence["guide_origin_sha256"] == GUIDE_ORIGIN_SHA and evidence["current_full_source_profile_sha256"] == GUIDE_SOURCE_PROFILE_SHA and
        evidence["current_full_source_run_sha256"] == GUIDE_SOURCE_RUN_SHA and evidence["current_full_source_report_sha256"] == GUIDE_SOURCE_REPORT_SHA,
        "exact ready1 guide/source identity differs")
    paths = [previous[key] for key in ("exact_current_path_object", "exact_tied_current_path_object")]
    endpoints = {path["path"][-1]["to"]["cell"] for path in paths}
    require(endpoints == {row["cell"] for row in scope["declared_ena_cohort"]} and
        all(path["path"][-1]["to"]["port"] == "ENA" and path["path"][-2]["from"]["cell"] == candidate["outer"] for path in paths),
        "exact critical/tied paths do not cover the selected whole cohort")
    return {**expected, "actual_critical_path_index": 1, "actual_tied_cohort_path_index": 2975,
        "exact_tied_current_path_object": previous["exact_tied_current_path_object"], "target_whole_lab": target_lab,
        "all_original_ff_members_in_target_lab": whole, "authorized_guide_delta": previous["authorized_guide_delta"],
        "previous_extra_ready0_copy_is_not_stacked": True, "routed_guide_source_inherited_as_fresh_graph_or_gain_proof": False}


def prepare(self_sha, scope_sha, profile_sha, run_sha, proof_sha, selection, binary_sha, archive_sha, host_sha):
    actual, pinned = (profile_sha, run_sha, proof_sha, binary_sha, archive_sha, host_sha), (LISTING_PROFILE_SHA, LISTING_RUN_SHA, LISTING_PROOF_SHA, BINARY_SHA, ARCHIVE_SHA, HOST_SHA)
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in
        (self_sha, scope_sha, *pinned, TEST_SHA, CHECKS_SHA, HOST_HELPER_SHA, HOST_SCOPE_SHA, LISTING_HELPER_SHA, LISTING_SCOPE_SHA,
         LISTING_COMPARER_SHA, LISTING_COMPARISON_SCOPE_SHA, GUIDE_ORIGIN_SHA, GUIDE_SOURCE_PROFILE_SHA, GUIDE_SOURCE_RUN_SHA,
         GUIDE_SOURCE_REPORT_SHA, GUIDE_SOURCE_GRAPH_SHA)) and re.fullmatch("(?:0|[1-9][0-9]*)", EXPECTED_SELECTION) and
        re.fullmatch(r"MISTRAL_M?COMB\.\d+\.\d+\.\d+", EXPECTED_CLONE_BEL), "actual selected-copy prerequisite identities remain UNFROZEN")
    require(actual == pinned and type(selection) is int and selection >= 0 and str(selection) == EXPECTED_SELECTION and not PROFILE.exists() and not FOLDER.exists(), "explicit actual pins/selection/exclusive outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (LISTING_PROFILE, profile_sha),
        (LISTING_RUN, run_sha), (LISTING_PROOF, proof_sha), (LISTING / "run_listing.py", LISTING_HELPER_SHA), (LISTING / "scope.md", LISTING_SCOPE_SHA),
        (LISTING / "compare_listing.py", LISTING_COMPARER_SHA), (LISTING / "comparison-scope.md", LISTING_COMPARISON_SCOPE_SHA),
        (HOST, host_sha), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (BINARY, binary_sha), (ARCHIVE, archive_sha), (GUIDE, GUIDE_SHA), (PLAN, PLAN_SHA), (NATIVE, NATIVE_SHA),
        (GUIDE_ORIGIN, GUIDE_ORIGIN_SHA), (GUIDE_SOURCE / "source-identity.json", GUIDE_SOURCE_PROFILE_SHA),
        (GUIDE_SOURCE / "route/run.json", GUIDE_SOURCE_RUN_SHA), (GUIDE_SOURCE / "route/timing.json", GUIDE_SOURCE_REPORT_SHA),
        (GUIDE_SOURCE_GRAPH, GUIDE_SOURCE_GRAPH_SHA)):
        bind(inputs, path, expected)
    previous, prepared, proof, host = (read(path) for path in (LISTING_RUN, LISTING_PROFILE, LISTING_PROOF, HOST))
    closed_record(previous, prepared, LISTING_PROFILE, profile_sha); validate_host(host)
    require(proof["schema"] == 1 and proof["phase"] == "lut-pair-ready1-compose-copy-listing-native-reproduction" and
        proof["source_identity_sha256"] == profile_sha and proof["current_copy_listing_run_sha256"] == run_sha and
        proof["compiler_commit"] == COMMIT and proof["delta_base_commit"] == BASE and proof["host_validation_sha256"] == HOST_SHA and
        proof["generator_sha256"] == LISTING_COMPARER_SHA and proof["scope_sha256"] == LISTING_COMPARISON_SCOPE_SHA and
        proof["recorder_sha256"] == LISTING_HELPER_SHA and proof["recorder_scope_sha256"] == LISTING_SCOPE_SHA and
        proof["current_actual_execution"] == previous["execution"] and
        proof["structural_rejection"] is proof["model_or_copy_listing_rejection"] is proof["native_path_topology_rejection"] is None and
        all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact",
            "complete_predicted_report_exact", "fresh_lut_pair_copy_listing_reproduction_proved", "fresh_selected_composed_copy_prerequisite_available", "final_original_path_metadata_and_runtime_hashes_stable")) and
        all(proof[key] == {"endpoint_diagnostic": True, "original_listing": True, "disabled_control": True} for key in
            ("ten_model_equality_by_reference", "placement_metric_equality_by_reference", "complete_report_equality_by_reference")) and
        all(proof["recorder_diagnostic_flags_match_independent_comparison"].values()), "independent current copy listing reproduction is not positive")
    adopt(inputs, proof)
    require(set(previous["output_sha256"]) == {str(LISTING_RUN.parent / name) for name in ("phase.log", "placed.json", "timing.json")}, "closed listing output triplet differs")
    for ledger in (previous["input_sha256"], previous["output_sha256"], previous["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original closure pathname is not absolute"); bind(inputs, path, expected)
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    listing, control, parsers = definitions()
    require((listing.COMMIT, listing.BASE, listing.BINARY_SHA, listing.ARCHIVE_SHA, listing.HOST_SHA) == (COMMIT, BASE, BINARY_SHA, ARCHIVE_SHA, HOST_SHA), "called current listing identity differs")
    pure = {str(LISTING / "run_listing.py"): LISTING_HELPER_SHA, str(NATIVE): NATIVE_SHA,
        str(listing.CONTROL / "run_baseline.py"): listing.CONTROL_HELPER_SHA, **{str(path): expected for path, expected in control.PARSERS}}
    for path, expected in pure.items(): bind(inputs, path, expected)
    models, parsed = listing.qualification((LISTING_RUN.parent / "phase.log").read_text(), control, parsers)
    require(len(models) == 10 and canonical(models) == canonical(previous["actual_selected_local_qualification"]) == canonical(proof["fresh_local_models"]) and
        canonical(parsed) == canonical(previous["actual_pair_copy_listing"]) == canonical(proof["actual_pair_copy_listing"]), "actual listing model/copy evidence differs")
    candidate, prefix = copy_prefix(parsed, selection)
    native = load(NATIVE, NATIVE_SHA, "ready1_copy_selected_native_pure"); top = native.read_netlist(LISTING_RUN.parent / "placed.json")["modules"]["top"]
    scope = declared_scope(top, candidate)
    guide = guide_scope(top, previous, proof, scope, candidate)
    ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ffs) == 8221 and ffs == previous["all_original_ff_bel_manifest"] and previous["compiler_commit"] == COMMIT and
        previous["binary_sha256"] == BINARY_SHA and previous["source_archive_sha256"] == ARCHIVE_SHA and previous["host_validation_sha256"] == HOST_SHA and
        previous["compose_copy_requested"] is True and previous["pair_candidate_selection"] == -1 and
        read(GUIDE) == {"critical_paths": [previous["exact_current_path_object"]]} and read(PLAN) == {"steps": previous["local_plan_steps"]} and
        len(previous["local_plan_steps"]) == 10, "literal current guide/TEN/source/fixed FF manifest differs")
    routes = [segment for segment in previous["exact_current_path_object"]["path"] if segment["type"] == "routing"]
    require(routes[-2]["from"]["cell"] == candidate["inner"] and routes[-2]["to"]["cell"] == candidate["outer"] and
        routes[-1]["from"]["cell"] == candidate["outer"] and routes[-1]["to"]["cell"] + "." + routes[-1]["to"]["port"] == candidate["sink"], "actual chosen candidate is outside the bound one-path guide")
    profile = {"schema": 1, "phase": PHASE, "compiler_commit": COMMIT, "delta_base_commit": BASE, "binary_sha256": BINARY_SHA,
        "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "listing_profile_sha256": profile_sha, "listing_run_sha256": run_sha, "listing_proof_sha256": proof_sha,
        "listing_recorder_sha256": LISTING_HELPER_SHA, "listing_recorder_scope_sha256": LISTING_SCOPE_SHA,
        "listing_comparer_sha256": LISTING_COMPARER_SHA, "listing_comparison_scope_sha256": LISTING_COMPARISON_SCOPE_SHA,
        "guide_path": str(GUIDE), "guide_sha256": GUIDE_SHA, "exact_current_path_object": previous["exact_current_path_object"],
        "original_plan_path": str(PLAN), "original_plan_sha256": PLAN_SHA, "local_plan_steps": previous["local_plan_steps"],
        "retained_local_models": models, "retained_copy_cohorts": previous["retained_copy_cohorts"], "all_original_ff_bel_manifest": ffs,
        "expected_candidate": candidate, "expected_copy_prefix": prefix, "pair_candidate_selection": selection, "compose_copy_requested": True,
        **guide, **scope, "command": command(previous, selection), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"],
        "selected_execution": expected_execution(previous), "pure_function_helper_sha256": pure,
        "post_plan_requested": False, "driver_pass_executed": False, "selected_graph_or_functional_equivalence_proved": False,
        "selected_physical_or_cache_equivalence_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "input_sha256": dict(sorted(inputs.items()))}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "explicit_selected_candidate": candidate}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, previous, host = read(PROFILE), read(LISTING_RUN), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    selection = profile["pair_candidate_selection"]
    require(type(selection) is int and str(selection) == EXPECTED_SELECTION and profile["expected_candidate"]["clone_bel"] == EXPECTED_CLONE_BEL,
        "frozen explicit selection/BEL differs")
    require(not FOLDER.exists() and profile["phase"] == PHASE and profile["command"] == command(previous, selection) and
        profile["selected_execution"] == expected_execution(previous) and profile["cwd"] == previous["cwd"] == str(MODULE) and
        profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
        all(inputs[str(path)] == profile[key] == expected for path, key, expected in ((LISTING_PROFILE, "listing_profile_sha256", LISTING_PROFILE_SHA),
            (LISTING_RUN, "listing_run_sha256", LISTING_RUN_SHA), (LISTING_PROOF, "listing_proof_sha256", LISTING_PROOF_SHA), (HOST, "host_validation_sha256", HOST_SHA),
            (BINARY, "binary_sha256", BINARY_SHA), (ARCHIVE, "source_archive_sha256", ARCHIVE_SHA), (GUIDE, "guide_sha256", GUIDE_SHA),
            (GUIDE_ORIGIN, "guide_origin_sha256", GUIDE_ORIGIN_SHA))) and
        inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"], "frozen selected-copy invocation differs")
    listing, control, parsers = definitions(); validate_host(host); clean_source(host)
    models, parsed = listing.qualification((LISTING_RUN.parent / "phase.log").read_text(), control, parsers)
    candidate, prefix = copy_prefix(parsed, selection)
    require(canonical(candidate) == canonical(profile["expected_candidate"]) and prefix == profile["expected_copy_prefix"] and
        canonical(models) == canonical(profile["retained_local_models"]) and all(inputs[path] == expected for path, expected in profile["pure_function_helper_sha256"].items()), "actual selected prerequisite/parser inputs differ")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["selected_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual selected runtime differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "fresh explicit composed-copy selection did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step")) and
            not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "selected-copy completion is not predicted-only")
        models, selected = qualification(log, listing, control, parsers, candidate, prefix)
        record["actual_selected_local_qualification"], record["actual_selected_pair_copy_qualification"] = models, selected
        record["all_ten_complete_trial_models_exact"] = canonical(models) == canonical(profile["retained_local_models"])
        metric = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
        rows, prior = metric.findall(log), metric.findall((LISTING_RUN.parent / "phase.log").read_text())
        record["all_71_placement_metrics_exact"] = len(rows) == len(prior) == 71 and rows == prior
        native = load(NATIVE, NATIVE_SHA, "ready1_copy_selected_output_native_pure"); top = native.read_netlist(FOLDER / "placed.json")["modules"]["top"]
        ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"}
        record["all_original_ff_bels_exact"] = ffs == profile["all_original_ff_bel_manifest"] and len(ffs) == 8221
        require(record["all_ten_complete_trial_models_exact"] and record["all_71_placement_metrics_exact"] and record["all_original_ff_bels_exact"], "selected copy changed earlier TEN/placement/fixed FFs")
        report, before_report = read(FOLDER / "timing.json"), read(LISTING_RUN.parent / "timing.json")
        def pairs(document):
            counts = {}
            for path in document["critical_paths"]:
                key = (path["from"], path["to"], path["max_delay"]); counts[key] = counts.get(key, 0) + 1
            return counts
        current_pairs, original_pairs = pairs(report), pairs(before_report)
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and len(current_pairs) == 7 and current_pairs == original_pairs and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "selected predicted count/window/Fmax shape differs")
        record["actual_predicted_fmax"] = report["fmax"]
        record["actual_predicted_pair_window_path_counts"] = [{"from": key[0], "to": key[1], "window_ns": key[2], "paths": count} for key, count in sorted(current_pairs.items())]
        record["complete_predicted_report_exact_diagnostic"] = canonical(report) == canonical(before_report)
        record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json")}
        require(all((FOLDER / name).stat().st_size > 0 for name in ("phase.log", "placed.json", "timing.json")), "actual selected output absent")
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "explicit_candidate_applied": selection, "selected_graph_or_functional_equivalence_proved": False, "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                    try:
                        finish({**inputs, **record["output_sha256"]}); invocation.verify(); clean_source(host)
                        record["final_original_input_output_runtime_hashes_stable"] = True
                    except BaseException as final_error:
                        record["final_original_input_output_runtime_hashes_stable"] = False; record["final_hash_or_runtime_failure"] = repr(final_error)
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute")); parser.add_argument("--candidate", type=int)
    names = ("self-sha256", "scope-sha256", "listing-profile-sha256", "listing-run-sha256", "listing-proof-sha256", "binary-sha256", "archive-sha256", "host-sha256")
    for name in (*names, "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = tuple(getattr(args, name.replace("-", "_")) for name in names)
        require(all(values) and args.candidate is not None, "actual preparation hashes and explicit candidate missing")
        prepare(*values[:5], args.candidate, *values[5:])
    else:
        require(args.profile_sha256, "actual prepared selected profile pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()

