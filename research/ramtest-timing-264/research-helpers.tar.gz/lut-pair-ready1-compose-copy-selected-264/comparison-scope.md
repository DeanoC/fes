# Ready1 selected composed-copy conditional native proof

This new comparator owns only compare_selected.py and this scope. It starts from
the fresh ready1 listing image, never the previous ready0 selected or routed
graph. The current compiler is cae5eb9a on e137ca5b, host84416288,
ELFa2b5da93/archivec64eb65c. The eleven actual listing/selected profile, run,
proof and helper/scope activation constants remain UNFROZEN until ROOT supplies
closed actual identities. Explicit SHA arguments must match them. No selected
candidate, index, site, Q, mask, gain or cohort is assumed. ROOT alone imports,
checks AST, prepares/executes helpers and performs compiler/test/GPU/Git operations.

The prerequisite is the fresh positive ready1 listing reproduction, including
its nonzero guarded-candidate availability flag. It proves exact whole native,
TEN complete model, 71-row placement and complete predicted report rollback
against the three independent closed TEN references: e137 diagnostic12a95709,
5a listing94627ac9 and dual-reference disabled control9498fb62. Every original
flat artifact/runtime pathname in that proof is rebound. Both current listing
and selected records must be their exact completed profiles, input unions,
executions and output triplets, without failure or partial-output fields.
The current host's source/submodule/model/object-dependency maps, committed
archive evidence, 58 native and 51 CLI cases, ELF and every called helper/project
module byte are included in the original-path audit and final rehash.

The selected command is independently reconstructed from its own listing.
Only its explicitly chosen candidate and new write/report aliases differ.
The literal TEN00bf plan, source JSON, QSF, SDC, device, seed and full execution
environment remain unchanged. Compose-copy stays enabled, no-route remains,
and no post-plan, driver pass, RBF or routing is admitted. Pure qualification
reparses the immutable listing, then matches the complete fresh copy-log prefix
through the chosen actual guarded candidate and its sole application marker.
Compiler logs bind the trial; they never substitute for the graph/truth proof.

The exact new ready1 guideea8eb811 and originc95af436 are rebound. The selected
profile must preserve its positive listing's full source path at index1 and
tied path at2975, source profile/run/report/selected-graph hashes, complete pair
records and target neighborhood. The chosen pair and sink must be the guide's
last two literal native routing edges. An independent original root-user scan
derives the whole same-LAB scalar FF.ENA cohort and common CLK. Its actual two
members and all fifteen original target-LAB FF records must match the guide,
origin, positive listing evidence and selected profile. The earlier extra
ready0 composed copy is not stacked. The guide source is an unaccepted search
measurement; its routed graph, physical state and gain are not inherited.

The whole native proof admits exactly one new ALUT2..6 and one sole private
owner+$Q alias:14907→14908 cells and16645→16646 nets. The first-free paired name
is independently derived from the original cell/net namespace. Actual new Q
must be absent from every original alias, public port, driver and user. All
original private raw IDs remain literal. No owner-frame alignment, numerical
translation, BUF collapse, creator exception or metadata waiver is used.
All original records, attributes, tables, controls, raw slots, nested orders,
paired PLL entries, owner/net/port orders and all8221 FF BELs remain exact except
the precisely derived two ENA connection slots. Complete reconstructed driver
and user occurrence tables permit only the clone's external input loads, its
unique Q driver and those ENA transfers. Every other root/inner side user stays
literal. The actual clone must occupy an originally empty serialized whole ALM
within production L1 radius3 of the target. Pair, target and destination whole
FF neighborhoods are independently checked against the prepared scope; leaf
driver neighborhoods are additionally retained in native evidence.

Composition is independently rebuilt from actual original inner/outer tables
and literal A..F signal identities, deduplicating shared external leaves. It
allows at most six leaves and rejects feedback or ambiguous drivers. Actual
clone arity, input order, padding and table are checked, not borrowed from the
logged mask. Every Boolean assignment up to64 evaluates both original tables
and the actual clone. Padded ports are enumerated for both values. Disconnected
source inputs and unsupported raw literals fail closed: absent packed metadata
cannot establish a source constant or inversion.

This proof is conditional on connected original/clone inputs and FF controls
having their native logical polarity. Placed JSON does not export actual packed
PIN states, ENA polarity, physical ALM banks, full LAB/cache selectors or indexed
user-store holes. Those claims remain explicitly false/unproved here. Fresh
routed FES_PINMAP/LABSTATE evidence must independently establish effective
constants/inversions, clone/source/mate truth, FF enable equivalence and protected
carry/shared-bank/LAB neighbors. Native backend test results are separate evidence.
There is no independent numerical STA, hold, calibration, RBF-decode or hardware
claim, and no routed gain against the accepted five-stage117.771759MHz result.

Own selected and listing reports independently validate all15290 actual native
paths and all seven clock-pair endpoint/window sets, finite signed terms and
clock attribution. TEN models and71 placement rows stay exact. Selected timing
delays and Fmax may change; complete report equality is diagnostic only. Native,
selected-prefix and topology rejections are separate, preserving own report
evidence and the final original-path rehash on structural rejection. The sole
output selected/comparison-selected-copy.json is exclusive. Phase is
lut-pair-ready1-selected-composed-copy-conditional-native-proof. Only every gate
passing makes selected_native_graph_and_conditional_function_proved and
fresh_full_route_prerequisite_under_plain_sig_condition true; packed physical
truth, cache equivalence, routed acceptance and hardware remain false.
