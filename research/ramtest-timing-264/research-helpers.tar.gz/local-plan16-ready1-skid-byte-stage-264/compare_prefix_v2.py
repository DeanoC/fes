"""Ninth prefix proof with four explicit generated-private owner frames."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
CONTROL = RAW / "local-plan16-eight-control-264"
CONTROL_PROFILE_SHA = "8aa53a2e8fbf0299ddab4d528b22e4c372e996684f81d9c08a73d61204029e3d"
CONTROL_GENERATOR_SHA = "cd4ff35e96d576369e8066455b7f0d5cb15836c54f037ae7b1fe3afa34db0536"
CONTROL_SCOPE_SHA = "08877d28e4b45dcb2e43af81b20001694f9ecb9d814946c32638ac39fafaee06"
CONTROL_RUNNER_SHA = "b5e0f6ad4b09c3d051174e9dd4409f9f02c030a0db9b6626741dec7c715a5749"
CONTROL_PROOF_SHA = "1cff85d6656ba2afe90c89ee5a7e37a68bfa72f9592c273e4396a672520f268f"
CONTROL_RUN_SHA = "0e6d744095bd007622e017db2205198c46925f438a6e0a171e0fa63fbb2a4f0c"
RUNNER_SHA = "51ff54f38b122f9d6bef47b2feb9a64916855b3523215df8b06e0c3cc99dd487"
RUNNER_SCOPE_SHA = "1533f18f01efebf3b3dc3010d054d91b3ad1a565206f4b0b9205a988615d8702"
PROFILE_SHA = "aceefeba07c0b3f3d7e98d09d336742b10a31aac734dccfe9c6df6dd71971d51"
PLAN_SHA = "9acacb2358c2e41aba147c445ec626f9c25f0ae29e2f557b416160860720f9bd"
COMMIT, BASE = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f", "ec0a8d0cc56f0915e985ca7d1528daab1450c00d"
HOST_SHA = "0f3c11a523ca7981b5d3e373c10d67d0ade5bf5cac9212e02e0186d6368b438c"
BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
GUIDE = RAW / "local-plan16-ready1-skid-byte-guide-264"
GUIDE_SHA = "b17bd35289a1a25aba13fadc027a984e3730110ab5e91e0f0e8b9002d5b349ca"
DERIVATION_SHA = "2e00e59b0c31381635ae979ce5c2202033bb3b8eafcad3e441e6c2626b7b4eb0"
EXPERIMENT_SHA = "f74c76d8ee455ccc499e86a99256c771537953615b0136762dae1ed85a33a4e3"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
LAWS = RAW / "local-multicopy-ready1-264/compare_prefix.py"
LAWS_SHA = "0a52299ec2c2547dd24407bbad78caa904093ee0514c0c28ea6eda04e1e44744"
INNER, OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B"
CLONE = OUTER + "$local_remap$3"
TARGETS = tuple("hps_ddr.port1.skid_byteenable_MISTRAL_FF_Q_" + str(i) for i in (3, 7))
COPY_NAMES = ("hps_ddr.port1.slot_free_MISTRAL_ALUT4_C$local_remap", OUTER + "$local_remap",
    "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B$local_remap", OUTER + "$local_remap$1", OUTER + "$local_remap$2",
    "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B$local_remap$1", "hps_ddr.port1.slot_free_MISTRAL_ALUT4_C$local_remap$1",
    "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B$local_remap$2")
STRICT_HELPER_SHA = "0d824c45fde97ac6ae3c524b1d411c83cb36f06fc95deadec1ca28a150db831f"
STRICT_SCOPE_SHA = "2b61d270ac09da2bf2ecfab5a25fbc50f4841d50ec17c8c3865ceccc051b698d"
STRICT_PROOF_SHA = "0a121998881b8ac94e0b816c315579d0789e7a714fb875356b5c758d239ea60c"
RUN_SHA = "899a21d86764d2904aeab4632724b68e7db8e23cccd5ddc6a84be932dd4de4a6"
COMB_OWNER = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMP = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C"
PRIVATE_FRAMES = ((COMB_OWNER, 120724, 120726), (DECOMP + "$code0", 120726, 120728),
    (DECOMP + "$code1", 120728, 120730), (DECOMP + "$root", 120730, 120732))


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def adopt(audit, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        audit.bind(Path(name), expected, execution=True)


def copy_pin_snapshot(native, cell):
    encoded = cell["attributes"].get("FES_PINMAP_V1")
    if encoded is None:
        return {"present": False, "complete_exported_pin_snapshot_proved": False, "physical_truth_proved": False}
    require(type(encoded) is str and re.fullmatch(r"(?:[0-9a-fA-F]{2})+", encoded), "new copy pin snapshot is not complete hex")
    snapshot = json.loads(bytes.fromhex(encoded).decode(), object_pairs_hook=native.unique_object, parse_constant=native.nonfinite)
    require(type(snapshot) is dict and set(snapshot) == {"count", "pins"} and type(snapshot["count"]) is int and
            snapshot["count"] == 5 and type(snapshot["pins"]) is dict and set(snapshot["pins"]) == set(cell["connections"]) == set("ABCDQ") and
            cell["type"] == "MISTRAL_ALUT4", "new copy pin snapshot does not cover exactly its five native ports")
    match = re.fullmatch(r"MISTRAL_(?:MCOMB|COMB)\.(\d+)\.(\d+)\.(\d+)", cell["attributes"]["NEXTPNR_BEL"])
    require(match is not None and 0 <= int(match[3]) < 60 and int(match[3]) % 6 in (0, 1), "new copy lacks an actual combinational half BEL")
    half = int(match[3]) % 6
    available = {"A", "B", "D" if half else "C", "E1" if half else "E0", "F1" if half else "F0"}
    pins = snapshot["pins"]
    require(all(type(row) is list and len(row) == 2 and type(row[0]) is int and row[0] == 0 and type(row[1]) is str
                for row in pins.values()) and pins["Q"] == [0, "COMBOUT"] and
            len({pins[pin][1] for pin in "ABCD"}) == 4 and all(pins[pin][1] in available for pin in "ABCD"),
            "new copy plain-SIG physical pin shape/output/actual half input membership differs")
    return {"present": True, "encoded": encoded, "decoded": snapshot, "actual_bel": cell["attributes"]["NEXTPNR_BEL"],
        "actual_half": half, "complete_exported_pin_snapshot_proved": True, "bel_half_input_membership_checked": True,
        "paired_half_shared_bank_allocation_or_physical_truth_proved": False, "physical_truth_proved": False}


def private_frames(native, laws, a, b, od, ou, nd, nu):
    rows, changes = [], {}
    for owner, old_bit, new_bit in PRIVATE_FRAMES:
        alias, driver = owner + "$Q", (owner, "Q", 0, 0)
        require(laws.scalar(a["cells"][owner], "Q") == old_bit and laws.scalar(b["cells"][owner], "Q") == new_bit and
                od.get(old_bit) == nd.get(new_bit) == [driver] and a["netnames"][alias]["bits"] == [old_bit] and
                b["netnames"][alias]["bits"] == [new_bit], "explicit private owner/Q/sole driver differs: " + owner)
        for top, bit in ((a, old_bit), (b, new_bit)):
            require([name for name, net in top["netnames"].items() if bit in net["bits"]] == [alias] and
                    all(bit not in port["bits"] for port in top["ports"].values()), "private owner has another alias/public slot: " + owner)
        left, right = copy.deepcopy(a["netnames"][alias]), copy.deepcopy(b["netnames"][alias])
        left.pop("bits"); right.pop("bits")
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + alias)
        slots = ou.get(old_bit, [])
        require(slots and slots == nu.get(new_bit, []), "private owner complete named consumers differ: " + owner)
        for slot in [driver, *slots]:
            cell, port, index, occurrence = slot
            require(occurrence == 0 and cell not in a["cells"].pll_ports and cell not in b["cells"].pll_ports and
                    a["cells"][cell]["connections"][port][index] == old_bit and
                    b["cells"][cell]["connections"][port][index] == new_bit and slot not in changes,
                    "private frame slot is not unique/exact in both images: " + str(slot))
            changes[slot] = (old_bit, new_bit)
        rows.append({"owner": owner, "alias": alias, "before_raw_bit": old_bit, "after_raw_bit": new_bit,
            "before_driver": list(driver), "after_driver": list(driver), "named_consumer_slots": [list(slot) for slot in slots],
            "before_alias_record": a["netnames"][alias], "after_alias_record": b["netnames"][alias]})
    require(len({row[1] for row in PRIVATE_FRAMES}) == len({row[2] for row in PRIVATE_FRAMES}) == 4,
            "private owner frame is not bijective within either image")
    return rows, changes


def prove(native, selected, laws, before_doc, after_doc, profile, models):
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "same-compiler native document/creator differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    alias, model = CLONE + "$Q", models[8]
    require((model["inner"], model["outer"]) == (INNER, OUTER) and profile["expected_additional_copy_name"] == CLONE and
            all(name not in a["cells"] and name not in a["netnames"] for name in (CLONE, alias)), "ninth ordinary cone/free paired namespace differs")
    require(set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and list(a) == list(b) and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (14905, 14906, 16643, 16644) and
            set(b["cells"]) == set(a["cells"]) | {CLONE} and set(b["netnames"]) == set(a["netnames"]) | {alias} and
            [name for name in b["cells"] if name != CLONE] == list(a["cells"]) and
            [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports), "exact module/order/PLL/one-cell/one-net population differs")
    od, ou = selected.native_tables(a)
    nd, nu = selected.native_tables(b)
    frames, slot_changes = private_frames(native, laws, a, b, od, ou, nd, nu)
    frame_aliases = {row["alias"]: row for row in frames}
    old_private, new_private = {row["before_raw_bit"] for row in frames}, {row["after_raw_bit"] for row in frames}
    for name, net in a["netnames"].items():
        expected = copy.deepcopy(net)
        if name in frame_aliases: expected["bits"] = [frame_aliases[name]["after_raw_bit"]]
        require(native.canonical(expected) == native.canonical(b["netnames"][name]), "undeclared original alias/raw bits/metadata differs: " + name)
    wi, mi, ai, qi = laws.lut(a["cells"][INNER])
    wo, mo, ao, qo = laws.lut(a["cells"][OUTER])
    wp, mp, ap, qp = laws.lut(a["cells"][OUTER + "$local_remap"])
    wc, mc, ac, qc = laws.lut(b["cells"][CLONE])
    require((wi, wo, wp, wc, mi, mo, mp, mc) == (2, 3, 4, 4, 0xb, 0x32, 0x4440, 0x4440) and
            qi == 97422 and qo == 109091 and ao.count(qi) == 1 and ao[1] == qi and
            ac == ap == [98308, 98312, 23880, 107546] and len(set(ac)) == 4 and
            set(ac) == set(ai + [bit for bit in ao if bit != qi]) and not ({qi, qo, qp, qc} & set(ac)) and
            not old_private & set(ac) and not new_private & set(ac) and
            len({qi, qo, qp, qc}) == 4 and qc == 120724 and qc not in (set(od) - old_private) and qc not in new_private and
            not new_private & (set(od) - old_private) and nd.get(qc) == [(CLONE, "Q", 0, 0)] and
            b["netnames"][alias]["bits"] == [qc] and
            [name for name, net in b["netnames"].items() if qc in net["bits"]] == [alias] and
            all(qc not in port["bits"] for port in b["ports"].values()) and
            b["cells"][CLONE]["attributes"]["NEXTPNR_BEL"] == model["bel"], "actual new private Q/site/four-input composition differs")
    new_pin_snapshot = copy_pin_snapshot(native, b["cells"][CLONE])
    left, right = copy.deepcopy(a["cells"][OUTER + "$local_remap"]), copy.deepcopy(b["cells"][CLONE])
    for cell in (left, right):
        cell["attributes"].pop("NEXTPNR_BEL")
        # This comparison is only a template for the NEW owner. Every original
        # cell and its complete original attributes remain strict below.
        cell["attributes"].pop("FES_PINMAP_V1", None)
        cell["connections"].pop("Q")
    require(native.canonical(left) == native.canonical(right) and
            list(a["cells"][OUTER + "$local_remap"]["connections"]) == list(b["cells"][CLONE]["connections"]) and
            list(a["cells"][OUTER + "$local_remap"]["port_directions"]) == list(b["cells"][CLONE]["port_directions"]),
            "new copy metadata/table/input/port order differs beyond actual BEL/Q/site pin snapshot")
    left, right = dict(a["netnames"][OUTER + "$local_remap$Q"]), dict(b["netnames"][alias])
    left.pop("bits"); right.pop("bits")
    require(native.canonical(left) == native.canonical(right), "new private alias metadata differs")
    retained_rows, retained_slots, retained_outputs = profile["retained_copy_cohorts"], set(), []
    require([row["cell"] for row in retained_rows] == list(COPY_NAMES) and
            [len(row["consumer_slots"]) for row in retained_rows] == [21, 2, 10, 1, 6, 1, 1, 3], "eight literal retained owner/cohort declarations differ")
    for row, earlier in zip(retained_rows, models[:8]):
        name, slots = row["cell"], sorted(tuple(slot) for slot in row["consumer_slots"])
        bit = laws.scalar(a["cells"][name], "Q")
        require(native.canonical(a["cells"][name]) == native.canonical(row["record"]) == native.canonical(b["cells"][name]) and
                bit == laws.scalar(b["cells"][name], "Q") and od.get(bit) == nd.get(bit) == [(name, "Q", 0, 0)] and
                ou.get(bit) == nu.get(bit) == slots and len(slots) == earlier["ena_users"] and
                a["cells"][name]["attributes"]["NEXTPNR_BEL"] == earlier["bel"] and
                not retained_slots & set(slots) and name.startswith(earlier["outer"] + "$local_remap"), "retained copy full record/literal Q/consumer slots differs: " + name)
        retained_slots.update(slots)
        retained_outputs.append({"cell": name, "before_raw_bit": bit, "after_raw_bit": bit, "consumer_slots": [list(slot) for slot in slots]})
    declared = sorted((row["cell"], row["port"], row["vector_index"], row["occurrence"]) for row in profile["declared_ena_cohort"])
    chosen = [(name, "ENA", 0, 0) for name in TARGETS]
    group = sorted(slot for slot in ou.get(qo, []) if laws.lab(a["cells"][slot[0]]) == [27, 21])
    require(model["primary_lab"] == [27, 21] and model["selected_groups"] == 1 and model["ena_users"] == 2 and
            len(ou.get(qo, [])) == 102 and len(nu.get(qo, [])) == 100 and nu.get(qc) == chosen == group == declared and
            sorted(slot for slot in ou[qo] if slot not in chosen) == nu[qo] and not set(chosen) & retained_slots,
            "root102→100/new two ENAs/whole target LAB/retained eight cohorts differ")
    for slot in ou[qo] + sorted(retained_slots):
        cell = a["cells"][slot[0]]
        require(slot[1:] == ("ENA", 0, 0) and cell["type"] == "MISTRAL_FF" and laws.scalar(cell, "CLK") == 3549,
                "ready union is not a common-clock scalar FF ENA cohort")
    redirects = []
    for name in TARGETS:
        declaration = next(row for row in profile["declared_ena_cohort"] if row["cell"] == name)
        require(native.canonical(a["cells"][name]) == native.canonical(declaration["before_record"]) and
                declaration["old_raw_bit"] == qo and declaration["clock_raw_bit"] == 3549 and
                declaration["bel"] == a["cells"][name]["attributes"]["NEXTPNR_BEL"] ==
                {TARGETS[0]: "MISTRAL_FF.27.21.52", TARGETS[1]: "MISTRAL_FF.27.21.40"}[name] and
                laws.scalar(b["cells"][name], "ENA") == qc, "predeclared target FF full record/clock/BEL/ENA differs")
        redirects.append({"cell": name, "port": "ENA", "vector_index": 0, "occurrence": 0,
            "old_raw_bit": qo, "new_raw_bit": qc, "bel": declaration["bel"]})
    leaves, truth = [], []
    for pin, bit in zip("ABCD", ac):
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit) and
                a["cells"][od[bit][0][0]]["type"] != "MISTRAL_CONST", "boundary lacks a unique unchanged ordinary native driver")
        leaves.append({"port": pin, "raw_bit": bit, "native_driver": list(od[bit][0])})
    prior_names = (OUTER + "$local_remap", OUTER + "$local_remap$1", OUTER + "$local_remap$2")
    require(all(laws.lut(a["cells"][name])[:3] == (4, 0x4440, ac) for name in prior_names),
            "three retained ready1 copies have different actual logical input order/table")
    for assignment in range(16):
        values = {bit: (assignment >> i) & 1 for i, bit in enumerate(ac)}
        inner_value = (mi >> sum(values[bit] << i for i, bit in enumerate(ai))) & 1
        original = (mo >> sum((inner_value if bit == qi else values[bit]) << i for i, bit in enumerate(ao))) & 1
        prior = [(laws.lut(a["cells"][name])[1] >> assignment) & 1 for name in prior_names]
        additional = (mc >> assignment) & 1
        require(prior == [original] * 3 and additional == original, "conditional original/three retained/new sixteen-row function differs")
        truth.append({"assignment": assignment, "original": original, "retained_copies": prior, "additional": additional})
    # Remove the entire old private partition before adding new keys: raw IDs
    # overlap between owner frames and the new copy, so sequential relabeling
    # could erase a real driver or conflate two differently named nets.
    expected_drivers = {bit: slots for bit, slots in od.items() if bit not in old_private}
    expected_drivers.update({row["after_raw_bit"]: [tuple(row["after_driver"])] for row in frames})
    expected_drivers[qc] = [(CLONE, "Q", 0, 0)]
    require(nd == expected_drivers, "complete native drivers differ beyond four private owner frames/new Q")
    expected_users = {bit: copy.deepcopy(slots) for bit, slots in ou.items() if bit not in old_private}
    expected_users.update({row["after_raw_bit"]: [tuple(slot) for slot in row["named_consumer_slots"]] for row in frames})
    for slot in chosen: expected_users[qo].remove(slot)
    expected_users[qc] = chosen
    for pin, bit in zip("ABCD", ac): expected_users.setdefault(bit, []).append((CLONE, pin, 0, 0))
    require(nu == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete users differ beyond two ENAs/four actual input load slots")
    for name, cell in a["cells"].items():
        expected = copy.deepcopy(cell)
        for (owner, port, index, occurrence), (old_bit, new_bit) in slot_changes.items():
            if name == owner:
                require(occurrence == 0 and expected["connections"][port][index] == old_bit, "explicit old private slot differs")
                expected["connections"][port][index] = new_bit
        if name in TARGETS: expected["connections"]["ENA"] = [qc]
        require(native.canonical(expected) == native.canonical(b["cells"][name]) and
                list(cell["connections"]) == list(b["cells"][name]["connections"]) and
                list(cell["port_directions"]) == list(b["cells"][name]["port_directions"]), "original metadata/BEL/pins/order/undeclared raw slot differs: " + name)
    ff_bels = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ff_bels) == 8221 and ff_bels == profile["all_original_ff_bel_manifest"], "complete8221 FF BEL declaration differs")
    declared_labs = {tuple(lab) for lab in profile["declared_whole_labs"]}
    members = lambda labs: sorted(({"cell": name, "record": cell} for name, cell in a["cells"].items()
        if cell["type"] == "MISTRAL_FF" and tuple(laws.lab(cell)) in labs), key=lambda row: row["cell"])
    require(native.canonical(members(declared_labs)) == native.canonical(profile["original_ffs_in_declared_labs"]), "predeclared whole-LAB original FF records differ")
    selected_lab = laws.lab(b["cells"][CLONE])
    selected_members = [{"cell": row["cell"], "before_record": row["record"], "after_record": b["cells"][row["cell"]],
        "before_available_pin_snapshot": row["record"]["attributes"].get("FES_PINMAP_V1"),
        "after_available_pin_snapshot": b["cells"][row["cell"]]["attributes"].get("FES_PINMAP_V1")}
        for row in members({tuple(selected_lab)})]
    return {"serialized_native_scope_proved": True, "inner": INNER, "outer": OUTER, "new_clone": CLONE,
        "new_private_alias": alias, "actual_clone_q": qc, "original_root_q": qo, "actual_clone_bel": model["bel"],
        "actual_new_clone_record": b["cells"][CLONE],
        "actual_new_clone_pin_snapshot": new_pin_snapshot,
        "new_owner_site_pin_snapshot_only_metadata_exception": True,
        "actual_original_cone_records": {name: a["cells"][name] for name in (INNER, OUTER, *prior_names)},
        "declared_ena_redirects": redirects, "declared_ena_redirect_count": 2,
        "retained_copy_cohorts": retained_rows, "actual_retained_copy_output_rows": retained_outputs,
        "original_root_users_before": 102, "original_root_users_after": 100,
        "whole_selected_lab": selected_lab, "original_ffs_in_selected_lab": selected_members,
        "whole_selected_lab_native_ff_count": len(selected_members), "predeclared_whole_labs": profile["declared_whole_labs"],
        "conditional_boundary": leaves, "assignments_checked": 16, "conditional_plain_sig_truth_rows": truth,
        "all_original_ff_placements_controls_and_nonprivate_raw_slots_exact": True,
        "all_original_aliases_and_raw_ids_exact": False, "all_original_nonprivate_raw_slots_exact": True,
        "explicit_private_output_owners": frames, "private_output_owner_count": 4,
        "explicit_private_output_changed_slots": [{"cell": slot[0], "port": slot[1], "vector_index": slot[2],
            "occurrence": slot[3], "old_raw_bit": bits[0], "new_raw_bit": bits[1]} for slot, bits in sorted(slot_changes.items())],
        "complete_native_driver_and_user_tables_proved": True,
        "original_export_order_and_paired_pll_records_exact": True, "private_output_frame_alignment_used": True,
        "physical_pins_lab_cache_gpu_or_independent_sta_proved": False}


def comparison(args):
    require(not (HERE / "baseline/comparison-prefix-v2.json").exists(), "exclusive ninth V2 prefix output already exists")
    require(args.control_sha256 == CONTROL_PROOF_SHA and args.control_run_sha256 == CONTROL_RUN_SHA and
            args.runner_sha256 == RUNNER_SHA and args.runner_scope_sha256 == RUNNER_SCOPE_SHA and args.profile_sha256 == PROFILE_SHA and
            args.run_sha256 == RUN_SHA and args.strict_rejection_sha256 == STRICT_PROOF_SHA,
            "actual positive fresh-eight control/run or finalized recorder activation pins differ")
    native = load(PURE, PURE_SHA, "plan16_ninth_v2_prefix_native")
    audit = native.Audit()
    for path, expected in ((PURE, PURE_SHA), (Path(__file__).resolve(), args.self_sha256), (HERE / "prefix-v2-scope.md", args.scope_sha256),
            (HERE / "compare_prefix.py", STRICT_HELPER_SHA), (HERE / "prefix-scope.md", STRICT_SCOPE_SHA),
            (HERE / "baseline/comparison-prefix.json", args.strict_rejection_sha256),
            (HERE / "run_baseline.py", args.runner_sha256), (HERE / "scope.md", args.runner_scope_sha256),
            (HERE / "source-identity.json", args.profile_sha256), (HERE / "baseline/run.json", args.run_sha256),
            (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA), (CONTROL / "baseline/run.json", args.control_run_sha256),
            (CONTROL / "baseline/comparison-control.json", args.control_sha256), (CONTROL / "compare_control.py", CONTROL_GENERATOR_SHA),
            (CONTROL / "comparison-scope.md", CONTROL_SCOPE_SHA), (CONTROL / "run_baseline.py", CONTROL_RUNNER_SHA),
            (GUIDE / "skid-byte-guide.json", GUIDE_SHA), (GUIDE / "derivation.json", DERIVATION_SHA),
            (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (LAWS, LAWS_SHA)):
        audit.bind(path, expected)
    runner = load(HERE / "run_baseline.py", args.runner_sha256, "plan16_ninth_v2_prefix_runner_definitions")
    profile, record, original, previous, control_proof, derived = (native.read(path) for path in
        (HERE / "source-identity.json", HERE / "baseline/run.json", CONTROL / "source-identity.json",
         CONTROL / "baseline/run.json", CONTROL / "baseline/comparison-control.json", GUIDE / "derivation.json"))
    strict = native.read(HERE / "baseline/comparison-prefix.json")
    for manifest in (control_proof, derived, strict): adopt(audit, manifest)
    require(strict["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-bounded-native-prefix" and
            strict["generator_sha256"] == STRICT_HELPER_SHA and strict["scope_sha256"] == STRICT_SCOPE_SHA and
            strict["source_identity_sha256"] == PROFILE_SHA and strict["current_baseline_run_sha256"] == RUN_SHA and
            strict["candidate_completed"] is True and strict["native_graph_proof_available"] is False and
            strict["routed_gain_accepted"] is False and strict["all_71_placement_metrics_exact"] is True and
            strict["native_path_topology_rejection"] is None and strict["final_original_path_metadata_and_runtime_hashes_stable"] is True and
            strict["structural_rejection"] == {"exception_type": "ValueError", "reason":
                "original alias/raw bits/metadata differs: " + COMB_OWNER + "$Q"}, "immutable strict rejection provenance/reason differs")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "ninth profile original input is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    require(control_proof["phase"] == "local-plan16-exact-eight-stage-native-control" and
            control_proof["structural_rejection"] is control_proof["native_path_topology_rejection"] is None and
            all(control_proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "complete_predicted_report_exact",
                "fresh_ninth_stage_control_prerequisite_proved", "all_eight_complete_trial_models_exact", "all_71_placement_metrics_exact",
                "final_original_path_metadata_and_runtime_hashes_stable")) and
            control_proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and control_proof["current_baseline_run_sha256"] == args.control_run_sha256 and
            control_proof["generator_sha256"] == CONTROL_GENERATOR_SHA and control_proof["scope_sha256"] == CONTROL_SCOPE_SHA and
            control_proof["compiler_commit"] == COMMIT and control_proof["delta_base_commit"] == BASE and control_proof["host_validation_sha256"] == HOST_SHA,
            "fresh-eight exact native/report reproduction prerequisite is not positive")
    require(previous["completed"] is True and previous["exit_code"] == 0 and previous["compiler_read_audit_passed"] is True and
            previous["final_original_input_output_runtime_hashes_stable"] is True and previous["source_identity_sha256"] == CONTROL_PROFILE_SHA and
            all(native.canonical(previous[key]) == native.canonical(value) for key, value in original.items() if key != "input_sha256") and
            previous["input_sha256"] == {**original["input_sha256"], str(CONTROL / "source-identity.json"): CONTROL_PROFILE_SHA} and
            previous["execution"] == control_proof["current_actual_execution"], "actual fresh-eight completed record/profile differs")
    require(profile["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-predicted-baseline" and
            profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and
            profile["source_archive_sha256"] == ARCHIVE_SHA and profile["host_validation_sha256"] == HOST_SHA and
            profile["helper_sha256"] == args.runner_sha256 and profile["scope_sha256"] == args.runner_scope_sha256 and
            profile["control_proof_sha256"] == args.control_sha256 and profile["previous_source_identity_sha256"] == CONTROL_PROFILE_SHA and
            profile["previous_baseline_run_sha256"] == args.control_run_sha256 and
            profile["experimental_current_full_proof_sha256"] == EXPERIMENT_SHA and profile["accepted_current_full_proof_sha256"] == ACCEPTED_SHA and
            profile["minimum_accepted_memory_mhz"] == 117.77175903320312 and profile["guide_sha256"] == GUIDE_SHA and
            profile["guide_derivation_sha256"] == DERIVATION_SHA and derived["experimental_full_proof_sha256"] == EXPERIMENT_SHA and
            derived["accepted_reference_full_proof_sha256"] == ACCEPTED_SHA and derived["guide_sha256"] == GUIDE_SHA and
            derived["source_eighth_experiment_timing_gain_accepted"] is False, "compiler/control/guide-construction/accepted-reference roles differ")
    for key, value in profile.items():
        if key != "input_sha256": require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == args.profile_sha256 and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): args.profile_sha256} and
            record["command"] == runner.command(previous) and record["execution"] == profile["baseline_execution"] == previous["execution"] and
            record["cwd"] == previous["cwd"] and record["diagnostic_environment"] == previous["diagnostic_environment"] and
            record["original_eight_complete_trial_models_exact"] is True, "closed ninth record/current runtime/input union differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is outside the frozen input closure")
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")},
            "complete predicted output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual predicted output is empty")
        audit.bind(Path(name), expected)
    require(audit.paths.get(HERE / "local-plan.json") == profile["local_plan_sha256"] == PLAN_SHA and
            native.read(HERE / "local-plan.json")["steps"] == profile["local_plan_steps"] and len(profile["local_plan_steps"]) == 9 and
            profile["local_plan_steps"][:8] == original["local_plan_steps"] and profile["local_plan_steps"][8] ==
            {"report": str(GUIDE / "skid-byte-guide.json"), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True},
            "exact eight descriptors plus the sole ninth descriptor differ")
    control, definitions = runner.local_definitions()
    for path, expected in control.PARSERS:
        require(audit.paths.get(path) == expected, "pure log-parser dependency is outside the frozen closure")
    log, previous_log = (HERE / "baseline/phase.log").read_text(), (CONTROL / "baseline/phase.log").read_text()
    models, old_models = runner.qualification(log, control, definitions), control.qualification(previous_log, definitions)
    require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
            native.canonical(models[:8]) == native.canonical(old_models) == native.canonical(profile["retained_local_models"]) ==
            native.canonical(control_proof["fresh_local_models"]), "complete fresh nine/retained eight trial model bindings differ")
    frozen = load(FREEZE, FREEZE_SHA, "plan16_ninth_v2_prefix_freeze_definitions")
    selected = load(SELECTED, SELECTED_SHA, "plan16_ninth_v2_prefix_tables_topology", frozen)
    laws = load(LAWS, LAWS_SHA, "plan16_ninth_v2_prefix_scalar_lut_lab_definitions")
    before, after = native.read_netlist(CONTROL / "baseline/placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(CONTROL / "baseline/timing.json")
    metrics = len(native.PLACEMENT_METRICS.findall(log)) == 71 and native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(previous_log)
    evidence, rejection, topology, topology_rejection = None, None, None, None
    try:
        require(metrics, "all71 original placement metrics are not exact")
        evidence = prove(native, selected, laws, before, after, profile, models)
    except (ValueError, TypeError, KeyError, IndexError, AttributeError, StopIteration) as error:
        rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    try:
        topology = selected.report_topology(after, report, old_report)
        require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and
                report["timing_report_paths"] == 16384 and report["fmax"] == record["actual_predicted_fmax"], "current native report count/pairs/cap/Fmax differs")
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error:
        topology_rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy")),
            "actual ninth phase is not predicted-only")
    audit.finish()
    positive = rejection is None and topology_rejection is None
    return {"schema": 1, "phase": "local-plan16-ready1-skid-byte-ninth-stage-explicit-private-owner-native-prefix", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "source_identity_sha256": args.profile_sha256, "current_baseline_run_sha256": args.run_sha256,
        "control_proof_sha256": args.control_sha256, "previous_baseline_run_sha256": args.control_run_sha256,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256, "runner_sha256": args.runner_sha256,
        "runner_scope_sha256": args.runner_scope_sha256, "candidate_completed": True, "structural_rejection": rejection,
        "immutable_strict_prefix_rejection_sha256": args.strict_rejection_sha256,
        "immutable_strict_prefix_generator_sha256": STRICT_HELPER_SHA, "immutable_strict_prefix_scope_sha256": STRICT_SCOPE_SHA,
        "immutable_strict_prefix_structural_rejection": strict["structural_rejection"],
        "pure_function_helper_sha256": {str(path): expected for path, expected in ((PURE, PURE_SHA), (SELECTED, SELECTED_SHA),
            (FREEZE, FREEZE_SHA), (LAWS, LAWS_SHA), (CONTROL / "run_baseline.py", CONTROL_RUNNER_SHA), *control.PARSERS)},
        "native_path_topology_rejection": topology_rejection, "native_graph_proof_available": rejection is None,
        "fresh_driver_guide_available_after_conditional_prefix_proof": positive, "native_graph_evidence": evidence,
        "fresh_local_models": models, "previous_local_models": old_models, "all_eight_retained_complete_trial_models_exact": True,
        "all_71_placement_metrics_exact": metrics,
        "current_complete_native_report_topology": topology, "actual_predicted_fmax": report["fmax"],
        "complete_predicted_report_exact": native.canonical(report) == native.canonical(old_report), "complete_predicted_report_exact_required": False,
        "experimental_current_full_proof_sha256": EXPERIMENT_SHA, "accepted_current_full_proof_sha256": ACCEPTED_SHA,
        "minimum_accepted_memory_mhz": 117.77175903320312, "conditional_plain_sig_equivalence_only": True,
        "original_private_output_raw_ids_equal": False,
        "private_output_frame_alignment_used": rejection is None,
        "global_numeric_normalization_or_buffer_collapse_used": False,
        "physical_pin_lab_cache_gpu_or_sta_acceptance_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False, "artifact_sha256": dict(sorted(audit.artifacts.items())),
        "execution_file_sha256": dict(sorted(audit.execution.items())), "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "runner-sha256", "runner-scope-sha256", "control-sha256", "control-run-sha256", "profile-sha256", "run-sha256", "strict-rejection-sha256"):
        parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    with (HERE / "baseline/comparison-prefix-v2.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_path_topology_rejection", "native_graph_proof_available")}, indent=2))


if __name__ == "__main__": main()
