"""Record a ninth local remap only after the new compiler reproduces the eight-stage control."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
CONTROL = RAW / "local-plan16-eight-control-264"
CONTROL_PROFILE_SHA = "8aa53a2e8fbf0299ddab4d528b22e4c372e996684f81d9c08a73d61204029e3d"
CONTROL_RUN_SHA = "0e6d744095bd007622e017db2205198c46925f438a6e0a171e0fa63fbb2a4f0c"
CONTROL_PROOF_SHA = "1cff85d6656ba2afe90c89ee5a7e37a68bfa72f9592c273e4396a672520f268f"
CONTROL_HELPER_SHA = "b5e0f6ad4b09c3d051174e9dd4409f9f02c030a0db9b6626741dec7c715a5749"
CONTROL_SCOPE_SHA = "6df5d7f730aae63cf95710eead246834aa181cba15a2a137867b9fb01e10e7fb"
CONTROL_COMPARE_SHA = "cd4ff35e96d576369e8066455b7f0d5cb15836c54f037ae7b1fe3afa34db0536"
CONTROL_COMPARE_SCOPE_SHA = "08877d28e4b45dcb2e43af81b20001694f9ecb9d814946c32638ac39fafaee06"
COMPILER = RAW / "remap-plan16-264"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-remap-plan16-264"
COMMIT, BASE = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f", "ec0a8d0cc56f0915e985ca7d1528daab1450c00d"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
HOST, HOST_SHA = COMPILER / "validation/host-validation.json", "0f3c11a523ca7981b5d3e373c10d67d0ade5bf5cac9212e02e0186d6368b438c"
GUIDE_FOLDER = RAW / "local-plan16-ready1-skid-byte-guide-264"
GUIDE, DERIVATION = GUIDE_FOLDER / "skid-byte-guide.json", GUIDE_FOLDER / "derivation.json"
GUIDE_SHA = "b17bd35289a1a25aba13fadc027a984e3730110ab5e91e0f0e8b9002d5b349ca"
DERIVATION_SHA = "2e00e59b0c31381635ae979ce5c2202033bb3b8eafcad3e441e6c2626b7b4eb0"
GUIDE_HELPER_SHA = "6a8d00e4f3bd62476659dbcec8cc80f939d146710dc6f9bbac22932066a39b3c"
GUIDE_SCOPE_SHA = "ca8fa97c11b7d980548a84f1d044762b964c3c788941b5a78b1fbded9908df72"
FULL = RAW / "local-multicopy-port0-skid-address-route-264"
FULL_PROOF = RAW / "local-multicopy-port0-skid-address-route-proof-264/comparison.json"
FULL_PROOF_SHA = "f74c76d8ee455ccc499e86a99256c771537953615b0136762dae1ed85a33a4e3"
FULL_PROFILE_SHA = "539376c79a565e3f114c20349a1a764059443217c68b088c2892bc66de1960c0"
FULL_RUN_SHA = "3ef0c0b68f5bcb5d9fc0c7667663c88b1cdc086869973929c2c8e3b4450b7497"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PROFILE, PLAN, FOLDER = HERE / "source-identity.json", HERE / "local-plan.json", HERE / "baseline"
INNER, OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B"
TARGETS = tuple("hps_ddr.port1.skid_byteenable_MISTRAL_FF_Q_" + str(i) for i in (3, 7))


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected) and
            (path not in inputs or inputs[path] == expected), "invalid/conflicting original path hash")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path)
        inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution entry is not absolute")
        bind(inputs, name, expected)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module path differs")
    return module


def local_definitions():
    control = load(CONTROL / "run_baseline.py", CONTROL_HELPER_SHA, "skid_byte_ninth_control_pure")
    return control, control.local_definitions()


def qualification(log, control, definitions):
    headers = list(re.finditer(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, row.groups())) for row in headers] == [(i, 0, g, 0, 1) for i, g in enumerate((8, 1, 1, 1, 1, 1, 1, 1, 1))], "fresh nine-stage headers differ")
    models = control.qualification(log[:headers[8].start()], definitions)
    block = log[headers[8].end():]
    trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
    choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
    applications = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
    require(trials and len(choices) == len(applications) == 1 and choices[0][1] == applications[0][1] == "0" and
            trials[-1].end() < choices[0].start() < applications[0].start(), "ninth candidate0/application lacks a final guarded trial")
    row, choice = trials[-1].groups(), choices[0].groups()[1:]
    require((row[0], row[1], row[4], row[12], row[7]) == choice and row[:2] == (INNER, OUTER) and row[2:4] == ("27", "21") and
            row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and row[11:13] == ("1", "2") and int(row[7]) >= 250,
            "fresh two-ENA fixed-FF/clock/hold/boundary/minimum-gain guards differ")
    models.append({"index": 8, "candidate": 0, "groups_budget": 1, "selected_groups": 1, "inner": INNER, "outer": OUTER,
        "primary_lab": [27, 21], "bel": row[4], "ena_users": 2, "gain_ps": int(row[7]), "actual_trial_count": len(trials),
        "prior_trial_rows": [trial.groups() for trial in trials[:-1]], "ff_shift": [0, 0],
        "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False})
    return models


def command(previous):
    result = list(previous["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == 1 and not any(flag in result for flag in
        ("--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "current control command role differs")
    for flag, path in (("--remap-plan", PLAN), ("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous plan/output selector")
        result[result.index(flag) + 1] = str(path)
    return result


def clean_source(host):
    def git(repo, *args):
        return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
            git(SOURCE, "merge-base", BASE, COMMIT) == BASE and
            set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == set(host["changed_source_files"]), "current compiler source is not its clean committed host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
            [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def prepare(self_sha, scope_sha, control_sha, control_run_sha, guide_sha, derivation_sha):
    require(control_sha == CONTROL_PROOF_SHA and control_run_sha == CONTROL_RUN_SHA and guide_sha == GUIDE_SHA and
            derivation_sha == DERIVATION_SHA and not any(path.exists() for path in (PROFILE, PLAN, FOLDER)),
            "actual guide/derivation pins and exclusive ninth outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA),
            (CONTROL / "baseline/run.json", control_run_sha), (CONTROL / "baseline/comparison-control.json", control_sha),
            (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA), (CONTROL / "scope.md", CONTROL_SCOPE_SHA),
            (CONTROL / "compare_control.py", CONTROL_COMPARE_SHA), (CONTROL / "comparison-scope.md", CONTROL_COMPARE_SCOPE_SHA),
            (GUIDE, guide_sha), (DERIVATION, derivation_sha), (GUIDE_FOLDER / "derive_guide.py", GUIDE_HELPER_SHA), (GUIDE_FOLDER / "scope.md", GUIDE_SCOPE_SHA),
            (FULL_PROOF, FULL_PROOF_SHA), (FULL / "source-identity.json", FULL_PROFILE_SHA), (FULL / "route-c0/run.json", FULL_RUN_SHA),
            (ACCEPTED, ACCEPTED_SHA), (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA), (HOST, HOST_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        bind(inputs, path, expected)
    control, definitions = local_definitions()
    proof, original, previous, derived, experiment, accepted, host = (read(path) for path in
        (CONTROL / "baseline/comparison-control.json", CONTROL / "source-identity.json", CONTROL / "baseline/run.json", DERIVATION, FULL_PROOF, ACCEPTED, HOST))
    control.host_valid(host, HOST_SHA)
    for manifest in (proof, derived, experiment, accepted): adopt(inputs, manifest)
    require(proof["phase"] == "local-plan16-exact-eight-stage-native-control" and proof["candidate_completed"] is True and
            proof["native_graph_proof_available"] is proof["complete_predicted_report_exact"] is proof["fresh_ninth_stage_control_prerequisite_proved"] is True and
            proof["all_eight_complete_trial_models_exact"] is proof["all_71_placement_metrics_exact"] is True and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and
            proof["current_baseline_run_sha256"] == control_run_sha and proof["compiler_commit"] == COMMIT and proof["host_validation_sha256"] == HOST_SHA and
            proof["generator_sha256"] == CONTROL_COMPARE_SHA and proof["scope_sha256"] == CONTROL_COMPARE_SCOPE_SHA and
            proof["final_original_path_metadata_and_runtime_hashes_stable"] is True, "fresh new-compiler eight-stage prerequisite is not positive")
    require(previous["completed"] is True and previous["exit_code"] == 0 and previous["compiler_read_audit_passed"] is True and
            previous["final_original_input_output_runtime_hashes_stable"] is True and previous["source_identity_sha256"] == CONTROL_PROFILE_SHA and
            all(canonical(previous[key]) == canonical(value) for key, value in original.items() if key != "input_sha256") and
            previous["input_sha256"] == {**original["input_sha256"], str(CONTROL / "source-identity.json"): CONTROL_PROFILE_SHA} and
            previous["execution"] == original["baseline_execution"] == proof["current_actual_execution"] and previous["compiler_commit"] == COMMIT and
            previous["binary_sha256"] == BINARY_SHA and previous["source_archive_sha256"] == ARCHIVE_SHA and
            not any(key in previous for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "closed current control/profile/runtime differ")
    for ledger in (previous["input_sha256"], previous["output_sha256"], previous["execution"]["files"], *(host[key] for key in control.HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original control/host entry is not absolute")
            bind(inputs, path, expected)
    require(experiment["structural_rejection"] is None and experiment["native_graph_proof_available"] is experiment["physical_scope_proved"] is True and
            experiment["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and experiment["current_full_run_sha256"] == FULL_RUN_SHA and
            experiment["source_identity_sha256"] == FULL_PROFILE_SHA and experiment["accepted_full_proof_sha256"] == ACCEPTED_SHA and
            accepted["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and accepted["structural_rejection"] is None and
            derived["phase"] == "local-plan16-ready1-skid-byte-exact-current-path-guide" and derived["experimental_full_proof_sha256"] == FULL_PROOF_SHA and
            derived["current_full_run_sha256"] == FULL_RUN_SHA and derived["route_profile_sha256"] == FULL_PROFILE_SHA and
            derived["accepted_reference_full_proof_sha256"] == ACCEPTED_SHA and derived["accepted_memory_reference_mhz"] == 117.77175903320312 and
            derived["source_eighth_experiment_timing_gain_accepted"] is derived["new_candidate_qualified"] is False and
            derived["generator_sha256"] == GUIDE_HELPER_SHA and derived["scope_sha256"] == GUIDE_SCOPE_SHA and derived["guide_sha256"] == guide_sha and
            derived["guide_path"] == str(GUIDE) and derived["selected_lab"] == [27, 21] and derived["selected_endpoint"] == TARGETS[1] and
            derived["selected_path_source_indices"] == [1] and derived["selected_paths"] == 1 and derived["expected_next_copy_name"] == OUTER + "$local_remap$3" and
            derived["existing_function_assignments_checked"] == 16 and derived["exact_path_objects_and_original_source_order_preserved"] is True and
            derived["all_original_report_metadata_except_filtered_critical_paths_exact"] is True and
            derived["clock_terms_locations_sources_windows_or_segment_delays_modified"] is False, "guide construction and accepted-reference roles differ")
    native = load(NATIVE, NATIVE_SHA, "ninth_skid_byte_native_pure")
    frozen = load(FREEZE, FREEZE_SHA, "ninth_skid_byte_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "ninth_skid_byte_selected_pure", frozen)
    before_doc, full_doc = native.read_netlist(CONTROL / "baseline/placed.json"), native.read_netlist(FULL / "route-c0/routed.json")
    before, routed = before_doc["modules"]["top"], full_doc["modules"]["top"]
    guide, full_report = read(GUIDE), read(FULL / "route-c0/timing.json")
    paths = [full_report["critical_paths"][index] for index in derived["selected_path_source_indices"]]
    require(canonical(guide) == canonical({**full_report, "critical_paths": paths}) and
            paths[0]["path"][-1]["to"]["cell"] == TARGETS[1] and paths[0]["path"][-1]["to"]["port"] == "ENA", "actual guide path object or full metadata differs")
    for segment in paths[0]["path"]:
        for endpoint in (segment["from"], segment["to"]):
            name, port = endpoint["cell"], endpoint["port"]
            a, b = before["cells"][name], routed["cells"][name]
            require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and a["attributes"]["NEXTPNR_BEL"] == b["attributes"]["NEXTPNR_BEL"] and
                    a["port_directions"][port] == b["port_directions"][port] and a["connections"][port] == b["connections"][port], "guide endpoint changed in the fresh eight-stage control")
    drivers, users = selected.native_tables(before)
    q = before["cells"][OUTER]["connections"]["Q"][0]
    cohort = [slot for slot in users[q] if before["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"].startswith("MISTRAL_FF.27.21.")]
    require(len(users[q]) == 102 and cohort == [(name, "ENA", 0, 0) for name in TARGETS] and
            derived["declared_target_lab_ena_slots"] == [list(slot) for slot in cohort], "ninth group is not exactly the two remaining original-root LAB27.21 ENAs")
    target_rows = []
    for name in TARGETS:
        cell = before["cells"][name]
        require(cell["type"] == "MISTRAL_FF" and cell["connections"]["CLK"] == [3549], "original target FF clock differs")
        target_rows.append({"cell": name, "port": "ENA", "vector_index": 0, "occurrence": 0, "old_raw_bit": q,
            "clock_raw_bit": 3549, "bel": cell["attributes"]["NEXTPNR_BEL"], "before_record": cell})
    models = control.qualification((CONTROL / "baseline/phase.log").read_text(), definitions)
    require(canonical(models) == canonical(previous["actual_selected_local_qualification"]) == canonical(proof["fresh_local_models"]) and len(models) == 8,
            "fresh completed eight-stage model records differ")
    copies, seen, labs, owners = [], {}, {(27, 21)}, {INNER, OUTER}
    for index, model in enumerate(models):
        outer = model["outer"]; ordinal = seen.get(outer, 0); seen[outer] = ordinal + 1
        name = outer + "$local_remap" + ("$" + str(ordinal) if ordinal else "")
        cell = before["cells"][name]; bit = cell["connections"]["Q"][0]; recorded = derived["retained_copy_cohorts"][index]
        require(recorded["cell"] == name and recorded["raw_q"] == bit and recorded["consumer_slots"] == [list(slot) for slot in users[bit]] and
                cell["type"] == recorded["record"]["type"] and cell["parameters"] == recorded["record"]["parameters"] and
                cell["connections"] == recorded["record"]["connections"] and cell["port_directions"] == recorded["record"]["port_directions"] and
                cell["attributes"]["NEXTPNR_BEL"] == recorded["record"]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
                len(users[bit]) == model["ena_users"] and not set(users[bit]) & set(cohort) and all(slot[1:] == ("ENA", 0, 0) and
                before["cells"][slot[0]]["type"] == "MISTRAL_FF" and before["cells"][slot[0]]["connections"]["CLK"] == [3549] for slot in users[bit]),
                "retained eight-copy logical record/cohort/site differs")
        copies.append({"cell": name, "record": cell, "consumer_slots": [list(slot) for slot in users[bit]]})
        owners.update((model["inner"], outer, name)); owners.update(slot[0] for slot in users[bit]); labs.add(tuple(model["primary_lab"]))
    require([len(row["consumer_slots"]) for row in copies] == [21, 2, 10, 1, 6, 1, 1, 3], "all eight retained cohorts differ")
    expected_name = OUTER + "$local_remap$3"
    require(all(name not in before["cells"] and name not in before["netnames"] for name in (expected_name, expected_name + "$Q")), "expected unused third suffix pair is occupied")
    for name in owners:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", before["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "original cone/copy/cohort lacks a placed BEL")
        labs.add(tuple(map(int, match.groups())))
    ff_bels, neighborhoods = {}, []
    for name, cell in before["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        bel = cell["attributes"].get("NEXTPNR_BEL", ""); match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", bel)
        require(match is not None, "original FF lacks a placed BEL")
        ff_bels[name] = bel
        if tuple(map(int, match.groups())) in labs: neighborhoods.append({"cell": name, "record": cell})
    require(len(ff_bels) == 8221 and ff_bels == original["all_original_ff_bel_manifest"], "all original FF placement names/BELs changed")
    old_plan_path = Path(original["original_plan_path"]); old_plan = read(old_plan_path)
    require(inputs[str(old_plan_path)] == original["original_plan_sha256"] == "13fa3ff7f6a587e8c4dfc6a3f971b37126ba8d277e4447de0ace4c14ec3498a6" and
            old_plan["steps"] == original["local_plan_steps"] and len(old_plan["steps"]) == 8, "literal original eight descriptors differ")
    plan = copy.deepcopy(old_plan); plan["steps"].append({"report": str(GUIDE), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True})
    require(len(plan["steps"]) == 9 <= 16 and plan["steps"][:8] == old_plan["steps"], "new nine-step plan or exact first-eight descriptors differ")
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    for name, expected in control.SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    finish(inputs); clean_source(host)
    with PLAN.open("x") as stream: stream.write(json.dumps(plan, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, PLAN, sha(PLAN))
    profile = {"schema": 1, "phase": "local-plan16-ready1-skid-byte-ninth-stage-predicted-baseline", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA,
        "control_proof_sha256": control_sha, "previous_source_identity_sha256": CONTROL_PROFILE_SHA, "previous_baseline_run_sha256": control_run_sha,
        "experimental_current_full_proof_sha256": FULL_PROOF_SHA, "accepted_current_full_proof_sha256": ACCEPTED_SHA,
        "minimum_accepted_memory_mhz": 117.77175903320312, "guide_sha256": guide_sha, "guide_derivation_sha256": derivation_sha,
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "original_eight_plan_path": str(old_plan_path), "original_eight_plan_sha256": inputs[str(old_plan_path)],
        "local_plan_sha256": inputs[str(PLAN)], "local_plan_steps": plan["steps"], "retained_local_models": models,
        "authorized_plan_delta": {"append_index": 8, "step": plan["steps"][8], "first_eight_descriptors_exact": True},
        "expected_additional_copy_name": expected_name, "declared_ena_cohort": target_rows, "retained_copy_cohorts": copies,
        "declared_whole_labs": sorted(map(list, labs)), "original_ffs_in_declared_labs": sorted(neighborhoods, key=lambda row: row["cell"]),
        "all_original_ff_bel_manifest": dict(sorted(ff_bels.items())), "actual_ninth_site_neighborhood_requires_later_prefix_proof": True,
        "command": command(previous), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"], "baseline_execution": previous["execution"],
        "input_sha256": dict(sorted(inputs.items())), "driver_pass_executed": False, "native_graph_or_physical_equivalence_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "plan_sha256": sha(PLAN), "inputs": len(inputs), "target_ena_count": len(target_rows)}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha)
    profile = read(PROFILE)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    previous, host = read(CONTROL / "baseline/run.json"), read(HOST)
    require(not FOLDER.exists() and profile["command"] == command(previous) and profile["baseline_execution"] == previous["execution"] and
            profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["cwd"] == previous["cwd"] == str(MODULE) and
            inputs[str(CONTROL / "baseline/run.json")] == profile["previous_baseline_run_sha256"] and
            inputs[str(CONTROL / "baseline/comparison-control.json")] == profile["control_proof_sha256"] and
            inputs[str(HOST)] == profile["host_validation_sha256"] == HOST_SHA and inputs[str(BINARY)] == profile["binary_sha256"] == BINARY_SHA and
            inputs[str(ARCHIVE)] == profile["source_archive_sha256"] == ARCHIVE_SHA and inputs[str(PLAN)] == profile["local_plan_sha256"] and
            read(PLAN)["steps"] == profile["local_plan_steps"] and len(profile["local_plan_steps"]) == 9 and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"], "frozen ninth profile/command/runtime/plan differs")
    control, definitions = local_definitions(); control.host_valid(host, HOST_SHA); clean_source(host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in control.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module path/bytes differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual current compiler/runtime differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "ninth predicted qualification did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy")) and
                not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual ninth phase is not predicted-only")
        models = qualification(log, control, definitions); record["actual_selected_local_qualification"] = models
        record["original_eight_complete_trial_models_exact"] = canonical(models[:8]) == canonical(profile["retained_local_models"])
        require(record["original_eight_complete_trial_models_exact"], "the freshly retained eight guarded models changed")
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "predicted report cap/count/Fmax invalid")
        record["actual_predicted_fmax"] = report["fmax"]; record["output_sha256"] = {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "actual predicted output missing")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "original_eight_complete_trial_models_exact": True, "actual_ninth_qualification": models[8], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "control-sha256", "control-run-sha256", "guide-sha256", "derivation-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.control_sha256, args.control_run_sha256, args.guide_sha256, args.derivation_sha256)
        require(all(values), "actual positive-control/run/guide preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
