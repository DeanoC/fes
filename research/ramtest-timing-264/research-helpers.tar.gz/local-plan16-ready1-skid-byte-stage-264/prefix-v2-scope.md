# Ninth prefix with four explicit private-owner frames

ROOT alone activates this new comparator after whole-file/hash/AST and independent
peer review. It writes only the exclusive baseline/comparison-prefix-v2.json.
The immutable strict comparator0d824c45, scope2b61d270 and actual rejection
0a121998 are bound, retained and never executed again. The rejection must name
the original comb-remap alias shift, with native topology positive and no gain
claim. The actual ninth profileaceefeba, plan9acacb23, closed run899a21d8, positive
fresh-eight control1cff85d6/run0e6d7440 and finalized recorder51ff54f3/scope1533f18f
are separately bound. Actual self/scope and every activation argument are required.

This version permits exactly four observed per-owner output frames:

| Native owner suffix | Before Q | After Q |
| --- | ---: | ---: |
| comb-remap pass_end E | 120724 | 120726 |
| decomposition code0 | 120726 | 120728 |
| decomposition code1 | 120728 | 120730 |
| decomposition root | 120730 | 120732 |

The implementation pins their complete owner names. Each image must have the
same sole named owner Q driver, sole owner$Q alias, no public-port occurrence and
the same complete named consumer-slot list. Every alias field except its listed
bit is exact. Every original cell field, LUT table, physical pin attribute,
BEL, port order and input slot remains exact except the explicitly recorded
driver/consumer slots of those four frames and the two named equivalent ENAs.
Their complete alias records and per-slot before/after bits are emitted.

The new ALUT4$local_remap$3 Q120724 legitimately reuses the old comb-private ID.
Both private partitions are independently bijective. All four old private
driver/user keys are removed together before the four new keys and the new
clone key are inserted. New private keys and the clone Q must be disjoint from
all surviving original nonprivate drivers. This is a complete owner/slot ledger,
not a numeric translation: no global +2 rule, simultaneous graph rewriting,
buffer collapse or unnamed alias allowance exists. All other original alias
bits and cell slots remain literal. The proof explicitly reports that original
private raw IDs differ; it does not claim all original raw IDs are unchanged.

The new clone is the sole added cell/net:14905→14906 cells/16643→16644 aliases.
Its Q has one driver, one alias and only FF3/7 ENA consumers in LAB27.21.
Original root users102→100; the eight retained copy owners, literal output IDs
and cohorts21/2/10/1/6/1/1/3 remain exact. Complete native drivers/users are
reconstructed from named frames, two ENA redirects and four actual new input
load slots. Original module metadata/public ports/export order/paired duplicate
PLL records, all8221 original FF BELs and all71 placement metrics remain exact.

Sixteen conditional plain-SIG rows independently compare actual innerALUT2
0xb/outerALUT3 0x32, three retained ready1 ALUT4 functions and the actual new
ALUT4 function0x4440 on four unchanged literal boundary drivers. The new copy's
site-specific FES_PINMAP exception remains limited to that new owner: if
present it must cover ABCDQ with plain-SIG states, COMBOUT Q and distinct pins
in its actual even/odd BEL half. Its whole payload and actual selected-LAB FF
records are recorded. Original pin attributes are never discarded. Missing
pre-route pin/LAB/cache state and paired-half physical truth remain unproved.

The full current15290/seven-pair predicted report is checked against its own
lossless native graph and fresh-eight endpoint/window set even on structural
rejection. Finite terms, clock/native topology and count/order checks remain;
current numerical delays can differ, and full report equality is diagnostic.
Structural and topology failures remain separate. A fresh driver guide becomes
available only when both succeed. No independent numerical STA, physical truth,
GPU cache state, RBF decode, routed gain or hardware claim follows this prefix.

Flat positive-control, guide-derivation and immutable strict-rejection closures
are adopted once, alongside the current input/profile union, actual runtime
and all three completed outputs. Pinned32fd lossless parsing/Audit,72131/8601
native tables/topology,0a52299e scalar/LUT/LAB and current command/log definitions
are reused read-only; no old proof generator, authenticator, prepare/run/main
or source query is invoked. Every original input/runtime/output path is rehashed
at the end. Source d7e5c61f/ELF41c2afe1/archive4fbebd5e/host0f3c11a5 remain current;
old-eight f74c76d8 supplies construction provenance only. Accepted five6dcf8c4b
and117.771759MHz remain the separate gain reference. No acceptance is inherited.
