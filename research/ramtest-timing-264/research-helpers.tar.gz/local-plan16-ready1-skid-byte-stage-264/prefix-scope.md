# Ninth-stage strict native prefix gate

ROOT alone runs this comparison after whole-file/hash/AST and independent peer
review. Actual self/scope, recorder/scope, prepared ninth profile and completed
ninth run hashes are mandatory arguments. The positive fresh-eight comparison
1cff85d6 and completed run0e6d7440 also require explicit activation hashes. The
known eight profile8aa53a2e and current d7e5c61f/41c2afe1/4fbebd5e/host0f3c11a5
are separate from the old-eight guide-construction compiler and routed image.
The actual prepared ninth profileaceefeba and plan9acacb23 are now pinned.
Its closed run, output bit and chosen BEL are never guessed before completion;
the actual completed run SHA remains a mandatory activation argument.

The exact positive control's flat artifact/runtime closure, current profile
input union, own completed outputs/runtime, guideb17bd352 and derivation2e00e59b
are bound once and every original path is rehashed at the end. Pinned32fd
provides lossless parsing/Audit/canonical;72131/8601 provide native slot tables
and complete current path topology;0a52299e contributes only scalar/LUT/LAB
definitions. The new recorder and its frozen control/older parser definitions
contribute only literal command and guarded log parsing. No prepare/run/main,
source-clean query, old authenticator or proof generator is called. Relative
archive member evidence is never interpreted as a live dependency pathname.

All eight plan descriptors, complete actual preceding trial dictionaries and
copy cohorts21/2/10/1/6/1/1/3 remain exact. The ninth descriptor alone appends the
actual guide, candidate0/groups1, pinsfalse and preserveFFtrue. All71 ordinary
placement metric rows must remain exact. The fresh ninth model supplies its
actual ALUT4$local_remap$3 BEL and Q: only two original-root FF3/7 ENA slots in
LAB27.21 move from109091 to its private Q. Root users102→100, every retained
copy and literal Q, all8221 original FF BELs and all other original cell fields
including parameters/attributes/controls/connections/order must remain exact.

The complete14905→14906 cells/16643→16644 nets module preserves original
settings/attributes/public ports, owner order, paired duplicate PLL entries,
every existing alias/raw bit and all driver/user slots. The new private net
has exactly one new LUT driver and exactly those two FF ENA consumers. Four
actual boundary input slots are added on their unchanged native drivers.
There is no private-output frame allowance, numeric offset/ID translation,
buffer collapse or global field removal. Any generated private-alias shift
is an explicit structural rejection, even if its Boolean function appears
unchanged; a separately authorized new proof would be needed for that delta.

Only the NEW copy's FES_PINMAP_V1 may differ from the old copy used as its
metadata template: it is a chosen-BEL-specific export. If present, its complete
five-port hex payload is decoded with duplicate/nonfinite rejection, all states
must be plain SIG, Q must map to COMBOUT, and four distinct input pins must belong
to the actual even C/E0/F0/A/B or odd D/E1/F1/A/B bank. The full new payload is
recorded. This checks shape and BEL-half membership, not paired-half sharing or
physical LUT truth. A missing payload remains explicitly unproved. Every original
cell's complete pin-map attribute is still preserved by exact record comparison;
no original pin field is removed or altered by this new-owner exception.

Sixteen exhaustive conditional plain-SIG rows compare the actual innerALUT2
0xb/outerALUT3 0x32 composition, three retained ready1 ALUT4 copies0x4440 and
the new ALUT4 function0x4440 on four distinct literal native boundary drivers.
This is serialized logical truth. Constants, inversion/pin assignment, active
low physical storage, ALM sharing and hidden caches are not independently
proved by a pre-route image that omits their full snapshots.

Original FF full exported records are closed for the predeclared whole LABs
and the actual chosen clone LAB; available FES_PINMAP_V1 values are recorded,
and every exported field outside the two named equivalent ENAs is exact.
Missing physical pin/LAB state remains unproved. No in-memory GPU IDs, indexed
user cache, ALM legality, decoded RBF, physical truth or hardware claim follows.

The complete current15290/seven-pair predicted report is validated against
its own lossless native graph and fresh-eight endpoint/window set, including
finite terms, actual clocks/native topology and count/order constraints.
Its delays may change; complete report equality is diagnostic only. Structural
and topology failures are recorded separately with current report diagnostics
and final hashes. A fresh driver guide is available only if both checks pass.
Neither modeled Fmax nor this prefix establishes routed gain or independent
numerical STA. Accepted five6dcf8c4b at117.771759MHz remains the sole gain
reference; old-eight prooff74c76d8 contributes guide provenance and no gain.
