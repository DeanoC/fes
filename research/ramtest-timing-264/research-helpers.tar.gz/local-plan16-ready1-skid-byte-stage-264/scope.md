# Contingent ninth-stage predicted qualification

Only ROOT activates this new recorder, after whole-file/hash/AST and independent
peer review. Preparation requires actual self/scope, positive fresh eight-stage
comparison-control and completed eight-run SHA arguments, plus actual guide and
derivation SHA arguments. The new compiler control must prove complete native,
all eight complete trial records,71 placement metrics and full predicted-report
identity before preparation can produce any ninth-stage profile or plan.
Execution requires the actual exclusively prepared source-identity SHA.

The current compiler is d7e5c61f/ELF41c2afe1/archive4fbebd5e, with completed
host0f3c11a5 native17/CLI13 and compiled source/dependency closure. Its runtime
must equal the actual new-eight invocation exactly. Source/model/submodule and
all absolute input/output/runtime path hashes remain checked before and after.
The current eight profile is8aa53a2e and literal original plan13fa3ff7. A new
plan preserves its eight descriptor values/order/report pathnames and appends
only actual skid-byte guideb17bd352 at index8, candidate0/groups1, pinsfalse,
preserveFFtrue. Nine steps are within the new16 cap. The command changes only
the plan selector and two new output aliases; the executable, diagnostics,
options, seed, RTL/BUILD_ID, platform/library/device and all environment remain
literal current-control values. No routing, RBF or driver pass is permitted.

Guide provenance comes from timing-rejected old-eight full run3ef0c0b6 and
native/physical-positive prooff74c76d8. Its exact source-index1 path and every
other report field remain unchanged, along with clocks/windows/delays. All
guide endpoints' actual native parameters/BEL/ports/raw connections are checked
against the new-eight placed image. Accepted five6dcf8c4b at117.771759MHz remains
a separate gain reference; neither old-eight timing nor guide truth qualifies
this compiler or the prospective ninth candidate.

The selected group is exactly two remaining original-root FF3/7 ENA slots at
LAB27.21 with CLK3549. Preparation reconstructs all eight existing copy records
and consumer cohorts21/2/10/1/6/1/1/3 from the actual fresh placed graph, verifies
their names/outputs/logical inputs/masks/sites against the guide inventory, and
keeps them disjoint from these two targets. It checks the unused cell/net/alias
pair outer3B$local_remap$3/$Q. It binds all8221 original FF BELs and predeclares
entire original FF neighborhoods for all current cones/copies/cohort LABs.
The future candidate site, Q bit and affected site neighborhood remain unknown
until its actual fresh guarded trial and independent prefix proof.

Pinned control b5e0f6ad contributes only pure hash-bound qualification
definitions and its allowlisted older parser definitions. Native32fd and
selected72131/8601 contribute lossless parsing and raw tables only. No old
prepare/run/auth/main/comparison entrypoint is invoked. All nine stages are
parsed afresh; the first eight complete records must exactly match the closed
fresh control. The ninth candidate0/application must bind its final actual
trial, one two-ENA group, zero FF shift, every compiled clock/hold/boundary guard
and gain at least250ps. Earlier rejected trial rows remain diagnostics. No site,
gain or private-output ID is predicted or borrowed from a preceding route.

Each phase emits separate exclusive source-identity/plan/run/output files and
preserves partial hashed outputs on failure. Predicted cap16384/count15290,
one placed timing refresh and absence of routing/signoff/driver/RBF are checked
from the actual log. A later independently authored prefix comparison must
prove the actual14905→14906 cell/16643→16644 net delta, only the named two ENAs
and exact retained graph/order/PLL/FF placement before any full-route phase.
This recorder claims no native/physical equivalence, numerical STA, routed
timing gain or hardware acceptance, and does not inherit hidden pin/LAB state.
