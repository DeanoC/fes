#!/usr/bin/env python3
"""Root-operated fresh groups8 ready remap plus bounded AC decomposition.

No build, compiler, router, deployment or hardware operation runs here. Listing
exports prove only restored named dictionaries and placements; routed proofs
require actual final pin snapshots and exact original BUF preservation. JSON
does not export indexed_store slots, free-list state or owner bucket addresses.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import copy
import tarfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
OLD = RAW / "control-decomposition-prefix-264"
GRANDPARENT = RAW / "control-decomposition-isolation-264"
OLD_HELPER = OLD / "compare_control_decomposition.py"
OLD_HELPER_SHA256 = "46b300b7ea30ed3a34f89082ef52abe32f54a0d18ae40518c16fc3cb25df428e"
if hashlib.sha256(OLD_HELPER.read_bytes()).hexdigest() != OLD_HELPER_SHA256:
    raise ValueError("frozen 6ad prefix helper changed")
old_spec = importlib.util.spec_from_file_location("retained_control_decomposition_evidence", OLD_HELPER)
predecessor = importlib.util.module_from_spec(old_spec)
old_spec.loader.exec_module(predecessor)
RANKING = RAW / "root-pin-ranking-264"
RANK_LIST = RANKING / "list-r6"
RANK_HELPER = RANKING / "compare_routes.py"
spec = importlib.util.spec_from_file_location("retained_root_pin_ranking_evidence", RANK_HELPER)
ranking = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ranking)
retained, staged, comb, ready, previous = ranking.retained, ranking.staged, ranking.comb, ranking.ready, ranking.previous
require, sha, relative = ranking.require, ranking.sha, ranking.relative
BEST = ranking.BEST
SOURCE_BASE = "ec3fc0156a60a3d3193142def03d992a875aaab0"
DELTA_BASE = "fddbdac2d966ff3c2455e8b93ee221c71156fad7"
RESULT_COMMIT = "6ad210a60991f93a607ac4490d6282b1267ec64a"
PINS = "ABCDEF"
MARKER = "$decomposition$"
SLOT_LIMIT = ranking.SLOT_LIMIT
DECOMP_OPTIONS = {"--remap-decompose-critical", "--remap-decompose-candidate"}
SEALED_EC3 = {
    "run.json": "604e200e6e131c2e8a1022809406df58cc8bde128f1505b22696e7eeb5e3f714",
    "comparison.json": "18fda0e105ddd4fb5cbef7939a0e01ff5dfdf36bdf29c343a5ae453bc8210ba7",
    "route.log": "7441c7de548cb4fca414510408394a5466eaef9eb385f6d4c55efcc0a9651e7e",
    "placed.json": "2952b4a22f35b2e0e95c5fb46396a7d84684ba22d13693636166e8988774b440",
}
SEALED_RUNNER = "905717543693824f69b69cd64fb4cb665f572c9868cf93f71b3b988de3db75f8"
SEALED_PREFIX_COMPARISON = "6c0d617004c4cedbe89de533f30f994663cc68c8d29902650bbc92203094cb4d"
SEALED_COPY = {"nextpnr-mistral": "ba39ad814af51c4a6af3ca1854fcd1dd992af350bb09741d5b6becfa2d7d4b18",
               "source.tar.gz": "af9b2c05bc7e4fe513f7f879d06c51c94fb696d2bde23469400fc7d041eff209",
               "source-identity.json": "2cc4985c404ac5e2047a359df3682af51dabf033f95b3ff57adc46e9fe80d4ac"}


def read(path):
    def nonfinite(value):
        raise ValueError("nonfinite JSON value: " + value)
    return json.loads(path.read_text(), object_pairs_hook=staged.unique_object, parse_constant=nonfinite)


class ObjectPairs(list):
    """Distinguish lossless JSON objects from ordinary JSON arrays."""


class NetlistCells(dict):
    def __init__(self, cells, pll_ports):
        super().__init__(cells)
        self.pll_ports = pll_ports


def read_netlist(path):
    """Permit only the known two-output PLL export, retaining both entries."""
    def nonfinite(value):
        raise ValueError("nonfinite netlist JSON value: " + value)
    pairs = json.loads(path.read_text(), object_pairs_hook=ObjectPairs, parse_constant=nonfinite)
    duplicates = {}
    def convert(value, location=(), pll_cell=False):
        if isinstance(value, ObjectPairs):
            counts = {}
            for key, _ in value:
                counts[key] = counts.get(key, 0) + 1
            repeated = {key for key, count in counts.items() if count > 1}
            allowed = (pll_cell and len(location) == 5 and location[0] == "modules" and
                       location[2] == "cells" and location[4] in {"port_directions", "connections"})
            require(not repeated or allowed and repeated == {"outclk"} and counts["outclk"] == 2,
                    "unpermitted duplicate netlist JSON key at " + repr(location))
            is_cell = len(location) == 4 and location[0] == "modules" and location[2] == "cells"
            is_pll = is_cell and dict(value).get("type") == "altera_pll"
            converted = [(key, convert(item, (*location, key), is_pll)) for key, item in value]
            if repeated:
                duplicates[location] = converted
            return dict(converted)
        if isinstance(value, list):
            return [convert(item, (*location, index)) for index, item in enumerate(value)]
        return value
    result = convert(pairs)
    audited = {}
    for location, values in duplicates.items():
        audited.setdefault((location[1], location[3]), {})[location[4]] = values
    for (module, name), fields in audited.items():
        require(set(fields) == {"port_directions", "connections"}, "PLL duplicate port directions/connections are not paired")
        require([key for key, _ in fields["port_directions"]] == [key for key, _ in fields["connections"]],
                "PLL ordered port direction/connection entries disagree")
        directions = [value for key, value in fields["port_directions"] if key == "outclk"]
        outputs = [value for key, value in fields["connections"] if key == "outclk"]
        require(directions == ["output", "output"] and len(outputs) == 2 and
                all(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0 for bits in outputs) and
                outputs[0] != outputs[1], "PLL duplicate outclk export is not two distinct scalar outputs")
        clocks = result["modules"][module]["cells"][name]["parameters"].get("number_of_clocks")
        require(type(clocks) is str and set(clocks) <= {"0", "1"} and int(clocks, 2) == 2,
                "PLL duplicate output count disagrees with parameters")
    for module, top in result["modules"].items():
        top["cells"] = NetlistCells(top["cells"], {name: fields for (owner, name), fields in audited.items() if owner == module})
    return result


class Netlist(ranking.Netlist):
    def __init__(self, cells, netnames=None):
        super().__init__(cells, netnames)
        self.pll_ports = getattr(cells, "pll_ports", {})
        for name, fields in self.pll_ports.items():
            outputs = [bits for port, bits in fields["connections"] if port == "outclk"]
            for occurrence, bits in enumerate(outputs):
                bit = bits[0]
                require(self.drivers.get(bit) in (None, (name, "outclk", 0)), "PLL output also has another driver")
                self.drivers[bit] = (name, "outclk", occurrence)
        self.direct_users = {}
        for name, cell in cells.items():
            for port, direction in cell["port_directions"].items():
                if direction == "input":
                    for index, bit in enumerate(cell["connections"][port]):
                        if bit in self.drivers:
                            self.direct_users.setdefault(self.drivers[bit], []).append((name, port, index))
        self.direct_users = {driver: sorted(users) for driver, users in self.direct_users.items()}


def pll_port_audit(old, new):
    def normalized(netlist):
        return {name: {"port_directions": fields["port_directions"],
                       "connections": [(port, [{"driver": netlist.token(bit), "named_net_aliases": netlist.external_names.get(bit, ())}
                                                for bit in bits]) for port, bits in fields["connections"]]}
                for name, fields in netlist.pll_ports.items()}
    before, after = normalized(old), normalized(new)
    require(before == after, "ordered duplicate PLL port/connection export changed")
    for name in before:
        for occurrence in range(2):
            token = (name, "outclk", occurrence)
            require(old.direct_users.get(token, []) == new.direct_users.get(token, []), "PLL clock-output direct consumer entries changed")
    return {"ordered_duplicate_pll_exports_preserved": True, "exports": before,
            "both_clock_output_consumer_entries_preserved": True,
            "limitations": ["Duplicate outclk occurrences are identified by export order, independently of numeric net IDs.",
                            "Reported pin snapshots, where present, are compared separately; JSON does not unambiguously bind duplicate outclk occurrences to every physical PLL pin."]}


def authenticate_compiler(record):
    require(Path(record["command"][0]) == HERE / "nextpnr-mistral", "candidate compiler is not the copied freeze")
    source = previous.source_identity(HERE, record)
    parent_source, _ = predecessor.authenticate_compiler(read(OLD / "disabled-control/comparison.json"))
    require(read(HERE / "source-identity.json") == read(OLD / "source-identity.json") and
            source["base_commit"] == SOURCE_BASE and source["result_commit"] == RESULT_COMMIT and
            source["result_commit"] == parent_source["result_commit"], "copied compiler identity changed")
    require(all(sha(HERE / name) == sha(OLD / name) == digest for name, digest in SEALED_COPY.items()),
            "copied 6ad binary/archive/identity differs from sealed bytes")
    require(sha(HERE / "change.patch") == sha(OLD / "change.patch"), "copied source patch changed")
    fields = dict(part.strip().split("=", 1) for part in record["tool_identity"].split(";") if "=" in part)
    require(fields.get("base_commit") == source["base_commit"] and
            fields.get("experimental_source_sha256") == source["archive_sha256"] and
            fields.get("sha256") == source["binary_sha256"], "compiler identity differs from copied bytes")
    staged.authenticated_digest(record, HERE / "source.tar.gz", ("source_archive_sha256",))
    require(record["base_compiler_commit"] == SOURCE_BASE and record["compiler_commit"] == RESULT_COMMIT,
            "recorded unchanged compiler lineage differs")
    validation = read(HERE / "copy-validation.json")
    names = (*SEALED_COPY, "change.patch")
    require(validation.get("compiler_commit") == RESULT_COMMIT and validation.get("base_commit") == SOURCE_BASE and
            validation.get("compiler_bytes_unchanged") is True and validation.get("copied_from") == str(OLD) and
            validation.get("only_profile_change") == "first local step groups 4 to 8" and
            validation.get("no_timing_inheritance") is True, "copy validation metadata changed")
    require(validation["input_sha256"] == {str(OLD / name): sha(OLD / name) for name in names} and
            validation["output_sha256"] == {name: sha(HERE / name) for name in names},
            "byte-copy input/output manifest differs from actual artifacts")
    staged.authenticated_digest(record, HERE / "copy-validation.json")
    return {**source, "freeze_path": relative(HERE), "compiler_bytes_identical_to_prefix_6ad": True,
            "copy_validation_sha256": sha(HERE / "copy-validation.json")}, parent_source


def authenticate_disabled_control():
    folder, parent_folder = HERE / "disabled-control", OLD / "disabled-control"
    record, parent = read(folder / "comparison.json"), read(parent_folder / "comparison.json")
    require(record.get("completed") is True and record.get("exit_code") == 0, "disabled loader is incomplete")
    predecessor.authenticate_disabled_control()
    previous.authenticate_inputs(record)
    source, _ = authenticate_compiler(record)
    require(record["command"][1:-2] == parent["command"][1:-2] and record["command"][-2:] ==
            ["--write", str(folder / "candidate.json")], "disabled fixed command changed")
    require(record["cwd"] == parent["cwd"] and not any(option.startswith("--remap") for option in record["command"][1:]),
            "disabled loader cwd/options changed")
    ready.authenticate_execution(record, parent)
    require("Info: Program finished normally." in (folder / "loader.log").read_text(), "disabled loader did not finish normally")
    actual, expected = read_netlist(folder / "candidate.json")["modules"], read_netlist(parent_folder / "candidate.json")["modules"]
    pll_audits = {name: pll_port_audit(Netlist(expected[name]["cells"], expected[name]["netnames"]),
                                       Netlist(top["cells"], top["netnames"])) for name, top in actual.items()}
    digest = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    require(actual == expected and digest == record["modules_sha256"] == parent["modules_sha256"], "disabled original dictionaries changed")
    require(sha(folder / "candidate.json") == record["candidate_sha256"] and
            sha(parent_folder / "candidate.json") == record["reference_sha256"], "disabled output/reference digest changed")
    staged.authenticated_digest(record, parent_folder / "comparison.json")
    staged.authenticated_digest(record, parent_folder / "candidate.json")
    return {"completed": True, "modules_equivalent": True, "original_module_dictionaries_identical": True,
            "modules_sha256": digest, "source": source, "candidate_sha256": record["candidate_sha256"],
            "reference_sha256": record["reference_sha256"], "comparison_sha256": sha(folder / "comparison.json"),
            "lossless_pll_port_audits": pll_audits,
            "separate_disabled_placement_run_available": False, "hardware_tested": False}


def fixed_command(command):
    filtered, index = [command[0]], 1
    while index < len(command):
        if command[index] in DECOMP_OPTIONS:
            require(index + 1 < len(command), "missing decomposition option value")
            index += 2
        else:
            filtered.append(command[index])
            index += 1
    # Duplicate options are checked on the complete command as well.
    staged.fixed_command(command)
    return staged.fixed_command(filtered)


def authenticate_profile(record, parent_record):
    command = record["command"]
    require("--remap-comb-plan" not in command, "retained profile uses the legacy single comb cut")
    require(not any(flag in command for flag in ("--remap-critical", "--remap-candidate", "--remap-groups",
                                                "--remap-optimize-pins", "--remap-preserve-ffs")),
            "legacy local options accompany the plan")
    local_file = Path(ready.argument(command, "--remap-plan"))
    require(local_file == HERE / "local-plan.json", "changed plan is not the new frozen profile")
    local_sha = staged.authenticated_digest(record, local_file, ("remap_plan_sha256",))
    parent_file = Path(ready.argument(parent_record["command"], "--remap-plan"))
    parent_plan = read(parent_file)
    expected = copy.deepcopy(parent_plan)
    require(parent_plan == parent_record["remap_plan"] and [step["groups"] for step in parent_plan["steps"]] == [4, 1, 1],
            "accepted parent plan changed")
    expected["steps"][0]["groups"] = 8
    plan = read(local_file)
    require(plan == expected == record["remap_plan"] and set(plan) == {"steps"} and len(plan["steps"]) == 3,
            "local profile differs beyond first groups4 to8")
    steps = []
    for index, step in enumerate(plan["steps"]):
        require(type(step) is dict and set(step) == staged.STEP_KEYS and type(step["candidate"]) is int and step["candidate"] == 0 and
                type(step["groups"]) is int and step["groups"] == (8 if index == 0 else 1) and
                step["optimize_pins"] is False and step["preserve_ff_placement"] is True and
                type(step["report"]) is str and step["report"] and "\0" not in step["report"], "invalid bounded local step")
        report_path = Path(step["report"])
        require(report_path.is_absolute(), "this profile retains its absolute authenticated reports")
        report_sha = staged.authenticated_digest(record, report_path)
        report_json = read(report_path)
        require(type(report_json.get("critical_paths")) is list, "local guide lacks critical paths")
        steps.append({**step, "index": index, "report_path": report_path, "report_sha256": report_sha, "report_json": report_json})
    staged.authenticated_digest(record, parent_file)
    validation = read(HERE / "copy-validation.json")
    require(validation["parent_plan"] == str(parent_file) and validation["parent_plan_sha256"] == sha(parent_file) and
            validation["local_plan_sha256"] == local_sha, "copied profile plan digest differs")
    require(type(record.get("ready_group_budget")) is int and record["ready_group_budget"] == 8 and
            record.get("fresh_listing") is record["list_only"] and record.get("compiler_bytes_unchanged") is True,
            "groups8/source/list metadata differs")
    require(staged.authenticate_comb_selection(record) == staged.authenticate_comb_selection(parent_record) == 0,
            "retained comb candidate changed")
    staged.authenticated_digest(record, comb.GUIDE_REPORT, ("retained_comb_report_sha256",))
    value = record.get("experimental_placed_reduction")
    require(type(value) is str and value == parent_record["experimental_placed_reduction"] and len(value.splitlines()) == 1,
            "only the original accepted placed11 stage may precede decomposition")
    parts = value.split()
    require(len(parts) == 3 and previous.re.fullmatch(r"[1-6]", parts[1]) and previous.re.fullmatch(r"0|[1-9][0-9]*", parts[2]),
            "invalid retained placed11 triple")
    placed = {"root": parts[0], "radius": int(parts[1]), "candidate": int(parts[2])}
    require(placed["candidate"] <= 2147483647, "retained placed candidate outside integer bounds")
    guide = Path(ready.argument(command, "--remap-decompose-critical"))
    require(guide == BEST / "timing.json", "decomposition guide is not authenticated parent116")
    guide_sha = staged.authenticated_digest(record, guide, ("decomposition_report_sha256", "decompose_report_sha256"))
    selection_text = ready.argument(command, "--remap-decompose-candidate") if "--remap-decompose-candidate" in command else "-1"
    require(previous.re.fullmatch(r"-1|0|[1-9][0-9]*", selection_text), "invalid decomposition candidate syntax")
    selection = int(selection_text)
    require(selection in (-1, 0) and (selection == -1) is record["list_only"], "decomposition selection/list metadata disagrees")
    for key in ("decomposition_candidate", "decomposition_selection"):
        if key in record:
            require(type(record[key]) is int and record[key] == selection, "decomposition candidate alias disagrees")
    return {"local_file": local_file, "local_sha256": local_sha, "local_steps": steps, "placed_specs": [placed],
            "guide": guide, "guide_sha256": guide_sha, "selection": selection}


def connections(netlist, name):
    cell = netlist.cells[name]
    return {port: [netlist.token(bit) for bit in bits] for port, bits in cell["connections"].items()}


def dictionary_cell(netlist, name):
    return {**netlist.cells[name], "connections": connections(netlist, name)}


def direct_connections(netlist, name):
    return {port: [netlist.drivers.get(bit, netlist.token(bit)) for bit in bits]
            for port, bits in netlist.cells[name]["connections"].items()}


def compare_named_nets(old_top, new_top, old, new, added_nets=(), routed=False):
    old_nets, new_nets = old_top["netnames"], new_top["netnames"]
    require(set(new_nets) - set(old_nets) == set(added_nets) and not set(old_nets) - set(new_nets),
            "named-net additions/removals exceed the declared clone Q nets")
    for name, before in old_nets.items():
        after = new_nets[name]
        def metadata(net):
            result = {key: value for key, value in net.items() if key != "bits"}
            if routed and "attributes" in result:
                result["attributes"] = {key: value for key, value in result["attributes"].items() if key != "ROUTING"}
            return result
        require(metadata(before) == metadata(after) and
                [old.token(bit) for bit in before["bits"]] == [new.token(bit) for bit in after["bits"]],
                "retained named net changed: " + name)


def listing_evidence(old_top, new_top):
    old, new = Netlist(old_top["cells"], old_top["netnames"]), Netlist(new_top["cells"], new_top["netnames"])
    pll_audit = pll_port_audit(old, new)
    require(set(old.cells) == set(new.cells) and not any(cell["type"] == "MISTRAL_BUF" for cell in new.cells.values()),
            "listing changed ec3's original named non-BUF dictionary")
    for name in old.cells:
        require(dictionary_cell(old, name) == dictionary_cell(new, name), "listing did not restore exact original named cell: " + name)
        require(not new.cells[name]["attributes"].get("FES_PINMAP_V1"), "listing has unexpected partial final pin snapshots")
    compare_named_nets(old_top, new_top, old, new)
    ranking.top_ports(old_top, new_top, old, new)
    require({key: value for key, value in old_top.items() if key not in {"cells", "netnames", "ports"}} ==
            {key: value for key, value in new_top.items() if key not in {"cells", "netnames", "ports"}}, "listing top metadata changed")
    return {"graph_proof_available": False, "partial_graph_evidence_available": True,
            "ec3_original_nonbuffer_named_dictionaries_preserved": True, "original_params_ports_bels_preserved": True,
            "pin_state_export_available": False, "indexed_store_slot_ids_proved": False,
            "lossless_pll_port_audit": pll_audit,
            "original_relative_export_order": export_order_audit(old_top, new_top),
            "listing_limitations": ["Pre-route JSON omits route-created BUFs and final logical/physical pin snapshots.",
                                    "Named dictionaries normalize harmless numeric net IDs to stable driver identities.",
                                    "No applied decomposition, routed truth/pin/BUF, Fmax, hold or RBF acceptance is claimed.", SLOT_LIMIT]}


def lut_shape(netlist, name):
    cell = netlist.cells[name]
    require(ready.is_lut(cell), "non-Boolean LUT in decomposition: " + name)
    width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
    require(set(cell["parameters"]) == {"LUT"} and type(cell["parameters"]["LUT"]) is str and
            len(cell["parameters"]["LUT"]) == 1 << width and set(cell["parameters"]["LUT"]) <= {"0", "1"}, "invalid LUT mask: " + name)
    require(cell["port_directions"] == {**{pin: "input" for pin in PINS[:width]}, "Q": "output"}, "invalid LUT ports: " + name)
    snapshot = ranking.pin_snapshot(netlist, name)
    require(set(snapshot["pins"]) == set(cell["port_directions"]) and snapshot["pins"]["Q"][0] == 0,
            "LUT pin snapshot/output polarity invalid: " + name)
    return width


def essential(table, width):
    return {index for index in range(width) if any(not row & (1 << index) and table[row] != table[row | (1 << index)]
                                                 for row in range(1 << width))}


def relevant_guide_edges(old, edge, report):
    found = []
    for index, path in enumerate(report["critical_paths"]):
        steps = path["path"]
        require(all(type(step["delay"]) in (int, float) and math.isfinite(step["delay"]) for step in steps), "nonfinite guide delay")
        if not steps or sum(step["delay"] for step in steps) <= path["max_delay"]:
            continue
        last = steps[-1]
        if last["type"] != "setup" or last["to"]["port"] not in {"ENA", "DATAIN"} or old.cells[last["to"]["cell"]]["type"] != "MISTRAL_FF":
            continue
        for step in steps:
            if (step["type"] == "routing" and
                    (step["from"]["cell"], step["from"]["port"]) == (edge["control_driver"][0], "Q") and
                    (step["to"]["cell"], step["to"]["port"]) == (edge["sink"], edge["port"])):
                require(old.inputs(edge["sink"])[edge["port"]] == [edge["control_driver"]], "guide selected edge is stale")
                require(tuple(step["from"]["loc"]) == comb.cell_lab(old.cells[edge["control_driver"][0]]) and
                        tuple(step["to"]["loc"]) == comb.cell_lab(old.cells[edge["sink"]]), "guide selected edge placement is stale")
                found.append(index)
    require(found, "selected original root/sink edge is absent from violated relevant guidance")
    return sorted(set(found))


def export_order_audit(old_top, new_top):
    reference_top = read_netlist(RANK_LIST / "placed.json")["modules"]["top"]
    result = {}
    for dictionary in ("cells", "netnames"):
        original = list(reference_top[dictionary])
        observed = [name for name in new_top[dictionary] if name in reference_top[dictionary]]
        require(observed == original, "pre-existing original relative export order changed: " + dictionary)
        # The caller has already proved the exact added owner set: clone cells
        # and their independent output nets, irrespective of net display names.
        added = [name for name in new_top[dictionary] if name not in old_top[dictionary]]
        filtered = [name for name in new_top[dictionary] if name in reference_top[dictionary] or name in added]
        require(filtered[:len(original)] == original and set(filtered[len(original):]) == set(added),
                "new decomposition owners precede the filtered pre-existing original prefix: " + dictionary)
        result[dictionary] = {"original_count": len(original), "observed_original_count": len(observed),
                              "original_relative_export_order_identical": True,
                              "filtered_pre_existing_names_are_exact_prefix": True, "new_clone_suffix": filtered[len(original):],
                              "reference_order_sha256": hashlib.sha256("\n".join(original).encode()).hexdigest()}
    return {**result, "source_assessment": "The unchanged json/jsonwrite.cc directly iterates ctx->cells and ctx->nets.",
            "pre_route_reference": relative(RANK_LIST / "placed.json"), "route_created_buffer_names_excluded": True,
            "export_order_audit_is_acceptance_gate": True,
            "limitations": ["Only relative order of named JSON entries is observed; no bucket addresses, capacity or indexed-store slots are exported.",
                            "Only names already present in the sealed pre-route listing are compared; route-created BUF cell/net creation order is excluded.",
                            "Prefix is checked after filtering to pre-existing names and declared new decomposition names, not against route-created records.",
                            "The audit describes final exported order, not all intermediate mutation or allocation history."]}


def clone_alm_isolation(old, new, added):
    # lab.cc appends two COMB/MCOMB then four FF BELs for each ALM.
    def location(cell):
        match = previous.re.fullmatch(r"MISTRAL_(M?COMB|FF)\.([0-9]+)\.([0-9]+)\.([0-9]+)", previous.bel(cell))
        if match is None:
            return None
        kind, x, y, z = match.groups()
        z = int(z)
        require(z < 60 and (z % 6 < 2 if kind != "FF" else z % 6 >= 2), "unsupported ALM BEL slot")
        return (int(x), int(y), z // 6)
    occupied = {}
    for name, cell in old.cells.items():
        alm = location(cell)
        if alm is not None:
            occupied.setdefault(alm, []).append(name)
    rows = []
    for name in sorted(added):
        alm = location(new.cells[name])
        require(alm is not None and not occupied.get(alm), "decomposition clone shares an ALM with original occupants: " + name)
        rows.append({"cell": name, "bel": previous.bel(new.cells[name]), "alm": alm, "original_occupants": []})
    return {"all_clone_alms_have_no_original_occupants": True, "rows": rows,
            "original_occupied_alm_count": len(occupied), "mapping": "LAB x/y and BEL z//6; COMB slots0/1, FF slots2..5",
            "clones_may_share_one_previously_empty_alm": True, "buffer_bel_occupants_included": True}


def prove_rewrite(old_top, new_top, guide):
    old, new = Netlist(old_top["cells"], old_top["netnames"]), Netlist(new_top["cells"], new_top["netnames"])
    pll_audit = pll_port_audit(old, new)
    added = set(new.cells) - set(old.cells)
    require(not set(old.cells) - set(new.cells) and len(added) in (2, 3) and
            all(MARKER in name and ready.is_lut(new.cells[name]) for name in added), "only one or two encoders and one decomposition root may be added")
    isolation = clone_alm_isolation(old, new, added)
    edges = []
    for name, before in old.cells.items():
        after = new.cells[name]
        require({key: value for key, value in before.items() if key != "connections"} ==
                {key: value for key, value in after.items() if key != "connections"}, "original type/params/BEL/attributes changed: " + name)
        require(ranking.pin_snapshot(old, name) == ranking.pin_snapshot(new, name), "original full logical/physical pins changed: " + name)
        a, b = connections(old, name), connections(new, name)
        require(set(a) == set(b), "original port dictionary changed: " + name)
        for port in a:
            if a[port] == b[port]:
                continue
            require(ready.is_lut(before) and before["port_directions"][port] == "input" and
                    len(a[port]) == len(b[port]) == 1 and b[port][0][0] in added and b[port][0][1:] == ("Q", 0),
                    "original connection changed outside one selected internal LUT input")
            edges.append({"sink": name, "port": port, "control_driver": a[port][0], "candidate_driver": b[port][0]})
        if before["type"] == "MISTRAL_BUF":
            require(direct_connections(old, name) == direct_connections(new, name) and
                    old.direct_users.get((name, "Q", 0), []) == new.direct_users.get((name, "Q", 0), []), "original BUF connections/users changed: " + name)
    require(len(edges) == 1, "exactly one original internal LUT input must change")
    edge = edges[0]
    root, original_root = edge["candidate_driver"][0], edge["control_driver"]
    require(len(original_root) == 3 and original_root[0] in old.cells and original_root[1:] == ("Q", 0) and
            ready.is_lut(old.cells[original_root[0]]) and new.drivers[new.cells[edge["sink"]]["connections"][edge["port"]][0]] == (root, "Q", 0),
            "selected source/sink does not connect original/new roots directly")
    encoders = sorted(added - {root})
    encoder_outputs = {(name, "Q", 0) for name in encoders}
    bound = set()
    for name in encoders:
        width = lut_shape(new, name)
        tokens = new.lut_inputs(name)
        require(2 <= width <= 4 and len(set(tokens)) == width and all(len(token) == 3 and token[0] in old.cells and token[1:] == ("Q", 0) for token in tokens),
                "encoder is not a single LUT over distinct original boundary Qs")
        bound.update(tokens)
    root_width = lut_shape(new, root)
    root_inputs = new.lut_inputs(root)
    require(root_width == 3 + len(encoders) and len(set(root_inputs)) == root_width and encoder_outputs <= set(root_inputs),
            "new root must consume every encoder plus three free signals")
    free = set(root_inputs) - encoder_outputs
    require(len(bound) == 4 and len(free) == 3 and not bound & free and
            all(len(token) == 3 and token[0] in old.cells and token[1:] == ("Q", 0) for token in free), "actual bound-four/free-three partition invalid")
    boundary = sorted(bound | free)
    for token in boundary:
        require(ranking.pin_snapshot(old, token[0])["pins"].get("Q", [None])[0] == 0, "boundary Q polarity is not SIG")
    visited = set()
    old_tree = old.expression(original_root, set(boundary), visited)
    require(len(visited) == 4 and original_root[0] in visited and edge["sink"] not in visited, "original cone is not exactly four LUTs")
    for name in visited:
        lut_shape(old, name)
    new_visited = set()
    new_tree = new.expression((root, "Q", 0), set(boundary), new_visited)
    require(new_visited == added, "new cone contains undeclared cells or omits an encoder")
    tables, rows = [], []
    for row in range(128):
        values = {token: (row >> index) & 1 for index, token in enumerate(boundary)}
        before, after = previous.evaluate(old_tree, values), previous.evaluate(new_tree, values)
        require(before == after, f"decomposition differs on actual seven-input assignment {row}")
        tables.append(before)
        rows.append({"row": row, "original": before, "decomposed": after})
    require(essential(tables, 7) == set(range(7)), "original raw support is not seven essential inputs")
    for name in encoders + [root]:
        tokens = new.lut_inputs(name)
        leaves, used = set(tokens), set()
        tree = new.expression((name, "Q", 0), leaves, used)
        table = [previous.evaluate(tree, {token: (row >> index) & 1 for index, token in enumerate(tokens)}) for row in range(1 << len(tokens))]
        require(essential(table, len(tokens)) == set(range(len(tokens))), "generated LUT contains an unpruned input: " + name)
    bound, free = sorted(bound), sorted(free)
    encoder_trees = [new.expression(token, set(bound), set()) for token in sorted(encoder_outputs)]
    root_tree = new.expression((root, "Q", 0), set(free) | encoder_outputs, set())
    columns, codes = [], []
    for bound_row in range(16):
        values = {token: (bound_row >> index) & 1 for index, token in enumerate(bound)}
        code = sum(previous.evaluate(tree, values) << index for index, tree in enumerate(encoder_trees))
        column = 0
        for free_row in range(8):
            current = {**values, **{token: (free_row >> index) & 1 for index, token in enumerate(free)}}
            column |= previous.evaluate(old_tree, current) << free_row
        columns.append(column)
        codes.append(code)
    require(2 <= len(set(columns)) <= 1 << len(encoders) and
            len(encoders) == (len(set(columns)) - 1).bit_length() and
            all((columns[a] == columns[b]) == (codes[a] == codes[b]) for a in range(16) for b in range(16)),
            "actual encoder codes are not injective function-column classes")
    for code in set(range(1 << len(encoders))) - set(codes):
        for free_row in range(8):
            values = {token: (free_row >> index) & 1 for index, token in enumerate(free)}
            values.update({token: (code >> index) & 1 for index, token in enumerate(sorted(encoder_outputs))})
            require(previous.evaluate(root_tree, values) == 0, "unused generated code is not zero-completed")
    root_users = new.direct_users.get((root, "Q", 0), [])
    require(root_users == [(edge["sink"], edge["port"], 0)], "new root output has unrelated consumers")
    for token in encoder_outputs:
        expected = [(root, port, 0) for port, tokens in new.inputs(root).items() if tokens == [token]]
        require(new.direct_users.get(token, []) == expected and len(expected) == 1, "encoder output is not private to the new root")
    selected_user = (edge["sink"], edge["port"], 0)
    for token in old.drivers.values():
        before = old.direct_users.get(token, [])
        after = new.direct_users.get(token, [])
        expected = [user for user in before if not (token == original_root and user == selected_user)]
        extras = [user for user in after if user[0] in added]
        require(after == sorted(expected + extras), "original direct consumer entries changed: " + str(token))
    added_nets = set(new_top["netnames"]) - set(old_top["netnames"])
    require(len(added_nets) == len(added) and all(len(new_top["netnames"][name]["bits"]) == 1 for name in added_nets) and
            {new.token(new_top["netnames"][name]["bits"][0]) for name in added_nets} == {(name, "Q", 0) for name in added},
            "new named nets do not exactly cover independent clone outputs")
    compare_named_nets(old_top, new_top, old, new, added_nets, routed=True)
    ranking.top_ports(old_top, new_top, old, new)
    require({key: value for key, value in old_top.items() if key not in {"cells", "netnames", "ports"}} ==
            {key: value for key, value in new_top.items() if key not in {"cells", "netnames", "ports"}}, "routed top metadata changed")
    guide_paths = relevant_guide_edges(old, edge, guide)
    return {"selected_internal_input": edge, "original_cut_nodes": sorted(visited), "boundary_order": boundary,
            "bound_inputs": bound, "free_inputs": free, "encoders": [ready.detail(name, new.cells[name]) for name in encoders],
            "root": ready.detail(root, new.cells[root]), "added_private_q_nets": sorted(added_nets),
            "seven_inputs_essential": True, "assignments_checked": 128, "truth_rows": rows,
            "true_rows": sum(tables), "columns_hex": [hex(value) for value in columns], "encoder_codes": codes,
            "column_classes": len(set(columns)), "unused_codes_zero_completed": True, "guide_path_indices": guide_paths,
            "all_original_cells_params_ports_bels_and_exported_pin_snapshots_preserved_except_selected_input": True,
            "all_original_ff_lut_buf_full_pins_preserved": True,
            "all_original_buffers_preserved": True, "original_named_consumer_entries_preserved_except_selected_input": True,
            "new_outputs_have_only_declared_independent_uses": True, "indexed_store_slot_ids_proved": False,
            "lossless_pll_port_audit": pll_audit,
            "clone_alm_isolation": isolation, "original_relative_export_order": export_order_audit(old_top, new_top),
            "proof_limitations": [SLOT_LIMIT]}


TRIAL = previous.re.compile(r"^Info: Decomposition trial root=(\S+) sink=(\S+)\.(\S+) definition=(\d+) encoders=(\d+) root_bel=(\S+) code_bels=(\S+) gain=([\d.-]+)ps improve=([01]) endpoints=([01]) clocks=([01]) hold=([01]) boundaries=([01])$", previous.re.M)
CANDIDATE = previous.re.compile(r"^Info: Decomposition candidate (\d+): root=(\S+) sink=(\S+)\.(\S+) cut=4 inputs=7 encoders=(\d+) gain=([\d.-]+)ps\.$", previous.re.M)


def geometry_probes(log, complete, selected_trial=None):
    groups, cuts, rows = {}, {}, []
    require(len(list(TRIAL.finditer(log))) == sum(line.startswith("Info: Decomposition trial ") for line in log.splitlines()),
            "malformed decomposition trial row")
    for trial in TRIAL.finditer(log):
        cut = trial.groups()[:3]
        definition = int(trial.group(4))
        require(definition < 840 and int(trial.group(5)) in (1, 2), "invalid definition/encoder count in trial")
        bels = [trial.group(6), *trial.group(7).split(";")]
        require(len(bels) == int(trial.group(5)) + 1 and len(set(bels)) == len(bels), "trial BEL count/uniqueness differs from encoder count")
        labs = []
        for bel in bels:
            match = previous.re.fullmatch(r"MISTRAL_(?:M)?COMB\.([0-9]+)\.([0-9]+)\.([0-9]+)", bel)
            require(match is not None, "unsupported trial BEL: " + bel)
            labs.append((int(match.group(1)), int(match.group(2))))
        key = (*cut, definition)
        group = groups.setdefault(key, {"ordered": set(), "geometries": {}, "timed": 0})
        ordered, geometry = tuple(labs), (labs[0], tuple(sorted(labs[1:])))
        require(ordered not in group["ordered"], "ordered root/encoder LAB tuple was timed twice within a definition")
        group["ordered"].add(ordered)
        group["geometries"][geometry] = group["geometries"].get(geometry, 0) + 1
        group["timed"] += 1
        cuts[cut] = cuts.get(cut, 0) + 1
        require(group["timed"] <= 4 and group["geometries"][geometry] <= 2 and cuts[cut] <= 16,
                "actual timed probes exceed definition/cut/unordered-geometry budget")
        rows.append({"original_root": cut[0], "sink": cut[1], "port": cut[2], "definition": definition,
                     "root_bel": bels[0], "encoder_bels": bels[1:], "ordered_labs": ordered,
                     "root_lab_encoder_lab_multiset": geometry})
    summaries = previous.re.findall(r"^Info: Decomposition probes: root=(\S+) sink=(\S+)\.(\S+) definition=(\d+) timed=(\d+) geometries=(\d+)$", log, previous.re.M)
    require(len(summaries) == sum(line.startswith("Info: Decomposition probes: ") for line in log.splitlines()),
            "malformed decomposition probe summary")
    reported, definitions = {}, {}
    for root, sink, port, definition, timed, geometries in summaries:
        cut, key = (root, sink, port), (root, sink, port, int(definition))
        require(key not in reported and int(definition) < 840, "repeated/invalid definition summary; cut attribution ambiguous")
        group = groups.get(key, {"timed": 0, "geometries": {}})
        require(int(timed) == group["timed"] <= 4 and int(geometries) >= len(group["geometries"]),
                "definition summary timed count/geometry upper bound disagrees with actual rows")
        reported[key] = {"actual_timed": group["timed"], "actual_timed_geometries": len(group["geometries"]),
                         "reported_geometry_keys": int(geometries)}
        definitions.setdefault(cut, set()).add(key[3])
    if selected_trial is not None:
        key = (*selected_trial.groups()[:3], int(selected_trial.group(4)))
        definitions.setdefault(key[:3], set()).add(key[3])
    require(all(len(values) <= 4 for values in definitions.values()), "more than four definitions were probed for one attributed cut")
    if complete:
        missing = set(groups) - set(reported)
        allowed = {(*selected_trial.groups()[:3], int(selected_trial.group(4)))} if selected_trial is not None else set()
        require(missing == allowed, "timed definition lacks rollback summary or final selected trial")
    return {"actual_timed_probes": len(rows), "maximum_probes_per_definition": 4, "maximum_probes_per_attributed_cut": 16,
            "maximum_probes_per_root_lab_encoder_lab_multiset_per_definition": 2, "ordered_lab_tuples_unique_per_definition": True,
            "encoder_lab_multiplicity_preserved": True, "definition_summaries": [{"original_root": key[0], "sink": key[1], "port": key[2],
                "definition": key[3], **value} for key, value in sorted(reported.items())], "rows": rows,
            "geometry_summary_limitations": ["Frozen geometry_counts may include untimed zero-count keys; reported geometry keys are an upper bound.",
                                             "All cap/dedup proofs use actual timed BEL rows; repeated root/sink/definition attribution is rejected."]}


def verify_decomposition_log(log, selection, proof=None, complete=True):
    discovery = previous.re.findall(r"^Info: Decomposition discovery: (\d+) bounded seven-input cuts\.$", log, previous.re.M)
    require(len(discovery) == 1 if complete else len(discovery) <= 1, "decomposition discovery log missing/repeated")
    if discovery:
        require(int(discovery[0]) <= 16, "decomposition discovery exceeded sixteen cuts")
    candidates = list(CANDIDATE.finditer(log))
    require(len(candidates) == sum(line.startswith("Info: Decomposition candidate ") for line in log.splitlines()),
            "malformed decomposition candidate row")
    require([int(match.group(1)) for match in candidates] == list(range(len(candidates))), "decomposition candidate ordinals changed")
    for candidate in candidates:
        trials = list(TRIAL.finditer(log[:candidate.start()]))
        require(trials, "qualified decomposition candidate lacks trial")
        trial = trials[-1]
        require(trial.groups()[:3] == candidate.groups()[1:4] and trial.group(5) == candidate.group(5) and
                float(trial.group(8)) == float(candidate.group(6)) >= 250 and trial.groups()[8:] == ("1",) * 5,
                "qualified decomposition candidate disagrees with guards/trial")
    if not complete:
        return {"qualified_candidates_logged": len(candidates), "log_complete": False,
                "geometry_probes": geometry_probes(log, False)}
    if selection < 0:
        require(f"Info: Decomposition: {len(candidates)} qualified candidates; no candidate applied." in log and
                "Info: Decomposition applied candidate" not in log, "decomposition listing lacks final rollback")
        return {"qualified_candidates": len(candidates), "log_complete": True, "none_applied": True,
                "geometry_probes": geometry_probes(log, True)}
    require(candidates and int(candidates[-1].group(1)) == selection and
            previous.re.findall(r"^Info: Decomposition applied candidate (\d+); full routing and signoff still required\.$", log, previous.re.M) == [str(selection)],
            "selected decomposition candidate was not uniquely applied")
    selected = candidates[-1]
    selected_trial = list(TRIAL.finditer(log[:selected.start()]))[-1]
    if proof is not None:
        edge = proof["selected_internal_input"]
        require(selected.groups()[1:4] == (edge["control_driver"][0], edge["sink"], edge["port"]) and
                int(selected.group(5)) == len(proof["encoders"]), "selected log root/sink/encoder count disagrees with final graph")
        require(selected_trial.group(6) == proof["root"]["bel"] and selected_trial.group(7).split(";") ==
                [encoder["bel"] for encoder in proof["encoders"]], "selected trial clone BELs differ from final graph")
    return {"candidate": selection, "original_root": selected.group(2), "sink": selected.group(3), "port": selected.group(4),
            "encoder_count": int(selected.group(5)), "modeled_gain_ps": float(selected.group(6)), "all_trial_guards_passed": True,
            "actual_final_clone_bels_and_pins_in_graph_proof": proof is not None,
            "selected_trial_bels_match_final_graph": proof is not None,
            "geometry_probes": geometry_probes(log, True, selected_trial)}


def retained_placed_prefix(log, spec, complete):
    # The frozen compiler adds stage headers only for a multi-triple env. This
    # profile has exactly one authenticated retained triple, before discovery.
    require("Info: Placed reduction stage " not in log, "single retained placed stage has an unexpected stage header")
    discoveries = list(previous.re.finditer(r"^Info: Decomposition discovery: \d+ bounded seven-input cuts\.$", log, previous.re.M))
    require(len(discoveries) == 1 if complete else len(discoveries) <= 1, "cannot attribute the retained placed stage before discovery")
    prefix = log[:discoveries[0].start()] if discoveries else log
    suffix = log[len(prefix):]
    require(not any("Placed reduction" in line for line in suffix.splitlines()), "placed reduction messages occur after decomposition discovery")
    messages = [line for line in prefix.splitlines() if line.startswith("Info: Placed reduction trial ")]
    require(all(previous.re.search(r"\broot=" + previous.re.escape(spec["root"]) + r"(?:\s|$)", line) for line in messages),
            "retained placed trial/candidate belongs to a different root")
    return prefix


def local_models(log, plans):
    return [staged.selected_local(block, step) for block, step in
            zip(staged.plan_blocks(log, plans["local_steps"]), plans["local_steps"])]


def discover_local_users(control, candidate, model):
    matches = []
    for name, cell in candidate.cells.items():
        if name in control.cells or not ready.is_lut(cell) or previous.bel(cell) != model["bel"]:
            continue
        users = sorted(ff for ff, item in candidate.cells.items() if item["type"] == "MISTRAL_FF" and
                       candidate.inputs(ff).get("ENA") == [(name, "Q", 0)])
        if not users:
            continue
        root = (model["outer"], "Q", 0)
        require(all(ff in control.cells and control.inputs(ff).get("ENA") == [root] for ff in users),
                "local clone serves an ENA outside its original root")
        selected = [{"ff": ff, "bel": previous.bel(candidate.cells[ff]), "control_driver": root,
                     "candidate_driver": (name, "Q", 0)} for ff in users]
        matches.append((name, selected))
    require(len(matches) == 1, "actual local clone/users cannot be uniquely recovered from stage BEL/root")
    return matches[0]


def partial_local_proof(control, candidate, clone, selected, step, model):
    require(len(selected) == model["selected_ff_count"], "listing local sink count differs from its stage")
    primary, path = staged.recover_local_cut(control, selected, step["report_json"], model)
    proof = ready.prove_clone(control, candidate, clone, selected)
    require(set(proof["retained_cone"]) == {model["inner"], model["outer"]} and proof["control_lut_depth"] == 2,
            "listing local composition differs from the authenticated two-LUT cut")
    root = tuple(proof["control_root"])
    originals = {name for name, cell in control.cells.items() if cell["type"] != "MISTRAL_BUF"}
    before = comb.consumers(control, root, originals)
    after = comb.consumers(candidate, root, originals)
    names = {row["ff"] for row in selected}
    require(primary in names and after == [user for user in before if not
            (user[0] in names and user[1:] == ("ENA", 0))], "listing changed an unselected shared root consumer")
    require(comb.consumers(candidate, (clone, "Q", 0), set(candidate.cells)) ==
            sorted((name, "ENA", 0) for name in names), "listing clone has unrelated consumers")
    groups = {}
    for name in names:
        require(previous.bel(control.cells[name]) == previous.bel(candidate.cells[name]), "listing FF placement changed")
        groups.setdefault(comb.cell_lab(control.cells[name]), []).append(name)
    require(len(groups) == model["selected_group_count"] <= step["groups"], "listing actual LAB groups differ from log/budget")
    for lab, members in groups.items():
        users = [user for user in before if comb.cell_lab(control.cells[user[0]]) == lab]
        require(sorted(user[0] for user in users) == sorted(members) and all(
            control.cells[name]["type"] == "MISTRAL_FF" and port == "ENA" and index == 0 and
            control.inputs(name)["CLK"] == control.inputs(primary)["CLK"] and
            control.pin_states(name).get("CLK", 0) == control.pin_states(primary).get("CLK", 0)
            for name, port, index in users), "listing selected an incomplete or incompatible LAB")
    for key in ("equivalent", "expected_ready_cone", "expected_mask_0xbbbbbbb0"):
        proof.pop(key, None)
    return {**proof, "stage": step["index"], "requested_group_budget": step["groups"],
            "selected_group_count": len(groups), "selected_ff_count": len(names), "primary_ff": primary,
            "selected_lab_groups": [{"lab": lab, "ffs": sorted(members)} for lab, members in sorted(groups.items())],
            "whole_compatible_lab_groups_proved_under_original_pin_assumptions": True,
            "selected_report_path": path, "selected_stage_log": model,
            "matches_control_composition_under_pin_assumptions": True,
            "clone_truth_proof_assumes_unserialized_clone_pins_are_plain_signals": True,
            "pin_state_export_available": False, "final_physical_pin_preservation_proved": False}


def ready_alignment(old_top, candidate_top, plans, log, parent_proof, listing=False):
    """Close the actual ready change before making an algebra-only AC reference."""
    control_top = read_netlist(staged.CONTROL / "routed.json")["modules"]["top"]
    control = Netlist(control_top["cells"], control_top["netnames"])
    original = Netlist(old_top["cells"], old_top["netnames"])
    candidate = Netlist(candidate_top["cells"], candidate_top["netnames"])
    model = local_models(log, plans)[0]
    clone, selected = discover_local_users(control, candidate, model)
    require(clone == parent_proof["local_clone_equivalences"][0]["clone"]["cell"] and clone in original.cells,
            "the frozen pass did not retain the first generated clone identity")
    proof = partial_local_proof(control, candidate, clone, selected, plans["local_steps"][0], model) if listing else \
            staged.prove_local(control, candidate, clone, selected, plans["local_steps"][0], model)
    before_cell, after_cell = original.cells[clone], candidate.cells[clone]
    require(set(before_cell) == set(after_cell) and {key: value for key, value in before_cell.items() if key not in
            {"type", "parameters", "connections", "port_directions", "attributes"}} ==
            {key: value for key, value in after_cell.items() if key not in
            {"type", "parameters", "connections", "port_directions", "attributes"}}, "generated clone metadata changed")
    permitted_attrs = {"NEXTPNR_BEL", "FES_PINMAP_V1"}
    require({key: value for key, value in before_cell["attributes"].items() if key not in permitted_attrs} ==
            {key: value for key, value in after_cell["attributes"].items() if key not in permitted_attrs},
            "generated clone attributes changed outside declared placement/pin snapshots")
    require(set(after_cell["parameters"]) == {"LUT"} and after_cell["port_directions"] == before_cell["port_directions"],
            "generated local LUT parameter/port shape changed")
    if not listing:
        lut_shape(candidate, clone)
    current_users = {row["ff"] for row in selected}
    targets = {"hps_ddr.m1_address_MISTRAL_FF_Q_17", "hps_ddr.m1_address_MISTRAL_FF_Q_11"}
    require(targets <= current_users and all(comb.cell_lab(candidate.cells[name]) == (23, 15) for name in targets),
            "groups8 did not cover both required address ENAs in LAB23,15")
    old_users = {name for name, cell in original.cells.items() if cell["type"] == "MISTRAL_FF" and
                 original.inputs(name).get("ENA") == [(clone, "Q", 0)]}
    union = old_users | current_users
    root = (model["outer"], "Q", 0)
    for name in union:
        require(control.inputs(name).get("ENA") == [root] and
                original.inputs(name).get("ENA") == ([(clone, "Q", 0)] if name in old_users else [root]) and
                candidate.inputs(name).get("ENA") == ([(clone, "Q", 0)] if name in current_users else [root]),
                "changed ready ENA is outside the independently proved old/new selections")
        require({key: value for key, value in original.cells[name].items() if key != "connections"} ==
                {key: value for key, value in candidate.cells[name].items() if key != "connections"},
                "selected original FF type/params/BEL/full pins changed: " + name)
        require({pin: tokens for pin, tokens in direct_connections(original, name).items() if pin != "ENA"} ==
                {pin: tokens for pin, tokens in direct_connections(candidate, name).items() if pin != "ENA"},
                "selected original FF non-ENA connection changed")
        if not listing:
            ranking.pin_snapshot(original, name)
            ranking.pin_snapshot(candidate, name)
    # Preserve named BUF input and Q users independently, before any alignment.
    if not listing:
        old_buffers = {name for name, cell in original.cells.items() if cell["type"] == "MISTRAL_BUF"}
        require(old_buffers == {name for name, cell in candidate.cells.items() if cell["type"] == "MISTRAL_BUF"},
                "original BUF named set changed")
        for name in old_buffers:
            require({key: value for key, value in original.cells[name].items() if key != "connections"} ==
                    {key: value for key, value in candidate.cells[name].items() if key != "connections"} and
                    direct_connections(original, name) == direct_connections(candidate, name) and
                    original.direct_users.get((name, "Q", 0), []) == candidate.direct_users.get((name, "Q", 0), []),
                    "original BUF parameters/pins/direct users changed: " + name)
    bits = {}
    for cell in original.cells.values():
        for values in cell["connections"].values():
            for bit in values:
                token = original.drivers.get(bit, original.token(bit))
                require(token not in bits or bits[token] == bit, "reference has ambiguous direct driver bits")
                bits[token] = bit
    def original_bit(bit):
        token = candidate.drivers.get(bit, candidate.token(bit))
        require(token in bits, "ready clone acquired a new/nonoriginal input or output")
        return bits[token]
    aligned = copy.deepcopy(old_top)
    aligned["cells"][clone] = copy.deepcopy(after_cell)
    aligned["cells"][clone]["connections"] = {pin: [original_bit(bit) for bit in values]
                                              for pin, values in after_cell["connections"].items()}
    for name in union:
        aligned["cells"][name]["connections"]["ENA"] = [original_bit(bit) for bit in candidate.cells[name]["connections"]["ENA"]]
    changed = sorted(name for name in union if original.inputs(name)["ENA"] != candidate.inputs(name)["ENA"])
    return aligned, {"first_local_clone": proof, "actual_changed_ff_enas_vs_parent_g4": changed,
                     "required_target_ena_users": sorted(targets), "required_target_lab": [23, 15],
                     "required_target_ena_coverage_proved": True,
                     "new_selected_ff_count": len(current_users), "old_g4_selected_ff_count": len(old_users),
                     "generated_first_clone_bel_may_differ": True,
                     "alignment_only_copies_proved_generated_clone_and_declared_ff_ena_edges": True,
                     "alignment_is_algebra_only_not_an_independent_route": True,
                     "no_g8_timing_inheritance": True, "partial_pin_assumptions": listing}


def replay_actual_stack(top, plans, log, parent_proof):
    control_top = read_netlist(staged.CONTROL / "routed.json")["modules"]["top"]
    control, candidate = Netlist(control_top["cells"], control_top["netnames"]), Netlist(top["cells"], top["netnames"])
    proofs = []
    for step, model, prior in zip(plans["local_steps"], local_models(log, plans), parent_proof["local_clone_equivalences"]):
        clone, selected = discover_local_users(control, candidate, model)
        require(clone == prior["clone"]["cell"], "retained local clone identity changed")
        proofs.append(staged.prove_local(control, candidate, clone, selected, step, model))
    prior = parent_proof["composed_cut_equivalence"]
    composed = comb.prove_cut(control, candidate, prior["clone"]["cell"], parent_proof["selected_internal_lut_inputs"],
                              read(comb.GUIDE_REPORT), comb.selected_candidate(log, 0))
    require([proof["assignments_checked"] for proof in proofs] == [32, 16, 16] and composed["assignments_checked"] == 32,
            "actual retained local/comb truth-table shapes changed")
    root = plans["placed_specs"][0]["root"]
    parent_top = read_netlist(BEST / "routed.json")["modules"]["top"]
    old_cube = ranking.cube(Netlist(parent_top["cells"], parent_top["netnames"]), root)
    new_cube = ranking.cube(candidate, root)
    require(len(old_cube[0]) == len(new_cube[0]) == 3 and len(old_cube[1]) == len(new_cube[1]) == 11 and
            old_cube[0] == new_cube[0] and old_cube[1] == new_cube[1], "retained placed11 symbolic cube changed")
    placed = {"original_nodes": old_cube[2], "actual_nodes": new_cube[2], "external_literals":
              [{"driver": token, "required": value} for token, value in sorted(new_cube[1].items())],
              "essential_input_count": 11, "symbolic_cube_equivalence": True, "at_most_64_rows_per_lut": True}
    return proofs, composed, placed


def g8_listing_evidence(top, plans, log, parent_proof):
    reference = read_netlist(RANK_LIST / "placed.json")["modules"]["top"]
    aligned, extension = ready_alignment(reference, top, plans, log, parent_proof, listing=True)
    proof = listing_evidence(aligned, top)
    proof.pop("ec3_original_nonbuffer_named_dictionaries_preserved", None)
    proof["original_nonbuffer_dictionaries_preserved_except_proved_ready_budget_change"] = True
    proof["ready_g8_partial_equivalence"] = extension
    control_top = read_netlist(staged.CONTROL / "routed.json")["modules"]["top"]
    control, candidate = Netlist(control_top["cells"], control_top["netnames"]), Netlist(top["cells"], top["netnames"])
    locals_ = []
    for step, model in zip(plans["local_steps"], local_models(log, plans)):
        clone, selected = discover_local_users(control, candidate, model)
        locals_.append(partial_local_proof(control, candidate, clone, selected, step, model))
    proof["local_clone_compositions_under_pin_assumptions"] = locals_
    proof["listing_limitations"].append("The first generated clone/selected ENA set differs from g4; its truth proof uses authenticated original pins and assumes unserialized clone pins are plain signals.")
    return proof


def comparison(folder):
    precursor_folder = OLD / "route-c0"
    early_paths = [folder / "run.json", HERE / "source-identity.json", HERE / "copy-validation.json",
                   HERE / "local-plan.json", HERE / "disabled-control/comparison.json",
                   OLD_HELPER, OLD / "source-identity.json", OLD / "disabled-control/comparison.json",
                   precursor_folder / "run.json", precursor_folder / "comparison.json",
                   RANK_HELPER, *[RANK_LIST / name for name in SEALED_EC3], BEST / "run.json", BEST / "comparison.json"]
    early = {path: sha(path) for path in early_paths}
    require(all(early[RANK_LIST / name] == digest for name, digest in SEALED_EC3.items()), "sealed ec3 reference changed")
    require(early[precursor_folder / "comparison.json"] == SEALED_PREFIX_COMPARISON, "sealed prefix source/graph precursor changed")
    record = read(folder / "run.json")
    require(type(record.get("list_only")) is bool and type(record.get("exit_code")) is int and
            type(record.get("elapsed_seconds")) in (int, float) and math.isfinite(record["elapsed_seconds"]) and record["elapsed_seconds"] >= 0,
            "run metadata is not final")
    success = record.get("completed") is True and record["exit_code"] == 0
    require(success or record["exit_code"] != 0 and record.get("failure"), "unfinished run metadata")
    listing = record["list_only"]
    ec3_proof = ranking.comparison(RANK_LIST)
    require(json.loads(json.dumps(ec3_proof)) == read(RANK_LIST / "comparison.json") and ec3_proof["matched_placement_metrics"] == 71 and
            ec3_proof["new24_listing"]["qualified_candidates"] == 0, "frozen ec3 listing proof changed")
    precursor = predecessor.comparison(precursor_folder)
    require(json.loads(json.dumps(precursor)) == read(precursor_folder / "comparison.json") and
            precursor["graph_proof_available"] and precursor["compiler_commit"] == RESULT_COMMIT,
            "copied 6ad source and full structural precursor changed")
    parent_proof = staged.comparison(BEST)
    require(parent_proof["graph_proof_available"] and parent_proof["local_clone_count"] == 3 and parent_proof["comb_clone_count"] == 1,
            "accepted parent116 graph proof changed")
    parent_record, parent_report, _, parent_log, parent_route = previous.route_evidence(BEST)
    control_record, control_report, _, control_log, _ = previous.route_evidence(staged.CONTROL)
    plans = authenticate_profile(record, parent_record)
    inputs = previous.authenticate_inputs(record)
    source, parent_source = authenticate_compiler(record)
    disabled = authenticate_disabled_control()
    for guide in (BEST, staged.CONTROL, staged.COMB_G4, staged.TWO_ROOT_CONTROL, comb.READY_CONTROL):
        staged.authenticate_guidance(record, guide)
    for path, aliases in ((HERE / "disabled-control/comparison.json", ("disabled_control_sha256",)),
                          (HERE / "disabled-control/candidate.json", ()), (BEST / "run.json", ("control_run_sha256",)),
                          (staged.BASE / "timing.json", ("capture_report_sha256",))):
        staged.authenticated_digest(record, path, aliases)
    runner = HERE / "route.py"
    staged.authenticated_digest(record, runner, ("runner_sha256",))
    require(sha(runner) == SEALED_RUNNER, "sealed groups8 runner changed")
    for name in SEALED_EC3:
        staged.authenticated_digest(record, RANK_LIST / name)
    for path in (OLD / "source-identity.json", OLD / "source.tar.gz", OLD / "acceptance-only-validation.json",
                 OLD / "disabled-control/comparison.json", OLD / "disabled-control/candidate.json",
                 GRANDPARENT / "source-identity.json", GRANDPARENT / "source.tar.gz",
                 RAW / "control-decomposition-264/source-identity.json", RAW / "control-decomposition-264/source.tar.gz"):
        staged.authenticated_digest(record, path)
    listing_proof = None
    if not listing:
        for name in ("run.json", "route.log", "placed.json", "comparison.json"):
            staged.authenticated_digest(record, HERE / "list" / name)
        listed = read(HERE / "list/run.json")
        require(listed.get("completed") is True and listed["exit_code"] == 0 and listed["list_only"] is True and
                listed["compiler_commit"] == RESULT_COMMIT and listed["remap_plan"] == record["remap_plan"],
                "fresh groups8 listing is not a completed matching profile")
        listing_proof = comparison(HERE / "list")
        require(json.loads(json.dumps(listing_proof)) == read(HERE / "list/comparison.json") and
                listing_proof["partial_graph_evidence_available"] and
                listing_proof["decomposition_selection"]["qualified_candidates"] > plans["selection"],
                "fresh groups8 listing structural/log proof changed or candidate absent")
    require(record["build_id"] == parent_record["build_id"] == control_record["build_id"] and record["cwd"] == parent_record["cwd"],
            "fixed BUILD_ID/cwd changed")
    expected = staged.fixed_command(parent_record["command"])
    if listing:
        expected = [item for item in expected if item[0] not in {"--router", "--gpu-device", "--compress-rbf"}]
    require(fixed_command(record["command"]) == expected, "ordinary fixed route/placement options changed")
    for option in ("--json", "--qsf", "--sdc"):
        path = ready.argument(record["command"], option)
        require(path == ready.argument(parent_record["command"], option) and record["input_sha256"].get(path) ==
                parent_record["input_sha256"].get(path), "synthesis/constraint input changed")
    require(record["experimental_capture_locality"] == parent_record["experimental_capture_locality"], "capture locality changed")
    ready.authenticate_execution(record, parent_record)
    log = (folder / "route.log").read_text()
    metrics, parent_metrics = previous.PLACEMENT_METRICS.findall(log), previous.PLACEMENT_METRICS.findall(parent_log)
    require(len(parent_metrics) == 71 and parent_metrics == previous.PLACEMENT_METRICS.findall(control_log) ==
            previous.PLACEMENT_METRICS.findall((RANK_LIST / "route.log").read_text()), "ordinary parent/control/ec3 metrics disagree")
    require(metrics == parent_metrics if success else metrics == parent_metrics[:len(metrics)], "ordinary placement metrics changed")
    placed_prefix = retained_placed_prefix(log, plans["placed_specs"][0], success)
    artifacts = [*early_paths, folder / "route.log", plans["local_file"], Path(__file__).resolve(), runner, HERE / "freeze.py",
                 HERE / "check_disabled_control.py", HERE / "change.patch", HERE / "source.tar.gz", HERE / "nextpnr-mistral",
                 HERE / "disabled-control/loader.log", HERE / "disabled-control/candidate.json",
                 *[Path(path) for path in record["input_sha256"]],
                 *[ready.ROOT / path for proof in (ec3_proof, precursor, parent_proof) for path in proof["artifact_sha256"]]]
    if listing_proof is not None:
        artifacts += [ready.ROOT / path for path in listing_proof["artifact_sha256"]]
    if success:
        artifacts += [folder / "placed.json"] if listing else [folder / name for name in ("timing.json", "routed.json", "core.rbf")]
    artifacts = list(dict.fromkeys(artifacts))
    digests = {path: sha(path) for path in artifacts}
    require(all(digests[path] == digest for path, digest in early.items()), "metadata changed during authentication")
    common = {"status": "experimental groups8 ready plus AC; unselected", "compiler_commit": record["compiler_commit"],
              "base_compiler_commit": source["base_commit"], "source": source, "unchanged_6ad_precursor_source": parent_source,
              "frozen_old_helper_sha256": OLD_HELPER_SHA256, "build_id": record["build_id"],
              "authenticated_inputs": inputs, "disabled_loader_equivalence": disabled,
              "precursor_full_structural_proof_repeated": True,
              "precursor_reference_binding": "sealed comparison-time source/graph reference; no performance inheritance",
              "ec3_listing_proof_repeated": True, "runner_binding": "authenticated compiler-run input",
              "elapsed_seconds": record["elapsed_seconds"], "exit_code": record["exit_code"], "candidate_completed": success,
              "list_only": listing, "local_plan_sha256": plans["local_sha256"], "ready_group_budget": 8,
              "decomposition_guide_sha256": plans["guide_sha256"], "decomposition_candidate": plans["selection"],
              "parent_116": {"path": relative(BEST), "route": parent_route, "comparison_sha256": sha(BEST / "comparison.json"),
                             "full_structural_truth_proof_repeated": True},
              "matched_placement_metrics": len(metrics), "placement_metrics_identical": metrics == parent_metrics,
              "placement_metrics_sha256": hashlib.sha256("\n".join(metrics).encode()).hexdigest(),
              "decomposition_log": [line for line in log.splitlines() if "Decomposition" in line],
              "default_recipe_selected": False, "hardware_tested": False, "no_historical_g8_timing_inheritance": True}
    if not success:
        require("Running the GPU router" not in log and not (folder / "core.rbf").exists() and not (folder / "routed.json").exists(),
                "failed transform emitted/started a route")
        common.update({"status": "groups8 transform failed before route; no acceptance", "failure": record["failure"],
                       "route_started": False, "graph_proof_available": False, "candidate_route": None,
                       "decomposition_selection": verify_decomposition_log(log, plans["selection"], complete=False)})
    else:
        cleaned = "\n".join(line for line in log.splitlines() if not line.startswith("Info: Placed reduction stage "))
        common["retained_transform_stack"] = ready.transform_stack(cleaned, control_log)
        common["retained11_selection"] = ranking.verify_selection(placed_prefix, plans["placed_specs"][0])
        if listing:
            require("Info: Program finished normally." in log and "Running the GPU router" not in log and "--no-route" in record["command"] and
                    "--rbf" not in record["command"] and not (folder / "core.rbf").exists() and not (folder / "routed.json").exists(),
                    "listing routed/emitted final artifacts")
            require(ready.argument(record["command"], "--write") == str(folder / "placed.json"), "listing output path changed")
            top = read_netlist(folder / "placed.json")["modules"]["top"]
            common.update(g8_listing_evidence(top, plans, log, parent_proof))
            common.update({"status": "host-only groups8 final AC listing; partial graph evidence; no route acceptance",
                           "route_started": False, "candidate_route": None,
                           "decomposition_selection": verify_decomposition_log(log, plans["selection"])})
        else:
            actual_record, report, _, final_log, route = previous.route_evidence(folder)
            require(actual_record == record and final_log == log, "route metadata changed during load")
            for option, name in (("--write", "routed.json"), ("--report", "timing.json"), ("--rbf", "core.rbf")):
                require(ready.argument(record["command"], option) == str(folder / name), "route output path changed")
            top = read_netlist(folder / "routed.json")["modules"]["top"]
            old_top = read_netlist(BEST / "routed.json")["modules"]["top"]
            proof_error, proof, extension, locals_, composed, placed = None, None, None, None, None, None
            try:
                aligned, extension = ready_alignment(old_top, top, plans, log, parent_proof)
                proof = prove_rewrite(aligned, top, read(plans["guide"]))
                locals_, composed, placed = replay_actual_stack(top, plans, log, parent_proof)
            except ValueError as error:
                proof_error = str(error)
            require(set(report["fmax"]) == set(ready.REQUIRED_CLOCKS) and all(report["fmax"][clock]["constraint"] >= nominal
                    for clock, nominal in ready.REQUIRED_CLOCKS.items()), "required clock set/constraints changed")
            reports = {"candidate": report, "parent_116": parent_report, "control_115": control_report,
                       "baseline_108": read(staged.BASE / "timing.json"), "ready_control_113": read(comb.READY_CONTROL / "timing.json")}
            clocks = {label: previous.compare_clocks(before, report) for label, before in reports.items() if label != "candidate"}
            raw_gates = {label: all(row["gain_mhz"] >= 0 for row in rows.values()) and
                         rows[ready.MEMORY_CLOCK]["gain_mhz"] > 0 and not route["final_reported_hold_violations"]
                         for label, rows in clocks.items()}
            gates = {label: passes and proof_error is None for label, passes in raw_gates.items()}
            common.update({"graph_proof_available": proof_error is None, "route_started": True, "candidate_route": route,
                           "decomposition_selection": verify_decomposition_log(log, plans["selection"], proof if proof_error is None else None),
                           "fresh_groups8_listing_proof_repeated": True, "fmax_comparisons": clocks,
                           "all_clock_nonregression": {label: all(row["gain_mhz"] >= 0 for row in rows.values()) for label, rows in clocks.items()},
                           "passes_all_clock_constraints": all(row["meets_constraint"] for row in clocks["parent_116"].values()),
                           "passes_raw_timing_gates_without_isolation_acceptance": raw_gates,
                           "passes_strict_diagnostic_gates": gates, "passes_strict_diagnostic_gate_vs_116": gates["parent_116"],
                           "passes_strict_diagnostic_gate_vs_115": gates["control_115"], "passes_strict_diagnostic_gate_vs_108": gates["baseline_108"],
                           "critical_path_comparisons": ready.critical_path_comparison(parent_report, report)})
            reference_log = (HERE / "list/route.log").read_text()
            reference_candidates, current_candidates = list(CANDIDATE.finditer(reference_log)), list(CANDIDATE.finditer(log))
            selected = plans["selection"]
            require(0 <= selected < len(reference_candidates) and current_candidates and
                    current_candidates[-1].group(0) == reference_candidates[selected].group(0), "selected candidate differs from fresh groups8 listing")
            reference_messages = [line for line in reference_log[:reference_candidates[selected].end()].splitlines() if "Decomposition" in line]
            current_messages = [line for line in log[:current_candidates[-1].end()].splitlines() if "Decomposition" in line]
            require(current_messages == reference_messages, "actual AC discovery/trial/candidate prefix differs from fresh groups8 listing")
            require(local_models(log, plans) == local_models(reference_log, plans), "actual local stage models differ from fresh groups8 listing")
            common["actual_local_and_ac_selected_prefix_match_fresh_listing"] = True
            if proof_error is None:
                common.update({"ready_g8_equivalence": extension, "decomposition_equivalence_on_ready_aligned_original_graph": proof,
                               "retained_local_clone_equivalences": locals_, "retained_comb_equivalence": composed,
                               "retained_placed11_symbolic_equivalence": placed, "local_clone_count": 3, "comb_clone_count": 1,
                               "selected_ff_ena_count": sum(row["selected_ff_count"] for row in locals_),
                               "required_target_ena_coverage_proved": extension["required_target_ena_coverage_proved"],
                               "lossless_pll_port_audit": proof["lossless_pll_port_audit"],
                               "retained_selected_ena_arrival_comparisons": staged.selected_ena_arrivals(locals_, reports)})
            else:
                original, candidate = Netlist(old_top["cells"], old_top["netnames"]), Netlist(top["cells"], top["netnames"])
                try:
                    common["lossless_pll_port_audit"] = pll_port_audit(original, candidate)
                except ValueError as error:
                    common["lossless_pll_port_audit"] = {"ordered_duplicate_pll_exports_preserved": False, "rejection": str(error)}
                common.update({"status": "rejected groups8 plus AC; structural/pin/truth/target proof failed",
                               "structural_rejection": proof_error, "ready_g8_equivalence": None,
                               "decomposition_equivalence_on_ready_aligned_original_graph": None,
                               "retained_local_clone_equivalences": None, "retained_comb_equivalence": None,
                               "retained_placed11_symbolic_equivalence": None, "candidate_accepted": False,
                               "rejection_limitations": ["Raw timing is diagnostic only; every strict gate remains false.",
                                                       "No alignment/decomposition/retained-clone equivalence is claimed after proof failure."]})
    require(all(sha(path) == digest for path, digest in digests.items()), "immutable artifacts changed during comparison")
    common.update({"artifact_sha256": {relative(path): digest for path, digest in digests.items()},
                   "final_metadata_stable_during_comparison": True})
    return common


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", nargs="?", default="list", help="finalized listing or full route under ready-g8-decomposition-264")
    args = parser.parse_args()
    folder = (HERE / args.run).resolve()
    require(folder.parent == HERE, "run must be a direct child of this experiment")
    result = comparison(folder)
    (folder / "comparison.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    keys = ("status", "compiler_commit", "candidate_completed", "list_only", "elapsed_seconds", "exit_code", "matched_placement_metrics",
            "graph_proof_available", "partial_graph_evidence_available", "decomposition_selection", "candidate_route", "fmax_comparisons",
            "all_clock_nonregression", "passes_strict_diagnostic_gates", "default_recipe_selected", "hardware_tested")
    print(json.dumps({key: result[key] for key in keys if key in result}, indent=2))


if __name__ == "__main__":
    main()
