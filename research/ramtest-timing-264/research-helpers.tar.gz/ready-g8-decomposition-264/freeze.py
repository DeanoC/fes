"""Root-operated byte copy of sealed 6ad; no compiler/source build or mutation."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
PARENT = RAW / "control-decomposition-prefix-264"
BEST = RAW / "remap-plan-264/route-c0-g1-third-c0-g1"
COMMIT = "6ad210a60991f93a607ac4490d6282b1267ec64a"
BASE = "ec3fc0156a60a3d3193142def03d992a875aaab0"
SEALED = {
    "nextpnr-mistral": "ba39ad814af51c4a6af3ca1854fcd1dd992af350bb09741d5b6becfa2d7d4b18",
    "source.tar.gz": "af9b2c05bc7e4fe513f7f879d06c51c94fb696d2bde23469400fc7d041eff209",
    "source-identity.json": "2cc4985c404ac5e2047a359df3682af51dabf033f95b3ff57adc46e9fe80d4ac",
}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("Nonfinite metadata: " + value)
    return json.loads(path.read_text(), object_pairs_hook=unique, parse_constant=nonfinite)

assert all(sha(PARENT / name) == digest for name, digest in SEALED.items())
source = read(PARENT / "source-identity.json")
assert source["base_commit"] == BASE and source["result_commit"] == COMMIT
assert source["binary_sha256"] == SEALED["nextpnr-mistral"]
assert source["source_archive_sha256"] == SEALED["source.tar.gz"]
parent = read(BEST / "run.json")
assert parent["completed"] and parent["exit_code"] == 0 and not parent["list_only"]
plan_file = Path(parent["command"][parent["command"].index("--remap-plan") + 1])
plan = read(plan_file)
assert plan == parent["remap_plan"] and len(plan["steps"]) == 3
assert [step["groups"] for step in plan["steps"]] == [4, 1, 1]
assert all(step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True
           for step in plan["steps"])
assert parent["input_sha256"][str(plan_file)] == sha(plan_file)
assert not any((HERE / name).exists() for name in (*SEALED, "change.patch", "local-plan.json", "copy-validation.json"))
for name in (*SEALED, "change.patch"):
    shutil.copy2(PARENT / name, HERE / name)
new_plan = json.loads(json.dumps(plan))
new_plan["steps"][0]["groups"] = 8
(HERE / "local-plan.json").write_text(json.dumps(new_plan, sort_keys=True, indent=2) + "\n")
record = {
    "compiler_commit": COMMIT, "base_commit": BASE, "compiler_bytes_unchanged": True,
    "copied_from": str(PARENT), "hardware_tested": False,
    "input_sha256": {str(PARENT / name): sha(PARENT / name) for name in (*SEALED, "change.patch")},
    "output_sha256": {name: sha(HERE / name) for name in (*SEALED, "change.patch")},
    "parent_plan": str(plan_file), "parent_plan_sha256": sha(plan_file),
    "local_plan_sha256": sha(HERE / "local-plan.json"),
    "only_profile_change": "first local step groups 4 to 8",
    "no_timing_inheritance": True,
}
(HERE / "copy-validation.json").write_text(json.dumps(record, sort_keys=True, indent=2) + "\n")
print(json.dumps(record, indent=2), flush=True)

