# Eight ready groups plus decomposition: phase margin regression

Frozen compiler `6ad210a60991f93a607ac4490d6282b1267ec64a`. This experiment changes the first existing local-remap group budget from four to eight; the other two stages and all later transformations are retained. No compiler or RTL change is introduced.

Fresh listing completed in 530.881999 seconds and qualified 16 decomposition candidates, all with 917 ps modeled gain. It selected 21 ENAs for the first local copy, then 2 and 10 for the other copies. Both formerly limiting address-enable registers at LAB23,15 use the first copy. Independent listing proof matched all 71 placement measurements and rechecked all actual compatible groups, with explicit limitations for unserialized pins. Listing comparison SHA256: `20b7f1dc20c5ef5d2bbb1fb789e2bb00d2d77b08afaff3c7b0d07a7c06d9976d`.

Candidate 0 completed a full GPU1 route in 757.868041 seconds, exit 0, with no final reported hold violations.

| Clock | Retained parent MHz | Candidate MHz |
| --- | ---: | ---: |
| Memory | 116.171005 | 116.279068 |
| Pixel | 93.668045 | 93.896713 |
| SDRAM phase | 378.582397 | 307.631805 |

The full graph proof passes the actual enlarged ready copy and all three retained local compositions, the retained internal cut and placed reduction, all 128 decomposition assignments, original FF/LUT/BEL/full pins, BUF sets/users, PLL outputs, consumer preservation and clone isolation. It changes the algebraic reference only for the independently proved first generated copy and its declared ENA edges. Full comparison SHA256: `3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e`.

Reject against the retained parent because phase margin regresses. The candidate passes the older 115 MHz control gate, but this does not replace the current parent. No package or hardware acceptance is claimed.

Memory is now limited by DDR0 group_bad Q11 through six original LUTs to error-counter Q18.ENA; the previously targeted ready-control group is no longer the reported limiter. The phase limiter remains the sampled-DQ-to-hold-register path. A separate same-profile experiment changes only the existing GPU `repairBand` setting to 3000 ps, so that the passing phase path becomes eligible during initial repair. It owns its route and final proof and reuses only the authenticated qualification listing.
