"""Root-operated groups8 ready remap followed by retained transforms and AC."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
RAW = HERE.parent
BEST = RAW / "remap-plan-264/route-c0-g1-third-c0-g1"
BASE = "ec3fc0156a60a3d3193142def03d992a875aaab0"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sys.path.insert(0, str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation
from scripts.search_placer_qor import _score_report, has_failed_route_arc
from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--candidate", type=int, default=0)
parser.add_argument("--list", action="store_true")
args = parser.parse_args()
assert args.candidate == 0, "This bounded profile selects AC candidate zero only."
previous = json.loads((BEST / "run.json").read_text())
assert previous["completed"] and previous["exit_code"] == 0 and not previous["final_reported_hold_violations"]
for filename, digest in previous["input_sha256"].items():
    assert sha(Path(filename)) == digest
old_command = previous["command"]
value = lambda option: old_command[old_command.index(option) + 1]
parent_local_file = Path(value("--remap-plan"))
parent_local_plan = json.loads(parent_local_file.read_text())
assert parent_local_plan == previous["remap_plan"] and len(parent_local_plan["steps"]) == 3
assert [step["groups"] for step in parent_local_plan["steps"]] == [4, 1, 1]
local_file = HERE / "local-plan.json"
local_plan = json.loads(local_file.read_text())
expected_plan = json.loads(json.dumps(parent_local_plan))
expected_plan["steps"][0]["groups"] = 8
assert local_plan == expected_plan
assert all(step["candidate"] == 0 and step["preserve_ff_placement"] and not step["optimize_pins"]
           for step in local_plan["steps"])
comb_guide = Path(value("--remap-comb-critical"))
assert value("--remap-comb-candidate") == "0"
reports = list(dict.fromkeys([Path(step["report"]) for step in local_plan["steps"]] + [comb_guide]))
lineage = []
for report in reports + [BEST / "timing.json"]:
    run, comparison = report.parent / "run.json", report.parent / "comparison.json"
    data = json.loads(run.read_text())
    assert data["completed"] and data["exit_code"] == 0
    trusted = json.loads(comparison.read_text())["artifact_sha256"]
    for name in ("run.json", "route.log", "timing.json", "routed.json", "core.rbf"):
        artifact = report.parent / name
        assert trusted[str(artifact.relative_to(ROOT))] == sha(artifact)
    lineage.extend((run, comparison))
freeze = json.loads((HERE / "source-identity.json").read_text())
binary, archive = HERE / "nextpnr-mistral", HERE / "source.tar.gz"
assert freeze["base_commit"] == BASE and freeze["result_commit"] == "6ad210a60991f93a607ac4490d6282b1267ec64a"
assert freeze == json.loads((RAW / "control-decomposition-prefix-264/source-identity.json").read_text())
assert sha(binary) == freeze["binary_sha256"] and sha(archive) == freeze["source_archive_sha256"]
disabled = HERE / "disabled-control/comparison.json"
disabled_record = json.loads(disabled.read_text())
assert disabled_record["completed"] and disabled_record["exit_code"] == 0
assert sha(HERE / "disabled-control/candidate.json") == disabled_record["candidate_sha256"]
for filename, digest in disabled_record["input_sha256"].items():
    assert sha(Path(filename)) == digest
output = HERE / ("list" if args.list else f"route-c{args.candidate}")
output.mkdir(exist_ok=False)
identity = f"base_commit={BASE}; experimental_source_sha256={sha(archive)}; sha256={sha(binary)}"
invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, identity)}, 1)
command, index = [str(binary)], 1
removed = {"--write", "--report", "--rbf"}
if args.list:
    removed |= {"--router", "--gpu-device"}
while index < len(old_command):
    if old_command[index] in removed:
        index += 2
    elif args.list and old_command[index] == "--compress-rbf":
        index += 1
    elif old_command[index] == "--remap-plan":
        command += ["--remap-plan", str(local_file)]
        index += 2
    else:
        command.append(old_command[index])
        index += 1
command += ["--write", str(output / ("placed.json" if args.list else "routed.json"))]
if args.list:
    command += ["--no-route"]
else:
    command += ["--report", str(output / "timing.json"), "--rbf", str(output / "core.rbf")]
capture_report = Path(previous["experimental_capture_locality"].rsplit(" ", 2)[0])
inputs = list(dict.fromkeys([binary, archive, HERE / "source-identity.json", HERE / "copy-validation.json",
                            Path(value("--json")), Path(value("--qsf")), Path(value("--sdc")),
                            local_file, parent_local_file, capture_report, disabled, HERE / "disabled-control/candidate.json",
                            *reports, BEST / "timing.json", BEST / "routed.json", *lineage,
                            Path(__file__).resolve(),
                            RAW / "control-decomposition-prefix-264/source-identity.json",
                            RAW / "control-decomposition-prefix-264/source.tar.gz",
                            RAW / "control-decomposition-prefix-264/acceptance-only-validation.json",
                            RAW / "control-decomposition-prefix-264/disabled-control/comparison.json",
                            RAW / "control-decomposition-prefix-264/disabled-control/candidate.json",
                            RAW / "control-decomposition-264/source-identity.json",
                            RAW / "control-decomposition-264/source.tar.gz",
                            *(RAW / "root-pin-ranking-264/list-r6" / name for name in
                              ("run.json", "comparison.json", "route.log", "placed.json")),
                            RAW / "control-decomposition-isolation-264/source-identity.json",
                            RAW / "control-decomposition-isolation-264/source.tar.gz"]))
copy_validation = json.loads((HERE / "copy-validation.json").read_text())
assert copy_validation["compiler_commit"] == freeze["result_commit"] and copy_validation["compiler_bytes_unchanged"]
for filename, digest in copy_validation["input_sha256"].items():
    assert sha(Path(filename)) == digest
for filename, digest in copy_validation["output_sha256"].items():
    assert sha(HERE / filename) == digest
if not args.list:
    listing = HERE / "list"
    listed = json.loads((listing / "run.json").read_text())
    proof = json.loads((listing / "comparison.json").read_text())
    assert listed["completed"] and listed["exit_code"] == 0 and listed["list_only"]
    assert listed["compiler_commit"] == freeze["result_commit"] and listed["remap_plan"] == local_plan
    assert proof["partial_graph_evidence_available"] and not proof["graph_proof_available"]
    assert proof["decomposition_selection"]["none_applied"] and proof["decomposition_selection"]["qualified_candidates"] > args.candidate
    for filename, digest in proof["artifact_sha256"].items():
        assert sha(ROOT / filename) == digest
    inputs += [listing / name for name in ("run.json", "route.log", "placed.json", "comparison.json")]
inputs = list(dict.fromkeys(inputs))
env = dict(invocation.env)
env["NEXTPNR_MISTRAL_CAPTURE_LOCALITY"] = previous["experimental_capture_locality"]
env["NEXTPNR_MISTRAL_PLACED_REDUCTION"] = previous["experimental_placed_reduction"]
command += ["--remap-decompose-critical", str(BEST / "timing.json")]
if not args.list:
    command += ["--remap-decompose-candidate", str(args.candidate)]
record = {"ready_group_budget": 8, "fresh_listing": args.list, "compiler_bytes_unchanged": True,
          "runner_sha256": sha(Path(__file__).resolve()), "kind": "host-only groups8 final AC listing" if args.list else "scratch groups8 full HIP route; unselected",
          "command": command, "cwd": str(MODULE), "tool_identity": identity,
          "base_compiler_commit": BASE,
          "compiler_commit": freeze["result_commit"],
          "build_id": previous["build_id"], "execution": invocation.inputs, "completed": False,
          "input_sha256": {str(path): sha(path) for path in inputs}, "source_archive_sha256": sha(archive),
          "experimental_capture_locality": env["NEXTPNR_MISTRAL_CAPTURE_LOCALITY"],
          "experimental_placed_reduction": env["NEXTPNR_MISTRAL_PLACED_REDUCTION"],
          "decomposition_report_sha256": sha(BEST / "timing.json"),
          "decomposition_selection": -1 if args.list else args.candidate,
          "capture_report_sha256": sha(capture_report), "control_run_sha256": sha(BEST / "run.json"),
          "remap_plan": local_plan, "remap_plan_sha256": sha(local_file),
          "retained_comb_report_sha256": sha(comb_guide), "disabled_control_sha256": sha(disabled),
          "list_only": args.list, "hardware_acceptance": False}
manifest = output / "run.json"
manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
start = time.monotonic()
try:
    with (output / "route.log").open("w") as log:
        result = audited_run(command, source_root=MODULE, cwd=MODULE, env=env, stdout=log,
                             stderr=subprocess.STDOUT, check=False, timeout=2400)
    record["exit_code"] = result.returncode
    record["elapsed_seconds"] = time.monotonic() - start
    invocation.verify()
    for filename, digest in record["input_sha256"].items():
        assert sha(Path(filename)) == digest
    log = (output / "route.log").read_text()
    assert result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log)
    if args.list:
        assert not (output / "core.rbf").exists() and (output / "placed.json").exists()
    else:
        board._require_gpu_backend(log)
        assert (output / "core.rbf").stat().st_size > 0 and "Running signoff timing analysis..." in log
        record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
        report = json.loads((output / "timing.json").read_text())
        _score_report(report, REQUIRED_CLOCKS)
        assert set(report["fmax"]) == {name for name, _ in REQUIRED_CLOCKS}
        record["fmax"] = report["fmax"]
    record["completed"] = True
    print(json.dumps({key: record[key] for key in ("completed", "elapsed_seconds", "list_only", "fmax",
                      "final_reported_hold_violations") if key in record}, indent=2), flush=True)
except BaseException as exc:
    record["failure"] = repr(exc)
    record["elapsed_seconds"] = time.monotonic() - start
    if "exit_code" not in record:
        record["exit_code"] = 124 if isinstance(exc, subprocess.TimeoutExpired) else 1
        record["exit_code_is_adapter_sentinel"] = True
    raise
finally:
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    invocation.close()
