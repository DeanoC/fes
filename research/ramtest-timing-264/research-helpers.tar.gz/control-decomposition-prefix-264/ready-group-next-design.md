# Next bounded ready-group experiment

Use frozen compiler `6ad210a60991f93a607ac4490d6282b1267ec64a` and change only
the first local-plan step's group budget **4 -> 8**. Keep its existing full115
guide and candidate0; keep the other two local steps, legacy comb candidate0,
capture diagnostic, placed11 diagnostic and decomposition candidate0 unchanged.
No compiler change is needed. This is a fresh experiment, not inherited timing
acceptance from the earlier g8 route.

## Fresh target and fourth-step blocker

`route-c0/timing.json` reports memory 116.0227356, pixel 93.475418 and phase
307.631805 MHz, exit0/no final reported holds. Its 8.619 ns memory limiter is
`cmd_ready_1 -> port1.slot_free_ALUT2_Q.A -> slot_free_ALUT4_C.C ->
m1_address_Q17.ENA` at LAB `(23,15)`. The report SHA256 is
`519356d349793806cfa6d20595438f4f32ce6e230e65a1e88fe39b3b5acdc000`.

The actual inner/outer masks are `0xb` and `0xf0e0`, with ordinary signal pin
states. In compiler traversal order the five distinct external drivers are:

1. `hps_ddr.f2sdram.cmd_ready_1`
2. `hps_ddr.f2sdram_cmd_valid_1_MISTRAL_ALUT2_Q.Q`
3. `hps_ddr.port1.skid_MISTRAL_FF_Q.Q`
4. `hps_ddr.port1.enter_read_MISTRAL_ALUT5_Q.Q`
5. `hps_ddr.port1.enter_write_MISTRAL_ALUT2_Q.Q`

Independent evaluation of all 32 assignments gives composed mask
`0xbbbbbbb0`; all five inputs are essential, within the existing <=6-input
local composer. The original ready root has exactly two users in LAB `(23,15)`:
`hps_ddr.m1_address_MISTRAL_FF_Q_17` at FF23.15.46 and Q11 at FF23.15.50.
Both use the same memory clock with signal clock/ENA polarity, weak placement
and no exported protection attributes. Their original root connection remains
in the fresh route. Final routed BUFs are not pre-route protection evidence.

A fourth local step using this fresh report, groups1, pins=false and fixed FFs
would otherwise identify the correct terminal two-LUT cone. It cannot execute
on frozen6ad: `local_remap.cc` names a clone solely `outer.name +
"$local_remap"`, and skips a cone when that cell/net/alias exists. Stage one
already owns `hps_ddr.port1.slot_free_MISTRAL_ALUT4_C$local_remap`. A selected
fourth candidate would fail closed before routing. There is no existing option
to reuse that clone for extra users or create a second same-outer copy.

## Existing g8 evidence and bounded choice

The earlier completed `../comb-remap-264/route-c0-ready-g8/` contains
`run.json`, `routed.json`, `timing.json` and `comparison.json`. Its authenticated
g8 proof already attaches both target FFs to this ready-function clone. Its
eight selected LAB groups were:

| LAB | ENAs | Included in g4 |
| --- | ---: | --- |
| 24,13 | 2 | yes |
| 24,12 | 5 | yes |
| 29,13 | 2 | yes |
| 30,13 | 2 | yes |
| 23,14 | 1 | no |
| 23,15 | 2 | no |
| 24,14 | 6 | no |
| 29,15 | 1 | no |

Compare `../comb-remap-264/route-c0-ready-g4/` for the original four groups.
That old g8 clone used MCOMB25.13.0 and mask `0xbbbbbbb0`, but the new trial
must discover and prove its actual selected site and users. The earlier g8
route measured 114.012085 / 92.747177 / 378.582397 MHz in a smaller stack;
those numbers are not a prediction or acceptance for the new stack.
Budget8 is an upper bound, not proof that eight groups or these exact users
will requalify. Require actual coverage of both LAB23,15 target FFs. Budgets5..7
have no established target-coverage evidence here.

The plan runs all local steps immediately after ordinary placement and prior
diagnostics, then legacy comb, capture, placed11 and decomposition. Thus the
budget enlargement is qualified before these later transformations. The
unchanged second guide ends at the different port1 ALUT3_B skid root; the
third guide ends at the port0 ALUT3_B skid root. Revalidate those paths and
later candidate0 qualifications in the newly staged graph.

No listing is necessary to establish that old g8 covered this target, but it
does not prove current qualification. A diagnostic local listing must use a
final -1, --no-route and no RBF, and omit decomposition: the CLI rejects local
listing before decomposition. Do not list a nonexistent fourth same-root
step. A direct selected trial remains bounded and fails before routing if any
requested stage does not qualify.

## Evidence and acceptance changes

Freeze new plan bytes and runner identity; authenticate all unchanged input,
guide, source/archive/binary hashes and the earlier g4/g8 proofs. Preserve the
parent116, prefix c0 and all previous artifacts. Use the fresh report above as
the diagnosis reference; the first compiler guide remains the old full115
report so only its budget changes.

Reprove all three local closures from an authenticated precursor, using actual
selected users, masks, pins, sites and logged group counts. Declare the first
generated copy's site and ENA-set changes as intentional; do not require its
old g4 BEL or generated pin map to match a fresh g8 copy. Discover actual
counts rather than assuming the old g8 totals. The known old selection would
add 12 ENAs, for 35 total across the three local copies.

Preservation remains strict for all reference original FF/LUT BELs,
parameters, full pins, BUFs and unselected consumers, with only the proven
selected ENAs/internal inputs allowed to change. Reprove retained comb truth,
capture/placed11 provenance and the actual decomposition's 128 rows, ALM
isolation and owner-prefix invariants. Do not weaken original pin/BUF gates to
permit another generated copy. Listing lacks independent routed-pin proof.

Acceptance requires complete route/RBF provenance, unchanged constraints and
all preceding placement metrics, no final holds, and all-clock nonregression
against retained parent116 (116.171005 / 93.668045 / 378.582397 MHz). Also report
the same-source prefix c0 comparison, target arrivals and all unselected
groups. A local modeled gain >=250 ps is qualification only; root performs
all listings, routes and final comparisons. This note changes no source,
runner or helper and claims no hardware acceptance.
