# Exact original GPU index control

Delta over fddbdac2d966ff3c2455e8b93ee221c71156fad7. Only successful selected
acceptance changes: allocate both replacement owner dictionaries and resolve
all source/destination slots before moving any unique_ptr. Insert clone keys
first, then reversed original keys. Thus original owners are the exact iterator
prefix, new clones the suffix. Keep live=true through final check for rollback.
No new port/user/BEL/pin changes. All25 focused tests and an unconditional exact
prefix regression must pass; fdd must first fail the new regression.

Listing/candidate ordinal, placement/model ranking and eligibility paths are
byte-identical after stripping only this successful-acceptance block. Reuse the
sealed fdd listing, authenticate both source archives and mechanically prove
that the candidate source outside this block is identical before routing.
The full route is fresh using the same fixed inputs/parent116 profile and GPU1.

This removes original net ID shifts, not every routing perturbation: added
loads, queue length and shuffle draws still change. No clock recovery is
assumed. Require all original pin/BUF/consumer preservation, exact truth and
all-clock/hold gates before the next-gain PR milestone. Host-only/unselected.
