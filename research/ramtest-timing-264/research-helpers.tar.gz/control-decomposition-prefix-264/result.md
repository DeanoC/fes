# Exact original owner prefix: rejected routed timing

Source `6ad210a60991f93a607ac4490d6282b1267ec64a`, over `fddbdac2d966ff3c2455e8b93ee221c71156fad7`. The accepted decomposition appends clones after original cell/net iterator entries. Disabled behavior is unchanged. The new prefix regression fails on the parent; all 25 focused policy/backend tests pass on this source, and both compiler targets build.

Candidate 0 completed in 748.888610 seconds using GPU device 1, exit 0, without hold violations.

| Clock | Retained parent MHz | Candidate MHz |
| --- | ---: | ---: |
| Memory | 116.171005 | 116.022736 |
| Pixel | 93.668045 | 93.475418 |
| SDRAM phase | 378.582397 | 307.631805 |

Reject on strict routed timing. The full graph comparison passes the actual 128-row decomposition truth table, retained transformations, all original BELs/full pin assignments, buffer sets/users, clone ALM isolation, both duplicate PLL output occurrences, and exact original-owner iterator prefix. All four strict timing gates fail.

Final comparison SHA256: `6c0d617004c4cedbe89de533f30f994663cc68c8d29902650bbc92203094cb4d`. Frozen helper SHA256: `46b300b7ea30ed3a34f89082ef52abe32f54a0d18ae40518c16fc3cb25df428e`.

The fdd listing is reused only after source authentication proves that code outside successful selected acceptance is byte-identical. This is a fresh full route, not a fresh listing. Original GPU IDs remain stable; added fanout and total shuffle length can still affect routing. No claim of equivalent physical-route calibration or hardware acceptance follows.

The memory bottleneck remains the ready-control path into the port1 address-enable group. The next isolated experiment expands the existing first local-remap stage from four to eight compatible groups, with later stages unchanged. It needs its own fresh listing, route and preservation proof; historical eight-group timing is not inherited.
