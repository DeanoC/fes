"""Freeze the generic seven-input control decomposition compiler; root-operated only."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SRC = ROOT / "sources/misteross/build/toolchain-ramtest-timing/src/nextpnr"
BUILD = ROOT / "sources/misteross/build/toolchain-ramtest-timing/build/nextpnr"
BASE = "ec3fc0156a60a3d3193142def03d992a875aaab0"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

result = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SRC, text=True).strip()
assert result != BASE
subprocess.run(["git", "merge-base", "--is-ancestor", BASE, result], cwd=SRC, check=True)
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=SRC, text=True).strip()
assert not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json"))
tracked = subprocess.check_output(["git", "diff", "--name-only", BASE, result], cwd=SRC, text=True).splitlines()
untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard"], cwd=SRC, text=True).splitlines()
files = sorted(set(tracked + untracked))
assert files and all((name.startswith("mistral/") or name == "common/kernel/timing.h") and (SRC / name).is_file() for name in files)
shutil.copy2(BUILD / "nextpnr-mistral", HERE / "nextpnr-mistral")
with tarfile.open(HERE / "source.tar.gz", "w:gz") as archive:
    for name in files:
        archive.add(SRC / name, arcname=name)
(HERE / "change.patch").write_bytes(subprocess.check_output(["git", "diff", BASE], cwd=SRC))
record = {"delta_base_commit": "fddbdac2d966ff3c2455e8b93ee221c71156fad7", "base_commit": BASE, "result_commit": result,
          "source_sha256": {name: sha(SRC / name) for name in files},
          "binary_sha256": sha(HERE / "nextpnr-mistral"),
          "source_archive_sha256": sha(HERE / "source.tar.gz"),
          "branch": subprocess.check_output(["git", "branch", "--show-current"], cwd=SRC, text=True).strip(),
          "status": "committed generic seven-input control decomposition experiment; no default/package selection"}
(HERE / "source-identity.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
print(json.dumps(record, indent=2), flush=True)
