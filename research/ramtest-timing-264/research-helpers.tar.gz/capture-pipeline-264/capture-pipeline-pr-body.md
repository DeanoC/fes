When a registered fixed hard-block output feeds a plain capture FF whose only consumer is a second plain FF, placing only the first FF near the block can leave a long internal hop. This adds an opt-in pass that places both existing FFs together while preserving the graph, initialization and latency.

Discovery uses cell types, timing arcs and graph structure. Each trial checks native LAB legality, complete affected clock-pair setup/hold timing, unrelated clock pairs and global Fmax; rejection restores both placements and architecture/LAB state. The request is read before packing, requires successful ordinary HeAP placement, and stays default off.

Stacked on #109. Host checks passed: 32 native cases and 11 CLI methods. Two independently checked full RAM-test routes improve a matched fresh-main baseline of 105.775330 MHz:

| Explicit configuration | Memory MHz | Gain MHz | Pixel MHz |
| --- | ---: | ---: | ---: |
| Budget 8, radius 24 | 105.864914 | +0.089584 | 95.565750 |
| Budget 64, radius 24 | 106.123314 | +0.347984 | 93.905533 |

Both keep all six required non-target clock windows positive and report no final hold violations. Pixel Fmax decreases but still passes 74.25 MHz. Memory still misses 130 MHz. The separate frozen 117.868927 MHz composed stack uses an older compiler/configuration/HeAP baseline and remains unchanged; these fresh-main results do not inherit that qualification.

The validation record includes measured compiler/input/output/proof hashes and all seven clock windows. Independent checks cover the exported native graph, register latency/initial values, complete affected LAB snapshots, packed functions and explicit route-through buffers. They do not independently decode route muxes or RBF bytes or establish hardware acceptance. No FES RTL, compiler pins, default recipe or constraints change.

Related investigation: https://github.com/DeanoC/fes/issues/264
