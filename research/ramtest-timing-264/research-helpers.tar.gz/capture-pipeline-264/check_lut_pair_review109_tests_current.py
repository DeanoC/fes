#!/usr/bin/env python3
"""Test the authenticated current PR109 build under an explicitly separate test environment."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

WORK = Path('/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d')
HERE = WORK / 'out/ramtest-wide-reduction-264/capture-pipeline-264'
HELPER = HERE / 'check_lut_pair_review109_current.py'
HELPER_SHA = '3223e4d37388ef82727f75351366c4a1c03fb8605d2c413eb2768feda49880c4'
CONFIG = HERE / 'lut-pair-review109-current-check-configure-v1/record.json'
CONFIG_SHA = 'f6b4cd222374ac6efbb52c132fe1c1e35e858afbd02b9cbc6f1853ec554dca2c'
BUILT = HERE / 'lut-pair-review109-current-check-build-v1/record.json'
BUILT_SHA = '6584df819ac4935f5ece84fd9648f7ad31e17fbcac656e2f2dcb812d3033f383'
BUILD_ENV_SHA = 'e28d3c983e3fa208b448f76bb8f69cc21b3e647840a4250de72bd3ea39988b0c'
ENV = {key: value for key, value in os.environ.items() if key in {
    'PATH', 'HOME', 'TMPDIR', 'LD_LIBRARY_PATH', 'CMAKE_PREFIX_PATH', 'PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR',
    'ROCM_PATH', 'ROCM_ROOT', 'HIP_PATH', 'HIP_ROCCLR_HOME', 'HIP_DEVICE_LIB_PATH', 'HSA_PATH'}}
ENV.update(LANG='C', LC_ALL='C', TZ='UTC')

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load_helper():
    require(sha(HELPER) == HELPER_SHA, 'reviewed helper bytes changed')
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('review109_tests_readonly_helpers', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    require(helper.ENV == ENV, 'readonly helper/test environment differs')
    return helper  # Only inputs(), elfs(), sha() and their pure dependencies are called; main never runs.

def authenticate(helper, ctest, expected):
    require(sha(CONFIG) == CONFIG_SHA and sha(BUILT) == BUILT_SHA, 'closed configure/build record changed')
    config, built = json.loads(CONFIG.read_text()), json.loads(BUILT.read_text())
    selected = helper.inputs(); executables = helper.elfs()
    paths = {str(HELPER): HELPER_SHA, str(Path(__file__).resolve()): expected,
             str(CONFIG): CONFIG_SHA, str(BUILT): BUILT_SHA, str(ctest): sha(ctest)}
    for stage, record, path in (('configure', config, CONFIG), ('build', built, BUILT)):
        require(record['schema'] == 'lut-pair-review109-current-check-v1' and record['stage'] == stage and
                record['state'] == 'passed' and record['exit_code'] == 0 and record['inputs_unchanged'] is True and
                record['recorder_sha256'] == record['recorder_after_sha256'] == HELPER_SHA and
                record['inputs_before'] == record['inputs_after'] == selected and
                record['command'] == helper.COMMANDS[stage] and record['cwd'] == str(helper.SOURCE) and
                record['environment_values_sha256'] == BUILD_ENV_SHA and record['tests_run'] is False and
                all(record[key] is False for key in ('compiled_commit_asserted', 'gain_qualified', 'full_route', 'hardware',
                                                     'historical_full_model_data_equivalence_proved')), 'archived build closure/claim differs')
        paths[str(path.parent / 'output.log')] = record['log_sha256']
        for name, digest in record['bindings_after_sha256'].items():
            key = str(helper.BUILD / name)
            require(key not in paths or paths[key] == digest, 'binding identities conflict'); paths[key] = digest
    cache = helper.BUILD / 'CMakeCache.txt'
    require(config['cache_after_sha256'] == built['cache_before_sha256'] == built['cache_after_sha256'] == sha(cache), 'cache differs')
    paths[str(cache)] = built['cache_after_sha256']
    require(executables == built['executables_after'] and config['environment_keys'] == built['environment_keys'], 'built ELFs/environment keys differ')
    paths.update({str(helper.BUILD / name): digest for name, digest in executables.items()})
    config_path, build_path = helper.BUILD / 'review109-current-configure-binding.json', helper.BUILD / 'review109-current-build-binding.json'
    configure = {'recorder_sha256': HELPER_SHA, 'inputs': selected, 'command': helper.COMMANDS['configure'],
                 'environment_values_sha256': BUILD_ENV_SHA, 'exit_code': 0, 'state': 'passed', 'cache_sha256': sha(cache)}
    build = {'configure_binding_sha256': sha(config_path), 'executables': executables, 'inputs': selected,
             'environment_values_sha256': BUILD_ENV_SHA, 'recorder_sha256': HELPER_SHA, 'exit_code': 0, 'state': 'passed'}
    require(json.loads(config_path.read_text()) == configure and json.loads(build_path.read_text()) == build and
            built['configure_binding_before_sha256'] == sha(config_path), 'successful configure/build binding differs')
    require(all(sha(name) == digest for name, digest in paths.items()), 'bound artifacts/tools differ')
    return {'inputs': selected, 'executables': executables, 'artifact_sha256': paths,
            'build_environment_keys': built['environment_keys'], 'build_environment_values_sha256': BUILD_ENV_SHA}

def write(path, value):
    temporary = path.with_suffix('.pending')
    with temporary.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)

def main():
    require(len(sys.argv) == 4 and sys.argv[1] in ('native', 'cli'), 'usage: check_lut_pair_review109_tests_current.py native|cli NEW_LABEL SCRIPT_SHA256')
    stage, label, expected = sys.argv[1:]
    require(re.fullmatch('[0-9a-f]{64}', expected) and sha(__file__) == expected and label and
            all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label), 'self pin/label differs')
    directory = HERE / ('lut-pair-review109-current-tests-' + label); directory.mkdir(exist_ok=False)
    record, log = directory / 'record.json', directory / 'output.log'; started = time.monotonic()
    env_sha = hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest()
    document = {'schema': 'lut-pair-review109-current-tests-v1', 'stage': stage, 'state': 'running', 'exit_code': None,
                'recorder_sha256': expected, 'tests_run': False, 'test_environment_keys': sorted(ENV),
                'test_environment_values_sha256': env_sha, 'build_environment_values_sha256': BUILD_ENV_SHA,
                'test_environment_equals_build': env_sha == BUILD_ENV_SHA, 'same_environment_claimed': False,
                'cleared_diagnostic_keys': sorted(k for k in os.environ if k.startswith('NEXTPNR_')),
                'configure_or_build_executed': False, 'compiled_commit_asserted': False,
                'historical_full_model_data_equivalence_proved': False, 'gain_qualified': False, 'full_route': False, 'hardware': False}
    write(record, document); print(json.dumps({'stage': stage, 'state': 'running', 'record': str(record)}), flush=True)
    try:
        helper = load_helper()
        resolved = shutil.which('ctest', path=ENV.get('PATH', '')); require(resolved, 'CTest tool is unavailable')
        ctest = Path(resolved).resolve(); before = authenticate(helper, ctest, expected); document['before'] = before
        command = list(helper.COMMANDS['native']) if stage == 'native' else [str(ctest)] + helper.COMMANDS['cli'][1:]
        require(Path(command[0]).is_absolute(), 'test executable must be absolute')
        document.update(command=command, cwd=str(helper.SOURCE), ctest_tool=str(ctest), ctest_sha256=sha(ctest),
                        build_environment_keys=before['build_environment_keys'])
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=helper.SOURCE, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        document.update(exit_code=result.returncode, tests_run=True)
        after = authenticate(helper, ctest, expected); document['after'] = after
        require(after == before and sha(__file__) == expected, 'bound source/model/cache/ELF/tool/helper bytes changed')
        text = log.read_text(errors='replace')
        if stage == 'native':
            cases = re.findall(r'^\[ RUN      \] (\S+)', text, re.M)
            require(cases and all(any(case.startswith(family + '.') for case in cases) for family in helper.FAMILIES) and
                    re.search(r'^\[  PASSED  \] ' + str(len(cases)) + r' tests?\.', text, re.M) and '[  SKIPPED ]' not in text,
                    'all five native suites must pass with nonempty case sets and no skips')
            document['native_case_count'] = len(cases)
        else:
            require('100% tests passed, 0 tests failed out of 3' in text, 'all three anchored CLI targets must pass')
            document['cli_ctest_target_count'] = 3
        require(result.returncode == 0, 'test returned a failing exit code'); document['state'] = 'passed'
    except BaseException as error:
        document.update(state='failed', error=type(error).__name__ + ': ' + str(error))
    finally:
        document['log_sha256'] = sha(log) if log.is_file() else None
        document['elapsed_seconds'] = time.monotonic() - started; document['recorder_after_sha256'] = sha(__file__)
        write(record, document)
        print(json.dumps({'stage': stage, 'state': document['state'], 'exit_code': document['exit_code'], 'record_sha256': sha(record)}), flush=True)
    return 0 if document['state'] == 'passed' else 1

if __name__ == '__main__':
    sys.exit(main())
