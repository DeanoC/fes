A further generic capture-pipeline search improvement is qualified and included in [nextpnr PR #110](https://github.com/DeanoC/nextpnr/pull/110).

With the same RTL/input hashes, seed, placement options and budget-64/radius-24 request, memory Fmax is **107.5037612915039 MHz**, up **1.3804473876953125 MHz** from the earlier 16-geometry budget-64 run (106.1233139038086 MHz), and **1.7284317016601562 MHz** from the matched fresh main baseline (105.77532958984375 MHz).

The compiler now considers up to 64 geometries while spending its 16 timing trials only after native legality and snapshot-preservation checks pass. It retains 53 register pairs rather than 37. This is structural compiler logic with no RAM-test names, pins or measured coordinates.

33 native cases and 11 CLI methods passed. The full GPU route completed, and the independent exported native/physical comparison passed for all 106 FF moves, original pin maps, identity buffers and affected whole LABs. All 15,290 complete paths across seven windows were checked; the six non-target windows remain positive and final signoff reports no hold violations.

Pixel Fmax is 94.98480224609375 MHz, down 1.33575439453125 MHz versus fresh main but still above its required 74.25006866455078 MHz. Capture remains 375.0871276855469 MHz. Memory still misses 130.0052032470703 MHz: its complete worst path is 9.302000254392624 ns against a 7.691999912261963 ns window.

The separate older frozen combined stack remains qualified at 117.86892700195312 MHz; this fresh-compiler comparison does not inherit or replace that result. The measured options remain explicit and default off, with no RTL, default-recipe, compiler-pin, ABI, constraint or hardware change.

The next experiment targets controlled FFs driving fixed HPS inputs, using actual sink-wire locality and guards for all incoming controls, feedback and other consumers. Retained Quartus placement is being used as a locality hint; its different BUILD_ID prevents claiming exact-input timing calibration.
