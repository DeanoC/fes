The fresh-main control is complete: **105.775330 MHz memory** with the current HeAP behavior and no staged remaps. The earlier frozen composed stack remains at **117.868927 MHz**; these are different compiler/configuration/placement baselines, so the fresh-main number is not a like-for-like regression measurement.

The next generic improvement is published in [nextpnr #110](https://github.com/DeanoC/nextpnr/pull/110), stacked on #109. It places both existing registers in an eligible hard-block capture pipeline together, preserving the graph, initialization and latency. Discovery uses cell types, timing arcs and connectivity, with no RAM-test names or coordinates.

| Matched fresh-main configuration | Memory MHz | Gain MHz | Pixel MHz | Capture MHz |
| --- | ---: | ---: | ---: | ---: |
| Baseline | 105.775330 | — | 96.320557 | 375.087128 |
| Capture pipeline, budget 8/radius 24 | 105.864914 | +0.089584 | 95.565750 | 375.087128 |
| Capture pipeline, budget 64/radius 24 | **106.123314** | **+0.347984** | 93.905533 | 375.087128 |

Both full routes passed independent exported-native/physical checks. All 15,290 reported paths across seven clock pairs were checked; all six required non-target windows remain positive and final hold checks are clear. Pixel Fmax decreases but passes its required 74.25 MHz. At budget 64, pixel headroom is 2.819 ns; memory still misses its 7.692 ns window by **1.731 ns**. Host checks passed **32 native cases and 11 CLI methods**.

[Measurement record and adjacent JSON](https://github.com/DeanoC/nextpnr/blob/afd1dcf9bc38e5e168ae4e4eccabcc13e2f0c07e/docs/validation/ramtest-capture-pipeline-2026-10-02.md) bind source `a0432321`, measured ELF `4db58a6de261b8542cce2c50f969f1f7b23b2c9c92150fa9a80697f88d185c27`, fixed inputs, outputs, proofs and clock windows. The pass remains default off. FES RTL, compiler pins, constraints and default recipes are unchanged; no hardware acceptance is claimed.

The combined capture-plus-LUT-copy route has also finished at 107.307648 MHz, but its independent composition proof is still pending, so it is not included among the qualified gains above. Investigation continues on the capture search: the remaining worst chain is already within the budget, but its first 16 geometries fail a legality/state-preservation check before timing evaluation.
