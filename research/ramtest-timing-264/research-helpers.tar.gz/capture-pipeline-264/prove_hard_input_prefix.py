"""One-shot exact exported-module/timing proof for the fresh hard-input-disabled C0 prefix.

No compiler, build, test, route, or old operational helper is executed. Only
the pinned reader's reviewed pure definitions are isolated. Creator text is
recorded separately; every module value and ordering must remain exact.
"""
import argparse
import ast
import hashlib
import json
import math
from pathlib import Path
import re
import types

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
TOOL = WORK / "sources/misteross/build/toolchain-ramtest-timing"
SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-experiment-mistral-hard-input-locality-264-54cde5d3")
OLD_SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-experiment-mistral-capture-pipeline-264-54cde5d3")
BASE_SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-feat-mistral-lut-pair-copies-264-54cde5d3")
MODEL = TOOL / "src/mistral"
OLD_BINARY = TOOL / "build/nextpnr-capture-pipeline-264/nextpnr-mistral"
BINARY = TOOL / "build/nextpnr-hard-input-locality-264/nextpnr-mistral"
OLD_BINARY_SHA = "4db58a6de261b8542cce2c50f969f1f7b23b2c9c92150fa9a80697f88d185c27"
BINARY_SHA = "ce8eb37feaf6a06ef76e4d28b3ca8dd17af3d8a59b822bbd2f03f040719b81fe"
OLD = HERE / "clock-group-pipeline-b8-pair-copy-c0-placed"
NEW = HERE / "hard-input-c0-prefix-placed-v1"
OUTPUT = HERE / "proof-hard-input-prefix.json"
OLD_RUN_SHA = "1ac34d488937d68b8a63d8b46b45433086cd42e36af6caf038b505ac08e09f9c"
PREFIX_RUN_SHA = "abb66f317e773c8c83d423cd2b6aa0b7a3cf7bda95aed06b5d55048df995018a"
OLD_OUTPUTS = {
    "placed.json": "42fd106f4cc66f965eeb44d9bea2c6d0128d2a07009cdec9c1ed2b7efb5a93ba",
    "timing.json": "ba18c96552bb3865b5ab2484c63d8b689e14539a07e3766a65dab83b423b6df9",
    "profile.json": "b01ebf1178bde3b447a5d40c0a9ab5364bbbc39df1ec403ef33e92a067f3c825",
    "trial.log": "3270ab5d38333fbedc2a61cc0e9159270f256d23e718961e25b2443cf7fa13c0",
}
BASE = HERE.parent / "lut-pair-copies-publication-264/main-baseline/run.json"
BASE_SHA = "3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c"
GUIDE = HERE.parent / "lut-pair-copies-publication-264/main-baseline-placed/timing.json"
GUIDE_SHA = "d117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512"
PAIR_GUIDE = HERE / "clock-group-pipeline-placed-b8-r24/timing.json"
PAIR_GUIDE_SHA = "18aecabd79f697c0f010ce0339349bbdd34c94e32814194b90a9610068cb980b"
RECORDER = HERE / "trial_hard_input_placed.py"
RECORDER_SHA = "a8b0b2a8b88aecaa9b85ddb0dcebfe6c4b4c12ccb6bd91ea38a36d87596264f8"
OLD_RECORDER = HERE / "select_post_pipeline.py"
OLD_RECORDER_SHA = "c2f59722b380245c46933bcc5b90f2c0766df86be8169d85d3993ab001f5505d"
READER = HERE.parent / "narrow-integrated-264/compare_route.py"
READER_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
DIGEST = re.compile(r"[0-9a-f]{64}")
INPUTS = {
    "out/ramtest-merged-remap/measured-diagnostic/synth.json": "61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28",
    "sources/misteross/cores/fes-ramtest/constraints.qsf": "8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4",
    "sources/misteross/boards/de10nano/clocks.sdc": "3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041",
}
ADDED = ("mistral/capture_pipeline_locality.cc", "mistral/tests/capture_pipeline_locality.cc",
         "mistral/tests/capture_pipeline_locality_cli.py", "docs/mistral-capture-pipeline-locality.md",
         "mistral/tests/hard_input_locality.cc", "mistral/tests/hard_input_locality_cli.py",
         "docs/mistral-hard-input-locality.md")
DIAGNOSTICS = {"NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY": str(GUIDE) + " 8 24"}
CANDIDATE = ("Info: LUT pair copy candidate 0: inner=hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q "
             "outer=hps_ddr.port0.slot_free_MISTRAL_ALUT3_B "
             "sink=hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_5.ENA "
             "clone_bel=MISTRAL_COMB.19.28.0 gain=3790ps cohort=1.")
APPLIED = "Info: LUT pair copy applied candidate 0; full routing and signoff still required."
CAPTURE = ("Info: Capture pipeline locality: source hps_ddr.f2sdram.rd_data_2[16], "
           "eligible=8 retained_pairs=7 (route signoff still required).")


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def reader():
    require(sha(READER) == READER_SHA, "pure reader bytes changed")
    names = {"require", "sha", "unique_object", "nonfinite", "read", "canonical",
             "ObjectPairs", "NetlistCells", "read_netlist", "Audit"}
    tree = ast.parse(READER.read_text(), filename=str(READER))
    nodes = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names]
    require(len(nodes) == len(names) and {node.name for node in nodes} == names, "pure reader API differs")
    namespace = {"__name__": "hard_input_prefix_pure_reader", "Path": Path, "json": json,
                 "hashlib": hashlib, "ROOT": WORK, "DIGEST": DIGEST}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(READER) + ":pure", "exec"), namespace)
    return types.SimpleNamespace(**{name: namespace[name] for name in names})


def command(binary, output):
    return [str(binary), "--json", str(WORK / "out/ramtest-merged-remap/measured-diagnostic/synth.json"),
            "--device", "5CSEBA6U23I7", "--qsf", str(WORK / "sources/misteross/cores/fes-ramtest/constraints.qsf"),
            "--sdc", str(WORK / "sources/misteross/boards/de10nano/clocks.sdc"), "--freq", "74.25", "--seed", "2",
            "--placer-heap-timingweight", "10", "--placer-heap-critexp", "2", "--replicate-enables", "4",
            "--timing-allow-fail", "--detailed-timing-report", "--router", "gpu", "--gpu-device", "1",
            "--write", str(output / "placed.json"), "--report", str(output / "timing.json"),
            "--timing-report-paths", "16384", "--no-route", "--remap-lut-pair-critical", str(PAIR_GUIDE),
            "--remap-lut-pair-compose-copy", "--remap-lut-pair-candidate", "0"]


def ordered(value):
    if isinstance(value, dict):
        return ["object", [[key, ordered(item)] for key, item in value.items()]]
    if isinstance(value, list):
        return ["array", [ordered(item) for item in value]]
    return [type(value).__name__, value]


def raw_slots(top):
    """Reconstruct every exported numeric bit/port-index/PLL-occurrence slot."""
    tables = {"drivers": {}, "users": {}}
    for owner, cell in top["cells"].items():
        special = top["cells"].pll_ports.get(owner)
        directions = special["port_directions"] if special else list(cell["port_directions"].items())
        connections = special["connections"] if special else list(cell["connections"].items())
        require([key for key, _ in directions] == [key for key, _ in connections], "port entry order differs")
        occurrences = {}
        for (port, direction), (_, bits) in zip(directions, connections):
            occurrence = occurrences.get(port, 0); occurrences[port] = occurrence + 1
            require(direction in {"input", "output", "inout"} and type(bits) is list and
                    all(type(bit) is int and bit >= 0 for bit in bits), "unsupported raw native connection")
            for index, bit in enumerate(bits):
                slot = [owner, port, index, occurrence]
                for kind, enabled in (("drivers", direction in {"output", "inout"}),
                                      ("users", direction in {"input", "inout"})):
                    if enabled:
                        tables[kind].setdefault(str(bit), []).append(slot)
    return tables


def authenticate(native, audit, args):
    def bind_map(values, external=False):
        require(type(values) is dict and values, "empty or invalid input closure")
        for name, digest in values.items():
            audit.bind(Path(name), digest, execution=external)

    for path, digest in ((READER, READER_SHA), (Path(__file__).resolve(), args.self_sha256),
                         (OLD / "run.json", OLD_RUN_SHA), (NEW / "run.json", args.prefix_run_sha256),
                         (BASE, BASE_SHA), (GUIDE, GUIDE_SHA), (PAIR_GUIDE, PAIR_GUIDE_SHA),
                         (RECORDER, RECORDER_SHA), (OLD_RECORDER, OLD_RECORDER_SHA),
                         (OLD_BINARY, OLD_BINARY_SHA), (BINARY, args.binary_sha256)):
        audit.bind(path, digest)
    with BINARY.open("rb") as stream:
        require(stream.read(4) == b"\x7fELF", "current compiler is not an ELF")
    old_run, run = native.read(OLD / "run.json"), native.read(NEW / "run.json")
    require(old_run["output_sha256"] == OLD_OUTPUTS and old_run["completed_normally"] is True and
            old_run["exit_code"] == 0 and old_run["execution_error"] is None and old_run["mode"] == "placed" and
            old_run["candidate"] == 0 and old_run["candidate_identity_verified"] is True and
            old_run["production_and_input_bytes_stable"] is True and old_run["profile_bytes_stable"] is True and
            old_run["required_outputs_present"] is True and
            old_run["profile_sha256"] == old_run["expected_profile_sha256"] == OLD_OUTPUTS["profile.json"],
            "frozen C0 run did not close with its exact outputs")
    bind_map({str(OLD / name): digest for name, digest in OLD_OUTPUTS.items()})
    require(run["schema"] == "hard-input-placed-trial-v1" and run["completed_normally"] is True and
            run["exit_code"] == 0 and run["failure"] is None and run["stable"] is True and
            run["normal_finish_marker"] is True and not run["output_hash_errors"], "prefix run is not closed/stable")
    outputs = run["output_sha256"]
    require(set(outputs) == {str(NEW / name) for name in OLD_OUTPUTS} and
            run["profile_sha256"] == outputs[str(NEW / "profile.json")] and
            {path.name for path in NEW.iterdir()} == set(OLD_OUTPUTS) | {"run.json"} and
            all(path.is_file() and not path.is_symlink() for path in NEW.iterdir()), "prefix artifact set differs")
    bind_map(outputs)
    old, current, base = native.read(OLD / "profile.json"), native.read(NEW / "profile.json"), native.read(BASE)
    require(old["command"] == command(OLD_BINARY, OLD) and old["binary_sha256"] == OLD_BINARY_SHA and
            old["helper_sha256"] == OLD_RECORDER_SHA and old["baseline_sha256"] == BASE_SHA and
            old["guide_sha256"] == GUIDE_SHA and old["pair_guide_sha256"] == PAIR_GUIDE_SHA and
            old["environment"] == DIAGNOSTICS and old["fixed_locale"] == {"LANG": "C", "LC_ALL": "C", "TZ": "UTC"} and
            old["cleared_environment_prefix"] == "NEXTPNR_", "frozen C0 command/diagnostic identity differs")
    require(current["schema"] == "hard-input-placed-trial-v1" and current["mode"] == "prefix" and
            current["command"] == run["command"] == command(BINARY, NEW) and
            current["helper_sha256"] == RECORDER_SHA and current["binary_sha256"] == args.binary_sha256 and
            current["compiled_commit_asserted"] is False, "prefix command/compiler/recorder identity differs")
    require(old["input_sha256"] == current["input_sha256"] == INPUTS and
            old["cwd"] == current["cwd"] == run["cwd"] == str(WORK / "sources/misteross"), "fixed inputs/cwd differ")
    for record in (old_run, old, run, current):
        require(all(record[key] is False for key in ("gain_accepted", "native_physical_equivalence_proved", "hardware_tested")),
                "a pre-route record asserts qualification")
    for record in (old_run, run):
        require(type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
                record["elapsed_seconds"] >= 0, "invalid actual elapsed time")
    environment = current["environment"]
    require(environment == run["environment"] and environment["selected_diagnostics"] == DIAGNOSTICS and
            environment["unlisted_values_recorded"] is False and
            DIGEST.fullmatch(environment["all_effective_values_sha256"]) and
            environment["all_effective_keys"] == sorted(set(environment["all_effective_keys"])) and
            {key for key in environment["all_effective_keys"] if key.startswith("NEXTPNR_")} == set(DIAGNOSTICS) and
            all(key.startswith("NEXTPNR_") for key in environment["cleared_diagnostic_keys"]) and
            all(environment["runtime_values"].get(key) == value for key, value in {"LANG": "C", "LC_ALL": "C", "TZ": "UTC"}.items()),
            "prefix diagnostic clearing/fixed locale record differs")
    inventories = []
    for profile, source, added in ((old, OLD_SOURCE, ADDED[:4]), (current, SOURCE, ADDED)):
        expected_paths, models = set(), {}
        for original, digest in base["production_source_sha256"].items():
            path = Path(original)
            if path.is_relative_to(BASE_SOURCE):
                path = source / path.relative_to(BASE_SOURCE)
            else:
                require(path.is_relative_to(MODEL), "unexpected fixed model inventory root")
                models[str(path)] = digest
            expected_paths.add(str(path))
        expected_paths.update(str(source / name) for name in added)
        inventory = profile["production_source_sha256"]
        require(set(inventory) == expected_paths and models and all(inventory[name] == digest for name, digest in models.items()),
                "source inventory/model mapping differs")
        bind_map(inventory, external=True); inventories.append(inventory)
    prior = old_run["byte_checks_before"]
    require(prior == old_run["byte_checks_after"] and prior["matches_expected"] is True and not prior["read_errors"] and
            not prior["production_source_mismatches"] and prior["input_sha256"] == INPUTS and
            prior["production_source_file_count"] == len(inventories[0]) and
            prior["production_source_snapshot_sha256"] == hashlib.sha256(json.dumps(inventories[0], sort_keys=True).encode()).hexdigest() and
            prior["artifact_sha256"] == old["bound_artifact_sha256"], "frozen C0 before/after closure differs")
    bind_map(prior["artifact_sha256"])
    expected = {**inventories[1], **{str(WORK / name): digest for name, digest in INPUTS.items()},
                str(GUIDE): GUIDE_SHA, str(PAIR_GUIDE): PAIR_GUIDE_SHA, str(OLD / "timing.json"): OLD_OUTPUTS["timing.json"],
                str(RECORDER): RECORDER_SHA, str(BINARY): args.binary_sha256, str(BASE): BASE_SHA}
    require(run["before_snapshot"] == run["after_snapshot"] == current["before_snapshot"] and
            run["before_snapshot"] == {"sha256": expected, "errors": {}}, "prefix exact before/after byte closure differs")
    bind_map({str(WORK / name): digest for name, digest in INPUTS.items()})
    old_lines, lines = (OLD / "trial.log").read_text().splitlines(), (NEW / "trial.log").read_text().splitlines()
    retained = lambda values: [line for line in values if line.startswith("Info: Capture pipeline locality retained ")]
    require(retained(old_lines) == retained(lines) == old["capture_retained_lines"] and len(retained(lines)) == 7 and
            all(lines.count(line) == 1 for line in (CANDIDATE, APPLIED, CAPTURE, "Info: Program finished normally.")) and
            not any("Hard input locality" in line for line in lines), "prefix stage identities/disabled hard-input log differs")
    return old_run, run, inventories


def evaluate(native, audit, args):
    _, _, inventories = authenticate(native, audit, args)
    before, after = native.read_netlist(OLD / "placed.json"), native.read_netlist(NEW / "placed.json")
    require(list(before) == list(after) == ["creator", "modules"] and
            list(before["modules"]) == list(after["modules"]) == ["top"] and
            type(before["creator"]) is str and type(after["creator"]) is str,
            "unexpected export header or additional module outside the exact comparison")
    old, new = before["modules"]["top"], after["modules"]["top"]
    require(native.canonical(old) == native.canonical(new) and native.canonical(ordered(old)) == native.canonical(ordered(new)),
            "complete exported module/value/object ordering differs; no normalization is permitted")
    require(native.canonical(ordered(old["cells"].pll_ports)) == native.canonical(ordered(new["cells"].pll_ports)),
            "lossless ordered PLL duplicate output occurrences differ")
    old_slots, new_slots = raw_slots(old), raw_slots(new)
    require(native.canonical(old_slots) == native.canonical(new_slots), "exported raw driver/user slots differ")
    old_timing, timing = native.read(OLD / "timing.json"), native.read(NEW / "timing.json")
    require(native.canonical(old_timing) == native.canonical(timing) and
            native.canonical(ordered(old_timing)) == native.canonical(ordered(timing)), "entire timing JSON differs")
    return {"complete_lossless_module_exact": True, "all_module_object_and_array_order_exact": True,
            "lossless_ordered_pll_occurrences_exact": True, "all_exported_bels_params_init_attrs_pins_aliases_exact": True,
            "exported_numeric_driver_user_port_index_occurrence_slots_exact": True, "entire_timing_json_exact": True,
            "cell_count": len(new["cells"]), "named_net_count": len(new["netnames"]),
            "exported_driver_slot_count": sum(map(len, new_slots["drivers"].values())),
            "exported_user_slot_count": sum(map(len, new_slots["users"].values())),
            "directly_rehashed_source_file_count": len(set(inventories[0]) | set(inventories[1])),
            "creator_metadata": {"frozen": before["creator"], "fresh": after["creator"],
                                 "only_permitted_nonmodule_difference": "creator"}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "prefix-run-sha256", "binary-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    require(all(DIGEST.fullmatch(value) for value in (args.self_sha256, args.prefix_run_sha256, args.binary_sha256)) and
            sha(__file__) == args.self_sha256 and HERE == WORK / "out/ramtest-wide-reduction-264/capture-pipeline-264",
            "proof location/activation identity differs")
    require(args.prefix_run_sha256 == PREFIX_RUN_SHA and args.binary_sha256 == BINARY_SHA,
            "only the actual finished prefix/production ELF is in this proof's scope")
    native = reader(); audit = native.Audit()
    with OUTPUT.open("x", encoding="utf-8") as stream:
        result, rejection, stable = None, None, False
        try:
            result = evaluate(native, audit, args)
        except BaseException as error:
            rejection = type(error).__name__ + ": " + str(error)
        try:
            audit.finish(); stable = True
        except BaseException as error:
            rejection = (rejection + "; " if rejection else "") + type(error).__name__ + ": " + str(error)
        passed = result is not None and rejection is None and stable
        record = {"schema": "hard-input-prefix-exact-proof-v1", "passed": passed, "rejection": rejection,
                  "input_bytes_stable_during_proof": stable, "comparison": result,
                  "prefix_run_sha256": args.prefix_run_sha256, "binary_sha256": args.binary_sha256,
                  "self_sha256": args.self_sha256, "frozen_c0_run_sha256": OLD_RUN_SHA,
                  "artifact_sha256": audit.artifacts, "direct_source_or_execution_sha256": audit.execution,
                  "compiled_commit_asserted": False, "complete_runtime_or_gpu_identity_proved": False,
                  "live_pointer_cache_or_indexed_store_holes_proved": False,
                  "live_pinmap_or_control_cache_equivalence_proved": False,
                  "independent_complete_placement_or_routing_legality_proved": False,
                  "actual_route_or_rbf_proved": False, "numerical_sta_calibrated": False,
                  "gain_accepted": False, "hardware_tested": False,
                  "scope": "Exact exported C0 pre-route prefix and entire timing JSON only; hard-input diagnostic disabled."}
        stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"passed": passed, "proof_sha256": sha(OUTPUT), "rejection": rejection}))
    require(passed, "prefix differs or authentication failed; rejected proof record retained")


if __name__ == "__main__":
    main()
