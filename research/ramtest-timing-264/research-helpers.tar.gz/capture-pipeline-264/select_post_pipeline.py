"""Record only post-B8 LUT-pair-copy candidate 0; never claim acceptance.

Root reviews the whole recorder before use, runs placed first, and schedules
route only after the existing B64 route closes. No other helper is executed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = Path("/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d")
RAW = WORK / "out/ramtest-wide-reduction-264"
SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-experiment-mistral-capture-pipeline-264-54cde5d3")
BINARY = WORK / "sources/misteross/build/toolchain-ramtest-timing/build/nextpnr-capture-pipeline-264/nextpnr-mistral"
BINARY_SHA = "4db58a6de261b8542cce2c50f969f1f7b23b2c9c92150fa9a80697f88d185c27"
BASE = RAW / "lut-pair-copies-publication-264/main-baseline/run.json"
BASE_SHA = "3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c"
CAPTURE_GUIDE = RAW / "lut-pair-copies-publication-264/main-baseline-placed/timing.json"
CAPTURE_GUIDE_SHA = "d117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512"
PIPELINE_ENV = "NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY"
SELECTED_ENV = {PIPELINE_ENV: str(CAPTURE_GUIDE) + " 8 24"}
PREFIX = HERE / "clock-group-pipeline-placed-b8-r24"
PREFIX_RUN_SHA = "95eb2f478408d8b65fb0127cd8404a3f97f2377a9c819aff31e8d2b81076b8df"
PREFIX_OUTPUT_SHA = {
    "placed.json": "8a433d2a8670a16c8d438ec42b19a27fd19cf79c6d83156101f22b7d4d55cef6",
    "profile.json": "9f770cfb10603b58bc7977d51854f6f79ab2980ea35f0c62374094631ecc959b",
    "timing.json": "18aecabd79f697c0f010ce0339349bbdd34c94e32814194b90a9610068cb980b",
    "trial.log": "0e5177153e02a4ed6476204aa29f89424c279e67faa187b3b950ec7e83b5f2ab",
}
PREFIX_HELPER = HERE / "trial_clock_group.py"
PREFIX_HELPER_SHA = "a3fb41cb3300099022c1af4c63c44bac6bf92eb4612ca4456bdaa41596ff01ed"
LISTING = HERE / "clock-group-pipeline-b8-pair-copy-list"
LISTING_RUN_SHA = "05bbdd76ba39abcb03b5538087c3eab80c72eaf4216d4294f4b7d8d83af41cfd"
LISTING_OUTPUT_SHA = {
    "placed.json": "8a433d2a8670a16c8d438ec42b19a27fd19cf79c6d83156101f22b7d4d55cef6",
    "profile.json": "fcc7ac5b2b05b705d22c0534ec07810a5e3a6d27d36ed00bc5aa82b786f36854",
    "timing.json": "18aecabd79f697c0f010ce0339349bbdd34c94e32814194b90a9610068cb980b",
    "trial.log": "28045b3f6b8835b82b1713de24fb699a8bfbab5784d82d125026114c317436f0",
}
LISTING_HELPER = HERE / "list_post_pipeline.py"
LISTING_HELPER_SHA = "be7e5dae7076555d43f40ea445bae05bb151072b293f4616c58c2224095e91e1"
INPUT_SHA = {
    "out/ramtest-merged-remap/measured-diagnostic/synth.json": "61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28",
    "sources/misteross/boards/de10nano/clocks.sdc": "3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041",
    "sources/misteross/cores/fes-ramtest/constraints.qsf": "8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4",
}
CANDIDATE_LINE = (
    "Info: LUT pair copy candidate 0: inner=hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q "
    "outer=hps_ddr.port0.slot_free_MISTRAL_ALUT3_B "
    "sink=hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_5.ENA "
    "clone_bel=MISTRAL_COMB.19.28.0 gain=3790ps cohort=1."
)
LISTING_SUMMARY = "Info: LUT pair copy: 56 qualified candidates; no candidate applied."
APPLIED_LINE = "Info: LUT pair copy applied candidate 0; full routing and signoff still required."
CAPTURE_SUMMARY = (
    "Info: Capture pipeline locality: source hps_ddr.f2sdram.rd_data_2[16], "
    "eligible=8 retained_pairs=7 (route signoff still required)."
)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path, expected):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected, "closed JSON bytes changed: " + str(path))
    return json.loads(data)


def option(command, flag):
    require(command.count(flag) == 1, "missing or duplicate option: " + flag)
    index = command.index(flag) + 1
    require(index < len(command), "missing option value: " + flag)
    return index


def write_json(path, value):
    text = json.dumps(value, indent=2, sort_keys=True) + "\n"
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(text)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def snapshot(artifacts, sources):
    errors = {}

    def collect(expected, relative=False):
        actual = {}
        for name in expected:
            try:
                actual[name] = sha(WORK / name if relative else name)
            except OSError as error:
                actual[name] = None
                errors[name] = str(error)
        return actual

    observed_artifacts = collect(artifacts)
    observed_sources = collect(sources)
    observed_inputs = collect(INPUT_SHA, relative=True)
    source_digest = hashlib.sha256(json.dumps(observed_sources, sort_keys=True).encode("utf-8")).hexdigest()
    return dict(
        matches_expected=observed_artifacts == artifacts and observed_sources == sources and observed_inputs == INPUT_SHA,
        artifact_sha256=observed_artifacts, input_sha256=observed_inputs,
        production_source_file_count=len(sources), production_source_snapshot_sha256=source_digest,
        production_source_mismatches=sorted(name for name in sources if observed_sources[name] != sources[name]),
        read_errors=errors,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    parser.add_argument("--mode", choices=("placed", "route"), required=True)
    args = parser.parse_args()
    require(len(args.self_sha256) == 64 and all(char in "0123456789abcdef" for char in args.self_sha256),
            "expected a lowercase SHA-256")
    require(HERE == RAW / "capture-pipeline-264" and sha(__file__) == args.self_sha256, "recorder location or bytes changed")
    prefix_run = read_json(PREFIX / "run.json", PREFIX_RUN_SHA)
    prefix_profile = read_json(PREFIX / "profile.json", PREFIX_OUTPUT_SHA["profile.json"])
    listing_run = read_json(LISTING / "run.json", LISTING_RUN_SHA)
    profile = read_json(LISTING / "profile.json", LISTING_OUTPUT_SHA["profile.json"])
    for record, expected in ((prefix_run, PREFIX_OUTPUT_SHA), (listing_run, LISTING_OUTPUT_SHA)):
        require(record["schema"] == 1 and record["exit_code"] == 0 and
                record["production_and_input_bytes_stable"] is True and record["output_sha256"] == expected and
                record["profile_sha256"] == expected["profile.json"], "preceding run did not close with the bound outputs")
    require(profile["helper_sha256"] == LISTING_HELPER_SHA and prefix_profile["helper_sha256"] == PREFIX_HELPER_SHA and
            profile["preceding_run_sha256"] == PREFIX_RUN_SHA and
            profile["preceding_profile_sha256"] == PREFIX_OUTPUT_SHA["profile.json"] and
            profile["pair_guide_sha256"] == PREFIX_OUTPUT_SHA["timing.json"], "listing ancestry or helper binding differs")
    for previous in (prefix_profile, profile):
        require(previous["binary_sha256"] == BINARY_SHA and previous["baseline_sha256"] == BASE_SHA and
                previous["guide_sha256"] == CAPTURE_GUIDE_SHA and previous["environment"] == SELECTED_ENV and
                previous["input_sha256"] == INPUT_SHA and previous["cwd"] == str(WORK / "sources/misteross"),
                "fixed compiler, input, cwd or B8/R24 request differs")
    sources = dict(profile["production_source_sha256"])
    require(sources and sources == prefix_profile["production_source_sha256"] and
            str(SOURCE / "mistral/capture_pipeline_locality.cc") in sources, "current source binding differs")
    prefix_command = list(prefix_profile["command"])
    require(prefix_command[0] == str(BINARY) and prefix_command.count("--no-route") == 1 and "--rbf" not in prefix_command and
            not any(value.startswith("--remap-") or value.startswith("--balance-") for value in prefix_command),
            "unexpected preceding transformation or routing request")
    for flag, relative in (("--json", "out/ramtest-merged-remap/measured-diagnostic/synth.json"),
                           ("--qsf", "sources/misteross/cores/fes-ramtest/constraints.qsf"),
                           ("--sdc", "sources/misteross/boards/de10nano/clocks.sdc")):
        require(prefix_command[option(prefix_command, flag)] == str(WORK / relative), "fixed input path differs")
    expected_listing_command = list(prefix_command)
    for flag, filename in (("--write", "placed.json"), ("--report", "timing.json")):
        expected_listing_command[option(expected_listing_command, flag)] = str(LISTING / filename)
    expected_listing_command.extend(("--remap-lut-pair-critical", str(PREFIX / "timing.json"),
                                     "--remap-lut-pair-compose-copy", "--remap-lut-pair-candidate", "-1"))
    require(profile["command"] == expected_listing_command, "listing command is not the exact fixed prefix plus copy listing")
    listing_lines = (LISTING / "trial.log").read_text(encoding="utf-8").splitlines()
    retained_lines = [line for line in listing_lines if line.startswith("Info: Capture pipeline locality retained ")]
    require(listing_lines.count(CANDIDATE_LINE) == 1 and listing_lines.count(LISTING_SUMMARY) == 1 and
            sum(line.startswith("Info: LUT pair copy candidate ") for line in listing_lines) == 56 and
            not any(line.startswith("Info: LUT pair copy applied candidate ") for line in listing_lines) and
            listing_lines.count(CAPTURE_SUMMARY) == 1 and len(retained_lines) == 7,
            "finished listing does not contain the exact candidate 0, rollback count and B8 prefix")
    output = HERE / ("clock-group-pipeline-b8-pair-copy-c0-" + args.mode)
    require(not output.exists() and not output.is_symlink(), "selected output already exists")
    command = list(profile["command"])
    command[option(command, "--remap-lut-pair-candidate")] = "0"
    design_name = "placed.json" if args.mode == "placed" else "routed.json"
    for flag, filename in (("--write", design_name), ("--report", "timing.json")):
        command[option(command, flag)] = str(output / filename)
    if args.mode == "route":
        command.remove("--no-route")
        command.extend(("--rbf", str(output / "core.rbf")))
    artifacts = {str(Path(__file__).resolve()): args.self_sha256, str(BINARY): BINARY_SHA,
                 str(BASE): BASE_SHA, str(CAPTURE_GUIDE): CAPTURE_GUIDE_SHA,
                 str(PREFIX_HELPER): PREFIX_HELPER_SHA, str(LISTING_HELPER): LISTING_HELPER_SHA,
                 str(PREFIX / "run.json"): PREFIX_RUN_SHA, str(LISTING / "run.json"): LISTING_RUN_SHA}
    for directory, expected in ((PREFIX, PREFIX_OUTPUT_SHA), (LISTING, LISTING_OUTPUT_SHA)):
        artifacts.update({str(directory / filename): expected_sha for filename, expected_sha in expected.items()})
    before = snapshot(artifacts, sources)
    require(before["matches_expected"], "bound artifacts, source or input bytes changed before execution")
    environment = {key: value for key, value in os.environ.items() if not key.startswith("NEXTPNR_")}
    environment.update({"LANG": "C", "LC_ALL": "C", "TZ": "UTC", **SELECTED_ENV})
    new_profile = dict(profile, role="exploratory post-capture candidate-0 " + args.mode + "; not timing acceptance",
                       helper_sha256=args.self_sha256, command=command, mode=args.mode, source_revision="a0432321",
                       preceding_run_sha256=LISTING_RUN_SHA, preceding_profile_sha256=LISTING_OUTPUT_SHA["profile.json"],
                       listing_run_sha256=LISTING_RUN_SHA, listing_output_sha256=LISTING_OUTPUT_SHA,
                       prefix_run_sha256=PREFIX_RUN_SHA, prefix_output_sha256=PREFIX_OUTPUT_SHA,
                       bound_artifact_sha256=artifacts, candidate=0, candidate_identity=CANDIDATE_LINE,
                       listing_qualified_candidates=56, capture_retained_lines=retained_lines,
                       cleared_environment_prefix="NEXTPNR_", fixed_locale={"LANG": "C", "LC_ALL": "C", "TZ": "UTC"},
                       native_physical_equivalence_proved=False, gain_accepted=False, hardware_tested=False)
    output.mkdir()
    new_profile_sha = write_json(output / "profile.json", new_profile)
    started_utc = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    started = time.monotonic()
    exit_code = None
    execution_error = None
    with (output / "trial.log").open("x", encoding="utf-8") as stream:
        try:
            result = subprocess.run(command, cwd=profile["cwd"], env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT, shell=False, check=False)
            exit_code = result.returncode
        except Exception as error:
            execution_error = type(error).__name__ + ": " + str(error)
            stream.write("Recorder execution error: " + execution_error + "\n")
    elapsed = time.monotonic() - started
    after = snapshot(artifacts, sources)
    unchanged = before["matches_expected"] and after["matches_expected"]
    trial_lines = (output / "trial.log").read_text(encoding="utf-8", errors="replace").splitlines()
    identity_ok = (trial_lines.count(CANDIDATE_LINE) == 1 and trial_lines.count(APPLIED_LINE) == 1 and
                   trial_lines.count(CAPTURE_SUMMARY) == 1 and
                   [line for line in trial_lines if line.startswith("Info: Capture pipeline locality retained ")] == retained_lines)
    required_names = {"profile.json", "trial.log", design_name, "timing.json"}
    if args.mode == "route":
        required_names.add("core.rbf")
    paths = sorted(output.iterdir())
    outputs_ok = {path.name for path in paths} == required_names and all(path.is_file() and not path.is_symlink() for path in paths)
    output_hashes = {path.name: sha(path) for path in paths if path.is_file()}
    profile_unchanged = output_hashes.get("profile.json") == new_profile_sha
    complete = exit_code == 0 and execution_error is None and unchanged and identity_ok and outputs_ok and profile_unchanged
    record = dict(schema=1, role=new_profile["role"], mode=args.mode, profile_sha256=output_hashes.get("profile.json"),
                  expected_profile_sha256=new_profile_sha, profile_bytes_stable=profile_unchanged,
                  started_utc=started_utc, elapsed_seconds=elapsed, exit_code=exit_code, execution_error=execution_error,
                  completed_normally=complete, production_and_input_bytes_stable=unchanged,
                  byte_checks_before=before, byte_checks_after=after, output_sha256=output_hashes,
                  candidate=0, candidate_identity_verified=identity_ok, required_outputs_present=outputs_ok,
                  listing_run_sha256=LISTING_RUN_SHA, listing_profile_sha256=LISTING_OUTPUT_SHA["profile.json"],
                  prefix_run_sha256=PREFIX_RUN_SHA, prefix_profile_sha256=PREFIX_OUTPUT_SHA["profile.json"],
                  native_physical_equivalence_proved=False, gain_accepted=False, hardware_tested=False)
    write_json(output / "run.json", record)
    print(json.dumps(dict(run_sha256=sha(output / "run.json"), exit_code=exit_code,
                         stable=unchanged, candidate_identity_verified=identity_ok, completed_normally=complete)))
    require(complete, "selected candidate failed, required identity/output missing, or bound bytes changed")


if __name__ == "__main__":
    main()
