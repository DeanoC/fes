"""Root-operated retained-fit write-locality query; no fitting or acceptance."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
OUT = HERE / 'quartus-write-locality-hints-v2'
MANIFEST = OUT / 'project-inputs.json'
MANIFEST_SHA = 'bc44dad808f2a23532e9b0f50d9979dd757045af2d61a7976c865cda464ac1f1'
TCL = HERE / 'quartus-write-locality-hint.tcl'
QUARTUS = Path('/home/deano/intelFPGA_lite/17.0/quartus')
CRITICAL = ('top.qpf', 'top.qsf', 'clocks.sdc', 'db/top.cmp.hdb', 'db/top.cmp.cdb',
            'db/top.routing.rdb', 'db/top.sta_cmp.7_slow_1100mv_100c.tdb',
            'output_files/top.fit.rpt', 'output_files/top.map.rpt', 'output_files/top.rbf')


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def tree(root):
    paths = sorted(root.rglob('*'))
    require(not any(path.is_symlink() for path in paths), 'symlink in fitted/output tree')
    return {str(path.relative_to(root)): sha(path) for path in paths if path.is_file()}


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-sha256', required=True)
    parser.add_argument('--tcl-sha256', required=True)
    args = parser.parse_args()
    require(all(re.fullmatch('[0-9a-f]{64}', value) for value in (args.self_sha256, args.tcl_sha256)), 'activation hashes required')
    require(sha(__file__) == args.self_sha256 and sha(TCL) == args.tcl_sha256 and sha(MANIFEST) == MANIFEST_SHA,
            'query recorder/script/private-fit manifest changed')
    manifest = json.loads(MANIFEST.read_text())
    source, private = Path(manifest['source']), Path(manifest['private_copy'])
    expected = manifest['input_sha256']
    require(private == OUT / 'project' and len(expected) == 176 and tree(source) == tree(private) == expected,
            'original/private 176-file fit differs before query')
    require(all(name in expected for name in CRITICAL), 'missing critical fitted input')
    require(not (OUT / 'query-record.json').exists() and not (OUT / 'failed-query-record.json').exists() and
            not (OUT / 'timing').exists() and not (OUT / 'timing-driver.log').exists(), 'immutable query outputs exist')
    environment = {'PATH': str(QUARTUS / 'bin') + ':/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
                   'LC_CTYPE': 'C', 'TZ': 'UTC', 'QUARTUS_ROOTDIR_OVERRIDE': str(QUARTUS)}
    if 'HOME' in os.environ:
        environment['HOME'] = os.environ['HOME']
    wrapper, native = QUARTUS / 'bin/quartus_sta', QUARTUS / 'linux64/quartus_sta'
    dependencies = subprocess.run(['/usr/bin/ldd', str(native)], check=True, text=True, capture_output=True,
                                  env={**environment, 'LD_LIBRARY_PATH': str(QUARTUS / 'linux64')}).stdout
    require('not found' not in dependencies, 'unresolved native Quartus dependency')
    with (OUT / 'quartus-sta-ldd.txt').open('x') as stream:
        stream.write(dependencies)
    paths = {Path(__file__).resolve(), TCL, MANIFEST, wrapper, native, OUT / 'quartus-sta-ldd.txt',
             QUARTUS / 'adm/qenv.sh'}
    optional_runtime = [QUARTUS / 'adm/qtb.sh']
    paths.update(path for path in optional_runtime if path.is_file())
    paths.update(path for path in (QUARTUS / 'linux64').glob('*.so*') if path.is_file())
    paths.update(Path(name) for name in re.findall(r'(?:=>\s+)?(/[^\s()]+)', dependencies))
    inputs = {str(path): sha(path) for path in sorted(paths)}
    command = [str(wrapper), '-t', str(TCL), str(private / 'top.qpf'), str(OUT / 'timing')]
    profile = {'schema': 1, 'classification': manifest['classification'], 'command': command, 'cwd': str(private),
               'environment': environment, 'input_sha256': inputs, 'fit_input_sha256': expected,
               'unavailable_optional_runtime_paths': [str(path) for path in optional_runtime if not path.is_file()],
               'exact_input_timing_calibration': False, 'fit_performed': False, 'gain_accepted': False,
               'equivalence_proved': False, 'hardware_tested': False}
    write(OUT / 'query-profile.json', profile)
    profile_hash = sha(OUT / 'query-profile.json')
    started = time.monotonic()
    exit_code, failure = None, None
    try:
        require(tree(source) == tree(private) == expected and all(sha(path) == digest for path, digest in inputs.items()),
                'bound query bytes changed before launch')
        with (OUT / 'timing-driver.log').open('x') as stream:
            result = subprocess.run(command, cwd=private, env=environment, stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=300, check=False)
        exit_code = result.returncode
        require(exit_code == 0 and (OUT / 'timing/completion.txt').is_file(), 'native query did not complete')
        original_after, private_after = tree(source), tree(private)
        require(original_after == expected and all(private_after.get(name) == expected[name] for name in CRITICAL),
                'original fit or critical private fitted bytes changed')
        require(all(sha(path) == digest for path, digest in inputs.items()) and sha(OUT / 'query-profile.json') == profile_hash,
                'query producer/runtime/profile bytes changed')
        outputs = tree(OUT / 'timing')
        require(outputs and tree(OUT / 'timing') == outputs, 'query output bytes unstable')
        record = {**profile, 'completed': True, 'exit_code': exit_code, 'elapsed_seconds': time.monotonic() - started,
                  'profile_sha256': profile_hash, 'output_sha256': outputs,
                  'driver_log_sha256': sha(OUT / 'timing-driver.log'), 'retained_source_inputs_unchanged': True,
                  'private_critical_fit_inputs_unchanged': True,
                  'private_changed_input_files': sorted(name for name in expected if private_after.get(name) != expected[name]),
                  'private_additional_files': sorted(set(private_after) - set(expected)),
                  'runtime_scope': 'Installed native payload/library files and ldd dependencies hashed; no loaded-library execution trace claimed.'}
        write(OUT / 'query-record.json', record)
        print(json.dumps({'completed': True, 'exit_code': exit_code, 'record_sha256': sha(OUT / 'query-record.json')}))
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
        snapshots = {}
        for name, root in [('original', source), ('private', private), ('output', OUT / 'timing')]:
            try:
                snapshots[name] = tree(root)
            except Exception as snapshot_error:
                snapshots[name] = {'error': str(snapshot_error)}
        write(OUT / 'failed-query-record.json', {**profile, 'completed': False, 'exit_code': exit_code,
              'elapsed_seconds': time.monotonic() - started, 'failure': failure, 'project_trees_after': snapshots})
        raise


if __name__ == '__main__':
    main()
