#!/usr/bin/env python3
"""Fixed one-shot RAM-test synthesis; snapshots are evidence, not equivalence or gain."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

WORK = Path('/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d')
ROOT = WORK / 'sources/misteross'
HERE = WORK / 'out/ramtest-wide-reduction-264/capture-pipeline-264'
HELPER = HERE / 'check_yosys_ffmux.py'
HELPER_SHA = 'd02c48d9e950b5b7478b7c5b0cbb73486246178d23cd7e3a2d893388e8ffc0b4'
CONFIG = HERE / 'yosys-ffmux-check-configure-v1/record.json'
CONFIG_SHA = '6222b5b3c94ef8d5f57006110025610c03c65350992e3f84e2a3d610c76d1877'
BUILT = HERE / 'yosys-ffmux-check-build-v1/record.json'
BUILT_SHA = 'cc6c95b085bf01303cca97d08864ea84614c3c91128ca2e43ea7087b38577533'
OLD = WORK / 'out/ramtest-merged-remap/measured-diagnostic'
INPUTS_SHA = '1d5ec9f5e18bfffb6083860af8257bbfb5daf093014f20621a3b3bd623b189a8'
SYNTH_SHA = '61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28'
BUILD_ENV_SHA = 'c5855cb6e17ee01d776bf04e95ae045287eda57ab76b058d5db0841d4fb7fa41'
BUILD_ID = '7168b508ab424b70f1c0f87b2035d821'
ELFS = {'yosys': '8ce1fe93a22e5be2db903aaf28b0c03e79a5d50d24d3a1fe4eb2d4e1cf514fc3',
        'yosys-abc': '60db0250b9f637ff040d4b4d5858c4d578e3551d71909f50979f5587c4805fe9'}
RTL = ('cores/fes-pong/rtl/pixel_pll.v', 'cores/fes-common/rtl/fes_application_gp.v',
       'cores/fes-common/rtl/fes_video_720p.v', 'cores/fes-common/rtl/fes_hps_ddr.v',
       'cores/fes-common/rtl/fes_hps_ddr_guard.v', 'cores/fes-ramtest/rtl/mem_channel.v',
       'cores/fes-ramtest/rtl/ram_font.v', 'cores/fes-ramtest/rtl/ram_display.v',
       'cores/fes-ramtest/rtl/sdram_addon_port.v', 'cores/fes-ramtest/rtl/ddr_rates.v',
       'cores/fes-ramtest/rtl/ddr_channel.v', 'cores/fes-ramtest/rtl/top.v', 'cores/fes-ramtest/rtl/ram_pll.v')
HEADER = 'cores/fes-common/generated/fes_application.vh'
ENV = {k: v for k, v in os.environ.items() if k in {
    'PATH', 'HOME', 'TMPDIR', 'LD_LIBRARY_PATH', 'CMAKE_PREFIX_PATH', 'PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR'}}
ENV.update(LANG='C', LC_ALL='C')

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def helper_module():
    require(sha(HELPER) == HELPER_SHA, 'reviewed new build helper changed')
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('ffmux_synthesis_readonly_inputs', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    require(helper.ENV == ENV, 'read-only helper execution environment differs')
    return helper  # Only pure inputs() and its read-only dependencies; never main/configure/build.

def closure(helper, expected):
    require(sha(CONFIG) == CONFIG_SHA and sha(BUILT) == BUILT_SHA and
            sha(OLD / 'run-inputs.json') == INPUTS_SHA, 'closed record changed')
    config, built, old = (json.loads(p.read_text()) for p in (CONFIG, BUILT, OLD / 'run-inputs.json'))
    selected = helper.inputs()
    files = {str(HELPER): HELPER_SHA, str(Path(__file__).resolve()): expected,
             str(CONFIG): CONFIG_SHA, str(BUILT): BUILT_SHA, str(OLD / 'run-inputs.json'): INPUTS_SHA,
             str(OLD / 'synth.json'): SYNTH_SHA}
    for stage, record, path in (('configure', config, CONFIG), ('build', built, BUILT)):
        require(record['schema'] == 'yosys-ffmux-build-check-v1' and record['stage'] == stage and
                record['state'] == 'passed' and record['exit_code'] == 0 and record['completed_normally'] is True and
                record['inputs_unchanged'] is True and record['inputs_before'] == record['inputs_after'] == selected and
                record['recorder_sha256'] == record['recorder_after_sha256'] == HELPER_SHA and
                record['command'] == helper.COMMANDS[stage] and record['cwd'] == str(helper.SOURCE) and
                record['environment_sha256'] == BUILD_ENV_SHA and record['tests_run'] is False and
                all(record[k] is False for k in ('compiled_commit_asserted', 'gain_qualified', 'hardware')),
                'archived source/build/claims differ')
        files[str(path.parent / 'output.log')] = record['log_sha256']
    cache, binding = helper.BUILD / 'CMakeCache.txt', helper.BUILD / 'ffmux-configure-binding.json'
    require(config['cache_sha256'] == built['cache_sha256'] == sha(cache) and
            config['configure_binding_sha256'] == built['configure_binding_sha256'] == sha(binding), 'cache/binding differs')
    require(json.loads(binding.read_text()) == {'recorder_sha256': HELPER_SHA, 'inputs': selected,
            'command': helper.COMMANDS['configure'], 'environment_sha256': BUILD_ENV_SHA,
            'cache_sha256': sha(cache)}, 'configure binding differs')
    runtime = {'executables': {n: sha(helper.BUILD / n) for n in ELFS},
               'share_files': {str(p.relative_to(helper.BUILD)): sha(p) for p in sorted((helper.BUILD / 'share').rglob('*')) if p.is_file()},
               'build_shared_libraries': {str(p.relative_to(helper.BUILD)): sha(p) for p in sorted(helper.BUILD.rglob('*.so*')) if p.is_file()}}
    require(runtime['executables'] == ELFS, 'selected compiler/ABC ELF differs')
    for key, inventory in runtime.items():
        require(inventory == built[key], 'runtime inventory differs: ' + key)
        files.update({str(helper.BUILD / name): digest for name, digest in inventory.items()})
    require(old['build_id'] == BUILD_ID and old['memory_mhz'] == 130 and len(old['sources']) == 25,
            'frozen RAM-test inputs differ')
    source = {str(ROOT / name): sha(ROOT / name) for name in old['sources']}
    require(source == {str(ROOT / name): digest for name, digest in old['sources'].items()}, 'frozen FES source bytes differ')
    files.update(source); files.update({str(cache): built['cache_sha256'], str(binding): built['configure_binding_sha256']})
    require(all(sha(name) == digest for name, digest in files.items()), 'bound records/logs/runtime/source changed')
    return {'production': selected, 'runtime': runtime, 'artifact_sha256': files,
            'archived_build_environment_keys': built['environment_keys'], 'archived_build_environment_sha256': BUILD_ENV_SHA}

def dependencies(path, directory, before):
    text = path.read_text()
    require(text.endswith('\n') and text.count(':') == 1 and '\n' not in text[:-1], 'unsupported Make dependency grammar')
    def tokens(value):
        result, token, escaped = [], '', False
        for char in value:
            if escaped:
                require(char == ' ', 'unsupported Make escape'); token += char; escaped = False
            elif char == '\\':
                escaped = True
            elif char == ' ':
                if token: result.append(token); token = ''
            else:
                require(char not in '\t\r\n#$', 'unsupported Make token'); token += char
        require(not escaped, 'trailing Make escape')
        return result + ([token] if token else [])
    targets, inputs = (tokens(part) for part in text[:-1].split(':'))
    resolve = lambda name: str((ROOT / name).resolve())
    require({resolve(n) for n in targets} == {str((directory / 'synth.json').resolve())}, 'unexpected dependency target')
    allowed = {str((ROOT / n).resolve()) for n in (*RTL, HEADER)}
    allowed.update(str(Path(n).resolve()) for n in before['artifact_sha256'] if '/share/' in n)
    actual = {resolve(n) for n in inputs}
    require(len(actual) == len(inputs) and actual <= allowed and
            {str((ROOT / n).resolve()) for n in (*RTL, HEADER)} <= actual, 'missing or undeclared synthesis dependency')
    return {name: sha(name) for name in sorted(actual)}

def write(path, document):
    pending = path.with_suffix('.pending')
    with pending.open('x') as stream:
        stream.write(json.dumps(document, indent=2, sort_keys=True) + '\n')
    pending.replace(path)

def main():
    require(len(sys.argv) == 4 and sys.argv[1] in ('off', 'on'), 'usage: off|on NEW_LABEL SELF_SHA256')
    mode, label, expected = sys.argv[1:]
    require(re.fullmatch('[0-9a-f]{64}', expected) and sha(__file__) == expected and
            re.fullmatch('[a-z0-9][a-z0-9-]*', label), 'self pin or label differs')
    directory = HERE / ('ramtest-ffmux-synth-' + mode + '-' + label); directory.mkdir(exist_ok=False)
    record, log = directory / 'record.json', directory / 'output.log'; started = time.monotonic()
    env_sha = hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest()
    document = {'schema': 'ramtest-ffmux-synthesis-v1', 'mode': mode, 'state': 'running', 'exit_code': None,
                'completed_normally': False, 'recorder_sha256': expected, 'started_unix': time.time(),
                'execution_environment_keys': sorted(ENV), 'execution_environment_sha256': env_sha,
                'archived_build_environment_sha256': BUILD_ENV_SHA, 'same_environment_claimed': False,
                'execution_environment_equals_build': env_sha == BUILD_ENV_SHA,
                'cleared_diagnostic_keys': sorted(k for k in os.environ if k.startswith(('NEXTPNR_', 'YOSYS_'))),
                'source_and_build_unchanged': False, 'compiled_commit_asserted': False,
                'tests_run': False, 'equivalence_proved': False, 'gain_qualified': False, 'hardware': False,
                'scope': 'One-shot synthesis and selected RTLIL snapshots only; no dynamic-loader or route/hardware acceptance.'}
    write(record, document); print(json.dumps({'mode': mode, 'state': 'running', 'record': str(record)}), flush=True)
    try:
        helper = helper_module(); before = closure(helper, expected); document['before'] = before
        snapshots = {'15.41': ('pre.il', 'INTEL_ALM_FFMUX' if mode == 'on' else 'CLKBUFMAP')}
        if mode == 'on': snapshots.update({'15.42': ('immediate.il', 'OPT_CLEAN'), '15.43': ('clean.il', 'CLKBUFMAP')})
        program = ('read_verilog -sv -D RAM_RATE_SWEEP=1 -D RAM_130_ONLY=1 -D RAM_OSS_HIGH_SPEED=1 '
                   '-I cores/fes-common/generated ' + ' '.join(RTL) +
                   "; chparam -set BUILD_ID 128'h" + BUILD_ID + ' top; synth_intel_alm -nobram -nolutram -nodsp' +
                   (' -ffmux' if mode == 'on' else '') + ' -top top; stat; write_json ' + str(directory / 'synth.json'))
        command = [str(helper.BUILD / 'yosys'), '-E', str(directory / 'deps.d')]
        for index, (name, _) in snapshots.items(): command += ['-P', index + ':' + str(directory / name)]
        command += ['-p', program]; document.update(command=command, cwd=str(ROOT), build_id=BUILD_ID)
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        document.update(exit_code=result.returncode, completed_normally=True)
        after = closure(helper, expected); document['after'] = after
        require(after == before, 'source/submodules/runtime/cache/input records changed')
        document['source_and_build_unchanged'] = True
        require(result.returncode == 0, 'one-shot synthesis failed')
        text = log.read_text(); require('End of script.' in text, 'normal Yosys completion marker missing')
        for index, (name, title) in snapshots.items():
            require(len(re.findall('^' + re.escape(index) + r'\. Executing ' + title + r' pass', text, re.M)) == 1,
                    'snapshot header boundary differs: ' + index)
            dump = (directory / name).read_text()
            require('module \\top\n' in dump and 'module \\MISTRAL_FF\n' in dump and 'autoidx ' in dump,
                    'snapshot lacks expected native module/model/header')
        require(('Executing INTEL_ALM_FFMUX pass' in text) == (mode == 'on'), 'opt-in execution differs')
        document['dependencies'] = dependencies(directory / 'deps.d', directory, before)
        outputs = {'synth.json', 'deps.d', 'output.log', *(name for name, _ in snapshots.values())}
        require({p.name for p in directory.iterdir()} == outputs | {'record.json'}, 'unexpected output set')
        document['outputs'] = {name: sha(directory / name) for name in sorted(outputs)}
        require(sha(__file__) == expected, 'recorder changed'); document['state'] = 'passed'
    except BaseException as error:
        document.update(state='failed', error_type=type(error).__name__, error=str(error))
    finally:
        document['elapsed_seconds'] = time.monotonic() - started; document['finished_unix'] = time.time()
        document['partial_outputs'] = {p.name: sha(p) for p in directory.iterdir() if p.is_file() and p != record}
        document['recorder_after_sha256'] = sha(__file__); write(record, document)
        print(json.dumps({'mode': mode, 'state': document['state'], 'exit_code': document['exit_code'],
                          'record_sha256': sha(record), 'elapsed_seconds': document['elapsed_seconds']}), flush=True)
    return 0 if document['state'] == 'passed' else 1

if __name__ == '__main__':
    sys.exit(main())
