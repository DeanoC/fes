"""Run one fixed Yosys FF-mux test against the closed, byte-bound build."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
SOURCE = Path('/home/deano/kepler/worktrees/yosys-experiment-intel-alm-ffmux-264-6f6ea018')
BUILD = WORK / 'sources/misteross/build/toolchain-ramtest-timing/build/yosys-ffmux-264'
RECORD = HERE / 'yosys-ffmux-check-build-v1/record.json'
RECORD_SHA = 'cc6c95b085bf01303cca97d08864ea84614c3c91128ca2e43ea7087b38577533'
TESTS = {'ffmux': 'ffmux.ys', 'dffs': 'dffs.ys', 'adffs': 'adffs.ys', 'fsm-init': 'fsm_init.ys'}
FIXTURES = ('tests/arch/intel_alm/ffmux.v', 'tests/arch/intel_alm/ffmux.ys',
            'tests/arch/intel_alm/dffs.ys', 'tests/arch/intel_alm/adffs.ys',
            'tests/arch/intel_alm/fsm_init.ys', 'tests/arch/common/dffs.v', 'tests/arch/common/adffs.v')
ENV = {k: v for k, v in os.environ.items() if k in {
    'PATH', 'HOME', 'TMPDIR', 'LD_LIBRARY_PATH', 'CMAKE_PREFIX_PATH', 'PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR'}}
ENV.update(LANG='C', LC_ALL='C')

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    temporary = path.with_suffix('.pending')
    with temporary.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
    temporary.replace(path)

def verify_build(record):
    selected = record['inputs_before']
    for name, row in selected['files'].items():
        path = SOURCE / name
        require(sha(path) == row['sha256'], 'selected source changed: ' + name)
        require((os.readlink(path) if path.is_symlink() else None) == row['symlink'], 'source alias changed: ' + name)
    for prefix, row in selected['submodules'].items():
        head = subprocess.check_output(['git', '-C', str(SOURCE / prefix), 'rev-parse', 'HEAD'], env=ENV).decode().strip()
        require(head == row['head'] == row['expected_gitlink'], 'submodule HEAD changed')
    head = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], env=ENV).decode().strip()
    require(head == selected['source_head'], 'source HEAD changed')
    for name, value in record['executables'].items():
        require(sha(BUILD / name) == value, 'build ELF changed')
    for key in ('share_files', 'build_shared_libraries'):
        for name, value in record[key].items():
            require(sha(BUILD / name) == value, 'build share/library changed')
    require(sha(BUILD / 'CMakeCache.txt') == record['cache_sha256'], 'build cache changed')
    require(sha(BUILD / 'ffmux-configure-binding.json') == record['configure_binding_sha256'], 'configure binding changed')
    require(sha(HERE / 'check_yosys_ffmux.py') == record['recorder_sha256'], 'build recorder changed')
    require(sha(RECORD) == RECORD_SHA, 'closed build record changed')

def main():
    require(len(sys.argv) == 4 and sys.argv[1] in TESTS, 'usage: TEST NEW_LABEL SCRIPT_SHA256')
    stage, label, expected = sys.argv[1:]
    require(label and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label), 'invalid label')
    require(sha(__file__) == expected and sha(RECORD) == RECORD_SHA, 'recorder/build pin differs')
    record = json.loads(RECORD.read_text())
    require(record['state'] == 'passed' and record['exit_code'] == 0 and record['completed_normally'] and
            record['inputs_unchanged'] and record['inputs_before'] == record['inputs_after'], 'build was not closed successful')
    environment_sha = hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest()
    require(environment_sha == record['environment_sha256'], 'effective environment differs from build')
    verify_build(record)
    fixtures = {name: sha(SOURCE / name) for name in FIXTURES}
    directory = HERE / ('yosys-ffmux-test-' + label)
    directory.mkdir(exist_ok=False)
    output, log = directory / 'record.json', directory / 'output.log'
    command = [str(BUILD / 'yosys'), '-s', TESTS[stage]]
    started = time.monotonic()
    document = {'schema': 'yosys-ffmux-test-v1', 'state': 'running', 'test': stage,
                'recorder_sha256': expected, 'build_record_sha256': RECORD_SHA,
                'command': command, 'cwd': str(SOURCE / 'tests/arch/intel_alm'), 'fixture_sha256': fixtures,
                'environment_sha256': environment_sha, 'environment_keys': sorted(ENV),
                'exit_code': None, 'completed_normally': False, 'source_and_build_unchanged': False,
                'gain_qualified': False, 'hardware': False, 'compiled_commit_asserted': False}
    write(output, document)
    print(json.dumps({'test': stage, 'state': 'running', 'record': str(output)}), flush=True)
    try:
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=document['cwd'], env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        document.update(exit_code=result.returncode, completed_normally=True)
        verify_build(record)
        require(fixtures == {name: sha(SOURCE / name) for name in FIXTURES}, 'test fixtures changed')
        require(sha(__file__) == expected, 'test recorder changed')
        document['source_and_build_unchanged'] = True
        document['state'] = 'passed' if result.returncode == 0 else 'failed'
    except BaseException as error:
        document.update(state='failed', error_type=type(error).__name__, error=str(error))
    finally:
        document['elapsed_seconds'] = time.monotonic() - started
        document['log_sha256'] = sha(log) if log.is_file() else None
        write(output, document)
        print(json.dumps({'test': stage, 'state': document['state'], 'exit_code': document['exit_code'],
                          'record_sha256': sha(output), 'elapsed_seconds': document['elapsed_seconds']}), flush=True)
    return 0 if document['state'] == 'passed' else 1

if __name__ == '__main__':
    sys.exit(main())
