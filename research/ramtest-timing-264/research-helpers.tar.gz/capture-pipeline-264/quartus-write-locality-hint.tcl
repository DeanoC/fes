# Root-only retained-fit query; no synthesis, fit, routing or hardware operation.
# Usage: quartus_sta -t quartus-write-locality-hint.tcl new-private-project/top.qpf new-output
# Root authenticates copied project/runtime/script bytes and before/after trees.
# BUILD_ID52991 differs from current OSS7168: these are mapping/locality hints.
if {[llength $quartus(args)] != 2} {error "Expected authenticated private project.qpf and nonexistent output directory"}
set project [file normalize [lindex $quartus(args) 0]]
set output [file normalize [lindex $quartus(args) 1]]
if {[file exists $output]} {error "Refusing existing output directory: $output"}
set qsf_file [open [file rootname $project].qsf r]
set qsf_text [read $qsf_file]
close $qsf_file
set observed_build_id MISSING
regexp {RAMTEST_BUILD_ID=128'h([0-9a-fA-F]{32})} $qsf_text ignored observed_build_id
if {[string tolower $observed_build_id] != "52991ce22369904849b68bdd900f9ae1"} {error "Unexpected retained-fit BUILD_ID: $observed_build_id"}
foreach relative {top.qpf top.qsf clocks.sdc db/top.cmp.hdb db/top.routing.rdb db/top.sta_cmp.7_slow_1100mv_100c.tdb} {
    set path [file join [file dirname $project] $relative]
    if {![file isfile $path] || [file size $path] == 0} {error "Missing or empty fitted input: $relative"}
}
file mkdir $output
set identity [open [file join $output identity.txt] {WRONLY CREAT EXCL}]
puts $identity "script [file normalize [info script]]"
puts $identity "project $project"
puts $identity "quartus_build_id $observed_build_id"
puts $identity "oss_build_id 7168b508ab424b70f1c0f87b2035d821"
puts $identity "classification retained-fit mapping/locality hints only; different BUILD_ID; clocks/SDC/models not independently matched; no exact-input timing calibration or acceptance"
puts $identity "source_mapping actual named bank FFs and native returned path owners; no OSS generated FF suffix interpreted as an RTL bit"
puts $identity "scope all named original bank FFs plus explicit copy-inclusive group; npaths8/check/group, not exhaustive signoff"
puts $identity "model slow temperature_C100 voltage_mV1100; setup/hold only; unavailable or empty properties are not zero"
if {[info exists quartus(version)]} {puts $identity "quartus_version $quartus(version)"}
close $identity

proc tsv {values} {
    set escaped {}
    foreach value $values {lappend escaped [string map [list "\\" "\\\\" "\t" "\\t" "\n" "\\n" "\r" "\\r"] $value]}
    return [join $escaped \t]
}
proc property {command} {
    if {[catch {uplevel #0 $command} value]} {return [list unavailable_error $value]}
    if {$value == ""} {return [list empty_or_unavailable {}]}
    return [list available $value]
}
proc resolve_registers {names} {
    set patterns {}
    foreach name $names {lappend patterns [string map [list "\[" "?" "\]" "?"] $name]}
    set result [get_registers $patterns]
    set actual {}
    foreach_in_collection reg $result {lappend actual [get_register_info -name $reg]}
    if {[lsort -unique $actual] != [lsort -unique $names]} {error "Register names did not re-resolve exactly: $names"}
    return $result
}
proc resolve_pin {name} {
    set pattern [string map [list "\[" "?" "\]" "?"] $name]
    set result [get_pins -compatibility_mode [list $pattern]]
    if {[get_collection_size $result] != 1} {error "Pin did not re-resolve uniquely: $name"}
    foreach_in_collection pin $result {
        if {[get_pin_info -name $pin] != $name} {error "Re-resolved pin name differs: $name"}
    }
    return $result
}
proc named_bank_owner {actual} {
    global bank_names
    set matches {}
    foreach name [dict keys $bank_names] {
        # Native node/cell/pin APIs can differ by a leading hierarchy prefix.
        # Compare literal text at a hierarchy boundary, never a glob or bit suffix.
        set short $actual
        set long $name
        if {[string length $short] > [string length $long]} {set short $name; set long $actual}
        set offset [expr {[string length $long] - [string length $short]}]
        if {$actual == $name || ($offset > 0 && [string index $long [expr {$offset - 1}]] == "|" &&
            [string range $long $offset end] == $short)} {lappend matches $name}
    }
    if {[llength $matches] > 1} {error "Ambiguous native owner among named bank registers: $actual"}
    return [lindex $matches 0]
}
proc query {label options} {
    global output reports path_properties selected_sources bank_names
    foreach check {setup hold} {
        set filename "$label-$check.rpt"
        set argv [concat [list -$check] $options [list -npaths 8 -detail full_path -show_routing]]
        set result [report_timing {*}$argv -file [file join $output $filename]]
        set paths [get_timing_paths {*}$argv]
        set status native_paths_retained
        if {[get_collection_size $paths] == 0} {set status native_no_path_not_a_pass}
        puts $reports [tsv [list $label $check $filename $result [get_collection_size $paths] $status]]
        set ordinal 0
        foreach_in_collection path $paths {
            incr ordinal
            foreach option {-from -to -from_clock -to_clock -from_clock_is_inverted -to_clock_is_inverted -slack -clock_relationship -clock_skew -data_delay -num_logic_levels} {
                set value [property [list get_path_info $option $path]]
                puts $path_properties [tsv [list $label $check $ordinal path $option {*}$value]]
            }
            foreach endpoint {from to} {
                set node [get_path_info -$endpoint $path]
                if {$node == ""} {
                    puts $path_properties [tsv [list $label $check $ordinal $endpoint node empty_or_unavailable {}]]
                    continue
                }
                foreach option {-name -type -location -cell} {
                    set value [property [list get_node_info $option $node]]
                    puts $path_properties [tsv [list $label $check $ordinal $endpoint $option {*}$value]]
                }
                if {$endpoint != "from" || (![string match "bank-*" $label] && $label != "hard-unrestricted")} {continue}
                set names {}
                set node_name [property [list get_node_info -name $node]]
                if {[lindex $node_name 0] == "available"} {lappend names [lindex $node_name 1]}
                set cell [property [list get_node_info -cell $node]]
                if {[lindex $cell 0] == "available"} {
                    set cell_name [property [list get_cell_info -name [lindex $cell 1]]]
                    puts $path_properties [tsv [list $label $check $ordinal from owner_name {*}$cell_name]]
                    if {[lindex $cell_name 0] == "available"} {lappend names [lindex $cell_name 1]}
                }
                foreach name $names {
                    set owner [named_bank_owner $name]
                    if {$owner != ""} {
                        dict set selected_sources $owner 1
                        puts $path_properties [tsv [list $label $check $ordinal from resolved_named_bank_owner available $owner]]
                    }
                }
            }
        }
    }
}

cd [file dirname $project]
project_open [file rootname [file tail $project]]
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist
set registers [get_registers {*hps_ddr*}]
set bank_file [open [file join $output bank-registers.tsv] {WRONLY CREAT EXCL}]
puts $bank_file "id\tname\trole\tlocation_state\tlocation\tfanout_edges_state\tnative_fanout_edges"
set bank_names [dict create]
set originals {}
foreach_in_collection reg $registers {
    set name [get_register_info -name $reg]
    set signal {}
    set suffix {}
    if {![regexp {\|(m0_writedata|m_writedata)\[[0-9]+\](~[^|]+)?$} $name ignored signal suffix]} {continue}
    if {$signal == "m_writedata" && ![regexp {\|fes_hps_ddr_guard:port0\|} $name]} {continue}
    set role named_original
    if {$suffix == ""} {lappend originals $name} else {set role named_fitter_copy}
    dict set bank_names $name $reg
    set location [property [list get_node_info -location $reg]]
    set fanout [property [list get_register_info -fanout_edges $reg]]
    puts $bank_file [tsv [list $reg $name $role {*}$location {*}$fanout]]
}
close $bank_file
if {![llength $originals] || [dict size $bank_names] > 1024} {project_close; error "Named original bank absent or exceeds1024; inspect bank-registers.tsv"}
set hard_pin_file [open [file join $output hard-pins.tsv] {WRONLY CREAT EXCL}]
puts $hard_pin_file "id\tname\trole\tinput_state\tinput_value\tclock_state\tclock_value"
set hard_names {}
set hard_pins [get_pins -compatibility_mode {*f2sdram*}]
if {[get_collection_size $hard_pins] > 4096} {close $hard_pin_file; project_close; error "Hard-IP pin inventory exceeds4096"}
foreach_in_collection pin $hard_pins {
    set name [get_pin_info -name $pin]
    set input [property [list get_pin_info -is_in_pin $pin]]
    set clock [property [list get_pin_info -is_clock_pin $pin]]
    set role inventoried_not_selected
    if {[regexp -nocase {\|wr_data_1\[19\]$} $name]} {
        set role named_target_pin
        if {[lindex $input 0] != "available" || ![lindex $input 1] ||
            [lindex $clock 0] != "available" || [lindex $clock 1]} {
            close $hard_pin_file; project_close; error "Named hard input cannot be classified: $name"
        }
        lappend hard_names $name
    }
    puts $hard_pin_file [tsv [list $pin $name $role {*}$input {*}$clock]]
}
close $hard_pin_file
if {[llength $hard_names] != 1} {project_close; error "No unique actual wr_data_1 pin19; inspect hard-pins.tsv before changing a query"}
set destination [resolve_pin [lindex $hard_names 0]]
set reports [open [file join $output reports.tsv] {WRONLY CREAT EXCL}]
set path_properties [open [file join $output path-properties.tsv] {WRONLY CREAT EXCL}]
puts $reports "label\tcheck\tfile\tnative_result\tnative_path_count\tstatus"
puts $path_properties "label\tcheck\tpath_ordinal\tobject\toption\tstate\tvalue"
set selected_sources [dict create]
query bank-originals [list -from [resolve_registers $originals] -to $destination]
query bank-with-copies [list -from [resolve_registers [dict keys $bank_names]] -to $destination]
# Also retain the native launch without a naming filter. An unnamed/renamed
# producer remains visible in this report even if no bank owner can resolve.
query hard-unrestricted [list -to $destination]
if {[dict size $selected_sources] > 16} {close $reports; close $path_properties; project_close; error "Actual source inventory exceeds16"}
set selected_file [open [file join $output actual-launch-registers.tsv] {WRONLY CREAT EXCL}]
puts $selected_file "name\tregister_id\tselection"
foreach name [lsort [dict keys $selected_sources]] {puts $selected_file [tsv [list $name [dict get $bank_names $name] native_path_owner_matched_named_bank]]}
close $selected_file
set inputs [open [file join $output actual-launch-pins.tsv] {WRONLY CREAT EXCL}]
puts $inputs "id\tname\towner\trole\tinput_state\tinput_value\tclock_state\tclock_value"
set ordinal 0
foreach_in_collection pin [get_pins -compatibility_mode {*hps_ddr*}] {
    set name [get_pin_info -name $pin]
    if {![regexp {^(.*)\|[^|]+$} $name ignored native_owner]} {continue}
    set owner [named_bank_owner $native_owner]
    if {$owner == "" || ![dict exists $selected_sources $owner]} {continue}
    set input [property [list get_pin_info -is_in_pin $pin]]
    set clock [property [list get_pin_info -is_clock_pin $pin]]
    if {[lindex $input 0] != "available" || [lindex $clock 0] != "available"} {error "Actual launch pin classification unavailable: $name"}
    set role output_or_other_pin
    if {[lindex $clock 1]} {set role clock_not_queried} elseif {[lindex $input 1]} {
        set role queried_actual_nonclock_input
        incr ordinal
        if {$ordinal > 128} {error "Actual launch input inventory exceeds128"}
        query [format "incoming-%03d" $ordinal] [list -to [resolve_pin $name]]
    }
    puts $inputs [tsv [list $pin $name $owner $role {*}$input {*}$clock]]
}
close $inputs
close $reports
close $path_properties
set completion [open [file join $output completion.txt] {WRONLY CREAT EXCL}]
puts $completion "named_original_bank_registers [llength $originals]"
puts $completion "named_bank_registers_including_copies [dict size $bank_names]"
puts $completion "actual_launch_registers_resolved [dict size $selected_sources]"
puts $completion "actual_nonclock_launch_input_queries $ordinal"
puts $completion "unresolved_or_zero_path_is_not_a_pass [expr {[dict size $selected_sources] == 0 || $ordinal == 0}]"
puts $completion "classification retained-fit hint only; no BUILD_ID-matched/current-C0 calibration, no equivalence, gain or hardware acceptance"
close $completion
delete_timing_netlist
project_close
