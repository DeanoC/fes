#!/usr/bin/env python3
"""Independent exported graph/physical proof for the fixed search64 experiment.

Only the pinned lower pure parsers and physical functions are called. The old
operational main, authentication, generators and aggregate evaluators are not
replayed. The finished route record and this entire new file need explicit
activation digests. Gain acceptance is computed separately from graph proof.
"""
import argparse
import builtins
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import types

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
ROOT = HERE.parents[2]
EXPECTED_ROOT = Path("/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d")
PUB = RAW / "lut-pair-copies-publication-264"
TOOL = ROOT / "sources/misteross/build/toolchain-ramtest-timing"
SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-experiment-mistral-capture-pipeline-search-264-54cde5d3")
OLD_SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-feat-mistral-lut-pair-copies-264-54cde5d3")
MODEL = TOOL / "src/mistral"
BINARY = TOOL / "build/nextpnr-capture-pipeline-search-264/nextpnr-mistral"
BASE_BINARY = TOOL / "build/nextpnr-lut-pair-copies-publication-264/nextpnr-mistral"
CURRENT_BINARY_SHA = "d4277a58ccd84ece70a5f678eac6c0e8dafb2f7a2d08d6d3deeae59b100396ca"
BASE_BINARY_SHA = "fb53b77256ab2958c8dfc321a8e977e4a741a73b1ead584c21c8f72116b129e8"
RECORDER = HERE / "trial_search64.py"
RECORDER_SHA = "9201e96636fce9e11152b26644391ea4b84e308ffdf6c6f7b4edd12dae6ff3cc"
DIGEST = re.compile(r"[0-9a-f]{64}")
RUNS = {
    "baseline": (PUB / "main-baseline", "3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c"),
    "baseline_place": (PUB / "main-baseline-placed", "0ba98d9e976bc8488349cb274b46afe935e6a636641659087bb16a6727e91e06"),
    "disabled": (HERE / "legal64-disabled-placed", "565f61889cec317ace54a4308a3140e9feea9b19d3d498e1810efb7b87cb3b82"),
    "selected": (HERE / "legal64-pipeline-placed-b64-r24", "5473effd8642ba03a96fb6665356825b785119a3231c7d20aba51decaf92a78c"),
}
ROUTE_FOLDER = HERE / "legal64-pipeline-route-b64-r24"
ROUTE_RUN_SHA = "3e3628d856bb288a87f625f220572e6fa8aa34c620eb89fe80f6239b9450d7c8"
PREFIX_PROOF = (HERE / "proof-legal64-disabled-placement.json", "1d3adcb5b2e88e6697797a0262181317655b2e72b4641b3cd645166dd77311a8")
PLACEMENT_MANIFEST = (HERE / "proof-legal64-placed-graph.json", "b111938b634a510361f0232ded4e4d03d6de67c6ab91d065daa8353e0c3ac83e")
STATIC_REFERENCES = (
    (HERE / "prove_pipeline_b64.py", "3c64fd6c3127b5b686f47005d4014c75dfc8749ee152ee6f744dd62f5f80b490"),
    (HERE / "prove_pipeline_c0.py", "e9d9833b390a433c0e87f0f667a10fd407985d441abad14e31dc50111ac81b16"),
)
HELPERS = {
    "native": (RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"),
    "tables": (RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"),
    "physical": (RAW / "local-multicopy-ready1-address-route-proof-264/physical.py", "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"),
}
INPUTS = {
    "out/ramtest-merged-remap/measured-diagnostic/synth.json": "61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28",
    "sources/misteross/cores/fes-ramtest/constraints.qsf": "8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4",
    "sources/misteross/boards/de10nano/clocks.sdc": "3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041",
}
ADDED_FILES = ("mistral/capture_pipeline_locality.cc", "mistral/tests/capture_pipeline_locality.cc",
               "mistral/tests/capture_pipeline_locality_cli.py", "docs/mistral-capture-pipeline-locality.md")
GUIDE = RUNS["baseline_place"][0] / "timing.json"
GUIDE_SHA = "d117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512"
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
BASE_MHZ = {MEMORY: 105.77532958984375, PIXEL: 96.320556640625, CAPTURE: 375.0871276855469}
CONSTRAINTS = {MEMORY: 130.0052032470703, PIXEL: 74.25006866455078, CAPTURE: 130.0052032470703}
FF_PORTS = {port: "input" for port in ("SLOAD", "SDATA", "SCLR", "ENA", "DATAIN", "CLK", "ACLR")} | {"Q": "output"}
RUNTIME_ENV_KEYS = {"PATH", "LD_LIBRARY_PATH", "LD_PRELOAD", "LANG", "LC_ALL", "TZ", "CUDA_VISIBLE_DEVICES",
                    "HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "OMP_NUM_THREADS", "HSA_OVERRIDE_GFX_VERSION"}


def require(value, reason):
    if not value:
        raise ValueError("search64 pipeline proof: " + reason)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON: " + value)))


def load_pure(path, expected, name, freezer=None):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and sha(path) == expected and name not in sys.modules,
            "pinned pure helper changed or module name occupied")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    allowed = {"argparse", "builtins", "collections", "copy", "hashlib", "importlib", "json", "math", "pathlib", "re", "sys"}
    def local_import(requested, globals=None, locals=None, fromlist=(), level=0):
        require(level == 0, "relative helper import forbidden")
        if requested == "freeze":
            require(freezer is not None, "unexpected freeze import")
            return freezer
        require(requested.split(".")[0] in allowed, "unexpected pure helper import: " + requested)
        return builtins.__import__(requested, globals, locals, fromlist, level)
    module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(sha(path) == expected, "pinned pure helper changed while loading")
    return module


def order(value):
    if isinstance(value, dict):
        return [(key, order(item)) for key, item in value.items()]
    if isinstance(value, list):
        return [order(item) for item in value]
    return None


def exact(native, before, after, reason, ordered=True):
    require(native.canonical(before) == native.canonical(after), reason)
    if ordered:
        require(order(before) == order(after), reason + " (export order)")


def literal(cell, port):
    value = cell["connections"][port]
    require(type(value) is list and len(value) == 1 and type(value[0]) is int and value[0] >= 0,
            "nonliteral scalar port: " + port)
    return value[0]


def net_shape(row):
    result = copy.deepcopy(row)
    result.get("attributes", {}).pop("ROUTING", None)
    return result


def fixed_arguments():
    return ["--json", str(ROOT / "out/ramtest-merged-remap/measured-diagnostic/synth.json"),
            "--device", "5CSEBA6U23I7", "--qsf", str(ROOT / "sources/misteross/cores/fes-ramtest/constraints.qsf"),
            "--sdc", str(ROOT / "sources/misteross/boards/de10nano/clocks.sdc"), "--freq", "74.25", "--seed", "2",
            "--placer-heap-timingweight", "10", "--placer-heap-critexp", "2", "--replicate-enables", "4",
            "--timing-allow-fail", "--detailed-timing-report", "--router", "gpu", "--gpu-device", "1"]


def recorded_command(binary, folder, routed):
    command = [str(binary)] + fixed_arguments() + ["--write", str(folder / ("routed.json" if routed else "placed.json")),
               "--report", str(folder / "timing.json"), "--timing-report-paths", "16384"]
    return command + (["--rbf", str(folder / "core.rbf")] if routed else ["--no-route"])


def bind_outputs(audit, folder, record, names, strict_directory=False):
    outputs = record["output_sha256"]
    require(type(outputs) is dict and set(outputs) == names, "output closure differs: " + folder.name)
    for filename, digest in outputs.items():
        require(Path(filename).name == filename and type(digest) is str and DIGEST.fullmatch(digest), "invalid output identity")
        path = folder / filename
        require(path.is_file() and not path.is_symlink(), "output is not a regular retained artifact")
        audit.bind(path, digest)
    if strict_directory:
        entries = list(folder.iterdir())
        require({path.name for path in entries} == names | {"run.json"} and
                all(path.is_file() and not path.is_symlink() for path in entries), "finished output directory closure differs")
    return outputs


def environment_record(value, selected):
    fields = {"runtime_values", "selected_diagnostics", "cleared_diagnostic_keys", "all_effective_keys",
              "all_effective_values_sha256", "unlisted_values_recorded"}
    require(type(value) is dict and set(value) == fields and value["selected_diagnostics"] == selected and
            value["unlisted_values_recorded"] is False and DIGEST.fullmatch(value["all_effective_values_sha256"]),
            "recorded effective diagnostic environment differs")
    keys, cleared, runtime = value["all_effective_keys"], value["cleared_diagnostic_keys"], value["runtime_values"]
    require(type(keys) is list and all(type(key) is str for key in keys) and keys == sorted(set(keys)) and
            {key for key in keys if key.startswith("NEXTPNR_")} == set(selected), "effective diagnostic keys differ")
    require(type(cleared) is list and cleared == sorted(set(cleared)) and
            all(type(key) is str and key.startswith("NEXTPNR_") for key in cleared), "cleared diagnostic key ledger invalid")
    require(type(runtime) is dict and set(runtime) <= RUNTIME_ENV_KEYS and set(runtime) <= set(keys) and
            all(type(item) is str for item in runtime.values()) and
            all(runtime.get(key) == item for key, item in {"LANG": "C", "LC_ALL": "C", "TZ": "UTC"}.items()),
            "recorded runtime value subset or locale differs")


def authenticate_records(audit, route_run_sha):
    runs = {**RUNS, "current": (ROUTE_FOLDER, route_run_sha)}
    records, profiles, closure = {}, {}, {}
    for name in ("baseline", "baseline_place"):
        folder, expected = runs[name]
        audit.bind(folder / "run.json", expected)
        record = read(folder / "run.json")
        require(record["exit_code"] == 0 and record["gain_accepted"] is False and record["hardware_tested"] is False and
                record["native_physical_equivalence_proved"] is False and record["original_production_and_input_bytes_stable"] is True,
                "baseline is not the finished pinned exploratory record")
        require(type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
                record["elapsed_seconds"] > 0, "invalid baseline elapsed time")
        names = {"routed.json", "timing.json", "core.rbf", "route.log"} if name == "baseline" else {
            "placed.json", "timing.json", "profile.json", "placement.log"}
        outputs = bind_outputs(audit, folder, record, names)
        profile = record if name == "baseline" else read(folder / "profile.json")
        if name == "baseline":
            require(record["completed_normally"] is True, "baseline normal completion missing")
            helper = PUB / "main_baseline.py"
        else:
            require(record["profile_sha256"] == outputs["profile.json"] and
                    profile["baseline_sha256"] == runs["baseline"][1], "baseline placement profile/reference differs")
            helper = PUB / "main_baseline_placement.py"
        require(profile["binary_sha256"] == BASE_BINARY_SHA and profile["input_sha256"] == INPUTS and
                profile["cwd"] == str(ROOT / "sources/misteross") and
                profile["command"] == recorded_command(BASE_BINARY, folder, name == "baseline"), "fixed baseline execution differs")
        source_files = profile["production_source_sha256"]
        require(type(source_files) is dict and len(source_files) >= 1199, "baseline source inventory incomplete")
        for filename, digest in source_files.items():
            path = Path(filename)
            require(path.is_absolute() and str(path) == filename and
                    (path.is_relative_to(OLD_SOURCE) or path.is_relative_to(MODEL)), "unexpected baseline source root")
            audit.bind(path, digest, execution=True)
        for filename, digest in INPUTS.items():
            audit.bind(ROOT / filename, digest)
        audit.bind(BASE_BINARY, BASE_BINARY_SHA, execution=True)
        audit.bind(helper, profile["helper_sha256"])
        records[name], profiles[name] = record, profile
        closure[name] = {"run_sha256": expected, "profile_sha256": record.get("profile_sha256"),
                         "binary_sha256": BASE_BINARY_SHA, "production_source_sha256": source_files,
                         "input_sha256": INPUTS, "output_sha256": outputs, "live_source_and_binary_rehashed": True}
    require(profiles["baseline"]["production_source_sha256"] == profiles["baseline_place"]["production_source_sha256"],
            "baseline route and placement source inventories differ")
    audit.bind(GUIDE, GUIDE_SHA)
    audit.bind(RECORDER, RECORDER_SHA)
    audit.bind(BINARY, CURRENT_BINARY_SHA, execution=True)
    with BINARY.open("rb") as stream:
        require(stream.read(4) == b"\x7fELF", "selected compiler is not an ELF file")
    mapped_names, model_files = set(), {}
    for filename, digest in profiles["baseline"]["production_source_sha256"].items():
        path = Path(filename)
        if path.is_relative_to(OLD_SOURCE):
            mapped = SOURCE / path.relative_to(OLD_SOURCE)
        else:
            require(path.is_relative_to(MODEL), "baseline inventory cannot be mapped to fixed model")
            mapped = path
            model_files[str(path)] = digest
        require(str(mapped) not in mapped_names, "mapped new source inventory collision")
        mapped_names.add(str(mapped))
    mapped_names.update(str(SOURCE / filename) for filename in ADDED_FILES)
    require(model_files and any(Path(filename).is_relative_to(SOURCE) for filename in mapped_names), "mapped source/model inventory missing")
    for name in ("disabled", "selected", "current"):
        folder, expected = runs[name]
        audit.bind(folder / "run.json", expected)
        record = read(folder / "run.json")
        routed = name == "current"
        names = {"profile.json", "trial.log", "timing.json", "routed.json" if routed else "placed.json"}
        if routed:
            names.add("core.rbf")
        outputs = bind_outputs(audit, folder, record, names, strict_directory=True)
        require(record["schema"] == 1 and record["profile_name"] == "profile.json" and
                record["profile_sha256"] == outputs["profile.json"], "trial profile identity differs")
        profile = read(folder / "profile.json")
        require(record["exit_code"] == 0 and record["failure"] is None and
                all(record[key] is True for key in ("completed_normally", "production_and_input_bytes_stable", "profile_bytes_stable",
                    "normal_finish_marker", "output_bytes_stable", "outputs_complete")) and
                all(record[key] is False for key in ("compiled_commit_asserted", "gain_accepted", "native_physical_equivalence_proved", "hardware_tested")) and
                record["output_hash_errors"] == {} and record["invalid_output_entries"] == [], "trial is not a finished stable exploratory record")
        require(type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
                record["elapsed_seconds"] > 0 and record["expected_output_names_before_run_record"] == sorted(names) and
                record["actual_output_names_before_run_record"] == sorted(names), "trial elapsed time/output closure invalid")
        mode = {"disabled": "disabled-placed", "selected": "pipeline-placed", "current": "pipeline-route"}[name]
        selected = {} if name == "disabled" else {"NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY": str(GUIDE) + " 64 24"}
        require(profile["schema"] == 1 and profile["source_root"] == str(SOURCE) and profile["binary_path"] == str(BINARY) and
                profile["baseline_path"] == str(runs["baseline"][0] / "run.json") and profile["baseline_sha256"] == runs["baseline"][1] and
                profile["guide_path"] == str(GUIDE) and profile["guide_sha256"] == GUIDE_SHA and profile["helper_sha256"] == RECORDER_SHA and
                profile["binary_sha256"] == CURRENT_BINARY_SHA and profile["input_sha256"] == INPUTS and profile["mode"] == mode and
                profile["pipeline_budget"] == (0 if name == "disabled" else 64) and profile["pipeline_radius"] == 24 and
                profile["geometry_search_limit"] == 64 and profile["timed_trial_limit"] == 16 and
                profile["profile_name"] == "profile.json" and profile["expected_output_names_before_run_record"] == sorted(names) and
                all(profile[key] is False for key in ("compiled_commit_asserted", "native_physical_equivalence_proved", "gain_accepted", "hardware_tested")),
                "fixed new trial profile differs")
        require(profile["role"] == record["role"] and profile["cwd"] == record["cwd"] == str(ROOT / "sources/misteross") and
                profile["command"] == record["command"] == recorded_command(BINARY, folder, routed) and
                profile["environment"] == record["environment"] and record["helper_sha256"] == RECORDER_SHA and
                record["binary_sha256"] == CURRENT_BINARY_SHA, "record/profile execution selection differs")
        environment_record(profile["environment"], selected)
        source_files = profile["production_source_sha256"]
        require(type(source_files) is dict and set(source_files) == mapped_names and
                all(source_files[path] == digest for path, digest in model_files.items()), "exact mapped source inventory/model bytes differ")
        expected_snapshot = {**source_files, **{str(ROOT / path): digest for path, digest in INPUTS.items()},
                             str(RECORDER): RECORDER_SHA, str(BINARY): CURRENT_BINARY_SHA,
                             str(runs["baseline"][0] / "run.json"): runs["baseline"][1], str(GUIDE): GUIDE_SHA}
        snapshot = {"sha256": expected_snapshot, "errors": {}}
        require(profile["before_snapshot"] == record["before_snapshot"] == record["after_snapshot"] == snapshot,
                "complete before/after source/input/ELF/helper/reference snapshot differs")
        for filename, digest in expected_snapshot.items():
            path = Path(filename)
            audit.bind(path, digest, execution=path.is_relative_to(SOURCE) or path.is_relative_to(MODEL) or path == BINARY)
        require("Info: Program finished normally." in (folder / "trial.log").read_text(), "normal finish marker absent from actual log")
        records[name], profiles[name] = record, profile
        closure[name] = {"run_sha256": expected, "profile_sha256": outputs["profile.json"], "mode": mode,
                         "binary_sha256": CURRENT_BINARY_SHA, "production_source_sha256": source_files,
                         "input_sha256": INPUTS, "output_sha256": outputs, "before_snapshot": record["before_snapshot"],
                         "after_snapshot": record["after_snapshot"], "completed_normally": True, "compiled_commit_asserted": False,
                         "command": record["command"], "environment": record["environment"], "elapsed_seconds": record["elapsed_seconds"]}
    require(all(profiles[name]["production_source_sha256"] == profiles["disabled"]["production_source_sha256"]
                for name in ("selected", "current")), "new compiler source bytes differ between disabled/placed/routed stages")
    require(profiles["selected"]["environment"]["runtime_values"] == profiles["current"]["environment"]["runtime_values"],
            "recorded placed/routed runtime value subsets differ")
    source_files = profiles["current"]["production_source_sha256"]
    saved_proofs = {}
    for label, (path, digest) in (("disabled_prefix", PREFIX_PROOF), ("placement_manifest", PLACEMENT_MANIFEST)):
        audit.bind(path, digest)
        proof = read(path)
        require(proof["schema"] == 1 and proof["parser_sha256"] == HELPERS["native"][1] and proof["hardware_tested"] is False,
                "fixed native proof header differs")
        for filename, expected in proof["artifact_sha256"].items():
            relative = Path(filename)
            if relative.is_absolute():
                require(relative.is_relative_to(SOURCE) and str(relative) == filename, "native proof artifact outside fixed source")
                audit.bind(relative, expected, execution=True)
            else:
                require(".." not in relative.parts and str(relative) == filename, "native proof artifact escapes fixed root")
                audit.bind(ROOT / relative, expected)
        known_execution = {**source_files, str(BINARY): CURRENT_BINARY_SHA,
                           **{str(helper): pin for helper, pin in HELPERS.values()}}
        for filename, expected in proof["directly_rehashed_execution_sha256"].items():
            require(filename in known_execution and known_execution[filename] == expected, "native proof execution inventory differs from fixed closure")
            audit.bind(Path(filename), expected, execution=True)
        saved_proofs[label] = proof
    prefix, manifest = saved_proofs["disabled_prefix"], saved_proofs["placement_manifest"]
    require(prefix["baseline_placed_run_sha256"] == runs["baseline_place"][1] and
            prefix["new_disabled_run_sha256"] == runs["disabled"][1] and
            all(prefix[key] is True for key in ("whole_module_exact", "entire_timing_json_exact", "ordered_duplicate_pll_ports_exact")) and
            prefix["graph_or_physical_gain_accepted"] is False, "disabled prefix proof identity/scope differs")
    require(manifest["placement_run_sha256"] == runs["selected"][1] and manifest["original_cells"] == 14893 and
            all(manifest[key] is True for key in ("whole_module_exact_except_declared_ff_bel_changes", "ordered_duplicate_pll_ports_exact",
                "all_original_ports_metadata_params_init_aliases_raw_slots_and_cell_fields_exact")) and manifest["route_gain_accepted"] is False,
            "selected placement manifest identity/scope differs")
    closure["disabled_prefix_proof"] = {"path": str(PREFIX_PROOF[0]), "sha256": PREFIX_PROOF[1], "comparisons_rederived": True}
    closure["placement_manifest"] = {"path": str(PLACEMENT_MANIFEST[0]), "sha256": PLACEMENT_MANIFEST[1], "comparisons_rederived": True}
    return runs, records, profiles, closure, manifest


def prove_placement(native, tables, physical, documents, reports, manifest):
    base = documents["baseline_place"]["modules"]["top"]
    disabled = documents["disabled"]["modules"]["top"]
    selected = documents["selected"]["modules"]["top"]
    pairs = manifest["retained_pairs"]
    require(type(pairs) is list and len(pairs) == 53 and all(type(pair) is list and len(pair) == 2 and
            all(type(name) is str and name for name in pair) for pair in pairs), "fixed fifty-three pair manifest schema differs")
    moved = {name for pair in pairs for name in pair}
    require(len(moved) == 106, "pair manifest overlaps")
    exact(native, documents["baseline_place"]["modules"], documents["disabled"]["modules"], "disabled complete module differs from native baseline placement")
    exact(native, base["cells"].pll_ports, disabled["cells"].pll_ports, "disabled lossless ordered PLL outputs differ")
    exact(native, reports["baseline_place"], reports["disabled"], "disabled entire timing JSON differs from native guide")
    for key in ("settings", "attributes", "ports", "netnames"):
        exact(native, disabled[key], selected[key], "placement module " + key + " changed")
    require(set(disabled) == set(selected) == {"settings", "attributes", "ports", "cells", "netnames"} and
            list(disabled) == list(selected) and list(disabled["cells"]) == list(selected["cells"]), "placement module/owner frame differs")
    exact(native, disabled["cells"].pll_ports, selected["cells"].pll_ports, "placement lossless ordered PLL outputs changed")
    changes = []
    for name, before in disabled["cells"].items():
        after = copy.deepcopy(selected["cells"][name])
        old_bel, new_bel = before["attributes"].get("NEXTPNR_BEL"), after["attributes"].get("NEXTPNR_BEL")
        if old_bel != new_bel:
            require(name in moved and before["type"] == after["type"] == "MISTRAL_FF", "undeclared original placement change: " + name)
            after["attributes"]["NEXTPNR_BEL"] = old_bel
            changes.append({"cell": name, "old_bel": old_bel, "new_bel": new_bel})
        exact(native, before, after, "complete original cell changed beyond declared FF BEL: " + name)
    require({row["cell"] for row in changes} == moved and len(changes) == 106, "exact 106 changed FF set differs")
    exact(native, changes, manifest["ff_bel_moves"], "rederived FF BEL edits differ from pinned root manifest")
    require(tables.native_tables(disabled) == tables.native_tables(selected), "complete indexed native driver/user slots changed")
    old_native, new_native = physical.Native(disabled), physical.Native(selected)
    pair_rows = []
    for first, second in pairs:
        for view in (old_native, new_native):
            for name in (first, second):
                cell = view.cells[name]
                require(cell["type"] == "MISTRAL_FF" and cell["parameters"] == {} and cell["port_directions"] == FF_PORTS and
                        set(cell["connections"]) == set(FF_PORTS), "moved FF full native schema/INIT differs")
                require(all(cell["connections"][port] == [] for port in ("ENA", "ACLR", "SCLR", "SLOAD", "SDATA")), "moved FF is not plain")
                for port in ("DATAIN", "Q", "CLK"):
                    literal(cell, port)
            q = view.token(literal(view.cells[first], "Q"))
            require(view.users[q] == [(second, "DATAIN", 0)] and literal(view.cells[first], "Q") == literal(view.cells[second], "DATAIN") and
                    view.cells[first]["connections"]["CLK"] == view.cells[second]["connections"]["CLK"] and
                    view.users.get(view.token(literal(view.cells[second], "Q"))), "plain unique two-register chain/clock/users differ")
            source = view.token(literal(view.cells[first], "DATAIN"))
            require(source[0] == "cell" and view.cells[source[1]]["type"] == "cyclonev_hps_interface_fpga2sdram", "first FF is not the fixed registered HPS boundary")
            source_port = source[2]
            if len(view.cells[source[1]]["connections"][source_port]) != 1:
                source_port += "[" + str(source[3]) + "]"
            require(tables.register_clock(view.cells, (source[1], source_port)) == view.cells[first]["connections"]["CLK"],
                    "actual registered hard-output and FF clock signals differ")
        pair_rows.append({"first": first, "second": second, "clock_raw_bit": literal(disabled["cells"][first], "CLK"),
                          "source": list(old_native.token(literal(disabled["cells"][first], "DATAIN"))),
                          "first_q_sole_second_datain_consumer": True, "plain_two_register_latency_unchanged": True})
    return {"exact_original_cell_count": len(disabled["cells"]), "exact_original_netname_count": len(disabled["netnames"]),
            "disabled_whole_module_lossless_pll_and_entire_timing_rederived_exact": True,
            "original_graph_params_init_directions_metadata_alias_order_ports_and_raw_slots_exact": True,
            "lossless_ordered_pll_exact": True, "ff_bel_changes": changes, "manifest_retained_pairs": pairs,
            "disjoint_pairs": pair_rows, "outer_creator_strings": {name: documents[name]["creator"] for name in ("baseline_place", "disabled", "selected")},
            "global_numeric_renaming_or_buffer_collapse_used": False}, moved


def route_ledger(native, tables, physical, place_doc, route_doc):
    a, b = place_doc["modules"]["top"], route_doc["modules"]["top"]
    require(list(a) == list(b) and set(a) == {"settings", "attributes", "ports", "cells", "netnames"}, "route module frame differs")
    require(set(a["settings"]) <= set(b["settings"]), "route dropped placement settings")
    exact(native, a["settings"], {key: value for key, value in b["settings"].items() if key in a["settings"]}, "route changed existing settings")
    attrs = copy.deepcopy(a["attributes"])
    require(attrs.get("step") == "place" and "FES_LABSTATE_V1" not in attrs, "route input is not a native placed frame")
    attrs["step"] = "route"
    exact(native, attrs, {key: value for key, value in b["attributes"].items() if key != "FES_LABSTATE_V1"}, "route top metadata changed")
    exact(native, a["ports"], b["ports"], "route top interface changed")
    exact(native, a["cells"].pll_ports, b["cells"].pll_ports, "route lossless ordered PLL outputs changed")
    original_cells, original_nets = set(a["cells"]), set(a["netnames"])
    require(original_cells <= set(b["cells"]) and original_nets <= set(b["netnames"]), "route removed an original owner/alias")
    added_cells, added_nets = set(b["cells"]) - original_cells, set(b["netnames"]) - original_nets
    require(not any(cell["type"] == "MISTRAL_BUF" for cell in a["cells"].values()) and
            [name for name in b["cells"] if name in original_cells] == list(a["cells"]) and
            [name for name in b["netnames"] if name in original_nets] == list(a["netnames"]), "original route owner order or initial BUF population differs")
    old_drivers, old_users = tables.native_tables(a)
    new_drivers, new_users = tables.native_tables(b)
    expected_cells = copy.deepcopy(dict(a["cells"]))
    expected_drivers, expected_users = copy.deepcopy(old_drivers), copy.deepcopy(old_users)
    view = physical.PhysicalView(b)
    rows, used_ffs = [], set()
    for name in sorted(added_cells):
        cell = b["cells"][name]
        require(set(cell) == {"hide_name", "type", "parameters", "attributes", "port_directions", "connections"} and
                set(cell["attributes"]) == {"BEL_STRENGTH", "NEXTPNR_BEL", "FES_PINMAP_V1"} and
                cell["type"] == "MISTRAL_BUF" and cell["parameters"] == {} and
                cell["port_directions"] == {"A": "input", "Q": "output"} and set(cell["connections"]) == {"A", "Q"}, "undeclared route cell type/schema")
        q, bit = literal(cell, "Q"), literal(cell, "A")
        users = new_users.get(q)
        require(type(users) is list and len(users) == 1 and users[0][1:] == ("DATAIN", 0, 0), "BUF output is not one exact FF DATAIN slot")
        ff = users[0][0]
        alias = name + "$conn$Q"
        require(ff in original_cells and ff not in used_ffs and name == ff + "$ROUTETHRU" and
                a["cells"][ff]["type"] == "MISTRAL_FF" and expected_cells[ff]["connections"]["DATAIN"] == [bit] and
                new_drivers.get(q) == [(name, "Q", 0, 0)] and len(old_drivers.get(bit, [])) == 1 and
                alias in added_nets and view.native.aliases.get(q) == [(alias, 0)] and
                b["netnames"][alias]["bits"] == [q] and not view.native.top_users.get(q), "BUF forwarding owner/raw bit/private alias differs")
        shape = physical._shape(view, name)
        truth = physical._truth(shape)
        require(shape["type"] == "MISTRAL_BUF" and shape["tables"] == [2] and shape["inputs"][0]["state"] == 0 and
                shape["pins"] == {"A": [0, "D" if shape["half"] else "C"], "Q": [0, "COMBOUT"]} and
                truth["rows"] == [{"row": 0, "Q": 0}, {"row": 1, "Q": 1}], "BUF packed physical function is not identity")
        _, x, y, z = physical._location(cell)
        kind, fx, fy, fz = physical._location(b["cells"][ff])
        require(kind == "FF" and fz % 6 in (2, 4) and (x, y, z // 6, z % 6) == (fx, fy, fz // 6, (fz % 6 - 2) // 2),
                "BUF is not the exact named FF half feedthrough")
        physical.evaluate_lut(view, name)
        used_ffs.add(ff)
        expected_cells[ff]["connections"]["DATAIN"] = [q]
        require(q not in expected_drivers and (ff, "DATAIN", 0, 0) in expected_users[bit], "BUF ledger collision")
        expected_drivers[q] = [(name, "Q", 0, 0)]
        expected_users[bit].remove((ff, "DATAIN", 0, 0))
        expected_users[bit].append((name, "A", 0, 0))
        expected_users[q] = [(ff, "DATAIN", 0, 0)]
        rows.append({"buffer": name, "ff": ff, "alias": alias, "input_raw_bit": bit, "output_raw_bit": q,
                     "input_original_driver": list(old_drivers[bit][0]), "bel": cell["attributes"]["NEXTPNR_BEL"],
                     "actual_pins": shape["pins"], "physical_truth": truth})
    require(added_nets == {row["alias"] for row in rows} and len(added_cells) == len(rows), "route aliases exceed declared BUF outputs")
    require(expected_drivers == new_drivers and {bit: sorted(users) for bit, users in expected_users.items()} == new_users,
            "complete raw indexed driver/user slots differ beyond explicit BUF substitutions")
    for name, expected in expected_cells.items():
        actual = copy.deepcopy(b["cells"][name])
        require("FES_PINMAP_V1" not in expected["attributes"] and type(actual["attributes"].get("FES_PINMAP_V1")) is str,
                "fresh original routed physical pin map absent")
        actual["attributes"].pop("FES_PINMAP_V1")
        exact(native, expected, actual, "route original graph/INIT/attrs/BEL changed: " + name)
    for name, original in a["netnames"].items():
        exact(native, net_shape(original), net_shape(b["netnames"][name]), "route original alias metadata/raw bits changed: " + name)
    return {"buffer_rows": rows, "buffer_count": len(rows), "all_original_raw_slots_and_metadata_reconstructed_exactly": True,
            "generated_buffer_identity_function_proved": True, "blanket_buffer_collapse_used": False}, view


def ff_record(physical, view, name):
    _, x, y, z = physical._location(view.cells[name])
    state = view.labs[(x, y)][3][2 + 6 * (z // 6):8 + 6 * (z // 6)]
    return physical._ff(view, name, state)


def exported_lab_controls(physical, view, lab):
    selected, clears, clocks, sync = {}, {}, set(), {"SCLR": set(), "SLOAD": set()}
    rows = []
    for index in range(10):
        alm = physical.evaluate_alm(view, (*lab, index))
        halves = {}
        for ff in alm["ff_occupants"]:
            signature = {port: (tuple(row["driver"]) if row["driver"] else None, tuple(row["pins"]))
                         for port, row in ff["controls"].items()}
            half = ff["half"]
            require(half not in halves or halves[half] == signature, "one FF half has incompatible shared controls")
            halves[half] = signature
            clock_enable = signature["CLK"], signature["ENA"]
            clocks.add(signature["CLK"])
            ce = ff["clk_ena_selector"]
            require(type(ce) is int and 0 <= ce < 3 and type(ff["aclr_selector"]) is int and
                    0 <= ff["aclr_selector"] < 2, "FF selector outside physical slot range")
            require(ce not in selected or selected[ce] == clock_enable, "one LAB CLK/ENA selector has incompatible native controls")
            selected[ce] = clock_enable
            if ff["controls"]["ACLR"]["driver"] is not None:
                ac = ff["aclr_selector"]
                require(ac not in clears or clears[ac] == signature["ACLR"], "one LAB ACLR selector has incompatible native controls")
                clears[ac] = signature["ACLR"]
            for port in sync:
                if ff["controls"][port]["driver"] is not None:
                    sync[port].add(signature[port])
        rows.append(alm)
    require(len(clocks) <= 1 and len(selected) <= 3 and len(clears) <= 2 and all(len(values) <= 1 for values in sync.values()),
            "whole-LAB exported control capacity exceeded")
    return rows


def clock_enable_groups(native, alms):
    groups = {}
    for alm in alms:
        for ff in alm["ff_occupants"]:
            selector = ff["clk_ena_selector"]
            signature = {port: copy.deepcopy(ff["controls"][port]) for port in ("CLK", "ENA")}
            ena = signature["ENA"]
            require(bool(ena["bits"]) == (ena["driver"] is not None), "ENA connectedness/driver disagrees")
            if not ena["bits"]:
                require(ena["pins"][0] in (1, 2), "absent ENA is not an explicit constant physical pin")
            if selector in groups:
                exact(native, groups[selector]["signature"], signature, "one selector denotes differing full CLK/ENA signatures")
            else:
                groups[selector] = {"signature": signature, "members": []}
            groups[selector]["members"].append(ff["cell"])
    for group in groups.values():
        group["members"].sort()
    return groups


def control_group_renumbering(native, old_alms, new_alms, moved):
    old_groups, new_groups = [clock_enable_groups(native, alms) for alms in (old_alms, new_alms)]
    mapping, changed = {}, []
    for old_alm, new_alm in zip(old_alms, new_alms):
        old = {row["cell"]: row for row in old_alm["ff_occupants"] if row["cell"] not in moved}
        new = {row["cell"]: row for row in new_alm["ff_occupants"] if row["cell"] not in moved}
        require(set(old) == set(new), "affected unmoved FF owner set changed")
        for name in sorted(old):
            a, b = copy.deepcopy(old[name]), copy.deepcopy(new[name])
            previous, current = a.pop("clk_ena_selector"), b.pop("clk_ena_selector")
            exact(native, a, b, "unmoved FF changed beyond CLK/ENA selector numbering: " + name)
            require(previous not in mapping or mapping[previous] == current, "one prior unmoved logical group split across selectors")
            mapping[previous] = current
            if previous != current:
                changed.append({"cell": name, "old_selector": previous, "new_selector": current,
                                "unchanged_complete_ff_record_except_selector": a})
    require(len(set(mapping.values())) == len(mapping), "distinct prior unmoved groups merged under one selector")
    rows = []
    for previous, current in sorted(mapping.items()):
        a, b = old_groups[previous], new_groups[current]
        exact(native, a["signature"], b["signature"], "mapped whole-LAB logical CLK/ENA signature changed")
        old_members, new_members = sorted(set(a["members"]) - moved), sorted(set(b["members"]) - moved)
        require(old_members == new_members and old_members, "mapped whole-LAB unmoved membership changed")
        rows.append({"old_selector": previous, "new_selector": current, "signature": a["signature"],
                     "unmoved_members": old_members, "old_moved_members": sorted(set(a["members"]) & moved),
                     "new_moved_members": sorted(set(b["members"]) & moved)})
    old_unmapped = {selector: row for selector, row in old_groups.items() if selector not in mapping}
    new_unmapped = {selector: row for selector, row in new_groups.items() if selector not in mapping.values()}
    require(all(set(row["members"]) <= moved for row in [*old_unmapped.values(), *new_unmapped.values()]),
            "an unmapped control group contains an undeclared unmoved FF")
    return {"all_old_groups": old_groups, "all_new_groups": new_groups, "consistent_injective_mapping": rows,
            "all_changed_unmoved_ff_records": changed, "old_moved_only_groups": old_unmapped,
            "new_moved_only_groups": new_unmapped, "complete_exported_signatures_and_unmoved_membership_proved": True,
            "actual_selector_to_routed_wire_or_rbf_mux_mapping_independently_proved": False}


def saved_field_proof(native, a, b, moved):
    old, new = copy.deepcopy(a["saved_fields"]), copy.deepcopy(b["saved_fields"])
    require(set(old) == set(new) == {"l6_mode", "carry_mode", "clk_ena_indices", "aclr_indices", "lab_aclr_used"},
            "saved ALM/LAB field schema differs")
    old_ce, new_ce = old.pop("clk_ena_indices"), new.pop("clk_ena_indices")
    old_ac, new_ac = old.pop("aclr_indices"), new.pop("aclr_indices")
    exact(native, old, new, "affected L6/carry modes or whole-LAB ACLR-used flags changed")
    require(all(type(values) is list and len(values) == 2 for values in (old_ce, new_ce, old_ac, new_ac)) and
            all(type(value) is int and 0 <= value < 3 for values in (old_ce, new_ce) for value in values) and
            all(type(value) is int and 0 <= value < 2 for values in (old_ac, new_ac) for value in values), "saved selector array schema/range differs")
    rows = []
    for half in (0, 1):
        old_ffs = {row["cell"]: row for row in a["ff_occupants"] if row["half"] == half}
        new_ffs = {row["cell"]: row for row in b["ff_occupants"] if row["half"] == half}
        previous, current = set(old_ffs), set(new_ffs)
        require(previous - moved == current - moved and previous ^ current <= moved, "half occupancy changed beyond declared moved FFs")
        if not previous and not current:
            require(old_ce[half] == new_ce[half] and old_ac[half] == new_ac[half], "half empty in both frames changed CE/ACLR indices")
        if old_ac[half] != new_ac[half]:
            require(previous != current and previous | current <= moved and
                    all(not row["controls"]["ACLR"]["bits"] and row["controls"]["ACLR"]["driver"] is None and
                        row["controls"]["ACLR"]["pins"][0] in (1, 2) for row in [*old_ffs.values(), *new_ffs.values()]),
                    "ACLR index changed outside declared plain-FF occupancy initialization")
        if previous != current or old_ce[half] != new_ce[half] or old_ac[half] != new_ac[half]:
            rows.append({"alm": a["alm"], "half": half, "old_ff_members": sorted(previous), "new_ff_members": sorted(current),
                         "old_clk_ena_index": old_ce[half], "new_clk_ena_index": new_ce[half],
                         "old_aclr_index": old_ac[half], "new_aclr_index": new_ac[half],
                         "only_declared_plain_moved_ff_occupancy_changes": previous != current,
                         "aclr_change_is_unconsumed_plain_ff_half_initialization": old_ac[half] != new_ac[half]})
    return rows


def physical_proof(native, physical, before, after, placement, moved, old_ledger, new_ledger):
    require(before.device == after.device == "5CSEBA6U23I7" and set(before.labs) == set(after.labs), "physical device/LAB geometry differs")
    labs = set()
    for row in placement["ff_bel_changes"]:
        for view, key in ((before, "old_bel"), (after, "new_bel")):
            require(view.cells[row["cell"]]["attributes"]["NEXTPNR_BEL"] == row[key], "routed moved FF BEL differs from manifest")
            _, x, y, _ = physical._location(view.cells[row["cell"]])
            labs.add((x, y))
    moved_labs = sorted(labs)
    old_buffers = {row["buffer"]: row for row in old_ledger["buffer_rows"]}
    new_buffers = {row["buffer"]: row for row in new_ledger["buffer_rows"]}
    originals = set(before.cells) - set(old_buffers)
    require(originals == set(after.cells) - set(new_buffers) and len(originals) == 14893, "physical original owner set differs")
    moved_records, original_pin_count = [], 0
    for name in sorted(originals):
        a, b = before.cells[name], after.cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and a["port_directions"] == b["port_directions"], "original physical type/INIT/schema differs")
        exact(native, before.pins(name), after.pins(name), "original complete physical pin map changed: " + name)
        original_pin_count += 1
        if name in moved:
            require(a["parameters"] == {} and a["port_directions"] == FF_PORTS, "moved routed FF native schema differs")
            pins = after.pins(name)
            require(pins["DATAIN"] == [0, "DATAIN"] and pins["Q"] == [0, "Q"] and pins["CLK"] == [0, "CLK"] and
                    all(a["connections"][port] == b["connections"][port] == [] for port in ("ENA", "ACLR", "SCLR", "SLOAD", "SDATA")),
                    "moved FF pin edge/state or plain controls differ")
            for port in ("Q", "CLK"):
                require(a["connections"][port] == b["connections"][port], "moved FF original raw Q/CLK differs")
            aa, bb = ff_record(physical, before, name), ff_record(physical, after, name)
            exact(native, aa["controls"], bb["controls"], "moved FF complete logical clock/control semantics changed")
            moved_records.append({"cell": name, "before": aa, "after": bb, "data_forwarding_proved_in_explicit_route_ledgers": True})
        else:
            require(a["attributes"]["NEXTPNR_BEL"] == b["attributes"]["NEXTPNR_BEL"], "unmoved original routed BEL changed")
    require(len(moved_records) == 106, "complete moved routed FF physical record set differs")
    for first, second in placement["manifest_retained_pairs"]:
        require(after.pins(first)["CLK"] == after.pins(second)["CLK"] == [0, "CLK"] and
                after.cells[first]["connections"]["CLK"] == after.cells[second]["connections"]["CLK"], "routed pair actual clock/positive edge differs")
    changed_buffers = []
    for name in sorted(set(old_buffers) | set(new_buffers)):
        a, b = old_buffers.get(name), new_buffers.get(name)
        same = bool(a and b and a["bel"] == b["bel"] and
                    native.canonical(physical.evaluate_lut(before, name)["lut"]) == native.canonical(physical.evaluate_lut(after, name)["lut"]))
        if not same:
            for view in (before, after):
                if name in view.cells:
                    _, x, y, _ = physical._location(view.cells[name])
                    labs.add((x, y))
            changed_buffers.append({"buffer": name, "before_identity": a, "after_identity": b})
    inside, outside = [], 0
    for lab in sorted(before.labs):
        require(before.labs[lab][:3] == after.labs[lab][:3], "LAB geometry kind changed")
        if lab not in labs:
            exact(native, before.labs[lab], after.labs[lab], "unaffected exact exported LAB state changed")
            for index in range(10):
                exact(native, sorted(before.occupants.get((*lab, index), [])), sorted(after.occupants.get((*lab, index), [])), "outside exact ALM occupancy changed")
                outside += 1
            continue
        old_alms, new_alms = exported_lab_controls(physical, before, lab), exported_lab_controls(physical, after, lab)
        controls = control_group_renumbering(native, old_alms, new_alms, moved)
        saved_changes = []
        for a, b in zip(old_alms, new_alms):
            saved_changes.extend(saved_field_proof(native, a, b, moved))
            old_banks = {row["cell"]: row for row in a["occupied_banks"] if row["cell"] in originals}
            new_banks = {row["cell"]: row for row in b["occupied_banks"] if row["cell"] in originals}
            exact(native, old_banks, new_banks, "affected original combinational bank/shared-input function changed")
        inside.append({"lab": list(lab), "all_ten_alms_before": old_alms, "all_ten_alms_after": new_alms,
                       "explicit_logical_control_group_renumbering": controls, "explicit_half_occupancy_and_selector_changes": saved_changes})
    return {"exported_physical_function_scope_proved": True, "all_original_full_pin_maps_exact": original_pin_count,
            "moved_ff_whole_labs": [list(lab) for lab in moved_labs], "affected_whole_labs": [list(lab) for lab in sorted(labs)],
            "affected_whole_lab_records": inside, "outside_exact_alm_count": outside, "declared_moved_ff_records": moved_records,
            "explicit_changed_generated_buffers": changed_buffers, "all_generated_buffers_evaluated_as_identity": True,
            "whole_lab_modes_occupants_original_banks_shared_inputs_and_control_capacity_checked": True,
            "saved_l6_carry_and_lab_aclr_used_fields_exact": True, "halves_empty_in_both_frames_have_exact_ce_aclr_indices": True,
            "aclr_index_changes_only_declared_plain_ff_half_occupancy_initialization": True,
            "complete_placement_or_routing_legality_independently_proved": False,
            "unexported_pointer_cache_gpu_or_full_runtime_identity_proved": False, "route_mux_pip_cram_or_rbf_independently_decoded": False}


def paths(report):
    require(report.get("timing_report_paths") == 16384 and type(report.get("critical_paths")) is list and
            len(report["critical_paths"]) == 15290, "complete emitted path count/cap differs")
    windows, endpoints, worst = {}, set(), {}
    for path in report["critical_paths"]:
        pair, window = (path["from"], path["to"]), path["max_delay"]
        require(type(window) in (int, float) and math.isfinite(window) and window > 0 and
                (pair not in windows or windows[pair] == window), "pair window inconsistent/nonfinite")
        windows[pair] = window
        require(type(path["path"]) is list and path["path"], "empty complete timing path")
        end = path["path"][-1]["to"]
        endpoint = (*pair, end["cell"], end["port"])
        require(endpoint not in endpoints, "duplicate pair/endpoint")
        endpoints.add(endpoint)
        terms = [segment["delay"] for segment in path["path"]]
        require(all(type(term) in (int, float) and math.isfinite(term) for term in terms), "nonfinite emitted segment delay")
        total = math.fsum(terms)
        require(math.isfinite(total), "nonfinite complete path sum")
        if pair not in worst or total > worst[pair]["complete_delay_ns"]:
            worst[pair] = {"complete_delay_ns": total, "headroom_ns": window - total, "actual_worst_path": path}
    require(len(windows) == 7 and len(endpoints) == 15290, "seven domain pair/endpoint coverage differs")
    return windows, endpoints, worst


def timing_proof(tables, documents, reports, logs, placement):
    topologies = {name: tables.report_topology(documents[name], report, reports["baseline"]) for name, report in reports.items()}
    sets = {name: paths(report) for name, report in reports.items()}
    require(all(rows[:2] == sets["baseline"][:2] for rows in sets.values()), "complete native pair/endpoint/window coverage differs")
    require(all(set(report["fmax"]) == set(CONSTRAINTS) and all(report["fmax"][clock]["constraint"] == constraint
                for clock, constraint in CONSTRAINTS.items()) for report in reports.values()), "required clock constraints differ")
    clocks = {}
    for clock, constraint in CONSTRAINTS.items():
        for name, report in reports.items():
            row = report["fmax"][clock]
            require(set(row) == {"achieved", "constraint"} and type(row["achieved"]) in (int, float) and
                    math.isfinite(row["achieved"]) and row["achieved"] > 0, "invalid finite positive modeled clock Fmax")
        old, current = reports["baseline"]["fmax"][clock]["achieved"], reports["current"]["fmax"][clock]["achieved"]
        require(old == BASE_MHZ[clock], "pinned fresh main clock Fmax differs")
        clocks[clock] = {"fresh_main_mhz": old, "current_mhz": current, "gain_vs_fresh_main_mhz": current - old,
                         "constraint_mhz": constraint, "constraint_passed": current >= constraint}
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    require(target in sets["current"][0], "target full-cycle memory clock pair absent")
    windows, non_target_positive = [], True
    for pair, window in sorted(sets["current"][0].items()):
        row, old = sets["current"][2][pair], sets["baseline"][2][pair]
        positive_required = pair != target
        if positive_required:
            non_target_positive = non_target_positive and row["headroom_ns"] > 0
        windows.append({"from": pair[0], "to": pair[1], "window_ns": window, **row,
                        "fresh_main_headroom_ns": old["headroom_ns"], "headroom_change_ns": row["headroom_ns"] - old["headroom_ns"],
                        "positive_headroom_required": positive_required})
    pair_event_rows = []
    for name, report in reports.items():
        top = documents[name]["modules"]["top"]
        incoming = {}
        for path in report["critical_paths"]:
            terminal = path["path"][-1]["to"]
            incoming.setdefault((terminal["cell"], terminal["port"]), []).append(path)
        for row in placement["disjoint_pairs"]:
            for cell in (row["first"], row["second"]):
                emitted = incoming.get((cell, "DATAIN"), [])
                require(emitted, "declared moved FF incoming timing endpoint absent")
                for path in emitted:
                    launch, capture = tables.clock_event(path["from"], top), tables.clock_event(path["to"], top)
                    require(launch is not None and capture is not None and launch[0] == capture[0] == "posedge" and
                            launch[2] == capture[2] == [row["clock_raw_bit"]], "declared pipeline source/first/second actual clock or reported edge differs")
                pair_event_rows.append({"frame": name, "cell": cell, "clock_raw_bit": row["clock_raw_bit"],
                                        "all_emitted_incoming_paths_same_actual_clock_and_positive_edge": True})
    retained_pattern = r"^Info: Capture pipeline locality retained first=(\S+) second=(\S+); routing and signoff still required\.$"
    for name in ("selected", "current"):
        retained = re.findall(retained_pattern, logs[name], re.M)
        require(retained == [tuple(pair) for pair in placement["manifest_retained_pairs"]] and
                "eligible=64 retained_pairs=53 (route signoff still required)." in logs[name],
                "finished placement/route retained-pair log differs from fixed manifest")
    require("Capture pipeline locality retained first=" not in logs["disabled"], "disabled log retained a locality move")
    holds = {}
    for name in ("baseline", "current"):
        log = logs[name]
        require("Running signoff timing analysis..." in log and "Info: Program finished normally." in log and
                re.search(r"GPU router time [^\n]+backend hip:", log) and
                not any(line.startswith("ERROR:") for line in log.splitlines()), "completed native HIP route/signoff evidence absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        warnings = [line for line in last.splitlines() if "Hold/min time violation" in line or
                    re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        holds[name] = {"last_signoff_hold_warning_lines": warnings, "final_reported_hold_violations": bool(warnings)}
    require(not holds["baseline"]["final_reported_hold_violations"], "fixed baseline final reported hold gate failed")
    accepted = (clocks[MEMORY]["gain_vs_fresh_main_mhz"] > 0 and non_target_positive and
                all(clocks[clock]["constraint_passed"] for clock in (PIXEL, CAPTURE)) and
                not holds["current"]["final_reported_hold_violations"])
    return {"passes_practical_target_memory_clock_gate_vs_fresh_main": accepted, "clocks": clocks,
            "seven_pair_windows": windows, "all_six_non_target_windows_positive": non_target_positive,
            "final_signoff_hold_evidence": holds, "all_clock_nonregression_vs_fresh_main": all(row["gain_vs_fresh_main_mhz"] >= 0 for row in clocks.values()),
            "positive_non_target_margin_reduction_allowed_and_disclosed": True, "native_report_topologies": topologies,
            "all_declared_pipeline_incoming_actual_clock_and_reported_edge_records": pair_event_rows,
            "all_emitted_finite_complete_path_sums_checked": True, "complete_path_count": 15290,
            "gain_acceptance_conditional_on_target_gain_non_target_windows_clock_thresholds_and_final_holds": True,
            "old_path_delays_or_signoff_inherited": False, "independent_numerical_sta_or_unreported_pair_extrema_proved": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    parser.add_argument("--route-run-sha256", required=True)
    args = parser.parse_args()
    require(DIGEST.fullmatch(args.self_sha256) and sha(__file__) == args.self_sha256 and
            DIGEST.fullmatch(args.route_run_sha256) and args.route_run_sha256 == ROUTE_RUN_SHA and
            ROOT == EXPECTED_ROOT and HERE == RAW / "capture-pipeline-264", "actual self and finished route activation pins required")
    output = HERE / "proof-pipeline-search64.json"
    require(not output.exists() and not output.is_symlink(), "independent proof output already exists")
    native = load_pure(*HELPERS["native"], "pipeline_search64_native_pinned")
    audit = native.Audit()
    audit.bind(Path(__file__).resolve(), args.self_sha256)
    for path, digest in [*HELPERS.values(), *STATIC_REFERENCES]:
        audit.bind(path, digest)
    freezer = types.ModuleType("pipeline_search64_isolated_freeze")
    freezer.require = require
    tables = load_pure(*HELPERS["tables"], "pipeline_search64_tables_pinned", freezer)
    physical = load_pure(*HELPERS["physical"], "pipeline_search64_physical_pinned")
    runs, records, profiles, closure, manifest = authenticate_records(audit, args.route_run_sha256)
    documents, reports, logs = {}, {}, {}
    for name, (folder, _) in runs.items():
        routed = name in {"baseline", "current"}
        documents[name] = native.read_netlist(folder / ("routed.json" if routed else "placed.json"))
        reports[name] = read(folder / "timing.json")
        log_name = "route.log" if name == "baseline" else "placement.log" if name == "baseline_place" else "trial.log"
        logs[name] = (folder / log_name).read_text()
    placement, moved = prove_placement(native, tables, physical, documents, reports, manifest)
    old_ledger, old_view = route_ledger(native, tables, physical, documents["baseline_place"], documents["baseline"])
    new_ledger, new_view = route_ledger(native, tables, physical, documents["selected"], documents["current"])
    exact(native, documents["baseline"]["modules"]["top"]["settings"], documents["current"]["modules"]["top"]["settings"], "matched routed settings/defaults changed")
    exported_physical = physical_proof(native, physical, old_view, new_view, placement, moved, old_ledger, new_ledger)
    reported_timing = timing_proof(tables, documents, reports, logs, placement)
    accepted = reported_timing["passes_practical_target_memory_clock_gate_vs_fresh_main"]
    audit.finish()
    result = {
        "schema": 1,
        "scope": "fixed search64 experimental ELF, fifty-three disjoint existing two-FF relocations, matched fresh main baseline",
        "source_root": str(SOURCE), "compiler_elf_sha256": CURRENT_BINARY_SHA, "compiled_commit_asserted": False,
        "self_sha256": args.self_sha256, "finished_route_run_sha256": args.route_run_sha256,
        "native_physical_equivalence_proved": True, "gain_accepted_against_matched_main_baseline": accepted,
        "memory_130_mhz_closed": reported_timing["clocks"][MEMORY]["constraint_passed"],
        "placement_native_proof": placement, "baseline_explicit_route_buffer_ledger": old_ledger,
        "current_explicit_route_buffer_ledger": new_ledger, "exported_physical_proof": exported_physical,
        "reported_timing_proof": reported_timing, "completed_record_closure": closure,
        "artifact_sha256": audit.artifacts, "directly_rehashed_source_or_compiler_sha256": audit.execution,
        "pinned_pure_helper_sha256": {str(path): digest for path, digest in HELPERS.values()},
        "static_reference_files_not_imported_or_executed": {str(path): digest for path, digest in STATIC_REFERENCES},
        "old_operational_main_authentication_generator_or_aggregate_evaluator_executed": False,
        "initial_13b_elf_or_historical_source_archive_required_or_executed": False,
        "source_to_elf_independent_reproducibility_proved": False,
        "independent_live_pointer_cache_gpu_or_full_runtime_identity_proved": False,
        "independent_numerical_sta_proved": False, "complete_placement_routing_or_device_legality_proved": False,
        "cram_or_rbf_independently_decoded": False, "hardware_tested": False,
        "default_recipe_publication_binary_or_deployment_qualification_claimed": False,
        "frozen_117_869_stack_qualification_inherited": False,
        "limitations": [
            "Physical claims use exported whole-LAB/pin snapshots and packed truth; complete placement/routing/device legality still relies on compiler checks.",
            "Only declared plain-FF occupancy changes may initialize an unconsumed half ACLR index; empty-in-both halves, L6/carry modes and LAB ACLR-used flags are exact.",
            "Unmoved FF control records and complete exported CLK/ENA signatures/memberships prove consistent injective selector renumbering; moved-only groups are scoped to the manifest and moved controls are checked separately.",
            "The actual selector-to-routed-wire reservation table and route mux/pip/CRAM/RBF bytes are not independently decoded.",
            "Exact serialized raw consumer slots do not prove live indexed-store allocation, pointers, caches, GPU IDs or full runtime identity.",
            "All emitted finite complete paths and final reported holds are checked without independently recomputing numerical STA or extrema for unreported clock pairs.",
            "Live source/model/ELF inventories and recorder before/after snapshots bind selected bytes; they do not independently reproduce source-to-ELF compilation or assert a compiled commit.",
            "These explicit measured options do not qualify a current default recipe, publication binary, device deployment or hardware, and do not inherit the older 117.869 MHz stack."]
    }
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"proof": str(output), "proof_sha256": sha(output), "native_physical_equivalence_proved": True,
                      "matched_baseline_gain_accepted": accepted,
                      "memory_gain_vs_fresh_main_mhz": reported_timing["clocks"][MEMORY]["gain_vs_fresh_main_mhz"]}, sort_keys=True))


if __name__ == "__main__":
    main()
