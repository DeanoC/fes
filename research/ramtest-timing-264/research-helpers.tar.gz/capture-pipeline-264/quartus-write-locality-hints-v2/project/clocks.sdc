# 50 MHz reference, video PLL, and selected memory/capture PLL clocks.
# Cross-domain button and reset bits are synchronised.
create_clock -name FPGA_CLK1_50 -period 20.000 [get_ports {FPGA_CLK1_50}]
derive_pll_clocks
set_clock_groups -asynchronous \
    -group [get_clocks FPGA_CLK1_50] \
    -group [get_clocks {video_clock|pll|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] \
    -group [get_clocks {ram_clock|pll|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] \
    -group [get_clocks {ram_clock|pll|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] \
    -group [get_clocks {ram_clock|pll|general[2].gpll~PLL_OUTPUT_COUNTER|divclk}]
