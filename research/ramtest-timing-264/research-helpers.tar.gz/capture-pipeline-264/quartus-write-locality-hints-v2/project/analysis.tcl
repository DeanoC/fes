project_open top
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist
report_timing -setup -npaths 20 -nworst 1 -detail full_path -show_routing -file ../worst-paths.rpt
report_timing -setup -through [get_pins -hierarchical {*f2sdram*cmd_ready_1}] -to [get_registers {*port1*skid_address*}] -npaths 20 -detail full_path -show_routing -file ../ready1-skid-address.rpt
report_timing -setup -through [get_pins -hierarchical {*f2sdram*cmd_ready_1}] -npaths 20 -detail full_path -show_routing -file ../ready1-all.rpt
project_close
