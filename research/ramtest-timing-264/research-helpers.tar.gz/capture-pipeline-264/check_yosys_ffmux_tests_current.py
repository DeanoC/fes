#!/usr/bin/env python3
"""Run fixed tests against the closed Yosys build, recording a separate test environment."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
HELPER = HERE / 'check_yosys_ffmux.py'
HELPER_SHA = 'd02c48d9e950b5b7478b7c5b0cbb73486246178d23cd7e3a2d893388e8ffc0b4'
CONFIG = HERE / 'yosys-ffmux-check-configure-v1/record.json'
CONFIG_SHA = '6222b5b3c94ef8d5f57006110025610c03c65350992e3f84e2a3d610c76d1877'
BUILT = HERE / 'yosys-ffmux-check-build-v1/record.json'
BUILT_SHA = 'cc6c95b085bf01303cca97d08864ea84614c3c91128ca2e43ea7087b38577533'
BUILD_ENV_SHA = 'c5855cb6e17ee01d776bf04e95ae045287eda57ab76b058d5db0841d4fb7fa41'
TESTS = {'ffmux': 'ffmux.ys', 'dffs': 'dffs.ys', 'adffs': 'adffs.ys', 'fsm-init': 'fsm_init.ys'}
FIXTURES = ('tests/arch/intel_alm/ffmux.v', 'tests/arch/intel_alm/ffmux.ys',
            'tests/arch/intel_alm/dffs.ys', 'tests/arch/intel_alm/adffs.ys',
            'tests/arch/intel_alm/fsm_init.ys', 'tests/arch/common/dffs.v', 'tests/arch/common/adffs.v')
ENV = {k: v for k, v in os.environ.items() if k in {
    'PATH', 'HOME', 'TMPDIR', 'LD_LIBRARY_PATH', 'CMAKE_PREFIX_PATH', 'PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR'}}
ENV.update(LANG='C', LC_ALL='C')

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load_helper():
    require(sha(HELPER) == HELPER_SHA, 'reviewed build helper changed')
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('yosys_ffmux_readonly_inputs', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    require(helper.ENV == ENV, 'readonly helper/test environment differs')
    return helper  # Only inputs() and its read-only dependencies are called; old main never runs.

def authenticate(helper, expected):
    require(sha(CONFIG) == CONFIG_SHA and sha(BUILT) == BUILT_SHA, 'closed configure/build record changed')
    config, built = json.loads(CONFIG.read_text()), json.loads(BUILT.read_text())
    selected = helper.inputs()
    paths = {str(HELPER): HELPER_SHA, str(Path(__file__).resolve()): expected,
             str(CONFIG): CONFIG_SHA, str(BUILT): BUILT_SHA}
    for stage, record, path in (('configure', config, CONFIG), ('build', built, BUILT)):
        require(record['schema'] == 'yosys-ffmux-build-check-v1' and record['stage'] == stage and
                record['state'] == 'passed' and record['exit_code'] == 0 and record['completed_normally'] is True and
                record['inputs_unchanged'] is True and record['inputs_before'] == record['inputs_after'] == selected and
                record['recorder_sha256'] == record['recorder_after_sha256'] == HELPER_SHA and
                record['command'] == helper.COMMANDS[stage] and record['cwd'] == str(helper.SOURCE) and
                record['environment_sha256'] == BUILD_ENV_SHA and record['tests_run'] is False and
                all(record[key] is False for key in ('compiled_commit_asserted', 'gain_qualified', 'hardware')),
                'closed configure/build closure or claims differ')
        paths[str(path.parent / 'output.log')] = record['log_sha256']
    require(config['environment_keys'] == built['environment_keys'], 'archived environment keys differ')
    cache, binding = helper.BUILD / 'CMakeCache.txt', helper.BUILD / 'ffmux-configure-binding.json'
    require(config['cache_sha256'] == built['cache_sha256'] == sha(cache) and
            config['configure_binding_sha256'] == built['configure_binding_sha256'] == sha(binding), 'cache/binding differs')
    expected_binding = {'recorder_sha256': HELPER_SHA, 'inputs': selected, 'command': helper.COMMANDS['configure'],
                        'environment_sha256': BUILD_ENV_SHA, 'cache_sha256': sha(cache)}
    require(json.loads(binding.read_text()) == expected_binding, 'successful configure binding differs')
    runtime = {'executables': {name: sha(helper.BUILD / name) for name in ('yosys', 'yosys-abc')},
               'share_files': {str(p.relative_to(helper.BUILD)): sha(p) for p in sorted((helper.BUILD / 'share').rglob('*')) if p.is_file()},
               'build_shared_libraries': {str(p.relative_to(helper.BUILD)): sha(p) for p in sorted(helper.BUILD.rglob('*.so*')) if p.is_file()}}
    for key, files in runtime.items():
        require(files == built[key], 'build runtime inventory differs: ' + key)
        paths.update({str(helper.BUILD / name): digest for name, digest in files.items()})
    paths.update({str(cache): built['cache_sha256'], str(binding): built['configure_binding_sha256']})
    require(all(sha(name) == digest for name, digest in paths.items()), 'bound build artifacts/logs changed')
    fixtures = {name: {'sha256': sha(helper.SOURCE / name),
                      'symlink': os.readlink(helper.SOURCE / name) if (helper.SOURCE / name).is_symlink() else None} for name in FIXTURES}
    return {'inputs': selected, 'runtime': runtime, 'artifact_sha256': paths, 'fixture_sha256': fixtures,
            'build_environment_keys': built['environment_keys'], 'build_environment_sha256': BUILD_ENV_SHA}

def write(path, document):
    temporary = path.with_suffix('.pending')
    with temporary.open('x') as stream:
        stream.write(json.dumps(document, sort_keys=True, indent=2) + '\n')
    temporary.replace(path)

def main():
    require(len(sys.argv) == 4 and sys.argv[1] in TESTS, 'usage: ffmux|dffs|adffs|fsm-init NEW_LABEL SCRIPT_SHA256')
    stage, label, expected = sys.argv[1:]
    require(re.fullmatch('[0-9a-f]{64}', expected) and sha(__file__) == expected and label and
            all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label), 'self pin/label differs')
    directory = HERE / ('yosys-ffmux-test-current-' + label); directory.mkdir(exist_ok=False)
    record, log = directory / 'record.json', directory / 'output.log'; started = time.monotonic()
    env_sha = hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest()
    document = {'schema': 'yosys-ffmux-test-current-v1', 'test': stage, 'state': 'running', 'exit_code': None,
                'recorder_sha256': expected, 'completed_normally': False, 'tests_run': False,
                'test_environment_keys': sorted(ENV), 'test_environment_sha256': env_sha,
                'build_environment_sha256': BUILD_ENV_SHA, 'test_environment_equals_build': env_sha == BUILD_ENV_SHA,
                'same_environment_claimed': False, 'source_and_build_unchanged': False,
                'cleared_diagnostic_keys': sorted(k for k in os.environ if k.startswith('NEXTPNR_')),
                'configure_or_build_executed': False, 'compiled_commit_asserted': False, 'gain_qualified': False, 'hardware': False}
    write(record, document); print(json.dumps({'test': stage, 'state': 'running', 'record': str(record)}), flush=True)
    try:
        helper = load_helper(); before = authenticate(helper, expected); document['before'] = before
        command, cwd = [str(helper.BUILD / 'yosys'), '-s', TESTS[stage]], helper.SOURCE / 'tests/arch/intel_alm'
        require(Path(command[0]).is_absolute(), 'Yosys executable must be absolute')
        document.update(command=command, cwd=str(cwd), build_environment_keys=before['build_environment_keys'])
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=cwd, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        document.update(exit_code=result.returncode, completed_normally=True, tests_run=True)
        after = authenticate(helper, expected); document['after'] = after
        require(after == before and sha(__file__) == expected, 'source/submodules/runtime/cache/logs/fixtures changed')
        document['source_and_build_unchanged'] = True
        document['state'] = 'passed' if result.returncode == 0 else 'failed'
    except BaseException as error:
        document.update(state='failed', error_type=type(error).__name__, error=str(error))
    finally:
        document['elapsed_seconds'] = time.monotonic() - started
        document['log_sha256'] = sha(log) if log.is_file() else None; document['recorder_after_sha256'] = sha(__file__)
        write(record, document)
        print(json.dumps({'test': stage, 'state': document['state'], 'exit_code': document['exit_code'],
                          'record_sha256': sha(record), 'elapsed_seconds': document['elapsed_seconds']}), flush=True)
    return 0 if document['state'] == 'passed' else 1

if __name__ == '__main__':
    sys.exit(main())
