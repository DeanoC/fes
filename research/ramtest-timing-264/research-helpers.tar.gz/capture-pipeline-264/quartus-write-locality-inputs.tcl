# Root-only retained-fit input query; no synthesis, fit, routing or hardware.
# Usage: quartus_sta -t quartus-write-locality-inputs.tcl private-project/top.qpf new-output
# Static reference: quartus-write-locality-hint.tcl SHA-256
# b9db594b55af892bc266ea8756c028abab6348b58db0fda50e42d1e4c6610a27.
# Root authenticates the copied project, runtime, new script and before/after trees.
# BUILD_ID52991 differs from OSS7168; output is mapping/locality hints only.
if {[llength $quartus(args)] != 2} {error "Expected authenticated private project.qpf and nonexistent output directory"}
set project [file normalize [lindex $quartus(args) 0]]
set output [file normalize [lindex $quartus(args) 1]]
if {[file exists $output]} {error "Refusing existing output directory: $output"}
set qsf_file [open [file rootname $project].qsf r]
set qsf_text [read $qsf_file]
close $qsf_file
set observed_build_id MISSING
regexp {RAMTEST_BUILD_ID=128'h([0-9a-fA-F]{32})} $qsf_text ignored observed_build_id
if {[string tolower $observed_build_id] != "52991ce22369904849b68bdd900f9ae1"} {error "Unexpected retained-fit BUILD_ID: $observed_build_id"}
foreach relative {top.qpf top.qsf clocks.sdc db/top.cmp.hdb db/top.routing.rdb db/top.sta_cmp.7_slow_1100mv_100c.tdb} {
    set path [file join [file dirname $project] $relative]
    if {![file isfile $path] || [file size $path] == 0} {error "Missing or empty fitted input: $relative"}
}
file mkdir $output
set identity [open [file join $output identity.txt] {WRONLY CREAT EXCL}]
puts $identity "script [file normalize [info script]]"
puts $identity "static_reference_sha256 b9db594b55af892bc266ea8756c028abab6348b58db0fda50e42d1e4c6610a27"
puts $identity "project $project"
puts $identity "quartus_build_id $observed_build_id"
puts $identity "oss_build_id 7168b508ab424b70f1c0f87b2035d821"
puts $identity "classification retained-fit mapping/locality hints only; different BUILD_ID; clocks/SDC/models not independently matched; no exact-input timing calibration or acceptance"
puts $identity "source_mapping exact full native bank-register name and actual native host cell object; cell names are diagnostic only; no prefix normalization or inferred RTL bit indices"
puts $identity "scope named original banks plus explicit copy-inclusive group; at most16 deduplicated native cells and128 actual nonclock input pin queries; npaths8/check/query; not exhaustive signoff"
puts $identity "native_api_contract get_node_info -cell returns host cell; get_cell_info -in_pins returns input-pin collection; get_pin_info -parent_cell must equal actual selected cell"
puts $identity "installed_help /home/deano/intelFPGA_lite/17.0/quartus/common/tcl/internal/init/sta.cmds.hlp"
puts $identity "model slow temperature_C100 voltage_mV1100; setup/hold only; unavailable or empty properties and zero paths are not a pass"
if {[info exists quartus(version)]} {puts $identity "quartus_version $quartus(version)"}
close $identity

proc tsv {values} {
    set escaped {}
    foreach value $values {lappend escaped [string map [list "\\" "\\\\" "\t" "\\t" "\n" "\\n" "\r" "\\r"] $value]}
    return [join $escaped \t]
}
proc property {command} {
    if {[catch {uplevel #0 $command} value]} {return [list unavailable_error $value]}
    if {$value == ""} {return [list empty_or_unavailable {}]}
    return [list available $value]
}
proc actual_boolean {value} {
    return [expr {[lindex $value 0] == "available" && [string is boolean -strict [lindex $value 1]]}]
}
proc resolve_registers {names} {
    global bank_names
    set patterns {}
    foreach name $names {lappend patterns [string map [list "\[" "?" "\]" "?"] $name]}
    set result [get_registers $patterns]
    set actual {}
    foreach_in_collection reg $result {
        set name [get_register_info -name $reg]
        if {![dict exists $bank_names $name] || [dict get $bank_names $name] ne $reg} {
            error "Re-resolved full register name has a different native register ID: $name"
        }
        lappend actual $name
    }
    if {[lsort -unique $actual] != [lsort -unique $names]} {error "Full native register names did not re-resolve exactly: $names"}
    return $result
}
proc resolve_actual_pin {pin name cell} {
    # This is only a collection lookup pattern. Before use, the returned full
    # name, native pin ID and native parent ID must all equal the actual objects.
    set pattern [string map [list "\[" "?" "\]" "?"] $name]
    set result [get_pins -compatibility_mode [list $pattern]]
    if {[get_collection_size $result] != 1} {error "Actual pin did not re-resolve uniquely: $pin $name"}
    foreach_in_collection resolved $result {
        if {$resolved ne $pin || [get_pin_info -name $resolved] ne $name ||
            [get_pin_info -parent_cell $resolved] ne $cell} {
            error "Exact native pin/name/parent identity differs: $pin $name $cell"
        }
    }
    return $result
}
proc retain_actual_source {label check ordinal node} {
    global bank_names selected_sources selected_cells path_properties unresolved_sources
    set node_name [property [list get_node_info -name $node]]
    set node_type [property [list get_node_info -type $node]]
    if {[lindex $node_name 0] != "available" || [lindex $node_type 0] != "available" ||
        [lindex $node_type 1] != "reg" || ![dict exists $bank_names [lindex $node_name 1]]} {
        incr unresolved_sources
        puts $path_properties [tsv [list $label $check $ordinal from full_bank_owner unresolved_no_exact_full_native_register [lindex $node_name 1]]]
        return
    }
    # Resolve the full bank-register owner before retaining its native cell.
    # get_cell_info -name can omit type prefixes inside the hierarchy and is
    # therefore never used to select or normalize an owner.
    set owner [lindex $node_name 1]
    set register [dict get $bank_names $owner]
    set register_name [property [list get_register_info -name $register]]
    set cell [property [list get_node_info -cell $node]]
    set register_cell [property [list get_node_info -cell $register]]
    if {[lindex $register_name 0] != "available" || [lindex $register_name 1] != $owner ||
        [lindex $cell 0] != "available" || [lindex $register_cell 0] != "available" ||
        [lindex $cell 1] ne [lindex $register_cell 1]} {
        incr unresolved_sources
        puts $path_properties [tsv [list $label $check $ordinal from full_bank_owner unresolved_native_register_cell_identity $owner]]
        puts $path_properties [tsv [list $label $check $ordinal from actual_host_cell {*}$cell]]
        puts $path_properties [tsv [list $label $check $ordinal from named_register_host_cell {*}$register_cell]]
        return
    }
    set native_cell [lindex $cell 1]
    set cell_type [property [list get_cell_info -type $native_cell]]
    set cell_name [property [list get_cell_info -name $native_cell]]
    puts $path_properties [tsv [list $label $check $ordinal from actual_host_cell {*}$cell]]
    puts $path_properties [tsv [list $label $check $ordinal from host_cell_type {*}$cell_type]]
    puts $path_properties [tsv [list $label $check $ordinal from diagnostic_host_cell_name {*}$cell_name]]
    if {[lindex $cell_type 0] != "available" || [lindex $cell_type 1] != "cell"} {
        incr unresolved_sources
        puts $path_properties [tsv [list $label $check $ordinal from full_bank_owner unresolved_native_cell_type $owner]]
        return
    }
    if {[dict exists $selected_sources $owner] && [dict get $selected_sources $owner] ne $native_cell} {
        error "One exact bank-register owner resolved to multiple native cells: $owner"
    }
    if {![dict exists $selected_cells $native_cell] && [dict size $selected_cells] >= 16} {
        error "Actual deduplicated native source cell inventory exceeds16"
    }
    dict set selected_sources $owner $native_cell
    if {[dict exists $selected_cells $native_cell]} {
        set row [dict get $selected_cells $native_cell]
        dict set row owners [lsort -unique [concat [dict get $row owners] [list $owner]]]
        dict set row launch_nodes [lsort -unique [concat [dict get $row launch_nodes] [list $node]]]
        dict set selected_cells $native_cell $row
    } else {
        dict set selected_cells $native_cell [dict create owners [list $owner] launch_nodes [list $node] diagnostic_name $cell_name]
    }
    puts $path_properties [tsv [list $label $check $ordinal from resolved_full_bank_owner available $owner]]
    puts $path_properties [tsv [list $label $check $ordinal from resolved_native_bank_register available $register]]
    puts $path_properties [tsv [list $label $check $ordinal from retained_actual_native_cell available $native_cell]]
}
proc query {label options} {
    global output reports path_properties zero_path_queries
    foreach check {setup hold} {
        set filename "$label-$check.rpt"
        set argv [concat [list -$check] $options [list -npaths 8 -detail full_path -show_routing]]
        set result [report_timing {*}$argv -file [file join $output $filename]]
        set paths [get_timing_paths {*}$argv]
        set status native_paths_retained_hint_only
        if {[get_collection_size $paths] == 0} {set status native_no_path_not_a_pass; incr zero_path_queries}
        puts $reports [tsv [list $label $check $filename $result [get_collection_size $paths] $status]]
        set ordinal 0
        foreach_in_collection path $paths {
            incr ordinal
            foreach option {-from -to -from_clock -to_clock -from_clock_is_inverted -to_clock_is_inverted -slack -clock_relationship -clock_skew -data_delay -num_logic_levels} {
                set value [property [list get_path_info $option $path]]
                puts $path_properties [tsv [list $label $check $ordinal path $option {*}$value]]
            }
            foreach endpoint {from to} {
                set node [get_path_info -$endpoint $path]
                if {$node == ""} {
                    puts $path_properties [tsv [list $label $check $ordinal $endpoint node empty_or_unavailable {}]]
                    continue
                }
                puts $path_properties [tsv [list $label $check $ordinal $endpoint actual_node_id available $node]]
                foreach option {-name -type -location -cell} {
                    set value [property [list get_node_info $option $node]]
                    puts $path_properties [tsv [list $label $check $ordinal $endpoint $option {*}$value]]
                }
                if {$endpoint == "from" && ([string match "bank-*" $label] || $label == "hard-unrestricted")} {
                    retain_actual_source $label $check $ordinal $node
                }
            }
        }
    }
}

cd [file dirname $project]
project_open [file rootname [file tail $project]]
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist
set registers [get_registers {*hps_ddr*}]
set bank_file [open [file join $output bank-registers.tsv] {WRONLY CREAT EXCL}]
puts $bank_file "id\tname\trole\tlocation_state\tlocation\tfanout_edges_state\tnative_fanout_edges"
set bank_names [dict create]
set originals {}
foreach_in_collection reg $registers {
    set name [get_register_info -name $reg]
    set signal {}
    set suffix {}
    if {![regexp {\|(m0_writedata|m_writedata)\[[0-9]+\](~[^|]+)?$} $name ignored signal suffix]} {continue}
    if {$signal == "m_writedata" && ![regexp {\|fes_hps_ddr_guard:port0\|} $name]} {continue}
    if {[dict exists $bank_names $name] && [dict get $bank_names $name] ne $reg} {error "Duplicate full bank-register name with distinct native IDs: $name"}
    set role named_original
    if {$suffix == ""} {lappend originals $name} else {set role named_fitter_copy}
    dict set bank_names $name $reg
    set location [property [list get_node_info -location $reg]]
    set fanout [property [list get_register_info -fanout_edges $reg]]
    puts $bank_file [tsv [list $reg $name $role {*}$location {*}$fanout]]
}
close $bank_file
set originals [lsort -unique $originals]
if {![llength $originals] || [dict size $bank_names] > 1024} {project_close; error "Named original bank absent or exceeds1024; inspect bank-registers.tsv"}
set hard_pin_file [open [file join $output hard-pins.tsv] {WRONLY CREAT EXCL}]
puts $hard_pin_file "id\tname\trole\tparent_state\tparent_id\tinput_state\tinput_value\tclock_state\tclock_value"
set hard_targets {}
set hard_pins [get_pins -compatibility_mode {*f2sdram*}]
if {[get_collection_size $hard_pins] > 4096} {close $hard_pin_file; project_close; error "Hard-IP pin inventory exceeds4096"}
foreach_in_collection pin $hard_pins {
    set name [get_pin_info -name $pin]
    set parent [property [list get_pin_info -parent_cell $pin]]
    set input [property [list get_pin_info -is_in_pin $pin]]
    set clock [property [list get_pin_info -is_clock_pin $pin]]
    set role inventoried_not_selected
    if {[regexp -nocase {\|wr_data_1\[19\]$} $name]} {
        set role named_target_pin
        if {![actual_boolean $input] || ![lindex $input 1] || ![actual_boolean $clock] ||
            [lindex $clock 1] || [lindex $parent 0] != "available"} {
            puts $hard_pin_file [tsv [list $pin $name unresolved_target_not_a_pass {*}$parent {*}$input {*}$clock]]
            close $hard_pin_file; project_close; error "Named hard input cannot be classified by native IDs/flags: $name"
        }
        lappend hard_targets [list $pin $name [lindex $parent 1]]
    }
    puts $hard_pin_file [tsv [list $pin $name $role {*}$parent {*}$input {*}$clock]]
}
close $hard_pin_file
if {[llength $hard_targets] != 1} {project_close; error "No unique actual wr_data_1 pin19; inspect hard-pins.tsv before changing a query"}
lassign [lindex $hard_targets 0] hard_pin hard_name hard_cell
set destination [resolve_actual_pin $hard_pin $hard_name $hard_cell]
set reports [open [file join $output reports.tsv] {WRONLY CREAT EXCL}]
set path_properties [open [file join $output path-properties.tsv] {WRONLY CREAT EXCL}]
puts $reports "label\tcheck\tfile\tnative_result\tnative_path_count\tstatus"
puts $path_properties "label\tcheck\tpath_ordinal\tobject\toption\tstate\tvalue"
set selected_sources [dict create]
set selected_cells [dict create]
set unresolved_sources 0
set unresolved_cells 0
set unresolved_pins 0
set zero_path_queries 0
query bank-originals [list -from [resolve_registers $originals] -to $destination]
query bank-with-copies [list -from [resolve_registers [dict keys $bank_names]] -to $destination]
# An unmatched native launch remains visible without a naming filter. It is
# recorded as unresolved and cannot create a selected source cell.
query hard-unrestricted [list -to $destination]
set selected_file [open [file join $output actual-launch-registers.tsv] {WRONLY CREAT EXCL}]
puts $selected_file "full_native_name\tregister_id\tactual_native_cell_id\tselection"
foreach name [lsort [dict keys $selected_sources]] {
    puts $selected_file [tsv [list $name [dict get $bank_names $name] [dict get $selected_sources $name] exact_full_native_register_and_host_cell]]
}
close $selected_file
set cells_file [open [file join $output actual-launch-cells.tsv] {WRONLY CREAT EXCL}]
puts $cells_file "actual_native_cell_id\tfull_bank_owners\tlaunch_node_ids\tcell_name_state\tcell_name\tlocation_state\tlocation\tinput_collection_state\tinput_collection\tinput_count\tstatus"
set inputs [open [file join $output actual-launch-pins.tsv] {WRONLY CREAT EXCL}]
puts $inputs "id\tname_state\tname\tfull_bank_owners\tactual_native_cell_id\tparent_state\tparent_id\trole\ttype_state\ttype_value\tinput_state\tinput_value\tclock_state\tclock_value\tlookup_state\tlookup_value\tquery_label"
set seen_pins [dict create]
set nonclock_inventory_count 0
set ordinal 0
foreach cell [lsort [dict keys $selected_cells]] {
    set row [dict get $selected_cells $cell]
    set owners [dict get $row owners]
    set cell_name [dict get $row diagnostic_name]
    set location [property [list get_cell_info -location $cell]]
    set collection [property [list get_cell_info -in_pins $cell]]
    set count unavailable
    set status actual_native_input_collection
    if {[lindex $collection 0] != "available"} {
        set status unavailable_native_inputs_not_a_pass
        incr unresolved_cells
    } elseif {[catch {get_collection_size [lindex $collection 1]} count_error]} {
        set status invalid_native_input_collection_not_a_pass
        set count $count_error
        incr unresolved_cells
    } else {
        set count $count_error
        if {$count == 0} {set status empty_native_input_collection_not_a_pass; incr unresolved_cells}
    }
    puts $cells_file [tsv [list $cell $owners [dict get $row launch_nodes] {*}$cell_name {*}$location {*}$collection $count $status]]
    if {$status != "actual_native_input_collection"} {continue}
    foreach_in_collection pin [lindex $collection 1] {
        set pin_name [property [list get_pin_info -name $pin]]
        set parent [property [list get_pin_info -parent_cell $pin]]
        set type [property [list get_pin_info -type $pin]]
        set input [property [list get_pin_info -is_in_pin $pin]]
        set clock [property [list get_pin_info -is_clock_pin $pin]]
        set lookup [list not_queried {}]
        set query_label {}
        set role unavailable_native_pin_identity_or_flags_not_a_pass
        if {[lindex $pin_name 0] != "available" || [lindex $parent 0] != "available" ||
            [lindex $parent 1] ne $cell || [lindex $type 0] != "available" ||
            [lindex $type 1] != "pin" || ![actual_boolean $input] || ![actual_boolean $clock]} {
            incr unresolved_pins
        } elseif {![lindex $input 1]} {
            set role native_in_pin_collection_noninput_not_a_pass
            incr unresolved_pins
        } elseif {[dict exists $seen_pins $pin]} {
            if {[dict get $seen_pins $pin] ne $cell} {error "One native pin appeared under distinct native cells: $pin"}
            set role duplicate_native_pin_not_requeried
        } else {
            dict set seen_pins $pin $cell
            if {[lindex $clock 1]} {
                set role actual_clock_input_not_queried
            } else {
                incr nonclock_inventory_count
                if {$nonclock_inventory_count > 128} {error "Actual deduplicated nonclock input pin inventory exceeds128"}
                set name [lindex $pin_name 1]
                if {[catch {resolve_actual_pin $pin $name $cell} actual_collection]} {
                    set role unresolved_exact_native_pin_collection_not_a_pass
                    set lookup [list unavailable_error $actual_collection]
                    incr unresolved_pins
                } else {
                    incr ordinal
                    if {$ordinal > 128} {error "Actual deduplicated nonclock input query inventory exceeds128"}
                    set role queried_exact_actual_nonclock_input
                    set lookup [list exact_native_pin_name_and_parent_verified $actual_collection]
                    set query_label [format "incoming-%03d" $ordinal]
                }
            }
        }
        puts $inputs [tsv [list $pin {*}$pin_name $owners $cell {*}$parent $role {*}$type {*}$input {*}$clock {*}$lookup $query_label]]
        if {$query_label != ""} {
            flush $inputs
            query $query_label [list -to $actual_collection]
        }
    }
}
close $inputs
close $cells_file
close $reports
close $path_properties
set completion [open [file join $output completion.txt] {WRONLY CREAT EXCL}]
puts $completion "named_original_bank_registers [llength $originals]"
puts $completion "named_bank_registers_including_copies [dict size $bank_names]"
puts $completion "actual_full_launch_registers_resolved [dict size $selected_sources]"
puts $completion "actual_unique_native_launch_cells [dict size $selected_cells]"
puts $completion "actual_unique_native_nonclock_input_pins_enumerated $nonclock_inventory_count"
puts $completion "actual_nonclock_launch_input_queries $ordinal"
puts $completion "unresolved_actual_launch_owner_observations $unresolved_sources"
puts $completion "unavailable_or_empty_native_input_collections $unresolved_cells"
puts $completion "unresolved_native_input_pin_identities_or_flags $unresolved_pins"
puts $completion "zero_path_setup_or_hold_queries $zero_path_queries"
puts $completion "unresolved_or_zero_path_is_not_a_pass [expr {[dict size $selected_cells] == 0 || $ordinal == 0 || $unresolved_sources > 0 || $unresolved_cells > 0 || $unresolved_pins > 0 || $zero_path_queries > 0}]"
puts $completion "classification retained-fit hint only; no BUILD_ID-matched/current-C0 calibration, no equivalence, gain or hardware acceptance"
close $completion
delete_timing_netlist
project_close
