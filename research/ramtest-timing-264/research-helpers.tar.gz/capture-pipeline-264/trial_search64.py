"""Record legal-first 64-geometry capture-pipeline trials; 130 MHz remains unresolved."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
TOOL = WORK / 'sources/misteross/build/toolchain-ramtest-timing'
SOURCE = Path('/home/deano/kepler/worktrees/nextpnr-experiment-mistral-capture-pipeline-search-264-54cde5d3')
OLD_SOURCE = Path('/home/deano/kepler/worktrees/nextpnr-feat-mistral-lut-pair-copies-264-54cde5d3')
MODEL = TOOL / 'src/mistral'
BINARY = TOOL / 'build/nextpnr-capture-pipeline-search-264/nextpnr-mistral'
BASE = WORK / 'out/ramtest-wide-reduction-264/lut-pair-copies-publication-264/main-baseline/run.json'
BASE_SHA = '3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c'
GUIDE = BASE.parent.parent / 'main-baseline-placed/timing.json'
GUIDE_SHA = 'd117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512'
INPUTS = {
    'out/ramtest-merged-remap/measured-diagnostic/synth.json': '61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28',
    'sources/misteross/cores/fes-ramtest/constraints.qsf': '8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4',
    'sources/misteross/boards/de10nano/clocks.sdc': '3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041',
}
ADDED_FILES = ('mistral/capture_pipeline_locality.cc', 'mistral/tests/capture_pipeline_locality.cc',
               'mistral/tests/capture_pipeline_locality_cli.py', 'docs/mistral-capture-pipeline-locality.md')
RUNTIME_ENV_KEYS = ('PATH', 'LD_LIBRARY_PATH', 'LD_PRELOAD', 'LANG', 'LC_ALL', 'TZ',
                    'CUDA_VISIBLE_DEVICES', 'HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES',
                    'OMP_NUM_THREADS', 'HSA_OVERRIDE_GFX_VERSION')


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def encoded(value):
    return json.dumps(value, indent=2, sort_keys=True) + '\n'


def write_exclusive(path, value):
    with path.open('x') as stream:
        stream.write(encoded(value))


def fixed_arguments():
    return ['--json', str(WORK / 'out/ramtest-merged-remap/measured-diagnostic/synth.json'),
            '--device', '5CSEBA6U23I7', '--qsf', str(WORK / 'sources/misteross/cores/fes-ramtest/constraints.qsf'),
            '--sdc', str(WORK / 'sources/misteross/boards/de10nano/clocks.sdc'), '--freq', '74.25',
            '--seed', '2', '--placer-heap-timingweight', '10', '--placer-heap-critexp', '2',
            '--replicate-enables', '4', '--timing-allow-fail', '--detailed-timing-report',
            '--router', 'gpu', '--gpu-device', '1']


def capture(paths):
    values, errors = {}, {}
    for path in sorted(paths):
        try:
            values[str(path)] = sha(path)
        except Exception as error:
            errors[str(path)] = type(error).__name__ + ': ' + str(error)
    return {'sha256': values, 'errors': errors}


def output_snapshot(output):
    paths = sorted(output.iterdir())
    invalid = [path.name for path in paths if path.is_symlink() or not path.is_file()]
    snapshot = capture(path for path in paths if path.name != 'run.json' and path.is_file() and not path.is_symlink())
    return {'names': [path.name for path in paths], 'sha256': {Path(path).name: value for path, value in snapshot['sha256'].items()},
            'errors': snapshot['errors'], 'invalid_entries': invalid}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-sha256', required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--mode', choices=('disabled-placed', 'pipeline-placed', 'pipeline-route'), required=True)
    args = parser.parse_args()
    require(all(re.fullmatch('[0-9a-f]{64}', value) for value in (args.self_sha256, args.binary_sha256)),
            'actual activation hashes required')
    require(sha(__file__) == args.self_sha256 and sha(BINARY) == args.binary_sha256 and
            sha(BASE) == BASE_SHA and sha(GUIDE) == GUIDE_SHA, 'recorder/compiler/reference/guide changed')
    with BINARY.open('rb') as stream:
        require(stream.read(4) == b'\x7fELF', 'compiler is not an ELF file')
    base = json.loads(BASE.read_text())
    expected_base = [str(TOOL / 'build/nextpnr-lut-pair-copies-publication-264/nextpnr-mistral')] + fixed_arguments() + [
        '--write', str(BASE.parent / 'routed.json'), '--report', str(BASE.parent / 'timing.json'),
        '--timing-report-paths', '16384', '--rbf', str(BASE.parent / 'core.rbf')]
    require(base['command'] == expected_base and base['cwd'] == str(WORK / 'sources/misteross') and
            base['input_sha256'] == INPUTS and base['completed_normally'] is True and base['exit_code'] == 0,
            'fixed baseline command/input identity or completion differs')
    files = {}
    model_files = {}
    mapped_count = 0
    for old, historical_hash in base['production_source_sha256'].items():
        path = Path(old)
        if path.is_relative_to(OLD_SOURCE):
            path = SOURCE / path.relative_to(OLD_SOURCE)
            mapped_count += 1
        else:
            require(path.is_relative_to(MODEL), 'unexpected production inventory root')
            model_files[str(path)] = historical_hash
        require(str(path) not in files, 'duplicate mapped production path')
        files[str(path)] = sha(path)
    for name in ADDED_FILES:
        files[str(SOURCE / name)] = sha(SOURCE / name)
    require(mapped_count > 0 and model_files and all(files[path] == value for path, value in model_files.items()),
            'live new source missing or model bytes differ from fixed baseline')
    bound_paths = set(files) | {str(WORK / name) for name in INPUTS} | {str(Path(__file__).resolve()), str(BINARY), str(BASE), str(GUIDE)}
    before = capture(bound_paths)
    expected = {**files, **{str(WORK / name): value for name, value in INPUTS.items()},
                str(Path(__file__).resolve()): args.self_sha256, str(BINARY): args.binary_sha256,
                str(BASE): BASE_SHA, str(GUIDE): GUIDE_SHA}
    require(not before['errors'] and before['sha256'] == expected, 'bound bytes changed before activation')
    routed = args.mode == 'pipeline-route'
    suffix = args.mode if args.mode == 'disabled-placed' else args.mode + '-b64-r24'
    output = HERE / ('legal64-' + suffix)
    require(not output.exists(), 'immutable trial output already exists')
    command = [str(BINARY)] + fixed_arguments() + [
        '--write', str(output / ('routed.json' if routed else 'placed.json')),
        '--report', str(output / 'timing.json'), '--timing-report-paths', '16384']
    command += ['--rbf', str(output / 'core.rbf')] if routed else ['--no-route']
    require(not any(flag.startswith('--remap-') or flag.startswith('--balance-') for flag in command),
            'unexpected graph remap in baseline command')
    cleared = sorted(key for key in os.environ if key.startswith('NEXTPNR_'))
    environment = {key: value for key, value in os.environ.items() if not key.startswith('NEXTPNR_')}
    environment.update({'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'})
    selected = {} if args.mode == 'disabled-placed' else {
        'NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY': f'{GUIDE} 64 24'}
    environment.update(selected)
    require({key: value for key, value in environment.items() if key.startswith('NEXTPNR_')} == selected,
            'unexpected effective diagnostic environment')
    environment_record = {'runtime_values': {key: environment[key] for key in RUNTIME_ENV_KEYS if key in environment},
                          'selected_diagnostics': selected, 'cleared_diagnostic_keys': cleared,
                          'all_effective_keys': sorted(environment),
                          'all_effective_values_sha256': hashlib.sha256(encoded(environment).encode()).hexdigest(),
                          'unlisted_values_recorded': False}
    expected_names = {'profile.json', 'trial.log', 'timing.json', 'routed.json' if routed else 'placed.json'}
    if routed:
        expected_names.add('core.rbf')
    profile = {'schema': 1, 'role': 'exploratory legal-first geometry search; not timing acceptance; 130MHz unresolved',
               'source_root': str(SOURCE), 'binary_path': str(BINARY), 'baseline_path': str(BASE), 'guide_path': str(GUIDE),
               'baseline_sha256': BASE_SHA, 'guide_sha256': GUIDE_SHA, 'helper_sha256': args.self_sha256,
               'binary_sha256': args.binary_sha256, 'mode': args.mode, 'pipeline_budget': 0 if not selected else 64,
               'pipeline_radius': 24, 'geometry_search_limit': 64, 'timed_trial_limit': 16,
               'production_source_sha256': files, 'input_sha256': INPUTS, 'before_snapshot': before,
               'command': command, 'environment': environment_record, 'cwd': base['cwd'],
               'profile_name': 'profile.json', 'expected_output_names_before_run_record': sorted(expected_names),
               'compiled_commit_asserted': False, 'native_physical_equivalence_proved': False,
               'gain_accepted': False, 'hardware_tested': False}
    output.mkdir()
    profile_hash = None
    returncode = None
    failure = None
    started = time.monotonic()
    try:
        write_exclusive(output / 'profile.json', profile)
        profile_hash = sha(output / 'profile.json')
        require(capture(bound_paths) == before, 'bound bytes changed after profile creation')
        with (output / 'trial.log').open('x') as stream:
            result = subprocess.run(command, cwd=base['cwd'], env=environment, stdout=stream, stderr=subprocess.STDOUT)
        returncode = result.returncode
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
    elapsed = time.monotonic() - started
    after = capture(bound_paths)
    unchanged = not after['errors'] and after == before
    artifacts = output_snapshot(output)
    outputs_complete = not artifacts['errors'] and not artifacts['invalid_entries'] and set(artifacts['names']) == expected_names
    profile_stable = profile_hash is not None and artifacts['sha256'].get('profile.json') == profile_hash
    marker = False
    try:
        marker = 'Info: Program finished normally.' in (output / 'trial.log').read_text()
    except Exception as error:
        failure = failure or {'type': type(error).__name__, 'message': str(error)}
    outputs_stable = output_snapshot(output) == artifacts
    completed = returncode == 0 and marker and outputs_complete and outputs_stable and profile_stable and unchanged and failure is None
    if not completed and failure is None:
        failure = {'type': 'TrialValidationFailure', 'message': 'exit/normal marker/output closure/profile or bound-byte stability failed'}
    record = {'schema': 1, 'role': profile['role'], 'profile_name': 'profile.json', 'profile_sha256': profile_hash,
              'helper_sha256': args.self_sha256, 'binary_sha256': args.binary_sha256,
              'command': command, 'environment': environment_record, 'cwd': base['cwd'],
              'before_snapshot': before, 'after_snapshot': after, 'exit_code': returncode, 'elapsed_seconds': elapsed,
              'production_and_input_bytes_stable': unchanged, 'profile_bytes_stable': profile_stable,
              'normal_finish_marker': marker, 'expected_output_names_before_run_record': sorted(expected_names),
              'actual_output_names_before_run_record': artifacts['names'], 'output_sha256': artifacts['sha256'],
              'output_hash_errors': artifacts['errors'], 'invalid_output_entries': artifacts['invalid_entries'],
              'output_bytes_stable': outputs_stable, 'outputs_complete': outputs_complete,
              'completed_normally': completed, 'failure': failure, 'compiled_commit_asserted': False,
              'native_physical_equivalence_proved': False, 'gain_accepted': False, 'hardware_tested': False}
    write_exclusive(output / 'run.json', record)
    print(json.dumps({'run_sha256': sha(output / 'run.json'), 'exit_code': returncode,
                      'completed_normally': completed, 'stable': unchanged}))
    require(completed, 'trial failed; closed failure record written without a gain claim')


if __name__ == '__main__':
    main()
