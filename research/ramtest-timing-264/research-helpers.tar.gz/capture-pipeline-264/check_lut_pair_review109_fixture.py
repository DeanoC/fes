#!/usr/bin/env python3
"""Incrementally rebuild and test one fixture correction without replacing the initial build bindings."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
HELPER = HERE / 'check_lut_pair_review109_current.py'
HELPER_SHA = '3223e4d37388ef82727f75351366c4a1c03fb8605d2c413eb2768feda49880c4'
CONFIG = HERE / 'lut-pair-review109-current-check-configure-v1/record.json'
CONFIG_SHA = 'f6b4cd222374ac6efbb52c132fe1c1e35e858afbd02b9cbc6f1853ec554dca2c'
BUILT = HERE / 'lut-pair-review109-current-check-build-v1/record.json'
BUILT_SHA = '6584df819ac4935f5ece84fd9648f7ad31e17fbcac656e2f2dcb812d3033f383'
BUILD_ENV_SHA = 'e28d3c983e3fa208b448f76bb8f69cc21b3e647840a4250de72bd3ea39988b0c'
FIXTURE = 'mistral/tests/lut_pair_placement.cc'
ENV = {k: v for k, v in os.environ.items() if k in {
    'PATH', 'HOME', 'TMPDIR', 'LD_LIBRARY_PATH', 'CMAKE_PREFIX_PATH', 'PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR',
    'ROCM_PATH', 'ROCM_ROOT', 'HIP_PATH', 'HIP_ROCCLR_HOME', 'HIP_DEVICE_LIB_PATH', 'HSA_PATH'}}
ENV.update(LANG='C', LC_ALL='C', TZ='UTC')

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def load_helper():
    require(sha(HELPER) == HELPER_SHA, 'reviewed helper changed'); sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('review109_fixture_readonly_inputs', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    require(helper.ENV == ENV, 'helper/test environment differs')
    return helper  # Only inputs(), elfs(), git() and their read-only dependencies are called.

def authenticate(helper, expected, test_sha):
    require(sha(CONFIG) == CONFIG_SHA and sha(BUILT) == BUILT_SHA, 'closed initial records changed')
    config, built = json.loads(CONFIG.read_text()), json.loads(BUILT.read_text())
    original, selected = built['inputs_before'], helper.inputs()
    for stage, row in (('configure', config), ('build', built)):
        require(row['schema'] == 'lut-pair-review109-current-check-v1' and row['stage'] == stage and row['state'] == 'passed' and
                row['exit_code'] == 0 and row['inputs_unchanged'] is True and row['inputs_before'] == row['inputs_after'] == original and
                row['recorder_sha256'] == row['recorder_after_sha256'] == HELPER_SHA and row['environment_values_sha256'] == BUILD_ENV_SHA and
                row['command'] == helper.COMMANDS[stage] and row['cwd'] == str(helper.SOURCE), 'initial build closure differs')
    special = {'files', 'changed_paths', 'source_status_porcelain', 'diff_sha256'}
    require({k: v for k, v in selected.items() if k not in special} == {k: v for k, v in original.items() if k not in special} and
            {k: v for k, v in selected['files'].items() if k != FIXTURE} == {k: v for k, v in original['files'].items() if k != FIXTURE},
            'production/model/submodule bytes or source membership changed')
    old, new = original['files'][FIXTURE], selected['files'][FIXTURE]
    require(old['mode'] == new['mode'] and old['symlink'] == new['symlink'] and old['sha256'] != new['sha256'] and
            selected['changed_paths'] == [FIXTURE] and len(selected['source_status_porcelain'].splitlines()) == 1 and
            selected['source_status_porcelain'][3:].strip() == FIXTURE and selected['source_status_porcelain'][:2] in (' M', 'M ', 'MM'),
            'only the declared tracked fixture correction is allowed')
    diff = helper.git(helper.SOURCE, 'diff', '--binary', 'HEAD').decode()
    require(hashlib.sha256(diff.encode()).hexdigest() == selected['diff_sha256'], 'fixture diff changed during snapshot')
    cache, configure = helper.BUILD / 'CMakeCache.txt', helper.BUILD / 'review109-current-configure-binding.json'
    build = helper.BUILD / 'review109-current-build-binding.json'
    require(config['cache_after_sha256'] == built['cache_before_sha256'] == built['cache_after_sha256'] == sha(cache), 'cache changed')
    require(json.loads(configure.read_text()) == {'recorder_sha256': HELPER_SHA, 'inputs': original, 'command': helper.COMMANDS['configure'],
            'environment_values_sha256': BUILD_ENV_SHA, 'exit_code': 0, 'state': 'passed', 'cache_sha256': sha(cache)} and
            json.loads(build.read_text()) == {'configure_binding_sha256': sha(configure), 'executables': built['executables_after'],
            'inputs': original, 'environment_values_sha256': BUILD_ENV_SHA, 'recorder_sha256': HELPER_SHA, 'exit_code': 0, 'state': 'passed'},
            'initial successful bindings changed')
    paths = {str(HELPER): HELPER_SHA, str(Path(__file__).resolve()): expected, str(CONFIG): CONFIG_SHA, str(BUILT): BUILT_SHA,
             str(CONFIG.parent / 'output.log'): config['log_sha256'], str(BUILT.parent / 'output.log'): built['log_sha256'], str(cache): sha(cache)}
    for record in (config, built):
        for name, digest in record['bindings_after_sha256'].items():
            require(str(helper.BUILD / name) not in paths or paths[str(helper.BUILD / name)] == digest, 'binding identities conflict')
            paths[str(helper.BUILD / name)] = digest
    require(all(sha(name) == digest for name, digest in paths.items()) and built['configure_binding_before_sha256'] == sha(configure),
            'initial artifact/log hashes changed')
    executables = helper.elfs()
    require(executables['nextpnr-mistral'] == built['executables_after']['nextpnr-mistral'] and
            executables['nextpnr-mistral-test'] == test_sha, 'production or expected test ELF changed')
    return {'inputs': selected, 'executables': executables, 'artifact_sha256': paths, 'fixture_diff': diff}

def write(path, document):
    temporary = path.with_suffix('.pending')
    with temporary.open('x') as stream:
        stream.write(json.dumps(document, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)

def main():
    require(len(sys.argv) in (4, 7) and sys.argv[1] in ('build', 'native'), 'usage: build LABEL SELF_SHA | native LABEL SELF_SHA BUILD_LABEL RECORD_SHA BINDING_SHA')
    stage, label, expected = sys.argv[1:4]
    require(len(sys.argv) == (4 if stage == 'build' else 7) and re.fullmatch('[0-9a-f]{64}', expected) and sha(__file__) == expected and
            label and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label), 'self pin/label/stage differs')
    directory = HERE / ('lut-pair-review109-fixture-' + label); directory.mkdir(exist_ok=False)
    record, log, binding = directory / 'record.json', directory / 'output.log', directory / 'binding.json'
    started = time.monotonic(); env_sha = hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest()
    document = {'schema': 'lut-pair-review109-fixture-v1', 'stage': stage, 'state': 'running', 'exit_code': None,
                'recorder_sha256': expected, 'completed_normally': False, 'tests_run': False,
                'environment_keys': sorted(ENV), 'environment_values_sha256': env_sha, 'archived_build_environment_values_sha256': BUILD_ENV_SHA,
                'test_environment_equals_archived_build': env_sha == BUILD_ENV_SHA, 'same_environment_claimed': False,
                'cleared_diagnostic_keys': sorted(k for k in os.environ if k.startswith('NEXTPNR_')),
                'reconfigure_executed': False, 'compiled_commit_asserted': False, 'gain_qualified': False, 'full_route': False, 'hardware': False}
    write(record, document); print(json.dumps({'stage': stage, 'state': 'running', 'record': str(record)}), flush=True)
    try:
        helper = load_helper(); initial = json.loads(BUILT.read_text()); test_sha = initial['executables_after']['nextpnr-mistral-test']
        prior_artifacts = {}; document['archived_build_environment_keys'] = initial['environment_keys']
        if stage == 'native':
            prior_label, prior_sha, binding_sha = sys.argv[4:]
            require(prior_label and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in prior_label) and
                    re.fullmatch('[0-9a-f]{64}', prior_sha) and re.fullmatch('[0-9a-f]{64}', binding_sha), 'invalid incremental build pins')
            prior_dir = HERE / ('lut-pair-review109-fixture-' + prior_label)
            require(sha(prior_dir / 'record.json') == prior_sha and sha(prior_dir / 'binding.json') == binding_sha, 'incremental record/binding changed')
            prior, saved = json.loads((prior_dir / 'record.json').read_text()), json.loads((prior_dir / 'binding.json').read_text())
            require(prior['stage'] == 'build' and prior['state'] == 'passed' and prior['exit_code'] == 0 and prior['completed_normally'] is True and
                    prior['recorder_sha256'] == prior['recorder_after_sha256'] == expected and prior['binding_sha256'] == binding_sha and
                    sha(prior_dir / 'output.log') == prior['log_sha256'], 'incremental build was not authenticated closed success')
            require(saved == {'recorder_sha256': expected, 'initial_build_record_sha256': BUILT_SHA, 'after': prior['after'],
                    'environment_values_sha256': prior['environment_values_sha256'], 'command': prior['command'], 'exit_code': 0, 'state': 'passed'},
                    'incremental binding differs')
            test_sha = saved['after']['executables']['nextpnr-mistral-test']
            prior_artifacts = {str(prior_dir / 'record.json'): prior_sha, str(prior_dir / 'binding.json'): binding_sha,
                               str(prior_dir / 'output.log'): prior['log_sha256']}
            document.update(incremental_record_sha256=prior_sha, incremental_binding_sha256=binding_sha, incremental_artifact_sha256=prior_artifacts)
        before = authenticate(helper, expected, test_sha); document['before'] = before
        if stage == 'native':
            require(before == saved['after'], 'incremental source/test ELF closure differs')
        require(all(sha(name) == digest for name, digest in prior_artifacts.items()), 'incremental artifacts changed before execution')
        cmake = shutil.which('cmake', path=ENV.get('PATH', '')); git = shutil.which('git', path=ENV.get('PATH', ''))
        require(cmake and git, 'required current tools unavailable')
        tools = {str(Path(path).resolve()): sha(Path(path).resolve()) for path in (cmake, git)}
        command = [str(Path(cmake).resolve()), '--build', str(helper.BUILD), '--target', 'nextpnr-mistral-test', '-j8'] if stage == 'build' else helper.COMMANDS['native']
        document.update(command=command, cwd=str(helper.SOURCE), tool_sha256=tools)
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=helper.SOURCE, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        document.update(exit_code=result.returncode, completed_normally=True, tests_run=stage == 'native')
        after = authenticate(helper, expected, helper.elfs()['nextpnr-mistral-test']); document['after'] = after
        require({k: v for k, v in before.items() if k != 'executables'} == {k: v for k, v in after.items() if k != 'executables'} and
                before['executables']['nextpnr-mistral'] == after['executables']['nextpnr-mistral'] and
                all(sha(name) == digest for name, digest in {**tools, **prior_artifacts}.items()), 'source/cache/production ELF/tool/incremental closure changed')
        document['source_and_bindings_unchanged'] = True
        if stage == 'native':
            require(before == after, 'native test ELF changed')
            text = log.read_text(errors='replace'); cases = re.findall(r'^\[ RUN      \] (\S+)', text, re.M)
            require(len(cases) == 45 and all(any(case.startswith(family + '.') for case in cases) for family in helper.FAMILIES) and
                    re.search(r'^\[  PASSED  \] 45 tests\.', text, re.M) and '[  SKIPPED ]' not in text, '45 native cases must pass without skips')
            document['native_case_count'] = len(cases)
        require(result.returncode == 0, 'incremental build/native returned failure'); document['state'] = 'passed'
        if stage == 'build':
            write(binding, {'recorder_sha256': expected, 'initial_build_record_sha256': BUILT_SHA, 'after': after,
                            'environment_values_sha256': env_sha, 'command': command, 'exit_code': 0, 'state': 'passed'})
            document['binding_sha256'] = sha(binding)
    except BaseException as error:
        document.update(state='failed', error=type(error).__name__ + ': ' + str(error))
    finally:
        document['elapsed_seconds'] = time.monotonic() - started
        document['log_sha256'] = sha(log) if log.is_file() else None; document['recorder_after_sha256'] = sha(__file__)
        write(record, document)
        print(json.dumps({'stage': stage, 'state': document['state'], 'exit_code': document['exit_code'], 'record_sha256': sha(record)}), flush=True)
    return 0 if document['state'] == 'passed' else 1

if __name__ == '__main__':
    sys.exit(main())
