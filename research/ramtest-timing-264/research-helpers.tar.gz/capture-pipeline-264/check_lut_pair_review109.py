#!/usr/bin/env python3
"""Record isolated PR109 configure/build/native/CLI checks; never replay old helpers."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

WORK = Path('/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d')
HERE = WORK / 'out/ramtest-wide-reduction-264/capture-pipeline-264'
SOURCE = Path('/home/deano/kepler/worktrees/nextpnr-feat-mistral-lut-pair-copies-264-54cde5d3')
TOOL = WORK / 'sources/misteross/build/toolchain-ramtest-timing'
BUILD = TOOL / 'build/nextpnr-lut-pair-review109-264'
MODEL = TOOL / 'src/mistral'
BASE = HERE.parent / 'lut-pair-copies-publication-264/main-baseline/run.json'
BASE_SHA = '3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c'
CHANGED = {'mistral/lut_pair_copy.cc', 'mistral/tests/lut_pair_placement.cc'}
SUBMODULES = {'3rdparty/googletest': '52eb8108c5bdec04579160ae17225d66034bd723',
              'tests': 'ce154121819a04ec921a4a6f6850c28f33c81b6c'}
FAMILIES = ('LutPairPlacementTest', 'LutPairCopyTest', 'LutDriverCopyTest', 'LabPinmapTest')
ENV = {key: value for key, value in os.environ.items() if key in {
    'PATH', 'HOME', 'TMPDIR', 'LD_LIBRARY_PATH', 'CMAKE_PREFIX_PATH', 'PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR',
    'ROCM_PATH', 'ROCM_ROOT', 'HIP_PATH', 'HIP_ROCCLR_HOME', 'HIP_DEVICE_LIB_PATH', 'HSA_PATH'}}
ENV.update(LANG='C', LC_ALL='C', TZ='UTC')
COMMANDS = {
    'configure': ['cmake', '-S', str(SOURCE), '-B', str(BUILD), '-DCMAKE_BUILD_TYPE=Release', '-DARCH=mistral',
                  '-DMISTRAL_ROOT=' + str(MODEL), '-DGPU_ROUTER=HIP', '-DCMAKE_HIP_ARCHITECTURES=gfx1100;gfx1201',
                  '-DCMAKE_HIP_COMPILER=/opt/rocm/core-7.14/lib/llvm/bin/clang++',
                  '-DBUILD_GUI=OFF', '-DBUILD_TESTS=ON', '-DUSE_OPENMP=OFF'],
    'build': ['cmake', '--build', str(BUILD), '--parallel', '8', '--target', 'nextpnr-mistral', 'nextpnr-mistral-test'],
    'native': [str(BUILD / 'nextpnr-mistral-test'), '--gtest_filter=' + ':'.join(name + '.*' for name in FAMILIES)],
    'cli': ['ctest', '--test-dir', str(BUILD), '--output-on-failure', '--no-tests=error',
            '-R', '^nextpnr-mistral-(lut-pair-placement|lut-driver-copy)-cli$'],
}

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(directory, *args):
    return subprocess.check_output(['git', '-C', str(directory), *args], env=ENV)

def inputs():
    files, modules, inactive = {}, {}, {}
    head = git(SOURCE, 'rev-parse', 'HEAD').decode().strip()
    require(head == git(SOURCE, 'rev-parse', '266e3ef7^{commit}').decode().strip(), 'unexpected PR109 HEAD')
    changed = {os.fsdecode(name) for name in git(SOURCE, 'diff', '--name-only', '-z', 'HEAD').split(b'\0') if name}
    require(changed <= CHANGED, 'source changes extend outside the two reviewed files')
    def visit(directory, prefix='', expected=head):
        actual = git(directory, 'rev-parse', 'HEAD').decode().strip()
        require(actual == expected, 'source/submodule HEAD changed: ' + prefix)
        require(not git(directory, 'ls-files', '--others', '--exclude-standard', '-z'), 'untracked source files: ' + prefix)
        for item in git(directory, 'ls-files', '--stage', '-z').split(b'\0'):
            if not item:
                continue
            metadata, raw_name = item.split(b'\t', 1)
            mode, oid, stage = metadata.decode().split(); name = os.fsdecode(raw_name)
            require(stage == '0', 'unmerged source index')
            path, owner = directory / name, prefix + name
            if mode == '160000':
                if not prefix and name not in SUBMODULES:
                    require(name in {'himbaechel/uarch/xilinx/meta', '3rdparty/corrosion'}, 'unexpected inactive gitlink')
                    inactive[owner] = oid; continue
                if not prefix:
                    require(SUBMODULES.get(name) == oid, 'unexpected root submodule/gitlink')
                modules[owner] = {'head': oid, 'expected_gitlink': oid}; visit(path, owner + '/', oid)
            else:
                files[owner] = {'sha256': sha(path), 'mode': mode,
                                'symlink': os.readlink(path) if path.is_symlink() else None}
    visit(SOURCE)
    require(set(SUBMODULES) <= set(modules), 'required build/test submodule missing')
    require(sha(BASE) == BASE_SHA, 'fixed model reference changed')
    models = {name: digest for name, digest in json.loads(BASE.read_text())['production_source_sha256'].items()
              if Path(name).is_relative_to(MODEL)}
    require(models and all(sha(name) == digest for name, digest in models.items()), 'baseline model bytes differ')
    return {'source_head': head, 'files': files, 'submodules': modules, 'inactive_gitlinks': inactive, 'model_sha256': models,
            'model_reference_sha256': BASE_SHA, 'changed_paths': sorted(changed),
            'diff_sha256': hashlib.sha256(git(SOURCE, 'diff', '--binary', 'HEAD')).hexdigest(),
            'coverage': 'All tracked root regular files and build/test submodule bytes; inactive gitlink IDs only; exact baseline MODEL subtree.'}

def elfs(required=True):
    result = {}
    for name in ('nextpnr-mistral', 'nextpnr-mistral-test'):
        path = BUILD / name
        if not path.is_file() and not required:
            continue
        with path.open('rb') as stream:
            require(stream.read(4) == b'\x7fELF', 'build output is not ELF: ' + name)
        result[name] = sha(path)
    return result

def write(path, document):
    temporary = path.with_suffix('.pending')
    with temporary.open('x') as stream:
        stream.write(json.dumps(document, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)

def main():
    require(len(sys.argv) == 4 and sys.argv[1] in COMMANDS, 'usage: check_lut_pair_review109.py STAGE NEW_LABEL SCRIPT_SHA256')
    stage, label, expected = sys.argv[1:]
    require(re.fullmatch('[0-9a-f]{64}', expected) and sha(__file__) == expected and label and
            all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label), 'recorder pin or new label invalid')
    directory = HERE / ('lut-pair-review109-check-' + label); directory.mkdir(exist_ok=False)
    record, log, cache = directory / 'record.json', directory / 'output.log', BUILD / 'CMakeCache.txt'
    config_path, build_path = BUILD / 'review109-configure-binding.json', BUILD / 'review109-build-binding.json'
    env_sha = hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest(); started = time.monotonic()
    document = {'schema': 'lut-pair-review109-check-v1', 'stage': stage, 'state': 'running', 'exit_code': None,
                'command': COMMANDS[stage], 'cwd': str(SOURCE), 'recorder_sha256': expected,
                'environment_keys': sorted(ENV), 'environment_values_sha256': env_sha,
                'cleared_diagnostic_keys': sorted(k for k in os.environ if k.startswith('NEXTPNR_')),
                'tests_run': False, 'compiled_commit_asserted': False, 'gain_qualified': False, 'full_route': False, 'hardware': False}
    write(record, document); print(json.dumps({'stage': stage, 'state': 'running', 'record': str(record)}), flush=True)
    try:
        selected = inputs(); document['inputs_before'] = selected
        binding = {'recorder_sha256': expected, 'inputs': selected, 'command': COMMANDS['configure'],
                   'environment_values_sha256': env_sha, 'exit_code': 0, 'state': 'passed'}
        if stage == 'configure':
            require(not BUILD.exists(), 'configure requires a fresh build directory')
        else:
            binding['cache_sha256'] = sha(cache)
            document['cache_before_sha256'] = binding['cache_sha256']
            require(json.loads(config_path.read_text()) == binding, 'successful configure/source/model/cache/environment binding differs')
            document['configure_binding_before_sha256'] = sha(config_path)
            document['executables_before'] = elfs(required=stage != 'build')
            if stage in ('native', 'cli'):
                built = {'configure_binding_sha256': sha(config_path), 'executables': document['executables_before'],
                         'inputs': selected, 'environment_values_sha256': env_sha, 'recorder_sha256': expected, 'exit_code': 0, 'state': 'passed'}
                require(json.loads(build_path.read_text()) == built, 'tests require this successful build and exact ELFs')
                document['build_binding_before_sha256'] = sha(build_path)
        with log.open('xb') as stream:
            result = subprocess.run(COMMANDS[stage], cwd=SOURCE, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        document.update(exit_code=result.returncode, tests_run=stage in ('native', 'cli'))
        document['inputs_after'] = inputs(); document['cache_after_sha256'] = sha(cache)
        require(document['inputs_after'] == selected and sha(__file__) == expected, 'selected inputs or recorder changed')
        if stage != 'configure':
            require(sha(cache) == binding['cache_sha256'] and sha(config_path) == document['configure_binding_before_sha256'], 'configure/cache changed')
        if stage != 'configure':
            document['executables_after'] = elfs()
        if stage in ('native', 'cli'):
            require(document['executables_after'] == document['executables_before'] and sha(build_path) == document['build_binding_before_sha256'], 'test ELF/build binding changed')
            text = log.read_text(errors='replace')
            if stage == 'native':
                cases = re.findall(r'^\[ RUN      \] (\S+)', text, re.M)
                require(cases and all(any(case.startswith(family + '.') for case in cases) for family in FAMILIES) and
                        re.search(r'^\[  PASSED  \] ' + str(len(cases)) + r' tests?\.', text, re.M) and '[  SKIPPED ]' not in text,
                        'native checks did not report all requested suites passing without skips')
                document['native_case_count'] = len(cases)
            else:
                require('100% tests passed, 0 tests failed out of 2' in text, 'both anchored CLI targets must pass')
                document['cli_ctest_target_count'] = 2
        require(result.returncode == 0, 'check returned a failing exit code')
        document['state'] = 'passed'
        if stage == 'configure':
            binding['cache_sha256'] = sha(cache); write(config_path, binding)
        if stage == 'build':
            write(build_path, {'configure_binding_sha256': sha(config_path), 'executables': document['executables_after'],
                              'inputs': selected, 'environment_values_sha256': env_sha, 'recorder_sha256': expected, 'exit_code': 0, 'state': 'passed'})
        document['inputs_unchanged'] = True
        document['bindings_after_sha256'] = {path.name: sha(path) for path in (config_path, build_path) if path.is_file()}
    except BaseException as error:
        document.update(state='failed', error=type(error).__name__ + ': ' + str(error))
    finally:
        document['log_sha256'] = sha(log) if log.is_file() else None
        document['elapsed_seconds'] = time.monotonic() - started; document['recorder_after_sha256'] = sha(__file__)
        write(record, document)
        print(json.dumps({'stage': stage, 'state': document['state'], 'exit_code': document['exit_code'], 'record_sha256': sha(record)}), flush=True)
    return 0 if document['state'] == 'passed' else 1

if __name__ == '__main__':
    sys.exit(main())
