When a registered fixed hard-block output feeds a plain capture FF whose only consumer is a second plain FF, placing only the first FF near the block can leave a long internal hop. This adds an opt-in pass that places both existing FFs together while preserving the graph, initialization and latency.

Discovery uses cell types, timing arcs and graph structure. Each trial checks native LAB legality, complete affected clock-pair setup/hold timing, unrelated clock pairs and global Fmax; rejection restores both placements and architecture/LAB state. The request is read before packing, requires successful ordinary HeAP placement, and stays default off.

Stacked on #109. Host checks passed: 32 native cases and 11 CLI methods. Three independently checked full RAM-test routes improve a matched fresh-main baseline of 105.775330 MHz:

| Explicit configuration | Memory MHz | Gain over fresh main MHz | Pixel MHz |
| --- | ---: | ---: | ---: |
| Budget 8, radius 24 | 105.864914 | +0.089584 | 95.565750 |
| Budget 64, radius 24 | 106.123314 | +0.347984 | 93.905533 |
| Budget 8, radius 24 + existing composed LUT-pair copy 0 | 107.307648 | +1.532318 | 94.894669 |

The combined result gains 1.442734 MHz over its budget-8 parent. Its independent proof checks the single new LUT and equivalent ENA edge, all earlier register placements, complete exported graph/physical ledgers and all seven clock windows. All three routes keep the six required non-target windows positive and report no final hold violations. Pixel Fmax decreases but still passes 74.25 MHz. Memory still misses 130 MHz.

The separate frozen 117.868927 MHz composed stack uses an older compiler/configuration/HeAP baseline and remains unchanged; these fresh-main results do not inherit that qualification. The validation record identifies the actual measured compiler/input/output/proof bytes and explicit options. It does not qualify a newly built publication binary or the current default recipe.

Independent checks cover the exported native graph, register latency/initial values, complete affected LAB snapshots, packed functions and explicit route-through buffers. They do not independently decode route muxes or RBF bytes, recompute numerical STA, prove complete device legality or establish hardware acceptance. No FES RTL, compiler pins, default recipe or constraints change.

Related investigation: https://github.com/DeanoC/fes/issues/264
