#!/usr/bin/env python3
"""Independent exported graph/physical/timing proof for post-B8 candidate 0.

No compiler, route, old main/authentication/generator or aggregate evaluator is
executed. Pinned helpers provide only the lossless parser, raw slot tables,
report topology and pure exported ALM primitives. The prior pipeline proof is
read as immutable evidence, never imported. This file requires whole review
and an explicit self digest before root executes it.
"""
import argparse
import builtins
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import types

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
ROOT = HERE.parents[2]
PUB = RAW / "lut-pair-copies-publication-264"
DIGEST = re.compile(r"[0-9a-f]{64}")
RUNS = {
    "baseline": (PUB / "main-baseline", "3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c"),
    "baseline_place": (PUB / "main-baseline-placed", "0ba98d9e976bc8488349cb274b46afe935e6a636641659087bb16a6727e91e06"),
    "parent_place": (HERE / "clock-group-pipeline-placed-b8-r24", "95eb2f478408d8b65fb0127cd8404a3f97f2377a9c819aff31e8d2b81076b8df"),
    "parent": (HERE / "clock-group-pipeline-route-b8-r24", "43ae1c42b28456f53fce8927276c00c58dee433dd0db2504b353b3183c8ea5c3"),
    "listing": (HERE / "clock-group-pipeline-b8-pair-copy-list", "05bbdd76ba39abcb03b5538087c3eab80c72eaf4216d4294f4b7d8d83af41cfd"),
    "selected": (HERE / "clock-group-pipeline-b8-pair-copy-c0-placed", "1ac34d488937d68b8a63d8b46b45433086cd42e36af6caf038b505ac08e09f9c"),
    "current": (HERE / "clock-group-pipeline-b8-pair-copy-c0-route", "a2ddc6830f6d75e11cb1e0fbd13a2d3b284db69554fc72505c27b531484c893d"),
}
HELPERS = {
    "native": (RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"),
    "tables": (RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"),
    "physical": (RAW / "local-multicopy-ready1-address-route-proof-264/physical.py", "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"),
}
RECORDER_SHA = "c2f59722b380245c46933bcc5b90f2c0766df86be8169d85d3993ab001f5505d"
LISTING_HELPER_SHA = "be7e5dae7076555d43f40ea445bae05bb151072b293f4616c58c2224095e91e1"
PREFIX_HELPER_SHA = "a3fb41cb3300099022c1af4c63c44bac6bf92eb4612ca4456bdaa41596ff01ed"
BINARY_SHA = "4db58a6de261b8542cce2c50f969f1f7b23b2c9c92150fa9a80697f88d185c27"
BASE_BINARY_SHA = "fb53b77256ab2958c8dfc321a8e977e4a741a73b1ead584c21c8f72116b129e8"
SOURCE_COMMIT = "a0432321e5ab99e20ec83e4fe97b652128b3c4b8"
SOURCE_ARCHIVE_SHA = "19c307f0fc22f5b766d8eba1f0bb7a282a52e0f5344a4674d2a76aa214fa7d29"
GUIDE_SHA = "d117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512"
PAIR_GUIDE_SHA = "18aecabd79f697c0f010ce0339349bbdd34c94e32814194b90a9610068cb980b"
LISTING_PROFILE_SHA = "fcc7ac5b2b05b705d22c0534ec07810a5e3a6d27d36ed00bc5aa82b786f36854"
PREFIX_PROFILE_SHA = "9f770cfb10603b58bc7977d51854f6f79ab2980ea35f0c62374094631ecc959b"
CURRENT_PROFILE_SHA = "218946fb41717c027fe7b54ce819a6dc1076b7aeff187dc22cf8e710c3e14dd7"
SELECTED_PROFILE_SHA = "b01ebf1178bde3b447a5d40c0a9ab5364bbbc39df1ec403ef33e92a067f3c825"
INPUTS = {
    "out/ramtest-merged-remap/measured-diagnostic/synth.json": "61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28",
    "sources/misteross/cores/fes-ramtest/constraints.qsf": "8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4",
    "sources/misteross/boards/de10nano/clocks.sdc": "3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041",
}
INNER = "hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q"
OUTER = "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B"
CLONE = OUTER + "$lut_pair_copy"
ALIAS = CLONE + "$Q"
SINK = "hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_5"
OLD_BIT, NEW_BIT = 105902, 120708
CLONE_BEL = "MISTRAL_COMB.19.28.0"
LEAVES = (98306, 98311, 5029, 103525)
CANDIDATE_LINE = ("Info: LUT pair copy candidate 0: inner=" + INNER + " outer=" + OUTER +
                  " sink=" + SINK + ".ENA clone_bel=" + CLONE_BEL + " gain=3790ps cohort=1.")
APPLIED_LINE = "Info: LUT pair copy applied candidate 0; full routing and signoff still required."
PAIR_NAMES = (
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_16", "ddr1_rdata_MISTRAL_FF_Q_15"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_15", "ddr0_rdata_MISTRAL_FF_Q_121"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_47", "ddr0_rdata_MISTRAL_FF_Q_3"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_19", "ddr0_rdata_MISTRAL_FF_Q_27"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_79", "ddr0_rdata_MISTRAL_FF_Q_28"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_101", "ddr0_rdata_MISTRAL_FF_Q_37"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_16", "ddr0_rdata_MISTRAL_FF_Q_122"),
)
MOVED = {name for pair in PAIR_NAMES for name in pair}
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
CONSTRAINTS = {MEMORY: 130.0052032470703, PIXEL: 74.25006866455078, CAPTURE: 130.0052032470703}
EXPECTED_MHZ = {
    "baseline": {MEMORY: 105.77532958984375, PIXEL: 96.320556640625, CAPTURE: 375.0871276855469},
    "parent": {MEMORY: 105.86491394042969, PIXEL: 95.56575012207031, CAPTURE: 375.0871276855469},
    "current": {MEMORY: 107.30764770507812, PIXEL: 94.89466857910156, CAPTURE: 375.0871276855469},
}


def require(value, reason):
    if not value:
        raise ValueError("post-pipeline C0 proof: " + reason)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON: " + value)))


def load_pure(path, expected, name, freezer=None):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and sha(path) == expected and name not in sys.modules,
            "pinned helper changed or module name occupied")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    allowed = {"argparse", "collections", "copy", "hashlib", "importlib", "json", "math", "pathlib", "re"}
    def local_import(requested, globals=None, locals=None, fromlist=(), level=0):
        require(level == 0, "relative helper import forbidden")
        if requested == "freeze":
            require(freezer is not None, "unexpected freeze import")
            return freezer
        require(requested.split(".")[0] in allowed, "unexpected helper import: " + requested)
        return builtins.__import__(requested, globals, locals, fromlist, level)
    module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(sha(path) == expected, "helper changed while loading")
    return module


def order(value):
    if isinstance(value, dict):
        return [(key, order(item)) for key, item in value.items()]
    if isinstance(value, list):
        return [order(item) for item in value]
    return None


def exact(native, before, after, reason, ordered=True):
    require(native.canonical(before) == native.canonical(after), reason)
    if ordered:
        require(order(before) == order(after), reason + " (export order)")


def literal(cell, port):
    value = cell["connections"][port]
    require(type(value) is list and len(value) == 1 and type(value[0]) is int and value[0] >= 0,
            "nonliteral scalar: " + port)
    return value[0]


def net_shape(row):
    result = copy.deepcopy(row)
    result.get("attributes", {}).pop("ROUTING", None)
    return result


def command_shape(command):
    require(type(command) is list and command and all(type(item) is str for item in command), "invalid recorded command")
    result, index = [], 1
    while index < len(command):
        flag = command[index]
        if flag in {"--write", "--report", "--rbf"}:
            require(index + 1 < len(command), "missing output operand")
            index += 2
        elif flag == "--no-route":
            index += 1
        else:
            result.append(flag)
            index += 1
    return result


def option(command, flag):
    require(command.count(flag) == 1, "missing/duplicate recorded option: " + flag)
    index = command.index(flag) + 1
    require(index < len(command), "missing recorded option value")
    return index


def authenticate(audit):
    """Fresh bounded record closure; no old operational authenticator is called."""
    records, profiles, closure = {}, {}, {}
    helper_paths = {"baseline": PUB / "main_baseline.py", "baseline_place": PUB / "main_baseline_placement.py",
                    "parent_place": HERE / "trial_clock_group.py", "parent": HERE / "trial_clock_group.py",
                    "listing": HERE / "list_post_pipeline.py", "selected": HERE / "select_post_pipeline.py",
                    "current": HERE / "select_post_pipeline.py"}
    for name, (folder, expected) in RUNS.items():
        audit.bind(folder / "run.json", expected)
        record = read(folder / "run.json")
        require(record["schema"] == 1 and record["exit_code"] == 0 and record["hardware_tested"] is False and
                record["gain_accepted"] is False and record["native_physical_equivalence_proved"] is False and
                type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
                record["elapsed_seconds"] > 0, "run is not the pinned successful exploratory record: " + name)
        outputs = record["output_sha256"]
        wanted = ({"routed.json", "timing.json", "core.rbf", "route.log"} if name == "baseline" else
                  {"placed.json", "timing.json", "profile.json", "placement.log"} if name == "baseline_place" else
                  {"routed.json", "timing.json", "profile.json", "trial.log", "core.rbf"} if name in {"parent", "current"} else
                  {"placed.json", "timing.json", "profile.json", "trial.log"})
        require(set(outputs) == wanted, "exact output closure differs: " + name)
        for filename, digest in outputs.items():
            require(Path(filename).name == filename and DIGEST.fullmatch(digest), "invalid output ledger")
            audit.bind(folder / filename, digest)
        require(record.get("production_and_input_bytes_stable", record.get("original_production_and_input_bytes_stable")) is True,
                "recorded source/input stability missing")
        if name == "baseline":
            require(record["completed_normally"] is True, "baseline completion missing")
            profile = record
        else:
            require(record["profile_sha256"] == outputs["profile.json"], "profile/output digest differs")
            profile = read(folder / "profile.json")
        require(profile["baseline_sha256"] == RUNS["baseline"][1] if name != "baseline" else True,
                "baseline ancestry differs")
        require(profile["input_sha256"] == INPUTS and profile["cwd"] == str(ROOT / "sources/misteross") and
                type(profile["production_source_sha256"]) is dict and len(profile["production_source_sha256"]) >= 1199,
                "fixed input/cwd/source closure incomplete")
        for filename, digest in profile["production_source_sha256"].items():
            require(Path(filename).is_absolute() and DIGEST.fullmatch(digest), "invalid recorded source member")
            audit.bind(Path(filename), digest, execution=True)
        audit.bind(Path(profile["command"][0]), profile["binary_sha256"], execution=True)
        audit.bind(helper_paths[name], profile["helper_sha256"])
        command = profile["command"]
        routed = name in {"baseline", "parent", "current"}
        require(command[option(command, "--write")] == str(folder / ("routed.json" if routed else "placed.json")) and
                command[option(command, "--report")] == str(folder / "timing.json") and
                command.count("--no-route") == (0 if routed else 1) and command.count("--rbf") == int(routed),
                "actual stage output/mode command differs")
        if routed:
            require(command[option(command, "--rbf")] == str(folder / "core.rbf"), "actual stage RBF path differs")
        for filename, digest in INPUTS.items():
            audit.bind(ROOT / filename, digest)
        records[name], profiles[name] = record, profile
        closure[name] = {"run_sha256": expected, "output_sha256": outputs, "binary_sha256": profile["binary_sha256"],
                         "production_source_sha256": profile["production_source_sha256"], "input_sha256": INPUTS,
                         "actual_command": profile["command"], "recorded_selected_environment": profile.get("environment"),
                         "recorded_elapsed_seconds": record["elapsed_seconds"], "recorded_exit_code": 0,
                         "all_recorded_source_input_and_execution_bytes_rehashed": True}
    guide = str(RUNS["baseline_place"][0] / "timing.json") + " 8 24"
    expected_env = {"NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY": guide}
    plain = command_shape(profiles["baseline"]["command"])
    require(not any(item.startswith(("--remap-", "--balance-")) for item in plain), "baseline enables a graph transform")
    for name in ("baseline", "baseline_place"):
        require("environment" not in profiles[name] and profiles[name]["binary_sha256"] == BASE_BINARY_SHA and
                command_shape(profiles[name]["command"]) == plain, "fresh baseline options/compiler differ")
        closure[name]["diagnostic_environment_cleared_by_pinned_recorder_code"] = True
    require(profiles["baseline"]["helper_sha256"] == "4693e169294ce5b42241dd79d3deaf5b55019abc9221f5b50e58d54ecedade3f" and
            profiles["baseline_place"]["helper_sha256"] == "6677bcb55bb6c97e5beabb0886efba309347256b4b4a9885aaa224ed8df480ba" and
            profiles["baseline"]["cleared_diagnostic_environment_keys"] == [], "fresh baseline pinned clear-environment recorder differs")
    for name in ("parent_place", "parent", "listing", "selected", "current"):
        profile = profiles[name]
        require(profile["environment"] == expected_env and profile["binary_sha256"] == BINARY_SHA and
                profile["guide_sha256"] == GUIDE_SHA and profile["production_source_sha256"] == profiles["parent_place"]["production_source_sha256"] and
                len(profile["production_source_sha256"]) == 1203, "B8 source/compiler/environment selection differs")
    for name in ("parent_place", "parent"):
        require(profiles[name]["helper_sha256"] == PREFIX_HELPER_SHA and command_shape(profiles[name]["command"]) == plain,
                "parent options or recorder differ")
    require(records["parent_place"]["profile_sha256"] == PREFIX_PROFILE_SHA and
            records["listing"]["profile_sha256"] == LISTING_PROFILE_SHA and
            records["selected"]["profile_sha256"] == SELECTED_PROFILE_SHA and
            records["current"]["profile_sha256"] == CURRENT_PROFILE_SHA and
            records["parent_place"]["output_sha256"]["timing.json"] == PAIR_GUIDE_SHA,
            "pinned stage profile or guide digest differs")
    extra = ["--remap-lut-pair-critical", str(RUNS["parent_place"][0] / "timing.json"),
             "--remap-lut-pair-compose-copy", "--remap-lut-pair-candidate"]
    for name, candidate in (("listing", "-1"), ("selected", "0"), ("current", "0")):
        require(command_shape(profiles[name]["command"]) == plain + extra + [candidate], "copy stage command differs")
        require(profiles[name]["pair_guide_sha256"] == PAIR_GUIDE_SHA, "copy guide changed")
    require(profiles["listing"]["helper_sha256"] == LISTING_HELPER_SHA and
            profiles["listing"]["preceding_run_sha256"] == RUNS["parent_place"][1] and
            profiles["listing"]["preceding_profile_sha256"] == PREFIX_PROFILE_SHA, "listing ancestry differs")
    expected_bound = {str(HERE / "select_post_pipeline.py"): RECORDER_SHA,
                      str(Path(profiles["current"]["command"][0])): BINARY_SHA,
                      str(RUNS["baseline"][0] / "run.json"): RUNS["baseline"][1],
                      str(RUNS["baseline_place"][0] / "timing.json"): GUIDE_SHA,
                      str(HERE / "trial_clock_group.py"): PREFIX_HELPER_SHA,
                      str(HERE / "list_post_pipeline.py"): LISTING_HELPER_SHA}
    for name in ("parent_place", "listing"):
        folder, digest = RUNS[name]
        expected_bound[str(folder / "run.json")] = digest
        expected_bound.update({str(folder / filename): value for filename, value in records[name]["output_sha256"].items()})
    sources = profiles["current"]["production_source_sha256"]
    snapshot_sha = hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest()
    for name, mode in (("selected", "placed"), ("current", "route")):
        record, profile = records[name], profiles[name]
        require(record["completed_normally"] is True and record["execution_error"] is None and
                record["profile_bytes_stable"] is True and record["candidate_identity_verified"] is True and
                record["required_outputs_present"] is True and record["mode"] == mode and record["candidate"] == 0 and
                record["expected_profile_sha256"] == record["profile_sha256"] and
                record["listing_run_sha256"] == RUNS["listing"][1] and record["prefix_run_sha256"] == RUNS["parent_place"][1] and
                record["listing_profile_sha256"] == LISTING_PROFILE_SHA and record["prefix_profile_sha256"] == PREFIX_PROFILE_SHA,
                "C0 completion or ancestor identity failed")
        require(profile["helper_sha256"] == RECORDER_SHA and profile["source_revision"] == SOURCE_COMMIT[:8] and
                profile["mode"] == mode and profile["candidate"] == 0 and profile["candidate_identity"] == CANDIDATE_LINE and
                profile["listing_qualified_candidates"] == 56 and profile["bound_artifact_sha256"] == expected_bound and
                profile["cleared_environment_prefix"] == "NEXTPNR_" and
                profile["fixed_locale"] == {"LANG": "C", "LC_ALL": "C", "TZ": "UTC"} and
                profile["preceding_run_sha256"] == RUNS["listing"][1] and
                profile["preceding_profile_sha256"] == LISTING_PROFILE_SHA and
                profile["listing_output_sha256"] == records["listing"]["output_sha256"] and
                profile["prefix_output_sha256"] == records["parent_place"]["output_sha256"], "C0 fixed recorder profile differs")
        for snapshot in (record["byte_checks_before"], record["byte_checks_after"]):
            require(snapshot == {"matches_expected": True, "artifact_sha256": expected_bound, "input_sha256": INPUTS,
                                  "production_source_file_count": len(sources), "production_source_snapshot_sha256": snapshot_sha,
                                  "production_source_mismatches": [], "read_errors": {}}, "C0 before/after closure differs")
        for filename, digest in expected_bound.items():
            audit.bind(Path(filename), digest)
        closure[name]["complete_recorded_before_after_byte_checks"] = record["byte_checks_before"], record["byte_checks_after"]
    audit.bind(HERE / "clock-group-source.tar.gz", SOURCE_ARCHIVE_SHA)
    audit.bind(HERE / "prove_pipeline.py", "c44e65a1e5fd48da36969ed76597720ec6fc5202e59c84f233f74253e34c894a")
    audit.bind(HERE / "proof-pipeline-b8-r24.json", "b03e2b0770cdf46c287ceae90c8ba7fa6e2c9f98e62fc2a5f340730232ddd825")
    parent_proof = read(HERE / "proof-pipeline-b8-r24.json")
    require(parent_proof["native_physical_equivalence_proved"] is True and
            parent_proof["gain_accepted_against_matched_main_baseline"] is True and
            parent_proof["completed_record_closure"]["current"]["run_sha256"] == RUNS["parent"][1] and
            parent_proof["completed_record_closure"]["selected"]["run_sha256"] == RUNS["parent_place"][1], "accepted B8 parent evidence differs")
    for filename, digest in parent_proof["artifact_sha256"].items():
        relative = Path(filename)
        require(not relative.is_absolute() and (ROOT / relative).resolve().is_relative_to(ROOT), "parent artifact escapes root")
        audit.bind(ROOT / relative, digest)
    for filename, digest in parent_proof["directly_rehashed_source_or_compiler_sha256"].items():
        audit.bind(Path(filename), digest, execution=True)
    listing_lines = (RUNS["listing"][0] / "trial.log").read_text().splitlines()
    require(listing_lines.count(CANDIDATE_LINE) == 1 and
            listing_lines.count("Info: LUT pair copy: 56 qualified candidates; no candidate applied.") == 1 and
            sum(line.startswith("Info: LUT pair copy candidate ") for line in listing_lines) == 56 and
            not any(line.startswith("Info: LUT pair copy applied candidate ") for line in listing_lines), "listing scope or rollback differs")
    retained = ["Info: Capture pipeline locality retained first=" + first + " second=" + second +
                "; routing and signoff still required." for first, second in PAIR_NAMES]
    for name in ("parent_place", "parent", "listing", "selected", "current"):
        lines = (RUNS[name][0] / "trial.log").read_text().splitlines()
        require([line for line in lines if line.startswith("Info: Capture pipeline locality retained ")] == retained and
                sum("eligible=8 retained_pairs=7 (route signoff still required)." in line for line in lines) == 1,
                "actual retained B8 pipeline manifest differs")
        if name in ("selected", "current"):
            require(lines.count(CANDIDATE_LINE) == 1 and lines.count(APPLIED_LINE) == 1 and
                    sum(line.startswith("Info: LUT pair copy applied candidate ") for line in lines) == 1 and
                    profiles[name]["capture_retained_lines"] == retained, "actual C0 application differs")
    return records, profiles, closure, parent_proof


def prove_placement(native, tables, documents, parent_proof):
    base, before, listed, after = [documents[name]["modules"]["top"]
                                   for name in ("baseline_place", "parent_place", "listing", "selected")]
    require(len(MOVED) == 14 and len(PAIR_NAMES) == 7 and len(base["cells"]) == len(before["cells"]) == 14893,
            "pipeline scope differs")
    require(set(base) == set(before) == set(after) == {"settings", "attributes", "ports", "cells", "netnames"}, "native placed module schema differs")
    for name in ("listing", "selected"):
        exact(native, documents["parent_place"]["creator"], documents[name]["creator"], "C0 placed creator metadata differs")
    exact(native, before, listed, "listing did not restore complete B8 placed frame")
    exact(native, before["cells"].pll_ports, listed["cells"].pll_ports, "listing PLL duplicate tokens changed")
    changes = []
    for key in ("settings", "attributes", "ports", "netnames"):
        exact(native, base[key], before[key], "B8 placement changed module " + key)
    require(list(base) == list(before) == list(after) and list(base["cells"]) == list(before["cells"]), "prior owner order changed")
    exact(native, base["cells"].pll_ports, before["cells"].pll_ports, "B8 ordered PLL tokens changed")
    for name, cell in base["cells"].items():
        actual = copy.deepcopy(before["cells"][name])
        old, new = cell["attributes"]["NEXTPNR_BEL"], actual["attributes"]["NEXTPNR_BEL"]
        if old != new:
            require(name in MOVED and cell["type"] == actual["type"] == "MISTRAL_FF", "undeclared B8 BEL move")
            actual["attributes"]["NEXTPNR_BEL"] = old
            changes.append({"cell": name, "before": old, "after": new})
        exact(native, cell, actual, "B8 changed original cell beyond declared FF BEL")
    require({row["cell"] for row in changes} == MOVED and changes == parent_proof["placement_native_proof"]["ff_bel_changes"] and
            tables.native_tables(base) == tables.native_tables(before), "prior fourteen FF moves/raw graph differ")
    for key in ("settings", "attributes", "ports"):
        exact(native, before[key], after[key], "C0 placement module " + key + " changed")
    require(set(after["cells"]) - set(before["cells"]) == {CLONE} and set(before["cells"]) <= set(after["cells"]) and
            [name for name in after["cells"] if name != CLONE] == list(before["cells"]) and
            set(after["netnames"]) - set(before["netnames"]) == {ALIAS} and set(before["netnames"]) <= set(after["netnames"]) and
            [name for name in after["netnames"] if name != ALIAS] == list(before["netnames"]), "C0 owner/alias closure or order differs")
    exact(native, before["cells"].pll_ports, after["cells"].pll_ports, "C0 ordered PLL tokens changed")
    for name, cell in before["cells"].items():
        actual = copy.deepcopy(after["cells"][name])
        if name == SINK:
            require(cell["type"] == actual["type"] == "MISTRAL_FF" and
                    cell["connections"]["ENA"] == [OLD_BIT] and actual["connections"]["ENA"] == [NEW_BIT], "C0 ENA selected raw bit differs")
            actual["connections"]["ENA"] = [OLD_BIT]
        exact(native, cell, actual, "C0 changed original graph/INIT/metadata/BEL beyond one ENA slot: " + name)
    for name, row in before["netnames"].items():
        exact(native, row, after["netnames"][name], "C0 changed original alias/raw bit/metadata")
    clone = after["cells"][CLONE]
    expected_clone = {"hide_name": 0, "type": "MISTRAL_ALUT4", "parameters": {"LUT": "0100010001000000"},
                      "attributes": {"BEL_STRENGTH": "00000000000000000000000000000001", "NEXTPNR_BEL": CLONE_BEL},
                      "port_directions": {"Q": "output", "D": "input", "C": "input", "B": "input", "A": "input"},
                      "connections": {"Q": [NEW_BIT], "D": [LEAVES[3]], "C": [LEAVES[2]], "B": [LEAVES[1]], "A": [LEAVES[0]]}}
    exact(native, expected_clone, clone, "exact clone native declaration differs")
    exact(native, {"hide_name": 0, "bits": [NEW_BIT], "attributes": {}}, net_shape(after["netnames"][ALIAS]), "clone alias differs")
    old_drivers, old_users = tables.native_tables(before)
    new_drivers, new_users = tables.native_tables(after)
    expected_drivers, expected_users = copy.deepcopy(old_drivers), copy.deepcopy(old_users)
    require(NEW_BIT not in old_drivers and NEW_BIT not in old_users and old_drivers[OLD_BIT] == [(OUTER, "Q", 0, 0)] and
            (SINK, "ENA", 0, 0) in old_users[OLD_BIT] and
            all(NEW_BIT not in row["bits"] for row in before["netnames"].values()) and
            all(NEW_BIT not in row["bits"] for row in before["ports"].values()), "clone output collides or old ENA driver differs")
    expected_drivers[NEW_BIT] = [(CLONE, "Q", 0, 0)]
    expected_users[OLD_BIT].remove((SINK, "ENA", 0, 0))
    expected_users[NEW_BIT] = [(SINK, "ENA", 0, 0)]
    for port, bit in zip("ABCD", LEAVES):
        expected_users.setdefault(bit, []).append((CLONE, port, 0, 0))
    require(expected_drivers == new_drivers and {bit: sorted(rows) for bit, rows in expected_users.items()} == new_users,
            "complete native raw driver/user slots differ beyond declared clone and single ENA redirect")
    inner, outer = before["cells"][INNER], before["cells"][OUTER]
    require(inner["type"] == "MISTRAL_ALUT2" and inner["parameters"] == {"LUT": "1011"} and
            outer["type"] == "MISTRAL_ALUT3" and outer["parameters"] == {"LUT": "00110010"} and
            [literal(inner, port) for port in "AB"] == list(LEAVES[:2]) and literal(inner, "Q") == 97446 and
            [literal(outer, port) for port in "ABC"] == [LEAVES[2], 97446, LEAVES[3]] and literal(outer, "Q") == OLD_BIT,
            "original composed function inputs/tables differ")
    truth = []
    for row in range(16):
        bits = [(row >> index) & 1 for index in range(4)]
        inner_value = (0xb >> (bits[0] | bits[1] << 1)) & 1
        original = (0x32 >> (bits[2] | inner_value << 1 | bits[3] << 2)) & 1
        composed = (0x4440 >> row) & 1
        require(original == composed, "exhaustive native composed truth differs")
        truth.append({"row": row, "leaf_values_ABCD": bits, "inner": inner_value, "original_outer": original, "clone": composed})
    ff_bels = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in before["cells"].items() if cell["type"] == "MISTRAL_FF"}
    return {"single_clone": CLONE, "clone_bel": CLONE_BEL, "single_redirect": {"cell": SINK, "port": "ENA", "old_raw_bit": OLD_BIT, "new_raw_bit": NEW_BIT},
            "prior_fourteen_ff_bel_moves_exact": changes, "all_original_ff_bels_preserved": ff_bels,
            "all_original_cell_count": len(before["cells"]), "all_original_netname_count": len(before["netnames"]),
            "original_full_graph_params_init_metadata_alias_order_ports_and_raw_slots_exact_except_declared_ena": True,
            "ordered_duplicate_pll_tokens_exact": True, "two_ff_pipeline_latency_unchanged": True,
            "retained_original_outer_users": [list(slot) for slot in new_users[OLD_BIT]],
            "clone_q_sole_consumer": [SINK, "ENA", 0, 0], "native_exhaustive_truth_16_rows": truth}


def route_ledger(native, tables, physical, place_doc, route_doc):
    """Explicit raw identity reconstruction, adapted from reviewed B8 lower code."""
    a, b = [document["modules"]["top"] for document in (place_doc, route_doc)]
    exact(native, place_doc["creator"], route_doc["creator"], "route creator differs")
    require(list(a) == list(b), "route module schema/order changed")
    exact(native, a["settings"], {key: value for key, value in b["settings"].items() if key in a["settings"]}, "route changed existing settings")
    attrs = copy.deepcopy(a["attributes"])
    require(attrs.get("step") == "place" and "FES_LABSTATE_V1" not in attrs, "frame is not native placed input")
    attrs["step"] = "route"
    exact(native, attrs, {key: value for key, value in b["attributes"].items() if key != "FES_LABSTATE_V1"}, "route top metadata changed")
    exact(native, a["ports"], b["ports"], "route interface changed")
    exact(native, a["cells"].pll_ports, b["cells"].pll_ports, "route PLL tokens changed")
    originals, original_nets = set(a["cells"]), set(a["netnames"])
    require(originals <= set(b["cells"]) and original_nets <= set(b["netnames"]), "route removed owner/alias")
    added, added_nets = set(b["cells"]) - originals, set(b["netnames"]) - original_nets
    require(not any(cell["type"] == "MISTRAL_BUF" for cell in a["cells"].values()) and
            [name for name in b["cells"] if name in originals] == list(a["cells"]) and
            [name for name in b["netnames"] if name in original_nets] == list(a["netnames"]), "route original order or initial BUF population differs")
    old_drivers, old_users = tables.native_tables(a)
    new_drivers, new_users = tables.native_tables(b)
    expected_cells = copy.deepcopy(dict(a["cells"]))
    expected_drivers, expected_users = copy.deepcopy(old_drivers), copy.deepcopy(old_users)
    view = physical.PhysicalView(b)
    rows, used = [], set()
    for name in sorted(added):
        cell = b["cells"][name]
        require(set(cell) == {"hide_name", "type", "parameters", "attributes", "port_directions", "connections"} and
                set(cell["attributes"]) == {"BEL_STRENGTH", "NEXTPNR_BEL", "FES_PINMAP_V1"} and cell["type"] == "MISTRAL_BUF" and
                cell["parameters"] == {} and cell["port_directions"] == {"A": "input", "Q": "output"} and
                set(cell["connections"]) == {"A", "Q"}, "undeclared route cell schema")
        q, bit = literal(cell, "Q"), literal(cell, "A")
        users = new_users.get(q)
        require(type(users) is list and len(users) == 1 and users[0][1:] == ("DATAIN", 0, 0), "BUF is not one exact FF DATAIN slot")
        ff, alias = users[0][0], name + "$conn$Q"
        require(ff in originals and ff not in used and name == ff + "$ROUTETHRU" and a["cells"][ff]["type"] == "MISTRAL_FF" and
                expected_cells[ff]["connections"]["DATAIN"] == [bit] and new_drivers.get(q) == [(name, "Q", 0, 0)] and
                len(old_drivers.get(bit, [])) == 1 and alias in added_nets and view.native.aliases.get(q) == [(alias, 0)] and
                b["netnames"][alias]["bits"] == [q] and not view.native.top_users.get(q), "BUF owner/raw bit/private alias differs")
        shape = physical._shape(view, name)
        truth = physical._truth(shape)
        require(shape["type"] == "MISTRAL_BUF" and shape["tables"] == [2] and shape["inputs"][0]["state"] == 0 and
                shape["pins"] == {"A": [0, "D" if shape["half"] else "C"], "Q": [0, "COMBOUT"]} and
                truth["rows"] == [{"row": 0, "Q": 0}, {"row": 1, "Q": 1}], "BUF packed physical truth is not identity")
        _, x, y, z = physical._location(cell)
        kind, fx, fy, fz = physical._location(b["cells"][ff])
        require(kind == "FF" and fz % 6 in (2, 4) and (x, y, z // 6, z % 6) == (fx, fy, fz // 6, (fz % 6 - 2) // 2), "BUF is not named FF half feedthrough")
        physical.evaluate_lut(view, name)
        used.add(ff)
        expected_cells[ff]["connections"]["DATAIN"] = [q]
        require(q not in expected_drivers and (ff, "DATAIN", 0, 0) in expected_users[bit], "BUF ledger collision")
        expected_drivers[q] = [(name, "Q", 0, 0)]
        expected_users[bit].remove((ff, "DATAIN", 0, 0))
        expected_users[bit].append((name, "A", 0, 0))
        expected_users[q] = [(ff, "DATAIN", 0, 0)]
        rows.append({"buffer": name, "ff": ff, "alias": alias, "input_raw_bit": bit, "output_raw_bit": q,
                     "input_original_driver": list(old_drivers[bit][0]), "bel": cell["attributes"]["NEXTPNR_BEL"], "actual_pins": shape["pins"], "physical_truth": truth})
    require(added_nets == {row["alias"] for row in rows} and len(added) == len(rows) and
            expected_drivers == new_drivers and {bit: sorted(users) for bit, users in expected_users.items()} == new_users,
            "complete route raw tables/aliases exceed declared BUF substitutions")
    for name, expected in expected_cells.items():
        actual = copy.deepcopy(b["cells"][name])
        require("FES_PINMAP_V1" not in expected["attributes"] and type(actual["attributes"].get("FES_PINMAP_V1")) is str, "fresh routed physical pin map absent")
        actual["attributes"].pop("FES_PINMAP_V1")
        exact(native, expected, actual, "route changed original graph/INIT/metadata/BEL: " + name)
    for name, row in a["netnames"].items():
        exact(native, net_shape(row), net_shape(b["netnames"][name]), "route original alias/raw bits changed")
    return {"buffer_rows": rows, "buffer_count": len(rows), "all_original_raw_slots_and_metadata_reconstructed_exactly": True,
            "generated_buffer_identity_function_proved": True, "blanket_buffer_collapse_used": False}, view


def exported_lab_controls(physical, view, lab):
    selected, clears, clocks, sync = {}, {}, set(), {"SCLR": set(), "SLOAD": set()}
    rows = []
    for index in range(10):
        alm = physical.evaluate_alm(view, (*lab, index))
        halves = {}
        for ff in alm["ff_occupants"]:
            signature = {port: (tuple(row["driver"]) if row["driver"] else None, tuple(row["pins"])) for port, row in ff["controls"].items()}
            half = ff["half"]
            require(half not in halves or halves[half] == signature, "one FF half has incompatible control pins")
            halves[half] = signature
            clocks.add(signature["CLK"])
            ce, ac = ff["clk_ena_selector"], ff["aclr_selector"]
            require(type(ce) is int and 0 <= ce < 3 and type(ac) is int and 0 <= ac < 2, "selector outside physical slot range")
            control = signature["CLK"], signature["ENA"]
            require(ce not in selected or selected[ce] == control, "LAB selector has incompatible native controls")
            selected[ce] = control
            if ff["controls"]["ACLR"]["driver"] is not None:
                require(ac not in clears or clears[ac] == signature["ACLR"], "ACLR selector has incompatible controls")
                clears[ac] = signature["ACLR"]
            for port in sync:
                if ff["controls"][port]["driver"] is not None:
                    sync[port].add(signature[port])
        rows.append(alm)
    require(len(clocks) <= 1 and len(selected) <= 3 and len(clears) <= 2 and all(len(values) <= 1 for values in sync.values()), "whole-LAB control capacity exceeded")
    return rows


def normalize_selected_ena(ff, after):
    """Only the proven clone output replaces the selected FF ENA token/raw bit."""
    result = copy.deepcopy(ff)
    if result["cell"] == SINK:
        ena = result["controls"]["ENA"]
        require(ena["bits"] == [NEW_BIT if after else OLD_BIT] and
                ena["driver"] == ["cell", CLONE if after else OUTER, "Q", 0], "selected physical ENA is not the proven old/clone signal")
        if after:
            ena["bits"] = [OLD_BIT]
            ena["driver"] = ["cell", OUTER, "Q", 0]
    return result


def control_groups(native, alms, after):
    groups = {}
    for alm in alms:
        for raw in alm["ff_occupants"]:
            ff = normalize_selected_ena(raw, after)
            selector = ff["clk_ena_selector"]
            signature = {port: copy.deepcopy(ff["controls"][port]) for port in ("CLK", "ENA")}
            ena = signature["ENA"]
            require(bool(ena["bits"]) == (ena["driver"] is not None), "ENA connectedness/driver differs")
            if not ena["bits"]:
                require(ena["pins"][0] in (1, 2), "absent ENA is not explicit constant physical pin")
            if selector in groups:
                exact(native, groups[selector]["signature"], signature, "selector full logical signature differs")
            else:
                groups[selector] = {"signature": signature, "members": []}
            groups[selector]["members"].append(ff["cell"])
    for row in groups.values():
        row["members"].sort()
    return groups


def control_renumbering(native, old_alms, new_alms):
    old_groups, new_groups = control_groups(native, old_alms, False), control_groups(native, new_alms, True)
    mapping, changed, selected = {}, [], []
    for a, b in zip(old_alms, new_alms):
        old = {row["cell"]: row for row in a["ff_occupants"]}
        new = {row["cell"]: row for row in b["ff_occupants"]}
        require(set(old) == set(new), "whole ALM FF occupancy changed")
        for name in sorted(old):
            aa, bb = normalize_selected_ena(old[name], False), normalize_selected_ena(new[name], True)
            previous, current = aa.pop("clk_ena_selector"), bb.pop("clk_ena_selector")
            exact(native, aa, bb, "FF changed beyond selector and proven selected ENA: " + name)
            require(previous not in mapping or mapping[previous] == current, "one prior group split across selectors")
            mapping[previous] = current
            if previous != current:
                changed.append({"cell": name, "old_selector": previous, "new_selector": current, "unchanged_normalized_ff_record": aa})
            if name == SINK:
                selected.append({"before": old[name], "after": new[name], "independent_16_row_ena_equivalence_proved": True})
    require(len(set(mapping.values())) == len(mapping) and set(mapping) == set(old_groups) and set(mapping.values()) == set(new_groups), "control group mapping is not complete and injective")
    rows = []
    for previous, current in sorted(mapping.items()):
        aa, bb = old_groups[previous], new_groups[current]
        exact(native, aa["signature"], bb["signature"], "whole-LAB normalized control signature changed")
        require(aa["members"] == bb["members"] and aa["members"], "whole-LAB control group membership changed")
        rows.append({"old_selector": previous, "new_selector": current, **aa})
    return {"all_old_groups": old_groups, "all_new_groups_after_single_proved_ena_substitution": new_groups,
            "consistent_complete_injective_mapping": rows, "all_changed_ff_selector_records": changed,
            "single_selected_ena_physical_records": selected, "actual_selector_to_routed_wire_mux_independently_proved": False}


def physical_proof(native, physical, before, after, old_ledger, new_ledger):
    require(before.device == after.device == "5CSEBA6U23I7" and set(before.labs) == set(after.labs), "physical device/LAB geometry differs")
    old_buffers = {row["buffer"]: row for row in old_ledger["buffer_rows"]}
    new_buffers = {row["buffer"]: row for row in new_ledger["buffer_rows"]}
    originals = set(before.cells) - set(old_buffers)
    require(set(after.cells) - set(new_buffers) == originals | {CLONE}, "routed original owner scope differs")
    labs = set()
    for name in (INNER, OUTER, SINK):
        for view in (before, after):
            _, x, y, _ = physical._location(view.cells[name])
            labs.add((x, y))
    require(after.cells[CLONE]["attributes"]["NEXTPNR_BEL"] == CLONE_BEL, "clone routed BEL changed")
    labs.add((19, 28))
    full_pin_maps = 0
    for name in sorted(originals):
        a, b = before.cells[name], after.cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and a["port_directions"] == b["port_directions"] and
                a["attributes"]["NEXTPNR_BEL"] == b["attributes"]["NEXTPNR_BEL"], "original routed type/INIT/BEL differs")
        exact(native, before.pins(name), after.pins(name), "original complete pin map changed: " + name)
        full_pin_maps += 1
    changed_buffers = []
    for name in sorted(set(old_buffers) | set(new_buffers)):
        a, b = old_buffers.get(name), new_buffers.get(name)
        same = bool(a and b and a["bel"] == b["bel"] and
                    native.canonical(physical.evaluate_lut(before, name)["lut"]) == native.canonical(physical.evaluate_lut(after, name)["lut"]))
        if not same:
            for view in (before, after):
                if name in view.cells:
                    _, x, y, _ = physical._location(view.cells[name])
                    labs.add((x, y))
            changed_buffers.append({"buffer": name, "before_identity": a, "after_identity": b})
    inside, outside = [], 0
    for lab in sorted(before.labs):
        require(before.labs[lab][:3] == after.labs[lab][:3], "LAB geometry kind changed")
        if lab not in labs:
            exact(native, before.labs[lab], after.labs[lab], "outside exact LAB state changed")
            for index in range(10):
                exact(native, sorted(before.occupants.get((*lab, index), [])), sorted(after.occupants.get((*lab, index), [])), "outside exact ALM occupancy changed")
                outside += 1
            continue
        old_alms, new_alms = exported_lab_controls(physical, before, lab), exported_lab_controls(physical, after, lab)
        controls = control_renumbering(native, old_alms, new_alms)
        for a, b in zip(old_alms, new_alms):
            old_banks = {row["cell"]: row for row in a["occupied_banks"] if row["cell"] in originals}
            new_banks = {row["cell"]: row for row in b["occupied_banks"] if row["cell"] in originals}
            exact(native, old_banks, new_banks, "original whole-ALM combinational bank/shared input function changed")
        inside.append({"lab": list(lab), "all_ten_alms_before": old_alms, "all_ten_alms_after": new_alms,
                       "explicit_complete_logical_control_renumbering": controls})
    old_shapes = [physical._shape(before, name) for name in (INNER, OUTER)]
    new_shapes = [physical._shape(after, name) for name in (INNER, OUTER, CLONE)]
    i, o = old_shapes
    ni, no, clone = new_shapes
    require((i["type"], o["type"], clone["type"], i["tables"], o["tables"], clone["tables"]) ==
            ("MISTRAL_ALUT2", "MISTRAL_ALUT3", "MISTRAL_ALUT4", [0xb], [0x32], [0x4440]), "routed physical composition tables differ")
    boundary = (physical._boundary(i) | physical._boundary(o)) - {i["outputs"]["Q"]}
    require(len(boundary) == 4 and physical._boundary(clone) == boundary and
            i["outputs"]["Q"] == ni["outputs"]["Q"] and o["outputs"]["Q"] == no["outputs"]["Q"] and
            before.scalar(SINK, "ENA", "input") == o["outputs"]["Q"] and
            after.scalar(SINK, "ENA", "input") == clone["outputs"]["Q"] and
            after.native.users[clone["outputs"]["Q"]] == [(SINK, "ENA", 0)], "physical boundary/selected ENA ownership differs")
    rows, boundary = [], sorted(boundary)
    for row in range(16):
        values = {token: (row >> index) & 1 for index, token in enumerate(boundary)}
        old = physical._read_shape(o, {**values, i["outputs"]["Q"]: physical._read_shape(i, values)})
        current_original = physical._read_shape(no, {**values, ni["outputs"]["Q"]: physical._read_shape(ni, values)})
        copied = physical._read_shape(clone, values)
        require(old == current_original == copied, "exhaustive routed pin-state composition truth differs")
        rows.append({"row": row, "original_before": old, "original_after": current_original, "clone_after": copied})
    return {"exported_physical_function_scope_proved": True, "all_original_full_pin_maps_exact": full_pin_maps,
            "affected_whole_labs": [list(lab) for lab in sorted(labs)], "affected_whole_lab_records": inside,
            "outside_exact_alm_count": outside, "explicit_changed_generated_buffers": changed_buffers,
            "all_generated_buffers_evaluated_as_identity": True, "physical_composition_boundary": [list(token) for token in boundary],
            "physical_exhaustive_truth_16_rows": rows, "original_inner_before": physical.evaluate_lut(before, INNER),
            "original_outer_before": physical.evaluate_lut(before, OUTER), "original_inner_after": physical.evaluate_lut(after, INNER),
            "original_outer_after": physical.evaluate_lut(after, OUTER), "clone_after": physical.evaluate_lut(after, CLONE),
            "whole_lab_modes_occupants_shared_inputs_control_capacity_and_original_banks_checked": True,
            "complete_placement_or_routing_legality_independently_proved": False,
            "unexported_pointer_cache_gpu_or_full_runtime_identity_proved": False, "route_mux_pip_cram_or_rbf_independently_decoded": False}


def paths(report):
    require(report.get("timing_report_paths") == 16384 and len(report["critical_paths"]) == 15290, "complete path count/cap differs")
    windows, endpoints, worst = {}, set(), {}
    for path in report["critical_paths"]:
        pair, window = (path["from"], path["to"]), path["max_delay"]
        require(type(window) in (int, float) and math.isfinite(window) and window > 0 and
                (pair not in windows or windows[pair] == window), "pair window inconsistent/nonfinite")
        windows[pair] = window
        end = path["path"][-1]["to"]
        endpoint = (*pair, end["cell"], end["port"])
        require(endpoint not in endpoints, "duplicate pair/endpoint")
        endpoints.add(endpoint)
        terms = [segment["delay"] for segment in path["path"]]
        require(all(type(term) in (int, float) and math.isfinite(term) for term in terms), "nonfinite segment delay")
        total = math.fsum(terms)
        require(math.isfinite(total), "nonfinite complete path sum")
        if pair not in worst or total > worst[pair]["complete_delay_ns"]:
            worst[pair] = {"complete_delay_ns": total, "headroom_ns": window - total, "actual_worst_path": path}
    require(len(windows) == 7 and len(endpoints) == 15290, "seven pair coverage differs")
    return windows, endpoints, worst


def timing_proof(tables, documents, reports):
    topologies = {name: tables.report_topology(documents[name], report, reports["baseline"]) for name, report in reports.items()}
    sets = {name: paths(report) for name, report in reports.items()}
    require(all(rows[:2] == sets["baseline"][:2] for rows in sets.values()), "complete native path pair/endpoint/window set differs")
    require(all(set(report["fmax"]) == set(CONSTRAINTS) and all(report["fmax"][clock]["constraint"] == constraint
                for clock, constraint in CONSTRAINTS.items()) for report in reports.values()), "required constraints differ")
    clocks = {}
    for clock, constraint in CONSTRAINTS.items():
        for name in EXPECTED_MHZ:
            row = reports[name]["fmax"][clock]
            require(set(row) == {"achieved", "constraint"} and row["achieved"] == EXPECTED_MHZ[name][clock] and
                    type(row["achieved"]) in (int, float) and math.isfinite(row["achieved"]), "bound final clock Fmax differs")
        current = reports["current"]["fmax"][clock]["achieved"]
        clocks[clock] = {"fresh_main_mhz": EXPECTED_MHZ["baseline"][clock], "b8_parent_mhz": EXPECTED_MHZ["parent"][clock],
                         "current_mhz": current, "gain_vs_b8_parent_mhz": current - EXPECTED_MHZ["parent"][clock],
                         "gain_vs_fresh_main_mhz": current - EXPECTED_MHZ["baseline"][clock], "constraint_mhz": constraint,
                         "constraint_passed": current >= constraint}
    require(clocks[MEMORY]["gain_vs_b8_parent_mhz"] > 0 and clocks[MEMORY]["gain_vs_fresh_main_mhz"] > 0 and
            all(clocks[clock]["constraint_passed"] for clock in (PIXEL, CAPTURE)), "target gain or mandatory pixel/capture constraint failed")
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    windows = []
    for pair, window in sorted(sets["current"][0].items()):
        row = sets["current"][2][pair]
        require(pair == target or row["headroom_ns"] > 0, "non-target full reported window failed")
        windows.append({"from": pair[0], "to": pair[1], "window_ns": window, **row,
                        "b8_parent_headroom_ns": sets["parent"][2][pair]["headroom_ns"],
                        "fresh_main_headroom_ns": sets["baseline"][2][pair]["headroom_ns"], "positive_headroom_required": pair != target})
    holds = {}
    for name in ("baseline", "parent", "current"):
        log = (RUNS[name][0] / ("route.log" if name == "baseline" else "trial.log")).read_text()
        require("Running signoff timing analysis..." in log and "Info: Program finished normally." in log and
                re.search(r"GPU router time [^\n]+backend hip:", log) and not any(line.startswith("ERROR:") for line in log.splitlines()), "completed HIP route/signoff evidence missing")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        warnings = [line for line in last.splitlines() if "Hold/min time violation" in line or
                    re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not warnings, "final signoff reports hold/min violation")
        holds[name] = {"last_signoff_hold_warning_lines": warnings, "final_reported_hold_violations": False}
    return {"passes_practical_target_memory_clock_gate_vs_b8_and_fresh_main": True, "clocks": clocks,
            "seven_pair_windows": windows, "all_six_non_target_windows_positive": True, "final_signoff_hold_evidence": holds,
            "all_clock_nonregression_vs_b8_parent": all(row["gain_vs_b8_parent_mhz"] >= 0 for row in clocks.values()),
            "all_clock_nonregression_vs_fresh_main": all(row["gain_vs_fresh_main_mhz"] >= 0 for row in clocks.values()),
            "native_report_topologies": topologies, "all_emitted_finite_complete_path_sums_checked": True,
            "complete_path_count": 15290, "old_path_delays_or_signoff_inherited": False,
            "independent_numerical_sta_or_unreported_pair_extrema_proved": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    args = parser.parse_args()
    require(DIGEST.fullmatch(args.self_sha256) and sha(__file__) == args.self_sha256 and HERE == RAW / "capture-pipeline-264",
            "actual self activation pin required")
    output = HERE / "proof-pipeline-c0.json"
    require(not output.exists() and not output.is_symlink(), "proof output already exists")
    native = load_pure(*HELPERS["native"], "pipeline_c0_native_pinned")
    audit = native.Audit()
    audit.bind(Path(__file__).resolve(), args.self_sha256)
    for path, digest in HELPERS.values():
        audit.bind(path, digest)
    freezer = types.ModuleType("pipeline_c0_isolated_freeze")
    freezer.require = require
    tables = load_pure(*HELPERS["tables"], "pipeline_c0_tables_pinned", freezer)
    physical = load_pure(*HELPERS["physical"], "pipeline_c0_physical_pinned")
    records, profiles, closure, parent_proof = authenticate(audit)
    documents, reports = {}, {}
    for name, (folder, _) in RUNS.items():
        documents[name] = native.read_netlist(folder / ("routed.json" if name in {"baseline", "parent", "current"} else "placed.json"))
        reports[name] = read(folder / "timing.json")
    placement = prove_placement(native, tables, documents, parent_proof)
    baseline_ledger, _ = route_ledger(native, tables, physical, documents["baseline_place"], documents["baseline"])
    parent_ledger, parent_view = route_ledger(native, tables, physical, documents["parent_place"], documents["parent"])
    current_ledger, current_view = route_ledger(native, tables, physical, documents["selected"], documents["current"])
    for name in ("parent", "current"):
        exact(native, documents["baseline"]["modules"]["top"]["settings"], documents[name]["modules"]["top"]["settings"], "routed settings/defaults differ")
    for name, bel in placement["all_original_ff_bels_preserved"].items():
        require(parent_view.cells[name]["attributes"]["NEXTPNR_BEL"] == current_view.cells[name]["attributes"]["NEXTPNR_BEL"] == bel,
                "original routed FF BEL moved after B8 parent")
    exported_physical = physical_proof(native, physical, parent_view, current_view, parent_ledger, current_ledger)
    reported_timing = timing_proof(tables, documents, reports)
    audit.finish()
    result = {"schema": 1, "scope": "one post-B8 composed ALUT4 copy and one ENA edge; prior fourteen FF placements preserved",
              "source_commit": SOURCE_COMMIT, "self_sha256": args.self_sha256,
              "native_physical_equivalence_proved": True, "gain_accepted_against_b8_pipeline_parent": True,
              "gain_accepted_against_matched_main_baseline": True, "placement_native_proof": placement,
              "fresh_main_explicit_route_buffer_ledger": baseline_ledger, "b8_parent_explicit_route_buffer_ledger": parent_ledger,
              "current_explicit_route_buffer_ledger": current_ledger, "exported_physical_proof": exported_physical,
              "reported_timing_proof": reported_timing, "completed_record_closure": closure,
              "artifact_sha256": audit.artifacts, "directly_rehashed_source_or_compiler_sha256": audit.execution,
              "pinned_pure_helper_sha256": {str(path): digest for path, digest in HELPERS.values()},
              "old_operational_main_authentication_generator_or_aggregate_evaluator_executed": False,
              "independent_live_pointer_cache_gpu_or_full_runtime_identity_proved": False,
              "independent_numerical_sta_proved": False, "cram_or_rbf_independently_decoded": False,
              "hardware_tested": False, "default_recipe_or_deployment_qualification_claimed": False,
              "frozen_117_869_stack_qualification_inherited": False,
              "limitations": [
                  "Physical claims use exported pin/LAB snapshots and packed truth, not independently decoded route muxes or RBF bytes.",
                  "Only the selected ENA driver/raw bit is replaced by the independently proved equivalent clone; full control signatures and memberships then establish complete injective selector renumbering.",
                  "The actual CLK/ENA selector-to-routed-wire reservation table is not exported or independently checked.",
                  "Exact serialized port slots do not prove live indexed-store allocation, pointers, caches, GPU IDs or full runtime identity.",
                  "Timing acceptance checks all emitted finite paths and final reported holds without independently recomputing numerical STA or unreported clock-pair extrema.",
                  "The qualified B8 parent record is pinned immutable evidence; no old operational helper is replayed, and the older 117.869 MHz stack is not a comparison baseline."]}
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"proof": str(output), "proof_sha256": sha(output), "native_physical_equivalence_proved": True,
                      "memory_gain_vs_b8_mhz": EXPECTED_MHZ["current"][MEMORY] - EXPECTED_MHZ["parent"][MEMORY],
                      "memory_gain_vs_fresh_main_mhz": EXPECTED_MHZ["current"][MEMORY] - EXPECTED_MHZ["baseline"][MEMORY]}, sort_keys=True))


if __name__ == "__main__":
    main()
