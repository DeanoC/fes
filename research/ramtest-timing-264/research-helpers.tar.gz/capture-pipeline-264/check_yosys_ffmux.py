#!/usr/bin/env python3
"""Configure/build only; tracked production plus all initialized submodule bytes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
WORK = Path('/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d')
HERE = WORK / 'out/ramtest-wide-reduction-264/capture-pipeline-264'
TOOL = WORK / 'sources/misteross/build/toolchain-ramtest-timing'
SOURCE = Path('/home/deano/kepler/worktrees/yosys-experiment-intel-alm-ffmux-264-6f6ea018')
BUILD = TOOL / 'build/yosys-ffmux-264'
BASE = '22bf145df1438aa46eb912beab5b5c19e491906a'
NEW_PASS = 'techlibs/intel_alm/intel_alm_ffmux.cc'
SUBMODULES = {'abc', 'libs/cxxopts', 'libs/fmt', 'libs/tomlplusplus', 'libs/boost_regex',
              'libs/slang', 'frontends/slang/lib', 'libs/symfpu',
              'frontends/slang/lib/third_party/slang', 'frontends/slang/lib/third_party/fmt'}
ENV = {k: v for k, v in os.environ.items() if k in {
    'PATH', 'HOME', 'TMPDIR', 'LD_LIBRARY_PATH', 'CMAKE_PREFIX_PATH', 'PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR'}}
ENV.update(LANG='C', LC_ALL='C')
COMMANDS = {
    'configure': ['cmake', '-S', str(SOURCE), '-B', str(BUILD), '-G', 'Ninja',
                  '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_C_COMPILER=/usr/bin/cc',
                  '-DCMAKE_CXX_COMPILER=/usr/bin/c++', '-DYOSYS_COMPONENTS=everything',
                  '-DYOSYS_USE_BUNDLED_LIBS=OFF', '-DYOSYS_WITHOUT_SLANG=OFF',
                  '-DYOSYS_WITHOUT_ABC=OFF', '-DYOSYS_ABC_EXECUTABLE=',
                  '-DYOSYS_ENABLE_UNIT_TESTS=OFF', '-DYOSYS_ENABLE_FUNCTIONAL_TESTS=OFF',
                  '-DCMAKE_INSTALL_PREFIX=' + str(TOOL / 'install')],
    'build': ['cmake', '--build', str(BUILD), '--parallel', '12', '--target', 'yosys', 'yosys-abc'],
}
def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()
def git(directory, *args):
    return subprocess.check_output(['git', '-C', str(directory), *args], env=ENV)
def inputs():
    files, modules = {}, {}
    def visit(directory, prefix='', expected=BASE):
        head = git(directory, 'rev-parse', 'HEAD').decode().strip()
        if head != expected:
            raise RuntimeError('source/submodule HEAD differs from its pinned gitlink: ' + prefix)
        if prefix:
            modules[prefix] = {'head': head, 'expected_gitlink': expected}
            if git(directory, 'ls-files', '--others', '--exclude-standard', '-z'):
                raise RuntimeError('unexpected untracked submodule source files: ' + prefix)
        for item in git(directory, 'ls-files', '--stage', '-z').split(b'\0'):
            if not item:
                continue
            metadata, raw_name = item.split(b'\t', 1)
            mode, oid, stage = metadata.decode().split()
            name = os.fsdecode(raw_name)
            if stage != '0':
                raise RuntimeError('unmerged source index')
            if not prefix and name.startswith('tests/'):
                continue
            path, full_name = directory / name, prefix + name
            if mode == '160000':
                if not (path / '.git').exists():
                    raise RuntimeError('uninitialized submodule: ' + full_name)
                visit(path, full_name + '/', oid)
            else:
                files[full_name] = {'sha256': sha(path), 'mode': mode,
                                    'symlink': os.readlink(path) if path.is_symlink() else None}
    visit(SOURCE)
    if {name.rstrip('/') for name in modules} != SUBMODULES:
        raise RuntimeError('initialized submodule set differs from the expected ten')
    extras = {os.fsdecode(v) for v in git(SOURCE, 'ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
              if v and not os.fsdecode(v).startswith('tests/')}
    if extras - {NEW_PASS}:
        raise RuntimeError('unexpected untracked non-test source files')
    files[NEW_PASS] = {'sha256': sha(SOURCE / NEW_PASS), 'mode': 'new-or-tracked', 'symlink': None}
    return {'source_head': BASE, 'files': files, 'submodules': modules,
            'coverage': 'Top-level tracked tests excluded; new test files excluded; all tracked submodule files included.'}
def write(path, document):
    temporary = path.with_suffix('.pending')
    with temporary.open('x') as stream:
        json.dump(document, stream, indent=2, sort_keys=True)
        stream.write('\n')
    temporary.replace(path)
def main():
    if len(sys.argv) != 4 or sys.argv[1] not in COMMANDS:
        raise SystemExit('usage: check_yosys_ffmux.py configure|build NEW_LABEL SCRIPT_SHA256')
    stage, label, expected = sys.argv[1:]
    if sha(__file__) != expected or not label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label):
        raise RuntimeError('recorder pin or new label invalid')
    directory = HERE / ('yosys-ffmux-check-' + label)
    directory.mkdir(exist_ok=False)
    record, log = directory / 'record.json', directory / 'output.log'
    binding = BUILD / 'ffmux-configure-binding.json'
    cache = BUILD / 'CMakeCache.txt'
    started = time.time()
    document = {'schema': 'yosys-ffmux-build-check-v1', 'stage': stage, 'state': 'running',
                'recorder_sha256': expected, 'command': COMMANDS[stage], 'cwd': str(SOURCE),
                'started_unix': started, 'exit_code': None, 'completed_normally': False,
                'environment_keys': sorted(ENV), 'environment_sha256': hashlib.sha256(
                    json.dumps(ENV, sort_keys=True).encode()).hexdigest(),
                'tests_run': False, 'gain_qualified': False, 'hardware': False, 'compiled_commit_asserted': False}
    write(record, document)
    print(json.dumps({'stage': stage, 'state': 'running', 'record': str(record)}), flush=True)
    try:
        selected = inputs()
        document['inputs_before'] = selected
        config_binding = {'recorder_sha256': expected, 'inputs': selected, 'command': COMMANDS['configure'],
                          'environment_sha256': document['environment_sha256']}
        if stage == 'configure' and BUILD.exists():
            raise RuntimeError('configure requires a fresh build directory')
        if stage == 'build':
            config_binding['cache_sha256'] = sha(cache)
        if stage == 'build' and json.loads(binding.read_text()) != config_binding:
            raise RuntimeError('build requires this recorder/source configure binding')
        with log.open('xb') as stream:
            result = subprocess.run(COMMANDS[stage], cwd=SOURCE, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        document.update(exit_code=result.returncode, completed_normally=True)
        document['inputs_after'] = inputs()
        document['recorder_after_sha256'] = sha(__file__)
        document['inputs_unchanged'] = selected == document['inputs_after'] and sha(__file__) == expected
        document['cache_sha256'] = sha(cache)
        if stage == 'build':
            document['inputs_unchanged'] &= document['cache_sha256'] == config_binding['cache_sha256']
            document['executables'] = {name: sha(BUILD / name) for name in ('yosys', 'yosys-abc')}
            for name in document['executables']:
                with (BUILD / name).open('rb') as stream:
                    if stream.read(4) != b'\x7fELF':
                        raise RuntimeError('build output is not ELF: ' + name)
            document['share_files'] = {str(p.relative_to(BUILD)): sha(p) for p in sorted((BUILD / 'share').rglob('*')) if p.is_file()}
            for name in ('dff_sim.v', 'dff_map.v', 'alm_sim.v', 'abc9_map.v', 'abc9_model.v', 'abc9_unmap.v'):
                if sha(BUILD / 'share/intel_alm/common' / name) != sha(SOURCE / 'techlibs/intel_alm/common' / name):
                    raise RuntimeError('native model/share copy differs from selected source: ' + name)
            document['build_shared_libraries'] = {str(p.relative_to(BUILD)): sha(p) for p in sorted(BUILD.rglob('*.so*')) if p.is_file()}
        document['state'] = 'passed' if result.returncode == 0 and document['inputs_unchanged'] else 'failed'
        if stage == 'configure' and document['state'] == 'passed':
            config_binding['cache_sha256'] = document['cache_sha256']
            write(binding, config_binding)
        if binding.is_file():
            document['configure_binding_sha256'] = sha(binding)
    except BaseException as error:
        document['state'] = 'failed'
        document['error_type'] = type(error).__name__
        document['error'] = str(error)
    finally:
        document['log_sha256'] = sha(log) if log.is_file() else None
        document['finished_unix'] = time.time()
        document['elapsed_seconds'] = document['finished_unix'] - started
        write(record, document)
        print(json.dumps({'stage': stage, 'state': document['state'], 'exit_code': document['exit_code'],
                          'record_sha256': sha(record), 'elapsed_seconds': document['elapsed_seconds']}), flush=True)
    return 0 if document['state'] == 'passed' else 1
if __name__ == '__main__':
    sys.exit(main())
