"""Record one fresh post-capture LUT-pair compose-copy listing; no acceptance."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
PREFIX = HERE / "clock-group-pipeline-placed-b8-r24"
RUN_SHA = "95eb2f478408d8b65fb0127cd8404a3f97f2377a9c819aff31e8d2b81076b8df"
PROFILE_SHA = "9f770cfb10603b58bc7977d51854f6f79ab2980ea35f0c62374094631ecc959b"
GUIDE_SHA = "18aecabd79f697c0f010ce0339349bbdd34c94e32814194b90a9610068cb980b"
BINARY_SHA = "4db58a6de261b8542cce2c50f969f1f7b23b2c9c92150fa9a80697f88d185c27"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    args = parser.parse_args()
    require(sha(__file__) == args.self_sha256, "recorder bytes changed")
    require(sha(PREFIX / "run.json") == RUN_SHA and sha(PREFIX / "profile.json") == PROFILE_SHA,
            "completed prefix record changed")
    record = json.loads((PREFIX / "run.json").read_text())
    profile = json.loads((PREFIX / "profile.json").read_text())
    require(record["exit_code"] == 0 and record["production_and_input_bytes_stable"] is True,
            "prefix trial did not complete stably")
    require(sha(PREFIX / "timing.json") == GUIDE_SHA and
            record["output_sha256"]["timing.json"] == GUIDE_SHA and
            record["output_sha256"]["profile.json"] == PROFILE_SHA and
            record["profile_sha256"] == PROFILE_SHA and profile["binary_sha256"] == BINARY_SHA,
            "prefix guide/profile/compiler binding differs")
    output = HERE / "clock-group-pipeline-b8-pair-copy-list"
    require(not output.exists(), "listing output exists")
    command = list(profile["command"])
    require(command.count("--no-route") == 1 and "--rbf" not in command and
            not any(flag.startswith("--remap-") or flag.startswith("--balance-") for flag in command),
            "unexpected preceding transform or routing request")
    for flag, filename in (("--write", "placed.json"), ("--report", "timing.json")):
        require(command.count(flag) == 1, "missing or duplicate output option")
        command[command.index(flag) + 1] = str(output / filename)
    command.extend(("--remap-lut-pair-critical", str(PREFIX / "timing.json"),
                    "--remap-lut-pair-compose-copy", "--remap-lut-pair-candidate", "-1"))
    selected = dict(profile["environment"])
    require(set(selected) == {"NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY"},
            "unexpected prefix diagnostic environment")
    environment = {key: value for key, value in os.environ.items() if not key.startswith("NEXTPNR_")}
    environment.update({"LANG": "C", "LC_ALL": "C", "TZ": "UTC", **selected})
    capture_guide = Path(selected["NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY"].rsplit(" ", 2)[0])
    capture_guide_sha = profile["guide_sha256"]

    def stable():
        return (sha(__file__) == args.self_sha256 and sha(command[0]) == BINARY_SHA and
                sha(PREFIX / "run.json") == RUN_SHA and sha(PREFIX / "profile.json") == PROFILE_SHA and
                sha(PREFIX / "timing.json") == GUIDE_SHA and sha(capture_guide) == capture_guide_sha and
                all(sha(path) == expected for path, expected in profile["production_source_sha256"].items()) and
                all(sha(WORK / path) == expected for path, expected in profile["input_sha256"].items()))
    require(stable(), "prefix/runtime source/input bytes changed")
    output.mkdir()
    new_profile = dict(profile, role="exploratory post-capture listing; not timing acceptance",
                       helper_sha256=args.self_sha256, command=command,
                       preceding_profile_sha256=PROFILE_SHA, preceding_run_sha256=RUN_SHA,
                       pair_guide_sha256=GUIDE_SHA)
    (output / "profile.json").write_text(json.dumps(new_profile, indent=2, sort_keys=True) + "\n")
    started = time.monotonic()
    with (output / "trial.log").open("x") as stream:
        result = subprocess.run(command, cwd=profile["cwd"], env=environment,
                                stdout=stream, stderr=subprocess.STDOUT)
    unchanged = stable()
    new_record = dict(schema=1, profile_sha256=sha(output / "profile.json"),
                      exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                      production_and_input_bytes_stable=unchanged,
                      output_sha256={path.name: sha(path) for path in sorted(output.iterdir()) if path.is_file()},
                      native_physical_equivalence_proved=False, gain_accepted=False, hardware_tested=False)
    with (output / "run.json").open("x") as stream:
        stream.write(json.dumps(new_record, indent=2, sort_keys=True) + "\n")
    print(json.dumps(dict(run_sha256=sha(output / "run.json"), exit_code=result.returncode, stable=unchanged)))
    require(unchanged and result.returncode == 0, "listing failed or bound bytes changed")


if __name__ == "__main__":
    main()
