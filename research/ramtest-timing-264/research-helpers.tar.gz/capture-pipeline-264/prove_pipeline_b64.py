#!/usr/bin/env python3
"""Independent exported-native/physical proof of thirty-seven two-FF relocations.

Only pinned pure parsers/evaluators are called. No compiler, router, old helper
main, generator, authentication routine or operational evaluator is replayed.
The exported physical proof does not decode route muxes, CRAM or the RBF.
"""
import argparse
import builtins
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import tarfile
import types

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
ROOT = HERE.parents[2]
PUB = RAW / "lut-pair-copies-publication-264"
DIGEST = re.compile(r"[0-9a-f]{64}")
RUNS = {
    "baseline": (PUB / "main-baseline", "3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c"),
    "baseline_place": (PUB / "main-baseline-placed", "0ba98d9e976bc8488349cb274b46afe935e6a636641659087bb16a6727e91e06"),
    "disabled": (HERE / "disabled-placed", "78d13714ab25be78254f5a4bc670202bd5d771f5529c7b1570dc9a1642edaa7b"),
    "selected": (HERE / "clock-group-pipeline-placed-b64-r24", "5f4580dc0d11c66d0bbc3b14ea7be977302fc8fed5ee89cab36abcedeb22250f"),
    "current": (HERE / "clock-group-pipeline-route-b64-r24", "3305e36039e6263c03d6bdd63670b523318678cddd558d2136e0f22dc310e38e"),
}
HELPERS = {
    "native": (RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"),
    "selected": (RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"),
    "freeze": (RAW / "driver-copy-selected-264/freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"),
    "physical": (RAW / "local-multicopy-ready1-address-route-proof-264/physical.py", "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"),
    "timing": (RAW / "driver-copy-ready-groups8-proof-264/timing.py", "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"),
}
CURRENT_BINARY_SHA = "4db58a6de261b8542cce2c50f969f1f7b23b2c9c92150fa9a80697f88d185c27"
INITIAL_BINARY_SHA = "13b52d1fc5d44a090ea412423260e3a666dfa4aa625dd03776c865a784bc0d7b"
INITIAL_ARCHIVE_SHA = "a9f4719c9c08a20abe851b1e238633866c7777fded6b32161232be82d77a3964"
INITIAL_SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-experiment-mistral-capture-pipeline-264-54cde5d3")
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
TARGET_MHZ = 105.77532958984375
EXPECTED_MHZ = 106.1233139038086
GUIDE_SHA = "d117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512"
PAIR_NAMES = (
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_16", "ddr1_rdata_MISTRAL_FF_Q_15"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_15", "ddr0_rdata_MISTRAL_FF_Q_121"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_47", "ddr0_rdata_MISTRAL_FF_Q_3"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_19", "ddr0_rdata_MISTRAL_FF_Q_27"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_79", "ddr0_rdata_MISTRAL_FF_Q_28"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_101", "ddr0_rdata_MISTRAL_FF_Q_37"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_16", "ddr0_rdata_MISTRAL_FF_Q_122"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_103", "ddr0_rdata_MISTRAL_FF_Q_39"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_75", "ddr0_rdata_MISTRAL_FF_Q_24"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_77", "ddr0_rdata_MISTRAL_FF_Q_25"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_93", "ddr0_rdata_MISTRAL_FF_Q_31"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_99", "ddr0_rdata_MISTRAL_FF_Q_35"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_21", "ddr0_rdata_MISTRAL_FF_Q_111"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_39", "ddr0_rdata_MISTRAL_FF_Q_2"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_10", "ddr0_rdata_MISTRAL_FF_Q_117"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_49", "ddr0_rdata_MISTRAL_FF_Q_4"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_34", "ddr0_rdata_MISTRAL_FF_Q"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_55", "ddr0_rdata_MISTRAL_FF_Q_7"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_20", "ddr0_rdata_MISTRAL_FF_Q_112"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_59", "ddr0_rdata_MISTRAL_FF_Q_9"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_7", "ddr0_rdata_MISTRAL_FF_Q_115"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_64", "ddr0_rdata_MISTRAL_FF_Q_13"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_125", "ddr0_rdata_MISTRAL_FF_Q_113"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_102", "ddr0_rdata_MISTRAL_FF_Q_38"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_5", "ddr0_rdata_MISTRAL_FF_Q_114"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_100", "ddr0_rdata_MISTRAL_FF_Q_36"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_72", "ddr0_rdata_MISTRAL_FF_Q_21"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q", "ddr0_rdata_MISTRAL_FF_Q_60"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_52", "ddr0_rdata_MISTRAL_FF_Q_6"),
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_11", "ddr1_rdata_MISTRAL_FF_Q_10"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_35", "ddr0_rdata_MISTRAL_FF_Q_1"),
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_2", "ddr1_rdata_MISTRAL_FF_Q"),
    ("hps_ddr.port0.returned_data_MISTRAL_FF_Q_105", "ddr0_rdata_MISTRAL_FF_Q_41"),
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_19", "ddr1_rdata_MISTRAL_FF_Q_18"),
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_23", "ddr1_rdata_MISTRAL_FF_Q_22"),
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_31", "ddr1_rdata_MISTRAL_FF_Q_30"),
    ("hps_ddr.port1.returned_data_MISTRAL_FF_Q_44", "ddr1_rdata_MISTRAL_FF_Q_43"),
)
MOVED = {name for pair in PAIR_NAMES for name in pair}
FF_PORTS = {port: "input" for port in ("SLOAD", "SDATA", "SCLR", "ENA", "DATAIN", "CLK", "ACLR")} | {"Q": "output"}


def require(value, reason):
    if not value:
        raise ValueError("capture-pipeline proof: " + reason)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON: " + value)))


def load_pure(path, expected, name, freezer=None):
    """Isolate the selected helper's import; never execute its freeze module."""
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and sha(path) == expected and name not in sys.modules,
            "pinned pure helper changed or name occupied")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    allowed = {"argparse", "builtins", "collections", "copy", "hashlib", "importlib", "json", "math", "pathlib", "re", "sys"}
    def local_import(requested, globals=None, locals=None, fromlist=(), level=0):
        require(level == 0, "relative helper import is forbidden")
        if requested == "freeze":
            require(freezer is not None, "unexpected freeze import")
            return freezer
        require(requested.split(".")[0] in allowed, "unexpected helper import: " + requested)
        return builtins.__import__(requested, globals, locals, fromlist, level)
    module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(sha(path) == expected, "pure helper changed while loading")
    return module


def order(value):
    if isinstance(value, dict):
        return [(key, order(item)) for key, item in value.items()]
    if isinstance(value, list):
        return [order(item) for item in value]
    return None


def exact(native, before, after, reason, ordered=True):
    require(native.canonical(before) == native.canonical(after), reason)
    if ordered:
        require(order(before) == order(after), reason + " (export order)")


def literal(cell, port):
    value = cell["connections"][port]
    require(type(value) is list and len(value) == 1 and type(value[0]) is int and value[0] >= 0,
            "nonliteral scalar port: " + port)
    return value[0]


def net_shape(row):
    result = copy.deepcopy(row)
    result.get("attributes", {}).pop("ROUTING", None)
    return result


def command_shape(command):
    require(type(command) is list and command and all(type(item) is str for item in command), "invalid recorded command")
    result, index = [], 1
    while index < len(command):
        flag = command[index]
        if flag in {"--write", "--report", "--rbf"}:
            require(index + 1 < len(command), "missing output command operand")
            index += 2
        elif flag == "--no-route":
            index += 1
        else:
            result.append(flag)
            index += 1
    require(not any(flag.startswith(("--remap-", "--balance-")) for flag in result), "undeclared graph transform flag")
    return result


def authenticate_records(audit):
    records, profiles, closure = {}, {}, {}
    helper_paths = {"baseline": PUB / "main_baseline.py", "baseline_place": PUB / "main_baseline_placement.py",
                    "disabled": HERE / "trial.py", "selected": HERE / "trial_clock_group.py", "current": HERE / "trial_clock_group.py"}
    for name, (folder, expected) in RUNS.items():
        audit.bind(folder / "run.json", expected)
        record = read(folder / "run.json")
        require(record["exit_code"] == 0 and record["hardware_tested"] is False and
                record["gain_accepted"] is False and record["native_physical_equivalence_proved"] is False,
                "record is not the pinned successful exploratory trial: " + name)
        require(type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
                record["elapsed_seconds"] > 0, "invalid recorded elapsed time")
        outputs = record["output_sha256"]
        expected_outputs = ({"routed.json", "timing.json", "core.rbf", "route.log"} if name == "baseline" else
                            {"placed.json", "timing.json", "profile.json", "placement.log"} if name == "baseline_place" else
                            {"routed.json", "timing.json", "profile.json", "trial.log", "core.rbf"} if name == "current" else
                            {"placed.json", "timing.json", "profile.json", "trial.log"})
        require(set(outputs) == expected_outputs, "recorded output closure differs: " + name)
        for filename, digest in outputs.items():
            require(Path(filename).name == filename and DIGEST.fullmatch(digest), "invalid output ledger member")
            audit.bind(folder / filename, digest)
        if name == "baseline":
            require(record["completed_normally"] is True and record["original_production_and_input_bytes_stable"] is True,
                    "baseline completion/source stability missing")
            profile = record
        else:
            require(record.get("production_and_input_bytes_stable", record.get("original_production_and_input_bytes_stable")) is True,
                    "trial source/input stability missing: " + name)
            require(record["profile_sha256"] == outputs["profile.json"], "profile/output hash disagreement")
            profile = read(folder / "profile.json")
            require(profile["baseline_sha256"] == RUNS["baseline"][1], "profile baseline differs")
        require(type(profile["production_source_sha256"]) is dict and len(profile["production_source_sha256"]) >= 1199,
                "recorded production source closure is incomplete")
        require(type(profile["input_sha256"]) is dict and len(profile["input_sha256"]) == 3, "functional input closure differs")
        for filename, digest in profile["input_sha256"].items():
            relative = Path(filename)
            require(not relative.is_absolute() and (ROOT / relative).resolve().is_relative_to(ROOT), "input path escapes ROOT")
            audit.bind(ROOT / relative, digest)
        for filename, digest in profile["production_source_sha256"].items():
            require(Path(filename).is_absolute() and DIGEST.fullmatch(digest), "invalid recorded production member")
        require(DIGEST.fullmatch(profile["binary_sha256"]) and DIGEST.fullmatch(profile["helper_sha256"]), "invalid execution/recorder digest")
        audit.bind(helper_paths[name], profile["helper_sha256"])
        records[name], profiles[name] = record, profile
        closure[name] = {"run_sha256": expected, "profile_sha256": record.get("profile_sha256"),
                         "binary_sha256": profile["binary_sha256"], "production_source_sha256": profile["production_source_sha256"],
                         "input_sha256": profile["input_sha256"], "output_sha256": outputs,
                         "completed_recorder_reported_source_input_stability": True,
                         "historical_mutable_binary_and_source_bytes_rehashed": False}
    base = profiles["baseline"]
    for name, profile in profiles.items():
        require(profile["input_sha256"] == base["input_sha256"] and profile["cwd"] == base["cwd"] and
                command_shape(profile["command"]) == command_shape(base["command"]), "fixed command/input/cwd differs: " + name)
    guide = str(RUNS["baseline_place"][0] / "timing.json") + " 64 24"
    for name in ("selected", "current"):
        require(profiles[name]["environment"] == {"NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY": guide} and
                profiles[name]["guide_sha256"] == GUIDE_SHA and profiles[name]["binary_sha256"] == CURRENT_BINARY_SHA,
                "selected/current clock-group profile differs")
    exact_profile_keys = ("binary_sha256", "production_source_sha256", "input_sha256", "helper_sha256", "environment", "guide_sha256", "cwd")
    require(all(profiles["selected"][key] == profiles["current"][key] for key in exact_profile_keys),
            "placed/current compiler or source selection differs")
    require(profiles["disabled"]["environment"] == {}, "disabled trial enabled a locality mode")
    for name in ("baseline", "baseline_place", "selected", "current"):
        for filename, digest in profiles[name]["production_source_sha256"].items():
            audit.bind(Path(filename), digest, execution=True)
        audit.bind(Path(profiles[name]["command"][0]), profiles[name]["binary_sha256"], execution=True)
        closure[name]["historical_mutable_binary_and_source_bytes_rehashed"] = True
    archive = HERE / "initial-source.tar.gz"
    retained_binary = HERE / "initial-nextpnr-mistral"
    audit.bind(archive, INITIAL_ARCHIVE_SHA)
    audit.bind(retained_binary, INITIAL_BINARY_SHA)
    require(profiles["disabled"]["binary_sha256"] == INITIAL_BINARY_SHA, "retained initial ELF is not the disabled run compiler")
    archived, live = {}, {}
    with tarfile.open(archive, "r:gz") as saved:
        members, original_names = {}, set()
        for member in saved.getmembers():
            require(member.name not in original_names, "duplicate source archive member name")
            original_names.add(member.name)
            name = member.name[2:] if member.name.startswith("./") else member.name
            if name in ("", "."):
                continue
            relative = Path(name)
            require(not relative.is_absolute() and ".." not in relative.parts and name not in members,
                    "ambiguous/escaping retained source archive member")
            members[name] = member
        require(len(original_names) == 2465, "retained source archive closure member count differs")
        for filename, digest in profiles["disabled"]["production_source_sha256"].items():
            path = Path(filename)
            member = members.get(path.relative_to(INITIAL_SOURCE).as_posix()) if path.is_relative_to(INITIAL_SOURCE) else None
            if member is not None:
                require(member.isfile(), "recorded source path is not a regular retained member")
                with saved.extractfile(member) as stream:
                    actual = hashlib.file_digest(stream, "sha256").hexdigest()
                require(actual == digest, "retained initial source member bytes differ: " + filename)
                archived[filename] = digest
            else:
                audit.bind(path, digest, execution=True)
                live[filename] = digest
    require(len(archived) == 932 and len(live) == 268, "initial source archive/live closure partition differs")
    closure["disabled"].update({"historical_mutable_binary_and_source_bytes_rehashed": True,
                               "retained_binary_path": str(retained_binary), "retained_binary_sha256": INITIAL_BINARY_SHA,
                               "retained_source_archive_path": str(archive), "retained_source_archive_sha256": INITIAL_ARCHIVE_SHA,
                               "retained_regular_source_member_sha256": archived, "direct_live_external_source_sha256": live,
                               "source_archive_extracted_or_executed": False})
    return records, profiles, closure


def prove_placement(native, tables, documents):
    base = documents["baseline_place"]["modules"]["top"]
    disabled = documents["disabled"]["modules"]["top"]
    selected = documents["selected"]["modules"]["top"]
    require(len(MOVED) == 74 and len(PAIR_NAMES) == 37, "pair declarations overlap")
    exact(native, base, disabled, "disabled placement differs from independent publication guide")
    exact(native, base["cells"].pll_ports, disabled["cells"].pll_ports,
          "disabled placement lossless ordered PLL outputs differ from publication guide")
    for key in ("settings", "attributes", "ports", "netnames"):
        exact(native, disabled[key], selected[key], "placement module " + key + " changed")
    require(set(disabled) == set(selected) == {"settings", "attributes", "ports", "cells", "netnames"} and
            list(disabled) == list(selected) and list(disabled["cells"]) == list(selected["cells"]), "placement owner/module schema changed")
    exact(native, disabled["cells"].pll_ports, selected["cells"].pll_ports, "lossless ordered PLL outputs changed")
    changes = []
    for name, before in disabled["cells"].items():
        after = copy.deepcopy(selected["cells"][name])
        old_bel, new_bel = before["attributes"].get("NEXTPNR_BEL"), after["attributes"].get("NEXTPNR_BEL")
        if old_bel != new_bel:
            require(name in MOVED and before["type"] == after["type"] == "MISTRAL_FF", "undeclared placement change: " + name)
            after["attributes"]["NEXTPNR_BEL"] = old_bel
            changes.append({"cell": name, "before": old_bel, "after": new_bel})
        exact(native, before, after, "original complete cell changed beyond declared FF BEL: " + name)
    require({row["cell"] for row in changes} == MOVED, "exact seventy-four changed FF manifest differs")
    require(tables.native_tables(disabled) == tables.native_tables(selected), "complete indexed native drivers/users changed at placement")
    old_native, new_native = [documents["_physical"].Native(top) for top in (disabled, selected)]
    pair_rows = []
    for first, second in PAIR_NAMES:
        for view in (old_native, new_native):
            for name in (first, second):
                cell = view.cells[name]
                require(cell["type"] == "MISTRAL_FF" and cell["parameters"] == {} and cell["port_directions"] == FF_PORTS and
                        set(cell["connections"]) == set(FF_PORTS), "moved FF full native schema/params differ")
                require(all(cell["connections"][port] == [] for port in ("ENA", "ACLR", "SCLR", "SLOAD", "SDATA")), "moved FF is not plain")
                for port in ("DATAIN", "Q", "CLK"):
                    literal(cell, port)
            q = view.token(literal(view.cells[first], "Q"))
            require(view.users[q] == [(second, "DATAIN", 0)] and
                    literal(view.cells[first], "Q") == literal(view.cells[second], "DATAIN") and
                    view.cells[first]["connections"]["CLK"] == view.cells[second]["connections"]["CLK"] and
                    view.users.get(view.token(literal(view.cells[second], "Q"))), "plain two-register chain/clock/users differ")
            source = view.token(literal(view.cells[first], "DATAIN"))
            require(source[0] == "cell" and view.cells[source[1]]["type"] == "cyclonev_hps_interface_fpga2sdram",
                    "first stage is not the actual registered HPS boundary")
        pair_rows.append({"first": first, "second": second, "clock_raw_bit": literal(disabled["cells"][first], "CLK"),
                          "source": list(old_native.token(literal(disabled["cells"][first], "DATAIN"))),
                          "first_q_sole_second_datain_consumer": True, "plain_two_register_latency_unchanged": True})
    return {"exact_original_cell_count": len(disabled["cells"]), "exact_original_netname_count": len(disabled["netnames"]),
            "full_graph_params_directions_metadata_alias_ports_raw_slots_exact": True,
            "lossless_ordered_pll_exact": True, "ff_bel_changes": changes, "disjoint_pairs": pair_rows,
            "global_numeric_renaming_or_buffer_collapse_used": False}


def route_ledger(native, tables, physical, place_doc, route_doc):
    a, b = place_doc["modules"]["top"], route_doc["modules"]["top"]
    require(list(a) == list(b) and set(a) == {"settings", "attributes", "ports", "cells", "netnames"}, "route module frame differs")
    require(set(a["settings"]) <= set(b["settings"]), "route dropped placement settings")
    exact(native, a["settings"], {key: value for key, value in b["settings"].items() if key in a["settings"]}, "route changed existing settings")
    attrs = copy.deepcopy(a["attributes"])
    require(attrs.get("step") == "place" and "FES_LABSTATE_V1" not in attrs, "input is not a native placed frame")
    attrs["step"] = "route"
    exact(native, attrs, {key: value for key, value in b["attributes"].items() if key != "FES_LABSTATE_V1"}, "route top metadata changed")
    exact(native, a["ports"], b["ports"], "route top interface changed")
    exact(native, a["cells"].pll_ports, b["cells"].pll_ports, "route lossless PLL outputs changed")
    original_cells, original_nets = set(a["cells"]), set(a["netnames"])
    require(original_cells <= set(b["cells"]) and original_nets <= set(b["netnames"]), "route removed an original owner/alias")
    added_cells, added_nets = set(b["cells"]) - original_cells, set(b["netnames"]) - original_nets
    require(not any(cell["type"] == "MISTRAL_BUF" for cell in a["cells"].values()) and
            [name for name in b["cells"] if name in original_cells] == list(a["cells"]) and
            [name for name in b["netnames"] if name in original_nets] == list(a["netnames"]), "original route owner order or starting BUF population differs")
    old_drivers, old_users = tables.native_tables(a)
    new_drivers, new_users = tables.native_tables(b)
    expected_cells = copy.deepcopy(dict(a["cells"]))
    expected_drivers, expected_users = copy.deepcopy(old_drivers), copy.deepcopy(old_users)
    view = physical.PhysicalView(b)
    rows, used_ffs = [], set()
    for name in sorted(added_cells):
        cell = b["cells"][name]
        require(set(cell) == {"hide_name", "type", "parameters", "attributes", "port_directions", "connections"} and
                set(cell["attributes"]) == {"BEL_STRENGTH", "NEXTPNR_BEL", "FES_PINMAP_V1"} and
                cell["type"] == "MISTRAL_BUF" and cell["parameters"] == {} and
                cell["port_directions"] == {"A": "input", "Q": "output"} and set(cell["connections"]) == {"A", "Q"}, "undeclared route cell type/schema")
        q, bit = literal(cell, "Q"), literal(cell, "A")
        users = new_users.get(q)
        require(type(users) is list and len(users) == 1 and users[0][1:] == ("DATAIN", 0, 0), "BUF output is not one exact FF DATAIN slot")
        ff = users[0][0]
        alias = name + "$conn$Q"
        require(ff in original_cells and ff not in used_ffs and name == ff + "$ROUTETHRU" and
                a["cells"][ff]["type"] == "MISTRAL_FF" and expected_cells[ff]["connections"]["DATAIN"] == [bit] and
                new_drivers.get(q) == [(name, "Q", 0, 0)] and len(old_drivers.get(bit, [])) == 1 and
                alias in added_nets and view.native.aliases.get(q) == [(alias, 0)] and
                b["netnames"][alias]["bits"] == [q] and not view.native.top_users.get(q), "BUF forwarding owner/raw bit/private alias differs")
        shape = physical._shape(view, name)
        truth = physical._truth(shape)
        require(shape["type"] == "MISTRAL_BUF" and shape["tables"] == [2] and shape["inputs"][0]["state"] == 0 and
                shape["pins"] == {"A": [0, "D" if shape["half"] else "C"], "Q": [0, "COMBOUT"]} and
                truth["rows"] == [{"row": 0, "Q": 0}, {"row": 1, "Q": 1}], "BUF packed physical function is not identity")
        _, x, y, z = physical._location(cell)
        kind, fx, fy, fz = physical._location(b["cells"][ff])
        require(kind == "FF" and fz % 6 in (2, 4) and (x, y, z // 6, z % 6) == (fx, fy, fz // 6, (fz % 6 - 2) // 2),
                "BUF is not the exact named FF half feedthrough")
        physical.evaluate_lut(view, name)
        used_ffs.add(ff)
        expected_cells[ff]["connections"]["DATAIN"] = [q]
        require(q not in expected_drivers and (ff, "DATAIN", 0, 0) in expected_users[bit], "BUF ledger collision")
        expected_drivers[q] = [(name, "Q", 0, 0)]
        expected_users[bit].remove((ff, "DATAIN", 0, 0))
        expected_users[bit].append((name, "A", 0, 0))
        expected_users[q] = [(ff, "DATAIN", 0, 0)]
        rows.append({"buffer": name, "ff": ff, "alias": alias, "input_raw_bit": bit, "output_raw_bit": q,
                     "input_original_driver": list(old_drivers[bit][0]), "bel": cell["attributes"]["NEXTPNR_BEL"],
                     "actual_pins": shape["pins"], "physical_truth": truth})
    require(added_nets == {row["alias"] for row in rows} and len(added_cells) == len(rows), "route aliases exceed declared BUF outputs")
    require(expected_drivers == new_drivers and {bit: sorted(users) for bit, users in expected_users.items()} == new_users,
            "complete raw indexed driver/user tables differ beyond explicit BUF substitutions")
    for name, expected in expected_cells.items():
        actual = copy.deepcopy(b["cells"][name])
        require("FES_PINMAP_V1" not in expected["attributes"] and type(actual["attributes"].get("FES_PINMAP_V1")) is str,
                "fresh original physical pin map absent")
        actual["attributes"].pop("FES_PINMAP_V1")
        exact(native, expected, actual, "route original cell graph/params/attrs/BEL differs: " + name)
    for name, original in a["netnames"].items():
        exact(native, net_shape(original), net_shape(b["netnames"][name]), "route original alias metadata/raw bits changed: " + name)
    return {"buffer_rows": rows, "buffer_count": len(rows), "all_original_raw_slots_and_metadata_reconstructed_exactly": True,
            "generated_buffer_identity_function_proved": True, "blanket_buffer_collapse_used": False}, view


def ff_record(physical, view, name):
    _, x, y, z = physical._location(view.cells[name])
    state = view.labs[(x, y)][3][2 + 6 * (z // 6):8 + 6 * (z // 6)]
    return physical._ff(view, name, state)


def exported_lab_controls(physical, view, lab):
    selected, clears, clocks, sync = {}, {}, set(), {"SCLR": set(), "SLOAD": set()}
    rows = []
    for index in range(10):
        alm = physical.evaluate_alm(view, (*lab, index))
        halves = {}
        for ff in alm["ff_occupants"]:
            signature = {port: (tuple(row["driver"]) if row["driver"] else None, tuple(row["pins"]))
                         for port, row in ff["controls"].items()}
            half = ff["half"]
            require(half not in halves or halves[half] == signature, "one FF half has incompatible shared control pins")
            halves[half] = signature
            clock_enable = signature["CLK"], signature["ENA"]
            clocks.add(signature["CLK"])
            ce = ff["clk_ena_selector"]
            require(type(ce) is int and 0 <= ce < 3 and type(ff["aclr_selector"]) is int and
                    0 <= ff["aclr_selector"] < 2, "exported FF selector is outside the physical slot range")
            require(ce not in selected or selected[ce] == clock_enable, "LAB CLK/ENA selector has incompatible native controls")
            selected[ce] = clock_enable
            if ff["controls"]["ACLR"]["driver"] is not None:
                ac = ff["aclr_selector"]
                require(ac not in clears or clears[ac] == signature["ACLR"], "LAB ACLR selector has incompatible native controls")
                clears[ac] = signature["ACLR"]
            for port in sync:
                if ff["controls"][port]["driver"] is not None:
                    sync[port].add(signature[port])
        rows.append(alm)
    require(len(clocks) <= 1 and len(selected) <= 3 and len(clears) <= 2 and
            all(len(values) <= 1 for values in sync.values()),
            "exported whole-LAB control capacity exceeded")
    return rows


def clock_enable_groups(native, alms):
    groups = {}
    for alm in alms:
        for ff in alm["ff_occupants"]:
            selector = ff["clk_ena_selector"]
            signature = {port: copy.deepcopy(ff["controls"][port]) for port in ("CLK", "ENA")}
            ena = signature["ENA"]
            require(bool(ena["bits"]) == (ena["driver"] is not None), "ENA connectedness/driver disagrees")
            if not ena["bits"]:
                require(ena["pins"][0] in (1, 2), "absent ENA is not an explicit constant physical pin")
            if selector in groups:
                exact(native, groups[selector]["signature"], signature, "one selector denotes differing full CLK/ENA groups")
            else:
                groups[selector] = {"signature": signature, "members": []}
            groups[selector]["members"].append(ff["cell"])
    for group in groups.values():
        group["members"].sort()
    return groups


def control_group_renumbering(native, old_alms, new_alms):
    old_groups, new_groups = [clock_enable_groups(native, alms) for alms in (old_alms, new_alms)]
    mapping, changed = {}, []
    for old_alm, new_alm in zip(old_alms, new_alms):
        old = {row["cell"]: row for row in old_alm["ff_occupants"] if row["cell"] not in MOVED}
        new = {row["cell"]: row for row in new_alm["ff_occupants"] if row["cell"] not in MOVED}
        require(set(old) == set(new), "affected unmoved FF owner set changed")
        for name in sorted(old):
            a, b = copy.deepcopy(old[name]), copy.deepcopy(new[name])
            old_selector, new_selector = a.pop("clk_ena_selector"), b.pop("clk_ena_selector")
            exact(native, a, b, "affected unmoved FF changed beyond CLK/ENA selector numbering: " + name)
            require(old_selector not in mapping or mapping[old_selector] == new_selector,
                    "one prior control group was split across different selectors")
            mapping[old_selector] = new_selector
            if old_selector != new_selector:
                changed.append({"cell": name, "old_selector": old_selector, "new_selector": new_selector,
                                "unchanged_complete_ff_record_except_selector": a})
    require(len(set(mapping.values())) == len(mapping), "distinct prior control groups merged under one selector")
    rows = []
    for old_selector, new_selector in sorted(mapping.items()):
        a, b = old_groups[old_selector], new_groups[new_selector]
        exact(native, a["signature"], b["signature"], "mapped whole-LAB logical CLK/ENA signature changed")
        old_members = sorted(set(a["members"]) - MOVED)
        new_members = sorted(set(b["members"]) - MOVED)
        require(old_members == new_members and old_members, "mapped whole-LAB unmoved group membership changed")
        rows.append({"old_selector": old_selector, "new_selector": new_selector, "signature": a["signature"],
                     "unmoved_members": old_members, "old_moved_members": sorted(set(a["members"]) & MOVED),
                     "new_moved_members": sorted(set(b["members"]) & MOVED)})
    old_unmapped = {selector: row for selector, row in old_groups.items() if selector not in mapping}
    new_unmapped = {selector: row for selector, row in new_groups.items() if selector not in mapping.values()}
    require(all(set(row["members"]) <= MOVED for row in [*old_unmapped.values(), *new_unmapped.values()]),
            "an unmapped control group contains an undeclared unmoved FF")
    return {"all_old_groups": old_groups, "all_new_groups": new_groups, "consistent_injective_mapping": rows,
            "all_changed_unmoved_ff_records": changed, "old_moved_only_groups": old_unmapped,
            "new_moved_only_groups": new_unmapped, "equivalent_exported_logical_clk_ena_groups_proved": True,
            "actual_selector_to_routed_wire_or_rbf_mux_mapping_independently_proved": False}


def physical_proof(native, physical, before, after, placement, old_ledger, new_ledger):
    require(before.device == after.device and set(before.labs) == set(after.labs), "physical device/LAB geometry set changed")
    labs = set()
    for row in placement["ff_bel_changes"]:
        for view in (before, after):
            _, x, y, _ = physical._location(view.cells[row["cell"]])
            labs.add((x, y))
    old_buffers = {row["buffer"]: row for row in old_ledger["buffer_rows"]}
    new_buffers = {row["buffer"]: row for row in new_ledger["buffer_rows"]}
    originals = set(before.cells) - set(old_buffers)
    require(originals == set(after.cells) - set(new_buffers), "physical original owner set changed")
    moved_records, original_pin_count = [], 0
    for name in sorted(originals):
        a, b = before.cells[name], after.cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and a["port_directions"] == b["port_directions"],
                "original physical owner schema/params differ")
        exact(native, before.pins(name), after.pins(name), "original complete physical pin map changed: " + name)
        original_pin_count += 1
        if name in MOVED:
            require(a["parameters"] == {} and a["port_directions"] == FF_PORTS, "moved routed FF full schema differs")
            pins = after.pins(name)
            require(pins["DATAIN"] == [0, "DATAIN"] and pins["Q"] == [0, "Q"] and
                    pins["CLK"] in ([0, "CLK"], [3, "CLK"]) and
                    all(a["connections"][port] == b["connections"][port] == [] for port in ("ENA", "ACLR", "SCLR", "SLOAD", "SDATA")),
                    "moved FF DATAIN/Q/clock physical state or plain controls differ")
            for port in ("Q", "CLK"):
                require(a["connections"][port] == b["connections"][port], "moved FF raw Q/CLK differs")
            aa, bb = ff_record(physical, before, name), ff_record(physical, after, name)
            exact(native, aa["controls"], bb["controls"], "moved FF clock edge/control semantics changed")
            moved_records.append({"cell": name, "before": aa, "after": bb, "data_forwarding_in_explicit_route_ledgers": True})
    for first, second in PAIR_NAMES:
        require(after.pins(first)["CLK"] == after.pins(second)["CLK"] and
                after.cells[first]["connections"]["CLK"] == after.cells[second]["connections"]["CLK"], "pair clock edge differs after routing")
    changed_buffers = []
    for name in sorted(set(old_buffers) | set(new_buffers)):
        a, b = old_buffers.get(name), new_buffers.get(name)
        if a and b:
            old_lut, new_lut = physical.evaluate_lut(before, name)["lut"], physical.evaluate_lut(after, name)["lut"]
            same = native.canonical(old_lut) == native.canonical(new_lut) and a["bel"] == b["bel"]
        else:
            same = False
        if not same:
            for view in (before, after):
                if name in view.cells:
                    _, x, y, _ = physical._location(view.cells[name])
                    require((x, y) in labs, "BUF physical/function change escaped moved whole LABs")
            changed_buffers.append(name)
    inside, outside = [], 0
    for lab in sorted(before.labs):
        require(before.labs[lab][:3] == after.labs[lab][:3], "LAB geometry kind changed")
        if lab not in labs:
            exact(native, before.labs[lab], after.labs[lab], "unaffected exported LAB state changed")
            for index in range(10):
                key = (*lab, index)
                exact(native, sorted(before.occupants.get(key, [])), sorted(after.occupants.get(key, [])),
                      "outside physical ALM occupancy changed")
                outside += 1
            continue
        old_alms = exported_lab_controls(physical, before, lab)
        new_alms = exported_lab_controls(physical, after, lab)
        renumbering = control_group_renumbering(native, old_alms, new_alms)
        for a, b in zip(old_alms, new_alms):
            old_banks = {row["cell"]: row for row in a["occupied_banks"] if row["cell"] in originals}
            new_banks = {row["cell"]: row for row in b["occupied_banks"] if row["cell"] in originals}
            exact(native, old_banks, new_banks, "affected original combinational bank/shared-input function changed")
        inside.append({"lab": list(lab), "all_ten_alms_before": old_alms, "all_ten_alms_after": new_alms,
                       "explicit_logical_control_group_renumbering": renumbering})
    return {"exported_physical_function_scope_proved": True, "all_original_full_pin_maps_exact": original_pin_count,
            "affected_whole_labs": [list(lab) for lab in sorted(labs)], "affected_whole_lab_records": inside,
            "outside_exact_alm_count": outside, "declared_moved_ff_records": moved_records,
            "explicit_changed_generated_buffers": changed_buffers, "all_generated_buffers_evaluated_as_identity": True,
            "whole_lab_exported_occupancy_modes_shared_inputs_and_control_constraints_checked": True,
            "complete_placement_or_routing_legality_independently_proved": False,
            "unexported_pointer_indexed_storage_cache_and_gpu_identity_proved": False,
            "physical_route_muxes_pips_cram_or_rbf_independently_decoded": False}


def timing_proof(tables, timing, documents, reports, logs):
    base, current = reports["baseline"], reports["current"]
    baseline_topology = tables.report_topology(documents["baseline"], base, base)
    topology = tables.report_topology(documents["current"], current, base)
    sets = {name: timing._paths(report) for name, report in reports.items()}
    require(all(rows[0] == sets["baseline"][0] and rows[1] == sets["baseline"][1] for rows in sets.values()),
            "all native frame seven-pair/15290-endpoint/window coverage differs")
    require(set(base["fmax"]) == set(current["fmax"]) == {MEMORY, PIXEL, CAPTURE}, "required clock set differs")
    require(all(set(report["fmax"]) == set(base["fmax"]) and
                all(report["fmax"][name]["constraint"] == base["fmax"][name]["constraint"] for name in base["fmax"])
                for report in reports.values()), "native placement/route clock set or constraints differ")
    require(base["fmax"][MEMORY]["achieved"] == TARGET_MHZ and current["fmax"][MEMORY]["achieved"] == EXPECTED_MHZ,
            "matched baseline/current memory frequency differs")
    clocks = {}
    for name in (MEMORY, PIXEL, CAPTURE):
        a, b = base["fmax"][name], current["fmax"][name]
        require(set(a) == set(b) == {"achieved", "constraint"} and a["constraint"] == b["constraint"] and
                all(type(row["achieved"]) in (int, float) and math.isfinite(row["achieved"]) and row["achieved"] > 0 for row in (a, b)),
                "clock constraint or finite Fmax differs")
        clocks[name] = {"before_mhz": a["achieved"], "after_mhz": b["achieved"], "gain_mhz": b["achieved"] - a["achieved"],
                        "constraint_mhz": b["constraint"], "constraint_passed": b["achieved"] >= b["constraint"]}
    require(abs(current["fmax"][PIXEL]["constraint"] - 74.25006866455078) < 1e-10 and
            abs(current["fmax"][CAPTURE]["constraint"] - 130.00520324707031) < 1e-10 and
            clocks[MEMORY]["gain_mhz"] > 0 and clocks[PIXEL]["constraint_passed"] and clocks[CAPTURE]["constraint_passed"],
            "matched-baseline memory gain or mandatory pixel/capture clock threshold failed")
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    relations = []
    for pair in sorted(sets["current"][0]):
        window = sets["current"][0][pair]
        old, new = sets["baseline"][2][pair], sets["current"][2][pair]
        require(pair == target or new["headroom_ns"] > 0, "non-target complete registered window failed")
        end = new["actual_worst_path"]["path"][-1]["to"]
        relations.append({"from": pair[0], "to": pair[1], "window_ns": window, "before_headroom_ns": old["headroom_ns"],
                          "after_headroom_ns": new["headroom_ns"], "headroom_change_ns": new["headroom_ns"] - old["headroom_ns"],
                          "after_complete_delay_ns": new["complete_delay_ns"], "after_worst_endpoint": end,
                          "positive_headroom_required": pair != target})
    hold_evidence = {}
    for name in ("baseline", "current"):
        log = logs[name]
        require("Running signoff timing analysis..." in log and "Info: Program finished normally." in log and
                re.search(r"GPU router time [^\n]+backend hip:", log) and not any(line.startswith("ERROR:") for line in log.splitlines()),
                "completed native HIP route/signoff evidence absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        holds = [line for line in last.splitlines() if "Hold/min time violation" in line or
                 re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not holds, "final signoff reports hold/min violations")
        hold_evidence[name] = {"last_signoff_hold_warning_lines": holds, "final_reported_hold_violations": False}
    retained = re.findall(r"^Info: Capture pipeline locality retained first=(\S+) second=(\S+); routing and signoff still required\.$", logs["current"], re.M)
    require(retained == list(PAIR_NAMES) and "eligible=64 retained_pairs=37 (route signoff still required)." in logs["current"],
            "actual route's retained pair log differs from independently checked placement manifest")
    return {"passes_matched_baseline_practical_timing_gate": True, "clocks": clocks, "seven_pair_windows": relations,
            "positive_non_target_margin_reduction_allowed_and_disclosed": True, "final_signoff_hold_evidence": hold_evidence,
            "baseline_native_report_topology": baseline_topology,
            "current_native_report_topology": topology, "all_finite_emitted_segment_sums_checked": True,
            "complete_path_count": len(sets["current"][1]), "old_delays_or_signoff_inherited": False,
            "independent_numerical_sta_or_unreported_pair_extrema_proved": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    args = parser.parse_args()
    require(DIGEST.fullmatch(args.self_sha256) and sha(__file__) == args.self_sha256, "actual self activation pin required")
    native = load_pure(*HELPERS["native"], "pipeline_native_pinned")
    audit = native.Audit()
    audit.bind(Path(__file__).resolve(), args.self_sha256)
    for path, digest in HELPERS.values():
        audit.bind(path, digest)
    freezer = types.ModuleType("pipeline_isolated_freeze")
    freezer.require = require
    tables = load_pure(*HELPERS["selected"], "pipeline_selected_pinned", freezer)
    physical = load_pure(*HELPERS["physical"], "pipeline_physical_pinned")
    timing = load_pure(*HELPERS["timing"], "pipeline_timing_pinned")
    records, profiles, closure = authenticate_records(audit)
    documents, reports = {}, {}
    for name, (folder, _) in RUNS.items():
        filename = "routed.json" if name in ("baseline", "current") else "placed.json"
        documents[name] = native.read_netlist(folder / filename)
        reports[name] = read(folder / "timing.json")
    documents["_physical"] = physical
    placement = prove_placement(native, tables, documents)
    old_ledger, old_view = route_ledger(native, tables, physical, documents["baseline_place"], documents["baseline"])
    new_ledger, new_view = route_ledger(native, tables, physical, documents["selected"], documents["current"])
    exact(native, documents["baseline"]["modules"]["top"]["settings"], documents["current"]["modules"]["top"]["settings"],
          "matched routed settings/defaults changed")
    exported_physical = physical_proof(native, physical, old_view, new_view, placement, old_ledger, new_ledger)
    logs = {"baseline": (RUNS["baseline"][0] / "route.log").read_text(),
            "current": (RUNS["current"][0] / "trial.log").read_text()}
    routed_timing = timing_proof(tables, timing, documents, reports, logs)
    audit.finish()
    result = {"schema": 1, "scope": "thirty-seven disjoint existing two-FF relocations; matched publication-main baseline",
              "native_physical_equivalence_proved": True, "gain_accepted_against_matched_main_baseline": True,
              "placement_native_proof": placement, "baseline_explicit_route_buffer_ledger": old_ledger,
              "current_explicit_route_buffer_ledger": new_ledger, "exported_physical_proof": exported_physical,
              "reported_timing_proof": routed_timing, "completed_record_closure": closure,
              "artifact_sha256": audit.artifacts, "directly_rehashed_source_or_compiler_sha256": audit.execution,
              "self_sha256": args.self_sha256, "independent_live_pointer_cache_gpu_or_full_runtime_identity_proved": False,
              "independent_numerical_sta_proved": False, "cram_or_rbf_independently_decoded": False,
              "hardware_tested": False, "default_recipe_or_deployment_qualification_claimed": False,
              "frozen_117_869_stack_qualification_inherited": False,
              "limitations": ["Physical claims use exported pin/LAB snapshots and packed truth, not independently decoded route muxes or RBF bytes.",
                              "CLK/ENA selector changes prove equivalent exported logical groups through a consistent injective renumbering; the actual selector-to-routed-wire reservation table is not exported or independently checked.",
                              "Historical disabled compiler/source bytes are checked from a pinned retained ELF/source archive, with its remaining external source members rehashed directly; no archive is extracted or executed.",
                              "Serialized port-bit slots do not prove live indexed-store allocation, pointers, caches, GPU IDs or full runtime identity.",
                              "Timing acceptance checks all emitted paths and final reported holds; it does not independently recompute numerical STA."]}
    output = HERE / "proof-pipeline-b64-r24.json"
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"proof": str(output), "proof_sha256": sha(output), "native_physical_equivalence_proved": True,
                      "matched_baseline_gain_accepted": True, "memory_gain_mhz": EXPECTED_MHZ - TARGET_MHZ}, sort_keys=True))


if __name__ == "__main__":
    main()
