Registered hard-block outputs can feed two existing capture registers whose placement adds avoidable routing delay. Add an opt-in Mistral placement pass that discovers this structure through native graph and timing information, moves both plain FFs, and preserves their connections, controls, initial values and two-register latency.

The search considers up to 64 distinct LAB pairs while limiting timing analysis to 16 placements that pass native legality and snapshot preservation. Illegal geometries therefore leave the timing budget available for later candidates. A native fixture exercises more than 16 illegal placements before a later qualifying pair. No RAM-test names, pins or measured coordinates are used by the compiler.

The matched budget-64/radius-24 full GPU route reaches **107.5037612915039 MHz** memory Fmax: **+1.3804473876953125 MHz** over the earlier 16-geometry budget-64 run and **+1.7284317016601562 MHz** over fresh main. It retains 53 pairs instead of 37. Pixel is 94.98480224609375 MHz, down 1.33575439453125 MHz from fresh main but above its required 74.25006866455078 MHz. Capture remains 375.0871276855469 MHz. All six non-target windows pass, and final signoff reports no hold violations. Memory still misses 130.0052032470703 MHz.

The earlier budget-8 result and its combined LUT-pair-copy result remain recorded separately. The older frozen 117.86892700195312 MHz stack uses a different compiler/configuration and retains its own qualification.

Validation:

- 33 native cases and 11 CLI methods passed on the measured source bytes.
- Disabled placement reproduces the entire baseline native module, ordered duplicate PLL ports and timing JSON.
- Full routed/RBF output completed normally with stable compiler, source and input hashes.
- Independent exported graph/physical checks cover all 106 FF moves, original pin maps, explicit identity buffers and 50 whole LABs.
- All 15,290 emitted finite complete paths across seven windows and final reported holds were checked.

The pass remains default off. Its bounded transactions restore rejected moves and preserve earlier accepted changes. Only the internal same-clock full-cycle hop may spend passing setup margin; other affected paths, native global clock timing and hold guards must not regress during placement.

The new [search measurement record](docs/validation/ramtest-capture-search64-2026-10-02.md) and adjacent JSON identify the actual experimental ELF, source bytes, options and raw evidence. They qualify those measured bytes and explicit options; they do not independently qualify a newly built publication binary, numerical STA, complete device legality, RBF decoding or hardware. No FES RTL, default recipe, compiler pins, ABI or constraints changed.

Stacked on #109. Related to DeanoC/fes#264.
