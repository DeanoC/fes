"""Record fixed-input placement/route trials of the capture-pipeline prototype."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-experiment-mistral-capture-pipeline-264-54cde5d3")
OLD_SOURCE = Path("/home/deano/kepler/worktrees/nextpnr-feat-mistral-lut-pair-copies-264-54cde5d3")
BINARY = Path("/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d/sources/misteross/build/toolchain-ramtest-timing/build/nextpnr-capture-pipeline-264/nextpnr-mistral")
BASE = Path("/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d/out/ramtest-wide-reduction-264/lut-pair-copies-publication-264/main-baseline/run.json")
BASE_SHA = '3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c'
GUIDE = Path("/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d/out/ramtest-wide-reduction-264/lut-pair-copies-publication-264/main-baseline-placed/timing.json")
GUIDE_SHA = 'd117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(value, reason):
    if not value:
        raise ValueError(reason)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-sha256', required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--mode', choices=('disabled-placed', 'pipeline-placed', 'pipeline-route'), required=True)
    parser.add_argument('--budget', type=int, default=8)
    parser.add_argument('--radius', type=int, default=24)
    args = parser.parse_args()
    require(sha(__file__) == args.self_sha256 and sha(BASE) == BASE_SHA and sha(GUIDE) == GUIDE_SHA,
            'recorder/reference/guide changed')
    require(1 <= args.budget <= 64 and 1 <= args.radius <= 24, 'invalid search bounds')
    base = json.loads(BASE.read_text())
    files = {}
    for old in base['production_source_sha256']:
        path = Path(old)
        if path.is_relative_to(OLD_SOURCE):
            path = SOURCE / path.relative_to(OLD_SOURCE)
        files[str(path)] = sha(path)
    for filename in ('mistral/capture_pipeline_locality.cc', 'mistral/tests/capture_pipeline_locality.cc',
                     'mistral/tests/capture_pipeline_locality_cli.py', 'docs/mistral-capture-pipeline-locality.md'):
        files[str(SOURCE / filename)] = sha(SOURCE / filename)
    def stable():
        return (sha(__file__) == args.self_sha256 and sha(BINARY) == args.binary_sha256 and
                sha(BASE) == BASE_SHA and sha(GUIDE) == GUIDE_SHA and
                all(sha(path) == expected for path, expected in files.items()) and
                all(sha(WORK / path) == expected for path, expected in base['input_sha256'].items()))
    output = HERE / ('clock-group-' + (args.mode if args.mode == 'disabled-placed' else
                     f'{args.mode}-b{args.budget}-r{args.radius}'))
    require(stable() and base['completed_normally'] and not output.exists(),
            'bound bytes changed or output exists')
    command, index = [str(BINARY)], 1
    routed = args.mode == 'pipeline-route'
    while index < len(base['command']):
        flag = base['command'][index]
        if flag == '--rbf':
            if routed:
                command.extend((flag, str(output / 'core.rbf')))
            index += 2
        elif flag in ('--write', '--report'):
            filename = ('routed.json' if routed else 'placed.json') if flag == '--write' else 'timing.json'
            command.extend((flag, str(output / filename)))
            index += 2
        else:
            command.append(flag)
            index += 1
    if not routed:
        command.append('--no-route')
    require(not any(flag.startswith('--remap-') or flag.startswith('--balance-') for flag in command),
            'unexpected graph remap')
    environment = {key: value for key, value in os.environ.items() if not key.startswith('NEXTPNR_')}
    environment.update({'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'})
    selected = {}
    if args.mode != 'disabled-placed':
        selected['NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY'] = f'{GUIDE} {args.budget} {args.radius}'
        environment.update(selected)
    output.mkdir()
    profile = dict(schema=1, role='exploratory trial; not timing acceptance', baseline_sha256=BASE_SHA,
                   guide_sha256=GUIDE_SHA, helper_sha256=args.self_sha256,
                   binary_sha256=args.binary_sha256, production_source_sha256=files,
                   input_sha256=base['input_sha256'], command=command, environment=selected, cwd=base['cwd'])
    (output / 'profile.json').write_text(json.dumps(profile, indent=2, sort_keys=True) + '\n')
    started = time.monotonic()
    with (output / 'trial.log').open('x') as stream:
        result = subprocess.run(command, cwd=base['cwd'], env=environment, stdout=stream, stderr=subprocess.STDOUT)
    unchanged = stable()
    record = dict(schema=1, profile_sha256=sha(output / 'profile.json'), exit_code=result.returncode,
                  elapsed_seconds=time.monotonic() - started, production_and_input_bytes_stable=unchanged,
                  output_sha256={path.name: sha(path) for path in sorted(output.iterdir()) if path.is_file()},
                  native_physical_equivalence_proved=False, gain_accepted=False, hardware_tested=False)
    with (output / 'run.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(run_sha256=sha(output / 'run.json'), exit_code=result.returncode, stable=unchanged)))
    require(unchanged and result.returncode == 0, 'trial failed or bound bytes changed')

if __name__ == '__main__':
    main()
