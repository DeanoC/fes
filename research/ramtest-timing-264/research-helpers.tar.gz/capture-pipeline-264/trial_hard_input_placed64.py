"""Record the broader 64-FF hard-input pre-route experiment; no gain claims."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
TOOL = WORK / 'sources/misteross/build/toolchain-ramtest-timing'
SOURCE = Path('/home/deano/kepler/worktrees/nextpnr-experiment-mistral-hard-input-locality-264-54cde5d3')
OLD_SOURCE = Path('/home/deano/kepler/worktrees/nextpnr-feat-mistral-lut-pair-copies-264-54cde5d3')
MODEL = TOOL / 'src/mistral'
BINARY = TOOL / 'build/nextpnr-hard-input-locality-264/nextpnr-mistral'
BASE = HERE.parent / 'lut-pair-copies-publication-264/main-baseline/run.json'
BASE_SHA = '3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c'
GUIDES = {
    'pipeline': (HERE.parent / 'lut-pair-copies-publication-264/main-baseline-placed/timing.json',
                 'd117e8952e4741f64ca14094df6c4db5a973f9de3a9dc038820852f7b5c0f512'),
    'pair': (HERE / 'clock-group-pipeline-placed-b8-r24/timing.json',
             None),
    'hard': (HERE / 'clock-group-pipeline-b8-pair-copy-c0-placed/timing.json',
             'ba18c96552bb3865b5ab2484c63d8b689e14539a07e3766a65dab83b423b6df9'),
}
INPUTS = {
    'out/ramtest-merged-remap/measured-diagnostic/synth.json': '61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28',
    'sources/misteross/cores/fes-ramtest/constraints.qsf': '8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4',
    'sources/misteross/boards/de10nano/clocks.sdc': '3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041',
}
ADDED = ('mistral/capture_pipeline_locality.cc', 'mistral/tests/capture_pipeline_locality.cc',
         'mistral/tests/capture_pipeline_locality_cli.py', 'docs/mistral-capture-pipeline-locality.md',
         'mistral/tests/hard_input_locality.cc', 'mistral/tests/hard_input_locality_cli.py',
         'docs/mistral-hard-input-locality.md')
RUNTIME_KEYS = ('PATH', 'LD_LIBRARY_PATH', 'LD_PRELOAD', 'LANG', 'LC_ALL', 'TZ',
                'CUDA_VISIBLE_DEVICES', 'HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES',
                'OMP_NUM_THREADS', 'HSA_OVERRIDE_GFX_VERSION')


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def encoded(value):
    return json.dumps(value, indent=2, sort_keys=True) + '\n'


def fixed_arguments():
    return ['--json', str(WORK / 'out/ramtest-merged-remap/measured-diagnostic/synth.json'),
            '--device', '5CSEBA6U23I7', '--qsf', str(WORK / 'sources/misteross/cores/fes-ramtest/constraints.qsf'),
            '--sdc', str(WORK / 'sources/misteross/boards/de10nano/clocks.sdc'), '--freq', '74.25',
            '--seed', '2', '--placer-heap-timingweight', '10', '--placer-heap-critexp', '2',
            '--replicate-enables', '4', '--timing-allow-fail', '--detailed-timing-report',
            '--router', 'gpu', '--gpu-device', '1']


def capture(paths):
    hashes, errors = {}, {}
    for path in sorted(paths):
        try:
            hashes[str(path)] = sha(path)
        except Exception as error:
            errors[str(path)] = type(error).__name__ + ': ' + str(error)
    return {'sha256': hashes, 'errors': errors}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-sha256', required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--pair-guide-sha256', required=True)
    parser.add_argument('--mode', choices=('prefix', 'selected'), required=True)
    args = parser.parse_args()
    for value in (args.self_sha256, args.binary_sha256, args.pair_guide_sha256):
        require(re.fullmatch('[0-9a-f]{64}', value), 'actual activation hash required')
    require(sha(__file__) == args.self_sha256 and sha(BINARY) == args.binary_sha256 and
            sha(BASE) == BASE_SHA, 'recorder/compiler/baseline changed')
    with BINARY.open('rb') as stream:
        require(stream.read(4) == b'\x7fELF', 'compiler must be an ELF')
    guides = {name: (path, expected or args.pair_guide_sha256) for name, (path, expected) in GUIDES.items()}
    for path, expected in guides.values():
        require(sha(path) == expected, 'stage-specific placed guide changed')
    base = json.loads(BASE.read_text())
    reference_command = [str(TOOL / 'build/nextpnr-lut-pair-copies-publication-264/nextpnr-mistral')] + fixed_arguments() + [
        '--write', str(BASE.parent / 'routed.json'), '--report', str(BASE.parent / 'timing.json'),
        '--timing-report-paths', '16384', '--rbf', str(BASE.parent / 'core.rbf')]
    require(base['command'] == reference_command and base['input_sha256'] == INPUTS and
            base['cwd'] == str(WORK / 'sources/misteross') and base['completed_normally'] is True and
            base['exit_code'] == 0, 'fixed baseline identity/completion differs')
    sources, models = {}, {}
    for original, expected in base['production_source_sha256'].items():
        path = Path(original)
        if path.is_relative_to(OLD_SOURCE):
            path = SOURCE / path.relative_to(OLD_SOURCE)
        else:
            require(path.is_relative_to(MODEL), 'unexpected production inventory root')
            models[str(path)] = expected
        require(str(path) not in sources, 'duplicate mapped production path')
        sources[str(path)] = sha(path)
    for name in ADDED:
        sources[str(SOURCE / name)] = sha(SOURCE / name)
    require(models and all(sources[path] == value for path, value in models.items()),
            'model bytes differ from fixed reference')
    expected = {**sources, **{str(WORK / name): value for name, value in INPUTS.items()},
                **{str(path): value for path, value in guides.values()},
                str(Path(__file__).resolve()): args.self_sha256, str(BINARY): args.binary_sha256, str(BASE): BASE_SHA}
    before = capture(expected)
    require(not before['errors'] and before['sha256'] == expected, 'bound bytes changed before activation')
    output = HERE / ('hard-input-c0-' + args.mode + '-placed-b64-v1')
    output.mkdir(exist_ok=False)
    command = [str(BINARY)] + fixed_arguments() + [
        '--write', str(output / 'placed.json'), '--report', str(output / 'timing.json'),
        '--timing-report-paths', '16384', '--no-route', '--remap-lut-pair-critical', str(guides['pair'][0]),
        '--remap-lut-pair-compose-copy', '--remap-lut-pair-candidate', '0']
    cleared = sorted(key for key in os.environ if key.startswith('NEXTPNR_'))
    environment = {key: value for key, value in os.environ.items() if not key.startswith('NEXTPNR_')}
    environment.update({'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'})
    selected = {'NEXTPNR_MISTRAL_CAPTURE_PIPELINE_LOCALITY': f'{guides["pipeline"][0]} 8 24'}
    if args.mode == 'selected':
        selected['NEXTPNR_MISTRAL_HARD_INPUT_LOCALITY'] = f'{guides["hard"][0]} 64 24'
    environment.update(selected)
    require({key: value for key, value in environment.items() if key.startswith('NEXTPNR_')} == selected,
            'unexpected effective diagnostic environment')
    environment_record = {'runtime_values': {key: environment[key] for key in RUNTIME_KEYS if key in environment},
                          'selected_diagnostics': selected, 'cleared_diagnostic_keys': cleared,
                          'all_effective_keys': sorted(environment),
                          'all_effective_values_sha256': hashlib.sha256(encoded(environment).encode()).hexdigest(),
                          'unlisted_values_recorded': False}
    profile = {'schema': 'hard-input-placed-trial-v1', 'command': command, 'cwd': base['cwd'],
               'mode': args.mode, 'binary_sha256': args.binary_sha256, 'helper_sha256': args.self_sha256,
               'production_source_sha256': sources, 'input_sha256': INPUTS, 'before_snapshot': before,
               'environment': environment_record, 'compiled_commit_asserted': False,
               'native_physical_equivalence_proved': False, 'gain_accepted': False, 'hardware_tested': False}
    profile_path = output / 'profile.json'
    profile_path.write_text(encoded(profile))
    profile_hash = sha(profile_path)
    started = time.monotonic()
    returncode = None
    failure = None
    try:
        require(capture(expected) == before, 'bound bytes changed after profile creation')
        with (output / 'trial.log').open('x') as stream:
            result = subprocess.run(command, cwd=base['cwd'], env=environment, stdout=stream, stderr=subprocess.STDOUT)
        returncode = result.returncode
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)}
    after = capture(expected)
    paths = sorted(output.iterdir())
    artifacts = capture(paths)
    names = {'profile.json', 'trial.log', 'placed.json', 'timing.json'}
    valid = set(path.name for path in paths) == names and all(path.is_file() and not path.is_symlink() for path in paths)
    stable = after == before and not after['errors'] and not artifacts['errors'] and capture(paths) == artifacts
    marker = (output / 'trial.log').is_file() and 'Info: Program finished normally.' in (output / 'trial.log').read_text()
    completed = returncode == 0 and valid and stable and marker and sha(profile_path) == profile_hash and failure is None
    record = {'schema': 'hard-input-placed-trial-v1', 'profile_sha256': profile_hash,
              'command': command, 'cwd': base['cwd'], 'environment': environment_record,
              'before_snapshot': before, 'after_snapshot': after, 'exit_code': returncode,
              'elapsed_seconds': time.monotonic() - started, 'completed_normally': completed,
              'stable': stable, 'output_sha256': artifacts['sha256'], 'output_hash_errors': artifacts['errors'],
              'normal_finish_marker': marker, 'failure': failure, 'gain_accepted': False,
              'native_physical_equivalence_proved': False, 'hardware_tested': False}
    with (output / 'run.json').open('x') as stream:
        stream.write(encoded(record))
    print(json.dumps({'mode': args.mode, 'completed_normally': completed, 'exit_code': returncode,
                      'run_sha256': sha(output / 'run.json')}))
    require(completed, 'trial failed; closed record retained without a gain claim')


if __name__ == '__main__':
    main()
