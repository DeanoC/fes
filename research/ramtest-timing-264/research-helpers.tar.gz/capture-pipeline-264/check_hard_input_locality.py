#!/usr/bin/env python3
"""Record one explicit hard-input compiler check, without old helper imports."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

WORK = Path('/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d')
HERE = WORK / 'out/ramtest-wide-reduction-264/capture-pipeline-264'
SOURCE = Path('/home/deano/kepler/worktrees/nextpnr-experiment-mistral-hard-input-locality-264-54cde5d3')
TOOL = WORK / 'sources/misteross/build/toolchain-ramtest-timing'
BUILD = TOOL / 'build/nextpnr-hard-input-locality-264'
STAGES = {
    'configure': ['cmake', '-S', str(SOURCE), '-B', str(BUILD),
                  '-DCMAKE_BUILD_TYPE=Release', '-DARCH=mistral',
                  '-DMISTRAL_ROOT=' + str(TOOL / 'src/mistral'),
                  '-DGPU_ROUTER=HIP', '-DCMAKE_HIP_ARCHITECTURES=gfx1100;gfx1201',
                  '-DCMAKE_HIP_COMPILER=/opt/rocm/core-7.14/lib/llvm/bin/clang++',
                  '-DBUILD_GUI=OFF', '-DBUILD_TESTS=ON', '-DUSE_OPENMP=OFF'],
    'build': ['cmake', '--build', str(BUILD), '--parallel', '8',
              '--target', 'nextpnr-mistral', 'nextpnr-mistral-test'],
    'native': [str(BUILD / 'nextpnr-mistral-test'), '--gtest_filter=HardInputLocalityTest.*'],
    'cli': [sys.executable, str(SOURCE / 'mistral/tests/hard_input_locality_cli.py'),
            str(BUILD / 'nextpnr-mistral'), '-v'],
    'regression-native': [str(BUILD / 'nextpnr-mistral-test'),
                          '--gtest_filter=CapturePipelineLocalityTest.*:LutDriverCopyTest.*:LutPairPlacementTest.*:LutPairCopyTest.*:LabPinmapTest.*'],
    'regression-cli': ['ctest', '--test-dir', str(BUILD), '--output-on-failure',
                       '-R', '^nextpnr-mistral-(capture-pipeline-locality|lut-pair-placement|lut-driver-copy)-cli$'],
}
FILES = ('mistral/CMakeLists.txt', 'mistral/arch.cc', 'mistral/arch.h',
         'mistral/main.cc', 'mistral/capture_pipeline_locality.cc',
         'mistral/tests/hard_input_locality.cc',
         'mistral/tests/hard_input_locality_cli.py', 'docs/mistral-hard-input-locality.md')


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def git(*args, directory=SOURCE):
    return subprocess.check_output(['git', '-C', str(directory), *args]).decode().strip()


def inputs():
    tracked = subprocess.check_output(['git', '-C', str(SOURCE), 'ls-files', '-z'])
    rows = {}
    for raw in tracked.split(b'\0'):
        if not raw:
            continue
        name = os.fsdecode(raw)
        path = SOURCE / name
        if path.is_file():
            rows[name] = sha(path)
    for name in FILES:
        rows[name] = sha(SOURCE / name)
    submodules = {}
    for name, expected in (
        ('3rdparty/googletest', '52eb8108c5bdec04579160ae17225d66034bd723'),
        ('tests', 'ce154121819a04ec921a4a6f6850c28f33c81b6c')):
        actual = git('rev-parse', 'HEAD', directory=SOURCE / name)
        if actual != expected:
            raise RuntimeError('unexpected submodule ' + name)
        submodules[name] = actual
    return {'head': git('rev-parse', 'HEAD'), 'files': rows,
            'diff_sha256': hashlib.sha256(subprocess.check_output(
                ['git', '-C', str(SOURCE), 'diff', '--binary'])).hexdigest(),
            'submodules': submodules}


def write_record(path, document):
    temporary = path.with_suffix('.pending')
    temporary.write_text(json.dumps(document, indent=2, sort_keys=True) + '\n')
    temporary.replace(path)


def main():
    if len(sys.argv) != 4 or sys.argv[1] not in STAGES:
        raise SystemExit('usage: check_hard_input_locality.py STAGE NEW_LABEL SCRIPT_SHA256')
    stage, label, expected = sys.argv[1:]
    if sha(__file__) != expected:
        raise RuntimeError('recorder source changed')
    if not label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label):
        raise RuntimeError('invalid new record label')
    selected = inputs()
    directory = HERE / ('hard-input-check-' + label)
    directory.mkdir(exist_ok=False)
    record = directory / 'record.json'
    log = directory / 'output.log'
    command = STAGES[stage]
    started = time.time()
    document = {'schema': 'hard-input-compiler-check-v1', 'stage': stage,
                'recorder_sha256': expected, 'command': command,
                'cwd': str(SOURCE), 'inputs_before': selected,
                'state': 'running', 'started_unix': started, 'exit_code': None,
                'hardware': False, 'full_route': False}
    write_record(record, document)
    print(json.dumps({'stage': stage, 'state': 'running', 'record': str(record)}), flush=True)
    try:
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=SOURCE, stdout=stream, stderr=subprocess.STDOUT)
        document['exit_code'] = result.returncode
        document['inputs_after'] = inputs()
        document['inputs_unchanged'] = document['inputs_after'] == selected
        document['log_sha256'] = sha(log)
        document['executables'] = {name: sha(BUILD / name)
                                  for name in ('nextpnr-mistral', 'nextpnr-mistral-test')
                                  if (BUILD / name).is_file()}
        document['state'] = 'passed' if result.returncode == 0 and document['inputs_unchanged'] else 'failed'
    except BaseException as error:
        document['state'] = 'failed'
        document['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        document['finished_unix'] = time.time()
        document['elapsed_seconds'] = document['finished_unix'] - started
        write_record(record, document)
        print(json.dumps({'stage': stage, 'state': document['state'],
                          'exit_code': document['exit_code'], 'record_sha256': sha(record),
                          'elapsed_seconds': document['elapsed_seconds']}), flush=True)
    return 0 if document['state'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
