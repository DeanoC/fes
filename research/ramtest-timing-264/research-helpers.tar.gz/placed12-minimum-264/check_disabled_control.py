"""Root-operated disabled JSON-loader control for the new committed margin delta.

Use the exact frozen 8e disabled export, including both duplicate PLL outclk
occurrences. Cached old proofs are authenticated, never rerun. This control
does not pack, place, route or claim physical/timing/hardware acceptance.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location("placed12_minimum_freeze_source", HERE / "freeze.py")
_freeze = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_freeze)
ROOT, PARENT, G8, MEASURED = _freeze.ROOT, _freeze.PARENT, _freeze.G8, _freeze.MEASURED
sha, require, read, authenticate_freeze = _freeze.sha, _freeze.require, _freeze.read, _freeze.authenticate_freeze
MODULE = ROOT / "sources/misteross"
G8_HELPER = G8 / "compare_control_decomposition.py"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
FULL = G8 / "route-c0/comparison.json"
FULL_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
CONTROL = PARENT / "disabled-control/comparison.json"
CONTROL_SHA = _freeze.PARENT_FILES["disabled-control/comparison.json"]
ACCEPTED = PARENT / "disabled-control/candidate.json"
ACCEPTED_SHA = _freeze.PARENT_FILES["disabled-control/candidate.json"]


def load_reference(g8=None):
    """Read cached full/list/control closures; call only individual netlist APIs."""
    _, inputs = _freeze.parent_source()
    _freeze.add_input(inputs, FULL, FULL_SHA)
    _freeze.add_input(inputs, G8_HELPER, G8_HELPER_SHA)
    full, old = read(FULL), read(CONTROL)
    require(full["graph_proof_available"] is True and full["final_metadata_stable_during_comparison"] is True and
            old["completed"] is True and type(old["exit_code"]) is int and old["exit_code"] == 0 and
            type(old["elapsed_seconds"]) in (int, float) and math.isfinite(old["elapsed_seconds"]) and old["elapsed_seconds"] >= 0 and
            old["compiler_commit"] == _freeze.BASE and old["candidate_sha256"] == ACCEPTED_SHA,
            "cached full/direct-parent control proof is not finalized")
    for filename, digest in full["artifact_sha256"].items():
        _freeze.add_input(inputs, ROOT / filename, digest)
    require(full["artifact_sha256"].get(str(G8_HELPER.relative_to(ROOT))) == G8_HELPER_SHA,
            "cached g8 full proof omits its parser binding")
    if g8 is None:
        spec = importlib.util.spec_from_file_location("sealed_minimum_g8_netlist_parser", G8_HELPER)
        g8 = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(g8)
    expected = g8.read_netlist(ACCEPTED)["modules"]
    modules_sha = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    require(modules_sha == old["modules_sha256"], "cached parent lossless normalized modules changed")
    return g8, old, expected, modules_sha, inputs


def control_inputs(source_identity, reference_inputs, source):
    inputs = dict(reference_inputs)
    for filename, digest in source_identity["input_sha256"].items():
        _freeze.add_input(inputs, filename, digest)
    for path in (HERE / "nextpnr-mistral", HERE / "source.tar.gz", HERE / "source-identity.json", HERE / "change.patch",
                 HERE / "freeze.py", Path(__file__).resolve(), source):
        _freeze.add_input(inputs, path, sha(path))
    return inputs


def expected_command(old):
    require(old["command"].count("--json") == old["command"].count("--balance-reduction-root") == 1,
            "cached disabled command is ambiguous")
    source = Path(old["command"][old["command"].index("--json")+1])
    selector = old["command"][old["command"].index("--balance-reduction-root")+1]
    command = [str(HERE / "nextpnr-mistral"), "--json", str(source), "--device", "5CSEBA6U23I7", "--no-pack", "--no-place",
               "--no-route", "--balance-reduction-root", selector, "--write", str(HERE / "disabled-control/candidate.json")]
    return source, command


def actual_modules(g8, expected):
    actual = g8.read_netlist(HERE / "disabled-control/candidate.json")["modules"]
    require(actual == expected, "disabled actual module dictionaries changed")
    audits = {name: g8.pll_port_audit(g8.Netlist(expected[name]["cells"], expected[name]["netnames"]),
                                    g8.Netlist(actual[name]["cells"], actual[name]["netnames"])) for name in expected}
    modules_sha = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return modules_sha, json.loads(json.dumps(audits))


def authenticate_control(g8=None):
    """Read-only shared API returning (sealed source identity, completed control)."""
    source_identity = authenticate_freeze()
    g8, old, expected, modules_sha, reference_inputs = load_reference(g8)
    source, command = expected_command(old)
    expected_inputs = control_inputs(source_identity, reference_inputs, source)
    output = HERE / "disabled-control"
    record = read(output / "comparison.json")
    require(record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and record["elapsed_seconds"] >= 0 and
            record["command"] == command and record["cwd"] == str(MODULE) and
            record["compiler_commit"] == source_identity["result_commit"] and record["base_compiler_commit"] == source_identity["base_commit"] and
            record["measured_base_commit"] == MEASURED and record["source_identity_sha256"] == sha(HERE / "source-identity.json") and
            record["source_archive_sha256"] == sha(HERE / "source.tar.gz") and record["binary_sha256"] == sha(HERE / "nextpnr-mistral") and
            record["reference_comparison_sha256"] == CONTROL_SHA and record["reference_sha256"] == ACCEPTED_SHA and
            record["cached_measured_full_proof_sha256"] == FULL_SHA and
            record["cached_parent_listing_proof_sha256"] == _freeze.PARENT_LIST_SHA and
            record["cached_comparison_helpers_reexecuted"] is False and record["input_sha256"] == expected_inputs and
            record["all_transform_options_disabled"] is True and record["root_selector_only_is_not_balance_reduction_enable"] is True and
            record["modules_equivalent"] is True and record["original_module_dictionaries_identical"] is True and
            record["ordered_duplicate_pll_exports_preserved"] is True and record["default_recipe_selected"] is False and record["hardware_tested"] is False,
            "new completed disabled control differs from the sealed source/command/proof contract")
    identity = f"base_commit={source_identity['base_commit']}; experimental_source_sha256={sha(HERE / 'source.tar.gz')}; sha256={sha(HERE / 'nextpnr-mistral')}"
    require(record["tool_identity"] == identity and record["output_sha256"] ==
            {str(output / name): sha(output / name) for name in ("candidate.json", "loader.log")} and
            record["candidate_sha256"] == sha(output / "candidate.json") and record["loader_log_sha256"] == sha(output / "loader.log"),
            "disabled control identity or output bytes changed")
    log = (output / "loader.log").read_text()
    require("Info: Program finished normally." in log and not any(marker in log for marker in
            ("Running the GPU router", "Local remap", "Comb remap", "Decomposition", "Capture locality", "Placed reduction")),
            "disabled control executed a transform or failed to finish")
    actual_sha, audits = actual_modules(g8, expected)
    require(record["modules_sha256"] == modules_sha == actual_sha and record["lossless_pll_port_audit"] == audits,
            "disabled modules/ordered duplicate PLL audit differs from the actual exports")
    base = read(G8 / "route-c0/run.json")
    require(read(FULL)["artifact_sha256"].get(str((G8 / "route-c0/run.json").relative_to(ROOT))) == sha(G8 / "route-c0/run.json"),
            "cached full proof omits its runtime reference")
    g8.ready.authenticate_execution(record, base)
    require(not any(key.startswith("NEXTPNR_MISTRAL_") for key in record["execution"]["environment"]),
            "disabled execution has transform environment")
    return source_identity, record


def main():
    source_identity = authenticate_freeze()
    g8, old, expected, modules_sha, reference_inputs = load_reference()
    source, command = expected_command(old)
    inputs = control_inputs(source_identity, reference_inputs, source)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    output = HERE / "disabled-control"
    require(not output.exists(), "disabled control output already exists")
    output.mkdir()
    identity = f"base_commit={source_identity['base_commit']}; experimental_source_sha256={sha(HERE / 'source.tar.gz')}; sha256={sha(HERE / 'nextpnr-mistral')}"
    record = {"command": command, "cwd": str(MODULE), "tool_identity": identity,
              "base_compiler_commit": source_identity["base_commit"], "compiler_commit": source_identity["result_commit"],
              "measured_base_commit": MEASURED, "source_identity_sha256": sha(HERE / "source-identity.json"),
              "source_archive_sha256": sha(HERE / "source.tar.gz"), "binary_sha256": sha(HERE / "nextpnr-mistral"),
              "execution": None, "input_sha256": inputs, "completed": False,
              "kind": "host-only disabled-transform JSON-loader control",
              "reference_comparison_sha256": CONTROL_SHA, "reference_sha256": ACCEPTED_SHA,
              "cached_measured_full_proof_sha256": FULL_SHA, "cached_parent_listing_proof_sha256": _freeze.PARENT_LIST_SHA,
              "cached_comparison_helpers_reexecuted": False, "all_transform_options_disabled": True,
              "root_selector_only_is_not_balance_reduction_enable": True, "default_recipe_selected": False, "hardware_tested": False,
              "proof_limitations": ["Actual module dictionaries and both ordered duplicate PLL outputs are compared; creator/version metadata outside modules may differ.",
                                    "No pack/place/route: physical pins, timing, holds, RBF and hardware behavior are not proved."]}
    invocation, start = None, time.monotonic()
    try:
        invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(HERE / "nextpnr-mistral", identity)}, 1)
        record["execution"] = invocation.inputs
        require(not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "disabled control has transform environment")
        with (output / "loader.log").open("x") as log:
            result = audited_run(command, source_root=MODULE, cwd=MODULE, env=invocation.env, stdout=log,
                                 stderr=subprocess.STDOUT, check=False, timeout=300)
        record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic()-start
        require(result.returncode == 0, "disabled loader failed")
        invocation.verify()
        log = (output / "loader.log").read_text()
        require("Info: Program finished normally." in log and not any(marker in log for marker in
                ("Running the GPU router", "Local remap", "Comb remap", "Decomposition", "Capture locality", "Placed reduction")),
                "disabled loader executed a transform or failed to finish")
        actual_sha, audits = actual_modules(g8, expected)
        require(actual_sha == modules_sha, "disabled normalized module digest changed")
        require(all(sha(Path(path)) == digest for path, digest in inputs.items()), "control inputs changed during execution")
        record.update({"completed": True, "modules_equivalent": True, "original_module_dictionaries_identical": True,
                       "modules_sha256": modules_sha, "lossless_pll_port_audit": audits, "ordered_duplicate_pll_exports_preserved": True,
                       "candidate_sha256": sha(output / "candidate.json"), "loader_log_sha256": sha(output / "loader.log"),
                       "output_sha256": {str(output / name): sha(output / name) for name in ("candidate.json", "loader.log")}})
        print(json.dumps({key: record[key] for key in ("completed", "modules_sha256", "candidate_sha256",
                                                     "ordered_duplicate_pll_exports_preserved")}), flush=True)
    except BaseException as error:
        record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic()-start
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        with (output / "comparison.json").open("x") as metadata:
            metadata.write(json.dumps(record, indent=2, sort_keys=True)+"\n")
        if invocation is not None:
            invocation.close()


if __name__ == "__main__":
    main()
