"""Root-operated proof for selected minimum200 reduction and fresh AC phases.

Listing truth is explicitly conditional on missing pin states. Routed proof
uses every actual pin snapshot. Cached predecessor proofs are hash-bound and
are never regenerated. No frozen helper globals or actual artifacts change.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import seal_profile as seal

HERE, ROOT = seal.HERE, seal.ROOT
require, sha, read = seal.require, seal.sha, seal.read
INITIAL_SHA = "17aec8fc88f324cbc895dadb62878658d78d7265d16dab58956618fb4cf731db"
MINIMUM_PS = 200
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
CONSTRAINTS = {PIXEL: 74.25006866455078, MEMORY: 130.00520324707031, CAPTURE: 130.00520324707031}
TARGET_MHZ = 116.27906799316406


def relative(path):
    return str(Path(path).resolve().relative_to(ROOT))


def serial(value):
    return json.loads(json.dumps(value))


def initial():
    require(sha(HERE / "compare.py") == INITIAL_SHA, "frozen initial comparator changed")
    return seal.module_at(HERE / "compare.py", "minimum200_frozen_initial_proof_api")


def prior_listing():
    record, proof = seal.authenticate_cached(HERE / "list-reduction", [HERE / "list-reduction/placed.json"])
    require(record["phase"] == "list-reduction" and record["compiler_commit"] == seal.RESULT and
            record["profile_sha256"] == sha(seal.PROFILE) and record["minimum_log_verified"] is True and
            proof["minimum_branch_gain_ps"] == MINIMUM_PS and proof["parent_qualification_inherited"] is False and
            proof["graph_proof_available"] is False and proof["partial_graph_evidence_available"] is True and
            proof["artifact_sha256"].get(relative(HERE / "compare.py")) == INITIAL_SHA,
            "fresh minimum200 initial qualification proof is not finalized")
    return record, proof


def selected_reduction(g8, log, specs, record, prior):
    blocks = g8.ranking.placed_log_blocks(log, specs)
    selected = record["reduction_selection"]
    require(selected in prior["qualified_reduction_ordinals"], "reduction ordinal was not freshly qualified")
    candidates = prior["new12_qualification"]["candidates"]
    require(0 <= selected < len(candidates), "fresh candidate detail missing")
    expected = candidates[selected]
    candidate_lines = list(re.finditer(r"^Info: Placed reduction candidate (\d+), .*\.$", blocks[1], re.M))
    require(candidate_lines and [int(match[1]) for match in candidate_lines] == list(range(selected + 1)),
            "actual selected reduction candidate sequence changed")
    last = candidate_lines[-1]
    require(last.group(0) == expected["candidate_log"], "selected reduction candidate differs from fresh listing")
    actual_prefix = [line for line in blocks[1][:last.end()].splitlines() if "Placed reduction" in line]
    fresh_log = (HERE / "list-reduction/route.log").read_text()
    fresh_specs = [{**spec, "candidate": -1 if index == 1 else spec["candidate"]} for index, spec in enumerate(specs)]
    fresh_block = g8.ranking.placed_log_blocks(fresh_log, fresh_specs)[1]
    fresh_matches = list(re.finditer(r"^Info: Placed reduction candidate (\d+), .*\.$", fresh_block, re.M))
    require(len(fresh_matches) > selected and actual_prefix ==
            [line for line in fresh_block[:fresh_matches[selected].end()].splitlines() if "Placed reduction" in line],
            "actual reduction trial/qualification prefix differs from its fresh listing")
    require(actual_prefix.count(seal.MINIMUM_LOG) == 1 and expected["guards"] == [1, 1, 1, 1] and
            expected["branch_gain_ps"] >= MINIMUM_PS and expected["endpoints"] == 227,
            "selected reduction lacks its exact minimum200/endpoint/clock/hold attribution")
    return expected, blocks


def reduction_cell_schema(g8, old, new, name, width, routed):
    a, b = old.cells[name], new.cells[name]
    mutable = {"type", "parameters", "port_directions", "connections", "attributes"}
    require({key: value for key, value in a.items() if key not in mutable} ==
            {key: value for key, value in b.items() if key not in mutable},
            "declared reduction changed unknown cell metadata: " + name)
    require({key: value for key, value in a["parameters"].items() if key != "LUT"} ==
            {key: value for key, value in b["parameters"].items() if key != "LUT"} and
            set(b["parameters"]) == {"LUT"} and type(b["parameters"]["LUT"]) is str and
            len(b["parameters"]["LUT"]) == 1 << width and set(b["parameters"]["LUT"]) <= {"0", "1"},
            "declared reduction changed non-LUT parameters or exported an invalid mask: " + name)
    ports = {**{pin: "input" for pin in "ABCDEF"[:width]}, "Q": "output"}
    require(b["port_directions"] == ports and set(b["connections"]) == set(ports) and
            all(type(bits) is list and len(bits) == 1 for bits in b["connections"].values()),
            "declared reduction port/direction/scalar schema changed: " + name)
    allowed = {"NEXTPNR_BEL", "FES_PINMAP_V1"} if routed else {"NEXTPNR_BEL"}
    require({key: value for key, value in a["attributes"].items() if key not in allowed} ==
            {key: value for key, value in b["attributes"].items() if key not in allowed},
            "declared reduction changed protected/source/strength attributes: " + name)


def physical_reduction_pins(g8, graph, cone):
    """Audit actual serialized pin state and the LUT6 dual-bank permutation.

    This derives the backend's physical truth image; it does not decode RBF
    configuration bits or invent a physical snapshot for pre-route exports.
    """
    rows = []
    for name in sorted(cone):
        width = g8.lut_shape(graph, name)
        snapshot = g8.ranking.pin_snapshot(graph, name)
        pins = snapshot["pins"]
        require(pins["Q"] == [0, "COMBOUT"] and all(
            len(pins[pin]) == 2 and pins[pin][0] in (0, 3) and type(pins[pin][1]) is str
            for pin in "ABCDEF"[:width]), "reduction has an incomplete/constant/non-signal physical pin: " + name)
        bel_match = re.fullmatch(r"MISTRAL_(?:M)?COMB\.(\d+)\.(\d+)\.(\d+)", previous_bel(g8, graph.cells[name]))
        require(bel_match is not None and int(bel_match[3]) % 6 in (0, 1), "invalid reduction COMB half")
        half = int(bel_match[3]) % 6
        physical = [pins[pin][1] for pin in "ABCDEF"[:width]]
        require(len(set(physical)) == width, "reduction logical pins share one physical input")
        if width != 6:
            require(width == 2 and set(physical) <= {"A", "B", "D" if half else "C", f"E{half}", f"F{half}"},
                    "public root physical inputs are not valid for its actual LUT half")
            rows.append({"cell": name, "width": width, "actual_pin_snapshot": snapshot,
                         "logical_truth_rows_checked": 4})
            continue
        require(physical == ["A", "B", "C", "D", f"E{half}", f"F{half}"],
                "ALUT6 physical mapping differs from all-six-connected architecture mapping")
        def physical_value(index, pin):
            bit = {"A": 0, "B": 1, "C": 3 if index >= 32 else 2,
                   "D": 2 if index >= 32 else 3, f"E{half}": 5, f"F{half}": 4}[pin]
            return (index >> bit) & 1
        table = int(graph.cells[name]["parameters"]["LUT"], 2)
        physical_mask, addresses, native_rows = 0, [], {}
        for index in range(64):
            native = sum((1 ^ physical_value(index, pin)) << bit for bit, pin in enumerate(physical))
            logical = sum((physical_value(index, pins[pin][1]) ^ (pins[pin][0] != 3)) << bit
                          for bit, pin in enumerate("ABCDEF"))
            require(native not in native_rows, "ALUT6 bank permutation is not bijective")
            native_rows[native] = index
            addresses.append(logical)
            physical_mask |= (1 ^ ((table >> logical) & 1)) << index
        require(set(addresses) == set(range(64)) and set(native_rows) == set(range(64)),
                "ALUT6 serialized mapping loses an essential input or bank")
        inversions = sum((pins[pin][0] == 3) << bit for bit, pin in enumerate("ABCDEF"))
        for native, index in native_rows.items():
            require(1 ^ ((physical_mask >> index) & 1) == (table >> (native ^ inversions)) & 1,
                    "ALUT6 physical dual-bank image differs from its actual logical state")
        rows.append({"cell": name, "width": 6, "actual_pin_snapshot": snapshot,
                     "logical_and_dual_bank_physical_rows_checked": 64,
                     "derived_active_low_physical_mask_hex": hex(physical_mask),
                     "actual_rbf_configuration_bits_independently_decoded": False})
    return rows


def reduction_shape(g8, source_top, candidate_top, initial_proof, selected, routed, declared_ac_users=frozenset()):
    """Recover the actual reused nodes and their twelve independent FF inputs."""
    api = initial()
    measured, new = api.netlist(g8, source_top), api.netlist(g8, candidate_top)
    reference_top = source_top if routed else api.top(g8, seal.LIST, "placed.json")
    old = measured if routed else api.netlist(g8, reference_top)
    root = seal.REDUCTION_ROOT
    cone, literals, nodes = g8.ranking.cube(measured, root)
    require(len(cone) == 3 and len(literals) == 12 and all(not value for value in literals.values()),
            "authenticated source is not the actual twelve-literal NOR")
    leaves, boundary = sorted(cone - {root}), sorted(literals)
    require(cone == set(initial_proof["source_twelve_literal_cube"]["source_cone"]) and
            previous_bel(g8, old.cells[root]) == previous_bel(g8, new.cells[root]) and
            new.cells[root]["type"] == "MISTRAL_ALUT2" and
            all(new.cells[name]["type"] == "MISTRAL_ALUT6" for name in leaves),
            "selected reduction did not reuse two six-input leaves and its fixed public root")
    require([previous_bel(g8, new.cells[name]) for name in leaves] == selected["leaf_bels"],
            "actual reused-leaf BELs differ from the freshly selected trial")
    require(set(new.inputs(root)) == {"A", "B"} and
            new.inputs(root) == {pin: [(name, "Q", 0)] for pin, name in zip("AB", leaves)},
            "new public root is not connected directly to its ordered two leaves")
    groups = []
    for name in leaves:
        reduction_cell_schema(g8, old, new, name, 6, routed)
        group = [token for tokens in new.inputs(name).values() for token in tokens]
        require(set(new.inputs(name)) == set("ABCDEF") and
                len(group) == len(set(group)) == 6 and set(group) <= set(boundary),
                "actual six-literal leaf partition contains a repeated or nonoriginal input")
        groups.append(set(group))
        require(new.direct_users.get((name, "Q", 0), []) == [(root, "AB"[leaves.index(name)], 0)],
                "a new reduction leaf acquired an undeclared consumer")
    require(groups[0].isdisjoint(groups[1]) and groups[0] | groups[1] == set(boundary),
            "actual balanced leaf partitions do not cover all twelve original literals exactly once")
    reduction_cell_schema(g8, old, new, root, 2, routed)
    require(old.direct_users.get((root, "Q", 0), []) == new.direct_users.get((root, "Q", 0), []),
            "shared public reduction root consumers changed")
    boundaries = {old.token(bit) for port in reference_top["ports"].values() for bit in port["bits"]}
    for name in cone - {root}:
        users = old.direct_users.get((name, "Q", 0), [])
        require((name, "Q", 0) not in boundaries and len(users) == 1 and users[0][0] in cone,
                "the absorbed source intermediate was not private")
    for token in boundary:
        before, after = old.direct_users.get(token, []), new.direct_users.get(token, [])
        require([user for user in before if user[0] not in cone] ==
                [user for user in after if user[0] not in cone and user[0] not in declared_ac_users] and
                sum(user[0] in cone for user in before) == sum(user[0] in cone for user in after) == 1,
                "an external literal's shared users or single cube use changed")
    old_tree = measured.expression((root, "Q", 0), set(boundary), set())
    if routed:
        actual_cone, actual_literals, actual_nodes = g8.ranking.cube(new, root)
        require(actual_cone == cone and actual_literals == literals, "actual routed pin polarity/function changed")
        new_tree = new.expression((root, "Q", 0), set(boundary), set())
        evaluate_new = lambda values: g8.previous.evaluate(new_tree, values)
        physical_pins = physical_reduction_pins(g8, new, cone)
    else:
        # The rewrite's intended signal states are an assumption here, never
        # fabricated as a final FES_PINMAP snapshot.
        for name in cone:
            require(not new.cells[name]["attributes"].get("FES_PINMAP_V1"), "listing has partial routed pins")
        def conditional(token, values):
            if token in values:
                return values[token]
            require(token[0] in cone and token[1:] == ("Q", 0), "unsupported listing cube driver")
            cell = new.cells[token[0]]
            width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
            address = sum(conditional(new.token(cell["connections"][pin][0]), values) << index
                          for index, pin in enumerate("ABCDEF"[:width]))
            return (int(cell["parameters"]["LUT"], 2) >> address) & 1
        evaluate_new = lambda values: conditional((root, "Q", 0), values)
        actual_nodes = [{"cell": name, "type": new.cells[name]["type"],
                         "mask_hex": hex(int(new.cells[name]["parameters"]["LUT"], 2)),
                         "bel": previous_bel(g8, new.cells[name])} for name in sorted(cone)]
        physical_pins = None
    table = []
    for row in range(4096):
        values = {token: (row >> bit) & 1 for bit, token in enumerate(boundary)}
        original, current = g8.previous.evaluate(old_tree, values), evaluate_new(values)
        require(original == current == int(row == 0), "twelve-literal equivalence failed on row " + str(row))
        table.append(current)
    closure = api.downstream_closure(g8, reference_top, candidate_top, root)
    return {"root": root, "reused_cells": sorted(cone), "reused_leaves": leaves,
            "original_nodes": nodes, "actual_nodes": actual_nodes, "external_boundary_order": boundary,
            "assignments_checked": 4096, "essential_literals": 12, "true_rows": sum(table),
            "truth_sha256": hashlib.sha256(bytes(table)).hexdigest(), "selected_trial": selected,
            "public_root_bel_fixed": True, "public_root_named_consumers_preserved": True,
            "literal_shared_users_preserved": True, "actual_pin_states_used": routed,
            "fresh_ac_extra_users_proved_separately": sorted(declared_ac_users),
            "listing_plain_signal_pin_states_are_assumptions": not routed,
            "actual_reduction_physical_pin_audit": physical_pins,
            "independent_current_listing_boolean_proof": False if not routed else None,
            "downstream_closure": closure}, cone


def previous_bel(g8, cell):
    return g8.previous.bel(cell)


def listing_graph(g8, reference_top, candidate_top, cone):
    api = initial()
    old, new = api.netlist(g8, reference_top), api.netlist(g8, candidate_top)
    require(set(old.cells) == set(new.cells) and not any(cell["type"] == "MISTRAL_BUF" for cell in new.cells.values()),
            "selected pre-route listing changed owners or contains route-created BUFs")
    for name in old.cells:
        a, b = old.cells[name], new.cells[name]
        if name not in cone:
            require(g8.dictionary_cell(old, name) == g8.dictionary_cell(new, name),
                    "outside-cone original/retained cell changed in listing: " + name)
        else:
            reduction_cell_schema(g8, old, new, name, 2 if name == seal.REDUCTION_ROOT else 6, False)
        require(b["attributes"].get("NEXTPNR_BEL") and not b["attributes"].get("FES_PINMAP_V1"),
                "listing has an unplaced cell or an unproved partial pin snapshot")
    g8.compare_named_nets(reference_top, candidate_top, old, new)
    g8.ranking.top_ports(reference_top, candidate_top, old, new)
    require({key: value for key, value in reference_top.items() if key not in {"cells", "netnames", "ports"}} ==
            {key: value for key, value in candidate_top.items() if key not in {"cells", "netnames", "ports"}},
            "selected listing changed module settings/attributes")
    for dictionary in ("cells", "netnames"):
        require(list(reference_top[dictionary]) == list(candidate_top[dictionary]), "listing owner order changed")
    return {"outside_three_declared_cells_named_dictionaries_exact": True,
            "all_original_ff_connections_bels_and_exported_attributes_exact": True,
            "ordered_lossless_pll_audit": g8.pll_port_audit(old, new), "owner_export_order_exact": True,
            "physical_pins_buffers_holds_and_user_slot_indices_not_proved": True}


def native_bits(graph):
    bits = {}
    for bit, token in graph.drivers.items():
        require(token not in bits, "ambiguous native output driver")
        bits[token] = bit
    return bits


def unwind_parent_ac(g8, parent_top, parent_proof):
    """Remove only the artifact-bound, already proved generated AC closure."""
    proof = parent_proof["decomposition_equivalence_on_ready_aligned_original_graph"]
    require(proof["assignments_checked"] == 128 and proof["all_original_buffers_preserved"] is True,
            "parent AC closure has no complete cached proof")
    graph = initial().netlist(g8, parent_top)
    edge = proof["selected_internal_input"]
    generated = [row["cell"] for row in proof["encoders"]] + [proof["root"]["cell"]]
    for row in [*proof["encoders"], proof["root"]]:
        require(g8.ready.detail(row["cell"], graph.cells[row["cell"]]) == row, "parent generated AC detail changed")
    require(g8.direct_connections(graph, edge["sink"])[edge["port"]] == [tuple(edge["candidate_driver"])],
            "parent AC selected redirect changed")
    aligned = copy.deepcopy(parent_top)
    bit = native_bits(graph)[tuple(edge["control_driver"])]
    aligned["cells"][edge["sink"]]["connections"][edge["port"]] = [bit]
    for name in generated:
        del aligned["cells"][name]
    for name in proof["added_private_q_nets"]:
        require(graph.token(parent_top["netnames"][name]["bits"][0])[0] in generated,
                "parent AC private alias points outside generated closure")
        del aligned["netnames"][name]
    return aligned, {"parent_proof_sha256": sha(seal.FULL / "comparison.json"), "cached_rows": 128,
                     "removed_generated_cells": generated, "removed_generated_nets": proof["added_private_q_nets"],
                     "restored_original_input": edge, "reference_is_algebraic_not_an_independent_route": True}


def lab_snapshot_delta(g8, old_top, new_top, cone):
    def decode(top):
        value = json.loads(bytes.fromhex(top["attributes"]["FES_LABSTATE_V1"]).decode(),
                           object_pairs_hook=g8.staged.unique_object)
        require(set(value) == {"device", "labs"} and value["device"] == "5CSEBA6U23I7", "invalid LAB snapshot schema")
        rows = {}
        for row in value["labs"]:
            require(type(row) is list and len(row) == 4 and all(type(item) is int for item in row[:3]) and
                    type(row[3]) is list and len(row[3]) == 62 and all(type(item) is int for item in row[3]) and
                    tuple(row[:2]) not in rows, "invalid/duplicate LAB snapshot row")
            rows[tuple(row[:2])] = row
        return value, rows
    def location(cell):
        match = re.fullmatch(r"MISTRAL_(?:M)?COMB\.(\d+)\.(\d+)\.(\d+)", previous_bel(g8, cell))
        return (*map(int, match.groups()[:2]), int(match[3]) // 6) if match else None
    def occupants(top):
        result = {}
        for name, cell in top["cells"].items():
            loc = location(cell)
            if loc is not None:
                result.setdefault(loc, []).append((name, cell["type"], previous_bel(g8, cell)))
        return result
    old_occupants, new_occupants = occupants(old_top), occupants(new_top)
    allowed = {location(top["cells"][name]) for top in (old_top, new_top) for name in cone}
    allowed.discard(None)
    before, old_rows = decode(old_top)
    after, new_rows = decode(new_top)
    require(list(old_rows) == list(new_rows), "physical LAB row identity/order changed")
    changes = []
    for key, row in old_rows.items():
        other = new_rows[key]
        require(row[:3] == other[:3], "physical LAB metadata changed")
        for index, value in enumerate(row[3]):
            expected = other[3][index]
            if index >= 2 and (index - 2) % 6 == 0:
                alm = (index - 2) // 6
                for occupancy, actual in ((old_occupants, value), (new_occupants, expected)):
                    cells = occupancy.get((*key, alm), [])
                    lut6 = [cell for cell in cells if cell[1] == "MISTRAL_ALUT6"]
                    require(actual == int(bool(lut6)) and (not lut6 or len(cells) == len(lut6) == 1),
                            "ALUT6 mode/whole-ALM occupancy differs from actual COMB/BUF occupants")
                if value != expected:
                    require((*key, alm) in allowed, "L6 mode changed outside declared reduction ALMs")
                    changes.append({"lab": key, "alm": alm, "old_l6_mode": value, "new_l6_mode": expected})
            else:
                require(value == expected, "carry/clock-enable/clear or LAB control state changed")
    require({key: value for key, value in old_top["attributes"].items() if key != "FES_LABSTATE_V1"} ==
            {key: value for key, value in new_top["attributes"].items() if key != "FES_LABSTATE_V1"} and
            old_top["settings"] == new_top["settings"], "unrelated routed top attributes/settings changed")
    return {"declared_reduction_alm_l6_mode_changes": changes,
            "l6_modes_match_actual_alut6_occupancy": True, "each_alut6_has_the_whole_comb_alm": True,
            "all_other_lab_snapshot_fields_exact": True}


def aligned_reduction_reference(g8, old_top, new_top, cone, lab_proof):
    """Copy only independently proved reduction state into the native reference."""
    old, new = initial().netlist(g8, old_top), initial().netlist(g8, new_top)
    bits, aligned = native_bits(old), copy.deepcopy(old_top)
    for name in cone:
        a, b = old.cells[name], new.cells[name]
        reduction_cell_schema(g8, old, new, name, 2 if name == seal.REDUCTION_ROOT else 6, True)
        aligned["cells"][name] = copy.deepcopy(b)
        connections = {}
        for pin, values in b["connections"].items():
            tokens = [new.drivers.get(bit, new.token(bit)) for bit in values]
            require(all(token in bits for token in tokens), "reduction introduced a nonoriginal signal")
            connections[pin] = [bits[token] for token in tokens]
        aligned["cells"][name]["connections"] = connections
    require(lab_proof["all_other_lab_snapshot_fields_exact"] is True, "LAB metadata adjustment lacks its proof")
    aligned["attributes"]["FES_LABSTATE_V1"] = new_top["attributes"]["FES_LABSTATE_V1"]
    return aligned


def actual_retained_stack(g8, top, phase, log, parent_proof):
    """Use the cached g8 rows as identities, then prove the current functions."""
    control_top = g8.read_netlist(g8.staged.CONTROL / "routed.json")["modules"]["top"]
    control, candidate = initial().netlist(g8, control_top), initial().netlist(g8, top)
    steps = phase["local_steps"]
    models = g8.local_models(log, {"local_steps": steps})
    priors = parent_proof["retained_local_clone_equivalences"]
    require(len(steps) == len(models) == len(priors) == 3, "retained local-stage proof count changed")
    local_proofs = []
    for step, model, prior in zip(steps, models, priors):
        clone, selected = g8.discover_local_users(control, candidate, model)
        require(clone == prior["clone"]["cell"] and serial(model) == prior["selected_stage_log"],
                "retained local clone or actual selected-stage model changed")
        local_proofs.append(g8.staged.prove_local(control, candidate, clone, selected, step, model))
    prior_comb = parent_proof["retained_comb_equivalence"]
    comb_proof = g8.comb.prove_cut(control, candidate, prior_comb["clone"]["cell"],
                                 [prior_comb["selected_internal_input"]], read(g8.comb.GUIDE_REPORT),
                                 g8.comb.selected_candidate(log, 0))
    require([proof["assignments_checked"] for proof in local_proofs] == [32, 16, 16] and
            comb_proof["assignments_checked"] == 32, "retained local/comb exhaustive proof sizes changed")
    parent = initial().netlist(g8, initial().top(g8, seal.FULL, "routed.json"))
    root = phase["reduction_steps"][0]["root"]
    before, after = g8.ranking.cube(parent, root), g8.ranking.cube(candidate, root)
    require(len(before[0]) == len(after[0]) == 3 and len(before[1]) == len(after[1]) == 11 and
            before[0] == after[0] and before[1] == after[1], "retained placed11 symbolic support/function changed")
    placed_proof = {"original_nodes": before[2], "actual_nodes": after[2], "essential_input_count": 11,
                    "symbolic_cube_equivalence": True, "at_most_64_rows_per_lut": True}
    return local_proofs, comb_proof, placed_proof


def clock_gates(g8, report, parent, log, record):
    require(set(report["fmax"]) == set(CONSTRAINTS) and set(parent["fmax"]) == set(CONSTRAINTS), "required clock set changed")
    for clock, constraint in CONSTRAINTS.items():
        row = report["fmax"][clock]
        require(set(row) == {"achieved", "constraint"} and row["constraint"] == parent["fmax"][clock]["constraint"] == constraint and
                all(type(row[key]) in (int, float) and math.isfinite(row[key]) and row[key] > 0 for key in row),
                "actual quantized clock constraint or finite positive Fmax changed")
    require(parent["fmax"][MEMORY]["achieved"] == TARGET_MHZ, "accepted target-clock reference changed")
    def paths(document):
        result = {}
        for path in document["critical_paths"]:
            key = (path["from"], path["to"])
            require(key not in result and type(path["max_delay"]) in (int, float) and math.isfinite(path["max_delay"]),
                    "duplicate/nonfinite critical path window")
            result[key] = path
        return result
    old_paths, new_paths = paths(parent), paths(report)
    require(set(old_paths) == set(new_paths) and len(new_paths) == 6, "required six clock-pair windows changed")
    capture_key = ("posedge " + CAPTURE, "negedge " + MEMORY)
    target_key = ("posedge " + MEMORY, "posedge " + MEMORY)
    require(old_paths[capture_key]["max_delay"] == new_paths[capture_key]["max_delay"] == 5,
            "capture phase window is not the exact accepted5ns")
    windows = []
    for key, path in new_paths.items():
        require(path["max_delay"] == old_paths[key]["max_delay"] and path["path"], "related clock-pair window changed")
        segments = path["path"]
        require(segments[-1]["type"] == "setup" and sum(segment["type"] == "setup" for segment in segments) == 1 and
                sum(segment["type"] == "clk-skew" for segment in segments) <= 1 and
                all(segment["type"] in {"clk-skew", "clk-to-q", "source", "routing", "logic", "setup"} and
                    type(segment["delay"]) in (int, float) and math.isfinite(segment["delay"]) for segment in segments),
                "critical path omits setup or contains unknown/nonfinite segments")
        total = math.fsum(segment["delay"] for segment in segments)
        headroom = path["max_delay"] - total
        require(math.isfinite(total) and math.isfinite(headroom), "nonfinite complete path sum")
        windows.append({"from": key[0], "to": key[1], "max_delay_ns": path["max_delay"],
                        "complete_segment_sum_ns": total, "setup_headroom_ns": headroom,
                        "positive_headroom_required": key != target_key, "passes_window": key == target_key or headroom > 0})
    require("Running signoff timing analysis..." in log, "final signoff block missing")
    hold = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
    require(record["final_reported_hold_violations"] is hold and record["fmax"] == report["fmax"],
            "final hold/Fmax metadata disagrees with actual outputs")
    achieved = report["fmax"]
    practical = achieved[MEMORY]["achieved"] > TARGET_MHZ and all(
        achieved[clock]["achieved"] >= CONSTRAINTS[clock] for clock in (PIXEL, CAPTURE)) and all(
        row["passes_window"] for row in windows) and not hold
    nonregression = all(achieved[clock]["achieved"] >= parent["fmax"][clock]["achieved"] for clock in CONSTRAINTS)
    return {"passes_practical_timing_gate": practical, "all_clock_fmax_nonregression_vs_accepted_g8": nonregression,
            "passes_strict_diagnostic_gate_vs_accepted_g8": practical and nonregression,
            "passes_all_clock_constraints": all(achieved[clock]["achieved"] >= CONSTRAINTS[clock] for clock in CONSTRAINTS),
            "target_memory_gain_mhz": achieved[MEMORY]["achieved"] - TARGET_MHZ,
            "required_related_windows": windows, "capture_phase_window_ns": 5,
            "final_reported_hold_violations": hold, "non_target_fmax_nonregression_is_not_a_practical_requirement": True}


def comparison(folder):
    api = initial()
    profile, g8, base, parent_proof, _, source, disabled = seal.load_profile()
    record = read(folder / "run.json")
    phase = seal.authenticate_phase(record)
    require(phase["phase"] in {"list-ac", "route"} and folder.resolve() == phase["folder"].resolve() and
            source["result_commit"] == seal.RESULT and record["completed"] is True and
            type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and record["elapsed_seconds"] >= 0,
            "applied phase is not the finalized selected listing or full route")
    _, prior = prior_listing()
    routed = phase["phase"] == "route"
    mutable = {"command", "remap_plan_sha256", "decomposition_selection", "decomposition_report_sha256",
               "experimental_placed_reduction", "list_only", "fresh_listing", "execution", "input_sha256", "completed",
               "elapsed_seconds", "exit_code", "fmax", "final_reported_hold_violations", "kind", "runner_sha256",
               "base_compiler_commit", "compiler_commit", "compiler_bytes_unchanged", "source_archive_sha256",
               "tool_identity", "disabled_control_sha256"}
    require(all(record.get(key) == value for key, value in base.items() if key not in mutable),
            "undeclared inherited profile metadata change")
    required = ["run.json", "route.log", "routed.json", "timing.json", "core.rbf"] if routed else ["run.json", "route.log", "placed.json"]
    digests = {Path(path): digest for path, digest in record["input_sha256"].items()}
    digests.update({folder / name: sha(folder / name) for name in required})
    digests[HERE / "compare.py"] = INITIAL_SHA
    digests[Path(__file__).resolve()] = sha(Path(__file__).resolve())
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()),
            "applied phase did not finish normally")
    metrics = g8.previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and metrics == g8.previous.PLACEMENT_METRICS.findall((seal.LIST / "route.log").read_text()),
            "ordinary placement changed")
    selected, _ = selected_reduction(g8, log, phase["reduction_steps"], record, prior)
    candidate_top = api.top(g8, folder, "routed.json" if routed else "placed.json")
    source_top = api.top(g8, seal.FULL, "routed.json")
    if routed:
        source_top, unwind = unwind_parent_ac(g8, source_top, parent_proof)
        declared_ac_users = set(candidate_top["cells"]) - set(source_top["cells"])
        require(len(declared_ac_users) in (2, 3) and all(g8.MARKER in name for name in declared_ac_users),
                "fresh full graph additions exceed the declared AC closure")
    else:
        declared_ac_users = set()
    reduction, cone = reduction_shape(g8, source_top, candidate_top, prior, selected, routed, declared_ac_users)
    retained, _ = api.retained_stack(g8, log, phase["reduction_steps"], parent_proof,
                                    api.top(g8, seal.LIST, "placed.json"), candidate_top)
    common = {"phase": phase["phase"], "compiler_commit": seal.RESULT, "minimum_branch_gain_ps": MINIMUM_PS,
              "retained_stage_minimum_branch_gain_ps": 250, "candidate_completed": True,
              "elapsed_seconds": record["elapsed_seconds"], "parent_qualification_inherited": False,
              "matched_placement_metrics": 71, "placement_metrics_identical": True,
              "current_twelve_reduction": reduction, "retained_stack": retained,
              "initial_qualification_proof_sha256": sha(HERE / "list-reduction/comparison.json"),
              "qualified_reduction_ordinals": [record["reduction_selection"]],
              "old_comparison_helpers_reexecuted": False, "default_recipe_selected": False, "hardware_tested": False,
              "new_disabled_control_sha256": sha(HERE / "disabled-control/comparison.json")}
    if not routed:
        require(record["decomposition_selection"] == -1 and not any(key in record for key in ("fmax", "final_reported_hold_violations")) and
                "Running the GPU router" not in log and "Running signoff timing analysis" not in log and
                not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
                "AC listing contains route/final timing claims")
        graph = listing_graph(g8, api.top(g8, seal.LIST, "placed.json"), candidate_top, cone)
        ac = g8.verify_decomposition_log(log, -1)
        common.update({"status": "selected minimum200 reduction; fresh AC listing; conditional truth only",
                       "graph_proof_available": False, "partial_graph_evidence_available": True, "route_started": False,
                       "listing_graph": graph, "decomposition_selection": ac,
                       "qualified_ac_ordinals": list(range(ac["qualified_candidates"])),
                       "timing_acceptance_available": False,
                       "proof_limitations": ["Pre-route physical/logical pins and route-created BUFs are unavailable.",
                                             "Current4096 rows assume the rewritten LUT pins are plain signals.",
                                             "In-memory owner identity, indexed-user slots/free lists and final clocks/holds/RBF are not proved."]})
    else:
        require((folder / "core.rbf").stat().st_size > 0 and "Running the GPU router" in log,
                "full GPU route/RBF absent")
        lab = lab_snapshot_delta(g8, source_top, candidate_top, cone)
        aligned = aligned_reduction_reference(g8, source_top, candidate_top, cone, lab)
        guide = read(Path(base["command"][base["command"].index("--remap-decompose-critical") + 1]))
        ac_proof = g8.prove_rewrite(aligned, candidate_top, guide)
        ac = g8.verify_decomposition_log(log, record["decomposition_selection"], ac_proof)
        locals_, comb, placed = actual_retained_stack(g8, candidate_top, phase, log, parent_proof)
        fresh_record, fresh_proof = seal.authenticate_cached(HERE / f"list-ac-r{record['reduction_selection']}",
                                                           [HERE / f"list-ac-r{record['reduction_selection']}" / "placed.json"])
        require(record["decomposition_selection"] in fresh_proof["qualified_ac_ordinals"], "AC ordinal not freshly qualified")
        fresh_log = (HERE / f"list-ac-r{record['reduction_selection']}" / "route.log").read_text()
        fresh_candidates, actual_candidates = list(g8.CANDIDATE.finditer(fresh_log)), list(g8.CANDIDATE.finditer(log))
        selection = record["decomposition_selection"]
        require(len(fresh_candidates) > selection and actual_candidates and
                [line for line in fresh_log[:fresh_candidates[selection].end()].splitlines() if "Decomposition" in line] ==
                [line for line in log[:actual_candidates[-1].end()].splitlines() if "Decomposition" in line],
                "actual AC discovery/trial/selection prefix differs from its fresh listing")
        report, parent_report = read(folder / "timing.json"), read(seal.FULL / "timing.json")
        gates = clock_gates(g8, report, parent_report, log, record)
        common.update({"status": "fully proved selected minimum200 reduction and freshly selected AC; practical gates recorded",
                       "graph_proof_available": True, "partial_graph_evidence_available": False, "route_started": True,
                       "algebraic_parent_ac_unwind": unwind, "proved_lab_snapshot_delta": lab,
                       "actual_ac_equivalence": ac_proof, "decomposition_selection": ac,
                       "retained_local_equivalences": locals_, "retained_comb_equivalence": comb,
                       "retained_placed11_equivalence": placed, "qualified_ac_ordinals": [selection],
                       "actual_selected_ac_prefix_matches_fresh_listing": True,
                       "timing_acceptance_available": True, "passes_practical_acceptance": gates["passes_practical_timing_gate"],
                       "clock_gates": gates, "fmax": report["fmax"],
                       "proof_limitations": ["JSON does not serialize indexed-user slot IDs, free lists or in-memory owner/bucket identity.",
                                             "Algebraic references carry only individually proved reduction cells and l6-mode changes."]})
    require(all(sha(path) == digest for path, digest in digests.items()), "artifacts changed during comparison")
    common["final_metadata_stable_during_comparison"] = True
    common["artifact_sha256"] = {relative(path): digest for path, digest in sorted(digests.items())}
    return common


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    require(not (args.folder / "comparison.json").exists(), "comparison output already exists")
    result = serial(comparison(args.folder))
    with (args.folder / "comparison.json").open("x") as output:
        output.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: result[key] for key in ("phase", "graph_proof_available", "candidate_completed",
                                                "qualified_ac_ordinals")}, indent=2))


if __name__ == "__main__":
    main()
