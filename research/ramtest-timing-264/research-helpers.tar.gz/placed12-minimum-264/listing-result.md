# Placed twelve-literal reduction: 200 ps admission experiment

This is a local compiler experiment at `6552942de15ed48e1bb9fbc71e3c08f189486313`, based on generic 7–12 literal support at `8e305cb994d797a79a93a0cf2f30aaf9980d8642`. Both commits are unpushed. PR97 is merged; this experiment has not incorporated its merged-main sibling #96 and is not a combined-main, FES-selection or hardware result.

The new generic option accepts a positive fourth `MIN_BRANCH_GAIN_PS` field in a placed-reduction stage. The retained eleven-literal stage keeps its original three fields and default 250 ps; only the appended twelve-literal stage requests 200 ps. Endpoint, clock, hold, legality, ranking, sixteen-trial and rollback guards remain unchanged. Both binaries built, all 35 focused backend tests passed in 137.942 s, source/test peer review was clean. The CLI suite was not rerun for this delta. `validation/host-validation.json` binds the committed three-file delta, producer binaries and test history.

Root-operated freeze, disabled-transform loader control and profile sealing passed. The loader exports exactly the old candidate bytes, preserving both PLL clock-vector outputs. The separate listing audit losslessly preserves duplicate PLL outclk entries. Profile `101fb96b2cee5746d6b92bf0c8c95963b9c196c559333fa50a3430b163a66d4e` binds 208 inputs. It keeps the accepted groups8/1/1, legacy comb0, capture60 and placed11 candidate0 stack, fixed RTL/synthesis/BUILD_ID/seed/GPU selection, and appends the twelve-literal stage with minimum200.

Fresh `list-reduction` completed in 545.3157827099785 s with exit0. Exactly one of sixteen trials qualified: fresh ordinal0, leaf BELs `MISTRAL_COMB.17.16.13` and `MISTRAL_COMB.17.16.54`, modeled branch and endpoint gains234 ps, all four guards passing. No candidate was applied in this listing. The earlier 250 ps listing had rejected the same modeled gain only because of the admission heuristic.

The first execution of the frozen initial comparator passed. Comparison `750971e50c611efdf7c0db909f50630a645dcacb4872b0f391899b3b4756a0b6` binds213 artifacts and proves same-phase named dictionaries, topology, masks, BELs, export order, PLL rollback and all71 placement metrics; the retained optimization stack; all4096 actual routed-source NOR12 truth rows; and the five-net/227-ENA downstream closure. The current listing truth calculation explicitly assumes the reference logical pin states. In-memory storage slots, free lists, buckets and pointers are not serialized and are not claimed. No current final pin/BUF/clock/hold/RBF or routed-gain proof is available.

Root has launched fresh `list-ac --reduction-candidate 0`. Its qualification must be proved independently before a selected AC candidate can be routed. `compare.py` remains frozen and accepts the initial listing only; a separate `compare_applied.py` is being drafted for actual selected-reduction/AC proof. Cached earlier comparisons are authenticated as lineage, not replayed or inherited as fresh qualification.

A follow-up PR still needs a verified routed memory improvement over116.27906799316406 MHz, passing actual required pixel/capture constraints, unchanged clock-pair/window coverage with positive headroom outside the target memory period, no final hold violations, and complete actual graph/pin/BEL/BUF/PLL proof outside declared equivalent changes. Historical stricter acceptance flags remain unchanged. No new timing gain, PR, compiler selection, RTL/ABI/constraint change or hardware acceptance is claimed;130 MHz remains unresolved.

Immutable evidence identities:

- Binary: `45cf034723018ec67ad934bd24c07ce21a516f68a0284c934e1ffd3c6729170c`.
- Source identity: `fd475c47e32fc6595168d8c130b0573a53e6d86a9d588f844291a61256f2a693`.
- Disabled control: `39d335aa9cc72ba297b5b2b372e51bb92222427b3c836910c4a88303270a235c`.
- Fresh listing run: `caa54da46549c8dad50a52a1205c9a96c932c3fd22c86eeb1d9b1dc39d8d7641`.
- Initial comparator: `17aec8fc88f324cbc895dadb62878658d78d7265d16dab58956618fb4cf731db`.
- Focused host validation: `7b116d728f1dd7c84ee8890eb3fbabe7ad72217ab99fcc8023d31e3e4becb389`.
