# Minimum200 full route: rejected

The fresh selected reduction0 and AC0 full GPU1 route at compiler `6552942de15ed48e1bb9fbc71e3c08f189486313` completed normally with exit0 in717.7635991189163 s. Reported memory is116.13053131103516 MHz, pixel93.3096923828125 MHz and capture378.5823974609375 MHz. Memory regresses0.14853668212890625 MHz against the accepted116.27906799316406 MHz result, so this trial fails the practical target-gain rule. It is not a gain or a publication candidate.

The final signoff reports no hold violations. Actual required pixel/capture constraints are74.25006866455078/130.0052032470703 MHz and both pass. All six accepted clock-pair windows remain present with unchanged periods; every non-target window has positive setup headroom. The capture-positive→memory-negative5 ns window uses1.7170000709593296 ns and leaves3.2829999290406704 ns. The target same-memory-clock path uses8.61099997535348 ns against7.691999912261963 ns and still misses130 MHz. The separate diagnostic `route-timing-diagnostic.json` records every complete segment sum, the false practical gate and the false historical stricter gate. It is a timing diagnosis, not a full acceptance proof.

Fresh initial listing and selected-reduction AC listing comparisons passed earlier (`750971e5…` and `af4ab4f5…`,213 and218 artifacts). Those are explicitly partial, pre-route proofs. They do not establish this full route's physical preservation.

The first execution of the frozen full comparator failed at its declared-AC-additions precondition. The actual route removed `ddr1_status_MISTRAL_FF_Q_177$ROUTETHRU` at COMB17.16.13 and added `ddr1_status_MISTRAL_FF_Q_173$ROUTETHRU` at COMB17.16.19. This is not a BUF rename: the first branch carries group_addr[7] and the second group_addr[2]. The reused numeric output bit123376 does not identify the same logical source. FF177 now takes its source directly; FF173 now takes the new BUF output. Their FF BELs, complete exported pin maps and other cell metadata remain equal, but their direct DATAIN topology changed. The new ALUT6 leaf occupies the old BUF site, and the vacated old leaf site permits the new route-through.

`route-buffer-diagnostic.json` was produced separately through the frozen lossless parser and an authenticated algebraic unwind of the already proved parent AC closure. It identifies exactly three changed reused reduction cells, the fresh AC sink, the two changed FF direct DATAIN branches, one removed BUF and three added AC cells plus one added BUF. It retains actual BUF pin/BEL/schema/user details and both ordered PLL outputs. It explicitly claims no full acceptance proof. No independent identity-chain Boolean proof, named-net preservation or unchanged physical topology is asserted. The strict comparator correctly rejects this change outside its declared scope; no `route-reduction0-ac0/comparison.json` exists.

The failed full attempt log and frozen `compare_applied.py` remain unchanged. No comparator relaxation, old evidence rewrite, new PR/push, FES compiler selection, RTL/ABI/constraint change, combined-main reproduction or hardware acceptance was performed. Local generic7–12 support and the optional admission margin remain tested but unpushed. PR97 is merged, and the verified116.279 MHz result remains the accepted reference. This compiler branch has not incorporated merged-main sibling#96. Root operated all executions; independent static review confirmed the diagnostic and strict rejection.

Next work corrects two generic narrow-search omissions: rank leaf pairs with the future ALUT2's actual unequal input arcs, and use distinct physical ALM representatives for ALUT6 shortlists. The changes also affect the retained eleven-literal stage, so every changed stage will need fresh candidate qualification; old ordinals cannot be assumed to retain their meaning. No future route gain is predicted from these fixes.

Immutable identities:

- Full run: `c9cae19b10b317279b3945c8f5b4eae94a1c4860b4fdee4f834a469affe1693b`.
- Routed graph: `37ddb764483b666b7d5af8d8578974560983631f9eb98adec48eedbccf059cb4`.
- Timing report: `5e29dece1476386d4a5f901431fc8174d6502cb00aba8a9eab9a9120b2861394`.
- RBF: `88cf15331ab114e96ddc4c9dc69a08725bb8147c29b1ed2d288dd5771f379070`.
- Failed full attempt: `629412f2a643a6b3d935579da06bb1072e63700319371034dd4fe013a45758ac`.
- Frozen full comparator: `74e26acd4dedd71a3ded9994017dce6432d84a111b4a80b4ccca870c95dd2a3d`.
- Buffer diagnostic helper/output: `389cbb14958c1e79ffd26dd76338434594d32e7dc1e2950271371451ec183ad3` / `f7274fa83dfb5cabccfcabf4feff106ebda4c26808917d2346132d1cc16f2f2c`.
- Timing diagnostic helper/output: `36bf475c22fce6e8d29b9d0d1c1f6e4837fa53c908442a9ef70a5677eec2be2d` / `82b90b32f618a9fe36908c8e0121ca1cc6cf5c9f067472cf934a1900f92828fb`.
