"""Root-operated three-file committed delta freeze for a per-stage admission margin.

Authenticate the cached 8e listing/source/control closure without replaying its
helpers or reading its obsolete producer-binary path. Only the three changed
HEAD files are archived; the remaining tree is bound through exact Git diff
scope and the frozen parent evidence. No build, route or candidate selection.
"""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SRC = ROOT / "sources/misteross/build/toolchain-ramtest-timing/src/nextpnr"
BUILD = ROOT / "sources/misteross/build/toolchain-ramtest-timing/build/nextpnr"
PARENT = HERE.parent / "placed12-reduction-264"
G8 = HERE.parent / "ready-g8-decomposition-264"
BASE = "8e305cb994d797a79a93a0cf2f30aaf9980d8642"
RESULT = "6552942de15ed48e1bb9fbc71e3c08f189486313"
MEASURED = "6ad210a60991f93a607ac4490d6282b1267ec64a"
CUMULATIVE_BASE = "91f3ad1bd8bbebd09e5a7ffb92e5026c5558e771"
EXPECTED_BINARY_SHA = "45cf034723018ec67ad934bd24c07ce21a516f68a0284c934e1ffd3c6729170c"
EXPECTED_TEST_BINARY_SHA = "a288d8a77dd803a4e83a93e4e1e81ff8558d3b13e85030016ba80568256c9f8b"
HOST_VALIDATION = HERE / "validation/host-validation.json"
HOST_VALIDATION_SHA = "7b116d728f1dd7c84ee8890eb3fbabe7ad72217ab99fcc8023d31e3e4becb389"
PLAN = HERE / "experiment-plan.json"
PLAN_SHA = "25ebfd7fdb8355837f4a1557ffadabe8009e17d5759605d2d486d423b3ecc78c"
CHANGED = {"mistral/placed_reduction.cc", "mistral/tests/placed_reduction.cc", "mistral/reduction_balance.md"}
PARENT_CHANGED = {"mistral/reduction_balance_policy.h", "mistral/reduction_balance.cc", "mistral/reduction_balance.md",
                  "mistral/placed_reduction.cc", "mistral/tests/local_remap.cc", "mistral/tests/placed_reduction.cc"}
BASE_DOCS = {"docs/mistral-reduction-balance.md", "docs/mistral-capture-locality.md", "docs/mistral-control-remapping.md"}
PARENT_LIST_SHA = "b7c9b20a715ce9db056d07a3776e218c6bd18e2bb42c9fef5d360fcfb30e7ed5"
PARENT_FILES = {
    "source-identity.json": "fd1afaff4d70ba48aa98420ddc6ffd92bd638e2099ee0a8df0e83faaf2558034",
    "source.tar.gz": "e173e234773f37de85d5e0645ffe83ef2bd5b1e7119b6368caa8226384621e80",
    "nextpnr-mistral": "a146cb930a368afeabe9398c503f134cf8bdabec57083a5ec968c2a4ebbaedb2",
    "change.patch": "d6fa096ae6152e457d286c9b70f04cc3a0fd9d39e9f926e501705ec8edabe656",
    "freeze.py": "f08a7a21f3a73c239043d73b4cd2d23b758fb42c72bfb29bcb13542c745adcb3",
    "check_disabled_control.py": "5dc29a74d80c505b5e0fb147428ae86ec04ad0cf91d94f331ac513337555d68e",
    "disabled-control/comparison.json": "cca8ad3c06a0fd418f6b6c6c71354a300f0afe97acda386b32ffd0423b432ded",
    "disabled-control/candidate.json": "4d9333b4ce26872c6a77ff24b699e361b498b0c2cb7193dcaf87b5eedf5a0835",
    "disabled-control/loader.log": "9c68dc68c8854206866cb7f8f2682b54fd63c462ef264d9149ca9baa73a8bf96",
}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata value: " + value)
    return json.loads(path.read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def git(*args, text=True):
    return subprocess.check_output(["git", *args], cwd=SRC, text=text)


def add_input(inputs, path, digest):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT) and sha(path) == digest, "frozen input changed: " + str(path))
    require(str(path) not in inputs or inputs[str(path)] == digest, "input digest collision: " + str(path))
    inputs[str(path)] = digest


def archive_payloads(path, expected):
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        require(len(members) == len(expected) and all(member.isfile() for member in members) and
                {member.name for member in members} == set(expected), "archive member set differs: " + str(path))
        payloads = {member.name: archive.extractfile(member).read() for member in members}
    require(all(hashlib.sha256(payload).hexdigest() == expected[name] for name, payload in payloads.items()),
            "archive payload differs: " + str(path))
    return payloads


def parent_source():
    """Read frozen parent records only; never call its freezer or comparison."""
    inputs = {}
    for filename, digest in PARENT_FILES.items():
        add_input(inputs, PARENT / filename, digest)
    add_input(inputs, PARENT / "list-reduction/comparison.json", PARENT_LIST_SHA)
    proof = read(PARENT / "list-reduction/comparison.json")
    require(proof["candidate_completed"] is True and proof["final_metadata_stable_during_comparison"] is True and
            proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False and
            proof["qualified_reduction_ordinals"] == [], "cached parent initial listing is not the sealed partial result")
    for name, digest in proof["artifact_sha256"].items():
        add_input(inputs, ROOT / name, digest)
    for path in (PARENT / "list-reduction" / name for name in ("run.json", "route.log", "placed.json")):
        require(proof["artifact_sha256"].get(str(path.relative_to(ROOT))) == sha(path), "parent listing omits its raw artifact")
    for filename, digest in PARENT_FILES.items():
        require(proof["artifact_sha256"].get(str((PARENT / filename).relative_to(ROOT))) == digest,
                "parent listing omits a frozen source/control input: " + filename)
    run = read(PARENT / "list-reduction/run.json")
    require(run["completed"] is True and type(run["exit_code"]) is int and run["exit_code"] == 0 and
            run["compiler_commit"] == BASE and run["list_only"] is True, "parent listing run is not complete")
    parent = read(PARENT / "source-identity.json")
    require(parent["base_commit"] == CUMULATIVE_BASE and parent["result_commit"] == BASE and
            parent["measured_base_commit"] == MEASURED and set(parent["source_sha256"]) == PARENT_CHANGED and
            parent["changed_files"] == sorted(PARENT_CHANGED) and
            set(parent["baseline_docs_only_changed_files"]) == BASE_DOCS and
            parent["binary_sha256"] == PARENT_FILES["nextpnr-mistral"] and
            parent["source_archive_sha256"] == PARENT_FILES["source.tar.gz"] and
            parent["change_patch_sha256"] == PARENT_FILES["change.patch"] and
            parent["clean_committed_checkout_at_freeze"] is True and
            parent["unchanged_6ad_implementation_except_declared_delta"] is True, "frozen parent source identity differs")
    archive_payloads(PARENT / "source.tar.gz", parent["source_sha256"])
    for filename, digest in parent["input_sha256"].items():
        add_input(inputs, filename, digest)
    disabled = read(PARENT / "disabled-control/comparison.json")
    require(disabled["completed"] is True and type(disabled["exit_code"]) is int and disabled["exit_code"] == 0 and
            disabled["compiler_commit"] == BASE and disabled["binary_sha256"] == PARENT_FILES["nextpnr-mistral"] and
            disabled["candidate_sha256"] == PARENT_FILES["disabled-control/candidate.json"] and
            disabled["original_module_dictionaries_identical"] is True and
            disabled["ordered_duplicate_pll_exports_preserved"] is True, "cached parent disabled control is incomplete")
    for filename, digest in disabled["input_sha256"].items():
        add_input(inputs, filename, digest)
    for filename, digest in disabled["output_sha256"].items():
        add_input(inputs, filename, digest)
    return parent, inputs


def host_validation(source_hashes):
    require(sha(HOST_VALIDATION) == HOST_VALIDATION_SHA and sha(PLAN) == PLAN_SHA, "root validation or predeclared plan changed")
    validation, plan = read(HOST_VALIDATION), read(PLAN)
    require(validation["delta_base_commit"] == BASE and validation["result_commit"] == RESULT and
            validation["source_sha256"] == source_hashes and validation["binary_sha256"] == EXPECTED_BINARY_SHA and
            validation["test_binary_sha256"] == EXPECTED_TEST_BINARY_SHA and
            validation["build_passed"] is True and validation["build_performed_before_commit_with_identical_committed_file_bytes"] is True and
            set(validation["build_targets"]) == {"nextpnr-mistral", "nextpnr-mistral-test"} and
            validation["backend_tests"] == validation["backend_passed"] == 35 and validation["backend_exit_code"] == 0 and
            validation["clean_committed_checkout"] is True and validation["cli_suite_executed_for_this_delta"] is False and
            validation["diff_check"] == "pass" and type(validation["independent_review"]) is str and validation["independent_review"] and
            validation["experiment_plan_sha256"] == PLAN_SHA and validation["default_recipe_selected"] is False and
            validation["hardware_tested"] is False and validation["new_timing_gain_proved"] is False,
            "root validation does not bind the committed source and current reviewed passing build/tests")
    require(plan["source_base_commit"] == BASE and plan["parent_listing_comparison_sha256"] == PARENT_LIST_SHA and
            plan["parent_source_identity_sha256"] == PARENT_FILES["source-identity.json"] and
            plan["default_minimum_branch_gain_ps"] == plan["retained_stage_minimum_branch_gain_ps"] == 250 and
            plan["new_stage_minimum_branch_gain_ps"] == 200 and plan["new_timing_gain_proved"] is False,
            "predeclared per-stage admission experiment changed")
    expected = {PLAN, *(HOST_VALIDATION.parent / name for name in
                ("build.log", "build-attempt-2.log", "build-attempt-3.log", "backend.log", "backend-final.log",
                 "low-gain-attempt-2.log", "low-gain-attempt-3.log"))}
    artifacts = {(ROOT / name).resolve(): digest for name, digest in validation["artifact_sha256"].items()}
    require(set(artifacts) == expected, "host validation artifact set differs")
    inputs = {}
    add_input(inputs, HOST_VALIDATION, HOST_VALIDATION_SHA)
    for path, digest in artifacts.items():
        add_input(inputs, path, digest)
    return validation, inputs


def authenticate_freeze():
    """Read-only sealed validation; does not read the changed producer binaries."""
    parent, parent_inputs = parent_source()
    source = read(HERE / "source-identity.json")
    require(source["base_commit"] == source["delta_base_commit"] == BASE and source["result_commit"] == RESULT and
            source["measured_base_commit"] == MEASURED and source["cumulative_base_commit"] == CUMULATIVE_BASE and
            re.fullmatch(r"[0-9a-f]{40}", source["source_tree_git_id"]) and
            source["binary_sha256"] == EXPECTED_BINARY_SHA and source["validated_test_binary_sha256"] == EXPECTED_TEST_BINARY_SHA and
            set(source["source_sha256"]) == CHANGED and source["changed_files"] == sorted(CHANGED) and
            source["clean_committed_checkout_at_freeze"] is True and source["unchanged_8e_implementation_except_declared_delta"] is True and
            source["parent_source_identity_sha256"] == PARENT_FILES["source-identity.json"] and
            source["cached_parent_listing_proof_sha256"] == PARENT_LIST_SHA and
            source["cached_parent_comparison_helpers_reexecuted"] is False,
            "source identity differs from the committed three-file margin experiment")
    require(sha(HERE / "nextpnr-mistral") == source["binary_sha256"] and
            sha(HERE / "source.tar.gz") == source["source_archive_sha256"] and
            sha(HERE / "change.patch") == source["change_patch_sha256"], "new frozen binary/archive/patch changed")
    archive_payloads(HERE / "source.tar.gz", source["source_sha256"])
    _, host_inputs = host_validation(source["source_sha256"])
    expected_inputs = {**parent_inputs, **host_inputs, str(Path(__file__).resolve()): sha(Path(__file__).resolve())}
    require(source["input_sha256"] == expected_inputs and source["host_validation_sha256"] == HOST_VALIDATION_SHA and
            source["preserved_parent_delta_sha256"] == {name: digest for name, digest in parent["source_sha256"].items() if name not in CHANGED},
            "new freeze omits or changes its parent/host/helper closure")
    for filename, digest in source["input_sha256"].items():
        require(sha(Path(filename)) == digest, "new freeze input changed: " + filename)
    return source


def freeze():
    parent, frozen_inputs = parent_source()
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json", "change.patch")),
            "new freeze artifacts already exist")
    base, result = git("rev-parse", BASE + "^{commit}").strip(), git("rev-parse", "HEAD^{commit}").strip()
    require(base == BASE and result == RESULT, "validated committed compiler result is missing")
    subprocess.run(["git", "merge-base", "--is-ancestor", base, result], cwd=SRC, check=True)
    require(not git("status", "--porcelain", "--untracked-files=all").strip(), "compiler checkout is not clean and committed")
    require(set(git("diff", "--name-only", "--no-renames", base, result, "--").splitlines()) == CHANGED,
            "committed delta is not exactly the three authorized files")
    require(set(git("diff", "--name-only", "--no-renames", MEASURED, CUMULATIVE_BASE, "--").splitlines()) == BASE_DOCS and
            set(git("diff", "--name-only", "--no-renames", CUMULATIVE_BASE, base, "--").splitlines()) == PARENT_CHANGED,
            "Git parent lineage differs from its frozen docs/six-file evidence")
    preserved = {}
    for name, digest in parent["source_sha256"].items():
        require(hashlib.sha256(git("show", f"{base}:{name}", text=False)).hexdigest() == digest,
                "Git parent source differs from its frozen archive: " + name)
        if name not in CHANGED:
            require(hashlib.sha256(git("show", f"{result}:{name}", text=False)).hexdigest() == digest,
                    "parent implementation changed outside the authorized delta: " + name)
            preserved[name] = digest
    payloads = {name: git("show", f"{result}:{name}", text=False) for name in sorted(CHANGED)}
    hashes = {name: hashlib.sha256(payload).hexdigest() for name, payload in payloads.items()}
    validation, host_inputs = host_validation(hashes)
    require(all((SRC / name).is_file() and not (SRC / name).is_symlink() and (SRC / name).read_bytes() == payload
                for name, payload in payloads.items()), "working source differs from committed HEAD")
    build_binary, test_binary = BUILD / "nextpnr-mistral", BUILD / "nextpnr-mistral-test"
    require(build_binary.is_file() and not build_binary.is_symlink() and test_binary.is_file() and not test_binary.is_symlink() and
            sha(build_binary) == EXPECTED_BINARY_SHA and sha(test_binary) == validation["test_binary_sha256"],
            "root-built binaries differ from the current passing validation")
    frozen_inputs.update(host_inputs)
    frozen_inputs[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
    shutil.copy2(build_binary, HERE / "nextpnr-mistral")
    require(sha(HERE / "nextpnr-mistral") == EXPECTED_BINARY_SHA == sha(build_binary), "producer changed while copying")
    timestamp = int(git("show", "-s", "--format=%ct", result).strip())
    with tarfile.open(HERE / "source.tar.gz", "w:gz") as archive:
        for name, payload in payloads.items():
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = len(payload), 0o644, timestamp
            archive.addfile(member, io.BytesIO(payload))
    with (HERE / "change.patch").open("xb") as output:
        output.write(git("diff", "--binary", "--no-ext-diff", "--no-textconv", base, result, "--", text=False))
    require(git("rev-parse", "HEAD^{commit}").strip() == result and
            not git("status", "--porcelain", "--untracked-files=all").strip(), "checkout changed while freezing")
    require(all(sha(Path(path)) == digest for path, digest in frozen_inputs.items()), "frozen inputs changed while freezing")
    record = {"base_commit": base, "delta_base_commit": base, "result_commit": result,
              "measured_base_commit": MEASURED, "cumulative_base_commit": CUMULATIVE_BASE,
              "source_tree_git_id": git("rev-parse", result + "^{tree}").strip(), "changed_files": sorted(CHANGED),
              "source_sha256": hashes, "binary_sha256": EXPECTED_BINARY_SHA,
              "source_archive_sha256": sha(HERE / "source.tar.gz"), "change_patch_sha256": sha(HERE / "change.patch"),
              "input_sha256": frozen_inputs, "host_validation_sha256": HOST_VALIDATION_SHA,
              "host_validation_path": str(HOST_VALIDATION), "validated_test_binary_sha256": EXPECTED_TEST_BINARY_SHA,
              "parent_source_identity_sha256": PARENT_FILES["source-identity.json"], "cached_parent_listing_proof_sha256": PARENT_LIST_SHA,
              "cached_parent_comparison_helpers_reexecuted": False, "preserved_parent_delta_sha256": preserved,
              "clean_committed_checkout_at_freeze": True, "unchanged_8e_implementation_except_declared_delta": True,
              "archive_scope": "Exact three changed files from committed HEAD; no entire-source-tree archive claim. Remaining bytes are bound by the 8e parent closure, base/result Git IDs and exact diff scope.",
              "producer_binary_path": str(build_binary), "branch": git("branch", "--show-current").strip(),
              "status": "committed generic per-stage placed-reduction minimum experiment; no qualification or timing/default/package/hardware acceptance"}
    with (HERE / "source-identity.json").open("x") as output:
        output.write(json.dumps(record, indent=2, sort_keys=True)+"\n")
    authenticate_freeze()
    print(json.dumps(record, indent=2), flush=True)


if __name__ == "__main__":
    freeze()
