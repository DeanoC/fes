"""Root-only timing diagnosis of a rejected route; no graph acceptance proof."""
import json
from pathlib import Path
import compare_applied as applied

HERE = Path(__file__).resolve().parent


def main():
    folder = HERE / "route-reduction0-ac0"
    inputs = [Path(__file__), HERE / "compare_applied.py", folder / "run.json",
              folder / "route.log", folder / "timing.json", folder / "routed.json",
              folder / "core.rbf", applied.seal.FULL / "timing.json",
              HERE / "route-reduction0-ac0-compare-attempt1.log",
              HERE / "route-buffer-diagnostic.json"]
    hashes = {str(path.relative_to(applied.ROOT)): applied.sha(path) for path in inputs}
    record = applied.read(folder / "run.json")
    report = applied.read(folder / "timing.json")
    log = (folder / "route.log").read_text()
    applied.require(record["completed"] is True and record["exit_code"] == 0 and
                    "Info: Program finished normally." in log and
                    "Running the GPU router" in log and (folder / "core.rbf").stat().st_size > 0,
                    "completed full GPU route/RBF missing")
    gates = applied.clock_gates(None, report, applied.read(applied.seal.FULL / "timing.json"), log, record)
    applied.require(gates["passes_practical_timing_gate"] is False,
                    "this diagnostic is reserved for the rejected timing trial")
    applied.require(all(applied.sha(applied.ROOT / name) == value for name, value in hashes.items()),
                    "diagnostic input changed")
    result = {"diagnostic_only": True, "graph_acceptance_proof_available": False,
              "full_comparator_attempt1_failed": True, "acceptance": "rejected",
              "completed": record["completed"], "exit_code": record["exit_code"],
              "elapsed_seconds": record["elapsed_seconds"], "fmax": report["fmax"],
              "clock_gates": gates, "input_sha256": hashes}
    output = HERE / "route-timing-diagnostic.json"
    with output.open("x") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"output_sha256": applied.sha(output), "clock_gates": gates}, indent=2))


if __name__ == "__main__":
    main()
