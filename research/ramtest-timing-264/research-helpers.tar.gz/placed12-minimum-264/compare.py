"""Root-operated partial graph proof for the fresh minimum200 placed12 listing.

Saved old proofs are authenticated by artifact hashes, never re-executed.
This first version accepts only list-reduction. It exposes fresh qualified
reduction ordinals; later AC/full support must independently prove the actual
selected rewrite before those phases can be accepted here.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re

import seal_profile as seal

HERE, ROOT = seal.HERE, seal.ROOT
require, sha, read = seal.require, seal.sha, seal.read
RESULT = "6552942de15ed48e1bb9fbc71e3c08f189486313"
BINARY_SHA = "45cf034723018ec67ad934bd24c07ce21a516f68a0284c934e1ffd3c6729170c"
MINIMUM_PS = 200


def relative(path):
    return str(Path(path).resolve().relative_to(ROOT))


def serial(value):
    return json.loads(json.dumps(value))


def top(g8, folder, filename):
    modules = g8.read_netlist(folder / filename)["modules"]
    require(set(modules) == {"top"}, "unexpected exported module set")
    return modules["top"]


def netlist(g8, module):
    return g8.Netlist(module["cells"], module["netnames"])


def restored_listing(g8, reference_top, current_top):
    """Compare same-phase named dictionaries, preserving paired PLL exports."""
    old, new = netlist(g8, reference_top), netlist(g8, current_top)
    require(set(old.cells) == set(new.cells) and not any(cell["type"] == "MISTRAL_BUF" for cell in new.cells.values()),
            "listing added/removed an owner or contains route-created BUF cells")
    for name in old.cells:
        require(g8.dictionary_cell(old, name) == g8.dictionary_cell(new, name),
                "listing did not restore an exact named original/retained cell: " + name)
        require(new.cells[name]["attributes"].get("NEXTPNR_BEL") and
                not new.cells[name]["attributes"].get("FES_PINMAP_V1"), "listing has an unplaced cell or partial routed pins")
    g8.compare_named_nets(reference_top, current_top, old, new)
    g8.ranking.top_ports(reference_top, current_top, old, new)
    require({key: value for key, value in reference_top.items() if key not in {"cells", "netnames", "ports"}} ==
            {key: value for key, value in current_top.items() if key not in {"cells", "netnames", "ports"}},
            "same-phase module metadata/settings changed")
    orders = {}
    for key in ("cells", "netnames"):
        before, after = list(reference_top[key]), list(current_top[key])
        require(before == after, "named owner export iteration order changed: " + key)
        orders[key] = {"count": len(before), "exact_name_order_identical": True,
                       "name_order_sha256": hashlib.sha256("\n".join(before).encode()).hexdigest()}
    return {"same_phase_reference": relative(seal.LIST / "placed.json"),
            "named_owner_keys_topology_parameters_attributes_bels_restored": True,
            "original_ff_connections_and_bels_in_export_preserved": True,
            "retained_clone_and_comb_named_dictionaries_identical": True,
            "same_phase_module_settings_attributes_and_public_ports_identical": True,
            "named_owner_export_order": orders, "lossless_pll_port_audit": g8.pll_port_audit(old, new),
            "in_memory_owner_pointer_and_bucket_identity_proved": False,
            "indexed_user_slot_ids_and_free_list_proved": False,
            "current_logical_pin_states_and_physical_mapping_proved": False,
            "final_route_buffer_population_preservation_proved": False}


def literal_cube(g8, measured_top, reference_top, current_top, root):
    """Prove the source using actual routed pins; list truth is conditional."""
    measured, reference, current = [netlist(g8, module) for module in (measured_top, reference_top, current_top)]
    cone, literals, nodes = g8.ranking.cube(measured, root)
    require(len(cone) == 3 and len(literals) == 12 and all(not value for value in literals.values()),
            "requested reduction is not an exact three-LUT/twelve-literal NOR")
    boundary = sorted(literals)
    snapshots = {}
    for name in cone:
        snapshots[name] = g8.ranking.pin_snapshot(measured, name)
        original = measured.cells[name]
        for candidate in (reference, current):
            cell = candidate.cells[name]
            require(original["type"] == cell["type"] and original["parameters"] == cell["parameters"] and
                    original["port_directions"] == cell["port_directions"] and
                    g8.previous.bel(original) == g8.previous.bel(cell) and
                    g8.connections(measured, name) == g8.connections(candidate, name),
                    "source cube topology/mask/BEL changed outside its listing rollback: " + name)
    private_consumers = {}
    boundaries = {reference.token(bit) for port in reference_top["ports"].values() for bit in port["bits"]}
    for name in cone - {root}:
        token = (name, "Q", 0)
        users = reference.direct_users.get(token, [])
        require(token not in boundaries and len(users) == 1 and users[0][0] in cone and
                users == current.direct_users.get(token, []), "source cube has an observable/shared private intermediate")
        private_consumers[name] = users
    for token in boundary:
        require(sum(user[0] in cone for user in reference.direct_users.get(token, [])) == 1 and
                reference.direct_users.get(token, []) == current.direct_users.get(token, []),
                "source cube literal is repeated or its shared users changed")
    visited = set()
    tree = measured.expression((root, "Q", 0), set(boundary), visited)
    require(visited == cone, "source cube expression contains undeclared nodes")

    def evaluate_current(token, values, active=frozenset()):
        if token in values:
            return values[token]
        require(token not in active and token[0] in cone and token[1:] == ("Q", 0), "invalid conditional listing cube edge")
        name = token[0]
        cell, pins = current.cells[name], snapshots[name]["pins"]
        width, address = int(cell["type"].removeprefix("MISTRAL_ALUT")), 0
        for index, pin in enumerate("ABCDEF"[:width]):
            state = pins[pin][0]
            require(state in (0, 3) and len(cell["connections"][pin]) == 1, "unsupported reference cube pin state")
            value = evaluate_current(current.token(cell["connections"][pin][0]), values, active | {token})
            address |= (value ^ (state == 3)) << index
        return (int(cell["parameters"]["LUT"], 2) >> address) & 1

    source_table, listing_table = [], []
    for row in range(4096):
        values = {token: (row >> bit) & 1 for bit, token in enumerate(boundary)}
        expected = int(row == 0)
        actual = g8.previous.evaluate(tree, values)
        conditional = evaluate_current((root, "Q", 0), values)
        require(actual == conditional == expected, "source or conditional listing NOR differs at row " + str(row))
        source_table.append(actual)
        listing_table.append(conditional)
    require(g8.essential(source_table, 12) == set(range(12)), "source NOR has an inessential literal")
    return {"root": root, "source_reference": relative(seal.FULL / "routed.json"),
            "source_reference_uses_actual_serialized_logical_pin_states": True,
            "source_cone": sorted(cone), "source_nodes": nodes, "external_boundary_order": boundary,
            "raw_required_values": [False] * 12, "essential_literals": 12, "assignments_checked": 4096,
            "formula": "NOT(x0 OR x1 OR ... OR x11)", "true_rows": 1, "true_row_indices": [0],
            "source_truth_sha256": hashlib.sha256(bytes(source_table)).hexdigest(),
            "conditional_listing_truth_sha256": hashlib.sha256(bytes(listing_table)).hexdigest(),
            "private_intermediate_consumers_preserved": private_consumers,
            "root_consumers_preserved": current.direct_users.get((root, "Q", 0), []),
            "listing_masks_topology_bels_match_actual_routed_source": True,
            "listing_4096_rows_assume_reference_logical_pin_states": True,
            "independent_current_listing_pin_polarity_truth_proved": False}


def downstream_closure(g8, reference_top, current_top, root):
    """Recover the actual bounded endpoint tree, independently of trial counts."""
    def collect(module):
        graph = netlist(g8, module)
        active, completed, endpoints = set(), set(), set()
        def descend(token):
            require(token not in active, "downstream reduction closure contains a cycle")
            require(token not in completed, "three-cell reduction closure contains reconvergence")
            require(len(completed) + len(active) < 64, "downstream reduction closure exceeds the distinct-net bound")
            active.add(token)
            for name, pin, index in graph.direct_users.get(token, []):
                cell = graph.cells[name]
                require(index == 0, "downstream reduction edge is not scalar")
                if g8.ready.is_lut(cell):
                    require(cell["port_directions"].get(pin) == "input", "invalid downstream LUT input")
                    descend((name, "Q", 0))
                else:
                    require(cell["type"] == "MISTRAL_FF" and pin == "ENA", "observed reduction endpoint is not an ordinary FF ENA")
                    endpoints.add((name, pin, index))
            active.remove(token)
            completed.add(token)
        descend((root, "Q", 0))
        return completed, endpoints
    original, old_endpoints = collect(reference_top)
    current, endpoints = collect(current_top)
    require(original == current and old_endpoints == endpoints and len(current) == 5 and len(endpoints) == 227,
            "the observed five-net/227-ENA reduction closure changed")
    return {"distinct_net_count": len(current), "endpoint_count": len(endpoints), "net_driver_tokens": sorted(current),
            "endpoints": sorted(endpoints), "cycle_and_reconvergence_absent": True,
            "actual_named_closure_identical_to_same_phase_reference": True,
            "endpoint_clock_constraints_and_timing_are_not_independently_proved_from_listing": True}


def qualified_reduction(block, spec, endpoint_count):
    """Bind every emitted candidate to its immediately preceding guarded trial."""
    require(spec["minimum_branch_gain_ps"] == MINIMUM_PS and
            [line for line in block.splitlines() if "Placed reduction minimum branch gain:" in line] ==
            [seal.MINIMUM_LOG], "actual new-stage minimum log differs from sealed200")
    trial_pattern = re.compile(r"^Info: Placed reduction trial root=(\S+) leaves=(\S+) branch_gain=([\d.-]+)ps "
        r"endpoint_gain=([\d.-]+)ps improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])\.$")
    candidate_pattern = re.compile(r"^Info: Placed reduction candidate (\d+), (\d+) endpoints, branch gain ([\d.-]+)ps\.$")
    trials, candidates, previous_trial = [], [], None
    for line in block.splitlines():
        if line.startswith("Info: Placed reduction trial "):
            match = trial_pattern.fullmatch(line)
            require(match and match[1] == spec["root"], "malformed/misattributed two-leaf trial")
            leaves = match[2].split(",")
            require(len(leaves) == 2 and len(set(leaves)) == 2 and all(
                re.fullmatch(r"MISTRAL_(?:M)?COMB\.\d+\.\d+\.\d+", bel) for bel in leaves), "invalid trial leaf sites")
            gain, endpoint = float(match[3]), float(match[4])
            require(math.isfinite(gain) and math.isfinite(endpoint), "nonfinite trial gains")
            previous_trial = {"root": match[1], "leaf_bels": leaves, "branch_gain_ps": gain,
                              "endpoint_gain_ps": endpoint, "guards": [int(value) for value in match.groups()[4:]],
                              "trial_log": line}
            require(previous_trial["guards"][0] == int(gain > 0 and gain >= MINIMUM_PS),
                    "trial improvement guard does not match its actual positive200ps margin")
            trials.append(previous_trial)
        elif line.startswith("Info: Placed reduction candidate "):
            match = candidate_pattern.fullmatch(line)
            require(match and previous_trial and int(match[1]) == len(candidates) and int(match[2]) == endpoint_count and
                    previous_trial["guards"] == [1, 1, 1, 1] and previous_trial["branch_gain_ps"] >= MINIMUM_PS and
                    float(match[3]) == previous_trial["branch_gain_ps"], "candidate lacks its guarded >=200ps trial")
            candidates.append({**previous_trial, "candidate": int(match[1]), "endpoints": int(match[2]), "candidate_log": line})
            previous_trial = None
    summary = re.findall(r"^Info: Placed reduction: (\d+) qualified candidates; none applied\.$", block, re.M)
    require(spec["candidate"] == -1 and summary == [str(len(candidates))] and len(trials) <= 16 and
            block.count(f"Info: Balanced three-LUT reduction at '{spec['root']}' into 6+6 inputs.") == 1,
            "new twelve-literal listing did not complete the bounded probe and rollback")
    require(sum(trial["guards"] == [1, 1, 1, 1] for trial in trials) == len(candidates),
            "an all-guards-passing trial lacks its fresh qualification ordinal")
    return {"minimum_branch_gain_ps": MINIMUM_PS,
            "qualified_candidates": len(candidates), "qualified_ordinals": list(range(len(candidates))),
            "timed_trial_count": len(trials), "trials": trials, "candidates": candidates,
            "modeled_only_no_final_route_signoff": True, "final_listing_applied_no_reduction": True}


def retained_stack(g8, log, specs, base_proof, reference_top, current_top):
    headers = list(re.finditer(r"^Info: Placed reduction stage \d+:.*$", log, re.M))
    require(len(headers) == 2, "expected two explicit placed-stage attribution headers")
    blocks = g8.ranking.placed_log_blocks(log, specs)
    prefix = "\n".join(line for line in log[:headers[1].start()].splitlines()
                       if not line.startswith("Info: Placed reduction stage "))
    old_log = (seal.LIST / "route.log").read_text()
    old_prefix = g8.retained_placed_prefix(old_log, specs[0], True)
    transforms = g8.ready.transform_stack(prefix, old_prefix)
    steps = [{**step, "index": index} for index, step in enumerate(read(seal.LOCAL_PLAN)["steps"])]
    models = [g8.staged.selected_local(block, step) for block, step in zip(g8.staged.plan_blocks(log, steps), steps)]
    require(serial(models) == [proof["selected_stage_log"] for proof in base_proof["retained_local_clone_equivalences"]],
            "preceding local selections differ from the cached g8 proof")
    comb = g8.comb.selected_candidate(prefix, 0)
    require(serial(comb) == serial(g8.comb.selected_candidate(old_prefix, 0)), "retained internal comb selection changed")
    placed11 = g8.ranking.verify_selection(blocks[0], specs[0])
    require(serial(placed11) == base_proof["retained11_selection"], "retained placed11 qualification changed")
    new = netlist(g8, current_top)
    local_bindings = []
    for proof in base_proof["retained_local_clone_equivalences"]:
        name = proof["clone"]["cell"]
        require(name in new.cells and g8.previous.bel(new.cells[name]) == proof["clone"]["bel"] and
                int(new.cells[name]["parameters"]["LUT"], 2) == int(proof["clone_mask_hex"], 16), "cached local clone changed")
        selected = sorted(row["ff"] for row in proof["selected_ff_ena_users"])
        require(new.direct_users.get((name, "Q", 0), []) == [(ff, "ENA", 0) for ff in selected], "local clone consumers changed")
        local_bindings.append({"clone": name, "cached_truth_assignments": proof["assignments_checked"],
                               "selected_ffs": selected, "selected_groups": proof["selected_lab_groups"],
                               "actual_named_cell_and_consumer_signature_matches_cached_proof": True,
                               "current_unserialized_pins_not_independently_proved": True})
    return {"retained_transform_messages_identical": transforms, "retained_local_selections": models,
            "retained_local_cached_closures": local_bindings, "retained_comb_selection": comb,
            "retained_placed11_selection": placed11, "retained_capture_moves": 60,
            "old_comparison_helpers_reexecuted": False}, blocks[1]


def comparison(folder):
    record = read(folder / "run.json")
    digests = {Path(path): digest for path, digest in record["input_sha256"].items()}
    digests.update({folder / name: sha(folder / name) for name in ("run.json", "route.log", "placed.json")})
    digests[Path(__file__).resolve()] = sha(Path(__file__).resolve())
    _, g8, base, base_proof, _, source, disabled = seal.load_profile()
    phase = seal.authenticate_phase(record)
    require(phase["phase"] == "list-reduction" and folder.resolve() == phase["folder"].resolve(),
            "this comparator version accepts only the initial reduction listing")
    require(source["result_commit"] == RESULT and source["binary_sha256"] == BINARY_SHA and
            record["new_stage_minimum_branch_gain_ps"] == MINIMUM_PS and
            record["retained_stage_minimum_branch_gain_ps"] == 250 and
            record["minimum_log_verified"] is True and record["parent_qualification_inherited"] is False and
            record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0, "new source/listing is not finalized")
    mutable = {"command", "remap_plan_sha256", "decomposition_selection", "decomposition_report_sha256",
               "experimental_placed_reduction", "list_only", "fresh_listing", "execution", "input_sha256", "completed",
               "elapsed_seconds", "exit_code", "fmax", "final_reported_hold_violations", "kind", "runner_sha256",
               "base_compiler_commit", "compiler_commit", "compiler_bytes_unchanged", "source_archive_sha256",
               "tool_identity", "disabled_control_sha256"}
    require(all(record.get(key) == value for key, value in base.items() if key not in mutable), "undeclared inherited profile metadata change")
    require(not any(key in record for key in ("fmax", "final_reported_hold_violations")), "listing claims final clock/hold measurements")
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            not any(marker in log for marker in ("Info: Decomposition", "Running the GPU router", "Running signoff timing analysis")) and
            not any((folder / name).exists() for name in ("core.rbf", "routed.json", "timing.json")), "listing executed AC/route or failed")
    metrics = g8.previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and metrics == g8.previous.PLACEMENT_METRICS.findall((seal.LIST / "route.log").read_text()),
            "ordinary placement metrics changed")
    reference_top, current_top = top(g8, seal.LIST, "placed.json"), top(g8, folder, "placed.json")
    restored = restored_listing(g8, reference_top, current_top)
    stack, last_block = retained_stack(g8, log, phase["reduction_steps"], base_proof, reference_top, current_top)
    closure = downstream_closure(g8, reference_top, current_top, seal.REDUCTION_ROOT)
    qualification = qualified_reduction(last_block, phase["reduction_steps"][1], closure["endpoint_count"])
    cube = literal_cube(g8, top(g8, seal.FULL, "routed.json"), reference_top, current_top, seal.REDUCTION_ROOT)
    strict = {key: value for key, value in base_proof.items() if key.startswith("passes_strict_diagnostic") or
              key in {"all_clock_nonregression", "passes_all_clock_constraints", "passes_raw_timing_gates_without_isolation_acceptance"}}
    require(all(sha(path) == digest for path, digest in digests.items()), "artifacts changed during comparison")
    return {"status": "host-only placed12 minimum200 initial listing; partial evidence and fresh reduction ordinals",
            "phase": "list-reduction", "compiler_commit": RESULT, "base_compiler_commit": source["base_commit"],
            "measured_compiler_commit": base["compiler_commit"], "new_binary_sha256": BINARY_SHA,
            "minimum_branch_gain_ps": MINIMUM_PS, "retained_stage_minimum_branch_gain_ps": 250,
            "parent_listing_proof_sha256": seal.PARENT_PROOF_SHA, "parent_qualification_inherited": False,
            "actual_nondefault_minimum_log": seal.MINIMUM_LOG,
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"], "list_only": True,
            "route_started": False, "graph_proof_available": False, "partial_graph_evidence_available": True,
            "final_metadata_stable_during_comparison": True, "qualified_reduction_ordinals": qualification["qualified_ordinals"],
            "qualified_ac_ordinals": [], "matched_placement_metrics": 71, "placement_metrics_identical": True,
            "placement_metrics_sha256": hashlib.sha256("\n".join(metrics).encode()).hexdigest(),
            "cached_g8_full_and_list_proofs_artifact_bound": True, "cached_old_comparisons_reexecuted": False,
            "cached_measured_strict_flags_unchanged_no_timing_inheritance": strict,
            "new_disabled_loader_control": {"comparison_sha256": sha(HERE / "disabled-control/comparison.json"),
                                            "modules_sha256": disabled["modules_sha256"], "lossless_pll_port_audit": disabled["lossless_pll_port_audit"]},
            "restored_listing": restored, "retained_stack": stack, "source_twelve_literal_cube": cube,
            "new12_downstream_closure": closure, "new12_qualification": qualification,
            "current_applied_twelve_rewrite_proved": False,
            "timing_acceptance_available": False, "default_recipe_selected": False, "hardware_tested": False,
            "listing_limitations": ["The 4096-row source proof uses authenticated routed g8 logical pin snapshots; current listing rows assume those states.",
                                    "Current exported named dictionaries, masks, BELs and order match the same-phase g8 listing; in-memory owner pointers/indexed users/free lists are not serialized.",
                                    "No final physical pin/BUF/clock/hold/RBF proof or routed acceptance is claimed.",
                                    "Later selected-reduction/AC/full phases require further independent comparator support."],
            "artifact_sha256": {relative(path): digest for path, digest in sorted(digests.items())}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    require(not (args.folder / "comparison.json").exists(), "comparison output already exists")
    result = serial(comparison(args.folder))
    with (args.folder / "comparison.json").open("x") as output:
        output.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: result[key] for key in ("phase", "graph_proof_available", "candidate_completed",
                                                "qualified_reduction_ordinals")}, indent=2))


if __name__ == "__main__":
    main()
