"""Root-only lossless named delta diagnostic; this is not an acceptance proof."""
import json
from pathlib import Path
import compare_applied as applied

HERE = Path(__file__).resolve().parent
seal = applied.seal


def main():
    _, g8, _, parent_proof, _, _, _ = seal.load_profile()
    api = applied.initial()
    before_top = api.top(g8, seal.FULL, "routed.json")
    after_top = api.top(g8, HERE / "route-reduction0-ac0", "routed.json")
    before_top, unwind = applied.unwind_parent_ac(g8, before_top, parent_proof)
    before, after = api.netlist(g8, before_top), api.netlist(g8, after_top)
    removed = sorted(set(before.cells) - set(after.cells))
    added = sorted(set(after.cells) - set(before.cells))
    changed = {}
    for name in sorted(set(before.cells) & set(after.cells)):
        a, b = g8.dictionary_cell(before, name), g8.dictionary_cell(after, name)
        direct_a = g8.direct_connections(before, name)
        direct_b = g8.direct_connections(after, name)
        if a == b and direct_a == direct_b:
            continue
        changed[name] = {
            "type": before.cells[name]["type"],
            "changed_metadata": {key: {"before": a.get(key), "after": b.get(key)}
                                 for key in set(a) | set(b) if a.get(key) != b.get(key)},
            "direct_connections_before": direct_a,
            "direct_connections_after": direct_b,
        }
    def detail(graph, name):
        return {"cell": g8.dictionary_cell(graph, name),
                "direct_connections": g8.direct_connections(graph, name),
                "q_users": graph.direct_users.get((name, "Q", 0), [])}
    result = {
        "diagnostic_only": True, "acceptance_proof_available": False,
        "lossless_pll_audit": g8.pll_port_audit(before, after),
        "algebraic_cached_ac_unwind": unwind,
        "removed_cells": {name: detail(before, name) for name in removed},
        "added_cells": {name: detail(after, name) for name in added},
        "changed_original_cells": changed,
        "inputs_sha256": {str(path.relative_to(seal.ROOT)): seal.sha(path) for path in
                          [Path(__file__), HERE / "compare_applied.py", seal.FULL / "routed.json",
                           seal.FULL / "comparison.json", HERE / "route-reduction0-ac0/routed.json"]},
    }
    output = HERE / "route-buffer-diagnostic.json"
    with output.open("x") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"removed": removed, "added": added,
                      "changed_original_names": sorted(changed),
                      "output_sha256": seal.sha(output), "diagnostic_only": True}, indent=2))


if __name__ == "__main__":
    main()
