"""Root-only profile for a fresh placed12 trial with an explicit 200 ps minimum."""
import json
from pathlib import Path
import hashlib
import importlib.util

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PARENT = RAW / "placed12-reduction-264"
G8 = RAW / "ready-g8-decomposition-264"
FULL, LIST = G8 / "route-c0", G8 / "list"
PROFILE, LOCAL_PLAN = HERE / "profile.json", HERE / "local-plan.json"
PHASES = ("list-reduction", "list-ac", "route")
BASE = "8e305cb994d797a79a93a0cf2f30aaf9980d8642"
RESULT = "6552942de15ed48e1bb9fbc71e3c08f189486313"
BINARY_SHA = "45cf034723018ec67ad934bd24c07ce21a516f68a0284c934e1ffd3c6729170c"
PARENT_SEAL_SHA = "1b38401a02341656d8e32e8d71f526bf7beccfba0fba463cb49ef875d73dd7ee"
PARENT_PROFILE_SHA = "96c45636536d315ab24d134cd37d09499fd9ef6cf1464aaceffa75d249dfcdec"
PARENT_SOURCE_SHA = "fd1afaff4d70ba48aa98420ddc6ffd92bd638e2099ee0a8df0e83faaf2558034"
PARENT_PROOF_SHA = "b7c9b20a715ce9db056d07a3776e218c6bd18e2bb42c9fef5d360fcfb30e7ed5"
PARENT_COMPARATOR_SHA = "1823103ae0b5838b7559874f69b52b280d4efc484d40debb6345dc6fd80e3d92"
MINIMUM_PS = 200
DEFAULT_MINIMUM_PS = 250
REDUCTION_ROOT = "ddr0_test.group_valid_MISTRAL_ALUT6_E_F_MISTRAL_ALUT5_Q"
MINIMUM_LOG = "Info: Placed reduction minimum branch gain: 200ps."
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def previous():
    require(sha(PARENT / "seal_profile.py") == PARENT_SEAL_SHA, "frozen parent sealing helper changed")
    return module_at(PARENT / "seal_profile.py", "placed12_minimum_frozen_parent")


def read(path):
    return previous().read(path)


def authenticate_cached(folder, required=()):
    return previous().authenticate_cached(folder, required)


def authenticate_parent():
    """Use only immutable individual authenticators; do not rerun old comparisons."""
    old = previous()
    require(sha(PARENT / "profile.json") == PARENT_PROFILE_SHA and
            sha(PARENT / "source-identity.json") == PARENT_SOURCE_SHA and
            sha(PARENT / "list-reduction/comparison.json") == PARENT_PROOF_SHA and
            sha(PARENT / "compare.py") == PARENT_COMPARATOR_SHA, "parent listing lineage changed")
    profile, g8, base, full, listing, source, disabled = old.load_profile()
    record, proof = old.authenticate_cached(PARENT / "list-reduction", [PARENT / "list-reduction/placed.json"])
    require(source["result_commit"] == BASE and record["compiler_commit"] == BASE and
            record["profile_sha256"] == PARENT_PROFILE_SHA and record["phase"] == "list-reduction" and
            record["reduction_selection"] == -1 and record["decomposition_selection"] is None and
            proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False and
            proof["route_started"] is False and proof["qualified_reduction_ordinals"] == [] and
            proof["new12_qualification"]["timed_trial_count"] == 16 and
            proof["new12_qualification"]["qualified_candidates"] == 0 and
            proof["new12_qualification"]["final_listing_applied_no_reduction"] is True and
            proof["cached_old_comparisons_reexecuted"] is False, "parent is not the proved unselected listing")
    require(proof["artifact_sha256"].get(str((PARENT / "compare.py").relative_to(ROOT))) == PARENT_COMPARATOR_SHA,
            "parent proof omits its frozen comparator")
    return old, profile, g8, base, full, listing, source, disabled, record, proof


def authenticate_new_source(g8, base):
    # The current freeze/control helper owns source and lossless loader proof.
    checker = module_at(HERE / "check_disabled_control.py", "placed12_minimum_disabled_auth")
    source, control = checker.authenticate_control(g8)
    require(source["base_commit"] == BASE and source["result_commit"] == RESULT and
            source["measured_base_commit"] == base["compiler_commit"] and
            source["binary_sha256"] == BINARY_SHA and sha(HERE / "nextpnr-mistral") == BINARY_SHA,
            "new compiler is not the declared validated minimum-only delta")
    return source, control


def phase_folder(phase, reductionordinal, acordinal):
    return HERE / previous().phase_folder(phase, reductionordinal, acordinal).name


def reduction_steps(base, phase, reductionordinal):
    steps = previous().reduction_steps(base, phase, reductionordinal)
    require(steps[1]["root"] == REDUCTION_ROOT, "parent reduction root changed")
    return [{**steps[0], "minimum_branch_gain_ps": DEFAULT_MINIMUM_PS},
            {**steps[1], "minimum_branch_gain_ps": MINIMUM_PS}]


def expected_diagnostic_environment(base, phase, reductionordinal):
    first, second = reduction_steps(base, phase, reductionordinal)
    # Retained placed11 keeps its original three tokens; only new12 emits a
    # fourth token. Both semantic minima are explicit in profile/run records.
    spec = f"{first['root']} {first['radius']} {first['candidate']}\n" + \
           f"{second['root']} {second['radius']} {second['candidate']} {second['minimum_branch_gain_ps']}"
    return {"NEXTPNR_MISTRAL_CAPTURE_LOCALITY": base["experimental_capture_locality"],
            "NEXTPNR_MISTRAL_PLACED_REDUCTION": spec}


def expected_command(base, phase, reductionordinal, acordinal):
    old = previous()
    old_folder = old.phase_folder(phase, reductionordinal, acordinal)
    folder = phase_folder(phase, reductionordinal, acordinal)
    changes = {str(old.HERE / "nextpnr-mistral"): str(HERE / "nextpnr-mistral"),
               str(old.LOCAL_PLAN): str(LOCAL_PLAN)}
    changes.update({str(old_folder / name): str(folder / name)
                    for name in ("placed.json", "routed.json", "timing.json", "core.rbf")})
    command = [changes.get(token, token) for token in old.expected_command(base, phase, reductionordinal, acordinal)]
    require(not any(token.startswith(str(PARENT) + "/") for token in command), "command retained a parent output path")
    return command


def profile_aliases(base):
    return {"schema": 2, "reference_full": str(FULL), "reference_listing": str(LIST),
            "parent_profile_sha256": PARENT_PROFILE_SHA, "parent_source_identity_sha256": PARENT_SOURCE_SHA,
            "parent_listing_proof_sha256": PARENT_PROOF_SHA, "parent_qualification_inherited": False,
            "base_plan": base["remap_plan"],
            "new_reduction": {"root": REDUCTION_ROOT, "radius": 6, "minimum_branch_gain_ps": MINIMUM_PS},
            "retained_stage_minimum_branch_gain_ps": DEFAULT_MINIMUM_PS,
            "diagnostic_token_counts": [3, 4], "expected_nondefault_minimum_log": MINIMUM_LOG}


def load_profile():
    profile = read(PROFILE)
    require(set(profile) == set(profile_aliases({"remap_plan": {}})) |
            {"source_identity_sha256", "disabled_control_sha256", "input_sha256"}, "sealed profile key set changed")
    for filename, digest in profile["input_sha256"].items():
        require(sha(Path(filename)) == digest, "sealed input changed: " + filename)
    _, _, g8, base, full, listing, _, _, _, _ = authenticate_parent()
    source, disabled = authenticate_new_source(g8, base)
    require(all(profile[key] == value for key, value in profile_aliases(base).items()) and
            profile["base_plan"] == read(LOCAL_PLAN) and
            profile["source_identity_sha256"] == sha(HERE / "source-identity.json") and
            profile["disabled_control_sha256"] == sha(HERE / "disabled-control/comparison.json"), "profile aliases changed")
    return profile, g8, base, full, listing, source, disabled


def sealed_input_map(profile, phase, reductionordinal, acordinal):
    inputs = {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}
    dependencies = [] if phase == "list-reduction" else [HERE / "list-reduction"]
    if phase == "route":
        dependencies.append(HERE / f"list-ac-r{reductionordinal}")
    for folder in dependencies:
        record, proof = authenticate_cached(folder, [folder / "placed.json"])
        require(record["profile_sha256"] == sha(PROFILE) and record["compiler_commit"] == RESULT and
                record["new_stage_minimum_branch_gain_ps"] == MINIMUM_PS and record["list_only"] is True and
                record["source_identity_sha256"] == profile["source_identity_sha256"] and
                record["minimum_log_verified"] is True and
                proof["minimum_branch_gain_ps"] == MINIMUM_PS and
                proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False,
                "fresh minimum200 qualification prerequisite is not sealed")
        comparator = HERE / "compare.py"
        require(proof["artifact_sha256"].get(str(comparator.relative_to(ROOT))) == sha(comparator),
                "fresh proof does not bind its final comparator")
        if folder.name == "list-reduction":
            ordinals, selected = proof["qualified_reduction_ordinals"], reductionordinal
            require(record["phase"] == "list-reduction" and record["reduction_selection"] == -1 and
                    record["decomposition_selection"] is None, "wrong reduction listing prerequisite")
        else:
            ordinals, selected = proof["qualified_ac_ordinals"], acordinal
            require(record["phase"] == "list-ac" and record["reduction_selection"] == reductionordinal and
                    record["decomposition_selection"] == -1, "wrong fresh AC listing prerequisite")
        require(type(ordinals) is list and all(type(value) is int and 0 <= value <= 2147483647 for value in ordinals) and
                ordinals == sorted(set(ordinals)) and selected in ordinals, "selected ordinal is not freshly qualified")
        extra = {str(ROOT / path): digest for path, digest in proof["artifact_sha256"].items()}
        extra[str(folder / "comparison.json")] = sha(folder / "comparison.json")
        require(all(path not in inputs or inputs[path] == digest for path, digest in extra.items()), "input digest collision")
        inputs.update(extra)
    return inputs


def authenticate_phase(record):
    profile, g8, base, _, _, source, disabled = load_profile()
    phase, reduction, ac = record["phase"], record["reduction_selection"], record["decomposition_selection"]
    folder = phase_folder(phase, reduction, ac)
    diagnostics = expected_diagnostic_environment(base, phase, reduction)
    require(record["command"] == expected_command(base, phase, reduction, ac) and
            record["remap_plan"] == profile["base_plan"] and record["remap_plan_sha256"] == sha(LOCAL_PLAN) and
            record["placed_reduction_plan"] == reduction_steps(base, phase, reduction) and
            record["input_sha256"] == sealed_input_map(profile, phase, reduction, ac), "phase command/plan/input closure changed")
    require(record["new_stage_minimum_branch_gain_ps"] == MINIMUM_PS and
            record["retained_stage_minimum_branch_gain_ps"] == DEFAULT_MINIMUM_PS and
            record["diagnostic_token_counts"] == [3, 4] and record["expected_nondefault_minimum_log"] == MINIMUM_LOG and
            record["parent_listing_proof_sha256"] == PARENT_PROOF_SHA and record["parent_qualification_inherited"] is False,
            "per-stage minimum or parent-lineage provenance changed")
    require(record["diagnostic_environment"] == diagnostics and
            record["experimental_placed_reduction"] == diagnostics["NEXTPNR_MISTRAL_PLACED_REDUCTION"] and
            record["experimental_capture_locality"] == base["experimental_capture_locality"] and
            record["retained_comb_report_sha256"] == base["retained_comb_report_sha256"] and
            record["decomposition_report_sha256"] == (None if phase == "list-reduction" else base["decomposition_report_sha256"]),
            "retained transforms or diagnostic environment changed")
    identity = f"base_commit={BASE}; experimental_source_sha256={sha(HERE / 'source.tar.gz')}; sha256={BINARY_SHA}"
    require(record["compiler_commit"] == RESULT and record["base_compiler_commit"] == BASE and
            record["measured_compiler_commit"] == base["compiler_commit"] and record["compiler_bytes_unchanged"] is False and
            record["tool_identity"] == identity and record["source_archive_sha256"] == sha(HERE / "source.tar.gz") and
            record["source_identity_sha256"] == sha(HERE / "source-identity.json") and
            record["disabled_control_sha256"] == sha(HERE / "disabled-control/comparison.json"), "new compiler aliases changed")
    require(record["list_only"] is (phase != "route") and record["fresh_listing"] is (phase != "route") and
            record["profile_sha256"] == sha(PROFILE) and record["reference_run_sha256"] == sha(FULL / "run.json") and
            record["runner_sha256"] == sha(HERE / "route.py") and record["cwd"] == base["cwd"], "phase metadata changed")
    lineage = {} if phase == "list-reduction" else {"reduction_listing": str(HERE / "list-reduction")}
    if phase == "route":
        lineage["ac_listing"] = str(HERE / f"list-ac-r{reduction}")
    require(record["listing_lineage"] == lineage, "fresh listing lineage changed")
    require(type(record["minimum_log_verified"]) is bool, "minimum log verification alias is not boolean")
    if record["completed"] is True:
        minimum_lines = [line for line in (folder / "route.log").read_text().splitlines()
                         if "Placed reduction minimum branch gain:" in line]
        require(record["minimum_log_verified"] is True and minimum_lines == [MINIMUM_LOG],
                "completed phase does not contain exactly the sealed200 minimum log")
    g8.ready.authenticate_execution(record, base)
    steps = [{**step, "index": index, "report_path": Path(step["report"]), "report_json": g8.read(Path(step["report"])),
              "report_sha256": sha(Path(step["report"]))} for index, step in enumerate(record["remap_plan"]["steps"])]
    return {"phase": phase, "folder": folder, "local_plan_path": LOCAL_PLAN, "local_steps": steps,
            "reduction_steps": record["placed_reduction_plan"], "reduction_selection": reduction,
            "ac_selection": ac, "source": source, "disabled_control": disabled, "minimum_branch_gain_ps": MINIMUM_PS}


def seal():
    require(not PROFILE.exists() and not LOCAL_PLAN.exists(), "profile/plan already sealed")
    old, parent_profile, g8, base, _, _, _, _, _, proof = authenticate_parent()
    source, disabled = authenticate_new_source(g8, base)
    paths = {Path(path) for path in parent_profile["input_sha256"]}
    paths |= {ROOT / path for path in proof["artifact_sha256"]}
    paths |= {PARENT / "profile.json", PARENT / "list-reduction/comparison.json", PARENT / "seal_profile.py"}
    paths |= {Path(path) for record in (source, disabled) for path in record["input_sha256"]}
    paths |= {HERE / name for name in ("seal_profile.py", "route.py", "freeze.py", "check_disabled_control.py",
                                     "nextpnr-mistral", "source.tar.gz", "source-identity.json", "change.patch", "experiment-plan.json",
                                     "disabled-control/comparison.json", "disabled-control/candidate.json", "disabled-control/loader.log")}
    paths |= {path for path in (HERE / "validation").rglob("*") if path.is_file()}
    with LOCAL_PLAN.open("x") as output:
        output.write(json.dumps(base["remap_plan"], indent=2, sort_keys=True) + "\n")
    paths.add(LOCAL_PLAN)
    digests = {str(path): sha(path) for path in sorted(paths)}
    profile = {**profile_aliases(base), "source_identity_sha256": sha(HERE / "source-identity.json"),
               "disabled_control_sha256": sha(HERE / "disabled-control/comparison.json"), "input_sha256": digests}
    require(all(sha(Path(path)) == digest for path, digest in digests.items()), "inputs changed during sealing")
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"profile": str(PROFILE), "sha256": sha(PROFILE), "inputs": len(digests)}, indent=2))


if __name__ == "__main__":
    seal()
