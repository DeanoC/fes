# Port0 ready-output guide for a future distinct local stage

Root alone runs this derivation. It rehashes the accepted a4a full proof and
the completed 84af g1 prefix proof through their flat original artifact and
runtime maps. Only the pinned 026317 module's pure native parser, metadata,
JSON and audit utilities are reused; no prior generator or authenticator
entrypoint, compiler, STA or benchmark executes.

The guide contains exactly the accepted report's 180 original path objects
in their original order for port0.slot_free ALUT2_Q → ALUT4_C → original
FF.ENA. All skew, clock-to-Q, logic, routing, setup, location, net, source
and window fields remain untouched. The accepted signed sums show 71 window
misses across 29 LABs, with worst sum8.373999953269958ns. These are historical
reported values, not current g1 STA, prospective gain or a qualification.
The target ALUT4_C has no existing local clone in either actual image.

Every selected scalar, BEL/XY, direction, alias, native driver/user edge,
registered clock and endpoint metadata is checked in both the accepted
routed image and actual g1 pre-route prefix. Complete original Q coverage
is exactly180 FF.ENA users. Canonical inner0xb/outer0xf0e0 tables and their
exact five external signal inputs are composed over32 rows to establish
bounded logical eligibility. Actual accepted full SIG pin states are
checked separately. The g1 image lacks full pin serialization: its unseen
pin state, ALM masks, controls, physical Boolean behavior, route delays and
new timing are not inferred from the accepted image or the logical table.

Clock3549 is explicitly driven by CLKBUF.Q, whose A112726 comes from the
second serialized paired PLL outclk occurrence; the two outputs remain
112724/112726. Buffer metadata, accepted full A/Q SIG pins, native chain,
original aliases and clock consumers are checked without buffer collapse.
Raw occurrence1 is not asserted to be any logical parameter channel or
frequency/phase; the actual unchanged report window remains authoritative.

The new guide and derivation manifest are exclusive immutable outputs.
All bound original paths are rehashed before and after publication. This
provides a hypothesis for an additional distinct port0 output-copy stage,
not a selected ordinal/site, legality result, independent physical or STA
proof, routed gain, acceptance of the current g1 route, or hardware result.
