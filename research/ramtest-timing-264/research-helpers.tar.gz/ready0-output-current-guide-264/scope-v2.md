# Port0 ready guide v2: explicit direct-versus-buffered input load

Root alone executes this separately versioned derivation. The frozen v1
543b5ece source and58c3c40c scope remain bound and unchanged; its actual failed
attempt86500 is retained by root. It failed before publishing either output
because exact external-input user equality does not hold between pre-route
and routed images. This v2 writes only ready-guide-v2.json and
derivation-v2.json. It neither repairs nor invents a v1 result.

Every v1 native/path/clock/composition check remains except the single named
input-load difference on bit103525. All five input driver and alias identities
remain exact, and all users of the other four inputs remain exact. Both images
have14 users on103525: g1 has the direct skid_write FF.DATAIN slot; accepted
full has that FF's named ROUTETHRU.A slot. The actual routed BUF must have
A103525/Q130900, exact MCOMB34.24.6 BEL, empty parameters, real SIG A/C and
Q/COMBOUT pin map, one named private Q alias and one FF.DATAIN consumer. The
FF remains FF34.24.8 with all other metadata/connections exact. Removing
these two explicitly named per-image comparison slots must leave every other
consumer identical; the source graph and raw IDs are never mutated.

The actual after-image chain is checked against its unique row in the closed
a4a explicit buffer ledger, including the physical32-row bank0xf0f0f0f0 and
two identity truth rows from enter_write ALUT2.Q. This reuses authenticated
accepted physical evidence; it is not a new physical-mask evaluation. That
row's historical q_before130898 describes a different routed reference frame
and is never treated as the g1 baseline input. G1's real direct DATAIN is
103525. Its unseen physical pins and controls remain explicitly unproved.
There is no generic buffer collapse, raw-ID translation or broader allowance.

The accepted180 original path objects/order,71 misses/29 LABs, actual clocks,
PLL occurrences/CLKBUF, scalar aliases and five-input32-row logical eligibility
are unchanged. No arc, location, skew, source, delay, window or endpoint is
projected. Flat accepted a4a and g1 84af proof closures are rehashed directly;
only026317 pure native/audit utilities run, with no old generator/authenticator
entrypoints. This creates no new candidate, current STA/gain, routed acceptance
or hardware claim. All input paths and new outputs are rechecked around
exclusive publication.
