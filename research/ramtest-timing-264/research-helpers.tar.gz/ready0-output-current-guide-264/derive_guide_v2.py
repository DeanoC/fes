"""Derive untouched port0 ready paths with one explicit cross-image BUF load ledger."""
import argparse
from collections import Counter
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PURE = RAW / "driver-copy-ready-current-guide-264/derive_ready_guide.py"
PURE_SHA = "026317bcc0fe2d668451ca0ce65f51f0dc86691547caab460b012e6595fab2c9"
PARENT = RAW / "driver-copy-route-proof-v2-264/comparison.json"
PARENT_SHA = "a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304"
PREFIX = RAW / "ready-current-guide-g1-264/baseline/comparison.json"
PREFIX_SHA = "84afc015cd56263ea1d1542d281952c7eb699fe09a79a8718c76896e957d7458"
FULL, REPORT = RAW / "driver-copy-route-264/route-c0/routed.json", RAW / "driver-copy-route-264/route-c0/timing.json"
BASELINE = RAW / "ready-current-guide-g1-264/baseline/placed.json"
GUIDE, MANIFEST = HERE / "ready-guide-v2.json", HERE / "derivation-v2.json"
V1_SHA = "543b5ece1ca1f82fa0c151b88db8b4e4ba2e0211b063d727a127cc1391559dbe"
V1_SCOPE_SHA = "58c3c40c9e87c6ac03fe3c7a5a412de72b5833c79cc3049114d2d4a3efb00237"
INNER, OUTER = "hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port0.slot_free_MISTRAL_ALUT4_C"
HPS, PLL, BUFFER = "hps_ddr.f2sdram", "ram_clock.pll", "ram_clock.clocks_MISTRAL_CLKBUF_Q_1"
CLOCK, DOMAIN = "ram_clock.clocks[0]", "posedge ram_clock.clocks[0]"
COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("generator-sha256", "scope-sha256", "parent-proof-sha256", "prefix-proof-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    if not (args.parent_proof_sha256 == PARENT_SHA and args.prefix_proof_sha256 == PREFIX_SHA and
            not GUIDE.exists() and not MANIFEST.exists()):
        raise ValueError("wrong proof pins or diagnostic outputs already exist")
    import hashlib
    with PURE.open("rb") as stream:
        if hashlib.file_digest(stream, "sha256").hexdigest() != PURE_SHA:
            raise ValueError("frozen pure parser bytes changed")
    spec = importlib.util.spec_from_file_location("ready0_guide_pure_native", PURE)
    pure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pure)
    require, audit = pure.require, pure.Audit()
    for path, expected in ((PURE, PURE_SHA), (Path(__file__).resolve(), args.generator_sha256),
            (HERE / "scope-v2.md", args.scope_sha256), (HERE / "derive_guide.py", V1_SHA),
            (HERE / "scope.md", V1_SCOPE_SHA), (PARENT, PARENT_SHA), (PREFIX, PREFIX_SHA)):
        audit.bind(path, expected)
    parent, prefix = pure.read(PARENT), pure.read(PREFIX)
    require(parent["compiler_commit"] == prefix["compiler_commit"] == COMMIT and
        parent["structural_rejection"] is prefix["structural_rejection"] is None and
        all(parent[key] is True for key in ("candidate_completed", "graph_proof_available", "full_graph_and_pin_equivalence_proved",
            "candidate_accepted_under_confirmed_target_clock_rule", "final_original_path_metadata_and_runtime_hashes_stable")) and
        prefix["phase"] == "current-guide-g1-bounded-native-prefix" and
        all(prefix[key] is True for key in ("candidate_completed", "native_graph_proof_available",
            "fresh_driver_guide_available_after_conditional_prefix_proof", "final_original_path_metadata_and_runtime_hashes_stable")), "closed proof classifications changed")
    for proof, count in ((parent, 526), (prefix, 545)):
        require(len(proof["artifact_sha256"]) == count and len(proof["execution_file_sha256"]) == 281, "flat closure count changed")
        for name, expected in proof["artifact_sha256"].items():
            require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
            audit.bind(ROOT / name, expected)
        for name, expected in proof["execution_file_sha256"].items():
            audit.bind(Path(name), expected, runtime=True)
    require(all(path in audit.paths for path in (FULL, REPORT, BASELINE)), "actual frames/report absent from flat proof closure")
    full, baseline, report = pure.Native(FULL), pure.Native(BASELINE), pure.read(REPORT)
    require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290, "accepted report shape changed")
    expected_cells = {INNER: ("MISTRAL_ALUT2", "1011", "MISTRAL_COMB.43.27.55", {"A": [98306], "B": [98311], "Q": [97446]}),
        OUTER: ("MISTRAL_ALUT4", "1111000011100000", "MISTRAL_MCOMB.25.27.18", {"A": [20833], "B": [5029], "C": [97446], "D": [103525], "Q": [99105]})}
    require(OUTER + "$local_remap" not in full.cells and OUTER + "$local_remap" not in baseline.cells, "this outer already has a local clone")
    def signal_pin(name, port):
        value = full.pins(name).get(port)
        return type(value) is list and len(value) >= 2 and value[0] == 0 and all(type(pin) is str for pin in value[1:])
    for name, (kind, lut, bel, connections) in expected_cells.items():
        require(all(native.cells[name]["type"] == kind and native.cells[name]["parameters"] == {"LUT": lut} and
            native.cells[name]["attributes"]["NEXTPNR_BEL"] == bel and native.cells[name]["connections"] == connections
            for native in (full, baseline)) and pure.cell_metadata(full.cells[name]) == pure.cell_metadata(baseline.cells[name]), "actual cone changed")
        require(all(signal_pin(name, port) for port in connections), "accepted cone pin is not SIG")
    require(full.pll[PLL] == baseline.pll[PLL] and pure.cell_metadata(full.cells[PLL]) == pure.cell_metadata(baseline.cells[PLL]) and
        [bits for port, bits in full.pll[PLL]["connections"] if port == "outclk"] == [[112724], [112726]], "actual paired PLL changed")
    require(full.cells[BUFFER]["type"] == baseline.cells[BUFFER]["type"] == "MISTRAL_CLKBUF" and
        full.cells[BUFFER]["connections"] == baseline.cells[BUFFER]["connections"] == {"A": [112726], "Q": [3549]} and
        pure.cell_metadata(full.cells[BUFFER]) == pure.cell_metadata(baseline.cells[BUFFER]) and
        full.pins(BUFFER) == {"A": [0, "A"], "Q": [0, "Q"]}, "explicit native CLKBUF changed")
    for native in (full, baseline):
        require(native.scalar(HPS, "cmd_port_clk_0", "input") == 3549 and native.scalar(HPS, "cmd_ready_0", "output") == 98306 and
            native.drivers[3549] == (BUFFER, "Q", 0) and native.drivers[112726] == (PLL, "outclk", 1) and
            native.users[112726] == [(BUFFER, "A", 0)] and native.nets[CLOCK]["bits"] == [3549], "actual buffered launch clock chain changed")
    clock_aliases = []
    for bit, alias in ((3549, CLOCK), (112724, "ram_clock.pll_outclk_1"), (112726, "ram_clock.pll_outclk")):
        require(full.aliases[bit] == baseline.aliases[bit] == [(alias, 0)], "original complete clock aliases changed")
        def metadata(native):
            return {key: ({k: v for k, v in value.items() if k != "ROUTING"} if key == "attributes" else value)
                for key, value in native.nets[alias].items()}
        require(metadata(full) == metadata(baseline), "clock alias metadata changed")
        clock_aliases.append({"alias": alias, "native_bit": bit, "metadata_excluding_routing": metadata(full)})
    require(full.users[3549] == baseline.users[3549], "original clock consumers changed")
    selected, membership, endpoints, labs, violations, worst = [], [], set(), Counter(), 0, -math.inf
    for index, path in enumerate(report["critical_paths"]):
        edges = [segment for segment in path["path"] if segment["type"] == "routing"]
        if len(edges) < 2 or not (edges[-2]["from"]["cell"] == INNER and edges[-2]["to"]["cell"] == OUTER and
                edges[-1]["from"]["cell"] == OUTER and edges[-1]["to"]["port"] == "ENA"):
            continue
        parts, sink = path["path"], edges[-1]["to"]["cell"]
        require(path["from"] == path["to"] == DOMAIN and path["max_delay"] == 7.691999912261963 and
            [part["type"] for part in parts] == ["clk-skew", "clk-to-q", "routing", "logic", "routing", "logic", "routing", "setup"] and
            sink not in endpoints and all(native.cells[sink]["type"] == "MISTRAL_FF" for native in (full, baseline)), "selected registered path changed")
        expected = [(HPS, "cmd_port_clk_0", sink, "CLK"), (HPS, "cmd_ready_0", HPS, "cmd_ready_0"),
            (HPS, "cmd_ready_0", INNER, "A"), (INNER, "A", INNER, "Q"), (INNER, "Q", OUTER, "C"),
            (OUTER, "C", OUTER, "Q"), (OUTER, "Q", sink, "ENA"), (sink, "ENA", sink, "ENA")]
        for segment, ports in zip(parts, expected):
            require(set(segment) == ({"type", "from", "to", "delay", "net", "sources"} if segment["type"] == "routing" else {"type", "from", "to", "delay"}) and
                (segment["from"]["cell"], segment["from"]["port"], segment["to"]["cell"], segment["to"]["port"]) == ports and
                type(segment["delay"]) in (int, float) and math.isfinite(segment["delay"]), "exact native arc/schema changed")
            for side in ("from", "to"):
                value, name, port = segment[side], segment[side]["cell"], segment[side]["port"]
                require(full.endpoint(value) == baseline.endpoint(value) and pure.cell_metadata(full.cells[name]) == pure.cell_metadata(baseline.cells[name]) and
                    signal_pin(name, port), "original scalar/location/metadata or accepted SIG state changed")
            if segment["type"] == "routing":
                require(type(segment["sources"]) is list and all(type(source) is str for source in segment["sources"]), "routing provenance malformed")
                for native in (full, baseline):
                    bit = native.endpoint(segment["from"], "output")
                    require(native.endpoint(segment["to"], "input") == bit and native.drivers[bit] == (ports[0], ports[1], 0) and
                        native.nets[segment["net"]]["bits"] == [bit] and (segment["net"], 0) in native.aliases[bit] and
                        (ports[2], ports[3], 0) in native.users[bit], "actual routing scalar/driver/user/alias changed")
        require(full.scalar(sink, "CLK", "input") == baseline.scalar(sink, "CLK", "input") == 3549, "actual capture clock changed")
        total = math.fsum(part["delay"] for part in parts)
        require(math.isfinite(total), "nonfinite actual signed path sum")
        selected.append(path); endpoints.add(sink); labs[tuple(parts[-1]["to"]["loc"])] += 1
        violations += total > path["max_delay"]; worst = max(worst, total)
        membership.append({"source_index": index, "canonical_path_sha256": pure.object_sha(path), "endpoint": sink,
            "loc": parts[-1]["to"]["loc"], "reported_sum_ns": total, "reported_window_ns": path["max_delay"]})
    require((len(selected), violations, len(labs), worst) == (180, 71, 29, 8.373999953269958), "actual 180-path ready family changed")
    users = [(name, "ENA", 0) for name in sorted(endpoints)]
    require(full.users[99105] == baseline.users[99105] == users, "complete original 180-user closure changed")
    signals, table = [98306, 98311, 20833, 5029, 103525], []
    require(all(bit in full.drivers and full.drivers[bit] == baseline.drivers[bit] and full.aliases[bit] == baseline.aliases[bit]
        for bit in signals) and all(full.users[bit] == baseline.users[bit] for bit in signals if bit != 103525),
        "external composition driver/alias or other input-user identities changed")
    ff, source = "hps_ddr.port0.skid_write_MISTRAL_FF_Q", "hps_ddr.port0.enter_write_MISTRAL_ALUT2_Q"
    buf, alias = ff + "$ROUTETHRU", ff + "$ROUTETHRU$conn$Q"
    rows = parent["actual_one_copy_one_operand_and_explicit_buffer_private_bit_proof"]["explicit_named_buffer_private_bit_and_unique_ff_ledger"]["rows"]
    matches = [row for row in rows if row["buffer"] == buf]
    require(len(matches) == 1, "accepted explicit physical buffer ledger is not unique")
    row = matches[0]
    require(row["input_raw_bit"] == 103525 and row["q_after_raw_bit"] == 130900 and row["bel"] == "MISTRAL_MCOMB.34.24.6" and
        row["ff_bel"] == "MISTRAL_FF.34.24.8" and row["private_named_alias"] == alias and
        row["input_native_driver_slot"] == [source, "Q", 0, 0] and row["q_native_owner_slot"] == [buf, "Q", 0, 0] and
        row["q_users_after"] == [[ff, "DATAIN", 0, 0]] and row["unique_ff_datain_consumer_slot"] == [ff, "DATAIN", 0, 0] and
        row["actual_buffer_pin_states"] == {"A": [0, "C"], "Q": [0, "COMBOUT"]} and
        row["physical_bank_after"] == {"active_low_mask_hex": "0xf0f0f0f0", "alias_consistent_rows_checked": 32, "physical_rows_derived": 32} and
        row["input_effective_native_driver"] == ["cell", source, "Q", 0] and
        row["effective_buffer_truth"] == {"boundary": [["cell", source, "Q", 0]], "distinct_native_input_rows_checked": 2,
            "repeated_input_slots_preserved": True, "rows": [{"Q": 0, "row": 0}, {"Q": 1, "row": 1}]} and
        row["buffer_and_ff_metadata_full_pins_exact_except_these_two_raw_slots"] is True, "accepted after-frame BUF identity/truth row changed")
    require(buf not in baseline.cells and alias not in baseline.nets and full.cells[buf]["type"] == "MISTRAL_BUF" and
        full.cells[buf]["parameters"] == {} and full.cells[buf]["port_directions"] == {"A": "input", "Q": "output"} and
        full.cells[buf]["connections"] == {"A": [103525], "Q": [130900]} and full.cells[buf]["attributes"]["NEXTPNR_BEL"] == row["bel"] and
        full.pins(buf) == row["actual_buffer_pin_states"] and full.drivers[130900] == (buf, "Q", 0) and
        full.users[130900] == [(ff, "DATAIN", 0)] and full.aliases[130900] == [(alias, 0)] and full.nets[alias]["bits"] == [130900],
        "actual routed BUF/private-Q/unique-consumer/alias differs from accepted ledger")
    require(full.cells[ff]["type"] == baseline.cells[ff]["type"] == "MISTRAL_FF" and
        full.cells[ff]["attributes"]["NEXTPNR_BEL"] == baseline.cells[ff]["attributes"]["NEXTPNR_BEL"] == row["ff_bel"] and
        pure.cell_metadata(full.cells[ff]) == pure.cell_metadata(baseline.cells[ff]) and signal_pin(ff, "DATAIN") and
        full.scalar(ff, "DATAIN", "input") == 130900 and baseline.scalar(ff, "DATAIN", "input") == 103525 and
        {port: bits for port, bits in full.cells[ff]["connections"].items() if port != "DATAIN"} ==
        {port: bits for port, bits in baseline.cells[ff]["connections"].items() if port != "DATAIN"} and
        full.drivers[103525] == baseline.drivers[103525] == (source, "Q", 0), "actual direct-versus-buffered FF input or other FF fields changed")
    old_slot, new_slot = (ff, "DATAIN", 0), (buf, "A", 0)
    require(len(full.users[103525]) == len(baseline.users[103525]) == 14 and baseline.users[103525].count(old_slot) == 1 and
        full.users[103525].count(new_slot) == 1 and old_slot not in full.users[103525] and new_slot not in baseline.users[103525] and
        [slot for slot in baseline.users[103525] if slot != old_slot] == [slot for slot in full.users[103525] if slot != new_slot],
        "the explicit one-load per-image ledger does not close every input consumer")
    for truth_index in range(32):
        inner = (0xb >> ((truth_index & 1) | ((truth_index >> 1 & 1) << 1))) & 1
        outer_index = (truth_index >> 2 & 1) | ((truth_index >> 3 & 1) << 1) | (inner << 2) | ((truth_index >> 4 & 1) << 3)
        table.append((0xf0e0 >> outer_index) & 1)
    require(len(set(signals)) == 5 and all(any(table[row] != table[row ^ (1 << bit)] for row in range(32)) for bit in range(5)), "composition support is not five essential signals")
    guide = {"critical_paths": selected}
    audit.finish()
    with GUIDE.open("x") as stream:
        stream.write(json.dumps(guide, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(pure.read(GUIDE) == guide, "serialized guide changed an original path object")
    manifest = {"schema": 1, "completed": True, "phase": "exact-accepted-port0-ready-output-guide-explicit-input-buffer-v2", "compiler_commit": COMMIT,
        "parent_proof_sha256": PARENT_SHA, "prefix_proof_sha256": PREFIX_SHA, "generator_sha256": args.generator_sha256,
        "scope_sha256": args.scope_sha256, "pure_native_parser_sha256": PURE_SHA, "source_report_sha256": pure.sha(REPORT),
        "guide_path": str(GUIDE), "guide_sha256": pure.sha(GUIDE), "paths": 180, "reported_window_violations": 71, "labs": 29,
        "worst_reported_sum_ns": worst, "membership": membership, "actual_original_root_ena_users": [list(user) for user in users],
        "lab_counts": [{"loc": list(loc), "paths": count} for loc, count in sorted(labs.items())],
        "exact_path_objects_and_original_source_order_preserved": True, "clock_terms_locations_nets_sources_windows_or_segment_delays_modified": False,
        "registered_clock": {"domain": DOMAIN, "native_bit": 3549, "buffer": BUFFER, "buffer_input_native_bit": 112726,
            "buffer_input_actual_driver": [PLL, "outclk", 1], "paired_pll_outputs": [[112724], [112726]], "clock_aliases": clock_aliases,
            "clockbuf_collapsed_or_logical_parameter_channel_inferred": False},
        "composition_eligibility": {"inner": INNER, "outer": OUTER, "logical_input_native_bits": signals, "essential_inputs": 5,
            "rows": table, "mask": hex(sum(value << index for index, value in enumerate(table))),
            "accepted_full_pin_states_SIG_checked": True, "g1_unexported_pin_states_or_physical_composition_proved": False},
        "new_candidate_qualified": False, "new_sta_or_routing_gain_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "old_generator_or_authenticator_entrypoints_executed": False, "artifact_sha256": audit.artifacts,
        "historical_execution_file_sha256_rehashed": audit.runtime,
        "immutable_v1_generator_sha256": V1_SHA, "immutable_v1_scope_sha256": V1_SCOPE_SHA,
        "v1_outputs_or_failure_record_rewritten": False, "global_normalization_or_buf_collapse_used": False,
        "explicit_per_image_input_load_ledger": {"native_input_bit": 103525, "input_source": [source, "Q", 0],
            "all_other_input_users_exact": True, "total_load_slots_per_image": 14,
            "g1_direct_input_slot": list(old_slot), "accepted_routed_input_slot": list(new_slot),
            "accepted_routed_private_q_bit": 130900, "private_alias": alias,
            "accepted_after_frame_closed_physical_ledger_row": row,
            "historical_q_before_is_not_g1_baseline_and_not_used": True,
            "g1_unexported_physical_pin_states_independently_proved": False}}
    audit.finish()
    with MANIFEST.open("x") as stream:
        stream.write(json.dumps(manifest, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(pure.read(MANIFEST) == manifest and pure.sha(GUIDE) == manifest["guide_sha256"], "immutable new outputs changed")
    audit.finish()
    print(json.dumps({"completed": True, "guide_sha256": manifest["guide_sha256"], "manifest_sha256": pure.sha(MANIFEST),
        "paths": 180, "reported_window_violations": 71, "labs": 29, "routed_gain_accepted": False}, indent=2))


if __name__ == "__main__":
    main()
