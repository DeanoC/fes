"""Compare the existing single-root transform with no packing, placement or route.

This deliberately invokes the real JSON loader in the retained accepted compiler
and the frozen placed-reduction prototype. Diagnostic environment hooks remain
unset. Root runs this separately from the full-route experiment.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
MODULE = ROOT / "sources/misteross"
RAW = Path(__file__).resolve().parent
WIDE_ROOT = "ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT6_F_E_MISTRAL_ALUT5_Q_1"
sys.path.insert(0, str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    output = RAW / "single-root-control-equivalence"
    output.mkdir(exist_ok=False)
    baseline = RAW.parent / "route-slots-final"
    candidate = RAW / "route-local-r6-s0"
    baseline_record = json.loads((baseline / "run.json").read_text())
    candidate_record = json.loads((candidate / "run.json").read_text())
    require(baseline_record["build_id"] == candidate_record["build_id"], "BUILD_ID changed")
    source = Path(candidate_record["command"][candidate_record["command"].index("--json") + 1])
    source_digest = sha(source)
    require(source_digest == candidate_record["input_sha256"][str(source)] ==
            baseline_record["input_sha256"][str(source)], "synthesis input changed")
    binaries = {"accepted": RAW.parent / "validated-nextpnr-mistral", "candidate": RAW / "nextpnr-mistral"}
    expected = {
        "accepted": baseline_record["input_sha256"][baseline_record["command"][0]],
        "candidate": candidate_record["input_sha256"][str(binaries["candidate"])],
    }
    identity = json.loads((RAW / "source-identity.json").read_text())
    require(expected["candidate"] == identity["binary_sha256"], "candidate source identity mismatch")
    archive = RAW / "source.tar.gz"
    require(sha(archive) == candidate_record["source_archive_sha256"], "candidate archive changed")
    for label, binary in binaries.items():
        require(sha(binary) == expected[label], f"{label} compiler bytes changed")
    record = {
        "comparison": "retained accepted binary vs frozen prototype; real JSON loader; no pack/place/route",
        "build_id": candidate_record["build_id"], "root": WIDE_ROOT,
        "input_sha256": {str(source): source_digest, str(archive): sha(archive),
                         **{str(p): expected[k] for k, p in binaries.items()}},
        "completed": False, "runs": {},
        "default_recipe_selected": False, "hardware_tested": False,
    }
    manifest = output / "comparison.json"
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    start = time.monotonic()
    try:
        for label, binary in binaries.items():
            tool = board.AuthenticatedTool(binary, "sha256=" + expected[label])
            invocation = FunctionalInvocation({"nextpnr-mistral": tool}, 1)
            transformed = output / (label + ".json")
            command = [str(binary), "--json", str(source), "--device", "5CSEBA6U23I7",
                       "--no-pack", "--no-place", "--no-route", "--balance-reduction-root", WIDE_ROOT,
                       "--write", str(transformed)]
            record["runs"][label] = {"command": command, "execution": invocation.inputs}
            try:
                require(not any(k.startswith("NEXTPNR_MISTRAL_") for k in invocation.env),
                        "an experimental environment hook is enabled")
                with (output / (label + ".log")).open("w") as log:
                    result = audited_run(command, source_root=MODULE, cwd=MODULE, env=invocation.env,
                                         stdout=log, stderr=subprocess.STDOUT, check=False, timeout=300)
                record["runs"][label]["exit_code"] = result.returncode
                require(result.returncode == 0, f"{label} transform failed")
                text = (output / (label + ".log")).read_text()
                require("Info: Program finished normally." in text, f"{label} normal completion missing")
                require("Running the GPU router" not in text and "HeAP Placer Time" not in text,
                        f"{label} unexpectedly placed or routed")
                invocation.verify()
                record["runs"][label]["transformed_sha256"] = sha(transformed)
            finally:
                invocation.close()
        accepted = json.loads((output / "accepted.json").read_text())["modules"]
        current = json.loads((output / "candidate.json").read_text())["modules"]
        require(accepted == current, "the existing single-root transformed modules changed")
        record["single_root_transformed_modules_identical"] = True
        record["modules_sha256"] = hashlib.sha256(
            json.dumps(accepted, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        for filename, digest in record["input_sha256"].items():
            require(sha(Path(filename)) == digest, f"input changed during control check: {filename}")
        record["completed"] = True
        print(json.dumps({k: v for k, v in record.items() if k not in ("input_sha256", "runs")}, indent=2))
    except BaseException as exc:
        record["failure"] = repr(exc)
        raise
    finally:
        record["elapsed_seconds"] = time.monotonic() - start
        manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
