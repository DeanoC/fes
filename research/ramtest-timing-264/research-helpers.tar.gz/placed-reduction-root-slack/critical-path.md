# Routed critical path after the placed eleven-literal rewrite

Compared complete routes:

- Control: `../capture-locality/route-b64-r24/{timing.json,routed.json}`; memory110.9631576538086 MHz.
- Candidate: `route-local-r6-s0/{timing.json,routed.json}`; memory115.38018035888672 MHz, pixel93.58038330078125 MHz, capture307.6318054199219 MHz.

The memory bottleneck **moved away from the eleven-input error-counter conjunction**. The new critical path is hard-HPS `cmd_ready_1` to the port1 address18 FF's ENA, through the existing two-LUT slot-free/control cone.

| Segment | Coordinates | Delay ns |
| --- | --- | --- |
| HPS/capture clock skew | HPS anchor52,53 -> FF24,13 | +0.150 |
| HPS cmd_ready_1 clock-to-Q | HPS anchor52,53 | 1.177 |
| cmd_ready_1 routing | HPS -> ALUT2 at33,19 | 4.117 |
| ALUT2 A->Q logic |33,19 |0.400 |
| slot_free routing |33,19 -> ALUT4 at25,19 |0.966 |
| ALUT4 C->Q logic |25,19 |0.400 |
| Enable routing |25,19 -> FF24,13 |1.653 |
| FF ENA setup |24,13 |-0.196 |
| Total | |8.667 |

Routing contributes6.736 ns; fabric logic contributes0.800 ns. The remaining terms are HPS clock-to-Q1.177 ns and combined skew/setup-0.046 ns. The130.0052 MHz target permits7.692 ns, leaving0.975 ns to recover on this path.

The HPS source, both LUTs and capturing FF have identical BELs and identical serialized pin maps in the control and candidate. The old error27 source FF at9,32 and error18 ENA sink FF at2,5 also retain identical BELs/pin maps. The only rewritten LUTs are now ALUT6 at12,22, ALUT5 at13,22 and the preserved root BEL at10,22, changed from ALUT4 to ALUT2.

The **entire serialized net entry for `ram_clock.clocks[0]` is byte-value identical** between these JSON files, including its ROUTING attribute. This is the memory clock net/tree comparison, not a claim that data routing stayed identical. `hps_ddr.cmd_ready_1` and the final enable net ROUTING attributes differ; the intermediate `hps_ddr.port1.slot_free` ROUTING attribute matches exactly. Thus physical placement and the memory clock net stayed fixed while data routing changed.

The HPS location52,53 in the report is its BEL anchor, not the physical ready-pin exit. The candidate's saved ready-net route begins with a hop from **GIN.51.64.18** to H6.46.64.22. Any future geometry scoring should use the backend source wire rather than treating the BEL anchor as that signal's physical origin.

## What the detailed timing data proves

For the error18 ENA endpoint on the final error-counter enable net, the detailed maximum arrival falls from10.527000427 to9.678999901 ns: improvement0.848000526 ns. The corresponding minimum arrival rises from6.856999874 to7.105000019 ns. This confirms improved maximum timing at that endpoint.

Those detailed values summarize all upstream fan-in in the clock domain. They do **not** isolate the bit27-to-bit18 path, and they include timing terms different from the critical-path segment sum. The old9.012 ns bit27 path therefore cannot be assigned an exact new delay from these records alone. The new worst path's8.667 ns also cannot be substituted for that old path: its source and cone changed.

The detailed maximum arrival at the new HPS address18 ENA endpoint rises from9.887000084 to10.201000214 ns (0.314000130 ns). Together with unchanged source/sink/LUT BELs and changed ready/final-enable routing, this shows the new bottleneck had routing variation while the selected counter cone improved. It does not prove an isolated delay change for each ready-path routing arc in the control.

## Next generic compiler target

The critical ALUT2 has LUT mask0xb and inputs `cmd_ready_1` and command-valid1. Its Q feeds C of an ALUT4 with mask0xf0e0. The other ALUT4 inputs are owed-after[0], command-end[2] and beats-after[4]. These are exactly **five distinct external inputs** in the composed two-LUT function, so one ordinary ALUT5 can express it with exhaustive32-row truth-table verification.

The original ALUT2 must remain because its slot-free output also serves the command-read/write FF enables and skid control. The outer control net serves **109 FF ENA consumers across22 LABs**. Replacing the shared inner cell in place would affect those independent consumers, and one relocated clone should not be assumed to improve all109 destinations.

Use the existing generic report-guided local remap mechanism to test a composed ALUT5 clone for bounded critical ENA groups. Preserve every other consumer, the shared original cells, unrelated FF BELs and user slots; verify ALM/LAB legality, abstract setup and hold guards, then the complete route. Select from the new timing report and current frozen inputs. The latest hard-HPS input can potentially use a faster ALUT5 input pin, but this is a separate prediction requiring routed validation.

Further pin permutation of the eleven-literal conjunction would improve margin on a cone that is no longer the worst path. It is not the immediate lever for increasing the present115.380 MHz global memory result. The HPS-ready composed cone is the next concrete mapping/placement target; no improvement is claimed before its full-route test.
