"""Authenticate the placed-reduction route and compare its two frozen controls.

Run after route_local.py finishes. This writes evidence only; it does not select
a compiler, package or RBF. The 110 MHz capture-locality control is experimental.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import re
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = RAW.parents[2]
BASE = RAW.parent / "route-slots-final"
CONTROL = RAW.parent / "capture-locality/route-b64-r24"
MEMORY_CLOCK = "ram_clock.clocks[0]"
ROOT_CELL = "ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT4_Q"
CUBE_CELLS = {
    ROOT_CELL,
    ROOT_CELL + "_D_MISTRAL_ALUT5_Q",
    ROOT_CELL + "_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_Q",
}
PLACEMENT_METRICS = re.compile(
    r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def relative(path):
    return str(path.relative_to(ROOT))


def verify_archive(archive_path, source_hashes):
    require(source_hashes, f"empty source manifest: {archive_path}")
    with tarfile.open(archive_path) as archive:
        for name, expected in source_hashes.items():
            source = archive.extractfile(name)
            require(source is not None, f"source missing from archive: {name}")
            require(hashlib.sha256(source.read()).hexdigest() == expected,
                    f"archived source digest mismatch: {name}")
    return {"archive_sha256": sha(archive_path), "verified_source_files": len(source_hashes)}


def authenticate_inputs(record, binary_override=None):
    verified = {}
    for filename, expected in record["input_sha256"].items():
        original = Path(filename)
        actual = binary_override if binary_override and original.name == "nextpnr-mistral" else original
        require(sha(actual) == expected, f"input digest mismatch: {filename} (checked {actual})")
        verified[filename] = {"sha256": expected, "verified_path": str(actual)}
    return verified


def source_identity(folder, record):
    identity = read(folder / "source-identity.json")
    require(sha(folder / "nextpnr-mistral") == identity["binary_sha256"],
            f"binary identity mismatch: {folder}")
    binary = Path(record["command"][0])
    require(record["input_sha256"][str(binary)] == identity["binary_sha256"],
            f"recorded binary identity mismatch: {folder}")
    archive = folder / "source.tar.gz"
    if "source_archive_sha256" in record:
        require(sha(archive) == record["source_archive_sha256"], f"source archive mismatch: {folder}")
    if "source_archive_sha256" in identity:
        require(sha(archive) == identity["source_archive_sha256"], f"source identity archive mismatch: {folder}")
    verified = verify_archive(archive, identity["source_sha256"])
    return {**verified, "binary_sha256": identity["binary_sha256"],
            "base_commit": identity["base_commit"],
            **{k: identity[k] for k in ("result_commit", "branch", "status") if k in identity}}


def route_evidence(folder):
    record = read(folder / "run.json")
    require(record["completed"] and record["exit_code"] == 0, f"route is incomplete or failed: {folder}")
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log, f"normal completion missing: {folder}")
    require(not any(line.startswith("ERROR: Failed to route arc ") for line in log.splitlines()),
            f"failed route arc: {folder}")
    lower = log.lower()
    require("falling back to the cpu reference backend" not in lower and "backend cpu-reference" not in lower,
            f"CPU reference fallback: {folder}")
    backends = re.findall(r"\bbackend\s+(hip:[^\n]*?)\s+ready\b", log, re.I)
    require(backends, f"live HIP backend missing: {folder}")
    require("Running signoff timing analysis..." in log, f"final signoff missing: {folder}")
    hold = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
    require(record["final_reported_hold_violations"] is hold, f"hold record disagrees with final log: {folder}")
    report = read(folder / "timing.json")
    require(record["fmax"] == report["fmax"], f"recorded Fmax disagrees with final report: {folder}")
    rbf = folder / "core.rbf"
    require(rbf.stat().st_size > 0, f"empty RBF: {folder}")
    cells = read(folder / "routed.json")["modules"]["top"]["cells"]
    require(cells and all(c["attributes"].get("NEXTPNR_BEL") for c in cells.values()),
            f"routed design contains unplaced cells: {folder}")
    return record, report, cells, log, {
        "successful_full_route": True, "live_hip_backends": sorted(set(backends)),
        "final_signoff_reported": True, "final_reported_hold_violations": hold,
        "rbf_bytes": rbf.stat().st_size, "rbf_sha256": sha(rbf),
    }


def compare_clocks(baseline, candidate):
    require(set(candidate["fmax"]) == set(baseline["fmax"]), "clock set changed")
    result = {}
    for clock, current in sorted(candidate["fmax"].items()):
        old = baseline["fmax"][clock]
        require(current["constraint"] == old["constraint"], f"clock constraint changed: {clock}")
        result[clock] = {
            "control_mhz": old["achieved"], "candidate_mhz": current["achieved"],
            "constraint_mhz": current["constraint"],
            "gain_mhz": current["achieved"] - old["achieved"],
            "gain_percent": 100 * (current["achieved"] / old["achieved"] - 1),
            "meets_constraint": current["achieved"] >= current["constraint"],
        }
    return result


def bel(cell):
    return cell["attributes"].get("NEXTPNR_BEL")


def cell_category(name, cell):
    if cell["type"] == "MISTRAL_FF":
        return "ff"
    if name in CUBE_CELLS:
        return "cube_lut"
    if cell["type"] == "MISTRAL_BUF":
        return "transparent_buffer"
    return "other"


def compare_cells(old_cells, new_cells):
    common = set(old_cells) & set(new_cells)
    changed = {category: [] for category in ("ff", "cube_lut", "transparent_buffer", "other")}
    for name in sorted(common):
        if bel(old_cells[name]) != bel(new_cells[name]):
            changed[cell_category(name, old_cells[name])].append({
                "cell": name, "control_bel": bel(old_cells[name]), "candidate_bel": bel(new_cells[name]),
                "control_type": old_cells[name]["type"], "candidate_type": new_cells[name]["type"],
            })
    added = sorted(set(new_cells) - set(old_cells))
    removed = sorted(set(old_cells) - set(new_cells))
    old_ffs = {n for n, c in old_cells.items() if c["type"] == "MISTRAL_FF"}
    new_ffs = {n for n, c in new_cells.items() if c["type"] == "MISTRAL_FF"}
    require(old_ffs == new_ffs and not changed["ff"], "FF population or placement changed against 110 MHz control")
    require(not changed["other"], "a common BEL outside the three cone LUTs and transparent buffers changed")
    require(all(new_cells[n]["type"] == "MISTRAL_BUF" for n in added) and
            all(old_cells[n]["type"] == "MISTRAL_BUF" for n in removed), "non-buffer cell added or removed")
    logical_changes = sorted(n for n in common if any(
        old_cells[n][key] != new_cells[n][key] for key in ("type", "parameters")))
    require(set(logical_changes) == CUBE_CELLS, "LUT type/parameter changes do not match exactly the three cone LUTs")
    require(bel(old_cells[ROOT_CELL]) == bel(new_cells[ROOT_CELL]), "root LUT BEL changed")
    return {
        "common_cells": len(common), "common_ff_cells": len(old_ffs), "ff_placements_identical": True,
        "changed_common_bels_by_kind": changed,
        "changed_common_bels": [x["cell"] for entries in changed.values() for x in entries],
        "added_cells": added, "removed_cells": removed, "logical_type_or_parameter_changes": logical_changes,
        "root_bel_preserved": True,
        "cube_luts": {n: {
            "control_bel": bel(old_cells[n]), "candidate_bel": bel(new_cells[n]),
            "control_type": old_cells[n]["type"], "candidate_type": new_cells[n]["type"],
            "control_parameters": old_cells[n]["parameters"], "candidate_parameters": new_cells[n]["parameters"],
        } for n in sorted(CUBE_CELLS)},
    }


def cone_expression(cells):
    """Read the three-LUT Boolean cone, bypassing router-created BUF cells."""
    drivers = {}
    for name, cell in cells.items():
        for port, direction in cell["port_directions"].items():
            if direction == "output":
                for index, bit in enumerate(cell["connections"][port]):
                    require(bit not in drivers, f"multiple net drivers: {bit}")
                    drivers[bit] = (name, port, index)
    leaves, visited = set(), set()

    def expression(bit, stack):
        if isinstance(bit, str):
            require(bit in ("0", "1"), f"unknown constant in cone: {bit}")
            return ("constant", int(bit))
        require(bit not in stack, "cyclic cone")
        require(bit in drivers, f"undriven cone input: {bit}")
        name, port, index = drivers[bit]
        cell = cells[name]
        if cell["type"] == "MISTRAL_BUF":
            return expression(cell["connections"]["A"][0], stack | {bit})
        if name not in CUBE_CELLS:
            token = (name, port, index)
            leaves.add(token)
            return ("variable", token)
        visited.add(name)
        require(port == "Q" and index == 0, f"unexpected cone output: {name}.{port}")
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        inputs = [expression(cell["connections"][pin][0], stack | {bit}) for pin in "ABCDEF"[:width]]
        return ("lut", int(cell["parameters"]["LUT"], 2), inputs)

    tree = expression(cells[ROOT_CELL]["connections"]["Q"][0], set())
    require(visited == CUBE_CELLS, "the root does not reach all three cone LUTs")
    return tree, leaves


def evaluate(tree, values):
    if tree[0] == "constant":
        return tree[1]
    if tree[0] == "variable":
        return values[tree[1]]
    index = sum(evaluate(child, values) << i for i, child in enumerate(tree[2]))
    return (tree[1] >> index) & 1


def depth(tree):
    return 1 + max(map(depth, tree[2])) if tree[0] == "lut" else 0


def cone_equivalence(old_cells, new_cells):
    old_tree, old_leaves = cone_expression(old_cells)
    new_tree, new_leaves = cone_expression(new_cells)
    require(old_leaves == new_leaves and len(old_leaves) == 11, "eleven external cone inputs changed")
    tokens = sorted(old_leaves)
    for bits in itertools.product((0, 1), repeat=11):
        values = dict(zip(tokens, bits))
        require(evaluate(old_tree, values) == evaluate(new_tree, values), f"cone truth table changed: {bits}")
    return {"equivalent": True, "assignments_checked": 2048, "external_inputs": tokens,
            "control_lut_depth": depth(old_tree), "candidate_lut_depth": depth(new_tree)}


def comparison(folder):
    record, candidate, new_cells, new_log, candidate_route = route_evidence(folder)
    old_record, control, old_cells, old_log, control_route = route_evidence(CONTROL)
    base_record, baseline, _, base_log, baseline_route = route_evidence(BASE)
    require(record["build_id"] == old_record["build_id"] == base_record["build_id"], "BUILD_ID changed")
    inputs = authenticate_inputs(record)
    control_inputs = authenticate_inputs(old_record)
    baseline_binary = RAW.parent / "validated-nextpnr-mistral"
    baseline_inputs = authenticate_inputs(base_record, baseline_binary)
    # The candidate additionally authenticates the frozen report and source archive.
    functional_inputs = {p: h for p, h in old_record["input_sha256"].items() if Path(p).name != "nextpnr-mistral"}
    for name, expected in functional_inputs.items():
        require(record["input_sha256"].get(name) == expected == base_record["input_sha256"].get(name),
                f"synthesis/constraint input changed across controls: {name}")
    capture_report = BASE / "timing.json"
    require(record["capture_report_sha256"] == old_record["capture_report_sha256"] == sha(capture_report),
            "capture-locality report changed")
    require(record["experimental_capture_locality"] == old_record["experimental_capture_locality"],
            "capture-locality diagnostic options changed")
    require(record["experimental_placed_reduction"] == ROOT_CELL + " 6 0", "placed-reduction diagnostic options changed")
    require(record["input_sha256"].get(str(capture_report)) == sha(capture_report),
            "capture-locality report missing from authenticated input manifest")
    archive = RAW / "source.tar.gz"
    require(record["input_sha256"].get(str(archive)) == sha(archive) == record["source_archive_sha256"],
            "candidate source archive missing from authenticated input manifest")
    source = source_identity(RAW, record)
    control_source = source_identity(CONTROL.parent, old_record)
    baseline_source = verify_archive(RAW.parent / "nextpnr-slots-fixed-source.tar.gz",
                                     read(RAW.parent / "slot-fixed-source-hashes.json"))
    new_metrics = PLACEMENT_METRICS.findall(new_log)
    old_metrics = PLACEMENT_METRICS.findall(old_log)
    base_metrics = PLACEMENT_METRICS.findall(base_log)
    require(new_metrics == old_metrics == base_metrics and len(new_metrics) == 71,
            "ordinary HeAP trajectory changed or does not contain 71 metrics")
    placement = compare_cells(old_cells, new_cells)
    equivalence = cone_equivalence(old_cells, new_cells)
    control_clocks = compare_clocks(control, candidate)
    baseline_clocks = compare_clocks(baseline, candidate)
    strict_nonregression = all(c["gain_mhz"] >= 0 for c in baseline_clocks.values())
    clocks_close = all(c["meets_constraint"] for c in control_clocks.values())
    artifacts = [folder / name for name in ("run.json", "route.log", "timing.json", "routed.json", "core.rbf")]
    artifacts += [RAW / "source-identity.json", RAW / "source.tar.gz", RAW / "nextpnr-mistral"]
    artifacts += [ref / name for ref in (CONTROL, BASE) for name in ("run.json", "route.log", "timing.json", "routed.json", "core.rbf")]
    return {
        "status": "experimental, unselected; all-clock nonregression against 108 MHz baseline " +
                  ("passes" if strict_nonregression else "fails"),
        "build_id": record["build_id"], "base_compiler_commit": record["base_compiler_commit"],
        "elapsed_seconds": record["elapsed_seconds"],
        "control_110": {"path": relative(CONTROL), "standing": "experimental capture-locality tradeoff",
                        "route": control_route, "source": control_source, "authenticated_inputs": control_inputs},
        "baseline_108": {"path": relative(BASE), "standing": "accepted compiler control; 130 MHz remains unclosed",
                         "route": baseline_route, "source": baseline_source, "authenticated_inputs": baseline_inputs},
        "candidate_route": candidate_route, "source": source, "authenticated_inputs": inputs,
        "fmax_vs_control_110": control_clocks, "fmax_vs_baseline_108": baseline_clocks,
        "control_110_vs_baseline_108": compare_clocks(baseline, control),
        "passes_all_clock_nonregression_vs_110": all(c["gain_mhz"] >= 0 for c in control_clocks.values()),
        "passes_all_clock_nonregression_vs_108": strict_nonregression,
        "memory_improved_vs_110": control_clocks[MEMORY_CLOCK]["gain_mhz"] > 0,
        "nonmemory_required_clocks_close": all(c["meets_constraint"] for k, c in control_clocks.items() if k != MEMORY_CLOCK),
        "passes_all_clock_constraints": clocks_close,
        "passes_strict_diagnostic_gate_vs_108": strict_nonregression and
            baseline_clocks[MEMORY_CLOCK]["gain_mhz"] > 0 and not candidate_route["final_reported_hold_violations"],
        "placement_metrics_identical": True, "matched_placement_metrics": len(new_metrics),
        "placement_metrics_sha256": hashlib.sha256("\n".join(new_metrics).encode()).hexdigest(),
        "bel_reference": relative(CONTROL), **placement, "cone_equivalence": equivalence,
        "placed_reduction_log": [line for line in new_log.splitlines() if "Placed reduction" in line],
        "critical_memory_path": next(p for p in candidate["critical_paths"]
                                     if p["from"] == p["to"] == "posedge " + MEMORY_CLOCK),
        "artifact_sha256": {relative(p): sha(p) for p in artifacts},
        "default_recipe_selected": False, "hardware_tested": False,
        "caveats": ["The 110 MHz control is experimental and failed all-clock nonregression against the 108 MHz baseline.",
                    "Hold evidence checks final nextpnr warnings; this is not package signoff or hardware acceptance.",
                    "Transparent route buffers may differ because the rewritten LUT inputs use different routes."],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", nargs="?", default="route-local-r6-s0", help="candidate directory within placed-reduction")
    args = parser.parse_args()
    folder = RAW / args.route
    result = comparison(folder)
    output = folder / "comparison.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    exclude = {"critical_memory_path", "artifact_sha256", "authenticated_inputs", "control_110", "baseline_108",
               "changed_common_bels", "changed_common_bels_by_kind", "added_cells", "removed_cells", "cube_luts"}
    print(json.dumps({k: v for k, v in result.items() if k not in exclude}, indent=2))


if __name__ == "__main__":
    main()
