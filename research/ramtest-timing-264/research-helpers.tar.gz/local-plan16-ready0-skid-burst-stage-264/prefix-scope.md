# Strict initial eleventh-stage native prefix

ROOT alone activates this exclusive comparator after whole-byte/hash/AST and
independent peer review. Explicit self/scope, recorder225eb1b7/scopeb28ea15a,
prepared profile616f85a4, actual closed eleventh run, guidee2dde3c9 and
derivation95c6b895 SHA arguments are required. Actual prepared plan44ac866c is
bound. The run remains fail-closed until ROOT supplies its completed record;
no future Q/BEL/site or unknown hash is guessed. Output is the NEW exclusive
baseline/comparison-prefix.json, never a replacement earlier proof.

Structural before is tenth predicted run3d69a28a/profile77fd5636/plan00bf9b8c
and positive named-private-owner prefixbf9d312c. Its earlier owner alignment is
closed provenance, never replayed or applied to this new comparison. Current
tenth routed V2cd8ad7ff/run1a6d4f7b/profileea033985 is native/physical-positive
construction with rejected timing116.808784MHz. Its original strict rejection
fffb82ee and exact bounded mate-pin proof stay in the flat closure. Accepted
fifth6dcf8c4b/117.77175903320312MHz remains a separate gain reference. Neither
the tenth physical result nor guide's existing truth proves a new copy/site.

Compiler d7e5c61f/baseec0a8d0c, ELF41c2afe1/archive4fbebd5e/host0f3c11a5 and
exact fresh-eight control1cff85d6 remain bound. Complete actual profile/record
input union, outputs, current runtime, original source/host dependency and
closed previous proof/guide/full-reference flat maps are authenticated and
rehashed on original paths. Pure32fd supplies lossless ordered paired-PLL/native
JSON and Audit;72131/8601 supply native tables/current topology;0a522 supplies
only scalar/lut/lab definitions. The new recorder supplies only pure command,
local parser and current host checks. No old compare/prove, generator,
authenticator, prepare/run/main, evaluator or source query is invoked.

Literal first ten descriptors and every fresh complete trial dictionary remain
exact, including prior rejected probes. Only index10 is appended: actual guide,
candidate0/group1/pinsfalse/fixedFF. Eleven stages stay within cap16. Closed
execution has the same compiler/runtime/diagnostics and options as the tenth
invocation except the plan selector and fresh write/report paths. All71 original
placement metrics must be exact; no driver/GPU/RBF/signoff belongs to this phase.

Initial graph policy is strict:14907→14908 cells and16645→16646 nets. Only the
new port0 outerALUT3_B$local_remap$3 ALUT4 and its sole private Q alias are added.
Every original alias/raw bit, module field/settings/public port, cell/net owner
order, paired PLL record, cell table/parameter/attribute/BEL/pin snapshot and
native port order remains exact except FF1.ENA at LAB35.27. If earlier generated
private output IDs change, the initial proof saves that exact rejection; it
performs no private-frame alignment, blanket offset or buffer collapse.

All ten retained owner records, literal Qs, unique drivers and complete disjoint
cohorts21/2/10/1/6/1/1/3/2/8 remain exact. Actual rootQ105902 users168→167 and
the new Q has exactly FF1.ENA, the complete original-root LAB35.27 cohort on
CLK3549. Other FF controls, clock connections and placements are unchanged.
Actual chosen Q/BEL comes only from the completed model/export. Complete native
driver and reverse-user tables may differ only by this new Q, one declared ENA
redirect and four distinct additional source-load slots.

InnerALUT2 mask0xb/Q97446 and outerALUT3 mask0x32 use actual four distinct leaves
[98306,98311,5029,103525], each with one unchanged ordinary driver. All16 new
conditional plain-SIG rows independently compare the original two-LUT function,
the three retained port0 ALUT4 mask0x4440 copies and the new ALUT4 table0x4440.
This is a logical native boundary proof with explicit pin-state assumptions,
not physical truth or a new timing result.

Only the NEW owner's template comparison may differ in BEL/Q/site-specific
FES_PINMAP metadata. If exported, its snapshot must be complete strict hex/JSON,
count5/exactABCDQ, plain SIG with COMBOUT Q and four distinct input wires from
the actual COMB/MCOMB half. Membership alone proves neither shared A/B allocation
nor actual physical function. Missing snapshot is explicitly unproved. Every
original available pin attribute stays exact; none is discarded or normalized.

All8221 original FF BELs and complete predeclared FF neighborhoods must match.
The actual new copy's site adds its whole original FF neighborhood with before/
after records and any available pin snapshots. Current complete15290 paths,
seven actual pairs/cap16384, native topology and endpoint/window coverage are
checked against the tenth predicted report even when graph inspection rejects.
Predicted Fmax/report equality is diagnostic; timing equality is not required.
Structural/topology exceptions are explicit immutable records, and all bound
input/output/runtime paths are rehashed before publication on those failures.
Hidden pin/LAB caches, GPU IDs, independent numerical STA, routed physical gain,
decoded RBF and hardware are unproved. Fresh full routed acceptance is separate.
