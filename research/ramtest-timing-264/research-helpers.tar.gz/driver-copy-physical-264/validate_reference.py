"""Root-only actual reference snapshot validation of the new pure evaluator."""
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
PINS = {
    HERE / "physical_lut.py": "0f5249524010cd3adac4949ca283e70fbfdd6a624404b841858bef6d2a463176",
    HERE / "scope.md": "73050669a06db73e71e220709d6b624c77046394aa0867afd58114727db365ec",
    RAW / "narrow-integrated-264/compare_route.py": "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379",
    RAW / "narrow-integrated-264/route-reproduction/routed.json": "0ecb9e44978dae407841680836d7881ef3cc3ce084a28ce3253a4431bec4e05b",
    RAW / "narrow-integrated-264/route-reproduction/comparison.json": "01886d65d6e55f1f1c1d5345e00e3dee5358ce672b0f4a3bac3135f6ec155d4e",
}

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def check():
    for path, expected in PINS.items():
        if sha(path) != expected:
            raise ValueError("reference/evaluator changed: " + str(path))

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

def main():
    output = HERE / "reference-validation.json"
    if output.exists():
        raise ValueError("reference validation output already exists")
    check()
    native = module("copy_reference_native_parser", RAW / "narrow-integrated-264/compare_route.py")
    physical = module("copy_reference_physical", HERE / "physical_lut.py")
    document = native.read_netlist(RAW / "narrow-integrated-264/route-reproduction/routed.json")
    view = physical.PhysicalView(document["modules"]["top"])
    keys = [(28, 24, 0), (33, 28, 4), (33, 28, 5), (33, 31, 0)]
    records = [physical.evaluate_alm(view, key) for key in keys]
    source = physical.evaluate_lut(view, "ddr0_test.burst_MISTRAL_ALUT3_Q")
    if source["lut"]["type"] != "MISTRAL_ALUT3" or len(source["lut"]["effective_native_truth"]["rows"]) != 8:
        raise ValueError("actual reference source is not the expected eight-row decoder")
    check()
    result = {
        "schema": 1,
        "actual_reference_snapshot_validation_passed": True,
        "validator_sha256": sha(__file__),
        "input_sha256": {str(path): value for path, value in PINS.items()},
        "reference_cell_count": len(view.cells),
        "reference_alm_evidence": records,
        "reference_source_evidence": source,
        "copy_or_new_route_equivalence_proved": False,
        "whole_reference_closure_reexecuted_or_reauthenticated": False,
        "routed_timing_gain_or_hardware_acceptance_proved": False,
        "cram_rbf_or_route_pips_independently_decoded": False,
    }
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"actual_reference_snapshot_validation_passed": True,
                      "validation_sha256": sha(output), "evaluated_alm_keys": keys}, indent=2))

if __name__ == "__main__":
    main()
