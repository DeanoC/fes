# Pure final-snapshot LUT and carry evaluator

This new module accepts an authenticated, losslessly parsed final routed `top`
module. It reads native connections and `FES_PINMAP_V1` / `FES_LABSTATE_V1`.
It does not read files, execute tools, alter graphs or select a candidate. Its
author has not executed it. Root is the sole validation and routing operator.

`PhysicalView(top)` exposes `native` driver/user/alias/ordered-PLL tables.
Supply the lossless parser from `narrow-integrated-264/compare_route.py`; a
plain JSON parser loses the writer's paired PLL `outclk` occurrences. Driver
tokens remain separate from actual numeric bits. Unknown drivers, duplicate
physical owners, incomplete snapshots and unsupported occupants reject.

`evaluate_alm(view, (x, y, alm))` evaluates all actual combinational occupants
and records every FF in that ALM. `evaluate_lut(view, name)` includes this full
neighbor closure. Ordinary ALUT2..5, BUF/NOT and constant neighbors derive
both occupied 32-row banks. Actual logical signal pins use their exported
physical mapping: A/B address bits 0/1, C or D bit 2, E-half bit 3 and F-half
bit 4. SIG uses complemented physical input; INV uses raw input; constants
bypass addressing. Active-low storage complements the output. Input aliases
retain all logical slots and use one distinct native driver assignment;
physical rows inconsistent with a repeated native driver are unreachable,
while their mask bits are still derived. Shared physical inputs require an
exact common native driver, including across both occupied halves. Equivalent
source and clone functions cannot replace this physical net identity check.

ALUT6 supports actual input mappings and constants, all 64 dual-bank rows,
the C/D bank-dependent address swap and E/F address positions. Its actual
whole-ALM mode must match the saved field, and no other combinational occupant
may share it. MCOMB in logic mode applies the final 64-bit MLAB permutation;
RAM-mode MISTRAL_MLAB occupants reject. No RAM initialization address reversal
is used. The permutation and addressing rules come from current
`nextpnr-driver-domains-264/mistral/lab.cc` (`get_phys_pin_val`,
`permute_mlab_init`, `compute_lut_mask`), read as the selected model contract.

Arithmetic neighbors evaluate both 16-row LUT0/LUT1 operands and every distinct
native boundary assignment for `{CO, SO} = q0 + !q1 + CI`, following the selected
`intel_alm/common/alm_sim.v` primitive contract. D0 selects the lower bank and
D1 the upper bank; reserved E/F address positions are both bit 3 in arithmetic
mode. Shared D0/D1 nets may use actual A/B pins. Carry CI/CO physical pins and
the exact immediate successor placement/native edge are checked. An inverted
CI, non-arithmetic carry source, carry fanout, top-level carry boundary or
unsupported consumer rejects. Returned wire identities identify the dedicated
resource; actual routed pips are not decoded by this module.

`prove_lut_copy(before, after, source, clone, sink, operand,
expected_original_users=None)` proves strict original source preservation,
source/clone effective truth, original source and sink full-pin preservation,
and one exact native operand redirect. It assumes no ordinal or placement.
For the current predeclared 49-user source, the caller must pass 49: this
includes the selected operand, so the strict result is 48 original consumers
and one private clone-Q consumer. It does not normalize late DATAIN buffers.
The caller must independently close every original load/input-slot/alias and
any separately declared late-buffer ledger using actual snapshots.

`compare_ff_controls(before, after, [(x, y), ...])` compares every FF in the
specified whole LABs, including actual pins, native control connections and
saved clock-enable/clear selectors. Original FF DATAIN connectivity is a
separate caller obligation. Unsupported FF slots reject. Snapshot fields do
not establish the physical data/control mux routes by themselves.

These checks derive masks from exported model state. They do **not** decode
RBF/CRAM bytes, authenticate all routing pips, prove whole placement/routing
legality, recover omitted combInfo/unique-input caches or GPU IDs, recompute
STA, accept a routed timing gain, or establish hardware behavior. The caller
must bind source/artifact/runtime hashes, preserve typed full-module and PLL
records, close all allowed graph/physical changes, and apply the confirmed
clock/window/hold acceptance rule independently.
