"""Pure checks of exported native connections and physical ALM truth snapshots.

No file/tool execution, graph mutation, CRAM decoding or timing acceptance.
The caller supplies a losslessly parsed final routed top module and authenticates
its provenance. Derived masks are predictions from that exported snapshot.
"""
import json
import re

BEL = re.compile(r"MISTRAL_(M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)")
PINS = "ABCDEF"
ARITH_PINS = ("A", "B", "C", "D0", "D1")
MASK64 = (1 << 64) - 1
MLAB_PERMUTE = (
    0, 1, 4, 5, 8, 9, 12, 13, 29, 28, 25, 24, 21, 20, 17, 16,
    2, 3, 6, 7, 10, 11, 14, 15, 31, 30, 27, 26, 23, 22, 19, 18,
    32, 33, 36, 37, 40, 41, 44, 45, 61, 60, 57, 56, 53, 52, 49, 48,
    34, 35, 38, 39, 42, 43, 46, 47, 63, 62, 59, 58, 55, 54, 51, 50,
)


def require(condition, message):
    if not condition:
        raise ValueError("physical LUT proof: " + message)


def _unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate physical snapshot key")
        result[key] = value
    return result


def _decode(value):
    require(type(value) is str, "missing hex physical snapshot")
    try:
        return json.loads(bytes.fromhex(value).decode(), object_pairs_hook=_unique,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    except (UnicodeError, ValueError) as error:
        raise ValueError("physical LUT proof: malformed physical snapshot") from error


def _location(cell):
    match = BEL.fullmatch(cell.get("attributes", {}).get("NEXTPNR_BEL", ""))
    require(match is not None, "unsupported or missing ALM BEL")
    kind, x, y, z = match.groups()
    x, y, z = int(x), int(y), int(z)
    require(0 <= z < 60 and (z % 6 >= 2 if kind == "FF" else z % 6 < 2), "invalid ALM slot")
    return kind, x, y, z


def _lab_rows(top):
    value = _decode(top.get("attributes", {}).get("FES_LABSTATE_V1"))
    require(type(value) is dict and set(value) == {"device", "labs"} and type(value["device"]) is str
            and type(value["labs"]) is list, "invalid LAB snapshot schema")
    rows = {}
    for row in value["labs"]:
        require(type(row) is list and len(row) == 4 and all(type(v) is int for v in row[:3])
                and row[0] >= 0 and row[1] >= 0 and row[2] in (0, 1)
                and type(row[3]) is list and len(row[3]) == 62, "invalid LAB row")
        for index, field in enumerate(row[3]):
            maximum = 2 if index >= 2 and (index - 2) % 6 in (2, 3) else 1
            require(type(field) is int and 0 <= field <= maximum, "invalid LAB state field")
        key = tuple(row[:2])
        require(key not in rows, "duplicate physical LAB")
        rows[key] = row
    return value["device"], rows


class Native:
    """Native driver/user identities; do not reinterpret buffers or aliases."""
    def __init__(self, top):
        self.top, self.cells = top, top["cells"]
        self.drivers, self.users, self.aliases, self.top_users, self.entries = {}, {}, {}, {}, {}
        require(hasattr(self.cells, "pll_ports") and type(self.cells.pll_ports) is dict,
                "native module was not parsed with lossless PLL records")
        self.pll_ports = self.cells.pll_ports
        require(set(self.pll_ports) <= set(self.cells), "PLL records reference absent cells")
        for name, cell in self.cells.items():
            require(type(name) is str and type(cell) is dict and
                    set(cell["connections"]) == set(cell["port_directions"]), "invalid native cell ports")
            fields = self.pll_ports.get(name)
            if fields:
                require(cell["type"] == "altera_pll" and set(fields) == {"port_directions", "connections"}
                        and [p for p, _ in fields["port_directions"]] == [p for p, _ in fields["connections"]],
                        "invalid lossless PLL records")
                occurrence, entries = {}, []
                for (port, direction), (_, bits) in zip(fields["port_directions"], fields["connections"]):
                    index = occurrence.get(port, 0)
                    occurrence[port] = index + 1
                    require(port == "outclk" or index == 0, "unsupported duplicate native port")
                    require(port != "outclk" or direction == "output" and len(bits) == 1,
                            "invalid duplicate PLL output")
                    entries.append((port, direction, bits, index if port == "outclk" else 0))
                outputs = [bits for port, direction, bits, _ in entries if port == "outclk"]
                clocks = cell["parameters"].get("number_of_clocks")
                require(len(outputs) == 2 and outputs[0] != outputs[1] and
                        type(clocks) is str and set(clocks) <= {"0", "1"} and int(clocks, 2) == 2,
                        "lossless paired PLL output count/identity differs")
            else:
                entries = [(port, direction, cell["connections"][port], 0)
                           for port, direction in cell["port_directions"].items()]
            self.entries[name] = entries
            for port, direction, bits, occurrence in entries:
                require(direction in {"input", "output", "inout"} and type(bits) is list, "invalid native port")
                for index, bit in enumerate(bits):
                    require(type(bit) is int and bit >= 0 or type(bit) is str and bit in {"0", "1", "x", "z"},
                            "invalid native bit")
                    slot = occurrence if fields and port == "outclk" else index
                    if direction == "output":
                        require(type(bit) is int and bit not in self.drivers, "ambiguous native output driver")
                        self.drivers[bit] = ("cell", name, port, slot)
        for name, port in top.get("ports", {}).items():
            require(port["direction"] in {"input", "output", "inout"} and type(port["bits"]) is list,
                    "invalid top port")
            for index, bit in enumerate(port["bits"]):
                if port["direction"] == "input":
                    require(type(bit) is int and bit >= 0 and bit not in self.drivers, "ambiguous top input")
                    self.drivers[bit] = ("top", name, "input", index)
                else:
                    self.top_users.setdefault(bit, []).append((name, index, port["direction"]))
        self.connections = {}
        for name, entries in self.entries.items():
            converted = {}
            for port, direction, bits, occurrence in entries:
                converted[(port, occurrence) if name in self.pll_ports else port] = [self.token(bit) for bit in bits]
                if direction in {"input", "inout"}:
                    for index, bit in enumerate(bits):
                        self.users.setdefault(self.token(bit), []).append((name, port, index))
            self.connections[name] = converted
        for users in self.users.values():
            users.sort()
        for name, net in top.get("netnames", {}).items():
            require(type(net) is dict and type(net.get("bits")) is list, "invalid native named net")
            for index, bit in enumerate(net["bits"]):
                self.aliases.setdefault(bit, []).append((name, index))

    def token(self, bit):
        return ("constant", bit) if type(bit) is str else self.drivers.get(bit, ("undriven", bit))


class PhysicalView:
    def __init__(self, top):
        self.native = Native(top)
        self.top, self.cells = top, top["cells"]
        self.device, self.labs = _lab_rows(top)
        self.occupants = {}
        physical = set()
        for name, cell in self.cells.items():
            bel = cell.get("attributes", {}).get("NEXTPNR_BEL", "")
            if not BEL.fullmatch(bel):
                continue
            kind, x, y, z = _location(cell)
            require((x, y) in self.labs and (kind == "FF" or (kind == "MCOMB") == bool(self.labs[(x, y)][2])),
                    "BEL kind disagrees with actual LAB geometry")
            require((x, y, z) not in physical, "multiple owners of one physical COMB/MCOMB/FF slot")
            physical.add((x, y, z))
            self.occupants.setdefault((x, y, z // 6), []).append((name, kind, z % 6))

    def pins(self, name):
        value = _decode(self.cells[name].get("attributes", {}).get("FES_PINMAP_V1"))
        require(type(value) is dict and set(value) == {"count", "pins"} and type(value["count"]) is int
                and type(value["pins"]) is dict and value["count"] == len(value["pins"]), "invalid pin snapshot")
        for logical, pin in value["pins"].items():
            require(type(logical) is str and type(pin) is list and len(pin) >= 1 and type(pin[0]) is int
                    and 0 <= pin[0] <= 3 and all(type(p) is str for p in pin[1:]), "invalid physical pin entry")
        return value["pins"]

    def scalar(self, name, port, direction, connected=True):
        cell = self.cells[name]
        require(cell["port_directions"].get(port) == direction, "incorrect scalar port direction")
        bits = cell["connections"].get(port)
        require(type(bits) is list and (len(bits) == 1 if connected else len(bits) <= 1)
                and all(type(bit) is int and bit >= 0 for bit in bits), "invalid scalar native signal port")
        if not bits:
            return None
        token = self.native.token(bits[0])
        require(token[0] not in {"constant", "undriven"}, "unresolved native scalar driver")
        return token


def _table(value, width):
    require(type(value) is str and len(value) == 1 << width and set(value) <= {"0", "1"},
            "LUT table is not fully defined at its actual width")
    return int(value, 2)


def _input(view, name, logical, pins, allowed):
    cell, pin = view.cells[name], pins[logical]
    require(cell["port_directions"].get(logical) == "input", "invalid LUT input direction")
    bits = cell["connections"].get(logical)
    if pin[0] in (1, 2):
        require(bits == [], "constant pin still has a native signal connection")
        # Constants bypass physical addressing. Preserve any serialized default
        # physical names; do not pretend they are routed inputs.
        return {"port": logical, "state": pin[0], "constant": pin[0] - 1, "physical": pin[1:]}
    require(len(pin) == 2 and pin[1] in allowed, "unsupported signal pin mapping")
    token = view.scalar(name, logical, "input")
    return {"port": logical, "state": pin[0], "physical": [pin[1]], "driver": token}


def _output(view, name, logical, pins, physical, connected=True):
    require(pins[logical] == [0, physical], "unsupported output polarity or physical mapping")
    return view.scalar(name, logical, "output", connected)


def _shape(view, name):
    cell, pins = view.cells[name], view.pins(name)
    kind, _, _, z = _location(cell)
    require(kind != "FF", "LUT occupies an FF BEL")
    half = z % 6
    allowed = {"A", "B", "D" if half else "C", f"E{half}", f"F{half}"}
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    if match:
        width = int(match[1]); logical = tuple(PINS[:width])
        require(set(cell["parameters"]) == {"LUT"}, "unexpected LUT parameters")
        tables = [_table(cell["parameters"]["LUT"], width)]
        if width == 6:
            allowed = {"A", "B", "C", "D", f"E{half}", f"F{half}"}
        outputs = {"Q": "COMBOUT"}
    elif cell["type"] in {"MISTRAL_BUF", "MISTRAL_NOT"}:
        width, logical = 1, ("A",)
        require(cell["parameters"] == {}, "unexpected BUF/NOT parameters")
        tables = [2 if cell["type"] == "MISTRAL_BUF" else 1]; outputs = {"Q": "COMBOUT"}
    elif cell["type"] == "MISTRAL_CONST":
        width, logical = 0, ()
        value = cell["parameters"].get("LUT")
        require(set(cell["parameters"]) == {"LUT"} and type(value) is str and value and
                set(value) <= {"0", "1"} and int(value, 2) in (0, 1), "invalid constant LUT")
        tables = [int(value, 2)]; outputs = {"Q": "COMBOUT"}
    elif cell["type"] == "MISTRAL_ALUT_ARITH":
        width, logical = 5, ARITH_PINS
        require(set(cell["parameters"]) == {"LUT0", "LUT1"}, "unexpected arithmetic parameters")
        tables = [_table(cell["parameters"]["LUT0"], 4), _table(cell["parameters"]["LUT1"], 4)]
        outputs = {"SO": "COMBOUT", "CO": "CO"}
    else:
        require(False, "unsupported combinational occupancy: " + cell["type"])
    directions = {**{p: "input" for p in logical}, **{p: "output" for p in outputs}}
    arithmetic = cell["type"] == "MISTRAL_ALUT_ARITH"
    if arithmetic:
        directions["CI"] = "input"
    require(cell["port_directions"] == directions and set(cell["connections"]) == set(directions)
            and set(pins) == set(directions), "unsupported full LUT port/pin schema")
    inputs = []
    for pin in logical:
        permitted = allowed
        if arithmetic:
            permitted = {"A", "B", f"E{half}"} if pin == "D0" else (
                {"A", "B", f"F{half}"} if pin == "D1" else {"A", "B", "D" if half else "C"})
        inputs.append(_input(view, name, pin, pins, permitted))
    result = {"name": name, "type": cell["type"], "width": width, "half": half, "arithmetic": arithmetic,
              "tables": tables, "inputs": inputs, "pins": pins,
              "outputs": {p: _output(view, name, p, pins, physical, not arithmetic)
                          for p, physical in outputs.items()}}
    if arithmetic:
        require(pins["CI"][0] != 3, "inverted dedicated carry input is unsupported")
        result["carry_input"] = _input(view, name, "CI", pins, {"CI"})
    return result


def _value(input_record, assignment):
    if "constant" in input_record:
        return input_record["constant"]
    return assignment[input_record["driver"]] ^ int(input_record["state"] == 3)


def _truth(shape):
    inputs = shape["inputs"] + ([shape["carry_input"]] if shape["arithmetic"] else [])
    boundary = sorted({entry["driver"] for entry in inputs if "driver" in entry})
    rows = []
    for row in range(1 << len(boundary)):
        assignment = {token: (row >> index) & 1 for index, token in enumerate(boundary)}
        values = [_value(entry, assignment) for entry in shape["inputs"]]
        if shape["arithmetic"]:
            base = values[0] | values[1] << 1 | values[2] << 2
            q0 = (shape["tables"][0] >> (base | values[3] << 3)) & 1
            q1 = (shape["tables"][1] >> (base | values[4] << 3)) & 1
            addition = q0 + (1 ^ q1) + _value(shape["carry_input"], assignment)
            rows.append({"row": row, "q0": q0, "q1": q1, "SO": addition & 1, "CO": addition >> 1})
        else:
            address = sum(value << index for index, value in enumerate(values))
            rows.append({"row": row, "Q": (shape["tables"][0] >> address) & 1})
    return {"boundary": [list(token) for token in boundary], "rows": rows,
            "distinct_native_input_rows_checked": len(rows), "repeated_input_slots_preserved": True}


def _raw(pin, row, l6, arithmetic):
    bit = {"A": 0, "B": 1, "C": 3 if l6 and row >= 32 else 2,
           "D": 3 if l6 and row < 32 else 2,
           "E0": 5 if l6 else 3, "E1": 5 if l6 else 3,
           "F0": 3 if arithmetic else 4, "F1": 3 if arithmetic else 4}[pin]
    return (row >> bit) & 1


def _bank(shape, component=None):
    l6, arithmetic = shape["width"] == 6 and not shape["arithmetic"], shape["arithmetic"]
    inputs = shape["inputs"]
    if arithmetic:
        require(component in (0, 1), "missing arithmetic bank selection")
        inputs = inputs[:3] + [inputs[3 + component]]
    table = shape["tables"][component or 0]
    count = 16 if arithmetic else 64 if l6 else 32
    image, realizable = 0, 0
    for row in range(count):
        address, assignment, consistent = 0, {}, True
        for index, entry in enumerate(inputs):
            if "constant" in entry:
                logical = entry["constant"]
            else:
                raw = _raw(entry["physical"][0], row, l6, arithmetic)
                logical = raw ^ int(entry["state"] != 3)
                token, native_value = entry["driver"], 1 ^ raw
                if token in assignment and assignment[token] != native_value:
                    consistent = False
                assignment[token] = native_value
            address |= logical << index
        output = (table >> address) & 1
        image |= (1 ^ output) << row
        if consistent:
            expected_address = sum(_value(entry, assignment) << index for index, entry in enumerate(inputs))
            require(output == (table >> expected_address) & 1, "physical bank differs from native pin-state truth")
            realizable += 1
    require(realizable > 0, "physical bank has no alias-consistent native assignment")
    return {"physical_rows_derived": count, "alias_consistent_rows_checked": realizable,
            "active_low_mask_hex": hex(image)}


def _carry_wire(cell, output):
    _, x, y, z = _location(cell)
    index = 2 * (z // 6) + z % 6
    suffix = "CO" if output and index == 19 else "CI" if not output and index == 0 else (
        f"CARRY[{index if output else index - 1}]")
    return f"WIRE.{x}.{y}.{suffix}"


def _check_carry_pair(view, source, sink):
    a, b = view.cells[source], view.cells[sink]
    require(a["type"] == b["type"] == "MISTRAL_ALUT_ARITH", "carry edge leaves arithmetic primitives")
    _, ax, ay, az = _location(a); _, bx, by, bz = _location(b)
    ai, bi = 2 * (az // 6) + az % 6, 2 * (bz // 6) + bz % 6
    require((bx, by, bi) == ((ax, ay, ai + 1) if ai < 19 else (ax, ay - 1, 0)),
            "native carry consumer is not the immediate dedicated successor")
    require(view.pins(source).get("CO") == [0, "CO"] and view.pins(sink).get("CI") == [0, "CI"],
            "carry physical pins/polarity differ")
    require(view.scalar(source, "CO", "output") == view.scalar(sink, "CI", "input"), "carry edge native net differs")
    return {"source": [source, "CO", 0], "sink": [sink, "CI", 0],
            "source_wire": _carry_wire(a, True), "sink_wire": _carry_wire(b, False),
            "same_internal_carry_wire": ai < 19, "route_pips_independently_decoded": False}


def _carry(view, shape):
    name, incoming, outgoing = shape["name"], None, []
    ci = shape["carry_input"]
    if "driver" in ci:
        token = ci["driver"]
        require(len(token) == 4 and token[0] == "cell" and token[2:] == ("CO", 0),
                "dedicated carry has an unsupported incoming driver")
        incoming = _check_carry_pair(view, token[1], name)
    co = shape["outputs"]["CO"]
    if co is not None:
        require(not view.native.top_users.get(view.cells[name]["connections"]["CO"][0]),
                "carry output is a top-level boundary")
        users = view.native.users.get(co, [])
        require(len(users) <= 1, "dedicated carry has multiple native consumers")
        for sink, port, index in users:
            require(port == "CI" and index == 0, "carry output has an unsupported consumer")
            outgoing.append(_check_carry_pair(view, name, sink))
    return {"incoming": incoming, "constant_ci": ci.get("constant"), "outgoing": outgoing}


def _ff(view, name, state):
    cell, pins = view.cells[name], view.pins(name)
    kind, _, _, z = _location(cell)
    require(kind == "FF" and cell["type"] == "MISTRAL_FF" and z % 6 in (2, 4),
            "unsupported FF occupancy")
    require(set(pins) == set(cell["connections"]), "incomplete FF pin snapshot")
    half = (z % 6 - 2) // 2
    controls = {}
    for port in ("CLK", "ENA", "ACLR", "SCLR", "SLOAD"):
        require(cell["port_directions"].get(port) == "input", "missing FF control port")
        bits = cell["connections"][port]
        require(type(bits) is list and len(bits) <= 1, "non-scalar FF control")
        token = view.scalar(name, port, "input") if bits else None
        controls[port] = {"pins": pins[port], "bits": bits, "driver": list(token) if token else None}
    require(controls["CLK"]["driver"] is not None and pins["CLK"][0] in (0, 3), "unresolved FF clock")
    require(pins.get("Q") == [0, "Q"], "unsupported FF output pin state")
    view.scalar(name, "Q", "output")
    return {"cell": name, "bel": cell["attributes"]["NEXTPNR_BEL"], "half": half,
            "controls": controls, "actual_pins": pins, "clk_ena_selector": state[2 + half],
            "aclr_selector": state[4 + half], "control_route_muxes_independently_decoded": False}


def evaluate_alm(view, key):
    """Derive all occupied banks and actual neighbor/control/carry snapshots."""
    require(isinstance(view, PhysicalView) and type(key) in (tuple, list) and len(key) == 3 and
            all(type(v) is int and v >= 0 for v in key) and key[2] < 10, "invalid physical ALM key")
    key = tuple(key); x, y, index = key
    require((x, y) in view.labs, "ALM is outside saved LAB geometry")
    lab = view.labs[(x, y)]
    state = lab[3][2 + 6 * index:8 + 6 * index]
    used = view.occupants.get(key, [])
    shapes = [_shape(view, name) for name, kind, _ in used if kind != "FF"]
    six = [shape for shape in shapes if shape["width"] == 6]
    arithmetic = [shape for shape in shapes if shape["arithmetic"]]
    require(state[:2] == [int(bool(six)), int(bool(arithmetic))], "saved ALM modes disagree with native occupants")
    require(not six or len(shapes) == 1, "LUT6 does not own the whole combinational ALM")
    require(not arithmetic or len(arithmetic) == len(shapes), "mixed carry and ordinary LUT halves")
    require(sum(32 if shape["arithmetic"] else 1 << shape["width"] for shape in shapes) <= 64,
            "native LUT storage exceeds one ALM")
    sources, records, image = {}, [], MASK64
    for shape in shapes:
        for entry in shape["inputs"]:
            if "driver" not in entry:
                continue
            pin, token = entry["physical"][0], entry["driver"]
            require(pin not in sources or sources[pin] == token,
                    "one shared physical input has distinct actual native drivers")
            sources[pin] = token
        record = {"cell": shape["name"], "type": shape["type"], "half": shape["half"],
                  "actual_pins": shape["pins"], "inputs": shape["inputs"], "effective_native_truth": _truth(shape)}
        if shape["arithmetic"]:
            banks = [_bank(shape, 0), _bank(shape, 1)]
            half_image = int(banks[0]["active_low_mask_hex"], 16) | int(banks[1]["active_low_mask_hex"], 16) << 16
            record.update({"arithmetic_banks": banks, "carry": _carry(view, shape)})
        else:
            bank = _bank(shape)
            half_image = int(bank["active_low_mask_hex"], 16)
            record["physical_bank"] = bank
        if shape["width"] == 6:
            image = half_image
        else:
            offset = 32 * shape["half"]
            image = (image & ~(((1 << 32) - 1) << offset)) | half_image << offset
        record["derived_active_low_occupied_mask_hex"] = hex(half_image)
        records.append(record)
    permuted = sum(((image >> bit) & 1) << MLAB_PERMUTE[bit] for bit in range(64)) if lab[2] else image
    return {"device": view.device, "alm": list(key), "is_mlab_capable_logic": bool(lab[2]),
            "saved_fields": {"l6_mode": state[0], "carry_mode": state[1], "clk_ena_indices": state[2:4],
                             "aclr_indices": state[4:6], "lab_aclr_used": lab[3][:2]},
            "native_occupants": [{"cell": name, "kind": kind, "slot": slot} for name, kind, slot in sorted(used)],
            "occupied_banks": sorted(records, key=lambda record: record["half"]),
            "physical_input_native_drivers": {pin: list(token) for pin, token in sorted(sources.items())},
            "derived_active_low_64_mask_before_mlab_permutation_hex": hex(image),
            "derived_active_low_64_mask_after_mlab_permutation_hex": hex(permuted),
            "mlab_logic_permutation_applied": bool(lab[2]), "ram_init_address_reversal_used": False,
            "ff_occupants": [_ff(view, name, state) for name, kind, _ in sorted(used) if kind == "FF"],
            "cram_bytes_or_rbf_independently_decoded": False, "complete_placement_or_routing_legality_proved": False,
            "unexported_comb_cache_and_gpu_ids_proved": False, "hardware_tested": False}


def evaluate_lut(view, name):
    """Evaluate a LUT with its entire actual ALM occupancy closure."""
    require(name in view.cells, "requested LUT is absent")
    _, x, y, z = _location(view.cells[name])
    alm = evaluate_alm(view, (x, y, z // 6))
    matches = [row for row in alm["occupied_banks"] if row["cell"] == name]
    require(len(matches) == 1, "requested primitive is not one evaluated combinational occupant")
    return {"lut": matches[0], "alm": alm}


def prove_lut_copy(before, after, source, clone, sink, port, expected_original_users=None):
    """Strict final native one-edge copy proof; no late-buffer normalization.

    A caller composing separately declared late DATAIN buffers must prove that
    graph ledger itself; this function never relaxes native user identities.
    """
    require(clone not in before.cells and source in before.cells and source in after.cells and clone in after.cells,
            "copy source/clone identities differ")
    require(re.fullmatch(r"MISTRAL_ALUT[2-6]", before.cells[source]["type"]) is not None,
            "copy source is not an ordinary ALUT2..6")
    a, b, c = _shape(before, source), _shape(after, source), _shape(after, clone)
    require(before.cells[source] == after.cells[source] and a["pins"] == b["pins"],
            "original source metadata, ports, bits or full pins changed")
    require(a["type"] == c["type"] and a["tables"] == c["tables"] and
            [(entry["state"], entry.get("constant"), entry.get("driver")) for entry in a["inputs"]] ==
            [(entry["state"], entry.get("constant"), entry.get("driver")) for entry in c["inputs"]],
            "clone differs in actual logical input slots/states/constants/native drivers")
    require(_truth(a) == _truth(b) == _truth(c), "effective source/clone truth differs")
    require(sink in before.cells and sink in after.cells and before.cells[sink]["type"] ==
            after.cells[sink]["type"] == "MISTRAL_ALUT_ARITH" and port in ARITH_PINS,
            "selected edge is not an actual arithmetic data operand")
    selected = (sink, port, 0)
    old_token, new_token = a["outputs"]["Q"], c["outputs"]["Q"]
    require(before.scalar(sink, port, "input") == old_token and after.scalar(sink, port, "input") == new_token,
            "selected operand does not match source/clone Q")
    old_users = before.native.users.get(old_token, [])
    require(selected in old_users and (expected_original_users is None or len(old_users) == expected_original_users),
            "original source-Q consumer manifest differs")
    require(after.native.users.get(old_token, []) == [user for user in old_users if user != selected]
            and after.native.users.get(new_token, []) == [selected], "copy redirects more than its one original operand")
    require(before.pins(sink) == after.pins(sink), "original arithmetic sink full pins changed")
    return {"source": source, "clone": clone, "selected_operand": list(selected),
            "original_q_users": [list(user) for user in old_users],
            "retained_original_q_users": [list(user) for user in after.native.users.get(old_token, [])],
            "private_clone_q_users": [list(selected)], "original_source_and_sink_full_pins_unchanged": True,
            "effective_native_input_truth": _truth(a),
            "source_before": evaluate_lut(before, source), "source_after": evaluate_lut(after, source),
            "clone_after": evaluate_lut(after, clone), "sink_before": evaluate_lut(before, sink),
            "sink_after": evaluate_lut(after, sink),
            "global_graph_alias_load_and_late_buffer_ledger_proved": False,
            "routed_timing_or_hardware_acceptance_proved": False}


def compare_ff_controls(before, after, labs):
    """Preserve every original FF/control and saved selector in given whole LABs.

    DATAIN connectivity and its independently declared buffer ledger remain
    the caller's responsibility; all full physical FF pins must remain exact.
    """
    keys = {tuple(key) for key in labs}
    require(all(len(key) == 2 and all(type(v) is int and v >= 0 for v in key) for key in keys), "invalid LAB closure")
    snapshots = []
    for view in (before, after):
        selected = {}
        for key, used in view.occupants.items():
            if key[:2] not in keys:
                continue
            state = view.labs[key[:2]][3][2 + 6 * key[2]:8 + 6 * key[2]]
            for name, kind, _ in used:
                if kind == "FF":
                    selected[name] = _ff(view, name, state)
        snapshots.append(selected)
    require(snapshots[0] == snapshots[1], "original FF occupancy, controls, full pins or saved selectors changed")
    return {"whole_labs": [list(key) for key in sorted(keys)], "ff_cells": sorted(snapshots[0]),
            "original_ff_controls_full_pins_and_selectors_exact": True,
            "ff_datain_ledger_and_route_muxes_independently_proved": False}
