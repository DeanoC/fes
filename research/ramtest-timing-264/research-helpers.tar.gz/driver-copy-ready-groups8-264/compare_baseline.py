"""Exact serialized prefix comparison only; changed graphs fail closed."""
import argparse
import json
from pathlib import Path

import freeze

HERE, ROOT, FOLDER = freeze.HERE, freeze.ROOT, freeze.FOLDER
OLD = HERE.parent / "driver-domains-264/baseline"
OLD_PROOF_SHA = "e6cee54cf9227d81766b90ea337aef81ace71a5ea8266a77f3c5105788c7f377"
OLD_ID_SHA = "c0ff5c870267dea40ce12d2d01b7c8d587504ad5897c911778122c387a7b98f5"
OLD_GENERATOR_SHA = "4b018c4b05200309629c5056c4c0c9497cca234f0bb4aa9b6f66e5cbceeee0ff"
FREEZE_SHA = "c4bbb866007da8330e4f947d0931ca3979de2f335aa56883bb755b31fd88d894"
RUN_SHA = "b13e24bbf829169a1ef5a70d5f9e350893e67840b3ebf9cfec38143507d8303e"
PURE = HERE.parent / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SCOPE = HERE / "comparison-scope.md"


def closed_baseline(inputs):
    """Adopt only the immutable flat proof; do not run its generator/authenticator."""
    freeze.bind(inputs, OLD / "comparison.json", OLD_PROOF_SHA)
    proof = freeze.read(OLD / "comparison.json")
    freeze.require(proof["schema"] == 1 and proof["phase"] == "driver-domains-baseline" and
        proof["compiler_commit"] == freeze.COMMIT and proof["delta_base_commit"] == freeze.BASE and
        proof["source_identity_sha256"] == OLD_ID_SHA and proof["generator_sha256"] == OLD_GENERATOR_SHA and
        proof["frozen_native_parser_sha256"] == PURE_SHA and proof["candidate_completed"] is True and
        proof["baseline_native_graph_matches_predecessor"] is True and proof["complete_predicted_report_exact"] is True and
        proof["typed_native_module_bits_consumers_bels_attrs_params_ports_exact"] is True and
        proof["cell_and_net_export_order_exact"] is True and proof["lossless_ordered_pll_occurrences_exact"] is True and
        proof["expanded_paths_current_native_topology_validated"] is True and
        proof["legacy_report_path_count"] == 6 and proof["additional_reported_setup_path_count"] == 15284 and
        proof["timing_report_paths"] == 16384 and proof["matched_ordinary_placement_metrics"] == 71 and
        proof["final_original_path_metadata_and_runtime_hashes_stable"] is True,
        "old same-binary baseline lacks its exact closed serialized/report proof")
    for name, expected in proof["artifact_sha256"].items():
        relative = Path(name)
        freeze.require(not relative.is_absolute() and ".." not in relative.parts, "old artifact escapes ROOT")
        freeze.bind(inputs, ROOT / relative, expected)
    for name, expected in proof["execution_file_sha256"].items():
        freeze.require(Path(name).is_absolute(), "old runtime pathname is not absolute")
        freeze.bind(inputs, name, expected)
    record = freeze.read(OLD / "run.json")
    freeze.require(record["completed"] is True and record["exit_code"] == 0 and
        record["compiler_read_audit_passed"] is True and record["source_identity_sha256"] == OLD_ID_SHA and
        record["binary_sha256"] == freeze.BINARY_SHA and record["source_archive_sha256"] == freeze.ARCHIVE_SHA and
        record["phase"] == "baseline" and record["driver_candidate"] is None and
        record["timing_report_paths"] == 16384 and "failure" not in record and
        all(inputs.get(path) == expected for path, expected in
            {**record["input_sha256"], **record["output_sha256"], **record["execution"]["files"]}.items()),
        "old completed baseline execution is not fully bound to its cached closure")
    for name in ("run.json", "phase.log", "placed.json", "timing.json"):
        freeze.require(str(OLD / name) in inputs, "cached baseline lacks an actual phase artifact")
    return proof, record


def preview(value):
    if type(value) is dict:
        return {"type": "object", "entries": len(value)}
    if type(value) is list:
        return {"type": "array", "entries": len(value)}
    return {"type": type(value).__name__, "value": value[:200] + "..." if type(value) is str and len(value) > 200 else value}


def first_difference(before, after, path="$", canonical=None):
    if type(before) is not type(after):
        return {"path": path, "before": preview(before), "after": preview(after)}
    if isinstance(before, dict):
        for key in before:
            if key not in after:
                return {"path": path + "." + key, "kind": "removed-key"}
            result = first_difference(before[key], after[key], path + "." + key, canonical)
            if result is not None:
                return result
        for key in after:
            if key not in before:
                return {"path": path + "." + key, "kind": "added-key"}
    elif isinstance(before, list):
        if len(before) != len(after):
            return {"path": path, "before": preview(before), "after": preview(after)}
        for index, (old, new) in enumerate(zip(before, after)):
            result = first_difference(old, new, "%s[%d]" % (path, index), canonical)
            if result is not None:
                return result
    elif canonical(before) != canonical(after):
        return {"path": path, "before": preview(before), "after": preview(after)}
    return None


def comparison(identity_sha, generator_sha, scope_sha):
    initial = {}
    freeze.bind(initial, HERE / "freeze.py", FREEZE_SHA)
    freeze.bind(initial, HERE / "run.py", RUN_SHA)
    freeze.bind(initial, Path(__file__).absolute(), generator_sha)
    freeze.bind(initial, SCOPE, scope_sha)
    profile, inputs, context = freeze.authenticate_freeze(identity_sha)
    for path, expected in initial.items():
        freeze.bind(inputs, path, expected)
    cached, old_record = closed_baseline(inputs)
    freeze.bind(inputs, PURE, PURE_SHA)
    native = freeze.load(PURE, "ready_groups_exact_native_parser")
    recorder = freeze.load(HERE / "run.py", "ready_groups_frozen_baseline_recorder")
    record_path = FOLDER / "run.json"
    freeze.bind(inputs, record_path, freeze.sha(record_path))
    record = freeze.read(record_path)
    freeze.authenticate_phase(record, profile, identity_sha, context)
    freeze.require(record["completed"] is True and record["exit_code"] == 0,
        "the current changed-budget baseline has not completed successfully")
    for path, expected in {**record["input_sha256"], **record["output_sha256"], **record["execution"]["files"]}.items():
        freeze.bind(inputs, path, expected)
    log, old_log = (FOLDER / "phase.log").read_text(), (OLD / "phase.log").read_text()
    freeze.require("Info: Program finished normally." in log and
        log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
        not any(line.startswith("ERROR:") for line in log.splitlines()) and
        not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...", "Info: LUT driver copy")) and
        not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")),
        "current baseline lacks its actual no-driver/no-route predicted execution")
    actual_local = recorder.local_qualification(log)
    freeze.require(actual_local == record["actual_selected_local_qualification"],
        "current actual local qualification differs from the completed recorder")
    before, after = native.read_netlist(OLD / "placed.json"), native.read_netlist(FOLDER / "placed.json")
    old_top, new_top = before["modules"]["top"], after["modules"]["top"]
    old_report, report = freeze.read(OLD / "timing.json"), freeze.read(FOLDER / "timing.json")
    freeze.require(recorder.report_summary(report) == record["actual_predicted_report_summary"],
        "current predicted report summary differs from the actual completed recorder")
    includes = recorder.re.findall(r"^Info: Timing report includes (\d+) additional registered setup endpoint paths \(limit (\d+) per domain pair\)\.$", log, recorder.re.M)
    freeze.require(includes == [(str(len(report["critical_paths"]) - 6), "16384")],
        "current actual report count/limit differs from its log")
    freeze.require(len(old_top["cells"]) == cached["cell_count"] and len(old_top["netnames"]) == cached["named_net_count"] and
        len(old_report["critical_paths"]) == 15290, "cached baseline shape differs from its actual files")
    native_equal = native.canonical(old_top) == native.canonical(new_top)
    pll_equal = native.canonical(old_top["cells"].pll_ports) == native.canonical(new_top["cells"].pll_ports)
    order_equal = all(list(old_top[key]) == list(new_top[key]) for key in ("cells", "netnames"))
    report_equal = native.canonical(old_report) == native.canonical(report)
    old_metrics, new_metrics = native.PLACEMENT_METRICS.findall(old_log), native.PLACEMENT_METRICS.findall(log)
    metrics_equal = len(old_metrics) == len(new_metrics) == 71 and old_metrics == new_metrics
    rejections = []
    if not native_equal:
        rejections.append({"reason": "complete-serialized-native-module-changed",
            "first_difference": first_difference(old_top, new_top, canonical=native.canonical)})
    if not pll_equal:
        rejections.append({"reason": "lossless-ordered-PLL-occurrences-changed"})
    if not order_equal:
        rejections.append({"reason": "cell-or-net-export-owner-order-changed"})
    if not report_equal:
        rejections.append({"reason": "complete-predicted-report-changed",
            "first_difference": first_difference(old_report, report, canonical=native.canonical)})
    if not metrics_equal:
        rejections.append({"reason": "ordinary-placement-71-metrics-changed",
            "old_count": len(old_metrics), "new_count": len(new_metrics)})
    proved = not rejections
    freeze.finish(inputs)
    artifacts = {str(Path(path).relative_to(ROOT)): expected for path, expected in inputs.items() if Path(path).is_relative_to(ROOT)}
    execution = {path: expected for path, expected in inputs.items() if not Path(path).is_relative_to(ROOT)}
    execution.update(record["execution"]["files"])
    return {"schema": 1, "phase": "ready-groups8-exact-disabled-driver-prefix",
        "compiler_commit": freeze.COMMIT, "source_identity_sha256": identity_sha,
        "generator_sha256": generator_sha, "comparison_scope_sha256": scope_sha,
        "frozen_baseline_recorder_sha256": RUN_SHA, "frozen_native_parser_sha256": PURE_SHA,
        "cached_same_binary_baseline_proof_sha256": OLD_PROOF_SHA,
        "parent_full_proof_sha256": profile["parent_full_proof_sha256"],
        "authorized_prefix_delta": profile["authorized_prefix_delta"],
        "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "reference_baseline_elapsed_seconds": old_record["elapsed_seconds"],
        "exact_serialized_prefix_proof_available": proved,
        "no_serialized_effect_of_group_budget_change_proved": proved,
        "structural_rejections": rejections,
        "diagnostic_equalities": {"complete_typed_native_module": native_equal,
            "cell_and_net_export_order": order_equal, "lossless_ordered_pll_occurrences": pll_equal,
            "complete_predicted_report": report_equal, "all_71_ordinary_placement_metrics": metrics_equal},
        "creator_metadata": {"old": before["creator"], "new": after["creator"],
            "changed": before["creator"] != after["creator"], "only_top_level_creator_is_excluded_from_module_comparison": True},
        "actual_local_qualification": actual_local,
        "current_predicted_report_summary": record["actual_predicted_report_summary"],
        "cached_report_path_count": 15290,
        "exact_current_report_topology_matches_closed_cached_reference": proved,
        "cached_domain_pair_endpoint_counts": cached["domain_pair_endpoint_counts"],
        "independent_boolean_equivalence_proved": False, "physical_pin_preservation_proved": False,
        "in_memory_cache_or_indexed_store_identity_proved": False, "gpu_net_ids_proved": False,
        "routed_graph_proof_available": False, "passes_practical_timing_gate": None,
        "candidate_accepted_under_confirmed_target_clock_rule": False, "hardware_tested": False,
        "old_comparators_or_authenticators_replayed": False,
        "proof_limitations": [
            "This exact serialized comparison cannot accept or align a changed graph, report, order, PLL record or placement metric; changes require a separately reviewed proof.",
            "The completed current baseline and actual guarded candidate0 applications are bound; hidden pin polarity, physical bank/ALM controls, caches, user-store free lists and GPU IDs are not serialized or independently proved.",
            "When all exact checks pass, current native paths match the already closed cached report by exact graph/report identity, without importing routed delays or independently recomputing numerical STA.",
            "This is predicted no-route timing only; there is no RBF, analogue signoff, final-hold, routed-gain, Boolean, physical or hardware acceptance inheritance."],
        "artifact_sha256": dict(sorted(artifacts.items())), "execution_file_sha256": dict(sorted(execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    parser.add_argument("--compare-py-sha256", required=True)
    parser.add_argument("--scope-md-sha256", required=True)
    args = parser.parse_args()
    output = FOLDER / "comparison.json"
    freeze.require(not output.exists(), "comparison output already exists")
    result = comparison(args.source_identity_sha256, args.compare_py_sha256, args.scope_md_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("phase", "exact_serialized_prefix_proof_available",
        "no_serialized_effect_of_group_budget_change_proved", "structural_rejections", "elapsed_seconds")}, indent=2))


if __name__ == "__main__":
    main()
