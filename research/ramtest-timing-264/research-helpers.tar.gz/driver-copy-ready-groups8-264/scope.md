# Same-guide local group-budget control, fresh driver-disabled baseline

Root alone freezes/runs this new package. Source, prior helper packages and
accepted outputs stay immutable. The actual completed positive current full
proof is passed through `--parent-proof-sha256`; no old proof generator or
authenticator is replayed. The frozen new full recorder authenticates once,
then its actual finalized full proof/runtime flat closure is adopted and all
original paths are rehashed at exit. The current 5dd69a8d binary/archive/config
are copied byte-for-byte; no new source build or host-test acceptance is claimed.

The sole optimization-profile delta is zero-based local step1 `groups:1→8`.
The plan changes budgets8/1/1 to8/8/1. Its three guide paths/bytes, candidates0,
optimize_pins=false and preserve_ff_placement=true remain exact. This control
keeps the old guide and original primary group; it does not silently recenter
on the current worst group or substitute a new report. Existing legacy comb0,
capture/placed11/placed12min200, AC0, fixed synthesis/constraints/seed/GPU1 and
report cap16,384 remain unchanged in their original order and environment.

The initial baseline deliberately omits the driver pass. Its fresh prefix
needs its own actual predicted report before a future driver qualification can
be considered. Relative to the completed parent command, the runner removes
driver-critical/candidate and RBF output, adds one --no-route, and replaces
only local-plan/executable/write/report aliases. Runtime changes only the
copied compiler and PATH alias. Inherited router/device selectors remain
explicit under no-route; the router, analogue signoff and RBF never execute.

The runner binds controlled FunctionalInvocation/audited_run, current runtime
and source/input aliases, compiler accesses, actual exit/failure metadata and
exclusive new log/placed/report files. Every selected local step must actually
log candidate0 with fixed FF shifts, its exact requested group budget in the
plan header, one through that budget actual selected groups, and all model
guards true. Rejected trials may precede the sole candidate0/application;
the recorder preserves their diagnostics and binds candidate0 to its last
preceding trial by cone, site, sink count and gain. The frozen bounds remain
at most eight distinct cone/primary-LAB searches and twelve logged probes per
search. The accepted trial requires at least250ps modeled gain and all guards
true; preceding rejected probes do not inherit qualification. A stale/invalid
later guide or an unqualified selected candidate
fails; no qualification or site is inherited from the old parent.

Predicted Fmax/path summaries and current guard lines are diagnostics only.
This baseline recorder does not independently prove the changed local clone
function/users, original physical pins/BELs, buffer behavior, carry caches,
GPU IDs, routed timing gain, RBF or hardware behavior. Root will inspect and
independently prove the actual changed-prefix snapshot before any future
driver listing/selection or full-route scope is authored. Any future guide
must be the actual fresh baseline report; old routed delays are provenance
only. A successful baseline does not inherit the current accepted117.343 MHz
result or resolve the still-open130 MHz target.
