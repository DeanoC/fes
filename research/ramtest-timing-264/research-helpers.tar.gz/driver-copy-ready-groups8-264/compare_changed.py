"""Explicit22-ENA-slot serialized proof; no routed or physical acceptance."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re

import freeze

HERE, ROOT, FOLDER = freeze.HERE, freeze.ROOT, freeze.FOLDER
OLD = HERE.parent / "driver-domains-264/baseline"
FAST = HERE / "compare_baseline.py"
FAST_SHA = "8c5ce9ad81749000957c44c0529793b3a01768af5473f4878ff6bd34f2e09b04"
FAST_SCOPE_SHA = "631e315d54cb43ed7e700c60f13011f50c94fac3580daaa48ba7500053ff8894"
REJECTION_SHA = "c0d64065cdab310776c70a5857afccaa01bf55eb478b47c44c83ac8f5276c945"
FREEZE_SHA = "c4bbb866007da8330e4f947d0931ca3979de2f335aa56883bb755b31fd88d894"
RUN_SHA = "b13e24bbf829169a1ef5a70d5f9e350893e67840b3ebf9cfec38143507d8303e"
SELECTED_PURE = HERE.parent / "driver-copy-selected-264/compare_selected.py"
SELECTED_PURE_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
SCOPE = HERE / "changed-scope.md"
PINS = "ABCDEF"


def selected_models(log, budgets):
    header = re.compile(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", re.M)
    trial = re.compile(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", re.M)
    candidate = re.compile(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", re.M)
    applied = re.compile(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", re.M)
    headers = list(header.finditer(log))
    freeze.require([tuple(map(int, match.groups())) for match in headers] ==
        [(index, 0, budget, 0, 1) for index, budget in enumerate(budgets)], "local staged headers differ from the declared profile")
    models = []
    for index, match in enumerate(headers):
        block = log[match.end():headers[index + 1].start() if index + 1 < len(headers) else len(log)]
        trials, qualifiers, applications = list(trial.finditer(block)), list(candidate.finditer(block)), list(applied.finditer(block))
        freeze.require(trials and len(qualifiers) == len(applications) == 1 and
            qualifiers[0][1] == applications[0][1] == "0" and trials[-1].end() < qualifiers[0].start() < applications[0].start(),
            "local stage lacks its unique candidate0/application after the final trial")
        row, chosen = trials[-1].groups(), qualifiers[0].groups()[1:]
        freeze.require((row[0], row[1], row[4], row[12], row[7]) == chosen and row[5:7] == ("0", "0") and
            row[8:11] == ("1", "1", "1") and 1 <= int(row[11]) <= budgets[index] and int(row[7]) >= 250,
            "local selected trial lacks exact binding, fixed FFs or complete guards")
        models.append({"index": index, "candidate": 0, "groups_budget": budgets[index], "inner": row[0], "outer": row[1],
            "primary_lab": [int(row[2]), int(row[3])], "bel": row[4], "gain_ps": int(row[7]),
            "selected_groups": int(row[11]), "selected_ena_users": int(row[12]), "ff_shift": [0, 0],
            "clocks": True, "hold": True, "boundaries": True})
    return models


def lab(cell):
    match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
    freeze.require(match is not None, "native cell lacks its actual placed BEL")
    return int(match[1]), int(match[2])


def lut(cell):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    freeze.require(match is not None and set(cell["parameters"]) == {"LUT"}, "conditional composition cell is not an ordinary LUT")
    width, table = int(match[1]), cell["parameters"]["LUT"]
    freeze.require(type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"} and
        set(cell["port_directions"]) == set(PINS[:width] + "Q") and
        cell["port_directions"]["Q"] == "output" and all(cell["port_directions"][pin] == "input" for pin in PINS[:width]) and
        set(cell["connections"]) == set(PINS[:width] + "Q") and
        all(type(bits) is list and len(bits) == 1 and type(bits[0]) is int for bits in cell["connections"].values()) and
        "FES_PINMAP_V1" not in cell["attributes"], "conditional LUT has partial pins, constants, unknown table or invalid ports")
    return width, int(table, 2), [cell["connections"][pin][0] for pin in PINS[:width]], cell["connections"]["Q"][0]


def composition(top, model, clone, drivers):
    cells = top["cells"]
    inner, outer = model["inner"], model["outer"]
    wi, mi, ai, qi = lut(cells[inner])
    wo, mo, ao, qo = lut(cells[outer])
    wc, mc, ac, qc = lut(cells[clone])
    freeze.require((wi, wo, wc, mi, mo, mc, qo, qc) == (2, 3, 4, 0xb, 0x32, 0x4440, 109091, 120710) and
        ao.count(qi) == 1 and qi not in ai and qo not in ai + ao + ac and qc not in ai + ao + ac and
        len(set(ac)) == 4 and set(ac) == set(ai + [bit for bit in ao if bit != qi]),
        "actual unchanged clone is not the declared two-LUT/four-signal composition")
    for bit in ac:
        freeze.require(len(drivers.get(bit, [])) == 1 and cells[drivers[bit][0][0]]["type"] != "MISTRAL_CONST",
            "conditional support has an ambiguous or hidden constant source")
    rows = []
    for assignment in range(16):
        values = {bit: (assignment >> index) & 1 for index, bit in enumerate(ac)}
        inner_row = sum(values[bit] << index for index, bit in enumerate(ai))
        inner_value = (mi >> inner_row) & 1
        outer_row = sum((inner_value if bit == qi else values[bit]) << index for index, bit in enumerate(ao))
        expected, actual = (mo >> outer_row) & 1, (mc >> assignment) & 1
        freeze.require(expected == actual, "conditional two-LUT-to-clone truth differs at row" + str(assignment))
        rows.append({"assignment": assignment, "inner_row": inner_row, "inner_value": inner_value,
            "outer_row": outer_row, "retained_root_value": expected, "clone_value": actual})
    return {"inner": inner, "outer": outer, "clone": clone, "inner_mask_hex": hex(mi), "outer_mask_hex": hex(mo),
        "clone_mask_hex": hex(mc), "clone_actual_input_order": [{"port": PINS[index], "raw_bit": bit,
            "native_driver": list(drivers[bit][0])} for index, bit in enumerate(ac)], "truth_rows": rows,
        "assignments_checked": 16, "true_rows": sum(row["clone_value"] for row in rows),
        "conditional_composition_proved": True, "current_logical_pin_states_serialized": False,
        "pin_assumptions": "All source/clone logical input and Q pins are plain PIN_SIG; this is conditional raw-mask algebra, not a physical pin proof."}


def native_ledger(native, pure, before, after, old_models, models):
    a, b = before["modules"]["top"], after["modules"]["top"]
    freeze.require(list(a["cells"]) == list(b["cells"]) and list(a["netnames"]) == list(b["netnames"]) and
        native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports) and
        native.canonical({key: value for key, value in a.items() if key != "cells"}) ==
        native.canonical({key: value for key, value in b.items() if key != "cells"}),
        "outside cell dictionary, native top/netnames/order/PLL changed")
    freeze.require(not any(cell["type"] == "MISTRAL_BUF" for cell in b["cells"].values()) and
        not b["attributes"].get("FES_LABSTATE_V1"), "pre-route buffer or routed LAB state appeared")
    freeze.require(old_models[0] == models[0] and old_models[2] == models[2] and
        {key: value for key, value in old_models[1].items() if key not in {"groups_budget", "selected_groups", "selected_ena_users"}} ==
        {key: value for key, value in models[1].items() if key not in {"groups_budget", "selected_groups", "selected_ena_users"}} and
        (old_models[1]["groups_budget"], old_models[1]["selected_groups"], old_models[1]["selected_ena_users"],
         models[1]["groups_budget"], models[1]["selected_groups"], models[1]["selected_ena_users"]) == (1, 1, 2, 8, 8, 24),
        "actual downstream or local selected stage changed beyond the declared group/user expansion")
    model = models[1]
    clone = model["outer"] + "$local_remap"
    freeze.require(clone in a["cells"] and a["cells"][clone] == b["cells"][clone] and
        b["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"], "actual existing local clone moved or changed")
    old_drivers, old_users = pure.native_tables(a)
    new_drivers, new_users = pure.native_tables(b)
    freeze.require(old_drivers == new_drivers, "an original native output driver/raw bit changed")
    truth = composition(b, model, clone, new_drivers)
    outer, root_bit, clone_bit = model["outer"], 109091, 120710
    freeze.require(new_drivers[root_bit] == [(outer, "Q", 0, 0)] and new_drivers[clone_bit] == [(clone, "Q", 0, 0)] and
        b["netnames"].get(clone + "$Q", {}).get("bits") == [clone_bit], "actual root/clone Q owner or private alias differs")
    redirects = []
    for name, old in a["cells"].items():
        new = b["cells"][name]
        freeze.require(native.canonical({key: value for key, value in old.items() if key != "connections"}) ==
            native.canonical({key: value for key, value in new.items() if key != "connections"}) and
            list(old["connections"]) == list(new["connections"]), "original cell type/parameters/attrs/BEL/ports changed: " + name)
        for port, bits in old["connections"].items():
            if native.canonical(bits) == native.canonical(new["connections"][port]):
                continue
            freeze.require(old["type"] == "MISTRAL_FF" and port == "ENA" and old["port_directions"][port] == "input" and
                bits == [root_bit] and new["connections"][port] == [clone_bit], "input changed outside one declared ENA slot: " + name + "." + port)
            redirects.append({"cell": name, "port": "ENA", "vector_index": 0, "occurrence": 0,
                "old_raw_bit": root_bit, "new_raw_bit": clone_bit, "old_driver": [outer, "Q", 0, 0],
                "new_driver": [clone, "Q", 0, 0], "bel": old["attributes"]["NEXTPNR_BEL"],
                "preserved_connections_except_ena": {key: value for key, value in old["connections"].items() if key != "ENA"},
                "all_original_parameters_attributes_ports_bel_and_non_ena_slots_exact": True})
    changed_slots = sorted((row["cell"], "ENA", 0, 0) for row in redirects)
    freeze.require(len(redirects) == len(set(changed_slots)) == 22 and
        (len(old_users[root_bit]), len(new_users[root_bit]), len(old_users[clone_bit]), len(new_users[clone_bit])) == (109, 87, 2, 24),
        "the explicit22-slot/root109→87/clone2→24 allowance differs")
    for bit in set(old_users) | set(new_users):
        expected = old_users.get(bit, [])
        if bit == root_bit:
            freeze.require(set(changed_slots) <= set(expected), "redirected slot was not an actual root consumer")
            expected = [slot for slot in expected if slot not in set(changed_slots)]
        elif bit == clone_bit:
            freeze.require(set(changed_slots).isdisjoint(expected), "redirected slot was already a clone consumer")
            expected = sorted(expected + changed_slots)
        freeze.require(expected == new_users.get(bit, []), "unlisted native user/load slot changed at raw bit" + str(bit))
    original_root_users = sorted(old_users[root_bit] + old_users[clone_bit])
    selected_users = new_users[clone_bit]
    groups = {}
    primary = model["primary_lab"]
    old_primary = old_users[clone_bit]
    freeze.require(len(old_primary) == 2 and all(list(lab(a["cells"][slot[0]])) == primary for slot in old_primary),
        "old selected primary clone users do not match the guide LAB")
    primary_clock = a["cells"][old_primary[0][0]]["connections"]["CLK"]
    for name, port, index, occurrence in selected_users:
        cell = b["cells"][name]
        freeze.require(cell["type"] == "MISTRAL_FF" and (port, index, occurrence) == ("ENA", 0, 0) and
            cell["connections"]["CLK"] == primary_clock and (name, port, index, occurrence) in original_root_users,
            "selected clone consumer is not an original compatible FF ENA/CLK slot")
        groups.setdefault(lab(cell), []).append(name)
    freeze.require(len(groups) == model["selected_groups"] == 8, "actual compatible LAB group count differs")
    for location, members in groups.items():
        expected = [slot for slot in original_root_users if lab(a["cells"][slot[0]]) == location]
        freeze.require(sorted((name, "ENA", 0, 0) for name in members) == expected and
            all(a["cells"][slot[0]]["type"] == "MISTRAL_FF" and slot[1:] == ("ENA", 0, 0) and
                a["cells"][slot[0]]["connections"]["CLK"] == primary_clock for slot in expected),
            "a selected LAB is a partial or incompatible original native group")
    loads = [{"raw_bit": row["raw_bit"], "native_driver": row["native_driver"],
        "original_user_count": len(old_users.get(row["raw_bit"], [])), "current_user_count": len(new_users.get(row["raw_bit"], [])),
        "actual_named_load_slots_exact": old_users.get(row["raw_bit"], []) == new_users.get(row["raw_bit"], [])}
        for row in truth["clone_actual_input_order"]]
    freeze.require(all(row["actual_named_load_slots_exact"] for row in loads), "unchanged clone inputs acquired unlisted loads")
    return {"conditional_composition": truth, "declared_ena_redirects": sorted(redirects, key=lambda row: row["cell"]),
        "root": outer, "clone": clone, "root_raw_bit": root_bit, "clone_raw_bit": clone_bit,
        "original_root_users": [list(slot) for slot in old_users[root_bit]],
        "retained_original_root_users": [list(slot) for slot in new_users[root_bit]],
        "old_clone_users": [list(slot) for slot in old_users[clone_bit]], "new_clone_users": [list(slot) for slot in selected_users],
        "whole_selected_lab_groups": [{"lab": list(location), "ffs": sorted(members)} for location, members in sorted(groups.items())],
        "exported_CLK_network": primary_clock, "whole_exported_lab_group_compatibility_proved": True,
        "physical_clock_ena_polarity_and_control_selector_compatibility_independently_proved": False,
        "source_input_load_ledger": loads, "complete_native_driver_table_exact": True,
        "complete_native_user_table_matches_only_declared22_slots": True,
        "all_other_local_comb_capture_placed_ac_cells_nets_and_connections_exact": True,
        "all_original_ff_parameters_attrs_bels_control_and_non_ena_connection_records_exact": True,
        "cell_and_net_export_order_and_lossless_pll_occurrences_exact": True,
        "raw_bit_renaming_buffer_collapse_or_global_normalization_used": False}


def guide_edges(top, report):
    edges = set()
    for path in report["critical_paths"]:
        segments = path["path"]
        if (segments[-1]["type"] != "setup" or segments[-1]["to"]["port"] not in {"ENA", "DATAIN"} or
            sum(segment["delay"] for segment in segments) <= path["max_delay"]):
            continue
        for segment in segments:
            if segment["type"] != "routing":
                continue
            source, sink = segment["from"], segment["to"]
            if (re.fullmatch(r"MISTRAL_ALUT[2-6]", top["cells"][source["cell"]]["type"]) and source["port"] == "Q" and
                top["cells"][sink["cell"]]["type"] == "MISTRAL_ALUT_ARITH" and sink["port"] in {"A", "B", "C", "D0", "D1"}):
                edges.add((source["cell"], sink["cell"], sink["port"]))
    return [list(edge) for edge in sorted(edges)]


def comparison(identity_sha, generator_sha, scope_sha, rejection_sha):
    initial = {}
    for path, expected in ((HERE / "freeze.py", FREEZE_SHA), (HERE / "run.py", RUN_SHA),
        (FAST, FAST_SHA), (HERE / "comparison-scope.md", FAST_SCOPE_SHA), (SELECTED_PURE, SELECTED_PURE_SHA),
        (Path(__file__).absolute(), generator_sha), (SCOPE, scope_sha)):
        freeze.bind(initial, path, expected)
    freeze.require(rejection_sha == REJECTION_SHA, "the immutable actual fast rejection identity differs")
    profile, inputs, context = freeze.authenticate_freeze(identity_sha)
    for path, expected in initial.items():
        freeze.bind(inputs, path, expected)
    freeze.bind(inputs, FOLDER / "comparison.json", rejection_sha)
    rejected = freeze.read(FOLDER / "comparison.json")
    freeze.require(rejected["schema"] == 1 and rejected["phase"] == "ready-groups8-exact-disabled-driver-prefix" and
        rejected["compiler_commit"] == freeze.COMMIT and rejected["source_identity_sha256"] == identity_sha and
        rejected["generator_sha256"] == FAST_SHA and rejected["comparison_scope_sha256"] == FAST_SCOPE_SHA and
        rejected["candidate_completed"] is True and rejected["exact_serialized_prefix_proof_available"] is False and
        rejected["no_serialized_effect_of_group_budget_change_proved"] is False and
        rejected["diagnostic_equalities"] == {"complete_typed_native_module": False, "cell_and_net_export_order": True,
            "lossless_ordered_pll_occurrences": True, "complete_predicted_report": False, "all_71_ordinary_placement_metrics": True} and
        rejected["final_original_path_metadata_and_runtime_hashes_stable"] is True,
        "the immutable actual fast attempt is not its closed expected rejection")
    for name, expected in rejected["artifact_sha256"].items():
        freeze.require(not Path(name).is_absolute() and ".." not in Path(name).parts, "fast artifact escapes ROOT")
        freeze.bind(inputs, ROOT / name, expected)
    for name, expected in rejected["execution_file_sha256"].items():
        freeze.require(Path(name).is_absolute(), "fast runtime pathname is not absolute")
        freeze.bind(inputs, name, expected)
    fast = freeze.load(FAST, "ready_groups_frozen_exact_helpers")
    cached, old_record = fast.closed_baseline(inputs)
    freeze.bind(inputs, fast.PURE, fast.PURE_SHA)
    native = freeze.load(fast.PURE, "ready_groups_changed_native_parser")
    pure = freeze.load(SELECTED_PURE, "ready_groups_selected_pure_graph_report")
    recorder = freeze.load(HERE / "run.py", "ready_groups_changed_frozen_recorder")
    record = freeze.read(FOLDER / "run.json")
    freeze.authenticate_phase(record, profile, identity_sha, context)
    freeze.require(record["completed"] is True and record["exit_code"] == 0 and
        all(inputs.get(path) == expected for path, expected in
            {**record["input_sha256"], **record["output_sha256"], **record["execution"]["files"]}.items()) and
        str(FOLDER / "run.json") in inputs, "current completed phase is not closed by the actual fast attempt")
    log, old_log = (FOLDER / "phase.log").read_text(), (OLD / "phase.log").read_text()
    actual = recorder.local_qualification(log)
    freeze.require(actual == record["actual_selected_local_qualification"] and actual == rejected["actual_local_qualification"],
        "actual current qualification metadata changed after the fast rejection")
    old_models, models = selected_models(old_log, [8, 1, 1]), selected_models(log, [8, 8, 1])
    before, after = native.read_netlist(OLD / "placed.json"), native.read_netlist(FOLDER / "placed.json")
    old_report, report = freeze.read(OLD / "timing.json"), freeze.read(FOLDER / "timing.json")
    freeze.require(recorder.report_summary(report) == record["actual_predicted_report_summary"] and
        len(report["critical_paths"]) == len(old_report["critical_paths"]) == 15290 and
        report["fmax"] == old_report["fmax"] and
        len(native.PLACEMENT_METRICS.findall(log)) == 71 and native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(old_log),
        "current report count/Fmax/constraints or ordinary71 metrics differs")
    graph, timing, rejection = None, None, None
    try:
        graph = native_ledger(native, pure, before, after, old_models, models)
        timing = pure.report_topology(after, report, old_report)
        freeze.require(len(timing["domain_pair_endpoint_counts"]) == 7, "current report lacks all seven actual domain pairs")
    except ValueError as error:
        rejection = str(error)
    proved = rejection is None
    freeze.finish(inputs)
    artifacts = {str(Path(path).relative_to(ROOT)): expected for path, expected in inputs.items() if Path(path).is_relative_to(ROOT)}
    execution = {path: expected for path, expected in inputs.items() if not Path(path).is_relative_to(ROOT)}
    execution.update(record["execution"]["files"])
    return {"schema": 1, "phase": "ready-groups8-explicit-ena-slot-ledger", "compiler_commit": freeze.COMMIT,
        "source_identity_sha256": identity_sha, "generator_sha256": generator_sha, "comparison_scope_sha256": scope_sha,
        "exact_fast_rejection_sha256": rejection_sha, "frozen_exact_helper_sha256": FAST_SHA,
        "frozen_selected_pure_helper_sha256": SELECTED_PURE_SHA, "frozen_native_parser_sha256": fast.PURE_SHA,
        "cached_same_binary_baseline_proof_sha256": fast.OLD_PROOF_SHA,
        "parent_full_proof_sha256": profile["parent_full_proof_sha256"], "candidate_completed": True,
        "current_baseline_run_sha256": inputs[str(FOLDER / "run.json")],
        "current_baseline_report_path": str(FOLDER / "timing.json"),
        "current_baseline_report_sha256": record["output_sha256"][str(FOLDER / "timing.json")],
        "elapsed_seconds": record["elapsed_seconds"], "reference_baseline_elapsed_seconds": old_record["elapsed_seconds"],
        "serialized_native_graph_proof_available": proved, "structural_rejection": rejection,
        "current_native_paths_valid": proved, "explicit_22_slot_conditional_proof": proved,
        "conditional_local_composition_proved": proved, "conditional_equivalence_has_pin_assumptions": True,
        "fresh_driver_guide_available_after_serialized_logical_proof": proved,
        "authorized_prefix_delta": profile["authorized_prefix_delta"], "actual_local_qualification": actual,
        "declared_ena_redirects": graph["declared_ena_redirects"] if graph else None,
        "declared_ena_redirect_count": 22 if proved else None, "whole_selected_lab_group_count": 8 if proved else None,
        "local_model": graph, "current_report_evidence": timing,
        "reported_relevant_lut_to_arithmetic_edges": guide_edges(after["modules"]["top"], report) if proved else None,
        "driver_edge_membership_is_not_fresh_candidate_qualification": True,
        "matched_ordinary_placement_metrics": 71, "full_current_report_path_count": 15290,
        "independent_boolean_equivalence_proved": False, "physical_pin_preservation_proved": False,
        "in_memory_cache_or_indexed_store_identity_proved": False, "gpu_net_ids_proved": False,
        "routed_graph_proof_available": False, "passes_practical_timing_gate": None,
        "candidate_accepted_under_confirmed_target_clock_rule": False, "hardware_tested": False,
        "old_comparison_generators_or_authenticators_replayed": False,
        "proof_limitations": [
            "Only22 named FF.ENA raw slots are allowed to move from the retained root to the existing unchanged clone; all other complete native dictionaries, aliases, bit identities, drivers/users, export order, PLL and register controls stay strict.",
            "The16-row composition is conditional raw-LUT algebra under explicitly unexported plain-signal input/output pin assumptions; physical pin polarity, bank masks, shared inputs and FF control selectors are not independently proved.",
            "All15,290 current setup paths and seven actual pair windows are checked against current native cells/edges/clocks and exact endpoint/window coverage. Delays/skew are current emitted terms, never inherited by old path row or independently recomputed STA.",
            "Fresh local guards are compiled model evidence. Current reported LUT-to-ARITH edge membership is not a driver candidate qualification or an inherited selected site.",
            "This no-route baseline has no RBF, routing, analogue signoff, final hold, routed gain or hardware acceptance. The accepted117.343MHz parent remains a separate immutable measured profile."],
        "artifact_sha256": dict(sorted(artifacts.items())), "execution_file_sha256": dict(sorted(execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    parser.add_argument("--compare-py-sha256", required=True)
    parser.add_argument("--scope-md-sha256", required=True)
    parser.add_argument("--exact-rejection-sha256", required=True)
    args = parser.parse_args()
    output = FOLDER / "comparison-changed.json"
    freeze.require(not output.exists(), "changed comparison output already exists")
    result = comparison(args.source_identity_sha256, args.compare_py_sha256, args.scope_md_sha256, args.exact_rejection_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("phase", "serialized_native_graph_proof_available", "structural_rejection",
        "conditional_local_composition_proved", "fresh_driver_guide_available_after_serialized_logical_proof", "elapsed_seconds")}, indent=2))


if __name__ == "__main__":
    main()
