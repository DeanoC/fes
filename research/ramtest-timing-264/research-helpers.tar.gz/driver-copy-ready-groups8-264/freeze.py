"""Root-only same-binary baseline with one local group-budget delta."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
FULL = HERE.parent / "driver-copy-route-264"
FULL_FOLDER = FULL / "route-c0"
FULL_ID_SHA = "d56a1207bcf255c6e39bcab6bd322ece712f48cefd9ad65280c2fd29d51beee2"
FULL_FREEZE_SHA = "189fb1eff6b184dff01cd0780dfdf5e401371978ebea577f8ffb4b7b0f17aa35"
PARENT = HERE.parent / "driver-copy-route-proof-v2-264"
PARENT_PROOF = PARENT / "comparison.json"
PARENT_GENERATOR_SHA = "7e6257279931ff36008134b7c1a7c60edaecd2f26207aeb414247a37f5286477"
COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"
BASE = "9dc3633aa0c5395df9a81be8437d1a746ba54b5d"
BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
IDENTITY = HERE / "source-identity.json"
FOLDER = HERE / "baseline"
PLAN = HERE / "local-plan.json"
HELPERS = ("freeze.py", "run.py", "scope.md", "local-plan.json")


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(value):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) is not None and len(set(value)) > 1


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key")
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata: " + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(digest(expected), "unset artifact pin: " + path)
    if path in inputs:
        require(inputs[path] == expected, "conflicting input identity: " + path)
    else:
        require(sha(path) == expected, "original artifact path changed: " + path)
        inputs[path] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "original input/output pathname changed during operation: " + path)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def reference(inputs, parent_sha):
    bind(inputs, PARENT_PROOF, parent_sha)
    proof = read(PARENT_PROOF)
    require(proof["schema"] == 1 and proof["phase"] == "explicit-private-buffer-ledger-lut-driver-copy-full" and
            proof["compiler_commit"] == COMMIT and proof["source_identity_sha256"] == FULL_ID_SHA and
            proof["generator_sha256"] == PARENT_GENERATOR_SHA and proof["candidate_completed"] is True and
            proof["graph_proof_available"] is True and proof["structural_rejection"] is None and
            proof["candidate_accepted_under_confirmed_target_clock_rule"] is True and
            proof["passes_practical_timing_gate"] is True and proof["final_original_path_metadata_and_runtime_hashes_stable"] is True,
            "parent is not its completed positive independently proved full route")
    bind(inputs, FULL / "freeze.py", FULL_FREEZE_SHA)
    frozen = load(FULL / "freeze.py", "ready_groups_frozen_full_recorder")
    require(frozen.HERE == FULL and frozen.FOLDER == FULL_FOLDER, "frozen parent API paths differ")
    source, verified, previous = frozen.authenticate_freeze(FULL_ID_SHA)
    for path, expected in verified.items():
        require(path not in inputs or inputs[path] == expected, "parent input identity conflict")
        inputs[path] = expected
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "parent artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "parent runtime pathname is not absolute")
        bind(inputs, name, expected)
    require(inputs.get(str(PARENT / "compare_route.py")) == PARENT_GENERATOR_SHA, "parent closure omits actual generator")
    run = read(FULL_FOLDER / "run.json")
    frozen.authenticate_phase(run, source, FULL_ID_SHA, previous)
    require(run["completed"] is True and run["exit_code"] == 0 and run["compiler_read_audit_passed"] is True and
            source["result_commit"] == COMMIT and source["delta_base_commit"] == BASE and
            source["binary_sha256"] == BINARY_SHA and source["source_archive_sha256"] == ARCHIVE_SHA,
            "actual parent same-binary execution differs")
    require(all(inputs.get(path) == expected for path, expected in
                {**run["input_sha256"], **run["output_sha256"], **run["execution"]["files"]}.items()), "parent execution omitted from flat proof closure")
    require(run["command"].count("--remap-plan") == 1, "parent local plan selector ambiguous")
    original_plan_path = Path(run["command"][run["command"].index("--remap-plan") + 1])
    require(str(original_plan_path) in inputs, "original selected plan absent from parent closure")
    original_plan = read(original_plan_path)
    require(set(original_plan) == {"steps"} and len(original_plan["steps"]) == 3 and
            [step["groups"] for step in original_plan["steps"]] == [8, 1, 1] and all(
            set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and
            step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True and
            inputs.get(step["report"]) == sha(step["report"]) for step in original_plan["steps"]), "original full local profile/guides differ")
    expected_plan = copy.deepcopy(original_plan)
    expected_plan["steps"][1]["groups"] = 8
    require(read(PLAN) == expected_plan, "new local plan changes more than zero-based step1.groups1→8")
    return {"source": source, "run": run, "proof": proof, "parent_sha256": parent_sha,
            "original_plan_path": str(original_plan_path), "original_plan_sha256": inputs[str(original_plan_path)],
            "plan": expected_plan}


def expected_command(ctx):
    command = list(ctx["run"]["command"])
    for option in ("--remap-lut-driver-critical", "--remap-lut-driver-candidate", "--rbf"):
        require(command.count(option) == 1 and command.index(option) + 1 < len(command), "parent output/driver selector ambiguous")
        index = command.index(option)
        del command[index:index + 2]
    require("--no-route" not in command and "--compress-rbf" not in command, "parent routing/compression selector unexpected")
    command.append("--no-route")
    for option, value in (("--write", str(FOLDER / "placed.json")), ("--report", str(FOLDER / "timing.json")), ("--remap-plan", str(PLAN))):
        require(command.count(option) == 1, "baseline output/plan selector ambiguous")
        command[command.index(option) + 1] = value
    command[0] = str(HERE / "nextpnr-mistral")
    require(command.count("--no-route") == 1 and command.count("--timing-report-paths") == 1 and
            command[command.index("--timing-report-paths") + 1] == "16384" and
            command.count("--router") == 1 and command[command.index("--router") + 1] == "gpu" and
            command.count("--gpu-device") == 1 and command[command.index("--gpu-device") + 1] == "1" and
            not any(option in command for option in ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate", "--no-place", "--no-pack")),
            "baseline is not the exact fresh changed-prefix no-driver report invocation")
    return command


def expected_runtime(ctx, profile):
    execution = copy.deepcopy(ctx["run"]["execution"])
    require(execution["files"].pop(ctx["run"]["command"][0]) == BINARY_SHA, "parent runtime compiler differs")
    execution["files"][str(HERE / "nextpnr-mistral")] = profile["binary_sha256"]
    execution["environment"]["PATH"] = str(HERE) + ":/usr/bin:/bin"
    return execution


def record_template(profile, identity_sha, execution, ctx):
    return {"schema": 1, "phase": "baseline", "kind": "predicted fresh prefix with local group budgets8/8/1 and driver disabled",
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "source_identity_sha256": identity_sha,
        "parent_full_source_identity_sha256": FULL_ID_SHA, "parent_full_proof_sha256": ctx["parent_sha256"],
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "timing_report_paths": 16384,
        "local_plan_path": str(PLAN), "local_plan_sha256": profile["helper_sha256"]["local-plan.json"], "local_plan_steps": ctx["plan"]["steps"],
        "helper_sha256": profile["helper_sha256"], "command": expected_command(ctx), "cwd": ctx["run"]["cwd"],
        "diagnostic_environment": ctx["run"]["diagnostic_environment"], "execution": execution,
        "input_sha256": {**profile["input_sha256"], str(IDENTITY): identity_sha},
        "same_compiled_binary_as_parent": True, "driver_pass_executed": False,
        "fresh_driver_guide_available": False, "native_graph_or_physical_equivalence_independently_proved": False,
        "routed_timing_gain_accepted": False, "completed": False, "hardware_tested": False}


def authenticate_phase(run, profile, identity_sha, ctx):
    expected = record_template(profile, identity_sha, run["execution"], ctx)
    mutable = {"completed", "elapsed_seconds", "exit_code", "output_sha256", "compiler_read_audit_passed", "failure",
               "exit_code_is_adapter_sentinel", "actual_selected_local_qualification", "actual_predicted_report_summary", "fresh_driver_guide_available"}
    require({key: value for key, value in run.items() if key not in mutable} ==
            {key: value for key, value in expected.items() if key not in mutable} and
            run["execution"] == expected_runtime(ctx, profile), "actual fresh-prefix command/env/runtime/metadata differs")
    require(type(run["completed"]) is bool and "failure" not in run and "exit_code_is_adapter_sentinel" not in run, "fresh prefix failed/sentinel execution")
    if run["completed"]:
        require(run["exit_code"] == 0 and run["compiler_read_audit_passed"] is True and run["fresh_driver_guide_available"] is True and
                type(run["elapsed_seconds"]) in (int, float) and math.isfinite(run["elapsed_seconds"]) and run["elapsed_seconds"] >= 0 and
                set(run["output_sha256"]) == {str(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json")}, "completed baseline lacks audited actual outputs")


def authenticate_freeze(identity_sha):
    inputs = {}
    bind(inputs, IDENTITY, identity_sha)
    profile = read(IDENTITY)
    require(profile["schema"] == 1 and profile["result_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            profile["parent_full_source_identity_sha256"] == FULL_ID_SHA and digest(profile["parent_full_proof_sha256"]) and
            profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and
            profile["same_compiled_binary_as_parent"] is True and profile["driver_pass_executed"] is False,
            "frozen fresh-prefix identity differs")
    for path, expected in profile["input_sha256"].items():
        require(Path(path).is_absolute(), "input is not an original absolute pathname")
        bind(inputs, path, expected)
    ctx = reference(inputs, profile["parent_full_proof_sha256"])
    require(profile["helper_sha256"] == {name: inputs.get(str(HERE / name)) for name in HELPERS} and
            profile["command"] == expected_command(ctx) and profile["diagnostic_environment"] == ctx["run"]["diagnostic_environment"] and
            profile["local_plan_steps"] == ctx["plan"]["steps"] and profile["original_local_plan_path"] == ctx["original_plan_path"] and
            profile["original_local_plan_sha256"] == ctx["original_plan_sha256"] and
            profile["repositories"] == ctx["source"]["repositories"] and inputs.get(str(HERE / "nextpnr-mistral")) == BINARY_SHA and
            inputs.get(str(HERE / "source.tar.gz")) == ARCHIVE_SHA, "fresh profile copied compiler/plan aliases differ")
    return profile, inputs, ctx


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--parent-proof-sha256", required=True)
    for name in HELPERS:
        parser.add_argument("--" + name.replace(".", "-").replace("_", "-") + "-sha256", required=True)
    args = parser.parse_args()
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "build-config.txt", "source-identity.json", "baseline")), "fresh profile outputs already exist")
    inputs = {}
    for name in HELPERS:
        bind(inputs, HERE / name, getattr(args, name.replace(".", "_").replace("-", "_") + "_sha256"))
    ctx = reference(inputs, args.parent_proof_sha256)
    command = expected_command(ctx)
    finish(inputs)
    for name in ("nextpnr-mistral", "source.tar.gz", "build-config.txt"):
        origin, target = FULL / name, HERE / name
        expected = inputs.get(str(origin))
        require(digest(expected), "parent copied compiler artifact omitted: " + name)
        with target.open("xb") as output, origin.open("rb") as source:
            shutil.copyfileobj(source, output)
        target.chmod(0o555 if name == "nextpnr-mistral" else 0o444)
        bind(inputs, target, expected)
    profile = {"schema": 1, "result_commit": COMMIT, "delta_base_commit": BASE,
        "parent_full_source_identity_sha256": FULL_ID_SHA, "parent_full_proof_sha256": args.parent_proof_sha256,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "repositories": ctx["source"]["repositories"],
        "helper_sha256": {name: inputs[str(HERE / name)] for name in HELPERS}, "command": command,
        "diagnostic_environment": ctx["run"]["diagnostic_environment"], "local_plan_steps": ctx["plan"]["steps"],
        "original_local_plan_path": ctx["original_plan_path"], "original_local_plan_sha256": ctx["original_plan_sha256"],
        "authorized_prefix_delta": {"step_index": 1, "field": "groups", "before": 1, "after": 8},
        "same_compiled_binary_as_parent": True, "driver_pass_executed": False,
        "routed_or_physical_acceptance_inherited": False, "input_sha256": inputs, "hardware_tested": False}
    finish(inputs)
    with IDENTITY.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"source_identity_sha256": sha(IDENTITY), "parent_full_proof_sha256": args.parent_proof_sha256,
                      "group_budgets": [8, 8, 1], "inputs": len(inputs)}, indent=2))


if __name__ == "__main__":
    main()
