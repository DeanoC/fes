"""Root-only changed-prefix predicted baseline; no route or gain acceptance."""
import argparse
import json
import math
import re
import subprocess
import sys
import time

import freeze


def local_qualification(log):
    header = re.compile(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", re.M)
    starts = list(header.finditer(log))
    freeze.require([tuple(int(value) for value in match.groups()) for match in starts] ==
                   [(0, 0, 8, 0, 1), (1, 0, 8, 0, 1), (2, 0, 1, 0, 1)], "actual local profile is not8/8/1 FFfixed/pinsfalse")
    trial = re.compile(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", re.M)
    candidate = re.compile(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", re.M)
    applied = re.compile(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", re.M)
    rows = []
    for index, match in enumerate(starts):
        block = log[match.end():starts[index + 1].start() if index + 1 < len(starts) else len(log)]
        actual = list(trial.finditer(block))
        candidates, applications = list(candidate.finditer(block)), list(applied.finditer(block))
        freeze.require(actual and len(candidates) == len(applications) == 1 and
                       candidates[0].group(1) == applications[0].group(1) == "0" and
                       actual[-1].end() < candidates[0].start() < applications[0].start(),
                       "actual selected local step lacks its sole fresh candidate0/application after its trials")
        budget, cone_counts, diagnostics = (8 if index < 2 else 1), {}, []
        for probe in actual:
            values = probe.groups()
            key = values[:4]
            cone_counts[key] = cone_counts.get(key, 0) + 1
            freeze.require(len(cone_counts) <= 8 and cone_counts[key] <= 12 and
                           values[5:7] == ("0", "0") and all(flag in ("0", "1") for flag in values[8:11]) and
                           1 <= int(values[11]) <= budget and int(values[12]) > 0,
                           "actual local trial exceeds frozen cone/probe/group bounds or fixed-FF policy")
            diagnostics.append({"inner": values[0], "outer": values[1], "primary_lab": [int(values[2]), int(values[3])],
                                "bel": values[4], "ff_shift": [int(values[5]), int(values[6])], "gain_ps": int(values[7]),
                                "clocks": values[8] == "1", "hold": values[9] == "1", "boundaries": values[10] == "1",
                                "selected_groups": int(values[11]), "selected_ena_users": int(values[12])})
        row, chosen = actual[-1].groups(), candidates[0].groups()[1:]
        freeze.require((row[0], row[1], row[4], row[12], row[7]) == chosen and row[5:7] == ("0", "0") and
                       row[8:11] == ("1", "1", "1") and 1 <= int(row[11]) <= (8 if index < 2 else 1) and
                       int(row[12]) > 0 and int(row[7]) >= 250, "fresh local guard/group/FFfixed/candidate binding failed")
        rows.append({"index": index, "candidate": 0, "groups_budget": budget, "selected_groups": int(row[11]),
                     "inner": row[0], "outer": row[1], "primary_lab": [int(row[2]), int(row[3])], "bel": row[4],
                     "ff_shift": [0, 0], "gain_ps": int(row[7]), "clocks": True, "hold": True, "boundaries": True,
                     "actual_trial_count": len(actual), "prior_rejected_trials": diagnostics[:-1],
                     "candidate_bound_to_final_preceding_trial": True,
                     "selected_ena_users": int(row[12]), "guards_are_compiler_reported_not_independent_physical_sta": True})
    return rows


def report_summary(report):
    freeze.require(report.get("timing_report_paths") == 16384 and type(report.get("critical_paths")) is list and report["critical_paths"] and
                   type(report.get("fmax")) is dict and report["fmax"], "fresh predicted expanded report missing")
    for row in report["fmax"].values():
        freeze.require(set(row) == {"achieved", "constraint"} and all(type(value) in (int, float) and math.isfinite(value) and value > 0 for value in row.values()),
                       "fresh predicted Fmax/constraint nonfinite")
    counts = {}
    for path in report["critical_paths"]:
        freeze.require(type(path["max_delay"]) in (int, float) and math.isfinite(path["max_delay"]) and path["max_delay"] > 0 and
                       type(path["path"]) is list and path["path"] and all(type(segment["delay"]) in (int, float) and math.isfinite(segment["delay"])
                       for segment in path["path"]), "fresh predicted path contains missing/nonfinite terms")
        pair = path["from"], path["to"]
        counts[pair] = counts.get(pair, 0) + 1
        freeze.require(counts[pair] <= 16384 and math.isfinite(math.fsum(segment["delay"] for segment in path["path"])), "fresh predicted cap/path sum invalid")
    return {"fmax": report["fmax"], "reported_paths": len(report["critical_paths"]),
            "reported_pair_counts": [{"from": key[0], "to": key[1], "count": value} for key, value in sorted(counts.items())],
            "predicted_only_no_route_or_analogue_signoff": True, "native_topology_or_pin_equivalence_independently_proved": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    profile, inputs, ctx = freeze.authenticate_freeze(args.source_identity_sha256)
    freeze.require(not freeze.FOLDER.exists(), "fresh baseline output directory already exists")
    sys.path.insert(0, str(freeze.MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    tool_identity = (f"base_commit={freeze.BASE}; experimental_source_sha256={profile['source_archive_sha256']}; sha256={profile['binary_sha256']}")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(freeze.HERE / "nextpnr-mistral", tool_identity)}, 1)
    try:
        freeze.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env), "ambient compiler diagnostics forbidden")
        record = freeze.record_template(profile, args.source_identity_sha256, invocation.inputs, ctx)
        freeze.authenticate_phase(record, profile, args.source_identity_sha256, ctx)
        for path, expected in record["execution"]["files"].items():
            freeze.bind(inputs, path, expected)
        freeze.FOLDER.mkdir()
        manifest, started = freeze.FOLDER / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        try:
            with (freeze.FOLDER / "phase.log").open("x") as log:
                result = audited_run(record["command"], source_root=freeze.MODULE, cwd=record["cwd"],
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log, stderr=subprocess.STDOUT,
                    check=False, timeout=3600)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            record["compiler_read_audit_passed"] = True
            invocation.verify()
            freeze.require(result.returncode == 0 and all((freeze.FOLDER / name).is_file() and (freeze.FOLDER / name).stat().st_size > 0
                           for name in ("phase.log", "placed.json", "timing.json")), "changed-prefix baseline did not complete with actual outputs")
            freeze.require(not any((freeze.FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "predicted baseline has routed outputs")
            log = (freeze.FOLDER / "phase.log").read_text()
            freeze.require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                           not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...", "Info: LUT driver copy")) and
                           log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1,
                           "baseline executed driver/router or lacks explicit fresh predicted-report provenance")
            record["actual_selected_local_qualification"] = local_qualification(log)
            report = freeze.read(freeze.FOLDER / "timing.json")
            record["actual_predicted_report_summary"] = report_summary(report)
            includes = re.findall(r"^Info: Timing report includes (\d+) additional registered setup endpoint paths \(limit (\d+) per domain pair\)\.$", log, re.M)
            freeze.require(includes == [(str(len(report["critical_paths"]) - 6), "16384")], "actual fresh report count/limit diagnostic differs")
            record["output_sha256"] = {str(freeze.FOLDER / name): freeze.sha(freeze.FOLDER / name) for name in ("phase.log", "placed.json", "timing.json")}
            record["fresh_driver_guide_available"], record["completed"] = True, True
            freeze.authenticate_phase(record, profile, args.source_identity_sha256, ctx)
            freeze.finish({**inputs, **record["output_sha256"]})
            print(json.dumps({"phase": "baseline", "completed": True, "elapsed_seconds": record["elapsed_seconds"],
                              "actual_selected_local_qualification": record["actual_selected_local_qualification"],
                              "predicted_report_paths": len(report["critical_paths"]), "routed_gain_accepted": False}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
