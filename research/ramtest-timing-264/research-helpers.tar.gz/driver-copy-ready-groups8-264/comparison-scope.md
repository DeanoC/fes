# Exact changed-budget prefix comparison

Root alone executes this new comparator after the baseline is finalized. The
frozen four-file profile, source identity, runner and prior outputs remain
immutable. Comparator and this scope are supplied as explicit SHA256 arguments
and included in the result's flat artifact closure; they do not modify the
already executed profile or run record.

The direct control is the same5dd binary's driver-disabled8/1/1 baseline in
`driver-domains-264/baseline`, authenticated by completed proofe6cee54c. Its
flat artifact/runtime closure is rehashed without running an old comparator
or authenticator. The new frozen profile authenticates once through its
reviewed new full-recorder API. Current source, runtime, exact command and
environment, compiler read audit, actual completed run and three output
hashes are bound. Original pathnames are rehashed at exit.

This implements only the exact path. It compares the complete lossless typed
native module, including raw bit identities and every serialized cell/net,
connection, parameter, attribute, setting, public port, named native consumer,
cell/net export order and paired duplicate PLL record. Only the top-level
creator string is excluded and both actual values are disclosed. The entire
predicted report must compare exactly, including all15,290 paths over the
cached seven domain pairs, windows, finite signed segments, modeled Fmax and
constraints. All71 ordinary placement metrics must compare exactly. Current
8/8/1 headers and fresh selected candidate0 applications are re-parsed with
the frozen runner's actual group/probe bounds and guarded preceding trials.

Any module, PLL, order, report or metric difference produces an authenticated
rejection record with no exact-prefix proof. There is no changed-clone ledger,
algebraic alignment, BUF collapse, bit renumbering, settings normalization or
automatic scope expansion. An exact result establishes only that the larger
budget caused no serialized prefix/report effect; it does not request another
route or inherit qualification for a newly changed graph.

The current pre-route export lacks complete FES_PINMAP_V1 and FES_LABSTATE_V1.
Logical polarity, physical LUT banks/shared pins, ALM/FF control selectors,
carry caches, indexed user-store/free-list identities and GPU IDs remain
unproved. Exact paths reuse an already closed native topology proof only by
complete actual graph/report identity. Numerical STA is not independently
recomputed. Current guards remain compiler-modeled diagnostics. No Boolean,
physical pin, routing, RBF, analogue signoff, final hold, clock-gain or hardware
acceptance is claimed or inherited from the accepted117.343MHz route.
