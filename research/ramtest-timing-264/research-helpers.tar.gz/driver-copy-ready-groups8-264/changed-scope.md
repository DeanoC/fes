# Explicit22-ENA-slot changed-prefix proof

Root alone executes this separately versioned comparator. The frozen profile,
runner, fast comparator/scope and actual fast rejectionc0d64065 stay immutable.
The new helper and this scope are supplied by explicit SHA arguments. Output
is exclusively `baseline/comparison-changed.json`; no profile/run/old proof is
rewritten. Current source/profile/runtime/actual completed outputs, the fast
rejection, old closed e6cee baseline and all original artifact pathnames are
hash-bound. The frozen new profile authenticator runs once; old generators
and old authenticators do not run. Only pinned pure parsing/table/path APIs
and the frozen runner's pure qualification parser are called.

The sole native allowance is exactly22 additional FF.ENA scalar slots moving
from original root Q109091 to unchanged existing clone Q120710. Every row names
the actual cell, port/index/occurrence, raw old/new bit, both named drivers,
fixed BEL and all preserved non-ENA connections. Raw output driver tables
stay exact. Complete input-user tables must equal the old tables minus these
22 root slots plus precisely the same22 clone slots; all other native users
and clone input-load multiplicities stay exact. Root109→87 and clone2→24 users
are checked directly. There is no numeric renaming, buffer collapse, global
normalization or allowed cell/net addition/removal.

The old two primary users and22 additional users form exactly eight complete
LAB groups. All members must be actual original FF.ENA users with the same
exported CLK connection as the primary group; no original root user in a
selected LAB may be omitted or replaced by an incompatible port/type/clock.
All original FF parameters/attributes/BELs and every non-ENA native control,
data and output connection are exact. Physical clock/ENA polarity and control
selectors remain unexported assumptions, not proved control-set state.

The actual local stage1 inner ALUT2 mask0xb and outer ALUT3 mask0x32, unchanged
clone ALUT4 mask0x4440 and actual A..D native signal order compose for all16
assignments. This is conditional raw-mask algebra with plain PIN_SIG inputs
and Q outputs; current FES_PINMAP_V1 is absent. It proves the explicitly stated
conditional function, not independent physical Boolean equivalence. Existing
source/clone masks, ports, placement and input loads remain byte/object exact.
Other local stage choices and all comb/capture/placed11/placed12/AC cells,
public ports, settings, attributes, named nets, owner order and lossless paired
PLL records remain strict. No larger unwind or fresh AC-site alignment exists.

All15,290 current report paths are validated against their actual current
native cells/ports/locations, named edges, launch/capture clock connections,
finite signed segments, endpoint uniqueness and the same seven actual pair
windows. Endpoint coverage, report cap16,384, modeled Fmax/constraints and all71
ordinary placement metrics remain exact. Current skew/delay/path rows may
differ; no old row supplies new numerical timing. Unexported clock phases and
numerical STA are not independently reconstructed. Registered clock handling
uses the tested actual primitives; no DDROUT clock interpretation is invented.

A positive result makes the actual baseline report available as a logical/
native-proved guide for a future freshly qualifying driver invocation. It
supplies reported violated LUT-to-ARITH edge membership only; no driver ordinal,
site or modeled guard is inherited. Any unlisted change fails closed. This
predicted baseline gives no full-pin/physical-bank/cache/GPU-ID, RBF, analogue
signoff, final-hold, routed-gain or hardware acceptance. The immutable accepted
117.343MHz parent is not acceptance for this changed profile.
