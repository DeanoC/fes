# Isolated post-remap-plan host record

ROOT alone activates this recorder after whole-file and independent static
review. Its only subprocesses are read-only Git queries and an in-memory Git
archive. It does not repeat configuration, compilation, tests, old helpers,
authentication, STA, GPU routing or Quartus. Its sole output is exclusive
validation/host-validation.json.

The clean selected source is b3d036549c29a333e67c61bd1b23e705bce75d41, based on
d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f. Exactly nine reviewed arch, driver
prefix, main, local-plan, native/CLI test and local-plan document files changed.
The optional post plan runs after reductions/decomposition and before driver
copying. Early and post descriptors share the existing total cap of sixteen.
The default pipeline, report-edge validation and transformation guards remain
unchanged. Failed earlier experiment records are not host qualification here.

Activation requires actual self/scope, production ELF, committed source
archive, test ELF and check-results SHA arguments. The frozen and built
production bytes must match. All unprefixed source.tar.gz member names, types,
modes, links and file hashes must equal the selected committed Git archive.
Archive member maps use relative member names rather than filesystem paths.

The artifact map binds both ELFs, archive, current cache, successful initial
configure.log, committed configure-final.log, submodules.log, build.log,
native.log, cli.log, check-results.json, both CTest blocks in LastTest.log,
CTest registration, recorder and scope. There was no initial failed configure
or initial failed build to inherit or relabel. Build warnings are disclosed.

Every current .o.d manifest and every original/resolved dependency file is
bound. Main-repository dependencies match the committed archive; required
googletest/tests source dependencies match their selected gitlink commits.
The external Mistral checkout stays clean at model 7ed06e21. Cache evidence
binds its exact path, Release, HIP gfx1100/gfx1201, IPO on and OpenMP off.
Generated/build and system files remain byte evidence; they are not called
committed project source. Dependency closure does not authenticate historical
loaded compiler/test libraries or the complete build toolchain.

check-results.json must name this result commit and actual successful native
and CLI command argv, log paths and elapsed times. CTest must target this build
using either --test-dir or an explicit recorded build cwd. Native invocation
is exactly LocalRemapPlanTest.*:LutDriverCopyTest.*. CTest selects exactly the
remap-plan and LUT-driver-copy CLI scripts with the actual option order
-R FILTER -j2 --output-on-failure. The recorded invocation stays unchanged.
Optional successful build and configure command records are retained with
their bound logs.

Native RUN/OK names, per-suite durations and total PASSED completion must close
every case declared in the two current committed suites. Each verbose LastTest
block must name its current script and production ELF, close every committed
unittest method as ok, and finish with OK and Test Passed. The combined CTest
log must report both scripts passed. Counts derive from current committed
declarations, never from an inherited host record or an assumed future pass.
No XML, extra test rerun or old validator is required.

The four checks are native_plan, driver_backend, remap_plan_cli and driver_cli.
Each records actual case names/counts and elapsed time, with passed=true and
exit_code=0 only after its completed command and logs satisfy the checks.
source_sha256, artifact_sha256 and both build_dependency maps are flat absolute
file maps. The complete source, dependencies and every bound original file are
rechecked before and after publication. No routed/native physical equivalence,
timing improvement, RBF decode, GPU/device state or hardware acceptance is
inherited or claimed. Sixteen successful transformations are not proved.
