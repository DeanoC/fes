"""Actual current-window gate against the accepted fifth full route."""
import hashlib
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
CORE = RAW / "driver-copy-ready-groups8-proof-264/timing.py"
CORE_SHA256 = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
TARGET_MHZ = 117.77175903320312
PARENT_MHZ = {MEMORY: TARGET_MHZ, PIXEL: 93.6504898071289, CAPTURE: 259.49139404296875}
CONSTRAINTS = {MEMORY: 130.0052032470703, PIXEL: 74.25006866455078, CAPTURE: 130.0052032470703}


def require(value, message):
    if not value:
        raise ValueError(message)


def evaluate(core, document, report, parent_report, baseline_report, log, record):
    """Use only pinned pure _load/_paths; never call the historical timing gate."""
    token = "seventh_byteenable_" + str(id(document)) + "_" + str(id(report))
    frozen = core._load(core.FREEZE, core.FREEZE_SHA, token + "_freeze")
    selected = core._load(core.SELECTED, core.SELECTED_SHA, token + "_topology", frozen)
    for path, expected in core.DEPS.values():
        require(hashlib.sha256(path.read_bytes()).hexdigest() == expected, "pinned board dependency changed: " + str(path))
    previous_path = list(sys.path)
    try:
        sys.path.insert(0, str(core.MODULE))
        board = core._load(core.BOARD, core.BOARD_SHA, token + "_board")
    finally:
        sys.path[:] = previous_path
    for name, (path, expected) in core.DEPS.items():
        require(name in sys.modules and Path(sys.modules[name].__file__).resolve() == path.resolve() and
                hashlib.sha256(path.read_bytes()).hexdigest() == expected, "board imported different project dependency: " + name)
    topology = selected.report_topology(document, report, baseline_report)
    windows, endpoints, worst = core._paths(report)
    parent_windows, parent_endpoints, parent_worst = core._paths(parent_report)
    baseline_windows, baseline_endpoints, _ = core._paths(baseline_report)
    require(windows == parent_windows == baseline_windows and endpoints == parent_endpoints == baseline_endpoints,
            "current/accepted-fifth/own-predicted pair, endpoint or window coverage differs")
    require(set(report["fmax"]) == set(parent_report["fmax"]) == set(baseline_report["fmax"]) == set(CONSTRAINTS), "required clock set differs")
    clocks = {}
    for name, constraint in CONSTRAINTS.items():
        row, before, predicted = report["fmax"][name], parent_report["fmax"][name], baseline_report["fmax"][name]
        require(set(row) == set(before) == set(predicted) == {"achieved", "constraint"} and
                row["constraint"] == before["constraint"] == predicted["constraint"] == constraint and
                before["achieved"] == PARENT_MHZ[name] and all(type(value) in (int, float) and math.isfinite(value) and value > 0
                    for value in (row["achieved"], before["achieved"], predicted["achieved"])), "current clock/reference/constraint differs")
        clocks[name] = {"before_mhz": before["achieved"], "after_mhz": row["achieved"], "gain_mhz": row["achieved"] - before["achieved"],
            "constraint_mhz": constraint, "constraint_passed": row["achieved"] >= constraint}
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    require(windows[("posedge " + CAPTURE, "negedge " + MEMORY)] == 5 and
            windows[("negedge " + MEMORY, "posedge " + MEMORY)] == 3.8459999561309814, "actual phase windows differ")
    relations = [{"from": pair[0], "to": pair[1], "window_ns": windows[pair], **worst[pair],
        "before_headroom_ns": parent_worst[pair]["headroom_ns"], "headroom_change_ns": worst[pair]["headroom_ns"] - parent_worst[pair]["headroom_ns"],
        "positive_headroom_required": pair != target, "reported_window_met": worst[pair]["headroom_ns"] > 0,
        "passes_acceptance_window_policy": pair == target or worst[pair]["headroom_ns"] > 0} for pair in sorted(windows)]
    require("Running signoff timing analysis..." in log, "actual final signoff absent")
    last = log.rsplit("Running signoff timing analysis...", 1)[1]
    literal_hold = "Hold/min time violation" in last
    hold_lines = [line for line in last.splitlines() if re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and
        re.search(r"warning|violation|negative", line, re.I)]
    holds = literal_hold or bool(hold_lines)
    require(record["fmax"] == report["fmax"] and type(record["final_reported_hold_violations"]) is bool and
            record["final_reported_hold_violations"] == literal_hold and record["last_signoff_hold_warning_lines"] == hold_lines,
            "actual recorder Fmax/last hold scan differs")
    backend = board._require_gpu_backend(log)
    require(backend == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log) and "Info: Program finished normally." in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()), "actual live HIP/normal completion absent")
    gain = clocks[MEMORY]["after_mhz"] > TARGET_MHZ
    passed = (gain and all(clocks[name]["constraint_passed"] for name in (PIXEL, CAPTURE)) and
        all(row["passes_acceptance_window_policy"] for row in relations) and not holds)
    return {"passes_practical_timing_gate": passed, "actual_timing_thresholds_passed": passed,
        "raw_timing": {"memory_strict_gain_vs_current_accepted_fifth": gain, "memory_gain_threshold_mhz": TARGET_MHZ,
            "memory_130mhz_closed": clocks[MEMORY]["constraint_passed"], "clocks": clocks,
            "all_actual_required_non_target_windows": relations, "complete_current_path_count": len(endpoints),
            "final_reported_hold_violations": holds, "last_signoff_hold_warning_lines": hold_lines,
            "all_clock_fmax_nonregression_vs_accepted_reference": all(row["gain_mhz"] >= 0 for row in clocks.values()),
            "lower_positive_headroom_allowed_and_disclosed": True},
        "evidence": {"current_native_report_topology": topology, "gpu_backend": backend,
            "pinned_pure_module_sha256": {str(CORE): CORE_SHA256, str(core.SELECTED): core.SELECTED_SHA, str(core.FREEZE): core.FREEZE_SHA,
                str(core.BOARD): core.BOARD_SHA, **{str(path): expected for path, expected in core.DEPS.values()}},
            "all_finite_emitted_segment_sums_checked": True, "old_path_delays_or_sta_inherited": False,
            "historical_timing_evaluate_called": False, "unreported_extrema_or_physical_delays_independently_recomputed": False,
            "caller_must_bind_all_input_output_module_dependency_and_runtime_hashes": True},
        "overall_graph_acceptance_claimed": False, "hardware_tested": False}
