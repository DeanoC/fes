"""Pure named-slot proof of one added ready1 outer4 copy in final routed images."""
import copy
import re

PINS = "ABCDEF"
COMB = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMP = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C"
OWNERS = (COMB, DECOMP + "$code0", DECOMP + "$code1", DECOMP + "$root")


def require(value, message):
    if not value:
        raise ValueError(message)


def scalar(cell, port):
    bits = cell["connections"][port]
    require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0, "native scalar required: " + port)
    return bits[0]


def lut(cell):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    require(match is not None and set(cell["parameters"]) == {"LUT"}, "ordinary LUT schema differs")
    width, text = int(match[1]), cell["parameters"]["LUT"]
    expected = {pin: "input" for pin in PINS[:width]} | {"Q": "output"}
    require(type(text) is str and len(text) == 1 << width and set(text) <= {"0", "1"} and
            cell["port_directions"] == expected and set(cell["connections"]) == set(expected), "ordinary LUT mask/ports differ")
    return width, int(text, 2), [scalar(cell, pin) for pin in PINS[:width]], scalar(cell, "Q")


def net_record(net):
    result = copy.deepcopy(net)
    result.get("attributes", {}).pop("ROUTING", None)
    return result


def aliases(top):
    result = {}
    for name, net in top["netnames"].items():
        for bit in net["bits"]: result.setdefault(bit, []).append(name)
    return result


def prove(native, selected, before_doc, after_doc, ready, profile, trial):
    """No reads/imports; compare complete lossless documents and explicit ledgers."""
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "document schema/creator differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    model = profile["prefix_fresh_local_models"][6]
    inner, outer, clone = ready["inner"], ready["outer"], ready["new_clone"]
    retained, alias = outer + "$local_remap", clone + "$Q"
    source, sink, port = profile["declared_driver_edge"]
    driver_clone = source + "$lut_driver_copy$" + sink + "$" + port
    successor = profile["driver_current_immediate_carry_successor"]["cell"]
    require((inner, outer) == (model["inner"], model["outer"]) and clone == outer + "$local_remap$1" and
            ready["declared_ena_redirect_count"] == len(ready["declared_ena_redirects"]) == 1 and
            set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and list(a) == list(b) and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (20136, 20137, 21874, 21875) and
            set(b["cells"]) == set(a["cells"]) | {clone} and clone not in a["cells"] and
            set(b["netnames"]) == set(a["netnames"]) | {alias} and alias not in a["netnames"] and
            [name for name in b["cells"] if name != clone] == list(a["cells"]) and
            [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "complete module/order/PLL/one-copy population differs")
    require("FES_LABSTATE_V1" in a["attributes"] and all("FES_PINMAP_V1" in cell["attributes"]
            for top in (a, b) for cell in top["cells"].values()), "final physical snapshots missing")
    od, ou = selected.native_tables(a)
    nd, nu = selected.native_tables(b)
    aa, ba, allowed, frames = aliases(a), aliases(b), {}, []

    def frame(owner, named_alias, kind):
        old, new = scalar(a["cells"][owner], "Q"), scalar(b["cells"][owner], "Q")
        users = ou.get(old)
        require(od.get(old) == nd.get(new) == [(owner, "Q", 0, 0)] and users and users == nu.get(new),
                "private owner driver/complete named users differ: " + owner)
        for top, bit, names in ((a, old, aa), (b, new, ba)):
            require(names.get(bit) == [named_alias] and top["netnames"][named_alias]["bits"] == [bit] and
                    all(bit not in p["bits"] for p in top["ports"].values()), "private alias/boundary differs: " + owner)
        left, right = net_record(a["netnames"][named_alias]), net_record(b["netnames"][named_alias])
        left["bits"], right["bits"] = [], []
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + owner)
        for slot in [(owner, "Q", 0, 0)] + users:
            require(slot not in allowed and slot[3] == 0 and
                    a["cells"][slot[0]]["connections"][slot[1]][slot[2]] == old and
                    b["cells"][slot[0]]["connections"][slot[1]][slot[2]] == new,
                    "private named slot overlaps/differs or occurrence unsupported")
            allowed[slot] = (old, new)
        row = {"owner": owner, "alias": named_alias, "old_raw_bit": old, "new_raw_bit": new,
            "named_consumer_slots": [list(slot) for slot in users], "kind": kind}
        frames.append(row)
        return row

    private = [frame(owner, owner + "$Q", "existing_private_output") for owner in OWNERS]
    driver = frame(driver_clone, driver_clone + "$Q", "existing_driver_copy_output")
    require(driver["named_consumer_slots"] == [[sink, port, 0, 0]], "driver copy has another consumer")
    buffers = {name for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_BUF"}
    require(len(buffers) == 5232 and buffers == {name for name, cell in b["cells"].items() if cell["type"] == "MISTRAL_BUF"},
            "existing named buffer population differs")
    buffer_rows = []
    for name in sorted(buffers):
        row = frame(name, name + "$conn$Q", "existing_late_buffer_output")
        require(len(row["named_consumer_slots"]) == 1, "buffer output does not have one consumer")
        ff, ff_port, index, occurrence = row["named_consumer_slots"][0]
        require(ff_port == "DATAIN" and index == occurrence == 0 and a["cells"][ff]["type"] == b["cells"][ff]["type"] == "MISTRAL_FF" and
                a["cells"][name]["port_directions"] == b["cells"][name]["port_directions"] == {"A": "input", "Q": "output"} and
                set(a["cells"][name]["connections"]) == set(b["cells"][name]["connections"]) == {"A", "Q"} and
                scalar(a["cells"][name], "A") == scalar(b["cells"][name], "A"), "buffer input/unique FF identity differs")
        bit = scalar(a["cells"][name], "A")
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit), "buffer input native driver differs")
        buffer_rows.append({**row, "buffer": name, "ff": ff, "input_raw_bit": bit, "input_native_driver": list(od[bit][0])})
    require(len({row["old_raw_bit"] for row in frames}) == len({row["new_raw_bit"] for row in frames}) == len(frames), "private frames overlap")
    wi, mi, ai, qi = lut(a["cells"][inner])
    wo, mo, ao, qo = lut(a["cells"][outer])
    wp, mp, ap, qp = lut(a["cells"][retained])
    wc, mc, ac, qc = lut(b["cells"][clone])
    require((wi, wo, wp, wc, mi, mo, mp, mc) == (2, 4, 5, 5, 0xb, 0xf0e0, 0xbbbbbbb0, 0xbbbbbbb0) and
            ao.count(qi) == 1 and len(set(ac)) == 5 and ac == ap and set(ac) == set(ai + [bit for bit in ao if bit != qi]) and
            not ({qi, qo, qp, qc} & set(ac)) and len({qi, qo, qp, qc}) == 4 and
            b["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
            b["netnames"][alias]["bits"] == [qc] and nd.get(qc) == [(clone, "Q", 0, 0)] and ba.get(qc) == [alias] and
            all(qc not in p["bits"] for p in b["ports"].values()), "ready1 outer4 cone/copy/private placement differs")
    left, right = copy.deepcopy(a["cells"][retained]), copy.deepcopy(b["cells"][clone])
    for cell in (left, right):
        cell["attributes"].pop("NEXTPNR_BEL"); cell["attributes"].pop("FES_PINMAP_V1"); cell["connections"].pop("Q")
    require(native.canonical(left) == native.canonical(right) and
            list(a["cells"][retained]["connections"]) == list(b["cells"][clone]["connections"]) and
            list(a["cells"][retained]["port_directions"]) == list(b["cells"][clone]["port_directions"]), "new ready metadata/input order differs")
    left, right = net_record(a["netnames"][retained + "$Q"]), net_record(b["netnames"][alias])
    left["bits"], right["bits"] = [], []
    require(native.canonical(left) == native.canonical(right), "new ready private alias metadata differs")
    retained_rows = ready["retained_copy_cohorts"]
    require(len(retained_rows) == 6, "retained six-copy cohort declaration differs")
    retained_slots = set()
    for row, earlier in zip(retained_rows, profile["prefix_fresh_local_models"][:6]):
        name = row["cell"]; bit = scalar(a["cells"][name], "Q")
        slots = sorted(tuple(slot) for slot in row["consumer_slots"])
        require(a["cells"][name] == b["cells"][name] and a["cells"][name]["attributes"]["NEXTPNR_BEL"] == earlier["bel"] and
                ou.get(bit) == nu.get(bit) == slots and len(slots) == earlier["ena_users"] and not retained_slots & set(slots),
                "retained copy full physical metadata/complete users differ: " + name)
        retained_slots.update(slots)
    require(len(ou.get(qp, [])) == 21 and ou[qp] == nu[qp], "retained ready1 outer4 twenty-one-user copy differs")
    row = ready["declared_ena_redirects"][0]
    chosen = (row["cell"], "ENA", row["vector_index"], row["occurrence"])
    require(chosen == ("hps_ddr.m1_byteenable_MISTRAL_FF_Q_7", "ENA", 0, 0) and chosen not in allowed and
            chosen not in retained_slots and a["cells"][chosen[0]]["type"] == b["cells"][chosen[0]]["type"] == "MISTRAL_FF" and
            scalar(a["cells"][chosen[0]], "ENA") == qo and scalar(b["cells"][chosen[0]], "ENA") == qc and
            scalar(a["cells"][chosen[0]], "CLK") == scalar(b["cells"][chosen[0]], "CLK") == 3549 and
            a["cells"][chosen[0]]["attributes"]["NEXTPNR_BEL"] == "MISTRAL_FF.25.22.56" and
            len(ou.get(qo, [])) == 88 and len(nu.get(qo, [])) == 87 and nu.get(qc) == [chosen] and
            [slot for slot in ou[qo] if slot != chosen] == nu[qo], "one-ENA root88→87 partition differs")
    for slot in ou[qo] + list(retained_slots):
        require(slot[1:] == ("ENA", 0, 0) and a["cells"][slot[0]]["type"] == "MISTRAL_FF" and
                scalar(a["cells"][slot[0]], "CLK") == scalar(b["cells"][slot[0]], "CLK") == 3549, "known common-clock FF ENA union differs")
    allowed[chosen] = (qo, qc)
    truth = []
    for assignment in range(32):
        values = {bit: (assignment >> i) & 1 for i, bit in enumerate(ac)}
        iv = (mi >> sum(values[bit] << i for i, bit in enumerate(ai))) & 1
        original = (mo >> sum((iv if bit == qi else values[bit]) << i for i, bit in enumerate(ao))) & 1
        require(original == (mp >> assignment) & 1 == (mc >> assignment) & 1, "ready1 five-input logical composition differs")
        truth.append({"assignment": assignment, "value": original})
    for bit in ac:
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit) and a["cells"][od[bit][0][0]]["type"] != "MISTRAL_CONST", "ready1 leaf driver differs")
    ws, ms, ins, qs = lut(a["cells"][source])
    require(ws == 3 and ms == 0x20 and len(ou.get(qs, [])) == len(nu.get(qs, [])) == 48 and ou[qs] == nu[qs] and
            od.get(qs) == nd.get(qs) == [(source, "Q", 0, 0)] and (sink, port, 0, 0) not in ou[qs] and
            trial["source"] == source and trial["sink"] == sink and trial["port"] == port and trial["candidate"] == 0 and
            b["cells"][driver_clone]["attributes"]["NEXTPNR_BEL"] == trial["bel"], "driver source48/private1/actual qualified site differs")
    driver_truth = []
    for top in (a, b):
        wd, md, ind, _ = lut(top["cells"][driver_clone])
        require((wd, md, ind) == (ws, ms, ins) and len(set(ins)) == 3 and
                top["cells"][sink]["type"] == top["cells"][successor]["type"] == "MISTRAL_ALUT_ARITH" and
                scalar(top["cells"][sink], "CO") == scalar(top["cells"][successor], "CI"), "driver inputs/carry successor differs")
        driver_truth.append([{"assignment": i, "value": (md >> i) & 1} for i in range(8)])
    for bit in ins: require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit), "driver input native owner differs")
    co = scalar(a["cells"][sink], "CO")
    require(ou.get(co) == nu.get(co) == [(successor, "CI", 0, 0)], "dedicated carry successor has another consumer")
    expected_drivers = dict(od)
    for row in frames: del expected_drivers[row["old_raw_bit"]]
    require(qc not in expected_drivers, "new ready output overlaps a retained ordinary bit")
    for row in frames:
        bit = row["new_raw_bit"]
        require(bit not in expected_drivers and bit != qc, "private frame overlaps another driver/new clone")
        expected_drivers[bit] = [(row["owner"], "Q", 0, 0)]
    expected_drivers[qc] = [(clone, "Q", 0, 0)]
    require(nd == expected_drivers, "complete native drivers differ beyond explicit frames")
    expected_users = {}
    for bit, slots in ou.items():
        for slot in slots: expected_users.setdefault(allowed[slot][1] if slot in allowed else bit, []).append(slot)
    for i, bit in enumerate(ac): expected_users.setdefault(bit, []).append((clone, PINS[i], 0, 0))
    require(nu == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete native users differ beyond named frames/oneENA/fiveloads")
    for name, old in a["cells"].items():
        expected = copy.deepcopy(old)
        for port_name, bits in expected["connections"].items():
            for index, bit in enumerate(bits):
                slot = (name, port_name, index, 0)
                if slot in allowed:
                    require(allowed[slot][0] == bit, "declared original slot bit differs")
                    bits[index] = allowed[slot][1]
        if name == driver_clone:
            for field in ("NEXTPNR_BEL", "FES_PINMAP_V1"):
                require(field in expected["attributes"] and field in b["cells"][name]["attributes"], "actual driver site/pin field missing")
                expected["attributes"][field] = b["cells"][name]["attributes"][field]
        require(native.canonical(expected) == native.canonical(b["cells"][name]) and
                list(old["connections"]) == list(b["cells"][name]["connections"]) and
                list(old["port_directions"]) == list(b["cells"][name]["port_directions"]), "original metadata/fullpins/BEL/undeclaredslots differ: " + name)
    private_nets = {row["alias"]: row for row in frames}
    for name, old in a["netnames"].items():
        expected = net_record(old)
        if name in private_nets: expected["bits"] = [private_nets[name]["new_raw_bit"]]
        require(native.canonical(expected) == native.canonical(net_record(b["netnames"][name])), "original alias/rawbits/metadata differs: " + name)
    require(sum(cell["type"] == "MISTRAL_FF" for cell in a["cells"].values()) == 8221, "original FF population differs")
    return {"ready": ready, "driver": {"source": source, "clone": driver_clone, "sink": sink, "port": port, "successor": successor},
        "buffer_rows": buffer_rows, "private_output_rows": private, "driver_output_row": driver,
        "evidence": {"serialized_native_scope_proved": True, "original_cells": len(a["cells"]), "new_cells": len(b["cells"]),
            "buffer_count": len(buffer_rows), "private_output_owner_count": len(private), "complete_driver_and_user_tables_proved": True,
            "all_original_metadata_exact_except_named_frames_and_requalified_driver_site": True,
            "whole_module_lab_snapshot_exact": True, "all_six_retained_copies_and_consumer_slots_exact": True,
            "declared_ena_redirect_count": 1, "new_copy": clone, "original_root_users_before": 88, "original_root_users_after": 87,
            "actual_ready_q": qc, "actual_ready_conditional_rows": truth, "driver_source_retained_users": 48, "driver_copy_users": 1,
            "driver_conditional_rows_per_frame": driver_truth, "driver_site_before": a["cells"][driver_clone]["attributes"]["NEXTPNR_BEL"],
            "driver_site_after": b["cells"][driver_clone]["attributes"]["NEXTPNR_BEL"],
            "conditional_plain_sig_assumptions": True, "physical_pin_truth_or_sta_inherited": False}}
