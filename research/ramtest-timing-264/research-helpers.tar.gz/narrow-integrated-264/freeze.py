"""Root-only freeze and flat authentication for exact integrated reproduction.

No old proof generators are executed. The accepted cached proof is immutable;
its original artifact/runtime pathnames are hashed directly, then rehashed.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
TOOLCHAIN = MODULE / "build/toolchain-ramtest-timing"
SRC = TOOLCHAIN / "src/nextpnr-narrow-integrated-264"
BUILD = TOOLCHAIN / "build/nextpnr-narrow-integrated-264"
MISTRAL = TOOLCHAIN / "src/mistral"
COMMIT = "0c59d78a9d672f5ddc4a81b622055b125f1d2522"
BASE = "e792486c5763564ffc8a9b56366a11cebd982baa"
REFERENCE = HERE.parent / "narrow-search-full-v2-264/route-e0-t0-ac0"
REFERENCE_PROOF = REFERENCE / "comparison-v4.json"
REFERENCE_SHA = "0de965ae99e9708c158b590d62bdcfca31205e821e0b178b5bfb809fefb8918c"
FOLDER = HERE / "route-reproduction"
IDENTITY = HERE / "source-identity.json"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def digest(value):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata: " + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def bind(inputs, path, expected):
    path = Path(path).absolute()  # Retain and rehash the original symlink pathname.
    require(digest(expected), "input digest is malformed: " + str(path))
    if str(path) in inputs:
        require(inputs[str(path)] == expected, "conflicting input: " + str(path))
        return
    require(sha(path) == expected, "input changed: " + str(path))
    inputs[str(path)] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "input changed during operation: " + path)


def cached_reference():
    inputs = {}
    bind(inputs, REFERENCE_PROOF, REFERENCE_SHA)
    proof = read(REFERENCE_PROOF)
    require(proof["candidate_completed"] is True and proof["graph_proof_available"] is True and
            proof["candidate_accepted_under_confirmed_target_clock_rule"] is True and
            proof["final_metadata_stable_during_comparison"] is True and proof["structural_rejection"] is None,
            "reference is not the finalized accepted native full proof")
    for name, expected in proof["artifact_sha256"].items():
        path = ROOT / name
        require(not Path(name).is_absolute() and ".." not in Path(name).parts,
                "reference artifact escaped ROOT")
        bind(inputs, path, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "reference runtime pathname is not absolute")
        bind(inputs, name, expected)
    run = read(REFERENCE / "run.json")
    require(run["completed"] is True and run["exit_code"] == 0 and run["phase"] == "route" and
            run["final_reported_hold_violations"] is False and run["minimum_log_verified"] is True,
            "reference run is not finalized hold-clean full routing")
    return run, proof, inputs


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def snapshot(repo, label, archives, repositories, expected=None):
    commit = git(repo, "rev-parse", "HEAD").decode().strip()
    require(expected is None or commit == expected, "source commit differs: " + label)
    require(not git(repo, "status", "--porcelain=v1", "--untracked-files=no").strip(),
            "tracked source or submodule is dirty: " + label)
    archive_name = "archives/" + label + ".tar"
    payload = git(repo, "archive", "--format=tar", commit)
    archives[archive_name] = payload
    tree = git(repo, "rev-parse", commit + "^{tree}").decode().strip()
    links = {}
    for entry in git(repo, "ls-tree", "-r", "-z", commit).split(b"\0"):
        if not entry:
            continue
        header, name = entry.split(b"\t", 1)
        mode, kind, object_id = header.decode().split()
        if mode != "160000":
            continue
        name, object_id = name.decode(), object_id
        links[name] = {"commit": object_id, "archived": (repo / name / ".git").exists()}
        if links[name]["archived"]:
            snapshot(repo / name, label + "/" + name, archives, repositories, object_id)
    repositories[label] = {"path": str(repo), "commit": commit, "tree": tree,
        "archive_member": archive_name, "archive_sha256": hashlib.sha256(payload).hexdigest(), "gitlinks": links}


def expected_command(reference):
    command = list(reference["command"])
    command[0] = str(HERE / "nextpnr-mistral")
    for option, name in (("--write", "routed.json"), ("--report", "timing.json"), ("--rbf", "core.rbf")):
        require(command.count(option) == 1, "reference output option is ambiguous: " + option)
        command[command.index(option) + 1] = str(FOLDER / name)
    require("--no-route" not in command and command.count("--router") == 1 and
            command[command.index("--router") + 1] == "gpu" and command.count("--gpu-device") == 1 and
            command[command.index("--gpu-device") + 1] == "1", "reference is not the same full GPU1 profile")
    return command


def expected_environment(reference):
    return dict(reference["diagnostic_environment"])


def expected_runtime(reference, source):
    execution = json.loads(json.dumps(reference["execution"]))
    old = reference["command"][0]
    require(execution["files"].pop(old) == source["input_sha256"][old], "reference executable/runtime mismatch")
    execution["files"][str(HERE / "nextpnr-mistral")] = source["binary_sha256"]
    execution["environment"]["PATH"] = str(HERE) + ":/usr/bin:/bin"
    return execution


def record_template(source, execution):
    reference = read(REFERENCE / "run.json")
    inputs = dict(source["input_sha256"])
    inputs[str(IDENTITY)] = sha(IDENTITY)
    return {"schema": 1, "kind": "strict integrated reproduction of accepted full-v2",
        "phase": "integrated-reproduction", "compiler_commit": COMMIT, "integration_base_commit": BASE,
        "source_identity_sha256": sha(IDENTITY), "source_archive_sha256": source["source_archive_sha256"],
        "binary_sha256": source["binary_sha256"], "host_validation_sha256": source["host_validation_sha256"],
        "reference_proof_sha256": REFERENCE_SHA, "reference_run_sha256": source["reference_run_sha256"],
        "runner_sha256": source["helper_sha256"]["route.py"], "freeze_sha256": source["helper_sha256"]["freeze.py"],
        "comparator_sha256": source["helper_sha256"]["compare_route.py"],
        "command": expected_command(reference), "diagnostic_environment": expected_environment(reference),
        "cwd": reference["cwd"], "execution": execution, "input_sha256": inputs,
        "fresh_listing_qualification_claimed": False, "runtime_qualification_required": True,
        "strict_complete_module_graph_and_rbf_identity_required": True,
        "tool_identity": f"base_commit={BASE}; experimental_source_sha256={source['source_archive_sha256']}; sha256={source['binary_sha256']}",
        "completed": False, "hardware_acceptance": False}


def authenticate_phase(record, source):
    expected = record_template(source, record["execution"])
    state = {"completed", "elapsed_seconds", "exit_code", "failure", "exit_code_is_adapter_sentinel",
             "output_sha256", "compiler_read_audit_passed", "fmax", "final_reported_hold_violations"}
    require({key: value for key, value in record.items() if key not in state} ==
            {key: value for key, value in expected.items() if key not in state}, "actual reproduction metadata differs")
    require(type(record["completed"]) is bool and "failure" not in record and
            record["execution"] == expected_runtime(read(REFERENCE / "run.json"), source),
            "actual controlled runtime differs from the reference except executable/PATH")
    if record["completed"]:
        require(type(record["exit_code"]) is int and record["exit_code"] == 0 and
                record["compiler_read_audit_passed"] is True and
                set(record["output_sha256"]) == {str(FOLDER / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")},
                "completed reproduction lacks normal exit/audit/output closure")
    return expected


def authenticate_freeze():
    source = read(IDENTITY)
    require(source["schema"] == 1 and source["result_commit"] == COMMIT and source["integration_base_commit"] == BASE and
            source["reference_proof_sha256"] == REFERENCE_SHA and source["clean_committed_checkout_at_freeze"] is True and
            source["fresh_listing_qualification_claimed"] is False, "integrated source identity differs")
    finish(source["input_sha256"])
    require(source["input_sha256"].get(str(REFERENCE_PROOF)) == REFERENCE_SHA,
            "source closure omits the accepted proof")
    proof = read(REFERENCE_PROOF)
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts and
                source["input_sha256"].get(str(ROOT / name)) == expected, "accepted artifact closure is incomplete")
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute() and source["input_sha256"].get(name) == expected,
                "accepted original runtime pathname is missing")
    require(source["helper_sha256"] == {name: sha(HERE / name) for name in ("freeze.py", "route.py", "compare_route.py")},
            "integrated helper bytes differ")
    require(sha(HERE / "nextpnr-mistral") == source["binary_sha256"] and
            sha(HERE / "source.tar.gz") == source["source_archive_sha256"], "frozen compiler/archive differs")
    with tarfile.open(HERE / "source.tar.gz", "r:gz") as archive:
        members = archive.getmembers()
        expected = {row["archive_member"]: row["archive_sha256"] for row in source["repositories"].values()}
        require(len(members) == len(expected) and all(member.isfile() for member in members) and
                {member.name for member in members} == set(expected), "source archive member set differs")
        for member in members:
            require(hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected[member.name],
                    "source archive payload differs")
    for row in source["repositories"].values():
        require(git(row["path"], "rev-parse", row["commit"] + "^{tree}").decode().strip() == row["tree"],
                "committed source object differs")
        require(hashlib.sha256(git(row["path"], "archive", "--format=tar", row["commit"])).hexdigest() ==
                row["archive_sha256"], "source archive is not the committed Git payload")
    require(source["repositories"]["nextpnr"]["commit"] == COMMIT and
            source["repositories"]["nextpnr"]["path"] == str(SRC) and
            source["repositories"]["mistral"]["path"] == str(MISTRAL) and
            source["input_sha256"].get(str(HERE / "nextpnr-mistral")) == source["binary_sha256"] and
            source["input_sha256"].get(str(HERE / "source.tar.gz")) == source["source_archive_sha256"] and
            source["input_sha256"].get(source["host_validation_path"]) == source["host_validation_sha256"],
            "source/archive/binary/host-validation aliases are incomplete")
    reference = read(REFERENCE / "run.json")
    require(source["command"] == expected_command(reference) and
            source["diagnostic_environment"] == expected_environment(reference), "sealed reproduction profile differs")
    return source


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host-validation", type=Path, required=True)
    parser.add_argument("--host-validation-sha256", required=True)
    args = parser.parse_args()
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json", "build-config.txt")),
            "freeze output already exists")
    reference, _, inputs = cached_reference()
    bind(inputs, args.host_validation, args.host_validation_sha256)
    validation = read(args.host_validation)
    require(validation["result_commit"] == COMMIT and validation["integration_base_commit"] == BASE and
            validation["clean_committed_checkout"] is True and validation["build_passed"] is True and
            set(validation["checks"]) == {"focused_backend", "cli", "integration96"} and
            all(row["passed"] is True and type(row["exit_code"]) is int and row["exit_code"] == 0
                for row in validation["checks"].values()), "current host validation is not complete and passing")
    require(validation["artifact_sha256"], "host validation lacks artifact/log hashes")
    for name, expected in validation["artifact_sha256"].items():
        bind(inputs, name if Path(name).is_absolute() else ROOT / name, expected)
    require(sha(BUILD / "nextpnr-mistral") == validation["binary_sha256"], "validated binary differs")
    cache = (BUILD / "CMakeCache.txt").read_text()
    require("CMAKE_HOME_DIRECTORY:INTERNAL=" + str(SRC) + "\n" in cache and
            "MISTRAL_ROOT:STRING=" + str(MISTRAL) + "\n" in cache, "integrated build source roots differ")
    cache_digest = sha(BUILD / "CMakeCache.txt")
    archives, repositories = {}, {}
    snapshot(SRC, "nextpnr", archives, repositories, COMMIT)
    subprocess.run(["git", "-C", str(SRC), "merge-base", "--is-ancestor", BASE, COMMIT], check=True)
    snapshot(MISTRAL, "mistral", archives, repositories)
    for name in ("freeze.py", "route.py", "compare_route.py"):
        bind(inputs, HERE / name, sha(HERE / name))
    finish(inputs)
    with (HERE / "nextpnr-mistral").open("xb") as destination, (BUILD / "nextpnr-mistral").open("rb") as producer:
        shutil.copyfileobj(producer, destination)
    (HERE / "nextpnr-mistral").chmod(0o555)
    require(sha(HERE / "nextpnr-mistral") == validation["binary_sha256"], "copied compiler differs")
    require(sha(BUILD / "CMakeCache.txt") == cache_digest, "build configuration changed during freeze")
    with (HERE / "build-config.txt").open("x") as output:
        output.write(cache)
    bind(inputs, HERE / "build-config.txt", cache_digest)
    with (HERE / "source.tar.gz").open("xb") as output:
        with tarfile.open(fileobj=output, mode="w:gz") as archive:
            for name, payload in sorted(archives.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(payload), 0o444, 0
                archive.addfile(member, io.BytesIO(payload))
    source = {"schema": 1, "result_commit": COMMIT, "integration_base_commit": BASE,
        "reference_proof_sha256": REFERENCE_SHA, "reference_run_sha256": sha(REFERENCE / "run.json"),
        "repositories": repositories, "binary_sha256": sha(HERE / "nextpnr-mistral"),
        "source_archive_sha256": sha(HERE / "source.tar.gz"), "host_validation_sha256": args.host_validation_sha256,
        "host_validation_path": str(args.host_validation.absolute()), "clean_committed_checkout_at_freeze": True,
        "helper_sha256": {name: sha(HERE / name) for name in ("freeze.py", "route.py", "compare_route.py")},
        "command": expected_command(reference), "diagnostic_environment": expected_environment(reference),
        "fresh_listing_qualification_claimed": False, "required_runtime_qualification": True,
        "strict_complete_module_graph_and_rbf_identity_required": True, "hardware_tested": False,
        "input_sha256": inputs}
    source["input_sha256"].update({str(HERE / "nextpnr-mistral"): source["binary_sha256"],
                                  str(HERE / "source.tar.gz"): source["source_archive_sha256"]})
    finish(inputs)
    with IDENTITY.open("x") as output:
        output.write(json.dumps(source, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"compiler_commit": COMMIT, "source_identity_sha256": sha(IDENTITY),
        "binary_sha256": source["binary_sha256"], "inputs": len(inputs)}, indent=2))


if __name__ == "__main__":
    main()
