#!/usr/bin/env python3
"""Exact native-graph/RBF reproduction check for the integrated compiler.

This reads cached immutable proof evidence; it never replays old comparators,
builds, tests, queries or routes. Any native module or RBF difference rejects
reproduction without algebraic alignment or a physical-preservation waiver.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REFERENCE = HERE.parent / "narrow-search-full-v2-264" / "route-e0-t0-ac0"
REFERENCE_PROOF_SHA = "0de965ae99e9708c158b590d62bdcfca31205e821e0b178b5bfb809fefb8918c"
RESULT_COMMIT = "0c59d78a9d672f5ddc4a81b622055b125f1d2522"
MAIN_COMMIT = "e792486c5763564ffc8a9b56366a11cebd982baa"
DIGEST = re.compile(r"[0-9a-f]{64}")
PLACEMENT_METRICS = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
CONSTRAINTS = {MEMORY: 130.00520324707031, PIXEL: 74.25006866455078, CAPTURE: 130.00520324707031}
DIAGNOSTIC_PREFIXES = ("Info: Balanced ", "Info: Enable replication", "Info: Local-remap plan step ",
                       "Info: Local remap ", "Info: Comb remap ", "Info: Capture locality",
                       "Info: Placed reduction ", "Info: Placed-reduction ", "Info: Decomposition ")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def unique_object(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate manifest JSON key: " + key)
        result[key] = value
    return result


def nonfinite(value):
    raise ValueError("nonfinite JSON value: " + value)


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique_object, parse_constant=nonfinite)


def canonical(value):
    return json.dumps(value, sort_keys=True, allow_nan=False, ensure_ascii=True, separators=(",", ":"))


class ObjectPairs(list):
    pass


class NetlistCells(dict):
    def __init__(self, cells, pll_ports):
        super().__init__(cells)
        self.pll_ports = pll_ports


def read_netlist(path):
    """The frozen 132c parser's paired-PLL rule, without importing old helpers."""
    pairs = json.loads(Path(path).read_text(), object_pairs_hook=ObjectPairs, parse_constant=nonfinite)
    duplicates = {}
    def convert(value, location=(), pll_cell=False):
        if isinstance(value, ObjectPairs):
            counts = {}
            for key, _ in value:
                counts[key] = counts.get(key, 0) + 1
            repeated = {key for key, count in counts.items() if count > 1}
            allowed = (pll_cell and len(location) == 5 and location[0] == "modules" and
                       location[2] == "cells" and location[4] in {"port_directions", "connections"})
            require(not repeated or allowed and repeated == {"outclk"} and counts["outclk"] == 2,
                    "unpermitted duplicate netlist JSON key at " + repr(location))
            is_cell = len(location) == 4 and location[0] == "modules" and location[2] == "cells"
            is_pll = is_cell and dict(value).get("type") == "altera_pll"
            converted = [(key, convert(item, (*location, key), is_pll)) for key, item in value]
            if repeated:
                duplicates[location] = converted
            return dict(converted)
        if isinstance(value, list):
            return [convert(item, (*location, index)) for index, item in enumerate(value)]
        return value
    result = convert(pairs)
    audited = {}
    for location, values in duplicates.items():
        audited.setdefault((location[1], location[3]), {})[location[4]] = values
    for (module, name), fields in audited.items():
        require(set(fields) == {"port_directions", "connections"}, "unpaired PLL duplicate fields")
        require([key for key, _ in fields["port_directions"]] == [key for key, _ in fields["connections"]],
                "PLL ordered direction/connection entries disagree")
        directions = [value for key, value in fields["port_directions"] if key == "outclk"]
        outputs = [value for key, value in fields["connections"] if key == "outclk"]
        require(directions == ["output", "output"] and len(outputs) == 2 and
                all(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0 for bits in outputs) and
                outputs[0] != outputs[1], "PLL duplicate outclk is not two distinct scalar outputs")
        clocks = result["modules"][module]["cells"][name]["parameters"].get("number_of_clocks")
        require(type(clocks) is str and set(clocks) <= {"0", "1"} and int(clocks, 2) == 2,
                "PLL duplicate output count disagrees with parameters")
    require(type(result) is dict and set(result) == {"creator", "modules"} and
            type(result["creator"]) is str and set(result["modules"]) == {"top"},
            "netlist root metadata/module schema changed")
    for module, top in result["modules"].items():
        top["cells"] = NetlistCells(top["cells"], {name: fields for (owner, name), fields in audited.items() if owner == module})
    return result


class Audit:
    """Memoize canonical entry hashes, retaining every original path for exit."""
    def __init__(self):
        self.digests, self.paths, self.artifacts, self.execution = {}, {}, {}, {}

    def bind(self, path, expected=None, execution=False):
        path = Path(path)
        require(path.is_absolute(), "input path is not absolute")
        resolved = path.resolve()
        require(execution or resolved.is_relative_to(ROOT), "artifact is outside ROOT")
        if expected is not None:
            require(type(expected) is str and DIGEST.fullmatch(expected), "invalid expected input hash")
        if resolved not in self.digests:
            self.digests[resolved] = sha(path)
        digest = self.digests[resolved]
        require(expected is None or digest == expected, "input changed: " + str(path))
        require(path not in self.paths or self.paths[path] == digest, "input path identities conflict")
        self.paths[path] = digest
        if resolved.is_relative_to(ROOT):
            self.artifacts[str(resolved.relative_to(ROOT))] = digest
        if execution:
            self.execution[str(path)] = digest
        return digest

    def finish(self):
        require(all(sha(path) == digest for path, digest in self.paths.items()),
                "original artifact/runtime path changed during comparison")

    def adopt_verified(self, path, digest):
        """Adopt entry hashes already checked by the pinned NEW freeze helper."""
        path = Path(path)
        require(path.is_absolute() and type(digest) is str and DIGEST.fullmatch(digest), "invalid authenticated input")
        resolved = path.resolve()
        require(resolved not in self.digests or self.digests[resolved] == digest, "authenticated path identity conflict")
        require(path not in self.paths or self.paths[path] == digest, "authenticated original path conflict")
        self.digests[resolved], self.paths[path] = digest, digest
        if resolved.is_relative_to(ROOT):
            self.artifacts[str(resolved.relative_to(ROOT))] = digest
        else:
            self.execution[str(path)] = digest


def load_pinned(audit, path, digest, name):
    audit.bind(path, digest)
    require(type(digest) is str and DIGEST.fullmatch(digest), "new helper pin is unset")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def cached_reference(audit, source):
    audit.bind(REFERENCE / "comparison-v4.json", REFERENCE_PROOF_SHA)
    proof = read(REFERENCE / "comparison-v4.json")
    require(proof["graph_proof_available"] is True and proof["structural_rejection"] is None and
            proof["candidate_accepted_under_confirmed_target_clock_rule"] is True and
            proof["passes_practical_timing_gate"] is True,
            "cached accepted reference lacks its closed positive proof")
    require(len(proof["artifact_sha256"]) == 316 and len(proof["execution_file_sha256"]) == 282,
            "cached accepted proof closure shape changed")
    for filename, digest in proof["artifact_sha256"].items():
        path = ROOT / filename
        require(not Path(filename).is_absolute() and path.resolve().is_relative_to(ROOT), "cached artifact escapes ROOT")
        require(source["input_sha256"].get(str(path)) == digest, "cached artifact is outside the authenticated source closure")
    for filename, digest in proof["execution_file_sha256"].items():
        require(source["input_sha256"].get(filename) == digest, "cached runtime is outside the authenticated source closure")
    record = read(REFERENCE / "run.json")
    for filename, digest in record["input_sha256"].items():
        require(source["input_sha256"].get(filename) == digest, "reference input is outside the authenticated source closure")
    require(proof["artifact_sha256"].get(str((REFERENCE / "run.json").relative_to(ROOT))) == source["reference_run_sha256"],
            "reference run is outside its accepted closure")
    return proof, record


def authenticate_runtime(audit, record, reference):
    current, old = record["execution"], reference["execution"]
    binary, old_binary = record["command"][0], reference["command"][0]
    require({path: digest for path, digest in current["files"].items() if path != binary} ==
            {path: digest for path, digest in old["files"].items() if path != old_binary},
            "noncompiler runtime files changed")
    require(current["files"].get(binary) == record["input_sha256"].get(binary), "compiler runtime/input hashes disagree")
    require(current["environment"] == {**old["environment"], "PATH": str(Path(binary).parent) + ":/usr/bin:/bin"} and
            {key: value for key, value in current.items() if key not in {"files", "environment"}} ==
            {key: value for key, value in old.items() if key not in {"files", "environment"}},
            "controlled runtime environment/platform/GPU changed")
    for filename, digest in current["files"].items():
        audit.bind(Path(filename), digest, execution=True)


def diagnostics(log):
    return [line for line in log.splitlines() if line.startswith(DIAGNOSTIC_PREFIXES)]


def exact_graph(before, after):
    old, new = before["modules"]["top"], after["modules"]["top"]
    require(canonical(old) == canonical(new), "native full module differs; no alignment or equivalence exception is permitted")
    require(canonical(old["cells"].pll_ports) == canonical(new["cells"].pll_ports), "lossless ordered PLL output occurrences differ")
    for dictionary in ("cells", "netnames"):
        require(list(old[dictionary]) == list(new[dictionary]), "native " + dictionary + " owner export order differs")
    return {"complete_native_module_exact": True, "numeric_bit_ids_routes_aliases_bels_params_attrs_and_full_pins_exact": True,
            "native_json_value_equality_type_sensitive": True,
            "cell_and_net_export_order_exact": True, "lossless_ordered_pll_occurrences_exact": True,
            "cell_count": len(new["cells"]), "named_net_count": len(new["netnames"]),
            "creator_metadata": {"reference": before["creator"], "current": after["creator"],
                                 "only_permitted_nonmodule_difference": "creator"},
            "algebraic_alignment_or_buffer_collapse_used": False}


def path_windows(report):
    require(type(report["critical_paths"]) is list, "current critical paths are missing")
    windows = {}
    for path in report["critical_paths"]:
        key = (path["from"], path["to"])
        require(key not in windows and type(path["max_delay"]) in (int, float) and math.isfinite(path["max_delay"]) and
                path["max_delay"] > 0 and type(path["path"]) is list and path["path"], "malformed/duplicate timing window")
        segments = path["path"]
        require(segments[-1]["type"] == "setup" and sum(step["type"] == "setup" for step in segments) == 1 and
                sum(step["type"] == "clk-skew" for step in segments) <= 1 and all(
                step["type"] in {"clk-skew", "clk-to-q", "source", "routing", "logic", "setup"} and
                type(step["delay"]) in (int, float) and math.isfinite(step["delay"]) for step in segments),
                "timing path has unknown/nonfinite terms or missing/duplicate setup/skew")
        total = math.fsum(step["delay"] for step in segments)
        headroom = path["max_delay"] - total
        require(math.isfinite(total) and math.isfinite(headroom), "nonfinite complete path sum")
        windows[key] = {"from": key[0], "to": key[1], "window_ns": path["max_delay"],
                        "complete_delay_ns": total, "setup_headroom_ns": headroom}
    return windows


def timing_gates(report, parent_report, accepted_proof, log, record):
    require(set(report["fmax"]) == set(parent_report["fmax"]) == set(CONSTRAINTS), "required clock set changed")
    clocks = {}
    for clock, constraint in CONSTRAINTS.items():
        row, old = report["fmax"][clock], parent_report["fmax"][clock]
        require(row["constraint"] == old["constraint"] == constraint and type(row["achieved"]) in (int, float) and
                math.isfinite(row["achieved"]) and row["achieved"] > 0, "clock constraint/value changed")
        before = accepted_proof["raw_timing"]["clocks"][clock]["before_mhz"]
        clocks[clock] = {"achieved_mhz": row["achieved"], "accepted_narrow_mhz": old["achieved"],
                         "delta_vs_accepted_narrow_mhz": row["achieved"] - old["achieved"],
                         "groups8_reference_mhz": before, "gain_vs_groups8_mhz": row["achieved"] - before,
                         "constraint_mhz": constraint, "constraint_passed": row["achieved"] >= constraint}
    old_windows, windows = path_windows(parent_report), path_windows(report)
    require(len(windows) == 6 and set(windows) == set(old_windows) and
            all(windows[key]["window_ns"] == old_windows[key]["window_ns"] for key in windows),
            "six clock-pair/window identities differ from the accepted report")
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    for key, row in windows.items():
        row.update({"positive_headroom_required": key != target, "passes_window": key == target or row["setup_headroom_ns"] > 0,
                    "complete_delay_delta_vs_accepted_ns": row["complete_delay_ns"] - old_windows[key]["complete_delay_ns"],
                    "actual_path": report["critical_paths"][next(i for i, p in enumerate(report["critical_paths"]) if (p["from"], p["to"]) == key)]})
    require("Running signoff timing analysis..." in log, "final signoff block is missing")
    holds = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
    require(record["fmax"] == report["fmax"] and record["final_reported_hold_violations"] is holds,
            "actual final Fmax/hold metadata disagrees")
    practical = clocks[MEMORY]["gain_vs_groups8_mhz"] > 0 and all(clocks[c]["constraint_passed"] for c in (PIXEL, CAPTURE)) and \
        all(row["passes_window"] for row in windows.values()) and not holds
    return {"passes_practical_timing_gate": practical, "clocks": clocks, "required_related_windows": list(windows.values()),
            "preserves_accepted_narrow_memory_fmax": report["fmax"][MEMORY]["achieved"] >= parent_report["fmax"][MEMORY]["achieved"],
            "final_reported_hold_violations": holds, "memory_130mhz_closed": clocks[MEMORY]["constraint_passed"],
            "all_clock_fmax_nonregression_vs_groups8": all(row["gain_vs_groups8_mhz"] >= 0 for row in clocks.values()),
            "achieved_fmax_or_timing_json_identity_is_not_required": True}


def comparison(folder, source_identity_sha256):
    folder = Path(folder).resolve()
    audit = Audit()
    identity = HERE / "source-identity.json"
    audit.bind(identity, source_identity_sha256)
    source = read(identity)
    require(source["result_commit"] == RESULT_COMMIT and source["integration_base_commit"] == MAIN_COMMIT and
            source["reference_proof_sha256"] == REFERENCE_PROOF_SHA and
            source["helper_sha256"]["compare_route.py"] == audit.bind(Path(__file__).resolve()),
            "pinned source identity/compiler/comparator differs")
    producer = load_pinned(audit, HERE / "freeze.py", source["helper_sha256"]["freeze.py"], "integrated_reproduction_freeze")
    require(producer.HERE == HERE and producer.ROOT == ROOT and producer.REFERENCE == REFERENCE and
            producer.FOLDER.resolve() == folder and producer.COMMIT == RESULT_COMMIT and producer.BASE == MAIN_COMMIT,
            "new freeze API paths/source identity differ")
    authenticated = producer.authenticate_freeze()
    require(canonical(authenticated) == canonical(source), "source identity changed during authentication")
    for filename, digest in source["input_sha256"].items():
        audit.adopt_verified(Path(filename), digest)
    audit.bind(HERE / "route.py", source["helper_sha256"]["route.py"])
    accepted_proof, reference = cached_reference(audit, source)
    audit.bind(folder / "run.json")
    record = read(folder / "run.json")
    producer.authenticate_phase(record, source)
    require(type(record["schema"]) is int and record["schema"] == 1 and
            record["reference_run_sha256"] == source["reference_run_sha256"] and
            record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0 and record["compiler_read_audit_passed"] is True and
            not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel")),
            "actual reproduction is not a normally completed audited full route")
    require(record["source_identity_sha256"] == source_identity_sha256 and
            record["input_sha256"] == {**source["input_sha256"], str(identity): source_identity_sha256},
            "actual source identity/input map differs")
    for filename, digest in record["input_sha256"].items():
        audit.bind(Path(filename), digest, execution=not Path(filename).resolve().is_relative_to(ROOT))
    authenticate_runtime(audit, record, reference)
    expected_outputs = {str(folder / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")}
    require(set(record["output_sha256"]) == expected_outputs, "actual output closure differs")
    for filename, digest in record["output_sha256"].items():
        require(Path(filename).stat().st_size > 0, "actual output is empty")
        audit.bind(Path(filename), digest)
    log, reference_log = (folder / "route.log").read_text(), (REFERENCE / "route.log").read_text()
    require("Info: Program finished normally." in log and "Running the GPU router" in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()), "actual full GPU compiler did not complete normally")
    parent_report, report = read(REFERENCE / "timing.json"), read(folder / "timing.json")
    timing = timing_gates(report, parent_report, accepted_proof, log, record)
    rejection, graph = None, None
    selection_messages, metrics = diagnostics(log), PLACEMENT_METRICS.findall(log)
    try:
        require(selection_messages == diagnostics(reference_log), "current selection/qualification/transform messages differ")
        require(len(metrics) == 71 and metrics == PLACEMENT_METRICS.findall(reference_log),
                "71 ordinary placement metrics differ")
        graph = exact_graph(read_netlist(REFERENCE / "routed.json"), read_netlist(folder / "routed.json"))
        require(record["output_sha256"][str(folder / "core.rbf")] ==
                accepted_proof["artifact_sha256"][str((REFERENCE / "core.rbf").relative_to(ROOT))],
                "RBF bytes differ from the accepted route")
    except (ValueError, KeyError, TypeError) as error:
        rejection = str(error)
    exact = rejection is None
    reproduced = exact and timing["passes_practical_timing_gate"] and timing["preserves_accepted_narrow_memory_fmax"]
    audit.finish()
    return {"schema": 1, "phase": "integrated-reproduction", "compiler_commit": RESULT_COMMIT,
            "integration_base_commit": MAIN_COMMIT, "source_identity_sha256": source_identity_sha256,
            "validator_sha256": audit.artifacts[str(Path(__file__).resolve().relative_to(ROOT))],
            "reference_proof_sha256": REFERENCE_PROOF_SHA, "candidate_completed": True,
            "elapsed_seconds": record["elapsed_seconds"], "structural_rejection": rejection,
            "graph_proof_available": exact, "native_graph_and_rbf_reproduced": exact,
            "reproduction_proved": reproduced, "diagnostic_only_not_proved": not reproduced,
            "candidate_accepted_under_confirmed_target_clock_rule": reproduced,
            "passes_practical_timing_gate": exact and timing["passes_practical_timing_gate"],
            "passes_strict_diagnostic_gate_vs_groups8": exact and timing["passes_practical_timing_gate"] and
                                                        timing["all_clock_fmax_nonregression_vs_groups8"],
            "preserves_accepted_narrow_memory_fmax": timing["preserves_accepted_narrow_memory_fmax"],
            "exact_native_graph": graph if exact else None, "rbf_identity_proved": exact,
            "matched_ordinary_placement_metrics": 71 if exact else None,
            "current_runtime_qualification_messages_equal_accepted": selection_messages == diagnostics(reference_log),
            "actual_current_selection_messages": selection_messages,
            "fresh_listing_qualification_claimed": False, "old_comparators_or_authenticators_replayed": False,
            "raw_timing": timing, "hardware_tested": False, "default_recipe_selected": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())),
            "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True,
            "proof_limitations": ["Graph reproduction requires type-sensitive full native module equality, owner order, lossless PLL occurrences and identical RBF bytes; only root creator metadata may differ.",
                                  "Timing differences are reported from actual signoff; successful reproduction also preserves accepted narrow memory Fmax and passing practical non-target constraints/windows/holds.",
                                  "The accepted physical proof is reused by exact serialized graph/RBF identity; no algebraic reference, buffer collapse, scope widening or new pin normalization is used.",
                                  "JSON does not serialize in-memory indexed-store/free-list/bucket or GPU ID state. No independent RBF/CRAM decoder or hardware acceptance is claimed."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    require(not (args.folder / "comparison.json").exists(), "comparison output already exists")
    result = comparison(args.folder, args.source_identity_sha256)
    with (args.folder / "comparison.json").open("x") as output:
        output.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("reproduction_proved", "structural_rejection",
                                                "preserves_accepted_narrow_memory_fmax")}, indent=2))


if __name__ == "__main__":
    main()
