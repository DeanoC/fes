"""Root-only exact accepted-profile reproduction; comparisons never auto-run."""
import json
from pathlib import Path
import subprocess
import sys
import time

import freeze


def main():
    source = freeze.authenticate_freeze()
    folder = freeze.FOLDER
    freeze.require(not folder.exists(), "reproduction output already exists")
    sys.path.insert(0, str(freeze.MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    reference = freeze.read(freeze.REFERENCE / "run.json")
    identity = (f"base_commit={freeze.BASE}; experimental_source_sha256={source['source_archive_sha256']}; "
                f"sha256={source['binary_sha256']}")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(freeze.HERE / "nextpnr-mistral", identity)}, 1)
    try:
        freeze.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                       "ambient diagnostic environment is forbidden")
        record = freeze.record_template(source, invocation.inputs)
        freeze.authenticate_phase(record, source)
        freeze.finish(record["input_sha256"])
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        try:
            with (folder / "route.log").open("x") as log:
                result = audited_run(record["command"], source_root=freeze.MODULE, cwd=record["cwd"],
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log,
                    stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            record["compiler_read_audit_passed"] = True
            invocation.verify()
            log = (folder / "route.log").read_text()
            freeze.require(result.returncode == 0 and "Info: Program finished normally." in log and
                           not any(line.startswith("ERROR:") for line in log.splitlines()) and
                           "Running signoff timing analysis..." in log, "compiler did not complete full routing/signoff")
            board._require_gpu_backend(log)
            freeze.require(all((folder / name).is_file() and (folder / name).stat().st_size > 0
                               for name in ("routed.json", "timing.json", "core.rbf")), "full outputs are missing/empty")
            expected_minimum = reference["expected_nondefault_minimum_log"]
            freeze.require([line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line] ==
                           [expected_minimum], "current minimum200 runtime provenance differs")
            report = freeze.read(folder / "timing.json")
            record["fmax"] = report["fmax"]
            record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
            record["output_sha256"] = {str(folder / name): freeze.sha(folder / name)
                for name in ("route.log", "routed.json", "timing.json", "core.rbf")}
            record["completed"] = True
            freeze.authenticate_phase(record, source)
            freeze.finish(record["input_sha256"])
            print(json.dumps({key: record[key] for key in ("compiler_commit", "completed", "exit_code",
                "elapsed_seconds", "fmax", "final_reported_hold_violations")}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
