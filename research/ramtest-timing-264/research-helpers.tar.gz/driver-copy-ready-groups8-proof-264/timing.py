"""Pure reported-timing gate for the new 8/8/1 prefix; no graph acceptance."""
import builtins
import hashlib
import importlib.util
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
MODULE = ROOT / "sources/misteross"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE = SELECTED.parent / "freeze.py"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
BOARD = MODULE / "scripts/fes_build_common.py"
BOARD_SHA = "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a"
DEPS = {"scripts.source_repository": (MODULE / "scripts/source_repository.py",
        "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003"),
        "scripts.lockfile": (MODULE / "scripts/lockfile.py",
        "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a")}
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
TARGET_MHZ = 117.34334564208984
PARENT_MHZ = {MEMORY: TARGET_MHZ, PIXEL: 93.4928970336914, CAPTURE: 378.5823974609375}
CONSTRAINTS = {MEMORY: 130.0052032470703, PIXEL: 74.25006866455078, CAPTURE: 130.0052032470703}


def require(value, message):
    if not value:
        raise ValueError(message)


def _load(path, expected, name, frozen=None):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected, "pinned pure module changed: " + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    if frozen is not None:
        def local_import(module, globals=None, locals=None, fromlist=(), level=0):
            if module == "freeze" and level == 0:
                return frozen
            return builtins.__import__(module, globals, locals, fromlist, level)
        value.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    require(name not in sys.modules, "pure module name already occupied: " + name)
    sys.modules[name] = value
    try:
        exec(compile(data, str(path), "exec"), value.__dict__)
    finally:
        del sys.modules[name]
    return value


def _paths(report):
    require(report.get("timing_report_paths") == 16384 and len(report["critical_paths"]) == 15290,
            "complete actual expanded report count/cap differs")
    windows, endpoints, worst = {}, set(), {}
    for path in report["critical_paths"]:
        pair, window = (path["from"], path["to"]), path["max_delay"]
        require(type(window) in (int, float) and math.isfinite(window) and window > 0 and
                (pair not in windows or windows[pair] == window), "actual pair window is inconsistent/nonfinite")
        windows[pair] = window
        end = path["path"][-1]["to"]
        endpoint = (*pair, end["cell"], end["port"])
        require(endpoint not in endpoints, "actual report duplicates a pair/endpoint")
        endpoints.add(endpoint)
        terms = [segment["delay"] for segment in path["path"]]
        require(all(type(term) in (int, float) and math.isfinite(term) for term in terms), "nonfinite path term")
        total = math.fsum(terms)
        require(math.isfinite(total), "nonfinite complete path sum")
        if pair not in worst or total > worst[pair]["complete_delay_ns"]:
            worst[pair] = {"complete_delay_ns": total, "headroom_ns": window - total, "actual_worst_path": path}
    require(len(windows) == 7 and len(endpoints) == 15290, "actual seven-pair endpoint coverage differs")
    return windows, endpoints, worst


def evaluate(document, report, parent_report, baseline_report, log, record):
    """Accept the complete lossless document with modules.top; caller binds inputs."""
    token = str(id(document)) + "_" + str(id(report))
    frozen = _load(FREEZE, FREEZE_SHA, "ready_g8_timing_freeze_" + token)
    selected = _load(SELECTED, SELECTED_SHA, "ready_g8_timing_topology_" + token, frozen)
    for path, expected in DEPS.values():
        require(hashlib.sha256(path.read_bytes()).hexdigest() == expected, "pinned board dependency changed: " + str(path))
    previous_path = list(sys.path)
    try:
        sys.path.insert(0, str(MODULE))
        board = _load(BOARD, BOARD_SHA, "ready_g8_timing_board_" + token)
    finally:
        sys.path[:] = previous_path
    for name, (path, expected) in DEPS.items():
        require(name in sys.modules and Path(sys.modules[name].__file__).resolve() == path.resolve(),
                "board imported a different project dependency: " + name)
    topology = selected.report_topology(document, report, baseline_report)
    windows, endpoints, worst = _paths(report)
    parent_windows, parent_endpoints, parent_worst = _paths(parent_report)
    baseline_windows, baseline_endpoints, _ = _paths(baseline_report)
    require(windows == parent_windows == baseline_windows and endpoints == parent_endpoints == baseline_endpoints,
            "actual full/current-baseline/accepted-parent pair, endpoint or window coverage differs")
    require(set(report["fmax"]) == set(parent_report["fmax"]) == set(baseline_report["fmax"]) == set(CONSTRAINTS),
            "actual required clock set differs")
    clocks = {}
    for name, constraint in CONSTRAINTS.items():
        row, before, predicted = report["fmax"][name], parent_report["fmax"][name], baseline_report["fmax"][name]
        require(set(row) == set(before) == set(predicted) == {"achieved", "constraint"} and
                row["constraint"] == before["constraint"] == predicted["constraint"] == constraint and
                before["achieved"] == PARENT_MHZ[name] and all(type(value) in (int, float) and math.isfinite(value) and value > 0
                for value in (row["achieved"], before["achieved"], predicted["achieved"])), "actual Fmax/reference/constraint differs")
        clocks[name] = {"before_mhz": before["achieved"], "after_mhz": row["achieved"],
                        "gain_mhz": row["achieved"] - before["achieved"], "constraint_mhz": constraint,
                        "constraint_passed": row["achieved"] >= constraint}
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    require(windows[("posedge " + CAPTURE, "negedge " + MEMORY)] == 5 and
            windows[("negedge " + MEMORY, "posedge " + MEMORY)] == 3.8459999561309814, "actual phase windows differ")
    relations = [{"from": pair[0], "to": pair[1], "window_ns": windows[pair], **worst[pair],
                  "before_headroom_ns": parent_worst[pair]["headroom_ns"],
                  "headroom_change_ns": worst[pair]["headroom_ns"] - parent_worst[pair]["headroom_ns"],
                  "positive_headroom_required": pair != target,
                  "reported_window_met": worst[pair]["headroom_ns"] > 0,
                  "passes_acceptance_window_policy": pair == target or worst[pair]["headroom_ns"] > 0} for pair in sorted(windows)]
    require("Running signoff timing analysis..." in log, "last actual signoff block absent")
    last = log.rsplit("Running signoff timing analysis...", 1)[1]
    literal_hold = "Hold/min time violation" in last
    hold_lines = [line for line in last.splitlines() if re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and
                  re.search(r"warning|violation|negative", line, re.I)]
    holds = literal_hold or bool(hold_lines)
    require(record["fmax"] == report["fmax"] and type(record["final_reported_hold_violations"]) is bool and
            record["final_reported_hold_violations"] == literal_hold, "actual recorder Fmax/literal last-hold flag differs")
    backend = board._require_gpu_backend(log)
    require(re.search(r"GPU router time [^\n]+backend hip:", log) and "Info: Program finished normally." in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()), "actual live HIP/normal completion absent")
    passed = (clocks[MEMORY]["after_mhz"] > TARGET_MHZ and all(clocks[name]["constraint_passed"] for name in (PIXEL, CAPTURE))
              and all(row["passes_acceptance_window_policy"] for row in relations) and not holds)
    return {"passes_practical_timing_gate": passed, "actual_timing_thresholds_passed": passed,
            "raw_timing": {"memory_strict_gain_vs_117_34334564208984": clocks[MEMORY]["after_mhz"] > TARGET_MHZ,
                "memory_130mhz_closed": clocks[MEMORY]["constraint_passed"], "clocks": clocks,
                "all_actual_required_non_target_windows": relations, "complete_current_path_count": len(endpoints),
                "final_reported_hold_violations": holds, "last_signoff_hold_warning_lines": hold_lines,
                "all_clock_fmax_nonregression_vs_accepted_reference": all(row["gain_mhz"] >= 0 for row in clocks.values()),
                "lower_positive_headroom_allowed_and_disclosed": True},
            "evidence": {"current_native_report_topology": topology, "gpu_backend": backend,
                "pinned_pure_module_sha256": {str(SELECTED): SELECTED_SHA, str(FREEZE): FREEZE_SHA, str(BOARD): BOARD_SHA,
                    **{str(path): expected for path, expected in DEPS.values()}},
                "all_finite_emitted_segment_sums_checked": True, "old_path_delays_or_sta_inherited": False,
                "unreported_pair_extrema_or_physical_delays_independently_recomputed": False,
                "caller_must_bind_all_input_output_module_dependency_and_runtime_hashes": True},
            "overall_graph_acceptance_claimed": False, "hardware_tested": False}
