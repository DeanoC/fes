"""Authenticate actual new full route and report its timing; no graph acceptance."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
FULL = RAW / "driver-copy-ready-groups8-route-264"
PROFILE_SHA = "9cf010db57e534b7d42107124fa2621b7341e8b5704512d9e66053ab78300566"
PARENT = RAW / "driver-copy-route-264/route-c0"
PARENT_PROOF = RAW / "driver-copy-route-proof-v2-264/comparison.json"
PARENT_PROOF_SHA = "a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
TIMING_SHA = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
TIMING_SCOPE_SHA = "5088a952653ccd349edb109bd68e038cace200c911ec7707cef1d958897d8032"
PROJECT_DEPENDENCIES = {
    ROOT / "sources/misteross/scripts/source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    ROOT / "sources/misteross/scripts/lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a",
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name):
    require(sha(path) == expected and name not in sys.modules, "pure module identity differs")
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def inspect(self_sha, scope_sha):
    native = load(NATIVE, NATIVE_SHA, "ready_groups8_actual_native")
    audit = native.Audit()
    for path, expected in ((HERE / "inspect_timing.py", self_sha), (HERE / "inspection-scope.md", scope_sha),
                           (NATIVE, NATIVE_SHA), (HERE / "timing.py", TIMING_SHA),
                           (HERE / "timing-scope.md", TIMING_SCOPE_SHA), (FULL / "source-identity.json", PROFILE_SHA),
                           (PARENT_PROOF, PARENT_PROOF_SHA)):
        audit.bind(path, expected)
    for path, expected in PROJECT_DEPENDENCIES.items():
        audit.bind(path, expected)
    parent = native.read(PARENT_PROOF)
    require(parent["candidate_accepted_under_confirmed_target_clock_rule"] is True and
            parent["full_graph_and_pin_equivalence_proved"] is True and
            parent["final_original_path_metadata_and_runtime_hashes_stable"] is True, "accepted parent proof is not closed")
    for name, expected in parent["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "parent artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in parent["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "parent runtime path is not absolute")
        audit.bind(Path(name), expected, execution=True)
    profile = native.read(FULL / "source-identity.json")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "frozen profile path is not absolute")
        execution = name in profile["baseline_execution"]["files"]
        require(Path(name).resolve().is_relative_to(ROOT) or execution, "external profile artifact is not a runtime file")
        audit.bind(Path(name), expected, execution=execution)
    folder = FULL / "route-c0"
    audit.bind(folder / "run.json")
    record = native.read(folder / "run.json")
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["source_identity_sha256"] == PROFILE_SHA and record["execution"] == profile["baseline_execution"] and
            all(record[key] == value for key, value in profile.items()), "current actual run does not bind frozen execution")
    for name, expected in record["execution"]["files"].items():
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(folder / name) for name in
            ("route.log", "routed.json", "timing.json", "core.rbf")}, "actual output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output is empty")
        audit.bind(Path(name), expected)
    baseline = RAW / "driver-copy-ready-groups8-264/baseline"
    require(all(path in audit.paths for path in (PARENT / "timing.json", baseline / "timing.json")),
            "parent/current-baseline reports absent from bound closure")
    timing = load(HERE / "timing.py", TIMING_SHA, "ready_groups8_actual_timing")
    result = timing.evaluate(native.read_netlist(folder / "routed.json"),
                             native.read(folder / "timing.json"), native.read(PARENT / "timing.json"),
                             native.read(baseline / "timing.json"), (folder / "route.log").read_text(), record)
    require(all(Path(path) in audit.paths and audit.paths[Path(path)] == expected
                for path, expected in result["evidence"]["pinned_pure_module_sha256"].items()),
            "timing pure imports absent from exact bound closure")
    audit.finish()
    return {"schema": 1, "phase": "ready-groups8-actual-full-timing-only", "source_identity_sha256": PROFILE_SHA,
            "generator_sha256": self_sha, "scope_sha256": scope_sha, "accepted_parent_proof_sha256": PARENT_PROOF_SHA,
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"], "timing": result,
            "candidate_accepted": False, "full_graph_and_physical_equivalence_proved": False,
            "rbf_sha256": record["output_sha256"][str(folder / "core.rbf")], "hardware_tested": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    parser.add_argument("--scope-sha256", required=True)
    args = parser.parse_args()
    output = HERE / "timing-inspection.json"
    require(not output.exists(), "immutable timing inspection already exists")
    result = inspect(args.self_sha256, args.scope_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"output_sha256": sha(output), "timing_passed": result["timing"]["passes_practical_timing_gate"],
                      "clocks": result["timing"]["raw_timing"]["clocks"], "candidate_accepted": False}, indent=2))


if __name__ == "__main__":
    main()
