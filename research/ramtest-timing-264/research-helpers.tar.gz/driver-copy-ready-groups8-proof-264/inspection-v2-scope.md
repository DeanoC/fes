# Actual combined-route timing inspection, version 2

This new scope preserves the original c294aad1 inspector and b5fac548 scope.
Root invocation80515 failed before timing evaluation because the original
inspector allowed only current baseline runtime files as external profile
inputs. It created no timing-inspection.json. The flat parent closure also
contains242 historical compilation tool/header paths, each already explicitly
bound in parent.execution_file_sha256. These are historical hash evidence,
not a claim that the current compiler or Python invocation loaded those files.

The new inspector additionally allows an external profile member exactly when
its original absolute path and SHA match that closed parent runtime ledger.
Each is bound with Audit execution=True and finally rehashed. The actual new
route execution snapshot still must equal the current frozen baseline exactly.
Every profile field and all four actual outputs remain exact. This changes no
record, native graph, timing input, helper, guide, clock or acceptance threshold.

All remaining original inspection requirements hold: flat a4a accepted proof,
9cf current route profile, all closures, two explicitly pinned current board
project-import dependencies, and new e6ce77 timing/5088a952 scope. Complete
lossless32fd native document and both actual seven-pair reports are used.
Current timing/no CPU fallback/LAST holds are checked. No older generator or
authentication executes. No graph/physical equivalence or candidate acceptance
is granted; a successful timing gate still needs a separate native/physical
proof. No global numeric normalization, BUF collapse or hardware test.
