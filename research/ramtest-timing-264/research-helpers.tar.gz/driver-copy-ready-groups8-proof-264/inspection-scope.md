# Actual combined-route timing inspection

Root executes this new inspection only after the fresh combined route completes.
The 9cf010db profile and its complete original input closure are rehashed, and
every profile field must match the actual closed audited run record. Its actual
execution snapshot must equal the frozen current baseline. All four actual
outputs and execution files are bound. The accepted parent a4a91235 proof is a
closed flat hash source only; no older generator or authentication is executed.

The pinned lossless 32fd parser preserves repeated PLL ports. New timing.py and
its scope are bound; its exact pure imports must already belong to the bound
closure. The two current board-import dependencies source_repository.py and
lockfile.py are explicitly pinned and bound here, since older flat closures
omit them; each imports only standard-library modules. Their loaded paths and
bytes are checked by timing.py. Timing consumes the complete lossless routed native document, current report, exact
accepted117.343 report, current predicted baseline report, log and record. The
helper verifies every emitted current path/native endpoint, all actual windows,
other clock constraints, live HIP completion and LAST signoff holds. Numerical
STA and physical route delays are not independently recomputed.

This inspection does not accept a candidate or claim full graph/physical
equivalence. If timing fails, the route is rejected as a gain. If timing passes,
the declared22 ENA redirects, complete affected eight LABs/all67 FFs and source
copy/full original graph still need a separate bounded native/physical proof.
No original helper/output/profile is edited, no compiler is run here, no global
numeric ID normalization or BUF collapse is used, and no hardware is tested.
