# Pure timing check for the current 8/8/1 route

Root alone executes the final comparison. `evaluate(document, report,
parent_report, baseline_report, log, record)` accepts decoded current routed
native graph/report, the authenticated accepted 117.34334564208984 MHz report,
the current closed no-driver baseline report, actual route log and actual run
record. The first argument is the complete lossless native document containing
`document["modules"]["top"]`, not the top module alone. It reads only pinned
pure module bytes. It neither authenticates a
profile nor runs an older comparison, generator, compiler or timing analyser.
The enclosing comparator must bind this helper/scope, all six inputs and the
complete module dependency/runtime closure, then rehash their original paths.

The exact 72131acf topology helper uses its own pinned 8601df44 freeze module
through a module-local import binding. No caller `freeze`, old helper globals,
run record or timing report is patched. The actual board GPU guard is pinned
6c8f7343 and requires a live HIP backend without CPU fallback; a completed HIP
router line and normal compiler completion are separately required.
The board module's two executed project imports, `source_repository.py`
(29ab5ad5) and `lockfile.py` (742d5b39), are additionally pinned before loading,
their actual loaded module paths are checked, and their full hashes are
included in evidence. They contain no further project imports. These are new
current proof dependencies absent from the older flat artifact closures;
the enclosing comparator must bind and finally rehash both explicitly.

The current report must contain all 15,290 unique pair/endpoints across the
same seven actual pair/windows as the current baseline and accepted parent.
Current native clock attribution, port/vector slots, BEL coordinates, logic
arcs, routing aliases, endpoint continuity, finite terms and same-clock extra
ordering are checked by the frozen pure topology API. Worst complete delays
are derived with `math.fsum` from every emitted term, including skew, clock-to-Q,
routing, logic and setup. Capture-to-memory is exactly 5 ns; memory negative
to positive is exactly 3.8459999561309814 ns. All six non-target pairs require
strictly positive complete headroom.
The topology helper's Fmax difference fields compare the full report with the
current predicted baseline; the acceptance and all-clock diagnostics below
use the separate accepted routed parent.

Memory must exceed the accepted 117.34334564208984 MHz. The exact actual
constraints are pixel 74.25006866455078 and memory/capture 130.0052032470703
MHz; pixel and capture must pass. Target 130 MHz may remain open and is
reported separately. All-clock Fmax nonregression remains a diagnostic against
the accepted parent, whose pixel/capture are 93.4928970336914/378.5823974609375
MHz. Lower positive margins are allowed and their changes are reported.
Each relation separates `reported_window_met` from
`passes_acceptance_window_policy`: the target's policy exemption never labels
negative target headroom as meeting its reported window.

The LAST actual signoff block is scanned for literal hold/min violations and
broader hold/min warning, violation or negative messages. The actual recorder's
Fmax and literal hold flag are cross-checked without modifying the record.
The returned timing threshold boolean is independent of full graph acceptance.
The enclosing proof must separately establish its actual native and physical
scope before accepting a gain. Emitted numerical STA, physical routing delays,
unpublished endpoint transfer extrema, cache/GPU state, RBF/CRAM and hardware
acceptance are not independently reconstructed by this helper.
