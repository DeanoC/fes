"""Root-only selected12/minimum200 followed by fresh AC listing; no full phase.

The completed first and selected12 proofs are cached and artifact-bound. One
shared flat audit authenticates the original absolute input/runtime paths.
Root must pin the actual selected12 proof and ordinal before sealing.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
INITIAL = RAW / "narrow-search-264"
SELECTED = RAW / "narrow-search-selected-264"
SELECTED_FOLDER = SELECTED / "list-twelve-e0"
SELECTED_PROFILE = SELECTED / "profile.json"
SELECTED_PROOF_PATH = SELECTED_FOLDER / "comparison.json"
SELECTED_SEAL_SHA = "366ce989c6d7304f82cc2f09d0ae82aba49f7748d12629077b4c158192eb1e66"
SELECTED_RUNNER_SHA = "8c8584ba9099cae52bb299b0bd0654cf3f94d1b07f0873318cbd08642793e00b"
SELECTED_COMPARATOR_SHA = "fd3d9fab86ccf8fca5fac62e28bab7ca021eeed91d308d4bfc849d9ab0bcd426"
SELECTED_PROFILE_SHA = "173c18faa6747ef8baefb203382cd7fd71128c6474ff62b89861a715a35995af"
FIRST_GENERATOR_PATH = INITIAL / "compare_first11_fast_v2.py"
FIRST_GENERATOR_SHA = "d23197ada23ff984f195eedce7a4516d818aeac58ea153bbddc521e112607d5d"
FIRST_PROOF_PATH = INITIAL / "first-fast-proof-v2/comparison.json"
FIRST_PROOF_SHA = "f53de620d1265f10be1e834f548c9b9531842e7505393fe88d34c6d912bc8b9a"
FIRST_PURE_HELPER_SHA = "b9b7e62b4a7eaec22a2e064127da1b9332c66de7de1c1fe6509b37c1e6ed7027"
# Root-operated fresh selected12 listing proof; older minima are not reused.
SELECTED_PROOF_SHA = "80e9661e6315534b5be2e76b74613c151ecb02029a10e478d946d0b84e3051f1"
SELECTED_TWELVE = 0
SELECTED_ELEVEN = 0
PROFILE = HERE / "profile.json"
PHASES = ("list-ac",)
TWELVE_ROOT = "ddr0_test.group_valid_MISTRAL_ALUT6_E_F_MISTRAL_ALUT5_Q"
MINIMUM_PS, DEFAULT_MINIMUM_PS = 200, 250
MINIMUM_LOG = "Info: Placed reduction minimum branch gain: 200ps."
DIGEST = re.compile(r"[0-9a-f]{64}")
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite: " + value)))


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def relative(path):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT), "artifact is outside this FES checkout")
    return str(path.relative_to(ROOT))


def selected_primitives(audit=None):
    for name, digest in (("seal_profile.py", SELECTED_SEAL_SHA), ("route.py", SELECTED_RUNNER_SHA),
                         ("compare_selected11.py", SELECTED_COMPARATOR_SHA)):
        if audit is None:
            require(sha(SELECTED / name) == digest, "frozen selected helper changed: " + name)
        else:
            audit.bind(SELECTED / name, digest)
    return module_at(SELECTED / "seal_profile.py", "staged_frozen_selected_phase_primitives")


def bind_proof(audit, path, digest):
    audit.bind(path, digest)
    proof = read(path)
    require(type(proof["artifact_sha256"]) is dict and type(proof["execution_file_sha256"]) is dict,
            "cached proof has no closed artifact/runtime maps")
    for filename, expected in proof["artifact_sha256"].items():
        artifact = ROOT / filename
        require(type(filename) is str and not Path(filename).is_absolute() and
                artifact.resolve().is_relative_to(ROOT), "cached artifact escaped this checkout")
        audit.bind(artifact, expected)
    for filename, expected in proof["execution_file_sha256"].items():
        audit.bind(Path(filename), expected, execution=True)
    return proof


def cached_context():
    require(type(SELECTED_PROOF_SHA) is str and DIGEST.fullmatch(SELECTED_PROOF_SHA) and
            type(SELECTED_TWELVE) is int and 0 <= SELECTED_TWELVE <= 2147483647,
            "root has not pinned the completed fresh twelve proof and ordinal")
    require(sha(FIRST_GENERATOR_PATH) == FIRST_GENERATOR_SHA, "frozen flat authenticator changed")
    fast = module_at(FIRST_GENERATOR_PATH, "staged_frozen_flat_authenticator")
    require(fast.OUTPUT == FIRST_PROOF_PATH and fast.PURE_HELPER_SHA == FIRST_PURE_HELPER_SHA,
            "flat authenticator points to a different proof or pure helper")
    audit = fast.Audit()
    ctx = fast.context(audit)
    initial_profile, g8, base, source, control, _ = ctx
    baseline, _, _ = fast.completed_phase(audit, ctx, "baseline-placement")
    first_record, _, _ = fast.completed_phase(audit, ctx, "list-eleven")
    first_proof = bind_proof(audit, FIRST_PROOF_PATH, FIRST_PROOF_SHA)
    require(first_proof["generator"] == {
                "path": relative(FIRST_GENERATOR_PATH), "sha256": FIRST_GENERATOR_SHA,
                "pure_helper_path": relative(INITIAL / "compare_first11.py"),
                "pure_helper_sha256": FIRST_PURE_HELPER_SHA} and
            first_proof["phase"] == "list-eleven" and first_proof["candidate_completed"] is True and
            first_proof["compiler_commit"] == source["result_commit"] and
            first_proof["profile_sha256"] == fast.PROFILE_SHA and
            first_proof["source_identity_sha256"] == fast.SOURCE_SHA and
            first_proof["new_disabled_control_sha256"] == fast.CONTROL_SHA and
            first_proof["partial_graph_evidence_available"] is True and first_proof["graph_proof_available"] is False and
            first_proof["route_started"] is False and first_proof["timing_acceptance_available"] is False and
            first_proof["parent_qualification_inherited"] is False and
            first_proof["cached_old_comparisons_reexecuted"] is False and
            first_proof["final_metadata_stable_during_comparison"] is True and
            first_proof["matched_placement_metrics"] == 71 and first_proof["placement_metrics_identical"] is True,
            "cached first proof producer, qualification or partial limits changed")
    require(first_proof["artifact_sha256"] ==
            {name: digest for name, digest in audit.artifacts.items() if name != relative(FIRST_PROOF_PATH)} and
            first_proof["execution_file_sha256"] == audit.execution and
            first_proof["qualified_eleven_ordinals"] == first_proof["qualification"]["qualified_ordinals"] ==
            list(range(first_proof["qualification"]["qualified_candidates"])) and
            SELECTED_ELEVEN in first_proof["qualified_eleven_ordinals"],
            "first proof does not exactly close its actual source/runtime/ordinal inputs")
    selected = selected_primitives(audit)
    require(selected.INITIAL_PROOF_PATH == FIRST_PROOF_PATH and selected.INITIAL_PROOF_SHA == FIRST_PROOF_SHA and
            selected.INITIAL_GENERATOR_SHA == FIRST_GENERATOR_SHA and selected.SELECTED_ELEVEN == SELECTED_ELEVEN,
            "selected producer used a different first qualification")
    audit.bind(SELECTED_PROFILE, SELECTED_PROFILE_SHA)
    parent_profile = read(SELECTED_PROFILE)
    audit.closure(parent_profile["input_sha256"])
    require(len(parent_profile["input_sha256"]) == 254 and
            parent_profile["initial_eleven_proof_sha256"] == FIRST_PROOF_SHA and
            parent_profile["initial_generator_sha256"] == FIRST_GENERATOR_SHA and
            parent_profile["selected_eleven_ordinal"] == SELECTED_ELEVEN and
            parent_profile["source_identity_sha256"] == fast.SOURCE_SHA and
            parent_profile["disabled_control_sha256"] == fast.CONTROL_SHA and
            parent_profile["compiler_commit"] == source["result_commit"] and
            parent_profile["route_phase_allowed"] is False and parent_profile["ac_phase_allowed"] is False and
            all(parent_profile["input_sha256"].get(filename) == digest
                for filename, digest in initial_profile["input_sha256"].items()),
            "selected profile is not the sealed same-producer two-stage listing")
    for name in ("run.json", "route.log", "placed.json"):
        audit.bind(SELECTED_FOLDER / name)
    record = read(SELECTED_FOLDER / "run.json")
    environment = selected.expected_diagnostic_environment(base)
    require(record["command"] == selected.expected_command(base) and record["diagnostic_environment"] == environment and
            record["experimental_placed_reduction"] == environment["NEXTPNR_MISTRAL_PLACED_REDUCTION"] and
            record["experimental_capture_locality"] == base["experimental_capture_locality"] and
            record["placed_reduction_plan"] == selected.specifications(base) and
            record["input_sha256"] == {**parent_profile["input_sha256"], str(SELECTED_PROFILE): SELECTED_PROFILE_SHA} and
            record["profile_sha256"] == SELECTED_PROFILE_SHA and record["runner_sha256"] == SELECTED_RUNNER_SHA and
            record["compiler_commit"] == source["result_commit"] and record["base_compiler_commit"] == fast.BASE_COMMIT and
            record["source_identity_sha256"] == fast.SOURCE_SHA and record["disabled_control_sha256"] == fast.CONTROL_SHA and
            record["source_archive_sha256"] == source["source_archive_sha256"] and
            record["tool_identity"] == tool_identity(fast.BASE_COMMIT, source) and record["cwd"] == base["cwd"] and
            record["remap_plan"] == base["remap_plan"] and
            record["remap_plan_sha256"] == audit.bind(INITIAL / "local-plan.json") and
            record["reference_run_sha256"] == audit.bind(fast.FULL / "run.json") and
            record["measured_compiler_commit"] == base["compiler_commit"] and record["compiler_bytes_unchanged"] is False and
            record["compiler_bytes_unchanged_from_fresh_eleven_listing"] is True and
            record["initial_eleven_proof_sha256"] == FIRST_PROOF_SHA and
            record["initial_comparator_sha256"] == FIRST_PURE_HELPER_SHA and
            record["initial_generator_sha256"] == FIRST_GENERATOR_SHA and
            record["initial_pure_helper_sha256"] == FIRST_PURE_HELPER_SHA and
            record["initial_eleven_proof_path"] == str(FIRST_PROOF_PATH) and
            record["listing_lineage"] == {"eleven_listing": str(INITIAL / "list-eleven"),
                                         "own_unbalanced_baseline": str(INITIAL / "baseline-placement")} and
            record["parent_qualification_inherited"] is False and record["initial_current_proof_qualification_used"] is True and
            record["eleven_selection"] == SELECTED_ELEVEN and record["twelve_selection"] == -1 and
            record["reduction_selection"] == -1 and record["decomposition_selection"] is None and
            record["decomposition_report_sha256"] is None and record["list_only"] is True and record["fresh_listing"] is True and
            record["retained_stage_minimum_branch_gain_ps"] == DEFAULT_MINIMUM_PS and
            record["new_stage_minimum_branch_gain_ps"] == MINIMUM_PS and record["diagnostic_token_counts"] == [3, 4] and
            record["expected_nondefault_minimum_log"] == MINIMUM_LOG and record["minimum_log_verified"] is True and
            record["hardware_acceptance"] is False and record["completed"] is True and
            type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0 and not any(key in record for key in
                ("failure", "exit_code_is_adapter_sentinel", "fmax", "final_reported_hold_violations")),
            "actual selected-listing command/environment/source/qualification/runtime aliases changed")
    log = (SELECTED_FOLDER / "route.log").read_text()
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            [line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line] == [MINIMUM_LOG] and
            not any(marker in log for marker in ("Decomposition", "Running the GPU router", "Running signoff timing analysis")) and
            not any((SELECTED_FOLDER / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
            "selected prerequisite produced a later stage or failed")
    fast.runtime(audit, record, base)
    proof = bind_proof(audit, SELECTED_PROOF_PATH, SELECTED_PROOF_SHA)
    require(proof["phase"] == "list-twelve" and proof["candidate_completed"] is True and
            proof["compiler_commit"] == source["result_commit"] and proof["profile_sha256"] == SELECTED_PROFILE_SHA and
            proof["initial_eleven_proof_sha256"] == FIRST_PROOF_SHA and
            proof["initial_generator_sha256"] == FIRST_GENERATOR_SHA and proof["initial_pure_helper_sha256"] == FIRST_PURE_HELPER_SHA and
            proof["selected_eleven_ordinal"] == SELECTED_ELEVEN and proof["initial_current_proof_qualification_used"] is True and
            proof["parent_qualification_inherited"] is False and proof["cached_old_comparisons_reexecuted"] is False and
            proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False and
            proof["route_started"] is False and proof["timing_acceptance_available"] is False and
            proof["matched_placement_metrics"] == 71 and proof["placement_metrics_identical"] is True and
            proof["final_metadata_stable_during_comparison"] is True and
            proof["qualified_twelve_ordinals"] == proof["new12_qualification"]["qualified_ordinals"] ==
            list(range(proof["new12_qualification"]["qualified_candidates"])) and
            SELECTED_TWELVE in proof["qualified_twelve_ordinals"] and
            proof["new12_qualification"]["minimum_branch_gain_ps"] == MINIMUM_PS and
            proof["new12_qualification"]["none_applied"] is True and
            proof["actual_twelve_downstream_closure"]["endpoint_count"] == 227 and
            proof["source_twelve_conditional_cube"]["assignments_checked"] == 4096 and
            proof["rolled_back_twelve_conditional_cube"]["assignments_checked"] == 4096 and
            proof["applied_eleven_evidence"]["actual_conditional_cube"]["assignments_checked"] == 2048,
            "selected proof is not a complete fresh conditional qualification")
    candidate = [row for row in proof["new12_qualification"]["candidates"] if row["candidate"] == SELECTED_TWELVE]
    require(len(candidate) == 1 and candidate[0]["guards"] == [1, 1, 1, 1] and
            candidate[0]["branch_gain_ps"] >= MINIMUM_PS and candidate[0]["endpoints"] == 227,
            "selected twelve ordinal lacks its actual guarded endpoint closure")
    required = {SELECTED_PROFILE, FIRST_PROOF_PATH, FIRST_GENERATOR_PATH,
                *(SELECTED / name for name in ("seal_profile.py", "route.py", "compare_selected11.py")),
                *(SELECTED_FOLDER / name for name in ("run.json", "route.log", "placed.json"))}
    require(all(proof["artifact_sha256"].get(relative(path)) == audit.bind(path) for path in required) and
            all(proof["artifact_sha256"].get(relative(Path(filename))) == digest
                for filename, digest in record["input_sha256"].items()) and
            proof["execution_file_sha256"] == record["execution"]["files"],
            "selected proof omits its actual producer/run/input/runtime closure")
    return g8, base, source, control, {"record": record, "proof": proof, "first_record": first_record,
        "first_proof": first_proof, "baseline_record": baseline, "selected_profile": parent_profile,
        "audit": audit, "fast": fast, "selected": selected, "selected_candidate": candidate[0]}


def tool_identity(base_commit, source):
    return f"base_commit={base_commit}; experimental_source_sha256={source['source_archive_sha256']}; sha256={source['binary_sha256']}"


def phase_folder(phase="list-ac"):
    require(phase in PHASES and type(SELECTED_TWELVE) is int and SELECTED_TWELVE >= 0,
            "unknown phase or unpinned twelve ordinal")
    return HERE / f"list-ac-e{SELECTED_ELEVEN}-t{SELECTED_TWELVE}"


def specifications(base, phase="list-ac"):
    require(phase in PHASES, "only a fresh unselected AC listing is enabled")
    old = base["experimental_placed_reduction"].split()
    require(len(old) == 3 and old[1:] == ["6", "0"], "measured eleven root/radius changed")
    return [{"root": old[0], "radius": 6, "candidate": SELECTED_ELEVEN, "minimum_branch_gain_ps": DEFAULT_MINIMUM_PS},
            {"root": TWELVE_ROOT, "radius": 6, "candidate": SELECTED_TWELVE, "minimum_branch_gain_ps": MINIMUM_PS}]


def decomposition_guide(base):
    command = base["command"]
    require(command.count("--remap-decompose-critical") == command.count("--remap-decompose-candidate") == 1,
            "retained decomposition guide is ambiguous")
    index = command.index("--remap-decompose-critical")
    report = Path(command[index + 1])
    require(report.is_absolute() and command[command.index("--remap-decompose-candidate") + 1] == "0" and
            base["input_sha256"].get(str(report)) == base["decomposition_report_sha256"], "retained AC guide identity changed")
    return report, base["decomposition_report_sha256"]


def expected_diagnostic_environment(base, phase="list-ac"):
    first, second = specifications(base, phase)
    return {"NEXTPNR_MISTRAL_CAPTURE_LOCALITY": base["experimental_capture_locality"],
            "NEXTPNR_MISTRAL_PLACED_REDUCTION":
            f"{first['root']} 6 {first['candidate']}\n{second['root']} 6 {second['candidate']} {MINIMUM_PS}"}


def expected_command(base, phase="list-ac", selected=None):
    selected = selected_primitives() if selected is None else selected
    command = selected.expected_command(base)
    old_output = str(SELECTED_FOLDER / "placed.json")
    require(command.count(old_output) == 1 and command.count("--no-route") == 1 and not any(
        token in command for token in ("--report", "--rbf", "--router", "--gpu-device", "--gpu-opt",
                                      "--remap-decompose-critical", "--remap-decompose-candidate")),
        "selected command already contains a later transform/router output")
    report, _ = decomposition_guide(base)
    return [str(phase_folder(phase) / "placed.json") if token == old_output else token for token in command] + \
        ["--remap-decompose-critical", str(report), "--remap-decompose-candidate", "-1"]


def profile_aliases(base, source, prior):
    report, digest = decomposition_guide(base)
    return {"schema": 1, "scope": "fresh selected eleven and twelve followed by unselected AC listing only",
        "compiler_commit": source["result_commit"], "base_compiler_commit": prior["fast"].BASE_COMMIT,
        "source_identity_sha256": prior["fast"].SOURCE_SHA, "disabled_control_sha256": prior["fast"].CONTROL_SHA,
        "source_archive_sha256": source["source_archive_sha256"], "binary_sha256": source["binary_sha256"],
        "first_proof_sha256": FIRST_PROOF_SHA, "first_generator_sha256": FIRST_GENERATOR_SHA,
        "first_pure_helper_sha256": FIRST_PURE_HELPER_SHA, "selected_profile_sha256": SELECTED_PROFILE_SHA,
        "selected_twelve_proof_sha256": SELECTED_PROOF_SHA, "selected_comparator_sha256": SELECTED_COMPARATOR_SHA,
        "selected_eleven_ordinal": SELECTED_ELEVEN, "selected_twelve_ordinal": SELECTED_TWELVE,
        "placed_reduction_plan": specifications(base), "decomposition_report": str(report),
        "decomposition_report_sha256": digest, "decomposition_selection": -1,
        "diagnostic_token_counts": [3, 4], "expected_nondefault_minimum_log": MINIMUM_LOG,
        "initial_current_proof_qualification_used": True, "selected_current_proof_qualification_used": True,
        "parent_qualification_inherited": False, "ac_qualification_inherited": False, "route_phase_allowed": False,
        "default_recipe_selected": False, "hardware_tested": False}


def input_map(prior):
    audit = prior["audit"]
    inputs = dict(prior["selected_profile"]["input_sha256"])
    for filename, digest in prior["proof"]["artifact_sha256"].items():
        path = str((ROOT / filename).resolve())
        require(path not in inputs or inputs[path] == digest, "conflicting cached input identity")
        inputs[path] = digest
    for path, digest in ((SELECTED_PROFILE, SELECTED_PROFILE_SHA), (FIRST_PROOF_PATH, FIRST_PROOF_SHA),
                         (SELECTED_PROOF_PATH, SELECTED_PROOF_SHA)):
        inputs[str(path)] = audit.bind(path, digest)
    for path in (Path(__file__).resolve(), HERE / "route.py", HERE / "compare_applied.py"):
        inputs[str(path)] = audit.bind(path)
    return inputs


def load_profile():
    g8, base, source, control, prior = cached_context()
    audit = prior["audit"]
    audit.bind(PROFILE)
    profile = read(PROFILE)
    aliases = profile_aliases(base, source, prior)
    require(set(profile) == set(aliases) | {"input_sha256"} and
            all(profile[key] == value for key, value in aliases.items()) and
            profile["input_sha256"] == input_map(prior), "staged profile aliases or exact input closure changed")
    return profile, g8, base, source, control, prior


def sealed_input_map(profile):
    return {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}


def record_template(profile, base, source, prior, execution, phase="list-ac"):
    fast = prior["fast"]
    environment = expected_diagnostic_environment(base, phase)
    report, digest = decomposition_guide(base)
    record = {**base, "kind": "generic narrow-search fresh selected11/12 and unselected AC",
        "phase": phase, "command": expected_command(base, phase, prior["selected"]),
        "diagnostic_environment": environment, "placed_reduction_plan": specifications(base, phase),
        "experimental_placed_reduction": environment["NEXTPNR_MISTRAL_PLACED_REDUCTION"],
        "eleven_selection": SELECTED_ELEVEN, "twelve_selection": SELECTED_TWELVE, "reduction_selection": SELECTED_TWELVE,
        "decomposition_selection": -1, "decomposition_report_sha256": digest,
        "compiler_commit": source["result_commit"], "base_compiler_commit": fast.BASE_COMMIT,
        "measured_compiler_commit": base["compiler_commit"], "compiler_bytes_unchanged": False,
        "compiler_bytes_unchanged_from_fresh_eleven_listing": True,
        "source_identity_sha256": fast.SOURCE_SHA, "source_archive_sha256": source["source_archive_sha256"],
        "disabled_control_sha256": fast.CONTROL_SHA, "profile_sha256": sha(PROFILE), "runner_sha256": sha(HERE / "route.py"),
        "reference_run_sha256": prior["audit"].bind(fast.FULL / "run.json"),
        "remap_plan_sha256": prior["audit"].bind(INITIAL / "local-plan.json"),
        "initial_eleven_proof_sha256": FIRST_PROOF_SHA, "initial_generator_sha256": FIRST_GENERATOR_SHA,
        "initial_pure_helper_sha256": FIRST_PURE_HELPER_SHA,
        "selected_twelve_proof_sha256": SELECTED_PROOF_SHA, "selected_profile_sha256": SELECTED_PROFILE_SHA,
        "selected_comparator_sha256": SELECTED_COMPARATOR_SHA,
        "initial_current_proof_qualification_used": True, "selected_current_proof_qualification_used": True,
        "parent_qualification_inherited": False, "ac_qualification_inherited": False,
        "retained_stage_minimum_branch_gain_ps": DEFAULT_MINIMUM_PS, "new_stage_minimum_branch_gain_ps": MINIMUM_PS,
        "diagnostic_token_counts": [3, 4], "expected_nondefault_minimum_log": MINIMUM_LOG,
        "minimum_log_verified": False, "listing_lineage": {"eleven_listing": str(INITIAL / "list-eleven"),
            "own_unbalanced_baseline": str(INITIAL / "baseline-placement"), "twelve_listing": str(SELECTED_FOLDER)},
        "tool_identity": tool_identity(fast.BASE_COMMIT, source), "list_only": True, "fresh_listing": True,
        "execution": execution, "input_sha256": sealed_input_map(profile), "completed": False, "hardware_acceptance": False}
    for key in ("elapsed_seconds", "exit_code", "failure", "fmax", "final_reported_hold_violations", "exit_code_is_adapter_sentinel"):
        record.pop(key, None)
    return record


def authenticate_phase(record, context):
    profile, _, base, source, _, prior = context
    phase = record["phase"]
    expected = record_template(profile, base, source, prior, record["execution"], phase)
    state = {"elapsed_seconds", "exit_code", "failure", "exit_code_is_adapter_sentinel", "completed", "minimum_log_verified"}
    require({key: value for key, value in record.items() if key not in state} ==
            {key: value for key, value in expected.items() if key not in state},
            "actual staged command/environment/source/profile/dependency or inherited field changed")
    require(type(record["completed"]) is bool and type(record["minimum_log_verified"]) is bool and "failure" not in record,
            "staged state is malformed or has a recorded failure")
    prior["fast"].runtime(prior["audit"], record, base)
    if record["completed"]:
        lines = [line for line in (phase_folder(phase) / "route.log").read_text().splitlines()
                 if "Placed reduction minimum branch gain:" in line]
        require(record["minimum_log_verified"] is True and lines == [MINIMUM_LOG], "completed staged listing lacks its exact200 minimum")
    report, digest = decomposition_guide(base)
    prior["audit"].bind(report, digest)
    return {"phase": phase, "folder": phase_folder(phase), "specs": specifications(base, phase),
            "reduction_steps": specifications(base, phase), "command": expected["command"],
            "environment": expected["diagnostic_environment"], "ac_selection": -1,
            "report_path": report, "report_sha256": digest}


def main():
    require(not PROFILE.exists(), "staged profile already exists")
    _, base, source, _, prior = cached_context()
    inputs = input_map(prior)
    profile = {**profile_aliases(base, source, prior), "input_sha256": inputs}
    prior["audit"].finish()
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"profile_sha256": sha(PROFILE), "sealed_inputs": len(inputs),
                      "selected_twelve_ordinal": SELECTED_TWELVE, "scope": profile["scope"]}, indent=2))


if __name__ == "__main__":
    main()
