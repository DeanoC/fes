"""Root-operated partial proof of selected11/12 and fresh rolled-back AC listing.

Actual pre-route masks are checked under explicitly unproved plain-SIG pin states.
No applied AC clone truth, routed pin/BUF/clock/hold/RBF acceptance is claimed.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re

import seal_profile as seal

HERE, ROOT = seal.HERE, seal.ROOT
require, read, sha = seal.require, seal.read, seal.sha
PINS = "ABCDEF"
HEADER = re.compile(r"^Info: Placed reduction stage (\d+): root=(\S+) radius=(\d+) selection=(-?\d+)\.$", re.M)
TRIAL = re.compile(
    r"^Info: Placed reduction trial root=(\S+) leaves=(\S+) "
    r"branch_gain=([+-]?\d+(?:\.\d+)?)ps endpoint_gain=([+-]?\d+(?:\.\d+)?)ps "
    r"improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])\.$")
CANDIDATE = re.compile(r"^Info: Placed reduction candidate (\d+), (\d+) endpoints, branch gain ([+-]?\d+(?:\.\d+)?)ps\.$")
BEL = re.compile(r"MISTRAL_(?:M)?COMB\.(\d+)\.(\d+)\.(\d+)")


def relative(path):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT), "artifact lies outside the active FES checkout")
    return str(path.relative_to(ROOT))


def serial(value):
    return json.loads(json.dumps(value))


def top(g8, folder):
    document = g8.read_netlist(folder / "placed.json")
    require(set(document["modules"]) == {"top"}, "unexpected exported module set")
    return document["modules"]["top"]


def graph(g8, module):
    return g8.Netlist(module["cells"], module["netnames"])


def stage_blocks(log, specs):
    matches = list(HEADER.finditer(log))
    require(len(matches) == len(specs) == 2, "selected listing lacks exactly two attributed stage headers")
    prefix = log[:matches[0].start()]
    require(not any(marker in prefix for marker in ("Placed reduction", "Balanced three-LUT reduction")),
            "placed-reduction messages occur before the attributed stages")
    blocks = []
    for index, match in enumerate(matches):
        spec = specs[index]
        require(match.groups() == (str(index), spec["root"], str(spec["radius"]), str(spec["candidate"])),
                "actual stage header disagrees with its sealed specification")
        end = matches[index + 1].start() if index + 1 < len(matches) else len(log)
        blocks.append(log[match.end():end])
    require([line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line] == [seal.MINIMUM_LOG],
            "selected listing lacks exactly one explicit minimum200 diagnostic")
    return prefix, blocks


def qualification(block, spec, endpoints, literal_count):
    minimum, selection = spec["minimum_branch_gain_ps"], spec["candidate"]
    root = spec["root"]
    balanced = f"Info: Balanced three-LUT reduction at '{root}' into {(literal_count + 1) // 2}+{literal_count // 2} inputs."
    trials, candidates, pending, geometries = [], [], None, set()
    started, finished, minimum_seen = False, False, False
    for line in block.splitlines():
        if line == seal.MINIMUM_LOG:
            require(minimum == 200 and not minimum_seen and not started, "minimum200 diagnostic is misplaced")
            minimum_seen = True
        elif line == balanced:
            require(not started and not finished and (minimum == 250 or minimum_seen), "rewrite discovery repeated or preceded its minimum")
            started = True
        elif line.startswith("Info: Placed reduction trial "):
            require(started and not finished, "trial lies outside its discovered stage")
            match = TRIAL.fullmatch(line)
            require(match and match[1] == root, "malformed or misattributed trial")
            bels = match[2].split(",")
            require(len(bels) == len(set(bels)) == 2 and all(BEL.fullmatch(bel) for bel in bels), "trial lacks two distinct COMB BELs")
            geometry = tuple(tuple(int(value) for value in BEL.fullmatch(bel).groups()[:2]) for bel in bels)
            require(geometry not in geometries, "ordered leaf LAB geometry was timed twice")
            geometries.add(geometry)
            gain, endpoint_gain = float(match[3]), float(match[4])
            guards = [int(value) for value in match.groups()[4:]]
            require(math.isfinite(gain) and math.isfinite(endpoint_gain) and
                    guards[0] == int(gain > 0 and gain >= minimum) and (not guards[1] or endpoint_gain >= 0),
                    "trial qualification guard differs from its logged margin")
            pending = {"root": root, "leaf_bels": bels, "branch_gain_ps": gain,
                       "endpoint_gain_ps": endpoint_gain, "guards": guards, "trial_log": line}
            trials.append(pending)
        elif line.startswith("Info: Placed reduction candidate "):
            require(started and not finished, "candidate lies outside its discovered stage")
            match = CANDIDATE.fullmatch(line)
            require(match and pending and int(match[1]) == len(candidates) and int(match[2]) == endpoints and
                    pending["guards"] == [1, 1, 1, 1] and pending["branch_gain_ps"] >= minimum and
                    float(match[3]) == pending["branch_gain_ps"], "candidate lacks its consecutive ordinal and guarded trial")
            candidates.append({**pending, "candidate": int(match[1]), "endpoints": int(match[2]), "candidate_log": line})
            pending = None
        elif line.startswith("Info: Placed reduction: "):
            require(selection == -1 and started and not finished and line ==
                    f"Info: Placed reduction: {len(candidates)} qualified candidates; none applied.",
                    "listing completion disagrees with its actual candidates")
            finished = True
        elif "Placed reduction" in line or "Balanced three-LUT reduction" in line:
            require(False, "unsupported diagnostic within an attributed stage")
    require(started and block.count(balanced) == 1 and len(trials) <= 16 and
            sum(trial["guards"] == [1, 1, 1, 1] for trial in trials) == len(candidates) and
            minimum_seen is (minimum == 200), "stage did not complete bounded guarded qualification")
    require((selection == -1 and finished) or
            (selection >= 0 and not finished and len(candidates) == selection + 1 and pending is None),
            "selected stage did not stop at its ordinal, or final listing did not roll back")
    return {"minimum_branch_gain_ps": minimum, "selection": selection, "timed_trial_count": len(trials),
            "qualified_candidates": len(candidates), "qualified_ordinals": list(range(len(candidates))),
            "trials": trials, "candidates": candidates, "none_applied": selection == -1,
            "modeled_qualification_only_no_routed_timing_claim": True}


def conditional_cube(g8, module, root, count, reference):
    """Actual masks/connectivity, with every unavailable logical pin assumed SIG."""
    netlist = graph(g8, module)
    cone, literals, nodes = set(), {}, []
    def descend(token, required):
        require(len(token) == 3 and token[0] in netlist.cells and token[1:] == ("Q", 0), "cube has an unsupported native driver")
        name, cell = token[0], netlist.cells[token[0]]
        if not g8.ready.is_lut(cell):
            require(cell["type"] == "MISTRAL_FF" and token not in literals, "cube repeats a boundary or has a non-FFQ boundary")
            literals[token] = required
            return
        require(name not in cone and len(cone) < 3, "cube is cyclic, reconvergent or too large")
        cone.add(name)
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        ports = {**{pin: "input" for pin in PINS[:width]}, "Q": "output"}
        table = cell["parameters"].get("LUT")
        require(2 <= width <= 6 and cell["port_directions"] == ports and set(cell["connections"]) == set(ports) and
                all(type(bits) is list and len(bits) == 1 for bits in cell["connections"].values()) and
                set(cell["parameters"]) == {"LUT"} and type(table) is str and len(table) == 1 << width and
                set(table) <= {"0", "1"} and not cell["attributes"].get("FES_PINMAP_V1"), "cube has an invalid scalar LUT/schema or partial pins")
        mask = int(table, 2)
        matches = [row for row in range(1 << width) if bool((mask >> row) & 1) == required]
        require(len(matches) == 1, "raw conditional node is not a one-row cube")
        row = matches[0]
        for bit, pin in enumerate(PINS[:width]):
            descend(netlist.token(cell["connections"][pin][0]), bool((row >> bit) & 1))
        nodes.append({"cell": name, "type": cell["type"], "mask_hex": hex(mask),
                      "required_output": required, "unique_required_row": row,
                      "rows_checked": 1 << width, "bel": g8.previous.bel(cell)})
    descend((root, "Q", 0), True)
    require(len(cone) == 3 and len(literals) == count, "source is not the declared three-cell literal cube")
    top_tokens = {netlist.token(bit) for port in module["ports"].values() for bit in port["bits"]}
    for name in cone - {root}:
        users = netlist.direct_users.get((name, "Q", 0), [])
        require((name, "Q", 0) not in top_tokens and len(users) == 1 and users[0][0] in cone, "cube intermediate is not private")
    for token in literals:
        require(sum(user[0] in cone for user in netlist.direct_users.get(token, [])) == 1, "cube repeats an external source")
    boundary = sorted(literals)
    def evaluate(token, values):
        if token in values:
            return values[token]
        cell = netlist.cells[token[0]]
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        address = sum(evaluate(netlist.token(cell["connections"][pin][0]), values) << bit for bit, pin in enumerate(PINS[:width]))
        return (int(cell["parameters"]["LUT"], 2) >> address) & 1
    expected = sum(int(literals[token]) << bit for bit, token in enumerate(boundary))
    table = []
    for row in range(1 << count):
        values = {token: (row >> bit) & 1 for bit, token in enumerate(boundary)}
        value = evaluate((root, "Q", 0), values)
        require(value == int(row == expected), "conditional cube truth differs on row " + str(row))
        table.append(value)
    require(g8.essential(table, count) == set(range(count)), "cube contains an inessential literal")
    return {"root": root, "source_reference": relative(reference), "source_cone": sorted(cone), "source_nodes": nodes,
            "external_boundary_order": boundary, "conditional_required_values": [literals[token] for token in boundary],
            "assignments_checked": 1 << count, "true_rows": sum(table), "conditional_true_row": expected,
            "truth_sha256": hashlib.sha256(bytes(table)).hexdigest(),
            "raw_masks_and_native_ffq_identities_from_actual_supplied_placement": True,
            "all_lut_and_boundary_logical_pin_states_assumed_plain_signal": True,
            "independent_actual_listing_pin_polarity_truth_proved": False}, cone, literals


def cell_schema(g8, old, new, name, width, movable):
    before, after = old.cells[name], new.cells[name]
    mutable = {"type", "parameters", "port_directions", "connections", "attributes"}
    require({key: value for key, value in before.items() if key not in mutable} ==
            {key: value for key, value in after.items() if key not in mutable}, "declared cell changed unknown metadata: " + name)
    table = after["parameters"].get("LUT")
    require(after["type"] == f"MISTRAL_ALUT{width}" and set(before["parameters"]) == set(after["parameters"]) == {"LUT"} and
            type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"}, "declared cell LUT schema changed: " + name)
    allowed = {"NEXTPNR_BEL"} if movable else set()
    require({key: value for key, value in before["attributes"].items() if key not in allowed} ==
            {key: value for key, value in after["attributes"].items() if key not in allowed}, "declared cell changed non-placement attributes: " + name)


def applied_reduction(g8, baseline_top, candidate_top, cached, selected, root, count, baseline_path, candidate_path):
    require(count in (11, 12), "only the declared eleven/twelve literal stages are supported")
    source, cone, literals = conditional_cube(g8, baseline_top, root, count, baseline_path)
    current, new_cone, new_literals = conditional_cube(g8, candidate_top, root, count, candidate_path)
    for key in ("root", "source_cone", "source_nodes", "external_boundary_order", "conditional_required_values",
                "assignments_checked", "true_rows", "conditional_true_row", "truth_sha256"):
        require(serial(source[key]) == cached[key], "actual source differs from cached fresh cube: " + key)
    require(cone == new_cone and literals == new_literals and source["truth_sha256"] == current["truth_sha256"],
            "selected reduction changed original support or conditional truth")
    old, new = graph(g8, baseline_top), graph(g8, candidate_top)
    leaves = sorted(cone - {root})
    require(g8.previous.bel(old.cells[root]) == g8.previous.bel(new.cells[root]) and
            int(new.cells[root]["parameters"]["LUT"], 2) == 8 and
            new.inputs(root) == {pin: [(name, "Q", 0)] for pin, name in zip("AB", leaves)},
            "public root moved or is not the direct ordered two-leaf AND")
    cell_schema(g8, old, new, root, 2, False)
    require([g8.previous.bel(new.cells[name]) for name in leaves] == selected["leaf_bels"],
            "actual selected leaf BELs differ from the fresh guarded trial")
    partitions = []
    for index, name in enumerate(leaves):
        width = (count + 1) // 2 if index == 0 else count // 2
        cell_schema(g8, old, new, name, width, True)
        inputs = [new.token(new.cells[name]["connections"][pin][0]) for pin in PINS[:width]]
        require(len(inputs) == len(set(inputs)) == width and set(inputs) <= set(literals), "reduction leaf has a repeated or new literal")
        require(new.direct_users.get((name, "Q", 0), []) == [(root, "AB"[index], 0)], "reduction leaf output acquired a side user")
        partitions.append(set(inputs))
    require(partitions[0].isdisjoint(partitions[1]) and partitions[0] | partitions[1] == set(literals),
            "selected leaves do not partition all original inputs")
    require(old.direct_users.get((root, "Q", 0), []) == new.direct_users.get((root, "Q", 0), []), "public root users changed")
    return {"root": root, "reused_cells": sorted(cone), "reused_leaves": leaves,
            "source_conditional_cube": source, "actual_conditional_cube": current, "selected_trial": selected,
            "public_root_bel_output_net_and_consumers_preserved": True,
            "three_existing_cells_reused_without_owner_or_output_net_additions": True,
            "current_pin_states_and_physical_mapping_available": False}, cone


def outside_graph(g8, baseline_top, candidate_top, cone):
    old, new = graph(g8, baseline_top), graph(g8, candidate_top)
    require(set(old.cells) == set(new.cells) and not any(cell["type"] == "MISTRAL_BUF" for cell in new.cells.values()),
            "pre-route selected listing changed owners or contains route-created buffers")
    for name in old.cells:
        if name not in cone:
            require(g8.dictionary_cell(old, name) == g8.dictionary_cell(new, name) and
                    g8.direct_connections(old, name) == g8.direct_connections(new, name), "outside declared twelve cells changed: " + name)
        require(new.cells[name]["attributes"].get("NEXTPNR_BEL") and not new.cells[name]["attributes"].get("FES_PINMAP_V1"),
                "selected listing has an unplaced cell or partial physical pin export")
    for token in set(old.direct_users) | set(new.direct_users):
        before, after = old.direct_users.get(token, []), new.direct_users.get(token, [])
        require([user for user in before if user[0] not in cone] == [user for user in after if user[0] not in cone],
                "an outside named consumer entry changed: " + repr(token))
        require(sum(user[0] in cone for user in before) == sum(user[0] in cone for user in after),
                "a declared twelve input changed its native source consumer multiplicity")
    g8.compare_named_nets(baseline_top, candidate_top, old, new)
    g8.ranking.top_ports(baseline_top, candidate_top, old, new)
    require({key: value for key, value in baseline_top.items() if key not in {"cells", "netnames", "ports"}} ==
            {key: value for key, value in candidate_top.items() if key not in {"cells", "netnames", "ports"}} and
            not candidate_top["attributes"].get("FES_LABSTATE_V1"), "same-phase settings/attributes changed or routed LAB state appeared")
    orders = {}
    for dictionary in ("cells", "netnames"):
        names = list(baseline_top[dictionary])
        require(names == list(candidate_top[dictionary]), "original named owner export order changed")
        orders[dictionary] = {"count": len(names), "exact_name_order_identical": True,
                              "name_order_sha256": hashlib.sha256("\n".join(names).encode()).hexdigest()}
    return {"exact_outside_declared_three_cell_dictionaries_and_native_consumers": True,
            "all_original_ff_named_connections_bels_and_attributes_exact": True,
            "all_named_net_aliases_metadata_and_public_ports_preserved": True,
            "all_unmodified_input_consumer_entries_preserved": True, "only_derived_twelve_cone_input_entries_replaced": True,
            "named_owner_export_order": orders, "lossless_pll_port_audit": g8.pll_port_audit(old, new),
            "indexed_user_slots_free_lists_or_owner_bucket_identity_proved": False,
            "current_full_logical_physical_pin_or_route_buffer_preservation_proved": False}


def downstream(g8, module, root):
    netlist = graph(g8, module)
    visited, active, endpoints = set(), set(), set()
    def collect(token):
        require(token not in active and token not in visited and len(visited) + len(active) < 64,
                "narrow endpoint closure is cyclic, reconvergent or too large")
        active.add(token)
        for name, pin, index in netlist.direct_users.get(token, []):
            cell = netlist.cells[name]
            require(index == 0 and cell["port_directions"].get(pin) == "input", "endpoint edge is not a scalar input")
            if g8.ready.is_lut(cell):
                collect((name, "Q", 0))
            else:
                require(cell["type"] == "MISTRAL_FF" and pin != "CLK", "endpoint is not an ordinary FF input")
                endpoints.add((name, pin, index))
        active.remove(token)
        visited.add(token)
    collect((root, "Q", 0))
    require(endpoints, "twelve source has no ordinary endpoint")
    return {"net_count": len(visited), "nets": sorted(visited), "endpoint_count": len(endpoints), "ff_inputs": sorted(endpoints)}


def upstream_messages(log):
    markers = ("Balanced four-LUT reduction", "Enable replication", "Local-remap plan step ",
               "Local remap ", "Comb remap ", "Capture locality")
    return [line for line in log.splitlines() if any(marker in line for marker in markers)]


def conditional_ac_source(g8, module, cached, guide, candidates):
    """Source-only rows on authenticated identities, never absent encoder masks."""
    netlist = graph(g8, module)
    edge = cached["selected_internal_input"]
    root = tuple(edge["control_driver"])
    boundary = [tuple(token) for token in cached["boundary_order"]]
    nodes = set(cached["original_cut_nodes"])
    require(len(boundary) == len(set(boundary)) == 7 and len(nodes) == 4 and root[0] in nodes and
            all(len(token) == 3 and token[0] in netlist.cells and token[1:] == ("Q", 0) for token in boundary),
            "cached source-only AC boundary/cone identity is invalid")
    require(netlist.inputs(edge["sink"])[edge["port"]] == [root], "actual pre-route original AC sink edge is stale")
    shapes = {}
    for name in nodes:
        cell = netlist.cells[name]
        require(g8.ready.is_lut(cell) and not cell["attributes"].get("FES_PINMAP_V1"),
                "conditional AC source is not an ordinary raw pre-route LUT")
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        ports = {**{pin: "input" for pin in PINS[:width]}, "Q": "output"}
        table = cell["parameters"].get("LUT")
        require(2 <= width <= 6 and cell["port_directions"] == ports and set(cell["connections"]) == set(ports) and
                all(len(bits) == 1 for bits in cell["connections"].values()) and set(cell["parameters"]) == {"LUT"} and
                type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"},
                "conditional AC source LUT schema/mask is invalid")
        inputs = [netlist.token(cell["connections"][pin][0]) for pin in PINS[:width]]
        require(all(token in boundary or (len(token) == 3 and token[0] in nodes and token[1:] == ("Q", 0))
                    for token in inputs), "conditional AC source has an undeclared boundary/constant")
        shapes[name] = (int(table, 2), inputs)
    table, visited = [], set()
    def evaluate(token, values, active):
        if token in values:
            return values[token]
        require(token[0] in shapes and token not in active, "conditional AC source is cyclic or outside its four-node cone")
        active.add(token)
        visited.add(token[0])
        mask, inputs = shapes[token[0]]
        address = sum(evaluate(value, values, active) << index for index, value in enumerate(inputs))
        active.remove(token)
        return (mask >> address) & 1
    for row in range(128):
        table.append(evaluate(root, {token: (row >> index) & 1 for index, token in enumerate(boundary)}, set()))
    require(visited == nodes and g8.essential(table, 7) == set(range(7)) and
            table == [row["original"] for row in cached["truth_rows"]],
            "current conditional128 source differs from the authenticated seven-essential-input function")
    relevant = g8.relevant_guide_edges(netlist, {**edge, "control_driver": root}, guide)
    return {"original_root": root, "original_cut_nodes": sorted(nodes), "boundary_order": boundary,
            "assignments_checked": 128, "true_rows": sum(table), "truth_sha256": hashlib.sha256(bytes(table)).hexdigest(),
            "current_raw_four_lut_function_matches_cached_source_under_sig_assumption": True,
            "current_guide_path_indices": relevant,
            "fresh_logged_ordinals_with_same_root_and_sink": [int(match[1]) for match in candidates
                if (match[2], match[3], match[4]) == (root[0], edge["sink"], edge["port"])],
            "all_unexported_lut_and_boundary_logical_pin_states_assumed_plain_signal": True,
            "source_only_truth_not_applied_or_absent_encoder_equivalence": True,
            "logged_definition_four_node_membership_independently_proved": False}


def comparison(folder):
    folder = folder.resolve()
    context = seal.load_profile()
    profile, g8, base, source, control, prior = context
    audit = prior["audit"]
    require(folder.resolve() == seal.phase_folder("list-ac").resolve(), "only the fresh staged AC listing is supported")
    for path in (Path(__file__).resolve(), HERE / "seal_profile.py", HERE / "route.py", seal.PROFILE,
                 *(folder / name for name in ("run.json", "route.log", "placed.json"))):
        audit.bind(path)
    record = read(folder / "run.json")
    phase = seal.authenticate_phase(record, context=context)
    require(phase["phase"] == "list-ac" and phase["folder"].resolve() == folder.resolve() and
            phase["ac_selection"] == -1 and phase["specs"] == phase["reduction_steps"] and
            record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0 and not any(key in record for key in
            ("failure", "exit_code_is_adapter_sentinel", "fmax", "final_reported_hold_violations")),
            "staged AC listing is not finalized normal placement-only evidence")
    require(record["decomposition_selection"] == -1 and record["eleven_selection"] == 0 and
            record["twelve_selection"] == seal.SELECTED_TWELVE and record["reduction_selection"] == seal.SELECTED_TWELVE,
            "staged selected ordinals disagree with the authenticated phase")
    for filename, digest in record["input_sha256"].items():
        audit.bind(Path(filename), digest)
    for filename, digest in record["execution"]["files"].items():
        audit.bind(Path(filename), digest, execution=True)
    audit.bind(Path(phase["report_path"]), phase["report_sha256"])
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            not any(marker in log for marker in ("Running the GPU router", "Running signoff timing analysis")) and
            not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
            "staged listing ran routing/signoff or produced final outputs")
    discoveries = list(re.finditer(r"^Info: Decomposition discovery: (\d+) bounded seven-input cuts\.$", log, re.M))
    require(len(discoveries) == 1, "fresh AC discovery is absent/repeated")
    placed_log, ac_log = log[:discoveries[0].start()], log[discoveries[0].start():]
    require(not any(marker in ac_log for marker in ("Placed reduction", "Placed-reduction", "Balanced three-LUT reduction")) and
            "Info: Decomposition" not in placed_log, "selected placed stages and final AC listing are interleaved")
    specs = phase["specs"]
    require(len(specs) == 2 and specs[0]["candidate"] == 0 and specs[1]["candidate"] == seal.SELECTED_TWELVE and
            specs[0]["radius"] == specs[1]["radius"] == 6 and
            specs[0]["minimum_branch_gain_ps"] == 250 and specs[1]["minimum_branch_gain_ps"] == 200,
            "staged specification is not selected11/default250 then fresh selected12/min200")
    first_proof, selected_proof = prior["first_proof"], prior["proof"]
    selected_record = prior["record"]
    require(selected_proof["candidate_completed"] is True and selected_proof["partial_graph_evidence_available"] is True and
            selected_proof["graph_proof_available"] is False and selected_proof["parent_qualification_inherited"] is False and
            selected_record["compiler_commit"] == record["compiler_commit"] == source["result_commit"] and
            seal.SELECTED_TWELVE in selected_proof["qualified_twelve_ordinals"],
            "fresh selected12 qualification is absent or uses a different producer")
    selected_folder, baseline_folder = seal.SELECTED_FOLDER, seal.INITIAL / "baseline-placement"
    first_folder = seal.INITIAL / "list-eleven"
    for reference in (selected_folder, baseline_folder, first_folder):
        for name in ("run.json", "route.log", "placed.json"):
            audit.bind(reference / name)
    baseline_log, selected_log, first_log = [(reference / "route.log").read_text()
                                            for reference in (baseline_folder, selected_folder, first_folder)]
    metrics = [g8.previous.PLACEMENT_METRICS.findall(value) for value in (baseline_log, selected_log, first_log, log)]
    require(len(metrics[0]) == 71 and all(rows == metrics[0] for rows in metrics) and
            hashlib.sha256("\n".join(metrics[0]).encode()).hexdigest() == selected_proof["placement_metrics_sha256"] ==
            first_proof["placement_metrics_sha256"], "ordinary placement metrics differ from the authenticated fresh references")
    prefix, blocks = stage_blocks(placed_log, specs)
    require(upstream_messages(log) == upstream_messages(prefix) == upstream_messages(baseline_log) ==
            upstream_messages(selected_log) == upstream_messages(first_log), "retained local/comb/capture transform messages changed")
    baseline_top, selected_top, current_top = [top(g8, reference) for reference in (baseline_folder, selected_folder, folder)]
    closure11 = downstream(g8, baseline_top, specs[0]["root"])
    closure12 = downstream(g8, selected_top, specs[1]["root"])
    require(serial(closure11) == first_proof["actual_endpoint_closure"] and
            serial(closure12) == selected_proof["actual_twelve_downstream_closure"] and closure12["endpoint_count"] == 227 and
            downstream(g8, current_top, specs[1]["root"]) == closure12,
            "actual retained11 or selected12 complete endpoint closure changed")
    qualifications = [qualification(block, spec, closure["endpoint_count"], count)
                      for block, spec, closure, count in zip(blocks, specs, (closure11, closure12), (11, 12))]
    selected_trials = []
    for index, cached in enumerate((first_proof["qualification"], selected_proof["new12_qualification"])):
        matches = [row for row in cached["candidates"] if row["candidate"] == specs[index]["candidate"]]
        require(len(matches) == 1 and qualifications[index]["candidates"][-1] == matches[0],
                "selected reduction trial/BELs/gain/guards differ from its fresh qualification")
        selected_trials.append(matches[0])
    _, previous_blocks = stage_blocks(selected_log, [{**specs[0]}, {**specs[1], "candidate": -1}])
    for current_block, reference_block, trial in zip(blocks, previous_blocks, selected_trials):
        messages = lambda value: [line for line in value.splitlines()
                                  if "Placed reduction" in line or "Balanced three-LUT reduction" in line]
        current_messages, reference_messages = messages(current_block), messages(reference_block)
        require(reference_messages.count(trial["candidate_log"]) == 1 and current_messages ==
                reference_messages[:reference_messages.index(trial["candidate_log"]) + 1],
                "selected reduction discovery/trial/candidate prefix differs from its completed fresh listing")
    eleven, cone11 = applied_reduction(g8, baseline_top, current_top, first_proof["conditional_eleven_literal_cube"],
                                      selected_trials[0], specs[0]["root"], 11,
                                      baseline_folder / "placed.json", folder / "placed.json")
    twelve, cone12 = applied_reduction(g8, selected_top, current_top, selected_proof["rolled_back_twelve_conditional_cube"],
                                     selected_trials[1], specs[1]["root"], 12,
                                     selected_folder / "placed.json", folder / "placed.json")
    require(cone11.isdisjoint(cone12), "declared11/12 reused-cell cones overlap")
    outside = outside_graph(g8, selected_top, current_top, cone12)
    fresh_ac = g8.verify_decomposition_log(ac_log, -1)
    require(fresh_ac["log_complete"] is True and fresh_ac["none_applied"] is True,
            "final fresh AC listing did not restore every probe")
    ac_candidates = list(g8.CANDIDATE.finditer(ac_log))
    require(fresh_ac["qualified_candidates"] == len(ac_candidates), "fresh AC candidate count differs from actual ordinals")
    fast = prior["fast"]
    audit.bind(fast.FULL / "comparison.json", fast.FULL_PROOF_SHA)
    cached_ac = read(fast.FULL / "comparison.json")["decomposition_equivalence_on_ready_aligned_original_graph"]
    source_ac = conditional_ac_source(g8, current_top, cached_ac, read(Path(phase["report_path"])), ac_candidates)
    audit.finish()
    return {
        "phase": "list-ac", "status": "selected11/12 partial named proof; fresh AC rolled back; conditional truth only",
        "compiler_commit": source["result_commit"], "base_compiler_commit": record["base_compiler_commit"],
        "profile_sha256": sha(seal.PROFILE), "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "selected_eleven_ordinal": 0, "selected_twelve_ordinal": seal.SELECTED_TWELVE,
        "parent_qualification_inherited": False, "fresh_selected12_qualification_used": True,
        "qualified_ac_ordinals": list(range(len(ac_candidates))),
        "applied_eleven_evidence": eleven, "applied_twelve_evidence": twelve,
        "selected_reduction_qualifications_replayed_exactly": qualifications,
        "outside_declared_twelve_graph": outside, "actual_twelve_downstream_closure": closure12,
        "fresh_ac_qualification": fresh_ac,
        "current_conditional_ac_source128": source_ac,
        "fresh_ac_candidate_rows": [{"candidate": int(match[1]), "original_root": match[2], "sink": match[3],
                                     "port": match[4], "encoder_count": int(match[5]), "modeled_gain_ps": float(match[6])}
                                    for match in ac_candidates],
        "no_ac_owner_or_outside_declared_reduction_edge_survives_final_export": True,
        "applied_ac128_equivalence_proof_available": False,
        "graph_proof_available": False, "partial_graph_evidence_available": True,
        "route_started": False, "timing_acceptance_available": False,
        "matched_placement_metrics": 71, "placement_metrics_identical": True,
        "placement_metrics_sha256": hashlib.sha256("\n".join(metrics[0]).encode()).hexdigest(),
        "cached_old_comparisons_reexecuted": False, "default_recipe_selected": False, "hardware_tested": False,
        "final_metadata_stable_during_comparison": True,
        "execution_file_sha256": dict(sorted(audit.execution.items())),
        "artifact_sha256": dict(sorted(audit.artifacts.items())),
        "proof_limitations": [
            "Actual selected11/12 masks and all 2048 and 4096 rows assume missing LUT/boundary logical pin states are plain signal.",
            "Exactly three12 cells reuse original output nets with fixed public root and fresh leaf BELs; retained11/outside named graph and native users remain strict.",
            "Final AC qualification is fresh modeled log evidence; the export has no added AC owners and preserves edges outside the independently proved twelve-cell rewrite.",
            "No equivalence to absent AC encoder/root masks or applied AC128, current physical pin/LAB/BUF proof is claimed.",
            "The source-only conditional128 check uses authenticated four-node/boundary identities; it does not identify every logged definition's node set or prove absent encoder masks.",
            "Named owner order and consumer triples are observed; indexed slots/free lists, owner pointers/buckets are not serialized.",
            "No final setup/hold, timing acceptance, RBF or hardware claim follows; full native BUF/physical proof needs a separate profile.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    require(not (args.folder / "comparison.json").exists(), "comparison output already exists")
    result = comparison(args.folder)
    with (args.folder / "comparison.json").open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({key: result[key] for key in
                      ("phase", "candidate_completed", "graph_proof_available", "qualified_ac_ordinals")}, indent=2))


if __name__ == "__main__":
    main()
