"""Root-operated fresh selected11/12 prefix followed by AC-only listing."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

import seal_profile as seal


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", required=True, choices=seal.PHASES)
    args = parser.parse_args()
    context = seal.load_profile()
    profile, _, base, source, _, prior = context
    folder, inputs = seal.phase_folder(args.phase), seal.sealed_input_map(profile)
    seal.require(not folder.exists(), "staged output already exists")
    module = Path(base["cwd"])
    sys.path.insert(0, str(module))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    from scripts.search_placer_qor import has_failed_route_arc
    identity = seal.tool_identity(prior["fast"].BASE_COMMIT, source)
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(seal.INITIAL / "nextpnr-mistral", identity)}, 1)
    try:
        seal.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                     "ambient compiler diagnostic environment")
        record = seal.record_template(profile, base, source, prior, invocation.inputs, args.phase)
        seal.authenticate_phase(record, context)
        prior["audit"].finish()
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
        try:
            with (folder / "route.log").open("x") as log:
                result = audited_run(record["command"], source_root=module, cwd=module,
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log,
                    stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            invocation.verify()
            log = (folder / "route.log").read_text()
            seal.require(result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log),
                         "staged listing did not finish normally")
            seal.require((folder / "placed.json").is_file() and not any(marker in log for marker in
                ("Running the GPU router", "Running signoff timing analysis...", "Decomposition selected", "Decomposition applied")) and
                not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
                "AC listing routed, applied a clone or produced final outputs")
            minimum = [line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line]
            seal.require(minimum == [seal.MINIMUM_LOG], "staged listing lacks exactly one minimum200 log")
            completion = [line for line in log.splitlines() if line.startswith("Info: Decomposition: ")]
            seal.require(len(completion) == 1 and completion[0].endswith(" qualified candidates; no candidate applied."),
                         "AC stage is not a completed rolled-back listing")
            record["minimum_log_verified"], record["completed"] = True, True
            seal.authenticate_phase(record, context)
            prior["audit"].finish()
            print(json.dumps({key: record[key] for key in
                ("phase", "eleven_selection", "twelve_selection", "decomposition_selection", "completed", "exit_code", "elapsed_seconds")}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
