# RAM-test wide reduction experiment, 2026-09-29

Frozen input: `out/ramtest-merged-remap/measured-diagnostic/synth.json`, SHA-256
`61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28`,
BUILD_ID `7168b508ab424b70f1c0f87b2035d821`. Same device, QSF, SDC,
GPU device 1, seed 2, HeAP weight 10/exponent 2, enable replication budget 4.
No RTL, installed compiler, lock, production recipe or hardware changed.

The original DDR0 first-error zero detector is four LUTs in three levels. A
disposable pre-load JSON rewrite grouped sixteen input bits as 0–5, 6–11 and
12–15 into NOR6, NOR6 and NOR4 feeding AND3. The original and rewritten root
functions match on all 65,536 assignments; the three intermediate outputs each
have one consumer inside the cone. The root output and four cells were reused.

| Candidate | Memory | Pixel | Capture | Result |
| --- | ---: | ---: | ---: | --- |
| Selected merged diagnostic baseline | 106.157112 | 94.500099 | 347.793488 | selected |
| Pre-load index grouping, installed merged binary | 108.944328 | 95.229019 | 378.582397 | positive scratch result |
| Pre-load physical grouping, installed merged binary | 104.920784 | 84.210526 | 359.328918 | reject |
| In-process generic opt-in pass, fresh binary | 100.030014 | 95.029938 | 312.963898 | reject |
| Pre-load index grouping, same fresh binary | 108.944328 | 95.229019 | 378.582397 | byte-identical RBF to earlier scratch |

All four experimental full routes completed with HIP, final analogue signoff,
RBF and no reported final hold violation. The compiler candidate recognized
any four-LUT, sixteen-distinct-literal conjunction selected by root cell name,
with unit and real-CLI rejection tests. Before the identifier probe, all three
nextpnr CTest targets passed (205.54 s). The scratch rewrite is fixture-targeted; the compiler candidate
was generic but produced a memory regression, so it was not committed, pushed
or selected. Its source is preserved in `nextpnr-candidate-source.tar.gz`;
the nextpnr source checkout is clean at merged base `24f9a1db`.

The two packed designs have the same 14,893 cell names, types, parameters,
attributes and named connections. Two internal net IDs differ after loading;
two generated constant-net IDs shift after packing. Their initial placement
metrics and first analytical iteration match, but iteration 2 diverges and
18,336 of 18,494 common routed cells have different BELs. The same fresh
binary reproduces the original scratch Fmax and RBF exactly, so binary version
is excluded as the cause of that split. Avoiding new attribute-name interning
removed the generated constant-net ID shift but left the two internal IDs and
iteration-2 divergence; the placement-only probe was intentionally stopped.
This implicates net representation/order sensitivity in placement, without yet
identifying the exact algorithmic tie or proving a general timing-model error.

A later diagnostic sorted `HeAPPlacer::build_equations` net traversal by name
for the two equivalent packed inputs. A first version sorted on every solve
and was stopped for excessive overhead. A cached-sort version still spent over
two minutes after its first FF solve without reaching the first ALL result, so
both runs were stopped. Neither produced final placement or timing. The patch
and partial logs (`stable-net-order.diff`, `place-stable*.log`) are retained;
sorting this one loop is not an accepted remedy.

Raw routes: `route-balanced/`, `route-balanced-physical/`, `route-compiler/`,
`route-new-binary-scratch/`. Packed controls: `packed-scratch.json`,
`packed-compiler.json`, `packed-nointern.json`. Source fixtures and helpers are
in this directory. The next useful compiler experiment should control the
numeric net/port ordering at load or make placement ordering deterministic,
then compare equal-input post-pack placement and all-clock final timing.
