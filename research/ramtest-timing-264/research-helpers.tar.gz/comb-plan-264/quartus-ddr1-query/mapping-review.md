# Exact DDR1 retained-fit mapping evidence

Read-only analysis on 2026-09-30 in the compiler-gains FES worktree, based on
FES `7ce9926941a5f72cc3ca4b0ed61b7b06e76e5304`. Root alone copied and
authenticated the 176 project files and invoked Quartus on the private copy.
This agent prepared only the two new Tcl scripts and this new ignored note;
it did not invoke Quartus, build, route, edit compiler/RTL/helpers, or touch the
copied project, manifest, previous scripts or query outputs during analysis.

The exact logical DDR1 `idle[22] -> address[10].ENA` path exists in the
retained current Quartus fit. Its four-level worst path and three-level
reconvergent path give a concrete Boolean-factoring precedent for the
seven-level path in the immutable 116.171005 MHz OSS parent. The evidence
supports investigating a generic 24-literal equality rewrite and reuse of
its partial products in local control gates. It does not predict an OSS
timing gain.

## Exact endpoint and timing evidence

`timing-register/idle22-address10-register.rpt:26-27` returns two setup paths
from `ddr_channel:ddr1_test|idle[22]` to
`ddr_channel:ddr1_test|address[10]`, both on the selected memory clock with a
7.692 ns relationship:

| Path | Logic levels | Data delay | Setup slack | Data routing |
| --- | ---: | ---: | ---: | ---: |
| Worst | 4 | 4.528 ns | +2.974 ns | 2.800 ns |
| Reconvergent direct branch | 3 | 4.436 ns | +3.066 ns | See report |

The actual final data edges are `ddr1_test|address[10]|ena` at
`FF_X33_Y62_N55` (`:170` and `:379`). The successful query selected one
launch register and one capture register. Its `counts.txt` retains the
earlier field name `query_capture_pin_count`, although that collection is
now a register collection; the actual ENA evidence comes from the two
reported data edges. The initial hierarchical pin query returned no matches
and failed closed; its outputs remain separate under `timing/`.

The fitted paths are:

```text
idle22 FF30,62,N38
  -> Equal13~2          LAB30,62,N42 (fanout 7)
  -> Selector225~1      LAB31,63,N15 (fanout 11)
  -> burstcount[0]~0    LAB31,62,N0  (fanout 1)
  -> address[0]~1       LAB31,62,N45 (fanout 29)
  -> address10 ENA      FF33,62,N55
```

The second path bypasses `burstcount[0]~0`: `Selector225~1` also directly
feeds `address[0]~1.DATAA`. This is actual reconvergent connectivity, not a
second independent timeout comparator.

## Actual atom cone and Boolean masks

`atoms/counts.txt` identifies launch atom 726 and capture atom 4273, one
address10 ENA port, and producer atom 5254. The complete bounded ENA fanin
contains 50 atoms: 10 `LCELL_COMB` nodes and 40 FF leaves, within the 128-node
bound. Idle22 is present. Traversal starts at the ENA producer and stops at
FFs, rather than traversing capture CLK/DATAIN or upstream FF inputs.

The four equality leaves partition all 24 idle bits into six-bit products:

| Atom / leaf | Physical input order DATAA..DATAF | Raw mask | True physical row | Location |
| --- | --- | --- | ---: | --- |
| 5073 / Equal13~0 | 1, 3, 11, 5 duplicate, 2, 4 | `8000000000000000` | 0 | LAB30,63,N24 |
| 5074 / Equal13~1 | 0, 9, 10, 6, 8, 7 | `20000000000000` | 10 | LAB30,63,N6 |
| 5075 / Equal13~2 | 21, 20, 22, 23, 19, 14 | `8000` | 48 | LAB30,62,N42 |
| 5076 / Equal13~3 | 16, 12, 13, 18, 17, 15 | `4000000000` | 25 | LAB30,62,N48 |

Each leaf has six essential inputs and seven users. The partial products
are shared outside this address ENA cone. Their conjunction requires idle
bits 6, 9, 14, 16, 17, 18 and 19 high and every other idle bit low, exactly
`idle == 24'h0f4240 == 1000000`. The fit uses a nearby duplicate of idle[5]
as one input; it does not duplicate idle22 for this path.

The textual masks use a padded 64-bit, MSB-first truth-row encoding:
`value(row) = (int(mask,16) >> (63-row)) & 1`, with DATAA as row-index bit 0
through DATAF as bit 5. The unique true row of each leaf was checked directly
against the selected constant. Ordinary LSB-first integer decoding would
produce the wrong polarities.

Atom 5248 `Selector225~1` has mask `F0F0F0F0F0F0E0E0` and active inputs:

```text
DATAA = Equal13~1
DATAB = Equal13~0
DATAC = stop_sync[1]
DATAE = Equal13~3
DATAF = Equal13~2
```

All 64 physical truth rows prove:

```text
Selector225 = ~stop_sync & ~(Equal13~0 & Equal13~1 & Equal13~2 & Equal13~3)
            = ~stop_sync & ~(idle == 1000000)
```

D is unused and the remaining five inputs are essential. Quartus feeds the
four partial equality products directly into this local stop/timeout gate;
there is no separate four-product AND LUT on this critical branch. Idle to
this control predicate therefore takes two LUT levels.

The later relevant nodes are:

| Atom | Raw mask | Essential physical inputs | Fanout |
| --- | --- | --- | ---: |
| 5253 / burstcount[0]~0 | `5500550055045504` | A, B, C, D, F | 1 |
| 5254 / address[0]~1 | `33003300010001` | A, B, C, D, F | 29 |

All 29 consumers of atom 5254 use FF input port 7, the ENA port. Composing
these two masks while identifying their shared Selector225 input still
has eight essential external signals: hold, pass_end, write~0, state.WRITE,
Selector225, address~0, Selector192 and state.READ. The fitted terminal pair
therefore supplies no proof of a single six-input terminal fold. State
encoding or unreachable-state assumptions were not used to reduce support.

## Comparison with the immutable OSS parent

The parent is `remap-plan-264/route-c0-g1-third-c0-g1`, compiler
`b8f321400f78637a3347f5b020c05afc555bffd5`, memory Fmax 116.171005 MHz.
Its actual source is mapped suffix `idle_MISTRAL_FF_Q_8`, logical idle[22],
at (37,16); its destination is suffix `ddr1_address_MISTRAL_FF_Q_18`,
logical address[10] ENA, at (21,20).

The path crosses three comparator LUTs, three control LUTs, and the terminal
command LUT, for seven levels. Its effective setup total is 8.608 ns:
6.688 ns routing + 1.397 ns LUT delay + 0.731 ns clock-to-Q - 0.012 ns skew
- 0.196 ns setup. These totals use the OSS model and cannot be subtracted
from the Quartus data delay as a predicted compiler gain.

The comparator is the seven-LUT/24-literal equality cone identified by the
placed24 proposal. Its three ALUT4/ALUT5 branches feed the positive AND root.
All six intermediate LUTs are private, each with one LUT consumer. The
public root has nine direct LUT consumers, including the previously accepted
internal-cut clone and the critical control path. A four-ALUT6-leaf/ALUT4-root
mapping would use five LUTs and reduce this source's comparator path from
three levels to two while preserving that root object, output and all nine
consumers. The equality FFs retain their unrelated increment/feedback, adder
and NOT consumers. The current reduction recognizer supports three/four-node
11/16-literal cones, and the placed pass supports three-node/11-literal
cones; the 24-literal mapping is a proposed generic extension.

The new second comb-stage listing has already qualified a different,
six-essential-input, three-control-node cut into the final command LUT's C
input. It preserves the original shared control root and its other 32
consumers. If that cut passes full-route comparison, it reduces the three
control levels to one. Combining a separately qualified 24-literal rewrite
with that existing bounded cut would give a plausible four-level structure:
two comparator levels, one composed control LUT, and one terminal LUT.
This is a structural target, not a routed result.

## Next bounded compiler targets

1. Extend the existing private literal-reduction recognizer to a generic
   24-literal cube, using four six-literal leaves and a four-input root.
   Derive support and polarity from existing Boolean masks and connections,
   without matching DDR names or TIMEOUT constants and without enumerating
   2^24 input rows. Keep the public root/output/users, source FFs and unrelated
   consumers intact. Reuse/retire only proven private intermediates after
   acceptance. Upsized cells and their paired ALM occupants require live
   legality checks; placement cannot be inferred from the Quartus sites.
   Increasing policy bounds alone is insufficient: the current rewrite assumes
   every non-root child becomes a leaf. A seven-node implementation needs an
   explicit choice of four leaves and transactional retirement/rollback of the
   two surplus private intermediates, including their nets and user stores.
2. Investigate generic consumer-frontier factoring after a product frontier
   exists: reuse the four partial products directly in verified five/six-input
   local control clones, as the fitted stop/timeout gate demonstrates.
   Preserve the shared original equality and control paths. Prove aliases,
   constants and inversion exactly; do not use state-validity assumptions.
   This is a separate extension from the current two/three-node cut pass.

Both targets need the existing endpoint/clock/hold/boundary guards, exact
indexed consumer-slot rollback, preserved unrelated placements and fresh
current-graph guide validation. The root's current six-input internal-cut
route remains the immediate experiment; this note authorizes no compiler
edit, alternate route, refit, recipe selection or hardware operation.

## Provenance and limits

Current Quartus BUILD_ID is `52991ce22369904849b68bdd900f9ae1`; the measured
OSS input is `7168b508ab424b70f1c0f87b2035d821`. The former is not the older
`cd3e4c315005fde83065dff7483ae0d7` control-cone fit. The current QSF selects
Quartus 17.0.2, device 5CSEBA6U23I7, seed 1, QUARTUS/RAM_RATE_SWEEP/
RAM_130_ONLY and native PLL/SDC. It omits RAM_OSS_HIGH_SPEED. Native HPS
wrappers, PLL/clock treatment and timing models differ from the OSS flow.
An authenticated copy of compiled DB bytes does not establish whole-design
elaboration equivalence, calibrated timing differences, new 130 MHz OSS
closure, or hardware acceptance. No default recipe or shared contract changed.

Recomputed SHA256:

| Artifact | SHA256 |
| --- | --- |
| project-inputs.json | `15836c5f71e55fcaf15333ef90c5424d27b81de5db9fb6dd0e0b487c686a00b8` |
| query-ddr1.tcl | `ed4be8c03166c2379476e642b53fd277f5873ec4cf36c2fc831fda512215d1a7` |
| dump-ddr1-atoms.tcl | `a8f87ac02358afd1a782b26e67a96a2559a9d9c963186cf2008e8ce3e0d95473` |
| root query-ddr1-register.tcl | `beb8874cd923c99ed2bdd3a0136fd205c2d6cb90c1ce682c8230dc794de96ff9` |
| exact timing report | `01acbdd9c1978dad634f4aed97dc6e38174c24abc249055d2ee8edfe6e23045c` |
| atoms/cone-nodes.tsv | `83c720702f9fe166335d2f2492afe0082bb2f9f1beea2b160660f5826ea2b693` |
| atoms/cone-inputs.tsv | `ff7a5d2ea2f6ef174257b66bf66f7cc30c0d82b1e4d7fb75ee53a6a96772e123` |
| atoms/cone-outputs.tsv | `3e09bd1df42c92d6a1c486f62ba5e489c38c9ff33be2640bba9cfc2e37f9e0dc` |
| parent run.json | `b9777988d346a1352686feb7a129f9fe2822a1683f8d6dfdf76fa9fccf31d087` |
| parent routed.json | `f41c95937d9c17064ef4bf5af28a130c1d846fbfbaf3aa07f5430cd4f8ffd28b` |
| parent timing.json | `61f2985a5cdfd46f9f0ff0fcd023780ec9b8c1988b8ac1a69673f63884d78c86` |

The three parent artifact hashes match its retained comparison.json. Root's
project manifest owns authentication of the copied database. This analysis
adds no hardware classification beyond host-only retained-fit evidence.
