# Retained-fit DDR1 address[10].ENA producer cone, bounded to 128 atoms.
# Run only against root's authenticated private copy; this does not refit.
# Usage: quartus_cdb -t dump-ddr1-atoms.tcl /absolute/project/top.qpf /new/output
if {[llength $quartus(args)] != 2} {
    error "Usage: dump-ddr1-atoms.tcl project.qpf output-directory"
}
load_package atoms
set project [file normalize [lindex $quartus(args) 0]]
set output [file normalize [lindex $quartus(args) 1]]
file mkdir $output
set expected_build_id 52991ce22369904849b68bdd900f9ae1
set oss_build_id 7168b508ab424b70f1c0f87b2035d821
set qsf [file rootname $project].qsf
set qsf_file [open $qsf r]
set qsf_text [read $qsf_file]
close $qsf_file
set observed_build_id MISSING
regexp {RAMTEST_BUILD_ID=128'h([0-9a-fA-F]{32})} $qsf_text ignored observed_build_id
set observed_build_id [string tolower $observed_build_id]
set identity [open [file join $output identity.txt] {WRONLY CREAT EXCL}]
puts $identity "script [file normalize [info script]]"
puts $identity "project $project"
puts $identity "project_manifest [file join [file dirname [file dirname $project]] project-inputs.json]"
puts $identity "expected_quartus_build_id $expected_build_id"
puts $identity "observed_quartus_build_id $observed_build_id"
puts $identity "frozen_oss_build_id $oss_build_id"
puts $identity "classification retained-fit mapping evidence; BUILD_IDs and native PLL/SDC/timing models differ; no OSS timing calibration or hardware acceptance"
puts $identity "atom_netlist_type cmp; traversal starts at address10 ENA; stops at non-LCELL_COMB sources; max_nodes=128"
if {[info exists quartus(version)]} {puts $identity "quartus_version $quartus(version)"}
set missing {}
foreach relative {top.qpf top.qsf db/top.cmp.hdb db/top.routing.rdb} {
    set path [file join [file dirname $project] $relative]
    if {![file isfile $path] || [file size $path] == 0} {
        lappend missing $relative
        puts $identity "input $relative MISSING_OR_EMPTY"
    } else {
        puts $identity "input $relative bytes=[file size $path] mtime=[file mtime $path]"
    }
}
close $identity
if {[llength $missing]} {error "Retained fitted inputs missing or empty: $missing"}
if {$observed_build_id != $expected_build_id} {error "Unexpected retained Quartus BUILD_ID: $observed_build_id"}

cd [file dirname $project]
project_open [file rootname [file tail $project]]
read_atom_netlist -type cmp
set inventory [open [file join $output endpoint-atoms.tsv] {WRONLY CREAT EXCL}]
puts $inventory "id\ttype\tname\tlocation\texact_role"
set capture_nodes {}
set launch_nodes {}
set atom_count 0
set relevant_count 0
foreach_in_collection node [get_atom_nodes] {
    incr atom_count
    set name [get_atom_node_info -node $node -key NAME]
    if {![regexp {ddr1_test\|(idle|address)} $name]} {continue}
    incr relevant_count
    set type [get_atom_node_info -node $node -key TYPE]
    set role {}
    if {$type == "FF" && [regexp {ddr1_test\|idle\[22\]$} $name]} {
        lappend launch_nodes $node
        set role launch_idle22
    }
    if {$type == "FF" && [regexp {ddr1_test\|address\[10\]$} $name]} {
        lappend capture_nodes $node
        set role capture_address10
    }
    puts $inventory "$node\t$type\t$name\t[get_atom_node_info -node $node -key LOCATION]\t$role"
}
close $inventory
set endpoints [open [file join $output endpoint-inputs.tsv] {WRONLY CREAT EXCL}]
puts $endpoints "node\tport\ttype\tliteral_index\tinverted\tvcc\tgnd\tfanin"
set ena_count 0
set seeds {}
foreach node $capture_nodes {
    foreach port [get_atom_iports -node $node] {
        set vals [list $node $port]
        foreach key {type literal_index is_inverted is_logical_vcc is_logical_gnd fanin} {
            lappend vals [get_atom_port_info -node $node -port_id $port -type iport -key $key]
        }
        puts $endpoints [join $vals \t]
        if {[lindex $vals 2] == "ENA"} {
            incr ena_count
            set source [lindex $vals end]
            if {[llength $source] == 2} {lappend seeds [lindex $source 0]}
        }
    }
}
close $endpoints
set counts [open [file join $output counts.txt] {WRONLY CREAT EXCL}]
puts $counts "all_atoms $atom_count"
puts $counts "ddr1_idle_address_atoms $relevant_count"
puts $counts "exact_launch_idle22_FFs [llength $launch_nodes]"
puts $counts "exact_capture_address10_FFs [llength $capture_nodes]"
puts $counts "capture_ENA_ports $ena_count"
puts $counts "capture_ENA_producer_seeds [llength $seeds]"
puts $counts "launch_nodes $launch_nodes"
puts $counts "capture_nodes $capture_nodes"
puts $counts "ENA_producer_nodes $seeds"
close $counts
post_message "DDR1 atom query: idle22 FFs=[llength $launch_nodes]; address10 FFs=[llength $capture_nodes]; ENA ports=$ena_count; producers=[llength $seeds]"
if {[llength $launch_nodes] != 1 || [llength $capture_nodes] != 1 || $ena_count != 1 || [llength $seeds] != 1} {
    project_close
    error "Exact DDR1 atom endpoints did not resolve uniquely; inspect endpoint-atoms.tsv, endpoint-inputs.tsv and counts.txt"
}

# Expand only the ENA fanin. FFs, constants and hard nodes are recorded leaves.
# CLK/DATAIN/SCLR inputs of the capture FF are never traversed.
set queue $seeds
set selected {}
set seen [dict create]
while {[llength $queue]} {
    set node [lindex $queue 0]
    set queue [lrange $queue 1 end]
    if {[dict exists $seen $node]} {continue}
    dict set seen $node 1
    if {[dict size $seen] > 128} {
        project_close
        error "ENA producer cone exceeded 128 atoms; no truncated cone is published"
    }
    lappend selected $node
    if {[get_atom_node_info -node $node -key TYPE] != "LCELL_COMB"} {continue}
    foreach port [get_atom_iports -node $node] {
        set source [get_atom_port_info -node $node -port_id $port -type iport -key fanin]
        if {[llength $source] == 2} {lappend queue [lindex $source 0]}
    }
}
set selected [lsort -integer -unique $selected]
set nodes [open [file join $output cone-nodes.tsv] {WRONLY CREAT EXCL}]
set inputs [open [file join $output cone-inputs.tsv] {WRONLY CREAT EXCL}]
set outputs [open [file join $output cone-outputs.tsv] {WRONLY CREAT EXCL}]
puts $nodes "id\ttype\tname\tlocation\ttraversal_role"
puts $inputs "node\tport\ttype\tliteral_index\tinverted\tvcc\tgnd\tsource_node\tsource_port\tsource_name"
puts $outputs "node\tport\ttype\tname\tlutmask\tfanout_count\tfanout"
set comb_count 0
set leaf_count 0
set launch_in_cone 0
foreach node $selected {
    set type [get_atom_node_info -node $node -key TYPE]
    set role leaf
    if {$type == "LCELL_COMB"} {set role expanded; incr comb_count} else {incr leaf_count}
    if {[lsearch -exact $launch_nodes $node] >= 0} {set launch_in_cone 1; set role launch_idle22}
    puts $nodes "$node\t$type\t[get_atom_node_info -node $node -key NAME]\t[get_atom_node_info -node $node -key LOCATION]\t$role"
    # Non-LUT leaf inputs are deliberately omitted: they are outside this cone.
    if {$type == "LCELL_COMB"} {
        foreach port [get_atom_iports -node $node] {
            set vals [list $node $port]
            foreach key {type literal_index is_inverted is_logical_vcc is_logical_gnd} {
                lappend vals [get_atom_port_info -node $node -port_id $port -type iport -key $key]
            }
            set source [get_atom_port_info -node $node -port_id $port -type iport -key fanin]
            if {[llength $source] == 2} {
                lappend vals [lindex $source 0] [lindex $source 1] [get_atom_port_info -node [lindex $source 0] -port_id [lindex $source 1] -type oport -key name]
            } else {lappend vals {} {} {}}
            puts $inputs [join $vals \t]
        }
    }
    foreach port [get_atom_oports -node $node] {
        set vals [list $node $port]
        foreach key {type name} {lappend vals [get_atom_port_info -node $node -port_id $port -type oport -key $key]}
        if {$type == "LCELL_COMB" && [lindex $vals 2] == "COMBOUT"} {
            lappend vals [get_atom_port_info -node $node -port_id $port -type oport -key lutmask]
        } else {lappend vals {}}
        set fanout [get_atom_port_info -node $node -port_id $port -type oport -key fanout]
        lappend vals [llength $fanout] $fanout
        puts $outputs [join $vals \t]
    }
}
close $nodes
close $inputs
close $outputs
set summary [open [file join $output cone-summary.txt] {WRONLY CREAT EXCL}]
puts $summary "node_bound 128"
puts $summary "selected_atoms [llength $selected]"
puts $summary "expanded_LCELL_COMB_atoms $comb_count"
puts $summary "recorded_leaf_atoms $leaf_count"
puts $summary "exact_idle22_launch_present_in_ENA_cone $launch_in_cone"
puts $summary "status complete bounded ENA-only structural cone; timing and path sensitization require the separate TimeQuest report"
close $summary
project_close
