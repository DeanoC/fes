#!/usr/bin/env python3
"""Authenticate a retained three-local/two-comb staged experiment, host-only.

Only root invokes this after final metadata is written. Full routes require
actual pin snapshots and exact original BUF preservation. A final-step listing
records partial topology/mask evidence without claiming serialized pin states,
Fmax, final holds, an RBF or independent full Boolean signoff.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
PARENT = RAW / "remap-plan-264"
BEST = PARENT / "route-c0-g1-third-c0-g1"
SOURCE_BASE = "b8f321400f78637a3347f5b020c05afc555bffd5"
STAGED_HELPER = PARENT / "compare_routes.py"
spec = importlib.util.spec_from_file_location("staged_local_evidence", STAGED_HELPER)
staged = importlib.util.module_from_spec(spec)
spec.loader.exec_module(staged)
comb, ready, previous = staged.comb, staged.ready, staged.previous
require, read, sha, relative = staged.require, staged.read, staged.sha, staged.relative
Netlist = staged.Netlist
COMB_HEADER = previous.re.compile(r"^Info: Comb-remap plan step (\d+): candidate=(-?\d+)\.$", previous.re.M)


def fixed_command(command):
    filtered, index = [command[0]], 1
    while index < len(command):
        if command[index] == "--remap-comb-plan":
            index += 2
        else:
            filtered.append(command[index])
            index += 1
    return staged.fixed_command(filtered)


def authenticate_compiler(record):
    require(Path(record["command"][0]) == HERE / "nextpnr-mistral", "candidate is not the frozen comb-plan compiler")
    source = previous.source_identity(HERE, record)
    parent_record = read(BEST / "run.json")
    parent_source, _ = staged.authenticate_compiler(parent_record)
    require(source["base_commit"] == SOURCE_BASE == parent_source["result_commit"], "comb-plan compiler base is not frozenb8f3214")
    fields = dict(part.strip().split("=", 1) for part in record["tool_identity"].split(";") if "=" in part)
    require(fields.get("base_commit") == source["base_commit"] and
            fields.get("experimental_source_sha256") == source["archive_sha256"] and
            fields.get("sha256") == source["binary_sha256"], "compiler identity differs from the freeze")
    staged.authenticated_digest(record, HERE / "source.tar.gz", ("source_archive_sha256",))
    require(record["base_compiler_commit"] == SOURCE_BASE, "recorded compiler parent changed")
    result = source.get("result_commit")
    committed = isinstance(result, str) and previous.re.fullmatch(r"[0-9a-f]{40}", result) is not None
    if committed:
        require(record.get("compiler_commit") == result, "recorded compiler result changed")
    return {**source, "freeze_path": relative(HERE), "result_commit_recorded": committed}, parent_source


def authenticate_disabled_control():
    folder, parent_folder = HERE / "disabled-control", PARENT / "disabled-control"
    record, parent = read(folder / "comparison.json"), read(parent_folder / "comparison.json")
    require(record.get("completed") is True and record.get("exit_code") == 0 and parent["completed"], "disabled-loader metadata is not final")
    previous.authenticate_inputs(record)
    previous.authenticate_inputs(parent)
    source, _ = authenticate_compiler(record)
    require("Info: Program finished normally." in (folder / "loader.log").read_text(), "disabled loader did not finish normally")
    require(not any(option.startswith("--remap") for option in record["command"][1:]), "disabled-loader command enabled a remap")
    require(record["command"][1:-2] == parent["command"][1:-2] and record["command"][-2] == "--write" and
            record["command"][-1] == str(folder / "candidate.json"), "disabled loader fixed command changed")
    staged.ready.authenticate_execution(record, parent)
    expected = read(parent_folder / "candidate.json")["modules"]
    actual = read(folder / "candidate.json")["modules"]
    digest = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    require(actual == expected and digest == record["modules_sha256"] == parent["modules_sha256"], "disabled modules differ from frozenb8f")
    require(sha(folder / "candidate.json") == record["candidate_sha256"] and
            sha(parent_folder / "candidate.json") == record["reference_sha256"], "disabled-loader output/reference digest changed")
    return {"completed": True, "modules_equivalent": True, "modules_sha256": digest, "source": source,
            "candidate_sha256": record["candidate_sha256"], "reference_sha256": record["reference_sha256"],
            "comparison_sha256": sha(folder / "comparison.json"), "execution_inputs_authenticated": True,
            "hardware_tested": False}


def authenticate_plans(record, listing=False):
    require(not any(option in record["command"] for option in ("--remap-comb-critical", "--remap-comb-candidate")),
            "legacy comb options accompany the comb plan")
    # The local plan is unchanged, and its own final candidate is always selected.
    local_record = {**record, "list_only": False}
    local_file, local_sha, local_steps = staged.authenticate_plan(local_record)
    parent_record = read(BEST / "run.json")
    parent_local_file = Path(ready.argument(parent_record["command"], "--remap-plan"))
    parent_local = read(parent_local_file)
    local_plan = read(local_file)
    require(local_plan == parent_local == parent_record["remap_plan"] and len(local_steps) == 3,
            "the retained three-local-step plan changed")
    staged.authenticated_digest(record, parent_local_file)
    comb_file = Path(ready.argument(record["command"], "--remap-comb-plan"))
    comb_sha = staged.authenticated_digest(record, comb_file, ("comb_remap_plan_sha256", "remap_comb_plan_sha256", "comb_plan_sha256"))
    plan = json.loads(comb_file.read_text(), object_pairs_hook=staged.unique_object)
    require(type(plan) is dict and set(plan) == {"steps"} and type(plan["steps"]) is list and
            1 <= len(plan["steps"]) <= 8, "invalid comb-plan schema/count")
    steps = []
    for index, step in enumerate(plan["steps"]):
        require(type(step) is dict and set(step) == {"report", "candidate"} and type(step["report"]) is str and
                step["report"] and "\0" not in step["report"] and type(step["candidate"]) is int,
                "invalid comb-plan step schema")
        require(0 <= step["candidate"] <= 2147483647 or listing and index == len(plan["steps"]) - 1 and step["candidate"] == -1,
                "invalid comb-plan selected/list candidate")
        report = Path(step["report"])
        if not report.is_absolute():
            report = comb_file.parent / report
        report = report.resolve()
        digest = staged.authenticated_digest(record, report)
        guide = read(report)
        require(type(guide.get("critical_paths")) is list, "comb-plan guidance lacks critical paths")
        steps.append({**step, "index": index, "report_path": report, "report_sha256": digest, "report_json": guide})
    require(len(steps) == 2 and steps[0]["report_path"] == comb.GUIDE_REPORT and steps[0]["candidate"] == 0 and
            steps[1]["report_path"] == BEST / "timing.json", "comb-plan retained/new guidance lineage changed")
    require(record.get("list_only") is listing and ((steps[-1]["candidate"] == -1) is listing), "comb-plan listing record disagrees")
    require(record.get("comb_remap_plan") == plan, "recorded comb plan differs from authenticated bytes")
    for alias, step in (("retained_comb_report_sha256", steps[0]), ("new_comb_report_sha256", steps[1])):
        if alias in record:
            require(record[alias] == step["report_sha256"], "comb guidance alias changed")
    return {"local_file": local_file, "local_sha256": local_sha, "local_steps": local_steps,
            "comb_file": comb_file, "comb_sha256": comb_sha, "comb_steps": steps}


def comb_blocks(log, steps, complete=True):
    headers = list(COMB_HEADER.finditer(log))
    require(len(headers) == len(steps) if complete else len(headers) <= len(steps), "logged comb-plan stage count changed")
    blocks = []
    for index, match in enumerate(headers):
        require(tuple(map(int, match.groups())) == (index, steps[index]["candidate"]), "comb-plan stage/ordinal log disagrees")
        end = headers[index + 1].start() if index + 1 < len(headers) else len(log)
        blocks.append(log[match.end():end])
    return blocks


def compare_extension(old_top, new_top, guide, model, serialized_pins=True):
    """The only new graph edit is one ordinary LUT input to one added clone."""
    old_cells, new_cells = old_top["cells"], new_top["cells"]
    old, new = Netlist(old_cells, old_top["netnames"]), Netlist(new_cells, new_top["netnames"])
    added, removed = set(new_cells) - set(old_cells), set(old_cells) - set(new_cells)
    require(not removed and len(added) == 1 and ready.is_lut(new_cells[next(iter(added))]), "new comb step must add exactly one ALUT and remove no cells")
    clone = next(iter(added))
    selected = []
    for name, a in old_cells.items():
        b = new_cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and previous.bel(a) == previous.bel(b) and
                a["port_directions"] == b["port_directions"], "retained type/parameter/BEL/ports changed: " + name)
        if serialized_pins:
            require(a["attributes"].get("FES_PINMAP_V1") == b["attributes"].get("FES_PINMAP_V1"), "retained full pin snapshot changed: " + name)
        ai, bi = old.inputs(name), new.inputs(name)
        require(set(ai) == set(bi), "retained input ports changed")
        if a["type"] == "MISTRAL_BUF":
            require(ai == bi and old.direct_users.get((name, "Q", 0), []) == new.direct_users.get((name, "Q", 0), []),
                    "retained BUF connection/fanout changed: " + name)
            continue
        for port in ai:
            if ai[port] == bi[port]:
                continue
            require(ready.is_lut(a) and port in "ABCDEF" and len(ai[port]) == len(bi[port]) == 1 and
                    bi[port] == [(clone, "Q", 0)], "input changed outside one ordinary LUT cut sink: " + name + "." + port)
            selected.append({"sink": name, "port": port, "bel": previous.bel(b), "control_driver": ai[port][0],
                             "candidate_driver": bi[port][0]})
    proof = comb.prove_cut(old, new, clone, selected, guide, model)
    require(comb.consumers(new, (clone, "Q", 0), set(new_cells)) == [(selected[0]["sink"], selected[0]["port"], 0)],
            "new composed clone has an unexpected consumer")
    return {"added_clone_count_vs_116": 1, "added_buffer_count": 0, "removed_buffer_count": 0,
            "all_retained_buffers_preserved": serialized_pins, "all_ff_connections_preserved_vs_116": True,
            "all_retained_cell_bels_parameters_preserved": True, "full_pin_snapshots_preserved_vs_116": serialized_pins,
            "all_unselected_connections_preserved_vs_116": True, "selected_new_internal_input": selected[0],
            "new_comb_equivalence": proof}


def replay_retained_proofs(new_top, plans, log, parent_proof):
    """Recheck actual three local clones and the old comb clone in final JSON."""
    control_top = read(staged.CONTROL / "routed.json")["modules"]["top"]
    old, new = Netlist(control_top["cells"], control_top["netnames"]), Netlist(new_top["cells"], new_top["netnames"])
    local_models = [staged.selected_local(block, step) for block, step in
                    zip(staged.plan_blocks(log, plans["local_steps"]), plans["local_steps"])]
    local_proofs = []
    for step, model, prior in zip(plans["local_steps"], local_models, parent_proof["local_clone_equivalences"]):
        clone = prior["clone"]["cell"]
        local_proofs.append(staged.prove_local(old, new, clone, prior["selected_ff_ena_users"], step, model))
    old_model = comb.selected_candidate(comb_blocks(log, plans["comb_steps"])[0], 0)
    prior = parent_proof["composed_cut_equivalence"]
    retained = comb.prove_cut(old, new, prior["clone"]["cell"], parent_proof["selected_internal_lut_inputs"],
                             plans["comb_steps"][0]["report_json"], old_model)
    require(retained["assignments_checked"] == 32 and len(local_proofs) == 3 and
            [proof["assignments_checked"] for proof in local_proofs] == [32, 16, 16], "retained Boolean proof shapes changed")
    return local_proofs, retained


def listing_evidence(top, plans, log, parent_proof):
    """A listing preserves four accepted clones, but exports no pin states."""
    old_top = read(BEST / "routed.json")["modules"]["top"]
    old, new = Netlist(old_top["cells"], old_top["netnames"]), Netlist(top["cells"], top["netnames"])
    old_cells, new_cells = old.cells, new.cells
    removed, added = set(old_cells) - set(new_cells), set(new_cells) - set(old_cells)
    require(not added and removed and all(old_cells[name]["type"] == "MISTRAL_BUF" for name in removed),
            "final-step listing must retain all four accepted non-BUF clones/cells")
    require(not any(cell["type"] == "MISTRAL_BUF" for cell in new_cells.values()), "unexpected pre-route BUF export")
    for name in set(old_cells) & set(new_cells):
        a, b = old_cells[name], new_cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and previous.bel(a) == previous.bel(b) and
                a["port_directions"] == b["port_directions"] and old.inputs(name) == new.inputs(name),
                "accepted listing graph changed: " + name)
        require(not b["attributes"].get("FES_PINMAP_V1"), "unexpected partial listing pin export")
    blocks = comb_blocks(log, plans["comb_steps"])
    old_model = comb.selected_candidate(blocks[0], 0)
    require(old_model["root"] == parent_proof["selected_comb_candidate"]["root"] and
            old_model["sink"] == parent_proof["selected_comb_candidate"]["sink"] and
            old_model["port"] == parent_proof["selected_comb_candidate"]["port"], "retained listing comb candidate changed")
    local_models = [staged.selected_local(block, step) for block, step in
                    zip(staged.plan_blocks(log, plans["local_steps"]), plans["local_steps"])]
    for model, prior in zip(local_models, parent_proof["local_clone_equivalences"]):
        require(model["inner"] in prior["retained_cone"] and model["outer"] == prior["control_root"][0] and
                model["bel"] == prior["clone"]["bel"] and model["selected_ff_count"] == prior["selected_ff_count"],
                "retained listing local stage changed")
    return {"graph_proof_available": False, "partial_graph_evidence_available": True,
            "accepted_local_clone_count": 3, "accepted_comb_clone_count": 1,
            "accepted_topology_parameters_bels_preserved_vs_116": True,
            "independent_retained_boolean_proof_available": False,
            "route_created_control_buffers_absent_before_route": len(removed),
            "pin_state_export_available": False, "original_pin_polarity_and_physical_mapping_proved": False,
            "last_step_candidate_listing": [line for line in blocks[-1].splitlines() if "Comb remap" in line],
            "listing_limitations": ["Pre-route JSON omits all FES_PINMAP_V1 snapshots; pin preservation is not independently proved.",
                                    "Retained topology, masks and BELs match the authenticated parent; independent Boolean replay requires routed pin snapshots.",
                                    "No route, Fmax, final hold or RBF acceptance is claimed."]}


def comparison(folder):
    record = read(folder / "run.json")
    early_metadata = {path: sha(path) for path in (folder / "run.json", HERE / "source-identity.json",
        HERE / "disabled-control/comparison.json", BEST / "run.json", BEST / "comparison.json", PARENT / "source-identity.json")}
    listing = record.get("list_only")
    require(type(listing) is bool and type(record.get("exit_code")) is int and
            type(record.get("elapsed_seconds")) in (int, float) and math.isfinite(record["elapsed_seconds"]), "metadata is not final")
    success = record.get("completed") is True and record["exit_code"] == 0
    require(success or record["exit_code"] != 0 and record.get("failure"), "unfinished run metadata")
    plans = authenticate_plans(record, listing)
    parent_proof = staged.comparison(BEST)
    require(parent_proof["compiler_commit"] == SOURCE_BASE and parent_proof["local_clone_count"] == 3 and
            parent_proof["comb_clone_count"] == 1 and parent_proof["graph_proof_available"], "immutable116 parent proof changed")
    staged.authenticate_guidance(record, BEST)
    for guide in (staged.CONTROL, staged.COMB_G4, staged.TWO_ROOT_CONTROL, comb.READY_CONTROL):
        staged.authenticate_guidance(record, guide)
    inputs = previous.authenticate_inputs(record)
    source, parent_source = authenticate_compiler(record)
    disabled = authenticate_disabled_control()
    require(record.get("disabled_control_sha256") == sha(HERE / "disabled-control/comparison.json"), "disabled-control alias changed")
    staged.authenticated_digest(record, HERE / "disabled-control/comparison.json")
    staged.authenticated_digest(record, HERE / "disabled-control/candidate.json")
    parent_record, parent_report, parent_cells, parent_log, parent_route = previous.route_evidence(BEST)
    control_record, control_report, _, control_log, _ = previous.route_evidence(staged.CONTROL)
    require(record["build_id"] == parent_record["build_id"] == control_record["build_id"], "fixed BUILD_ID changed")
    expected_command = fixed_command(parent_record["command"])
    if listing:
        expected_command = [item for item in expected_command if item[0] not in {"--router", "--gpu-device", "--compress-rbf"}]
    require(fixed_command(record["command"]) == expected_command, "fixed route options changed")
    for option in ("--json", "--qsf", "--sdc"):
        path = ready.argument(record["command"], option)
        require(path == ready.argument(parent_record["command"], option) and
                record["input_sha256"].get(path) == parent_record["input_sha256"].get(path), "fixed synthesis/constraint input changed")
    require(record["experimental_capture_locality"] == parent_record["experimental_capture_locality"] ==
            control_record["experimental_capture_locality"] and record["experimental_placed_reduction"] ==
            parent_record["experimental_placed_reduction"] == control_record["experimental_placed_reduction"], "capture/placed stack inputs changed")
    staged.authenticated_digest(record, staged.BASE / "timing.json", ("capture_report_sha256",))
    staged.authenticated_digest(record, BEST / "run.json", ("control_run_sha256",))
    ready.authenticate_execution(record, parent_record)
    log = (folder / "route.log").read_text()
    metrics = previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and metrics == previous.PLACEMENT_METRICS.findall(parent_log) ==
            previous.PLACEMENT_METRICS.findall(control_log), "ordinary71 placement metrics changed")
    blocks = comb_blocks(log, plans["comb_steps"], success)
    artifacts = [folder / "run.json", folder / "route.log", plans["local_file"], plans["comb_file"],
                 Path(__file__).resolve(), HERE / "route.py", HERE / "freeze.py", HERE / "check_disabled_control.py",
                 HERE / "source-identity.json", HERE / "source.tar.gz", HERE / "nextpnr-mistral",
                 HERE / "disabled-control/comparison.json", HERE / "disabled-control/loader.log", HERE / "disabled-control/candidate.json"]
    artifacts += [Path(filename) for filename in record["input_sha256"]]
    artifacts += [ready.ROOT / name for name in parent_proof["artifact_sha256"]]
    if success:
        artifacts += [folder / "placed.json"] if listing else [folder / name for name in ("timing.json", "routed.json", "core.rbf")]
    artifacts = list(dict.fromkeys(artifacts))
    digests = {path: sha(path) for path in artifacts}
    require(all(digests[path] == digest for path, digest in early_metadata.items()), "final metadata changed during authentication")
    common = {"status": "experimental staged internal remap; unselected", "compiler_commit": record.get("compiler_commit"),
              "base_compiler_commit": source["base_commit"], "build_id": record["build_id"], "source": source,
              "compiler_parent_b8f3214": parent_source, "authenticated_inputs": inputs, "disabled_loader_equivalence": disabled,
              "elapsed_seconds": record["elapsed_seconds"], "exit_code": record["exit_code"], "candidate_completed": success,
              "list_only": listing, "local_plan_sha256": plans["local_sha256"], "comb_plan_sha256": plans["comb_sha256"],
              "comb_plan_steps": [{key: value for key, value in step.items() if key not in ("report_path", "report_json")} |
                                   {"report_path": relative(step["report_path"])} for step in plans["comb_steps"]],
              "parent_116": {"path": relative(BEST), "route": parent_route,
                             "comparison_sha256": sha(BEST / "comparison.json"), "full_structural_truth_proof_repeated": True},
              "placement_metrics_identical": True, "matched_placement_metrics": len(metrics),
              "placement_metrics_sha256": hashlib.sha256("\n".join(metrics).encode()).hexdigest(),
              "remap_log": [line for line in log.splitlines() if "remap" in line.lower()],
              "default_recipe_selected": False, "hardware_tested": False}
    if not success:
        require("Running the GPU router" not in log and not (folder / "core.rbf").exists() and not (folder / "routed.json").exists(),
                "failed plan trial produced/started a route")
        common.update({"status": "comb-plan trial failed before route; no route acceptance", "failure": record["failure"],
                       "route_started": False, "graph_proof_available": False, "candidate_route": None,
                       "accepted_comb_stage_logs": [comb.selected_candidate(block, step["candidate"]) for step, block in
                           zip(plans["comb_steps"], blocks) if f"Comb remap applied candidate {step['candidate']};" in block]})
    elif listing:
        require("Info: Program finished normally." in log and "Running the GPU router" not in log and not (folder / "core.rbf").exists(),
                "listing unexpectedly routed or emitted an RBF")
        require(ready.argument(record["command"], "--write") == str(folder / "placed.json") and "--no-route" in record["command"],
                "listing write/no-route options changed")
        common.update(listing_evidence(read(folder / "placed.json")["modules"]["top"], plans, log, parent_proof))
        common.update({"status": "host-only final-comb-step listing; partial graph evidence; no route acceptance",
                       "candidate_route": None, "route_started": False})
    else:
        r, report, cells, final_log, route = previous.route_evidence(folder)
        require(r == record and final_log == log, "metadata changed during final route load")
        for option, name in (("--write", "routed.json"), ("--report", "timing.json"), ("--rbf", "core.rbf")):
            require(ready.argument(record["command"], option) == str(folder / name), "candidate output path changed")
        new_model = comb.selected_candidate(blocks[1], plans["comb_steps"][1]["candidate"])
        top = read(folder / "routed.json")["modules"]["top"]
        extension = compare_extension(read(BEST / "routed.json")["modules"]["top"], top, plans["comb_steps"][1]["report_json"], new_model)
        local_proofs, retained = replay_retained_proofs(top, plans, log, parent_proof)
        require(set(report["fmax"]) == set(ready.REQUIRED_CLOCKS) and all(report["fmax"][clock]["constraint"] >= nominal
            for clock, nominal in ready.REQUIRED_CLOCKS.items()), "required clock set/constraints changed")
        reports = {"candidate": report, "parent_116": parent_report, "control_115": control_report,
                   "baseline_108": read(staged.BASE / "timing.json"), "ready_control_113": read(comb.READY_CONTROL / "timing.json")}
        clocks = {label: previous.compare_clocks(old, report) for label, old in reports.items() if label != "candidate"}
        selected = extension["selected_new_internal_input"]
        common.update({**extension, "candidate_route": route, "route_started": True, "graph_proof_available": True,
                       "common_ff_cells": parent_proof["common_ff_cells"], "original_lut_cells": parent_proof["original_lut_cells"],
                       "ff_placements_identical": True, "original_lut_placements_identical": True,
                       "local_clone_count": 3, "comb_clone_count": 2, "added_clone_count_vs_115": 5,
                       "selected_ff_ena_count": parent_proof["selected_ff_ena_count"],
                       "retained_local_clone_equivalences": local_proofs, "retained_comb_equivalence": retained,
                       "selected_new_comb_candidate": new_model, "transform_stack": ready.transform_stack(log, control_log),
                       "fmax_comparisons": clocks, "all_clock_nonregression": {label: all(row["gain_mhz"] >= 0 for row in data.values())
                           for label, data in clocks.items()},
                       "passes_all_clock_constraints": all(row["meets_constraint"] for row in clocks["control_115"].values()),
                       "passes_strict_diagnostic_gate_vs_115": all(row["gain_mhz"] >= 0 for row in clocks["control_115"].values()) and
                           clocks["control_115"][ready.MEMORY_CLOCK]["gain_mhz"] > 0 and not route["final_reported_hold_violations"],
                       "critical_path_comparisons": ready.critical_path_comparison(parent_report, report),
                       "critical_memory_path": next(path for path in report["critical_paths"] if path["from"] == path["to"] == "posedge " + ready.MEMORY_CLOCK),
                       "retained_selected_ena_arrival_comparisons": staged.selected_ena_arrivals(local_proofs, reports),
                       "new_cut_downstream_arrival_comparisons": comb.endpoint_arrival_comparison(cells, selected["sink"], reports)})
    require(all(sha(path) == digest for path, digest in digests.items()), "evidence changed during comparison")
    common.update({"artifact_sha256": {relative(path): digest for path, digest in digests.items()},
                   "final_metadata_stable_during_comparison": True})
    return common


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", nargs="?", default="route-c0", help="finalized direct child under comb-plan-264")
    args = parser.parse_args()
    folder = (HERE / args.route).resolve()
    require(folder.parent == HERE, "candidate must be a direct child of comb-plan-264")
    result = comparison(folder)
    (folder / "comparison.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    keys = ("status", "compiler_commit", "elapsed_seconds", "exit_code", "candidate_completed", "list_only",
            "matched_placement_metrics", "candidate_route", "graph_proof_available", "partial_graph_evidence_available",
            "common_ff_cells", "original_lut_cells", "local_clone_count", "comb_clone_count", "added_clone_count_vs_115",
            "all_retained_buffers_preserved", "full_pin_snapshots_preserved_vs_116", "selected_new_internal_input",
            "selected_new_comb_candidate", "fmax_comparisons", "all_clock_nonregression", "passes_all_clock_constraints",
            "passes_strict_diagnostic_gate_vs_115", "default_recipe_selected", "hardware_tested")
    print(json.dumps({key: result[key] for key in keys if key in result}, indent=2))


if __name__ == "__main__":
    main()
