"""Freeze the optional staged internal-remap compiler; root-operated only."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SRC = ROOT / "sources/misteross/build/toolchain-ramtest-timing/src/nextpnr"
BUILD = ROOT / "sources/misteross/build/toolchain-ramtest-timing/build/nextpnr"
BASE = "b8f321400f78637a3347f5b020c05afc555bffd5"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SRC, text=True).strip() == BASE
assert not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json"))
tracked = subprocess.check_output(["git", "diff", "--name-only", BASE], cwd=SRC, text=True).splitlines()
untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard"], cwd=SRC, text=True).splitlines()
files = sorted(set(tracked + untracked))
assert files and all(name.startswith("mistral/") and (SRC / name).is_file() for name in files)
shutil.copy2(BUILD / "nextpnr-mistral", HERE / "nextpnr-mistral")
with tarfile.open(HERE / "source.tar.gz", "w:gz") as archive:
    for name in files:
        archive.add(SRC / name, arcname=name)
(HERE / "change.patch").write_bytes(subprocess.check_output(["git", "diff", BASE], cwd=SRC))
record = {"base_commit": BASE, "source_sha256": {name: sha(SRC / name) for name in files},
          "binary_sha256": sha(HERE / "nextpnr-mistral"),
          "source_archive_sha256": sha(HERE / "source.tar.gz"),
          "branch": subprocess.check_output(["git", "branch", "--show-current"], cwd=SRC, text=True).strip(),
          "status": "uncommitted generic staged internal-remap experiment; no default/package selection"}
(HERE / "source-identity.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
print(json.dumps(record, indent=2), flush=True)
