"""Root-operated fresh route/list retaining three local steps and two comb steps."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
RAW = HERE.parent
PARENT = RAW / "remap-plan-264"
BEST = PARENT / "route-c0-g1-third-c0-g1"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sys.path.insert(0, str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation
from scripts.search_placer_qor import _score_report, has_failed_route_arc
from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--candidate", type=int, default=0)
parser.add_argument("--list", action="store_true", help="list only the final new comb step; no route/RBF")
args = parser.parse_args()
assert 0 <= args.candidate <= 2147483647
previous = json.loads((BEST / "run.json").read_text())
assert previous["completed"] and previous["exit_code"] == 0 and not previous["final_reported_hold_violations"]
assert previous["compiler_commit"] == "b8f321400f78637a3347f5b020c05afc555bffd5"
for filename, digest in previous["input_sha256"].items():
    assert sha(Path(filename)) == digest
old_command = previous["command"]
value = lambda option: old_command[old_command.index(option) + 1]
old_local_file = Path(value("--remap-plan"))
local_plan = json.loads(old_local_file.read_text())
assert local_plan == previous["remap_plan"] and len(local_plan["steps"]) == 3
assert all(step["candidate"] == 0 and step["preserve_ff_placement"] and not step["optimize_pins"]
           for step in local_plan["steps"])
assert [step["groups"] for step in local_plan["steps"]] == [4, 1, 1]
old_comb_guide = Path(value("--remap-comb-critical"))
assert value("--remap-comb-candidate") == "0"
new_comb_guide = BEST / "timing.json"
reports = list(dict.fromkeys([Path(step["report"]) for step in local_plan["steps"]] +
                            [old_comb_guide, new_comb_guide]))
lineage = []
for report in reports:
    run, comparison = report.parent / "run.json", report.parent / "comparison.json"
    data = json.loads(run.read_text())
    assert data["completed"] and data["exit_code"] == 0
    trusted = json.loads(comparison.read_text())["artifact_sha256"]
    for name in ("run.json", "route.log", "timing.json", "routed.json", "core.rbf"):
        artifact = report.parent / name
        assert trusted[str(artifact.relative_to(ROOT))] == sha(artifact)
    lineage.extend((run, comparison))
freeze = json.loads((HERE / "source-identity.json").read_text())
binary, archive = HERE / "nextpnr-mistral", HERE / "source.tar.gz"
assert freeze["base_commit"] == previous["compiler_commit"]
assert sha(binary) == freeze["binary_sha256"] and sha(archive) == freeze["source_archive_sha256"]
disabled = HERE / "disabled-control/comparison.json"
disabled_record = json.loads(disabled.read_text())
assert disabled_record["completed"] and disabled_record["exit_code"] == 0
assert sha(HERE / "disabled-control/candidate.json") == disabled_record["candidate_sha256"]
for filename, digest in disabled_record["input_sha256"].items():
    assert sha(Path(filename)) == digest
output = HERE / ("list-second" if args.list else f"route-c{args.candidate}")
output.mkdir(exist_ok=False)
local_file, comb_file = output / "local-plan.json", output / "comb-plan.json"
local_file.write_text(json.dumps(local_plan, indent=2, sort_keys=True) + "\n")
comb_plan = {"steps": [{"report": str(old_comb_guide), "candidate": 0},
                       {"report": str(new_comb_guide), "candidate": -1 if args.list else args.candidate}]}
comb_file.write_text(json.dumps(comb_plan, indent=2, sort_keys=True) + "\n")
identity = f"base_commit={freeze['base_commit']}; experimental_source_sha256={sha(archive)}; sha256={sha(binary)}"
invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, identity)}, 1)
command, index = [str(binary)], 1
removed = {"--write", "--report", "--rbf", "--remap-plan", "--remap-comb-critical", "--remap-comb-candidate"}
if args.list:
    removed |= {"--router", "--gpu-device"}
while index < len(old_command):
    if old_command[index] in removed:
        index += 2
    elif args.list and old_command[index] == "--compress-rbf":
        index += 1
    else:
        command.append(old_command[index])
        index += 1
command += ["--remap-plan", str(local_file), "--remap-comb-plan", str(comb_file),
            "--write", str(output / ("placed.json" if args.list else "routed.json"))]
if args.list:
    command += ["--no-route"]
else:
    command += ["--report", str(output / "timing.json"), "--rbf", str(output / "core.rbf")]
capture_report = Path(previous["experimental_capture_locality"].rsplit(" ", 2)[0])
inputs = list(dict.fromkeys([binary, archive, Path(value("--json")), Path(value("--qsf")), Path(value("--sdc")),
                            local_file, comb_file, old_local_file, capture_report, disabled,
                            HERE / "disabled-control/candidate.json", *reports, *lineage]))
env = dict(invocation.env)
env["NEXTPNR_MISTRAL_CAPTURE_LOCALITY"] = previous["experimental_capture_locality"]
env["NEXTPNR_MISTRAL_PLACED_REDUCTION"] = previous["experimental_placed_reduction"]
record = {"kind": "host-only final internal-step listing" if args.list else "scratch full HIP route; unselected",
          "command": command, "cwd": str(MODULE), "tool_identity": identity,
          "base_compiler_commit": freeze["base_commit"],
          "compiler_commit": freeze.get("result_commit", freeze["base_commit"] + "+comb-plan-experiment"),
          "build_id": previous["build_id"], "execution": invocation.inputs, "completed": False,
          "input_sha256": {str(path): sha(path) for path in inputs}, "source_archive_sha256": sha(archive),
          "experimental_capture_locality": env["NEXTPNR_MISTRAL_CAPTURE_LOCALITY"],
          "experimental_placed_reduction": env["NEXTPNR_MISTRAL_PLACED_REDUCTION"],
          "capture_report_sha256": sha(capture_report), "control_run_sha256": sha(BEST / "run.json"),
          "remap_plan": local_plan, "remap_plan_sha256": sha(local_file),
          "comb_remap_plan": comb_plan, "comb_remap_plan_sha256": sha(comb_file),
          "retained_comb_report_sha256": sha(old_comb_guide), "new_comb_report_sha256": sha(new_comb_guide),
          "disabled_control_sha256": sha(disabled), "list_only": args.list}
manifest = output / "run.json"
manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
start = time.monotonic()
try:
    with (output / "route.log").open("w") as log:
        result = audited_run(command, source_root=MODULE, cwd=MODULE, env=env, stdout=log,
                             stderr=subprocess.STDOUT, check=False, timeout=2400)
    record["exit_code"] = result.returncode
    record["elapsed_seconds"] = time.monotonic() - start
    invocation.verify()
    for filename, digest in record["input_sha256"].items():
        assert sha(Path(filename)) == digest
    log = (output / "route.log").read_text()
    assert result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log)
    if args.list:
        assert not (output / "core.rbf").exists() and (output / "placed.json").exists()
    else:
        board._require_gpu_backend(log)
        assert (output / "core.rbf").stat().st_size > 0 and "Running signoff timing analysis..." in log
        record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
        report = json.loads((output / "timing.json").read_text())
        _score_report(report, REQUIRED_CLOCKS)
        assert set(report["fmax"]) == {name for name, _ in REQUIRED_CLOCKS}
        record["fmax"] = report["fmax"]
    record["completed"] = True
    print(json.dumps({key: record[key] for key in ("completed", "elapsed_seconds", "list_only", "fmax",
                      "final_reported_hold_violations") if key in record}, indent=2), flush=True)
except BaseException as exc:
    record["failure"] = repr(exc)
    raise
finally:
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    invocation.close()
