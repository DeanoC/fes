# Generic staged internal-cut experiment

The new compiler option `--remap-comb-plan` executes one to eight explicit
report/candidate stages after the existing local-remap stages. It preserves
earlier accepted internal cuts, then validates each subsequent report against
the current graph before reusing the existing two/three-LUT cut composition,
legality, endpoint, clock, hold, boundary and exact rollback guards. The schema,
report syntax, duplicate keys, bounds and fresh-placement modes are checked
before placement. Only a final listing step may select -1, with no routing or
RBF. A selected failure, or failed HeAP placement, aborts before routing even
with `--force`. Plans are CLI-only state and disabled by default. No RTL names,
values or locations are compiler matching rules.

Base: `b8f321400f78637a3347f5b020c05afc555bffd5`; result:
`301fcee8db989dfd8f656c92714b32464d89cc3a`, pushed on
`experiment/mistral-comb-remap-plan-264`. All nine archived source files match
the result commit. Frozen binary SHA256:
`2f9dde8c42cfe866d1e95e8115b3d565059b1b07cb261dea891756a21386a414`;
source archive SHA256:
`49682b7130b0c980ca910ff5086b4e71efa54991835bc70c8e307b9a36827c29`.

Validation passed: 39 focused backend tests (five new sequential-cut tests,
15 existing internal-cut tests, 11 local-plan/report tests and eight pure cut
tests), 15 new CLI tests, and 23 existing CLI tests. The backend tests cover
shared inputs, exhaustive Boolean/polarity checks, original cell/BEL/parameter
and consumer preservation, exact indexed-store/free-list rollback after later
failure or listing, current-graph rejection of a stale second guide, and full
request prevalidation. CLI tests cover bounds/schema/duplicates, report paths
and preload, effective loaded placer and processed-design restrictions,
listing/legacy/local-stage interactions, `--force` failure before output, and
no plan replay on output reload. The first backend build hit a test-only const
indexed-store enumeration issue; using a snapshot copy fixed it without
changing the production store. Independent review found a placement-failure
`--force` bypass; it was fixed before the final build/tests/freeze. Final
production and helper reviews found no remaining acceptance blocker.

The real disabled-option loader modules exactly match the retained control:
SHA256 `11ed9f98d068a77bca1973ee75743b7fd964058fb2952f73e9b01baf9c005069`.
The compiler and FES worktrees are clean. No FES RTL, recipe, compiler lock,
ABI, producer selection or hardware changed. No PR was opened.

The experiment retains the immutable 116.171005 MHz parent's three local
stages (groups 4/1/1, candidate 0, preserved FFs) and its existing DDR1 internal
cut as the first comb stage. The completed parent timing report guides a
second comb stage. RTL, BUILD_ID, synthesis bytes, device, constraints, seed,
GPU1 execution and all other options remain fixed. The preplacement16,
placed11 and sixty capture moves remain enabled. Report lineage is bound to
the completed parent and every earlier guide's actual full-route artifacts.

The limiting DDR1 idle[22] to address[10].ENA path has seven logic levels.
Its terminal pair requires seven independent inputs, so the six-input local
fold cannot handle it. The next bounded target is a three-node internal cut
into the final command LUT's C input, with six essential inputs, preserving
the original shared root's other 32 consumers. Actual qualification and clone
function must be established from the selected stage's output, rather than
assuming that the structural target necessarily qualifies.

The fresh final-stage listing completed normally in 541.218 seconds. It
retained all three local stages and the first internal cut, then qualified
ten candidates without applying a final cut. Candidate 0 is the intended
three-node DDR1 cut into cmd_end.C, at MISTRAL_COMB.27.13.12, with 287 ps
modeled gain. Candidates 1/2 fold farther upstream into the ALUT5.E input;
candidates 3--9 fold into the preceding ALUT2.A input. These are measured
listing observations, not compiler matching rules.

The first new comparison-helper run exposed a pre-route/routed export
mismatch: route-created BUFs are absent from the listing, so replaying a
routed consumer-set proof directly raised a KeyError. The correction is
limited to this new ignored helper's listing path; full-route BUF/pin proof
requirements remain strict. Listing qualification makes no Fmax, final
pin-state, hold, RBF or hardware claim. The measured experimental best
remains 116.171005 MHz; strict accepted memory remains 108.944328 MHz, and
130 MHz remains unresolved.

The final listing checker skips Boolean replay rather than borrowing missing
pin states or representing absent routing buffers. It authenticates all 71
placement metrics and the parent's exact non-BUF topology, masks, parameters
and BELs. Its final SHA256 is
`e73b7db62739dedbadd9824fac09ab134832638a22735530d897280681ec945d`.
The fresh full GPU1 `route-c0` completed normally in 702.178 seconds using the
frozen compiler and unchanged inputs. Its memory/pixel/phase Fmax is
114.468864 / 94.348526 / 307.631805 MHz, with no final reported hold violation.
The comparison authenticates the new ALUT6's actual 64-row mask
0x5070505000000000, all prior three local and one internal Boolean proofs,
all original FF/LUT/BEL/parameter/pin states and all 5232 BUFs. There is one
additional ALUT and only the selected internal input changes relative to the
116.171 parent; all 71 placement metrics match. The result is rejected:
memory regresses by 1.702141 MHz and phase by 70.950592 MHz versus the parent,
although pixel improves by 0.680481 MHz. The new reported limiting path starts
at HPS cmd_ready_1 and ends at the port1 burstcount FF ENA.

The fresh full GPU1 `route-c1` completed normally in 723.744 seconds, with no
final reported hold violation. Its memory/pixel/phase Fmax is
117.605545 / 92.489822 / 307.631805 MHz. This is a rejected memory tradeoff:
memory improves 1.434540 MHz over the parent, but pixel regresses 1.178223 MHz
and phase regresses 70.950592 MHz. The strict checker also fails closed on a
real cell-population difference. The new ALUT5 at COMB.29.13.24 replaces one
parent routing-created BUF, m1_burstcount_FF_Q_1$ROUTETHRU, at that same site.
No full graph or BUF preservation claim follows. The original comparison
failure remains saved; `route-c1/rejection.json` binds the authentic raw
result and exact difference, SHA256
`261a232adca1c95f671457958276478fadd5f05d176343f44140324e72e18354`.

Independent actual-pin algebra corroborates the target-local 32-row function
uvws OR !n, mask 0x8000ffff; this does not change rejection. The new memory
critical path is cmd_ready_0 -> port0 skid_address_Q_23.ENA, 8.503 ns.

The fresh full GPU1 `route-c2` completed normally in 746.767 seconds, with no
final reported hold violation. It retains the same stack and selects the
qualified two-node cut into ALUT5.E, modeled gain 653 ps, at COMB.29.13.12.
Its memory/pixel/phase Fmax is 116.904373 / 93.240089 / 265.641998 MHz. The
retained full routed parent has no cell at this site, and no BUF is removed.
There is exactly one added ALUT3; all common original types, masks and BELs
remain unchanged. The neighboring original ALUT5 at COMB.29.13.13 acquires
a different physical input mapping, while all logical pin states stay SIG.
The strict checker fails closed on that full-pin-snapshot change. Pixel also
regresses 0.427956 MHz and phase 112.940399 MHz versus the parent, despite a
0.733368 MHz memory gain. The raw authenticated rejection record is
`route-c2/rejection.json`, SHA256
`f7f99ac63a8f0795ef59f762099ef8ab15e9c0f8fd1c849f4e0c13cefe06ec5d`.
No full graph or pin-preservation acceptance claim follows.

Independent actual-pin review confirms c2's eight-row function sP OR !n,
mask 0x8f. The clone feeds only ALUT5.E; the original shared intermediate
and status users remain. This local Boolean proof does not override the
physical pin-map rejection. Its new memory critical path is cmd_ready_1 ->
slot_free_ALUT2 -> slot_free_ALUT4_C -> m1_address_Q_17.ENA, two LUTs and
8.554 ns data delay versus the 7.692 ns requirement.

All three fresh routes and the listing are complete. No compiler, helper or
parent artifacts changed during them. No acceptance gate was weakened to
admit a rejected result. The best result under the retained-stack gates
remains 116.171005 MHz; the highest memory-only tradeoff of 117.605545 MHz
is rejected and unselected. Strict accepted memory remains 108.944328 MHz.
The 130 MHz memory target remains unresolved.

| Fresh result | Memory MHz | Pixel MHz | Phase MHz | Decision |
| --- | ---: | ---: | ---: | --- |
| Retained parent | 116.171005 | 93.668045 | 378.582397 | Retain experimental stack |
| New internal cut c0 | 114.468864 | 94.348526 | 307.631805 | Structural proof passes; timing regresses |
| Upstream cut c1 | 117.605545 | 92.489822 | 307.631805 | Removed original BUF; pixel/phase regress |
| Alternate cut c2 | 116.904373 | 93.240089 | 265.641998 | Changed original physical pin map; pixel/phase regress |

## Exact retained Quartus endpoint

The root queried an authenticated private copy of the saved current fitted
project, without refitting. The bounded address[10].ENA atom cone contains
50 atoms, including ten LCELL_COMB atoms and the unique idle[22] launch FF.
An exact TimeQuest query resolves one idle[22] register and one address[10].ENA
pin. Its two reported paths end on ENA: the worst has four LUT levels,
4.528 ns data delay and 2.974 ns setup slack at a 7.692 ns relationship; the
second has three levels, 4.436 ns delay and 3.066 ns slack. The worst path
is Equal13~2 -> Selector225~1 -> burstcount[0]~0 -> address[0]~1 -> ENA.

Two initial pin filters failed closed. Quartus 17 `get_pins` matches hierarchy
levels by default, or short cell|pin names with `-hierarchical`; its documented
`-compatibility_mode` allows the full hierarchy pattern. A register query
first established both actual ENA endpoints; the final compatibility-mode pin
query then reproduced the same two paths with unique exact pin selection.
All initial and successful outputs are retained separately.

All 176 original fitted project files remain hash-matched. In the private
copy, QPF/QSF/SDC and the compiled, routing and saved timing databases remain
unchanged; only the private analysis workspace db/top.taw.rdb changed. The
before/after identities and query artifacts are recorded in
`quartus-ddr1-query/query-record.json`, SHA256
`4a1eb603f1581533f83a3be4d195dd3f94e743573a23d777c42affea2d1822b1`.
Quartus BUILD_ID `52991ce22369904849b68bdd900f9ae1` differs from the OSS
fixed BUILD_ID `7168b508ab424b70f1c0f87b2035d821`; wrappers, models and
constraints also differ. This fit supports factoring/locality investigation,
not physical delay calibration or hardware acceptance.

The independently reviewed `mapping-review.md` binds actual input polarities
and masks. Four six-bit equality products partition all 24 idle bits; their
conjunction matches the source constant. They feed a five-essential-input
stop/timeout gate directly. The fitted terminal pair still has eight essential
external signals and supplies no proof of a six-input terminal collapse.
The note's SHA256 is
`900c3a6286a04a4fcb59115edb23a28d541fcabd126a3471bd8a11e6bfcd3919`.

## Next generic structural target

The retained OSS parent's timeout equality is seven LUTs and three levels,
with 24 distinct essential FF output literals. All six intermediate LUTs
are private, each with one consumer; the root has nine shared LUT users,
including the previously accepted internal-cut clone. Four six-literal
products plus a four-input root would use five LUTs and two levels, preserving
the root name/output and all nine consumers.

This requires explicit recognition, discovery, rewrite and placed-probe work
in `reduction_balance_policy.h`, `reduction_balance.cc` and
`placed_reduction.cc`. Current recognition supports three/four-node
11/16-literal cubes; discovery is bounded to four nodes; the rewrite assumes
every non-root child becomes a leaf. The placed pass accepts only the
three-node/eleven-literal class. Raising those bounds alone would be unsafe:
the new rewrite must choose four leaves and transactionally retire the two
surplus private intermediates, check live packing and placement legality,
and restore consumer slots/pin states/placements exactly after rejection.
Per-LUT single-assignment recognition examines at most 64 rows per LUT and
can prove the 24-literal cube symbolically; no state-validity assumption or
2^24 truth-table expansion is needed. Unrelated FFs and consumers remain
protected. Keep the existing internal-cut support limit at six signals.

Reusing the partial-product frontier directly in verified local control gates
is a subsequent factoring opportunity. The four-level total is a structural
target, not a routed timing result. No 24-literal compiler edit is included in
commit 301fcee8.
