"""Root-only activation of a one-file diagnostic rejection replay."""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
TOOLCHAIN = MODULE / "build/toolchain-ramtest-timing"
SOURCE = TOOLCHAIN / "src/nextpnr-driver-rejections-264"
MISTRAL = TOOLCHAIN / "src/mistral"
BASE = "e6d383ced713bc157264de7df3d8cb042edf7da3"
OLD = HERE.parent / "timing-paths-full-264"
OLD_PROOF_SHA = "a3d7cee7b53c6681d2affa93465f8f3c734bc90318cd70da0e0471d522618f43"
OLD_BASELINE_PROOF_SHA = "030bddd44e3a4b8310e8efd02dc6e4244fb9563a89a284f626a355cfa23792fa"
PREDECESSOR_HOST = OLD / "validation/host-validation.json"
PREDECESSOR_HOST_SHA = "9f1c0cecf099802a0991085f964c1ff545fb97408881ae44981e0a08fb56f39f"
FOCUSED_HOST = HERE.parent / "timing-paths-264/validation/host-validation.json"
FOCUSED_HOST_SHA = "d68ff437d71d0c74447d391a4b543ce22d3cad6686b7fe8d6ca15bf330594d64"
DELTA_FILES = {"mistral/lut_driver_copy.cc"}
PATH_LIMIT = 16384
PURE = HERE.parent / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
IDENTITY = HERE / "source-identity.json"
HELPERS = ("freeze.py", "run.py", "compare_listing.py", "proof-scope.md")
PHASES = {"list-driver": HERE / "list-driver"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def digest(value, width=64):
    return (type(value) is str and re.fullmatch(r"[0-9a-f]{%d}" % width, value) is not None
            and len(set(value)) > 1)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata: " + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def bind(inputs, path, expected):
    path = Path(path).absolute()
    require(digest(expected), "unset/invalid input hash: " + str(path))
    if str(path) in inputs:
        require(inputs[str(path)] == expected, "conflicting input identity: " + str(path))
        return
    require(sha(path) == expected, "input changed: " + str(path))
    inputs[str(path)] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "original input path changed during operation: " + path)


def reference(inputs):
    bind(inputs, OLD / "list-driver/comparison.json", OLD_PROOF_SHA)
    proof = read(OLD / "list-driver/comparison.json")
    require(proof["phase"] == "timing-paths-full-list-driver" and proof["compiler_commit"] == BASE and
            proof["timing_report_paths"] == PATH_LIMIT and proof["qualified_driver_ordinals"] == [] and
            proof["fresh_driver_qualification"] == {
                "bounded_reported_edges": 1, "eligible_probed_edges": [], "qualified_driver_ordinals": [],
                "no_candidate_applied": True, "minimum_modeled_gain_ps": 250,
                "guards_are_current_compiler_reported_not_independent_STA": True} and
            all(proof[key] is True for key in (
                "candidate_completed", "same_new_binary_listing_rollback_proved",
                "current_predicted_timing_report_exact_after_listing_rollback", "baseline_native_graph_matches_old",
                "legacy_report_prefix_and_fmax_exact", "expanded_paths_current_native_topology_validated",
                "typed_native_module_bits_consumers_bels_attrs_params_ports_exact", "cell_and_net_export_order_exact",
                "lossless_ordered_pll_occurrences_exact", "final_original_path_metadata_and_runtime_hashes_stable")),
            "cached full listing is not its completed strict zero-candidate proof")
    require(len(proof["artifact_sha256"]) == 430 and len(proof["execution_file_sha256"]) == 281,
            "cached full-listing closure shape differs")
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "cached artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "cached runtime path is not absolute")
        bind(inputs, name, expected)
    bind(inputs, PURE, PURE_SHA)
    bind(inputs, OLD / "baseline/comparison.json", OLD_BASELINE_PROOF_SHA)
    run = read(OLD / "list-driver/run.json")
    require(run["phase"] == "list-driver" and run["compiler_commit"] == BASE and
            run["completed"] is True and run["exit_code"] == 0 and run["compiler_read_audit_passed"] is True and
            run["source_identity_sha256"] == proof["source_identity_sha256"], "cached listing run identity differs")
    for name, expected in run["input_sha256"].items():
        require(inputs.get(name) == expected, "cached listing input is outside its proof closure")
    for name in ("run.json", "phase.log", "placed.json", "timing.json"):
        require(str(OLD / "list-driver" / name) in inputs, "cached proof lacks listing output: " + name)
    guide = OLD / "baseline/timing.json"
    require(inputs.get(str(guide)) == run["driver_guide_sha256"] == proof["driver_guide_sha256"] and
            len(read(guide)["critical_paths"]) == 15290 and
            len(proof["guide_evidence"]["reported_lut_to_arithmetic_data_edges"]) == 1,
            "actual authenticated full guide/sole data edge differs")
    return run, proof


def expected_command(parent, phase):
    require(phase == "list-driver", "only diagnostic list-driver replay is implemented")
    command = list(parent["command"])
    require(command.count("--no-route") == 1 and command.count("--remap-lut-driver-critical") == 1 and
            command[command.index("--remap-lut-driver-critical") + 1] == str(OLD / "baseline/timing.json") and
            command.count("--remap-lut-driver-candidate") == 1 and
            command[command.index("--remap-lut-driver-candidate") + 1] == "-1" and
            command.count("--timing-report-paths") == 1 and
            command[command.index("--timing-report-paths") + 1] == str(PATH_LIMIT),
            "cached full listing command/guide selectors differ")
    for option, name in (("--write", "placed.json"), ("--report", "timing.json")):
        require(command.count(option) == 1, "cached output selector is ambiguous: " + option)
        command[command.index(option) + 1] = str(PHASES[phase] / name)
    command[0] = str(HERE / "nextpnr-mistral")
    require(command.count("--router") == 1 and command[command.index("--router") + 1] == "gpu" and
            command.count("--gpu-device") == 1 and command[command.index("--gpu-device") + 1] == "1" and
            not any(option in command for option in ("--rbf", "--compress-rbf", "--no-place", "--no-pack")),
            "diagnostic replay changed the inherited placement profile")
    return command


def expected_runtime(parent, source):
    runtime = json.loads(json.dumps(parent["execution"]))
    old = parent["command"][0]
    require(runtime["files"].pop(old) == source["input_sha256"][old], "cached runtime executable differs")
    runtime["files"][str(HERE / "nextpnr-mistral")] = source["binary_sha256"]
    runtime["environment"]["PATH"] = str(HERE) + ":/usr/bin:/bin"
    return runtime


def record_template(source, identity_sha, phase, execution):
    parent = read(OLD / "list-driver/run.json")
    return {"schema": 1, "kind": "cross-binary diagnostic rejection replay only", "phase": phase,
        "compiler_commit": source["result_commit"], "delta_base_commit": BASE,
        "source_identity_sha256": identity_sha, "source_archive_sha256": source["source_archive_sha256"],
        "binary_sha256": source["binary_sha256"], "host_validation_sha256": source["host_validation_sha256"],
        "cached_full_listing_proof_sha256": OLD_PROOF_SHA,
        "cached_full_listing_run_sha256": source["cached_full_listing_run_sha256"],
        "driver_guide_kind": "authenticated predecessor binary actual full predicted placed baseline report",
        "driver_guide_sha256": source["driver_guide_sha256"], "timing_report_paths": PATH_LIMIT,
        "predecessor_host_validation_path": str(PREDECESSOR_HOST),
        "predecessor_host_validation_sha256": PREDECESSOR_HOST_SHA,
        "focused_host_validation_path": str(FOCUSED_HOST), "focused_host_validation_sha256": FOCUSED_HOST_SHA,
        "inherited_timing_and_focused_checks_reexecuted_for_this_binary": False,
        "helper_sha256": source["helper_sha256"], "command": expected_command(parent, phase),
        "diagnostic_environment": parent["diagnostic_environment"], "cwd": parent["cwd"], "execution": execution,
        "input_sha256": {**source["input_sha256"], str(IDENTITY): identity_sha}, "driver_candidate": -1,
        "cross_binary_reference": True, "own_disabled_driver_baseline_available": False,
        "driver_stage_is_last": True, "diagnostic_only": True, "routed_proof_or_timing_gain_claimed": False,
        "completed": False, "hardware_tested": False}


def authenticate_phase(run, source, identity_sha):
    expected = record_template(source, identity_sha, run["phase"], run["execution"])
    mutable = {"completed", "elapsed_seconds", "exit_code", "output_sha256", "compiler_read_audit_passed",
               "failure", "exit_code_is_adapter_sentinel"}
    require({key: value for key, value in run.items() if key not in mutable} ==
            {key: value for key, value in expected.items() if key not in mutable}, "actual replay metadata differs")
    require(run["execution"] == expected_runtime(read(OLD / "list-driver/run.json"), source),
            "actual runtime differs beyond new compiler/PATH")
    require(type(run["completed"]) is bool and "failure" not in run and "exit_code_is_adapter_sentinel" not in run,
            "replay has failed/sentinel execution")
    if run["completed"]:
        folder = PHASES[run["phase"]]
        require(type(run["exit_code"]) is int and run["exit_code"] == 0 and
                type(run["elapsed_seconds"]) in (int, float) and math.isfinite(run["elapsed_seconds"]) and
                run["elapsed_seconds"] >= 0 and run["compiler_read_audit_passed"] is True and
                set(run["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")},
                "completed replay lacks audited normal exit/output closure")


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def snapshot(repo, label, archives, repositories, expected=None):
    commit = git(repo, "rev-parse", "HEAD").decode().strip()
    require(expected is None or commit == expected, "source commit differs: " + label)
    require(not git(repo, "status", "--porcelain=v1", "--untracked-files=no").strip(), "dirty source/submodule: " + label)
    payload = git(repo, "archive", "--format=tar", commit)
    member = "archives/" + label + ".tar"
    archives[member] = payload
    links = {}
    for entry in git(repo, "ls-tree", "-r", "-z", commit).split(b"\0"):
        if not entry:
            continue
        header, name = entry.split(b"\t", 1)
        mode, _, object_id = header.decode().split()
        if mode == "160000":
            name = name.decode()
            initialized = (repo / name / ".git").exists()
            links[name] = {"commit": object_id, "archived": initialized}
            if initialized:
                snapshot(repo / name, label + "/" + name, archives, repositories, object_id)
    repositories[label] = {"path": str(repo), "commit": commit,
        "tree": git(repo, "rev-parse", commit + "^{tree}").decode().strip(),
        "archive_member": member, "archive_sha256": hashlib.sha256(payload).hexdigest(), "gitlinks": links}


def check_library(repositories, inputs):
    require(str(OLD / "source-identity.json") in inputs, "predecessor library identity is not closed")
    old = read(OLD / "source-identity.json")["repositories"]
    select = lambda rows: {name: row for name, row in rows.items() if name == "mistral" or name.startswith("mistral/")}
    require("mistral" in repositories and select(repositories) == select(old), "Mistral model/library identity changed")


def host_sources(validation, selected_source=SOURCE):
    result = {}
    for path, expected in validation["source_sha256"].items():
        path = Path(path)
        require(".." not in path.parts and digest(expected), "invalid host source pathname/hash")
        if path.is_absolute():
            require(path.is_relative_to(selected_source), "host source escaped selected checkout")
            path = path.relative_to(selected_source)
        require(str(path) not in result, "duplicate host source member")
        result[str(path)] = expected
    return result


def checks(document, required):
    require(set(document["checks"]) == set(required) and all(
        row["passed"] is True and type(row["exit_code"]) is int and row["exit_code"] == 0 and
        type(row["cases"]) is int and row["cases"] == required[name] and
        type(row["elapsed_seconds"]) in (int, float) and math.isfinite(row["elapsed_seconds"]) and row["elapsed_seconds"] >= 0
        for name, row in document["checks"].items()), "actual host checks are incomplete or failed")


def check_validation(validation, commit, binary, inputs):
    require(validation["schema"] == 1 and validation["result_commit"] == commit and validation["delta_base_commit"] == BASE and
            validation["clean_committed_checkout"] is True and validation["build_passed"] is True and
            validation["binary_sha256"] == binary and validation["hardware_tested"] is False and
            validation["diagnostic_only"] is True and validation["new_timing_gain_claimed"] is False,
            "host validation/compiler diagnostic identity differs")
    checks(validation, {"driver_backend": 7, "driver_cli": 10})
    require(validation["predecessor_host_validation_path"] == str(PREDECESSOR_HOST) and
            validation["predecessor_host_validation_sha256"] == PREDECESSOR_HOST_SHA and
            validation["focused_host_validation_path"] == str(FOCUSED_HOST) and
            validation["focused_host_validation_sha256"] == FOCUSED_HOST_SHA, "closed predecessor host identities differ")
    bind(inputs, PREDECESSOR_HOST, PREDECESSOR_HOST_SHA)
    bind(inputs, FOCUSED_HOST, FOCUSED_HOST_SHA)
    predecessor, focused = read(PREDECESSOR_HOST), read(FOCUSED_HOST)
    require(predecessor["result_commit"] == BASE and predecessor["clean_committed_checkout"] is True and
            predecessor["build_passed"] is True and predecessor["hardware_tested"] is False and
            focused["result_commit"] == "1cdef559c0e22a96bb0712f3ec348468b348f156" and
            focused["clean_committed_checkout"] is True and focused["build_passed"] is True and focused["hardware_tested"] is False,
            "closed predecessor host is not finalized")
    checks(predecessor, {"timing_paths_backend": 3, "timing_paths_cli": 4})
    checks(focused, {"timing_paths_backend": 3, "timing_paths_cli": 4, "driver_backend": 7,
                     "driver_cli": 10, "focused_backend": 37})
    previous = host_sources(predecessor, TOOLCHAIN / "src/nextpnr-timing-paths-full-264")
    current = host_sources(validation)
    require(len(previous) == 16 and set(current) == set(previous) and DELTA_FILES <= set(previous) and
            all(current[name] == previous[name] for name in previous.keys() - DELTA_FILES) and
            validation["unchanged_inherited_source_sha256"] ==
            {name: previous[name] for name in sorted(previous.keys() - DELTA_FILES)} and
            validation["predecessor_timing_checks_not_rerun"] == predecessor["checks"] and
            validation["focused_check_not_rerun"] == focused["checks"]["focused_backend"] and validation["artifact_sha256"],
            "host record changed inherited source or misstates non-rerun checks")
    # These original host/source/runtime paths already belong to the flat
    # predecessor proof; require their membership instead of replaying it.
    for document in (predecessor, focused):
        for path, expected in document["artifact_sha256"].items():
            path = str(Path(path).absolute() if Path(path).is_absolute() else ROOT / path)
            require(inputs.get(path) == expected, "predecessor artifact is outside the cached proof closure")
    for path, expected in validation["artifact_sha256"].items():
        bind(inputs, path if Path(path).is_absolute() else ROOT / path, expected)


def authenticate_freeze(identity_sha):
    inputs = {}
    bind(inputs, IDENTITY, identity_sha)
    source = read(IDENTITY)
    require(source["schema"] == 1 and digest(source["result_commit"], 40) and source["delta_base_commit"] == BASE and
            source["cached_full_listing_proof_sha256"] == OLD_PROOF_SHA and source["timing_report_paths"] == PATH_LIMIT and
            source["clean_committed_checkout_at_freeze"] is True and source["diagnostic_replay_only"] is True and
            source["own_disabled_driver_baseline_available"] is False and source["full_or_selected_phase_available"] is False,
            "frozen diagnostic identity differs")
    for path, expected in source["input_sha256"].items():
        require(Path(path).is_absolute(), "frozen input is not absolute")
        bind(inputs, path, expected)
    parent, _ = reference(inputs)
    require(source["helper_sha256"] == {name: inputs.get(str(HERE / name)) for name in HELPERS} and
            source["cached_full_listing_run_sha256"] == inputs[str(OLD / "list-driver/run.json")] and
            source["driver_guide_sha256"] == inputs[str(OLD / "baseline/timing.json")] and
            source["binary_sha256"] == inputs[str(HERE / "nextpnr-mistral")] and
            source["source_archive_sha256"] == inputs[str(HERE / "source.tar.gz")] and
            source["host_validation_sha256"] == inputs[source["host_validation_path"]], "frozen aliases differ")
    validation = read(source["host_validation_path"])
    check_validation(validation, source["result_commit"], source["binary_sha256"], inputs)
    check_library(source["repositories"], inputs)
    require(source["commands"] == {phase: expected_command(parent, phase) for phase in PHASES} and
            source["diagnostic_environment"] == parent["diagnostic_environment"], "frozen diagnostic profile differs")
    with tarfile.open(HERE / "source.tar.gz", "r:gz") as outer:
        rows = source["repositories"]
        expected = {row["archive_member"]: row["archive_sha256"] for row in rows.values()}
        members = outer.getmembers()
        require(len(members) == len(expected) and all(member.isfile() for member in members) and
                {member.name for member in members} == set(expected), "archive member set differs")
        payloads = {}
        for member in members:
            payload = outer.extractfile(member).read()
            require(hashlib.sha256(payload).hexdigest() == expected[member.name], "archive payload differs")
            payloads[member.name] = payload
        require(rows["nextpnr"]["path"] == str(SOURCE) and rows["nextpnr"]["commit"] == source["result_commit"] and
                rows["mistral"]["path"] == str(MISTRAL), "archived repository identities differ")
        with tarfile.open(fileobj=io.BytesIO(payloads[rows["nextpnr"]["archive_member"]]), mode="r:") as archive:
            for name, expected in host_sources(validation).items():
                member = archive.getmember(name)
                require(member.isfile() and hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected,
                        "host-tested bytes differ from committed archive: " + name)
    return source, inputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--binary-sha256", required=True)
    parser.add_argument("--host-validation", type=Path, required=True)
    parser.add_argument("--host-validation-sha256", required=True)
    for name in HELPERS:
        parser.add_argument("--" + name.replace(".", "-").replace("_", "-") + "-sha256", required=True)
    args = parser.parse_args()
    require(args.source.resolve() == SOURCE.resolve() and digest(args.commit, 40) and digest(args.binary_sha256),
            "explicit source/commit/binary pins are unset or differ")
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json", "build-config.txt")),
            "freeze output already exists")
    inputs = {}
    parent, _ = reference(inputs)
    for name in HELPERS:
        bind(inputs, HERE / name, getattr(args, name.replace(".", "_").replace("-", "_") + "_sha256"))
    bind(inputs, args.host_validation, args.host_validation_sha256)
    validation = read(args.host_validation)
    check_validation(validation, args.commit, args.binary_sha256, inputs)
    build = args.build.resolve()
    require(build.is_relative_to(TOOLCHAIN / "build") and sha(build / "nextpnr-mistral") == args.binary_sha256,
            "validated producer binary differs")
    cache = (build / "CMakeCache.txt").read_text()
    require("CMAKE_HOME_DIRECTORY:INTERNAL=" + str(SOURCE) + "\n" in cache and
            re.search(r"^MISTRAL_ROOT:(?:STRING|PATH)=" + re.escape(str(MISTRAL)) + r"$", cache, re.M),
            "build source/library roots differ")
    cache_sha = sha(build / "CMakeCache.txt")
    archives, repositories = {}, {}
    snapshot(SOURCE, "nextpnr", archives, repositories, args.commit)
    subprocess.run(["git", "-C", str(SOURCE), "merge-base", "--is-ancestor", BASE, args.commit], check=True)
    require(set(git(SOURCE, "diff", "--name-only", BASE, args.commit).decode().splitlines()) == DELTA_FILES,
            "committed source delta is not the one reviewed driver diagnostic file")
    previous = host_sources(read(PREDECESSOR_HOST), TOOLCHAIN / "src/nextpnr-timing-paths-full-264")
    for name, expected in previous.items():
        require(hashlib.sha256(git(SOURCE, "show", BASE + ":" + name)).hexdigest() == expected,
                "predecessor tested bytes differ from actual Git base: " + name)
    snapshot(MISTRAL, "mistral", archives, repositories)
    check_library(repositories, inputs)
    with tarfile.open(fileobj=io.BytesIO(archives["archives/nextpnr.tar"]), mode="r:") as archive:
        for name, expected in host_sources(validation).items():
            member = archive.getmember(name)
            require(member.isfile() and hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected,
                    "host-tested source differs from clean committed bytes: " + name)
    commands = {phase: expected_command(parent, phase) for phase in PHASES}
    finish(inputs)
    with (HERE / "nextpnr-mistral").open("xb") as output, (build / "nextpnr-mistral").open("rb") as producer:
        shutil.copyfileobj(producer, output)
    (HERE / "nextpnr-mistral").chmod(0o555)
    bind(inputs, HERE / "nextpnr-mistral", args.binary_sha256)
    require(sha(build / "CMakeCache.txt") == cache_sha, "producer cache changed during freeze")
    with (HERE / "build-config.txt").open("x") as output:
        output.write(cache)
    bind(inputs, HERE / "build-config.txt", cache_sha)
    with (HERE / "source.tar.gz").open("xb") as output:
        with tarfile.open(fileobj=output, mode="w:gz") as archive:
            for name, payload in sorted(archives.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(payload), 0o444, 0
                archive.addfile(member, io.BytesIO(payload))
    bind(inputs, HERE / "source.tar.gz", sha(HERE / "source.tar.gz"))
    source = {"schema": 1, "result_commit": args.commit, "delta_base_commit": BASE,
        "cached_full_listing_proof_sha256": OLD_PROOF_SHA,
        "cached_full_listing_run_sha256": inputs[str(OLD / "list-driver/run.json")],
        "driver_guide_sha256": inputs[str(OLD / "baseline/timing.json")], "timing_report_paths": PATH_LIMIT,
        "repositories": repositories, "binary_sha256": args.binary_sha256,
        "source_archive_sha256": inputs[str(HERE / "source.tar.gz")],
        "host_validation_path": str(args.host_validation.absolute()), "host_validation_sha256": args.host_validation_sha256,
        "helper_sha256": {name: inputs[str(HERE / name)] for name in HELPERS},
        "commands": commands, "diagnostic_environment": parent["diagnostic_environment"],
        "clean_committed_checkout_at_freeze": True, "diagnostic_replay_only": True,
        "own_disabled_driver_baseline_available": False, "full_or_selected_phase_available": False,
        "input_sha256": inputs, "hardware_tested": False}
    finish(inputs)
    with IDENTITY.open("x") as output:
        output.write(json.dumps(source, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"source_identity_sha256": sha(IDENTITY), "compiler_commit": args.commit,
                      "binary_sha256": args.binary_sha256, "inputs": len(inputs)}, indent=2))


if __name__ == "__main__":
    main()
