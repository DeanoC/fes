"""Record current rejection-diagnostic checks and separate inherited host evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
FES = HERE.parents[2]
SOURCE = FES / 'sources/misteross/build/toolchain-ramtest-timing/src/nextpnr-driver-rejections-264'
BUILD = FES / 'sources/misteross/build/toolchain-ramtest-timing/build/nextpnr-driver-rejections-264'
BASE = 'e6d383ced713bc157264de7df3d8cb042edf7da3'
PREDECESSOR = HERE.parent / 'timing-paths-full-264/validation/host-validation.json'
PREDECESSOR_SHA = '9f1c0cecf099802a0991085f964c1ff545fb97408881ae44981e0a08fb56f39f'
FOCUSED = HERE.parent / 'timing-paths-264/validation/host-validation.json'
FOCUSED_SHA = 'd68ff437d71d0c74447d391a4b543ce22d3cad6686b7fe8d6ca15bf330594d64'
CHANGED = {'mistral/lut_driver_copy.cc'}

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--commit', required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.commit)
    assert git('rev-parse', 'HEAD') == args.commit and not git('status', '--porcelain')
    assert git('merge-base', BASE, args.commit) == BASE
    assert set(git('diff', '--name-only', BASE, args.commit).splitlines()) == CHANGED
    assert sha(PREDECESSOR) == PREDECESSOR_SHA and sha(FOCUSED) == FOCUSED_SHA
    previous = json.loads(PREDECESSOR.read_text()); focused = json.loads(FOCUSED.read_text())
    assert previous['result_commit'] == BASE and previous['clean_committed_checkout'] is True
    assert previous['build_passed'] is True and previous['hardware_tested'] is False
    closed = {}
    for name, count in [('timing_paths_backend', 3), ('timing_paths_cli', 4)]:
        check = previous['checks'][name]
        assert check['passed'] is True and check['exit_code'] == 0 and check['cases'] == count
        closed[name] = check
    check = focused['checks']['focused_backend']
    assert check['passed'] is True and check['exit_code'] == 0 and check['cases'] == 37
    assert focused['result_commit'] == '1cdef559c0e22a96bb0712f3ec348468b348f156'
    for document in (previous, focused):
        for path, expected in document['artifact_sha256'].items():
            assert sha(path) == expected
    old_source = FES / 'sources/misteross/build/toolchain-ramtest-timing/src/nextpnr-timing-paths-full-264'
    sources, inherited = {}, {}
    for path, expected in previous['source_sha256'].items():
        old_path = Path(path); assert sha(old_path) == expected
        rel = str(old_path.relative_to(old_source))
        assert hashlib.sha256(subprocess.check_output(['git', '-C', str(SOURCE), 'show', BASE+':'+rel])).hexdigest() == expected
        now = SOURCE / rel; sources[str(now)] = sha(now)
        if rel not in CHANGED:
            assert sources[str(now)] == expected
            inherited[rel] = expected
    assert len(sources) == 16 and len(inherited) == 15
    v = HERE / 'validation'; checks = {}
    backend = (v / 'driver-backend.log').read_text()
    assert '[  PASSED  ] 7 tests.' in backend and '[  FAILED  ]' not in backend
    match = re.search(r'\[==========\] 7 tests from .* ran\. \((\d+) ms total\)', backend); assert match
    checks['driver_backend'] = dict(passed=True, exit_code=0, cases=7, elapsed_seconds=int(match.group(1))/1000)
    cli = (v / 'driver-cli.log').read_text()
    match = re.search(r'Ran 10 tests in ([\d.]+)s\s+OK\s*$', cli)
    assert match and not re.search(r'FAIL|ERROR', cli)
    checks['driver_cli'] = dict(passed=True, exit_code=0, cases=10, elapsed_seconds=float(match.group(1)))
    build = (v / 'build.log').read_text()
    assert 'Built target nextpnr-mistral' in build and 'Built target nextpnr-mistral-test' in build
    assert 'error:' not in build and 'fatal error:' not in build
    artifacts = [v / name for name in ['dependency-setup.log', 'configure.log', 'build.log', 'driver-backend.log', 'driver-cli.log']]
    artifacts += [BUILD / 'nextpnr-mistral', BUILD / 'nextpnr-mistral-test', BUILD / 'CMakeCache.txt', Path(__file__).resolve()]
    record = dict(schema=1, result_commit=args.commit, delta_base_commit=BASE,
                  clean_committed_checkout=True, build_passed=True, diagnostic_only=True,
                  hardware_tested=False, new_timing_gain_claimed=False,
                  binary_sha256=sha(BUILD / 'nextpnr-mistral'), test_binary_sha256=sha(BUILD / 'nextpnr-mistral-test'),
                  source_sha256=sources, artifact_sha256={str(p): sha(p) for p in artifacts}, checks=checks,
                  predecessor_host_validation_path=str(PREDECESSOR), predecessor_host_validation_sha256=PREDECESSOR_SHA,
                  predecessor_timing_checks_not_rerun=closed,
                  focused_host_validation_path=str(FOCUSED), focused_host_validation_sha256=FOCUSED_SHA,
                  focused_check_not_rerun=check, unchanged_inherited_source_sha256=inherited,
                  cold_build_warning_count=build.count('warning:'))
    output = v / 'host-validation.json'
    with output.open('x') as stream:
        stream.write(json.dumps(record, sort_keys=True, indent=2, allow_nan=False)+'\n')
    assert git('rev-parse', 'HEAD') == args.commit and not git('status', '--porcelain')
    assert sha(PREDECESSOR) == PREDECESSOR_SHA and sha(FOCUSED) == FOCUSED_SHA
    print(json.dumps(dict(commit=args.commit, binary_sha256=record['binary_sha256'],
                         host_validation_sha256=sha(output), checks=checks,
                         inherited_timing_checks_not_rerun=closed, focused_check_not_rerun=check,
                         cold_build_warning_count=record['cold_build_warning_count']), indent=2))

if __name__ == '__main__':
    main()
