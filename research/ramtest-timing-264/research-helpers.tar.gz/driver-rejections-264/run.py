"""Root-only no-route replay with one bounded rejection diagnostic."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

import freeze


def pure_listing(source):
    path = freeze.HERE / "compare_listing.py"
    freeze.require(freeze.sha(path) == source["helper_sha256"][path.name], "current comparator changed")
    spec = importlib.util.spec_from_file_location("driver_rejection_replay_check", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=freeze.PHASES)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    source, inputs = freeze.authenticate_freeze(args.source_identity_sha256)
    folder = freeze.PHASES[args.phase]
    freeze.require(not folder.exists(), "replay output already exists")
    sys.path.insert(0, str(freeze.MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    tool_identity = (f"base_commit={freeze.BASE}; experimental_source_sha256={source['source_archive_sha256']}; "
                     f"sha256={source['binary_sha256']}")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(freeze.HERE / "nextpnr-mistral", tool_identity)}, 1)
    try:
        freeze.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                       "ambient compiler diagnostics are forbidden")
        record = freeze.record_template(source, args.source_identity_sha256, args.phase, invocation.inputs)
        freeze.authenticate_phase(record, source, args.source_identity_sha256)
        for path, expected in record["execution"]["files"].items():
            freeze.bind(inputs, path, expected)
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        try:
            with (folder / "phase.log").open("x") as log:
                result = audited_run(record["command"], source_root=freeze.MODULE, cwd=record["cwd"],
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log,
                    stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            record["compiler_read_audit_passed"] = True
            invocation.verify()
            freeze.require(result.returncode == 0 and all((folder / name).is_file() and (folder / name).stat().st_size > 0
                           for name in ("phase.log", "placed.json", "timing.json")), "replay did not complete with actual outputs")
            helper = pure_listing(source)
            helper.replay_evidence(source, inputs)
            record["output_sha256"] = {str(folder / name): freeze.sha(folder / name)
                                      for name in ("phase.log", "placed.json", "timing.json")}
            record["completed"] = True
            freeze.authenticate_phase(record, source, args.source_identity_sha256)
            freeze.finish({**inputs, **record["output_sha256"]})
            print(json.dumps({key: record[key] for key in ("phase", "compiler_commit", "completed", "exit_code", "elapsed_seconds")}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
