"""Direct serialized cross-binary diagnostic proof; no trial or routed gain."""
import argparse
import importlib.util
import io
import json
from pathlib import Path
import re
import tarfile

import freeze


def native_helper(inputs):
    freeze.bind(inputs, freeze.PURE, freeze.PURE_SHA)
    spec = importlib.util.spec_from_file_location("driver_rejection_frozen_native_parser", freeze.PURE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def port_bits(top, cell, port):
    freeze.require(cell in top["cells"], "diagnostic cell is absent")
    value = top["cells"][cell]
    if port in value["connections"]:
        return value["connections"][port], value["port_directions"][port]
    match = re.fullmatch(r"(.+)\[(\d+)\]", port)
    freeze.require(match is not None and match[1] in value["connections"] and
                   int(match[2]) < len(value["connections"][match[1]]), "diagnostic native port is absent")
    return [value["connections"][match[1]][int(match[2])]], value["port_directions"][match[1]]


def reason_tokens(source):
    with tarfile.open(freeze.HERE / "source.tar.gz", "r:gz") as outer:
        payload = outer.extractfile(source["repositories"]["nextpnr"]["archive_member"]).read()
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:") as archive:
        text = archive.extractfile("mistral/lut_driver_copy.cc").read().decode()
    # Literal reason tokens, including the two existing ternary branches,
    # come from the authenticated current driver body rather than guessed logs.
    return set(re.findall(r'"([a-z]+(?:-[a-z]+)+)"', text))


def rejection(log, source, top):
    pattern = re.compile(r"^Info: LUT driver copy rejection source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) reason=([a-z]+(?:-[a-z]+)+)(.*)$")
    rows = [line for line in log.splitlines() if line.startswith("Info: LUT driver copy rejection")]
    freeze.require(len(rows) == 1, "replay requires exactly one bounded pretrial rejection row")
    match = pattern.fullmatch(rows[0])
    freeze.require(match is not None and match[4] in reason_tokens(source), "unknown/malformed current rejection reason")
    cached = freeze.read(freeze.OLD / "list-driver/comparison.json")
    edge = [match[1], match[2], match[3]]
    freeze.require(cached["guide_evidence"]["reported_lut_to_arithmetic_data_edges"] == [edge],
                   "rejection edge differs from the sole authenticated reported edge")
    cells = top["cells"]
    source_bits, source_dir = port_bits(top, edge[0], "Q")
    sink_bits, sink_dir = port_bits(top, edge[1], edge[2])
    freeze.require(cells[edge[0]]["type"] in {"MISTRAL_ALUT%d" % width for width in range(2, 7)} and
                   cells[edge[1]]["type"] == "MISTRAL_ALUT_ARITH" and source_dir == "output" and sink_dir == "input" and
                   source_bits == sink_bits and len(source_bits) == 1 and type(source_bits[0]) is int,
                   "rejection does not name the actual retained ordinary LUT-to-arithmetic data edge")
    details = {}
    allowed = {"cell", "type", "port", "net", "owner", "owner_type", "bound", "weak", "cluster", "region",
               "pseudo", "keep", "dont_touch", "mlab", "users", "kind", "table", "count", "endpoint_port", "clock_index",
               "cell_name_exists", "net_name_exists", "alias_name_exists", "width", "params_count", "lut_present", "lut_fully_defined",
               "lut_size", "ports_count", "q_pin_state", "net_present", "driver_present", "global", "clkconstr",
               "routed", "constant", "boundary", "protected", "driver_port_present", "driver_port_output", "driver_port_matching_net"}
    for item in match[5].split():
        key, separator, value = item.partition("=")
        freeze.require(separator and value and key not in details and
                       (key in allowed or re.fullmatch(r"input_[A-F]_(present|state|hasnet|ordinary)", key)),
                       "unknown/duplicate rejection metadata field")
        details[key] = value
    freeze.require(len(details) <= 64, "rejection metadata exceeds the bounded diagnostic row")
    if "cell" in details:
        freeze.require(details["cell"] in cells and details.get("type") == cells[details["cell"]]["type"],
                       "rejection detail cell/type is absent or stale")
        if "port" in details:
            bits, _ = port_bits(top, details["cell"], details["port"])
            if "net" in details:
                freeze.require(details["net"] in top["netnames"] and top["netnames"][details["net"]]["bits"] == bits,
                               "rejection detail native port/net connection differs")
    else:
        freeze.require("type" not in details, "rejection type lacks its actual cell")
    if "net" in details:
        freeze.require(details["net"] in top["netnames"], "rejection detail native net is absent")
    if "endpoint_port" in details:
        freeze.require("cell" in details, "endpoint metadata lacks actual cell")
        port_bits(top, details["cell"], details["endpoint_port"])
    if "owner" in details:
        owner = details["owner"]
        freeze.require(owner in cells and details.get("owner_type") == cells[owner]["type"], "protected owner cell/type is stale")
        for key in ("bound", "weak", "cluster", "region", "pseudo", "keep", "dont_touch", "mlab"):
            freeze.require(details.get(key) in ("0", "1"), "protected owner flags are incomplete/nonboolean")
        attributes = cells[owner]["attributes"]
        freeze.require(details["bound"] == str(int(bool(attributes.get("NEXTPNR_BEL")))) and
                       details["mlab"] == str(int(cells[owner]["type"] == "MISTRAL_MLAB")) and
                       details["keep"] == str(int("keep" in attributes)) and
                       details["dont_touch"] == str(int("dont_touch" in attributes)), "serialized protected owner flags differ")
        if match[4] == "source-protected-lab":
            loc = lambda name: cells[name]["attributes"]["NEXTPNR_BEL"].split(".")[1:3]
            freeze.require(loc(owner) == loc(edge[0]) and details["bound"] == "1" and
                           (details["weak"] == "0" or any(details[key] == "1" for key in
                            ("cluster", "region", "pseudo", "keep", "dont_touch", "mlab"))),
                           "protected-LAB reason lacks its actual same-LAB owner/reported exclusion flag")
    users = sum(connection.count(source_bits[0]) for cell in cells.values()
                for port, direction in cell["port_directions"].items() if direction == "input"
                for connection in (cell["connections"][port],))
    freeze.require(users == 49, "retained source Q native consumer multiplicity differs")
    return {"edge": edge, "reason": match[4], "details": details, "raw_log_row": rows[0],
            "retained_original_q_native_users": users, "row_count": 1,
            "native_edge_and_named_detail_references_checked": True,
            "hidden_pin_timing_cache_and_guard_state_independently_proved": False}


def replay_evidence(source, inputs):
    native = native_helper(inputs)
    folder = freeze.PHASES["list-driver"]
    freeze.require(not any((folder / name).exists() for name in ("core.rbf", "routed.json")), "diagnostic replay has routed output")
    before = native.read_netlist(freeze.OLD / "list-driver/placed.json")
    after = native.read_netlist(folder / "placed.json")
    old, new = before["modules"]["top"], after["modules"]["top"]
    freeze.require(type(before["creator"]) is str and type(after["creator"]) is str and
                   native.canonical(old) == native.canonical(new), "cross-binary actual native module differs beyond creator")
    freeze.require(native.canonical(old["cells"].pll_ports) == native.canonical(new["cells"].pll_ports) and
                   all(list(old[name]) == list(new[name]) for name in ("cells", "netnames")), "native owner order/PLL occurrences differ")
    report = freeze.read(folder / "timing.json")
    freeze.require(native.canonical(report) == native.canonical(freeze.read(freeze.OLD / "list-driver/timing.json")) and
                   report["timing_report_paths"] == freeze.PATH_LIMIT and len(report["critical_paths"]) == 15290,
                   "actual complete predicted timing report differs from authenticated predecessor")
    oldlog = (freeze.OLD / "list-driver/phase.log").read_text()
    log = (folder / "phase.log").read_text()
    freeze.require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                   not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...")) and
                   log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1,
                   "diagnostic replay lacks completed current predicted no-route report")
    freeze.require(native.diagnostics(oldlog) == native.diagnostics(log), "retained upstream qualifications differ")
    metrics = native.PLACEMENT_METRICS.findall(oldlog)
    freeze.require(len(metrics) == 71 and metrics == native.PLACEMENT_METRICS.findall(log), "all71 placement metrics differ")
    driver = [line for line in log.splitlines() if line.startswith("Info: LUT driver copy")]
    olddriver = [line for line in oldlog.splitlines() if line.startswith("Info: LUT driver copy")]
    details = rejection(log, source, new)
    freeze.require(olddriver == ["Info: LUT driver copy discovery: 1 bounded data edges.",
                                "Info: LUT driver copy: 0 qualified candidates; no candidate applied."] and
                   driver == [olddriver[0], details["raw_log_row"], olddriver[1]],
                   "replay changed discovery/qualification or logged trials/application")
    counts = re.findall(r"^Info: Timing report includes (\d+) additional registered setup endpoint paths \(limit (\d+) per domain pair\)\.$", log, re.M)
    freeze.require(counts == [("15284", str(freeze.PATH_LIMIT))], "full predicted report count/limit log differs")
    return {"old_creator": before["creator"], "new_creator": after["creator"], "only_creator_metadata_may_differ": True,
            "complete_typed_native_module_exact_across_binaries": True, "cell_and_net_export_order_exact": True,
            "lossless_ordered_pll_occurrences_exact": True, "matched_ordinary_placement_metrics": 71,
            "retained_upstream_qualification_messages_exact": True, "complete_predicted_report_exact": True,
            "actual_report_path_count": 15290, "bounded_reported_edges": 1, "qualified_driver_ordinals": [],
            "no_trial_or_per_edge_discovery_rows": True, "no_candidate_applied": True, "pretrial_rejection": details,
            "cell_count": len(new["cells"]), "named_net_count": len(new["netnames"])}


def comparison(identity_sha):
    source, inputs = freeze.authenticate_freeze(identity_sha)
    folder = freeze.PHASES["list-driver"]
    freeze.bind(inputs, folder / "run.json", freeze.sha(folder / "run.json"))
    run = freeze.read(folder / "run.json")
    freeze.authenticate_phase(run, source, identity_sha)
    freeze.require(run["completed"] is True, "actual diagnostic replay did not complete")
    for mapping in (run["input_sha256"], run["execution"]["files"], run["output_sha256"]):
        for path, expected in mapping.items():
            freeze.bind(inputs, path, expected)
    evidence = replay_evidence(source, inputs)
    freeze.finish(inputs)
    artifacts = {str(Path(path).relative_to(freeze.ROOT)): expected for path, expected in inputs.items()
                 if Path(path).is_relative_to(freeze.ROOT)}
    execution = {path: expected for path, expected in inputs.items() if not Path(path).is_relative_to(freeze.ROOT)}
    execution.update(run["execution"]["files"])
    return {"schema": 1, "phase": "driver-rejections-list-driver", "compiler_commit": source["result_commit"],
        "delta_base_commit": freeze.BASE, "source_identity_sha256": identity_sha,
        "generator_sha256": source["helper_sha256"]["compare_listing.py"], "frozen_native_parser_sha256": freeze.PURE_SHA,
        "cached_full_listing_proof_sha256": freeze.OLD_PROOF_SHA, "driver_guide_sha256": source["driver_guide_sha256"],
        "driver_guide_kind": run["driver_guide_kind"], "timing_report_paths": freeze.PATH_LIMIT,
        "candidate_completed": True, "elapsed_seconds": run["elapsed_seconds"], **evidence,
        "cross_binary_reference": True, "own_same_binary_disabled_driver_baseline_available": False,
        "same_binary_in_memory_rollback_proved": False, "independent_boolean_equivalence_proved": False,
        "physical_pin_preservation_proved": False, "in_memory_cache_or_indexed_store_identity_proved": False,
        "gpu_net_ids_proved": False, "routed_graph_proof_available": False, "new_timing_gain_claimed": False,
        "hardware_tested": False, "old_comparators_or_authenticators_replayed": False,
        "proof_limitations": [
            "This is a diagnostic cross-binary no-route replay; the creator may differ while complete actual serialized modules and predicted reports must match.",
            "The prior baseline/guide and topology/window proof are cached by the exact artifact closure; no previous generator or authenticator is executed.",
            "One current pretrial reason is compiler diagnostic evidence; unexported pin states, physical mappings, timing/cache/owner guard state are not independently proved.",
            "No trial, fresh qualified candidate, selected Boolean copy, routed gain, RBF, final hold or hardware acceptance is claimed."],
        "artifact_sha256": dict(sorted(artifacts.items())), "execution_file_sha256": dict(sorted(execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=freeze.PHASES)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    output = freeze.PHASES[args.phase] / "comparison.json"
    freeze.require(not output.exists(), "comparison output already exists")
    result = comparison(args.source_identity_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("phase", "compiler_commit", "complete_typed_native_module_exact_across_binaries",
        "complete_predicted_report_exact", "qualified_driver_ordinals", "pretrial_rejection", "routed_graph_proof_available")}, indent=2))


if __name__ == "__main__":
    main()
