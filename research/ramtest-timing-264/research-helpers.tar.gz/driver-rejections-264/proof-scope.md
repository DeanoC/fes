# Pretrial rejection diagnostic replay

Root alone activates and executes this package. Authors execute no helpers,
compilers, builds, tests, routes or hardware operations. Every previous source,
binary, helper and proof remains immutable.

The source base is `e6d383ced713bc157264de7df3d8cb042edf7da3`. Activation
requires the actual clean committed source, build, binary and finalized host
manifest pins plus all four reviewed helper hashes. The exact source delta
must be only `mistral/lut_driver_copy.cc`; the root-reviewed delta adds bounded
first-pretrial-rejection diagnostics without changing guard predicates,
qualification, constraints, placement/site budgets or transaction semantics.
Placeholders fail closed and all outputs are exclusive new files.

Current host checks are exactly driver backend 7 and driver CLI 10 cases,
passing with exit 0. The host binds all 16 current source files and requires
15 unchanged entries against the finalized full-report host `9f1c0cec…`.
Its timing backend 3/CLI 4 checks and the older `d68ff437…` focused 37 check
are separately labeled as not rerun. Actual current logs, record script,
binary/test binary and build cache are hashed. Git base bytes and the clean
committed archive must match the host source map. The Mistral library/model,
tree, archives and initialized gitlinks must equal the frozen predecessor.

The completed full listing proof `a3d7cee7…` supplies its flat 430-artifact,
281-runtime closure, including actual predecessor run/log/native placement,
the 15,290-path guide and both preceding host records. No old generator,
comparison or authenticator is replayed. Only the pinned `32fd10…` pure
lossless native parser/canonical serializer and diagnostic regex constants
are imported. Supplied original pathnames, including symlinks, are retained
and rehashed at completion.

There is exactly one phase: `list-driver`. Its command is the previous full
listing command with only the executable, placement output and report output
paths replaced. It retains the exact existing actual predecessor guide,
`--timing-report-paths 16384`, candidate `-1`, seed, GPU1 selectors and full
upstream guarded selections/environment. Controlled FunctionalInvocation
runtime differs only in executable and PATH; the compiler-read audit remains
mandatory. The GPU router, analogue signoff and RBF writer do not execute.
There is no new disabled-driver baseline, selection force or report pruning.

The new result must match the complete typed predecessor native module:
numeric connections, native consumers, settings, attributes, parameters,
ports, BELs, available pin fields, cell/net export order and lossless ordered
duplicate PLL records. Only top-level creator metadata may differ across
binaries, with both values disclosed. All 71 placement metrics and retained
upstream qualification records remain exact. The entire actual predicted
report must equal the authenticated predecessor report, preserving its six
legacy prefix paths, modeled Fmax/constraints and all 15,284 additional native
paths, windows, edges, endpoint uniqueness and count/order evidence already
closed by that predecessor proof. No routed delay or BUF projection is used.

Exactly one reported ordinary LUT-Q to arithmetic operand edge must remain
unchanged, with its original 49 native Q users. The new log must differ in
the driver block only by one bounded rejection row between discovery count 1
and qualified count 0. No per-edge discovery, timed trial, candidate or applied
copy row is permitted. Its reason token must occur in the authenticated
current driver body, with exact actual source/sink/port references. Named
detail cell/type/port/net and protected-owner references are checked where
serialized; hidden state remains current compiler diagnostic evidence.

The proof is cross-binary serialized preservation, not a same-binary baseline
or in-memory rollback/cache proof. It proves no independent Boolean copy,
full FES_PINMAP_V1, indexed user stores/free lists/buckets/pointers, GPU IDs,
routed graph, RBF, routed timing gain, final hold or hardware acceptance.
Any future genuine qualified copy needs a separate declared selected/full
proof package and actual routed timing acceptance.

Root execution API:

1. `freeze.py` with explicit source/commit/build/binary/host and helper pins.
2. `run.py list-driver --source-identity-sha256 SHA` using the actual frozen ID.
3. `compare_listing.py list-driver --source-identity-sha256 SHA` producing its
   own exclusive diagnostic comparison.
