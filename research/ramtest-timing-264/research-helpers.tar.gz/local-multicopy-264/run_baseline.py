"""Record a fresh multicopy-binary control using the unchanged three-stage plan."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-local-multicopy-264"
OLD = RAW / "driver-domains-264/baseline/run.json"
OLD_SHA = "d2afc1e34789d2974748cc86587bf62780b2441a186e05276ee8e9df8ba88156"
OLD_COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"
OLD_BINARY = RAW / "driver-domains-264/nextpnr-mistral"
OLD_BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
OLD_ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
HOST = HERE / "validation/host-validation.json"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
COMMIT, BASE = "81243a1300304d7e598156c692be2fcbf2c16268", OLD_COMMIT
BINARY, ARCHIVE = HERE / "nextpnr-mistral", HERE / "source.tar.gz"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "baseline"
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}
MODEL_KEYS = ("index", "candidate", "groups_budget", "selected_groups", "inner", "outer", "primary_lab", "bel",
              "ena_users", "gain_ps", "ff_shift", "compiled_clock_hold_boundary_guards_passed")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected), "invalid hash")
    require(path not in inputs or inputs[path] == expected, "conflicting original path identity")
    if path not in inputs:
        require(sha(path) == expected, "bound original path changed: " + path)
        inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def clean_source():
    def git(*args):
        return subprocess.run(["git", "-C", str(SOURCE), *args], check=True, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()
    require(git("rev-parse", "HEAD") == COMMIT and not git("status", "--porcelain", "--untracked-files=all") and
            git("merge-base", BASE, COMMIT) == BASE and
            set(git("diff", "--name-only", BASE, COMMIT).splitlines()) ==
            {"mistral/local_remap.cc", "mistral/tests/remap_plan.cc"}, "current compiler source is not the exact clean two-file result")


def command(old):
    result = list(old["command"])
    require(result[0] == str(OLD_BINARY) and result.count("--no-route") == 1 and
            not any(flag in result for flag in ("--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")),
            "retained command is not the disabled-driver predicted baseline")
    result[0] = str(BINARY)
    for flag, path in (("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector")
        result[result.index(flag) + 1] = str(path)
    return result


def expected_execution(old):
    result = copy.deepcopy(old["execution"])
    require(result["files"].pop(str(OLD_BINARY)) == OLD_BINARY_SHA and str(BINARY) not in result["files"] and
            result["environment"]["PATH"] == str(OLD_BINARY.parent) + ":/usr/bin:/bin" and result["gpu_device"] == 1,
            "retained runtime does not contain exactly the expected original compiler/PATH/device")
    result["files"][str(BINARY)] = BINARY_SHA
    result["files"] = dict(sorted(result["files"].items()))
    result["environment"]["PATH"] = str(BINARY.parent) + ":/usr/bin:/bin"
    return result


def local_qualification(log):
    budgets = (8, 1, 1)
    headers = list(re.finditer(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, row.groups())) for row in headers] == [(i, 0, budget, 0, 1) for i, budget in enumerate(budgets)], "fresh three-stage headers differ")
    models = []
    for index, header in enumerate(headers):
        block = log[header.end():headers[index + 1].start() if index + 1 < len(headers) else len(log)]
        trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
        choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
        applications = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
        require(trials and len(choices) == len(applications) == 1 and choices[0][1] == applications[0][1] == "0" and
                trials[-1].end() < choices[0].start() < applications[0].start(), "fresh candidate0/application is not bound to its final trial")
        row, choice = trials[-1].groups(), choices[0].groups()[1:]
        require((row[0], row[1], row[4], row[12], row[7]) == choice and row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and
                1 <= int(row[11]) <= budgets[index] and int(row[7]) >= 250, "fresh local fixed-FF/clock/hold/boundary/gain guards differ")
        models.append({"index": index, "candidate": 0, "groups_budget": budgets[index], "selected_groups": int(row[11]),
            "inner": row[0], "outer": row[1], "primary_lab": [int(row[2]), int(row[3])], "bel": row[4],
            "ena_users": int(row[12]), "gain_ps": int(row[7]), "actual_trial_count": len(trials),
            "prior_trial_rows": [x.groups() for x in trials[:-1]], "ff_shift": [0, 0],
            "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False})
    return models


def prepare(self_sha, scope_sha):
    require(not PROFILE.exists() and not FOLDER.exists(), "fresh control profile or outputs already exist")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (OLD, OLD_SHA),
                           (HOST, HOST_SHA), (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA)):
        bind(inputs, path, expected)
    old, host = read(OLD), read(HOST)
    require(old["completed"] is True and old["exit_code"] == 0 and old["compiler_read_audit_passed"] is True and
            old["phase"] == "baseline" and old["compiler_commit"] == BASE and old["binary_sha256"] == OLD_BINARY_SHA and
            old["source_archive_sha256"] == OLD_ARCHIVE_SHA and old["cwd"] == str(MODULE), "original D2 baseline is not closed")
    for ledger in (old["input_sha256"], old["output_sha256"], old["execution"]["files"], host["artifact_sha256"], host["source_sha256"]):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "flat provenance entry is not an original absolute pathname")
            bind(inputs, path, expected)
    require(host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
            host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and
            host["build_passed"] is host["clean_committed_checkout"] is True and
            set(host["checks"]) == {"repeated-backend", "regression-backend", "remap_plan_cli.py", "local_remap_cli.py"} and
            {name: row["cases"] for name, row in host["checks"].items()} ==
            {"repeated-backend": 4, "regression-backend": 19, "remap_plan_cli.py": 11, "local_remap_cli.py": 12} and
            all(row["passed"] is True for row in host["checks"].values()), "current selected compiler host provenance differs")
    require(old["command"].count("--remap-plan") == 1, "ambiguous retained local plan")
    plan_path = Path(old["command"][old["command"].index("--remap-plan") + 1])
    require(str(plan_path) in inputs, "original plan is not bound")
    plan = read(plan_path)
    require(set(plan) == {"steps"} and len(plan["steps"]) == 3 and [step["groups"] for step in plan["steps"]] == [8, 1, 1] and
            all(set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and
                step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True and
                step["report"] in inputs for step in plan["steps"]), "original exact three-stage descriptors/guide closure differs")
    for name, expected in SCRIPTS.items():
        bind(inputs, MODULE / "scripts" / name, expected)
    runtime = expected_execution(old)
    for path, expected in runtime["files"].items():
        bind(inputs, path, expected)
    clean_source()
    profile = {"schema": 1, "phase": "local-multicopy-three-stage-predicted-control", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA,
        "host_validation_path": str(HOST), "host_validation_sha256": HOST_SHA, "current_host_case_counts": {name: row["cases"] for name, row in host["checks"].items()},
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "retained_baseline_run_sha256": OLD_SHA,
        "original_plan_path": str(plan_path), "original_plan_sha256": inputs[str(plan_path)], "local_plan_steps": plan["steps"],
        "retained_local_models": local_qualification((OLD.parent / "phase.log").read_text()), "command": command(old),
        "cwd": old["cwd"], "diagnostic_environment": old["diagnostic_environment"], "baseline_execution": runtime,
        "authorized_runtime_delta": {"old_compiler_path": str(OLD_BINARY), "new_compiler_path": str(BINARY),
            "old_compiler_sha256": OLD_BINARY_SHA, "new_compiler_sha256": BINARY_SHA, "controlled_path_directory_replaced": True,
            "all_other_execution_fields_and_files_exact": True}, "input_sha256": dict(sorted(inputs.items())),
        "fourth_stage_or_driver_pass_executed": False, "baseline_native_equivalence_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source()
    with PROFILE.open("x") as stream:
        stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source()
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "local_plan_path": str(plan_path)}, indent=2))


def execute(profile_sha):
    inputs = {}
    bind(inputs, PROFILE, profile_sha)
    profile, old = read(PROFILE), read(OLD)
    require(not FOLDER.exists() and profile["command"] == command(old) and profile["baseline_execution"] == expected_execution(old) and
            profile["diagnostic_environment"] == old["diagnostic_environment"] and profile["compiler_commit"] == COMMIT and
            profile["host_validation_sha256"] == HOST_SHA, "fresh control profile/command/runtime role differs")
    for path, expected in profile["input_sha256"].items():
        bind(inputs, path, expected)
    require(inputs[str(OLD)] == OLD_SHA and inputs[str(HOST)] == HOST_SHA and inputs[str(BINARY)] == BINARY_SHA and
            inputs[str(ARCHIVE)] == ARCHIVE_SHA and inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and
            inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
            inputs[profile["original_plan_path"]] == profile["original_plan_sha256"] and
            read(profile["original_plan_path"])["steps"] == profile["local_plan_steps"], "frozen helper/source/host/original plan differs")
    clean_source()
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected,
                "loaded project module path/bytes differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs,
              "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env),
                "actual loaded runtime differs outside the declared compiler/PATH substitution")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"],
                env={**invocation.env, **profile["diagnostic_environment"]}, stdout=output, stderr=subprocess.STDOUT,
                check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify()
        require(actual.returncode == 0, "fresh multicopy control did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis...", "LUT driver copy")) and
                not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual control is not predicted-only without a driver stage")
        record["actual_selected_local_qualification"] = local_qualification(log)
        record["retained_selected_model_fields_exact"] = [{key: row[key] for key in MODEL_KEYS} for row in record["actual_selected_local_qualification"]] == \
            [{key: row[key] for key in MODEL_KEYS} for row in profile["retained_local_models"]]
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()),
                "fresh predicted report cap/count/Fmax is invalid")
        record["actual_predicted_fmax"], record["output_sha256"] = report["fmax"], {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual predicted output missing")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source()
        record["completed"] = True
        print(json.dumps({"completed": True, "retained_selected_model_fields_exact": record["retained_selected_model_fields_exact"],
                          "actual_local_qualification": record["actual_selected_local_qualification"], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in
                        ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(args.self_sha256 and args.scope_sha256, "preparation pins missing")
        prepare(args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256, "profile activation pin missing")
        execute(args.profile_sha256)


if __name__ == "__main__":
    main()
