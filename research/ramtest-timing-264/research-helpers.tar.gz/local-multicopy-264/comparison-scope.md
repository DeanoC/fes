# Multicopy original-plan control comparison

Root alone executes this new comparator after the fresh baseline has closed,
supplying its actual run SHA through --run-sha256. Profile 75bdbee6,
runner 10bd3b05, runner scope 57a5ea9f and current host manifest 98c1f40a
are fixed. The comparator/scope, original D2 run d2afc1e3 and complete flat
original/current input, output, host source/artifact and runtime ledgers are
bound and rehashed. No earlier generator, authenticator, compiler, test,
build, route or helper main is executed. The new runner is loaded only for
its pure command, expected_execution and local_qualification definitions;
prepare, execute and clean_source are never called.

The closed current run must exactly copy its profile except for the explicit
input union adding the profile's own path/hash, and must record actual zero
exit, completed audited execution and precisely three nonempty predicted
outputs. Compiler 81243a13/binary91a/archivec947/current host46 cases are
bound. The original plan path and all 8/1/1 descriptors, all other command
arguments and diagnostic environment remain exact. The current actual
runtime must equal D2 after only replacing the compiler pathname/hash and
its controlled PATH directory. Historical closure entries are kept separate
from the explicit current_actual_execution record; their presence does not
claim that historical build tools/headers were loaded by this invocation.

The structural branch requires all three freshly guarded selected model
fields and all 71 original placement metrics to match. It then compares the
entire original and current native modules: 14,900 cells, 16,638 net records,
settings, attributes, public ports, every owner/type/parameter/mask/BEL,
raw numeric connection and alias record remain exact. Module, cell/net owner,
public-port and each cell's connection/direction export order remain exact.
The lossless paired PLL occurrence entries and rebuilt complete raw native
driver/user slot tables must match. No module field is omitted, rewritten,
aligned or waived. Top-level creator strings are recorded separately as a
compiler provenance diagnostic; they do not substitute for module equality.
Any structural mismatch is recorded explicitly with graph evidence absent.

Even on structural rejection, the complete current lossless document and
actual report go through the pinned pure 72131 native-path validator, using
the pinned local 8601 require API and the pure 32fd parser/auditor. It validates
all 15,290 paths and seven domain-pair endpoint/window sets against the
original, finite native clock/data-edge attribution and exact emitted cap
16384. Existing path delays are not inherited. Complete actual report
equality is recorded separately from graph equality. The additive-stage
control prerequisite requires both the strict structural branch and exact
complete report equality. Complete rejected-trial log equality remains a
separate diagnostic beyond the strict selected model fields.

All original paths are rehashed before returning either branch. Publication
uses only exclusive baseline/comparison-control.json creation. This is
serialized native control reproduction and emitted-path coverage evidence;
unexported pins, LAB state, caches, physical legality and independently
reconstructed numerical STA remain unproved. It provides no routed gain,
hold/signoff, RBF, loaded historical test-library or hardware acceptance.
