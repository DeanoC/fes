# New multicopy compiler control

Only the root operator activates this runner. `prepare` creates a new,
exclusive source-identity.json; `execute` requires its exact SHA and creates
exclusive baseline outputs. The script has no import-time activation. It
never invokes older helpers, generators, authenticators, tests or builds.
Its Git subprocesses only read the new compiler's HEAD, cleanliness,
ancestry and complete two-file delta.

The control selects clean compiler 81243a13, binary 91a51253 and archive
c9476dec. The closed current host manifest 98c1f40a binds its current
four repeated-outer, 19 remaining backend and 11+12 CLI cases. Its complete
flat artifact/source ledger is rehashed without assigning historical
loaded build/test-library evidence to the present invocation. The closed
original D2 baseline d2afc1e3 contributes its complete original input,
output and execution ledgers, including its source identity, helpers,
RTL, generated headers, fixed BUILD_ID, all reports and exact plan.
Historical files remain immutable.

The compiler pathname/hash, selected source/archive/host provenance and
fresh write/report outputs are the only invocation changes. The original
local-plan pathname and all three 8/1/1 descriptors remain exact, including
candidate0, pin optimization disabled and fixed FF placement. No fourth
stage, recentered guide, driver-copy stage, RBF or route is selected. Device,
seed, timing options, all earlier/later transforms and both diagnostic
environment values remain those in the original D2 command.

FunctionalInvocation authenticates the actual current runtime. Its full
captured record must equal D2 after exactly two declared substitutions:
the old compiler file pathname/hash becomes the new selected compiler,
and its controlled PATH directory changes correspondingly. Every other
environment, machine, kernel, GPU device and captured library/tracer/KFD
file pathname/hash stays exact. The private HOME value remains the
mechanism's normalized private-build-home token; no ambient diagnostic or
library variables enter execution. The compiler runs through the current
pinned compiler-read-audit API against the same source module, and the
five loaded project Python module paths and bytes are checked explicitly.

All three stages must freshly qualify/apply candidate0 with their actual
final preceding trials, groups within 8/1/1, fixed FFs, existing clock,
hold and boundary guards and at least 250 ps predicted gain. Earlier
rejected trials remain recorded. The fresh selected model fields are
compared to the original only as a diagnostic boolean; the runner does
not declare native identity from those logs. The actual complete predicted
report must retain cap 16384, 15,290 paths and finite positive reported
Fmax fields. No independently reconstructed path topology, pin/LAB/cache
state, numerical STA, Boolean or physical equivalence is claimed here.

Inputs, historical outputs, source and actual runtime are checked before
activation and after completion. Runtime verification repeats the native
capture; all bound byte paths are rehashed and the current clean compiler
HEAD/delta rechecked. A failure preserves an explicit incomplete record
with actual exit status when available, adapter status labeled otherwise,
and hashes of any partial output files. Successful compiler completion is
not routed signoff, timing gain, hardware acceptance or proof that the
new control graph equals the original. A later independent native control
comparison is required before adding a repeated-outer fourth stage.
