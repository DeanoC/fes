"""Record completed multicopy host checks without rerunning a build or test."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TOOL = ROOT / "sources/misteross/build/toolchain-ramtest-timing"
SOURCE, BUILD = TOOL / "src/nextpnr-local-multicopy-264", TOOL / "build/nextpnr-local-multicopy-264"
OLD_SOURCE = TOOL / "src/nextpnr-driver-domains-264"
PREVIOUS = HERE.parent / "driver-domains-264/validation/host-validation.json"
PREVIOUS_SHA = "b20ad824130de975372f7dabc4a1335f630caa6f6df7687beb2b93fb17a245e0"
BASE, COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52", "81243a1300304d7e598156c692be2fcbf2c16268"
CHANGED = {"mistral/local_remap.cc": "9cab6b21a1b1f80b6ccc20237c136bdf150586fab82121ee33c8648c507ced62",
    "mistral/tests/remap_plan.cc": "12d4d89179aca920b977021443baaaa1cbe77d93ff323186b1b0a6fdbea91dab"}
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args])


def clean():
    require(git("rev-parse", "HEAD").decode().strip() == COMMIT and not git("status", "--porcelain").strip(), "source is not the clean committed result")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    parser.add_argument("--scope-sha256", required=True)
    args = parser.parse_args()
    validation, output, bound = HERE / "validation", HERE / "validation/host-validation.json", {}
    require(not output.exists(), "exclusive host record already exists")
    def bind(path, expected=None):
        path = Path(path).absolute()
        actual = sha(path)
        require(expected is None or actual == expected, "original bytes differ: " + str(path))
        require(str(path) not in bound or bound[str(path)] == actual, "conflicting input identity")
        bound[str(path)] = actual
        return actual
    bind(Path(__file__).resolve(), args.self_sha256); bind(HERE / "host-scope.md", args.scope_sha256); bind(PREVIOUS, PREVIOUS_SHA)
    clean()
    require(git("merge-base", BASE, COMMIT).decode().strip() == BASE and set(git("diff", "--name-only", BASE, COMMIT).decode().splitlines()) == set(CHANGED), "source delta is not exactly the reviewed two files")
    previous = json.loads(PREVIOUS.read_text())
    require(previous["result_commit"] == BASE and previous["clean_committed_checkout"] is True and previous["build_passed"] is True, "prior host record is not closed")
    sources, inherited = {}, {}
    for old_path, expected in previous["source_sha256"].items():
        relative = str(Path(old_path).relative_to(OLD_SOURCE))
        require(relative not in CHANGED and hashlib.sha256(git("show", BASE + ":" + relative)).hexdigest() == expected, "inherited base source differs")
        bind(old_path, expected); inherited[relative] = expected; sources[str(SOURCE / relative)] = bind(SOURCE / relative, expected)
    for relative, expected in CHANGED.items():
        sources[str(SOURCE / relative)] = bind(SOURCE / relative, expected)
    extra = ("mistral/remap_plan.cc", "mistral/remap_report.h", "mistral/local_remap_policy.h", "mistral/local_remap_pin_policy.h", "mistral/tests/local_remap.cc", "mistral/tests/remap_plan_cli.py", "mistral/tests/local_remap_cli.py")
    for relative in extra:
        expected = hashlib.sha256(git("show", BASE + ":" + relative)).hexdigest()
        sources[str(SOURCE / relative)] = bind(SOURCE / relative, expected); inherited[relative] = expected
    require(len(previous["source_sha256"]) == 16 and all(hashlib.sha256(git("show", COMMIT + ":" + str(Path(path).relative_to(SOURCE)))).hexdigest() == digest for path, digest in sources.items()), "live selected source differs from committed bytes")
    bind(HERE / "nextpnr-mistral", BINARY_SHA); bind(BUILD / "nextpnr-mistral", BINARY_SHA); bind(HERE / "source.tar.gz", ARCHIVE_SHA)
    bind(BUILD / "nextpnr-mistral-test", "ea2b55d6dbce12d04d9a6a3000e8a5f2bd8bb4a26326f1e624688b34afa36a6f")
    with tarfile.open(HERE / "source.tar.gz", "r:gz") as archive:
        for path, expected in sources.items():
            member = archive.getmember(str(Path(path).relative_to(SOURCE)))
            require(member.isfile() and hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected, "archive selected source differs")
    bind(BUILD / "CMakeCache.txt")
    cache = (BUILD / "CMakeCache.txt").read_text()
    require("CMAKE_HOME_DIRECTORY:INTERNAL=" + str(SOURCE) + "\n" in cache and all(value in cache for value in ("ARCH:STRING=mistral\n", "BUILD_TESTS:BOOL=ON\n", "GPU_ROUTER:STRING=HIP\n")), "actual build source/architecture differs")
    old_cache = TOOL / "build/nextpnr-driver-domains-264/CMakeCache.txt"
    bind(old_cache, previous["artifact_sha256"][str(old_cache)])
    model_root = re.search(r"(?m)^MISTRAL_ROOT:STRING=(.+)$", cache)
    require(model_root is not None and "MISTRAL_ROOT:STRING=" + model_root[1] + "\n" in old_cache.read_text(), "external model source pathname changed")
    logs = {}
    for name in ("dependency-setup.log", "configure.log", "configure-v2.log", "build.log", "build-v2.log", "repeated-backend.log", "regression-backend.log", "cli.log", "repeated-backend.xml", "regression-backend.xml"):
        bind(validation / name); logs[name] = (validation / name).read_text()
    require("Configuring incomplete, errors occurred!" in logs["configure.log"] and "3rdparty/googletest" in logs["configure.log"] and "tests/gui" in logs["configure.log"], "initial missing-gitlink configure failure is absent")
    require("indexed_store" in logs["build.log"] and "entry.second.users.enumerate()" in logs["build.log"] and "error:" in logs["build.log"] and "Error 2" in logs["build.log"], "initial const-iterator build failure is absent")
    require("Configuring done" in logs["configure-v2.log"] and "Generating done" in logs["configure-v2.log"] and "CMake Error" not in logs["configure-v2.log"], "corrected configuration failed")
    require(all("Built target " + name in logs["build-v2.log"] for name in ("nextpnr-mistral", "nextpnr-mistral-test")) and not re.search(r"(?:fatal )?error:|\] Error \d", logs["build-v2.log"]), "corrected production/test build failed")
    declarations = set()
    for relative in ("mistral/tests/remap_plan.cc", "mistral/tests/local_remap.cc"):
        declarations.update(fixture + "." + name for fixture, name in re.findall(r"\bTEST(?:_F)?\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)", (SOURCE / relative).read_text()) if fixture in {"LocalRemapPlanTest", "LocalRemapComposition", "LocalRemapPins"})
    repeated = {name for name in declarations if name.startswith("LocalRemapPlanTest.RepeatedOuter")}
    require(len(repeated) == 4 and len(declarations - repeated) == 19, "committed native coverage differs")
    checks = {}
    for key, expected in (("repeated-backend", repeated), ("regression-backend", declarations - repeated)):
        xml, log = ET.fromstring(logs[key + ".xml"]), logs[key + ".log"]
        cases = xml.findall("./testsuite/testcase")
        actual = [case.attrib["classname"] + "." + case.attrib["name"] for case in cases]
        require(len(actual) == len(expected) and set(actual) == expected and xml.attrib["tests"] == str(len(expected)) and all(xml.attrib[field] == "0" for field in ("failures", "disabled", "errors")), "actual native XML coverage/failures differ")
        require(all(case.attrib["status"] == "run" and case.attrib["result"] == "completed" and not list(case) and case.attrib["file"] == str(SOURCE / ("mistral/tests/remap_plan.cc" if case.attrib["classname"] == "LocalRemapPlanTest" else "mistral/tests/local_remap.cc")) for case in cases), "native XML contains skipped/failed/noncurrent cases")
        ran = re.findall(r"\[\s*RUN\s*\]\s+(\S+)", log)
        require(len(ran) == len(expected) and set(ran) == expected and "[  PASSED  ] %d tests." % len(expected) in log and not re.search(r"\[\s*(?:FAILED|SKIPPED)\s*\]", log), "actual backend log did not complete all current cases")
        checks[key] = {"passed": True, "cases": len(expected), "reported_elapsed_seconds": float(xml.attrib["time"]), "case_names": sorted(expected)}
    for number, script, count in ((6, "remap_plan_cli.py", 11), (7, "local_remap_cli.py", 12)):
        block = "\n".join(line[len(str(number)) + 2:] for line in logs["cli.log"].splitlines() if line.startswith(str(number) + ": "))
        expected = set(re.findall(r"(?m)^\s+def (test_\w+)\(", (SOURCE / "mistral/tests" / script).read_text()))
        ran = re.findall(r"(?m)^(test_\w+) .* \.\.\. ok$", block)
        match = re.search(r"Ran %d tests in ([\d.]+)s\s+OK\s*$" % count, block)
        require(str(SOURCE / "mistral/tests" / script) in block and str(BUILD / "nextpnr-mistral") in block and len(expected) == len(ran) == count and set(ran) == expected and match is not None, "actual CLI case/invocation summary differs")
        checks[script] = {"passed": True, "cases": count, "reported_elapsed_seconds": float(match[1]), "case_names": sorted(expected)}
    require("100% tests passed, 0 tests failed out of 2" in logs["cli.log"], "CTest completion differs")
    record = {"schema": 1, "result_commit": COMMIT, "compiler_commit": COMMIT, "delta_base_commit": BASE, "clean_committed_checkout": True,
        "build_passed": True, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "source_sha256": sources, "unchanged_inherited_source_sha256": inherited,
        "artifact_sha256": dict(sorted(bound.items())), "checks": checks, "predecessor_host_sha256": PREVIOUS_SHA,
        "preserved_failed_attempts": {"configure.log": {"passed": False, "classification": "missing googletest/tests gitlinks"}, "build.log": {"passed": False, "classification": "test-only const indexed_store enumeration"}},
        "generic_arch_compile_rerun": False, "common_source_changed": False, "generic_compile_acceptance_inherited": False,
        "other_predecessor_checks_rerun": False, "loaded_build_or_test_runtime_authenticated": False, "new_sta_or_routing_gain_claimed": False,
        "native_routed_or_physical_equivalence_proved": False, "hardware_tested": False, "recorder_reran_builds_tests_or_old_entrypoints": False}
    clean()
    for path, expected in bound.items():
        require(sha(path) == expected, "original host input changed: " + path)
    with output.open("x") as stream:
        stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(json.loads(output.read_text()) == record, "new host record differs")
    clean()
    require(all(sha(path) == expected for path, expected in bound.items()), "original input changed after publication")
    print(json.dumps({"host_validation_sha256": sha(output), "compiler_commit": COMMIT, "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
