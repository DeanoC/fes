# Multicopy compiler host record

Root alone runs this recorder. It reads the completed current configure,
build, backend XML/logs and CLI log; it never repeats a compiler, test,
benchmark, older helper or authenticator. Its only subprocesses are read-only
Git queries against the isolated committed compiler checkout.

The clean result 81243a1300304d7e598156c692be2fcbf2c16268 must descend from 5dd
with exactly two changed files: mistral/local_remap.cc and
mistral/tests/remap_plan.cc. Their reviewed hashes, the copied and built
production binary 91a51253, test binary ea2b55d6, source archive c9476dec,
actual CMake cache, this helper/scope and every validation artifact are bound.
The prior closed b20ad824 host record is read without executing it. Its 16
source files plus the unchanged local-remap plan/policy/report/test support
must match both the actual 5dd Git bytes and the current clean result. Selected
source archive members must match those current bytes. The complete tracked
Git delta contains no other changes; the external Mistral model pathname in
the current and retained CMake caches must match. This does not authenticate
the libraries loaded during historical build/test executions.

The initial configure log 94051 is preserved and classified as failed because
the googletest/tests gitlinks were absent. Dependency setup and successful
configure-v2 remain separate artifacts. The initial build 62549 is preserved
as failed: production completed, but the new test instantiated the broken
const indexed_store enumeration overload. The corrected build-v2 must finish
both current targets. Neither initial attempt is relabeled as successful.

The current native XML/logs must contain exactly four repeated-outer cases
and all 19 remaining local plan/composition/pin cases declared in current
source, with no disabled, skipped or failed cases. They cover retained 2+1
copy users, actual native endpoint timing guards, exhaustive fixture truth,
qualified list/failed-selection exact rollback and both-name collisions.
The CLI log must complete all 11 remap-plan and 12 local-remap methods from
current source under the current built compiler, with both CTest suites
passing. Durations are reported by the retained XML/logs, not measured anew.

The generic architecture is not rebuilt: this is a Mistral-only two-file
delta with no common kernel change. Earlier driver/timing/focused tests are
not rerun and their compile or runtime acceptance is not assigned to this
binary. This record claims host build/test evidence only, no new STA/Fmax,
routing gain, full native or physical equivalence, RBF or hardware result.
Inputs are rehashed before and after exclusive host-validation.json
publication; source HEAD and cleanliness are rechecked around publication.
