"""Compare a closed new-compiler predicted control with the original D2 graph."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE = HERE / "source-identity.json"
PROFILE_SHA = "75bdbee671bf186440705bfc4c9f33f2d58318e88569516582060cab50cde59e"
RUN = HERE / "baseline/run.json"
RUNNER = HERE / "run_baseline.py"
RUNNER_SHA = "10bd3b05d1fc15d999c1b4768f383d2020378658adc39b2fc3a88162fe0e6459"
RUNNER_SCOPE_SHA = "57a5ea9f173ce45fe08e9c3d45c85e75a45902ee837b4a7a4475e266810513c9"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE = SELECTED.parent / "freeze.py"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def prove_module(native, selected, before, after):
    require(set(before) == set(after) == {"creator", "modules"} and
            set(before["modules"]) == set(after["modules"]) == {"top"}, "complete native document shape differs")
    a, b = before["modules"]["top"], after["modules"]["top"]
    require(len(a["cells"]) == len(b["cells"]) == 14900 and len(a["netnames"]) == len(b["netnames"]) == 16638 and
            native.canonical(a) == native.canonical(b), "complete native module metadata/cells/nets/raw bits differ")
    require(list(a) == list(b) and list(a["cells"]) == list(b["cells"]) and
            list(a["netnames"]) == list(b["netnames"]) and list(a["ports"]) == list(b["ports"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "native module/owner/public-port order or lossless paired PLL entries differ")
    for name, cell in a["cells"].items():
        require(list(cell["connections"]) == list(b["cells"][name]["connections"]) and
                list(cell["port_directions"]) == list(b["cells"][name]["port_directions"]),
                "original cell port/direction order differs: " + name)
    require(selected.native_tables(a) == selected.native_tables(b), "complete raw driver/user slot tables differ")
    return {"complete_native_module_exact": True, "original_owner_and_port_order_exact": True,
            "lossless_paired_pll_entries_exact": True, "native_driver_and_user_slot_tables_exact": True,
            "cells": 14900, "netnames": 16638, "raw_id_translation_or_metadata_waiver_used": False,
            "unexported_pins_lab_caches_or_physical_state_proved": False}


def compare(self_sha, scope_sha, run_sha):
    native = load(NATIVE, NATIVE_SHA, "multicopy_control_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha),
            (PROFILE, PROFILE_SHA), (RUN, run_sha), (RUNNER, RUNNER_SHA), (HERE / "scope.md", RUNNER_SCOPE_SHA),
            (HERE / "validation/host-validation.json", HOST_SHA), (NATIVE, NATIVE_SHA),
            (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    runner = load(RUNNER, RUNNER_SHA, "multicopy_control_runner_pure")
    audit.bind(runner.OLD, runner.OLD_SHA)
    profile, record, old, host = (native.read(path) for path in (PROFILE, RUN, runner.OLD, runner.HOST))
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["source_identity_sha256"] == PROFILE_SHA and
            all(record[key] == value for key, value in profile.items() if key != "input_sha256") and
            record["input_sha256"] == {**profile["input_sha256"], str(PROFILE): PROFILE_SHA} and
            not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel", "partial_outputs_only")),
            "current baseline is not its closed exact profile/input-union record")
    require(profile["command"] == runner.command(old) and record["execution"] == profile["baseline_execution"] == runner.expected_execution(old) and
            profile["diagnostic_environment"] == old["diagnostic_environment"] and profile["cwd"] == old["cwd"] == str(runner.MODULE) and
            profile["compiler_commit"] == host["compiler_commit"] == host["result_commit"] == runner.COMMIT and
            profile["delta_base_commit"] == host["delta_base_commit"] == old["compiler_commit"] == runner.BASE and
            profile["binary_sha256"] == host["binary_sha256"] == runner.BINARY_SHA and
            profile["source_archive_sha256"] == host["source_archive_sha256"] == runner.ARCHIVE_SHA and
            profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            profile["host_validation_sha256"] == HOST_SHA and host["build_passed"] is host["clean_committed_checkout"] is True,
            "exact compiler substitution/current host/runtime/invocation differs")
    for ledger in (profile["input_sha256"], old["input_sha256"], old["output_sha256"], host["artifact_sha256"], host["source_sha256"]):
        for path, expected in ledger.items():
            audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    for runtime in (old["execution"], record["execution"]):
        for path, expected in runtime["files"].items():
            audit.bind(Path(path), expected, execution=True)
    require(old["completed"] is True and old["exit_code"] == 0 and old["compiler_read_audit_passed"] is True and
            profile["retained_baseline_run_sha256"] == runner.OLD_SHA and old["phase"] == "baseline" and
            old["binary_sha256"] == runner.OLD_BINARY_SHA and old["source_archive_sha256"] == runner.OLD_ARCHIVE_SHA and
            profile["current_host_case_counts"] == {name: row["cases"] for name, row in host["checks"].items()} and
            all(row["passed"] is True for row in host["checks"].values()), "closed original baseline/current host checks differ")
    require(audit.paths.get(Path(profile["original_plan_path"])) == profile["original_plan_sha256"] and
            native.read(profile["original_plan_path"])["steps"] == profile["local_plan_steps"] and
            len(profile["local_plan_steps"]) == 3 and [step["groups"] for step in profile["local_plan_steps"]] == [8, 1, 1] and
            all(step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True
                for step in profile["local_plan_steps"]), "original three-stage plan identity/role differs")
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")},
            "current predicted output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "empty current predicted output")
        audit.bind(Path(path), expected)
    old_log, log = (runner.OLD.parent / "phase.log").read_text(), (HERE / "baseline/phase.log").read_text()
    old_models, models = runner.local_qualification(old_log), runner.local_qualification(log)
    require(native.canonical(old_models) == native.canonical(profile["retained_local_models"]) and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]), "current/retained actual trial bindings differ")
    selected_models_exact = [{key: row[key] for key in runner.MODEL_KEYS} for row in models] == \
                            [{key: row[key] for key in runner.MODEL_KEYS} for row in old_models]
    require(record["retained_selected_model_fields_exact"] is selected_models_exact, "recorded model equality diagnostic differs")
    metrics = native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(old_log) and len(native.PLACEMENT_METRICS.findall(log)) == 71
    frozen = load(FREEZE, FREEZE_SHA, "multicopy_control_frozen_pure")
    selected = load(SELECTED, SELECTED_SHA, "multicopy_control_selected_pure", frozen)
    before, after = native.read_netlist(runner.OLD.parent / "placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    evidence, rejection = None, None
    try:
        require(selected_models_exact, "original three selected local model fields differ")
        require(metrics, "original 71 placement metrics differ")
        evidence = prove_module(native, selected, before, after)
    except (ValueError, TypeError, KeyError, IndexError) as error:
        rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(runner.OLD.parent / "timing.json")
    topology = selected.report_topology(after, report, old_report)
    report_exact = native.canonical(report) == native.canonical(old_report)
    require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and
            report["timing_report_paths"] == 16384 and record["actual_predicted_fmax"] == report["fmax"] and
            "Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...", "LUT driver copy")),
            "current predicted report/phase role differs")
    audit.finish()
    return {"schema": 1, "phase": "local-multicopy-exact-three-stage-native-control", "source_identity_sha256": PROFILE_SHA,
        "current_baseline_run_sha256": run_sha, "retained_baseline_run_sha256": runner.OLD_SHA,
        "compiler_commit": runner.COMMIT, "delta_base_commit": runner.BASE, "generator_sha256": self_sha, "scope_sha256": scope_sha,
        "host_validation_sha256": HOST_SHA, "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "current_actual_execution": record["execution"], "authorized_runtime_delta": profile["authorized_runtime_delta"],
        "pure_function_helper_sha256": {str(NATIVE): NATIVE_SHA, str(SELECTED): SELECTED_SHA, str(FREEZE): FREEZE_SHA, str(RUNNER): RUNNER_SHA},
        "creator_strings": {"before": before["creator"], "after": after["creator"]}, "creator_strings_equal": before["creator"] == after["creator"],
        "old_local_models": old_models, "fresh_local_models": models, "selected_local_model_fields_exact": selected_models_exact,
        "complete_local_trial_diagnostics_exact": native.canonical(models) == native.canonical(old_models), "all_71_placement_metrics_exact": metrics,
        "structural_rejection": rejection, "native_graph_proof_available": rejection is None, "native_graph_evidence": evidence,
        "current_predicted_native_paths": topology, "complete_predicted_report_exact": report_exact,
        "fresh_additive_stage_control_prerequisite_proved": rejection is None and report_exact,
        "raw_id_alignment_or_native_module_field_waiver_used": False, "independent_physical_equivalence_proved": False,
        "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "run-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    output = HERE / "baseline/comparison-control.json"
    require(not output.exists(), "immutable control comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.run_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "complete_predicted_report_exact": result["complete_predicted_report_exact"],
        "fresh_additive_stage_control_prerequisite_proved": result["fresh_additive_stage_control_prerequisite_proved"]}, indent=2))


if __name__ == "__main__":
    main()
