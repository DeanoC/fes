"""Root-only selected fresh eleven followed by fresh minimum200 twelve listing."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
import seal_profile as seal


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=seal.PHASES, required=True)
    args = parser.parse_args()
    context = seal.load_profile()
    profile, g8, base, source, _, _ = context
    folder, inputs = seal.phase_folder(args.phase), seal.sealed_input_map(profile, args.phase)
    seal.require(not folder.exists(), "selected phase output already exists")
    module = Path(base["cwd"])
    sys.path.insert(0, str(module))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    from scripts.search_placer_qor import has_failed_route_arc
    old = seal.initial()
    identity = f"base_commit={old.BASE}; experimental_source_sha256={seal.sha(seal.INITIAL / 'source.tar.gz')}; sha256={source['binary_sha256']}"
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(seal.INITIAL / "nextpnr-mistral", identity)}, 1)
    try:
        seal.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                     "ambient compiler diagnostic environment")
        diagnostics = seal.expected_diagnostic_environment(base, args.phase)
        record = {**base, "kind": "generic narrow-search fresh selected11 and unselected minimum200 twelve",
                  "phase": args.phase, "command": seal.expected_command(base, args.phase),
                  "diagnostic_environment": diagnostics, "placed_reduction_plan": seal.specifications(base, args.phase),
                  "experimental_placed_reduction": diagnostics["NEXTPNR_MISTRAL_PLACED_REDUCTION"],
                  "eleven_selection": seal.SELECTED_ELEVEN, "twelve_selection": -1, "reduction_selection": -1,
                  "decomposition_selection": None, "decomposition_report_sha256": None,
                  "parent_qualification_inherited": False, "compiler_bytes_unchanged": False,
                  "compiler_bytes_unchanged_from_fresh_eleven_listing": True,
                  "base_compiler_commit": old.BASE, "compiler_commit": source["result_commit"],
                  "measured_compiler_commit": base["compiler_commit"],
                  "source_identity_sha256": profile["source_identity_sha256"],
                  "source_archive_sha256": profile["source_archive_sha256"],
                  "disabled_control_sha256": profile["disabled_control_sha256"],
                  "runner_sha256": seal.sha(Path(__file__)), "profile_sha256": seal.sha(seal.PROFILE),
                  "reference_run_sha256": seal.sha(old.FULL / "run.json"), "remap_plan_sha256": seal.sha(old.LOCAL_PLAN),
                  "initial_eleven_proof_sha256": seal.INITIAL_PROOF_SHA,
                  "initial_comparator_sha256": seal.INITIAL_COMPARATOR_SHA,
                  "initial_generator_sha256": seal.INITIAL_GENERATOR_SHA,
                  "initial_pure_helper_sha256": seal.INITIAL_PURE_HELPER_SHA,
                  "initial_eleven_proof_path": str(seal.INITIAL_PROOF_PATH),
                  "initial_current_proof_qualification_used": True,
                  "retained_stage_minimum_branch_gain_ps": seal.DEFAULT_MINIMUM_PS,
                  "new_stage_minimum_branch_gain_ps": seal.MINIMUM_PS, "diagnostic_token_counts": [3, 4],
                  "expected_nondefault_minimum_log": seal.MINIMUM_LOG,
                  "minimum_log_verified": False,
                  "listing_lineage": {"eleven_listing": str(seal.INITIAL / "list-eleven"),
                                      "own_unbalanced_baseline": str(seal.INITIAL / "baseline-placement")},
                  "tool_identity": identity, "list_only": True, "fresh_listing": True,
                  "execution": invocation.inputs, "input_sha256": inputs,
                  "completed": False, "hardware_acceptance": False}
        for key in ("elapsed_seconds", "exit_code", "failure", "fmax", "final_reported_hold_violations",
                    "exit_code_is_adapter_sentinel"):
            record.pop(key, None)
        seal.authenticate_phase(record, context=context)
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
        try:
            with (folder / "route.log").open("x") as log:
                result = audited_run(record["command"], source_root=module, cwd=module,
                                     env={**invocation.env, **diagnostics}, stdout=log, stderr=subprocess.STDOUT,
                                     check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            invocation.verify()
            seal.require(all(seal.sha(Path(path)) == digest for path, digest in inputs.items()), "selected phase input changed")
            log = (folder / "route.log").read_text()
            seal.require(result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log),
                         "selected phase did not finish normally")
            seal.require((folder / "placed.json").exists() and not any(marker in log for marker in
                         ("Decomposition", "Running the GPU router", "Running signoff timing analysis...")) and
                         not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
                         "selected listing produced AC/router/final outputs")
            minimum = [line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line]
            seal.require(minimum == [seal.MINIMUM_LOG], "selected listing lacks exactly one minimum200 log")
            record["minimum_log_verified"], record["completed"] = True, True
            seal.authenticate_phase(record, context=context)
            print(json.dumps({key: record[key] for key in
                              ("phase", "eleven_selection", "elapsed_seconds", "completed", "exit_code")}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
