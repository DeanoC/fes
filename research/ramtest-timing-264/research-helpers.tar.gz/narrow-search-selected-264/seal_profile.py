"""Root-only selected-eleven/fresh-twelve profile; no AC or route phase.

The initial profile and its completed proof remain immutable. Root must supply
the exact fresh proof digest and a qualified ordinal before sealing this file.
The first proof's flat cached authenticator runs once; old comparisons and
recursive profile authenticators are never replayed.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
INITIAL = RAW / "narrow-search-264"
INITIAL_SEAL_SHA = "6df06f16ec4b025cf2f991e2555b84e3ed30947d9002827d4598a4c899d711c9"
INITIAL_RUNNER_SHA = "c30d7e0c742aa524689636fb08f1f5b08889cf77e04e196849051ddb2e7866e7"
INITIAL_PURE_HELPER_SHA = "b9b7e62b4a7eaec22a2e064127da1b9332c66de7de1c1fe6509b37c1e6ed7027"
INITIAL_COMPARATOR_SHA = INITIAL_PURE_HELPER_SHA
INITIAL_GENERATOR_PATH = INITIAL / "compare_first11_fast_v2.py"
INITIAL_GENERATOR = INITIAL_GENERATOR_PATH
INITIAL_GENERATOR_SHA = "d23197ada23ff984f195eedce7a4516d818aeac58ea153bbddc521e112607d5d"
INITIAL_PROOF_PATH = INITIAL / "first-fast-proof-v2/comparison.json"
# Root-operated fresh proof: the historical fast-v1 proof is not used.
INITIAL_PROOF_SHA = "f53de620d1265f10be1e834f548c9b9531842e7505393fe88d34c6d912bc8b9a"
SELECTED_ELEVEN = 0
PROFILE = HERE / "profile.json"
PHASES = ("list-twelve",)
TWELVE_ROOT = "ddr0_test.group_valid_MISTRAL_ALUT6_E_F_MISTRAL_ALUT5_Q"
MINIMUM_PS, DEFAULT_MINIMUM_PS = 200, 250
MINIMUM_LOG = "Info: Placed reduction minimum branch gain: 200ps."
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def unique(items):
        value = {}
        for key, item in items:
            require(key not in value, "duplicate metadata key: " + key)
            value[key] = item
        return value
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite: " + value)))


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def initial():
    for name, digest in (("seal_profile.py", INITIAL_SEAL_SHA), ("route.py", INITIAL_RUNNER_SHA),
                         ("compare_first11.py", INITIAL_COMPARATOR_SHA)):
        require(sha(INITIAL / name) == digest, "frozen initial helper changed: " + name)
    return module_at(INITIAL / "seal_profile.py", "selected_narrow_frozen_initial_authenticator")


def authenticate_initial():
    require(type(INITIAL_PROOF_SHA) is str and re.fullmatch(r"[0-9a-f]{64}", INITIAL_PROOF_SHA) and
            type(SELECTED_ELEVEN) is int and 0 <= SELECTED_ELEVEN <= 2147483647,
            "root has not pinned a completed fresh eleven proof and selected ordinal")
    old = initial()
    require(sha(INITIAL_GENERATOR) == INITIAL_GENERATOR_SHA, "flat first-proof generator changed")
    fast = module_at(INITIAL_GENERATOR, "selected_narrow_frozen_flat_first_authenticator")
    require(fast.OUTPUT == INITIAL_PROOF_PATH and fast.PURE_HELPER_SHA == INITIAL_PURE_HELPER_SHA and
            fast.SEAL_SHA == INITIAL_SEAL_SHA and fast.RUNNER_SHA == INITIAL_RUNNER_SHA,
            "flat first-proof authenticator bound different frozen inputs")
    profile, g8, base, source, control, baseline_record, record, proof = \
        fast.authenticate_cached_first(INITIAL_PROOF_SHA)
    require(record["phase"] == "list-eleven" and record["reduction_selection"] == -1 and
            record["compiler_commit"] == source["result_commit"] and
            record["profile_sha256"] == sha(old.PROFILE) and
            proof["compiler_commit"] == source["result_commit"] and
            proof["profile_sha256"] == sha(old.PROFILE) and
            proof["parent_qualification_inherited"] is False and
            proof["graph_proof_available"] is False and proof["partial_graph_evidence_available"] is True and
            proof["route_started"] is False and proof["cached_old_comparisons_reexecuted"] is False,
            "initial proof is not this producer's fresh unselected qualification")
    require(proof["generator"] == {
                "path": str(INITIAL_GENERATOR.relative_to(ROOT)), "sha256": INITIAL_GENERATOR_SHA,
                "pure_helper_path": str((INITIAL / "compare_first11.py").relative_to(ROOT)),
                "pure_helper_sha256": INITIAL_PURE_HELPER_SHA} and
            SELECTED_ELEVEN in proof["qualified_eleven_ordinals"],
            "selected ordinal lacks the frozen fresh qualification proof")
    candidate = [row for row in proof["qualification"]["candidates"] if row["candidate"] == SELECTED_ELEVEN]
    require(len(candidate) == 1 and candidate[0]["guards"] == [1, 1, 1, 1] and
            candidate[0]["branch_gain_ps"] >= DEFAULT_MINIMUM_PS and
            candidate[0]["endpoints"] == proof["actual_endpoint_closure"]["endpoint_count"],
            "selected eleven candidate has incomplete current guards or endpoint attribution")
    baseline = INITIAL / "baseline-placement"
    require(baseline_record["phase"] == "baseline-placement" and baseline_record["completed"] is True and
            type(baseline_record["exit_code"]) is int and baseline_record["exit_code"] == 0 and
            baseline_record["compiler_commit"] == source["result_commit"], "fresh own baseline is incomplete")
    # The flat API independently authenticates both actual records, their
    # command/environment/source/dependency/runtime identities, and every
    # sealed input once, with a final rehash. These additional checks only
    # select a fresh qualified ordinal; no recursive old authenticator runs.
    for current, phase in ((record, "list-eleven"), (baseline_record, "baseline-placement")):
        require(current["command"] == old.expected_command(base, phase) and
                current["diagnostic_environment"] == old.expected_diagnostic_environment(base, phase) and
                current["placed_reduction_plan"] == old.specifications(base, phase) and
                current["profile_sha256"] == sha(old.PROFILE) and current["list_only"] is True and
                current["fresh_listing"] is True and current["decomposition_selection"] is None and
                "failure" not in current, "cached own baseline/list phase aliases changed")
    for path in (old.PROFILE, INITIAL / "seal_profile.py", INITIAL / "route.py", INITIAL / "compare_first11.py",
                 *(baseline / name for name in ("run.json", "route.log", "placed.json"))):
        require(proof["artifact_sha256"].get(str(path.relative_to(ROOT))) == sha(path),
                "fresh proof omits its own baseline/helper closure: " + str(path))
    for current in (record, baseline_record):
        for filename, digest in current["input_sha256"].items():
            require(proof["artifact_sha256"].get(str(Path(filename).relative_to(ROOT))) == digest,
                    "cached fresh proof omits an actual phase input")
    return old, profile, g8, base, source, control, record, proof


def specifications(base, phase="list-twelve"):
    require(phase in PHASES, "this profile permits only the fresh twelve listing")
    old = base["experimental_placed_reduction"].split()
    require(len(old) == 3 and old[1:] == ["6", "0"], "original eleven root/radius changed")
    return [{"root": old[0], "radius": 6, "candidate": SELECTED_ELEVEN,
             "minimum_branch_gain_ps": DEFAULT_MINIMUM_PS},
            {"root": TWELVE_ROOT, "radius": 6, "candidate": -1, "minimum_branch_gain_ps": MINIMUM_PS}]


def phase_folder(phase="list-twelve"):
    require(phase in PHASES and type(SELECTED_ELEVEN) is int and SELECTED_ELEVEN >= 0,
            "unknown phase or unpinned eleven ordinal")
    return HERE / f"list-twelve-e{SELECTED_ELEVEN}"


def expected_diagnostic_environment(base, phase="list-twelve"):
    first, second = specifications(base, phase)
    return {"NEXTPNR_MISTRAL_CAPTURE_LOCALITY": base["experimental_capture_locality"],
            "NEXTPNR_MISTRAL_PLACED_REDUCTION":
            f"{first['root']} 6 {first['candidate']}\n{second['root']} 6 -1 {MINIMUM_PS}"}


def expected_command(base, phase="list-twelve"):
    old = initial()
    command = old.expected_command(base, "list-eleven")
    old_output, new_output = str(INITIAL / "list-eleven/placed.json"), str(phase_folder(phase) / "placed.json")
    require(command.count(old_output) == 1 and "--no-route" in command and not any(
        token in command for token in ("--report", "--rbf", "--remap-decompose-critical", "--remap-decompose-candidate")),
        "initial no-route command contains a later phase")
    return [new_output if token == old_output else token for token in command]


def profile_aliases(base, source):
    old = initial()
    return {"schema": 1, "scope": "fresh selected eleven followed by unselected minimum200 twelve only",
            "initial_profile_sha256": sha(old.PROFILE), "initial_eleven_proof_sha256": INITIAL_PROOF_SHA,
            "initial_comparator_sha256": INITIAL_COMPARATOR_SHA,
            "initial_generator_sha256": INITIAL_GENERATOR_SHA,
            "initial_pure_helper_sha256": INITIAL_PURE_HELPER_SHA,
            "initial_eleven_proof_path": str(INITIAL_PROOF_PATH), "selected_eleven_ordinal": SELECTED_ELEVEN,
            "compiler_commit": source["result_commit"], "base_compiler_commit": old.BASE,
            "source_identity_sha256": sha(INITIAL / "source-identity.json"),
            "disabled_control_sha256": sha(INITIAL / "disabled-control/comparison.json"),
            "source_archive_sha256": sha(INITIAL / "source.tar.gz"),
            "binary_sha256": sha(INITIAL / "nextpnr-mistral"),
            "placed_reduction_plan": specifications(base), "local_plan_sha256": sha(old.LOCAL_PLAN),
            "diagnostic_token_counts": [3, 4], "expected_nondefault_minimum_log": MINIMUM_LOG,
            "parent_qualification_inherited": False, "initial_current_proof_qualification_used": True,
            "ac_phase_allowed": False, "route_phase_allowed": False,
            "default_recipe_selected": False, "hardware_tested": False}


def load_profile(initial_context=None):
    profile = read(PROFILE)
    old, initial_profile, g8, base, source, control, record, proof = \
        authenticate_initial() if initial_context is None else initial_context
    aliases = profile_aliases(base, source)
    require(set(profile) == set(aliases) | {"input_sha256"} and
            all(profile[key] == value for key, value in aliases.items()), "selected profile aliases changed")
    require(profile["input_sha256"] == selected_input_map(initial_profile, proof),
            "selected profile input closure changed")
    return profile, g8, base, source, control, {"record": record, "proof": proof}


def selected_input_map(initial_profile, proof):
    # The flat first-proof API has already hashed and closed these parent
    # artifacts and runtime inputs. Reuse their exact map rather than hashing
    # the transitive parent again; only this draft's new files need entry hashes.
    inputs = dict(initial_profile["input_sha256"])
    for filename, digest in proof["artifact_sha256"].items():
        path = (ROOT / filename).resolve()
        require(path.is_relative_to(ROOT), "cached artifact escaped the checkout")
        key = str(path)
        require(key not in inputs or inputs[key] == digest, "conflicting cached input identity")
        inputs[key] = digest
    require(proof["artifact_sha256"].get(str(INITIAL_GENERATOR.relative_to(ROOT))) == INITIAL_GENERATOR_SHA,
            "cached proof omits its actual generator")
    inputs[str(INITIAL_PROOF_PATH)] = INITIAL_PROOF_SHA
    for path in (Path(__file__), HERE / "route.py", HERE / "compare_selected11.py"):
        require(path.exists(), "selected profile input is absent: " + str(path))
        inputs[str(path.resolve())] = sha(path)
    return inputs


def sealed_input_map(profile, phase="list-twelve"):
    require(phase in PHASES, "unknown selected phase")
    return {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}


def authenticate_phase(record, context=None):
    # Reuse one already authenticated closure within a caller, then rehash all
    # bound artifacts at completion; do not replay the transitive old proofs.
    profile, g8, base, source, _, _ = load_profile() if context is None else context
    phase, folder = record["phase"], phase_folder(record["phase"])
    environment = expected_diagnostic_environment(base, phase)
    old = initial()
    identity = f"base_commit={old.BASE}; experimental_source_sha256={sha(INITIAL / 'source.tar.gz')}; sha256={source['binary_sha256']}"
    require(record["command"] == expected_command(base, phase) and record["diagnostic_environment"] == environment and
            record["experimental_placed_reduction"] == environment["NEXTPNR_MISTRAL_PLACED_REDUCTION"] and
            record["experimental_capture_locality"] == base["experimental_capture_locality"] and
            record["placed_reduction_plan"] == specifications(base, phase) and
            record["input_sha256"] == sealed_input_map(profile, phase), "selected phase command/env/input closure changed")
    require(record["compiler_commit"] == source["result_commit"] and record["base_compiler_commit"] == old.BASE and
            record["source_identity_sha256"] == profile["source_identity_sha256"] and
            record["source_archive_sha256"] == profile["source_archive_sha256"] and
            record["disabled_control_sha256"] == profile["disabled_control_sha256"] and record["tool_identity"] == identity and
            record["profile_sha256"] == sha(PROFILE) and record["runner_sha256"] == sha(HERE / "route.py") and
            record["remap_plan"] == base["remap_plan"] and record["remap_plan_sha256"] == sha(old.LOCAL_PLAN) and
            record["cwd"] == base["cwd"] and record["reference_run_sha256"] == sha(old.FULL / "run.json") and
            record["measured_compiler_commit"] == base["compiler_commit"] and
            record["compiler_bytes_unchanged"] is False,
            "selected phase producer/profile aliases changed")
    require(record["eleven_selection"] == SELECTED_ELEVEN and record["twelve_selection"] == -1 and
            record["reduction_selection"] == -1 and record["decomposition_selection"] is None and
            record["decomposition_report_sha256"] is None and record["list_only"] is True and
            record["fresh_listing"] is True and record["parent_qualification_inherited"] is False and
            record["initial_eleven_proof_sha256"] == INITIAL_PROOF_SHA and
            record["initial_comparator_sha256"] == INITIAL_COMPARATOR_SHA and
            record["initial_generator_sha256"] == INITIAL_GENERATOR_SHA and
            record["initial_pure_helper_sha256"] == INITIAL_PURE_HELPER_SHA and
            record["initial_eleven_proof_path"] == str(INITIAL_PROOF_PATH) and
            record["retained_stage_minimum_branch_gain_ps"] == DEFAULT_MINIMUM_PS and
            record["new_stage_minimum_branch_gain_ps"] == MINIMUM_PS and record["diagnostic_token_counts"] == [3, 4] and
            record["expected_nondefault_minimum_log"] == MINIMUM_LOG and
            record["initial_current_proof_qualification_used"] is True and record["hardware_acceptance"] is False and
            record["listing_lineage"] == {"eleven_listing": str(INITIAL / "list-eleven"),
                                         "own_unbalanced_baseline": str(INITIAL / "baseline-placement")} and
            record["compiler_bytes_unchanged_from_fresh_eleven_listing"] is True,
            "selected phase inherited a stale ordinal or allowed a later phase")
    require("failure" not in record, "selected phase has a recorded execution failure")
    require(type(record["minimum_log_verified"]) is bool, "minimum verification alias is not boolean")
    if record["completed"] is True:
        lines = [line for line in (folder / "route.log").read_text().splitlines()
                 if "Placed reduction minimum branch gain:" in line]
        require(record["minimum_log_verified"] is True and lines == [MINIMUM_LOG], "exact minimum200 log is absent")
    g8.ready.authenticate_execution(record, base)
    return {"phase": phase, "folder": folder, "specs": specifications(base, phase),
            "command": expected_command(base, phase), "environment": environment}


def main():
    require(not PROFILE.exists(), "selected profile already exists")
    context = authenticate_initial()
    _, initial_profile, _, base, source, _, _, proof = context
    inputs = selected_input_map(initial_profile, proof)
    require(all(sha(Path(path)) == digest for path, digest in inputs.items()), "input closure changed during sealing")
    profile = {**profile_aliases(base, source), "input_sha256": inputs}
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True) + "\n")
    load_profile(initial_context=context)
    print(json.dumps({"profile_sha256": sha(PROFILE), "sealed_inputs": len(inputs),
                      "selected_eleven_ordinal": SELECTED_ELEVEN, "scope": profile["scope"]}, indent=2))


if __name__ == "__main__":
    main()
