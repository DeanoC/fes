"""Root-operated partial proof of selected eleven and fresh twelve listing.

The source reference is this producer's actual unbalanced placement. Only the
three explicitly reused eleven-literal cells may change. The twelve-literal
stage must finish with its original cells restored. Raw-mask truth assumes
the logical pin states omitted by pre-route JSON; no routed acceptance follows.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re

import seal_profile as seal

HERE, ROOT = seal.HERE, seal.ROOT
require, read, sha = seal.require, seal.read, seal.sha
PINS = "ABCDEF"
HEADER = re.compile(r"^Info: Placed reduction stage (\d+): root=(\S+) radius=(\d+) selection=(-?\d+)\.$", re.M)
TRIAL = re.compile(
    r"^Info: Placed reduction trial root=(\S+) leaves=(\S+) "
    r"branch_gain=([+-]?\d+(?:\.\d+)?)ps endpoint_gain=([+-]?\d+(?:\.\d+)?)ps "
    r"improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])\.$")
CANDIDATE = re.compile(r"^Info: Placed reduction candidate (\d+), (\d+) endpoints, branch gain ([+-]?\d+(?:\.\d+)?)ps\.$")
BEL = re.compile(r"MISTRAL_(?:M)?COMB\.(\d+)\.(\d+)\.(\d+)")


def relative(path):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT), "artifact lies outside the active FES checkout")
    return str(path.relative_to(ROOT))


def serial(value):
    return json.loads(json.dumps(value))


def top(g8, folder):
    document = g8.read_netlist(folder / "placed.json")
    require(set(document["modules"]) == {"top"}, "unexpected exported module set")
    return document["modules"]["top"]


def graph(g8, module):
    return g8.Netlist(module["cells"], module["netnames"])


def completed_phase(folder, context):
    record = read(folder / "run.json")
    phase = seal.authenticate_phase(record, context=context)
    require(phase["phase"] == "list-twelve" and phase["folder"].resolve() == folder.resolve() and
            record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0 and "failure" not in record,
            "selected listing is not finalized normally")
    require(not any(key in record for key in ("fmax", "final_reported_hold_violations")) and
            record["eleven_selection"] == seal.SELECTED_ELEVEN and record["twelve_selection"] == -1 and
            record["reduction_selection"] == -1 and record["decomposition_selection"] is None,
            "selected listing claims a later selected transform or final timing")
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            not any(marker in log for marker in
                    ("Decomposition", "Running the GPU router", "Running signoff timing analysis", "Placed-reduction")) and
            not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
            "selected listing ran AC/router or produced final outputs")
    specs = phase["specs"]
    require(len(specs) == 2 and specs[0]["candidate"] == seal.SELECTED_ELEVEN and
            specs[0]["radius"] == specs[1]["radius"] == 6 and specs[0]["minimum_branch_gain_ps"] == 250 and
            specs[1]["root"] == seal.TWELVE_ROOT and specs[1]["candidate"] == -1 and
            specs[1]["minimum_branch_gain_ps"] == 200,
            "selected listing is not fresh eleven/default250 then twelve/minimum200")
    return record, phase, log


def stage_blocks(log, specs):
    matches = list(HEADER.finditer(log))
    require(len(matches) == len(specs) == 2, "selected listing lacks exactly two attributed stage headers")
    prefix = log[:matches[0].start()]
    require(not any(marker in prefix for marker in ("Placed reduction", "Balanced three-LUT reduction")),
            "placed-reduction messages occur before the attributed stages")
    blocks = []
    for index, match in enumerate(matches):
        spec = specs[index]
        require(match.groups() == (str(index), spec["root"], str(spec["radius"]), str(spec["candidate"])),
                "actual stage header disagrees with its sealed specification")
        end = matches[index + 1].start() if index + 1 < len(matches) else len(log)
        blocks.append(log[match.end():end])
    require([line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line] == [seal.MINIMUM_LOG],
            "selected listing lacks exactly one explicit minimum200 diagnostic")
    return prefix, blocks


def qualification(block, spec, endpoints, literal_count):
    minimum, selection = spec["minimum_branch_gain_ps"], spec["candidate"]
    root = spec["root"]
    balanced = f"Info: Balanced three-LUT reduction at '{root}' into {(literal_count + 1) // 2}+{literal_count // 2} inputs."
    trials, candidates, pending, geometries = [], [], None, set()
    started, finished, minimum_seen = False, False, False
    for line in block.splitlines():
        if line == seal.MINIMUM_LOG:
            require(minimum == 200 and not minimum_seen and not started, "minimum200 diagnostic is misplaced")
            minimum_seen = True
        elif line == balanced:
            require(not started and not finished and (minimum == 250 or minimum_seen), "rewrite discovery repeated or preceded its minimum")
            started = True
        elif line.startswith("Info: Placed reduction trial "):
            require(started and not finished, "trial lies outside its discovered stage")
            match = TRIAL.fullmatch(line)
            require(match and match[1] == root, "malformed or misattributed trial")
            bels = match[2].split(",")
            require(len(bels) == len(set(bels)) == 2 and all(BEL.fullmatch(bel) for bel in bels), "trial lacks two distinct COMB BELs")
            geometry = tuple(tuple(int(value) for value in BEL.fullmatch(bel).groups()[:2]) for bel in bels)
            require(geometry not in geometries, "ordered leaf LAB geometry was timed twice")
            geometries.add(geometry)
            gain, endpoint_gain = float(match[3]), float(match[4])
            guards = [int(value) for value in match.groups()[4:]]
            require(math.isfinite(gain) and math.isfinite(endpoint_gain) and
                    guards[0] == int(gain > 0 and gain >= minimum) and (not guards[1] or endpoint_gain >= 0),
                    "trial qualification guard differs from its logged margin")
            pending = {"root": root, "leaf_bels": bels, "branch_gain_ps": gain,
                       "endpoint_gain_ps": endpoint_gain, "guards": guards, "trial_log": line}
            trials.append(pending)
        elif line.startswith("Info: Placed reduction candidate "):
            require(started and not finished, "candidate lies outside its discovered stage")
            match = CANDIDATE.fullmatch(line)
            require(match and pending and int(match[1]) == len(candidates) and int(match[2]) == endpoints and
                    pending["guards"] == [1, 1, 1, 1] and pending["branch_gain_ps"] >= minimum and
                    float(match[3]) == pending["branch_gain_ps"], "candidate lacks its consecutive ordinal and guarded trial")
            candidates.append({**pending, "candidate": int(match[1]), "endpoints": int(match[2]), "candidate_log": line})
            pending = None
        elif line.startswith("Info: Placed reduction: "):
            require(selection == -1 and started and not finished and line ==
                    f"Info: Placed reduction: {len(candidates)} qualified candidates; none applied.",
                    "listing completion disagrees with its actual candidates")
            finished = True
        elif "Placed reduction" in line or "Balanced three-LUT reduction" in line:
            require(False, "unsupported diagnostic within an attributed stage")
    require(started and block.count(balanced) == 1 and len(trials) <= 16 and
            sum(trial["guards"] == [1, 1, 1, 1] for trial in trials) == len(candidates) and
            minimum_seen is (minimum == 200), "stage did not complete bounded guarded qualification")
    require((selection == -1 and finished) or
            (selection >= 0 and not finished and len(candidates) == selection + 1 and pending is None),
            "selected stage did not stop at its ordinal, or final listing did not roll back")
    return {"minimum_branch_gain_ps": minimum, "selection": selection, "timed_trial_count": len(trials),
            "qualified_candidates": len(candidates), "qualified_ordinals": list(range(len(candidates))),
            "trials": trials, "candidates": candidates, "none_applied": selection == -1,
            "modeled_qualification_only_no_routed_timing_claim": True}


def conditional_cube(g8, module, root, count, reference):
    """Actual masks/connectivity, with every unavailable logical pin assumed SIG."""
    netlist = graph(g8, module)
    cone, literals, nodes = set(), {}, []
    def descend(token, required):
        require(len(token) == 3 and token[0] in netlist.cells and token[1:] == ("Q", 0), "cube has an unsupported native driver")
        name, cell = token[0], netlist.cells[token[0]]
        if not g8.ready.is_lut(cell):
            require(cell["type"] == "MISTRAL_FF" and token not in literals, "cube repeats a boundary or has a non-FFQ boundary")
            literals[token] = required
            return
        require(name not in cone and len(cone) < 3, "cube is cyclic, reconvergent or too large")
        cone.add(name)
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        ports = {**{pin: "input" for pin in PINS[:width]}, "Q": "output"}
        table = cell["parameters"].get("LUT")
        require(2 <= width <= 6 and cell["port_directions"] == ports and set(cell["connections"]) == set(ports) and
                all(type(bits) is list and len(bits) == 1 for bits in cell["connections"].values()) and
                set(cell["parameters"]) == {"LUT"} and type(table) is str and len(table) == 1 << width and
                set(table) <= {"0", "1"} and not cell["attributes"].get("FES_PINMAP_V1"), "cube has an invalid scalar LUT/schema or partial pins")
        mask = int(table, 2)
        matches = [row for row in range(1 << width) if bool((mask >> row) & 1) == required]
        require(len(matches) == 1, "raw conditional node is not a one-row cube")
        row = matches[0]
        for bit, pin in enumerate(PINS[:width]):
            descend(netlist.token(cell["connections"][pin][0]), bool((row >> bit) & 1))
        nodes.append({"cell": name, "type": cell["type"], "mask_hex": hex(mask),
                      "required_output": required, "unique_required_row": row,
                      "rows_checked": 1 << width, "bel": g8.previous.bel(cell)})
    descend((root, "Q", 0), True)
    require(len(cone) == 3 and len(literals) == count, "source is not the declared three-cell literal cube")
    top_tokens = {netlist.token(bit) for port in module["ports"].values() for bit in port["bits"]}
    for name in cone - {root}:
        users = netlist.direct_users.get((name, "Q", 0), [])
        require((name, "Q", 0) not in top_tokens and len(users) == 1 and users[0][0] in cone, "cube intermediate is not private")
    for token in literals:
        require(sum(user[0] in cone for user in netlist.direct_users.get(token, [])) == 1, "cube repeats an external source")
    boundary = sorted(literals)
    def evaluate(token, values):
        if token in values:
            return values[token]
        cell = netlist.cells[token[0]]
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        address = sum(evaluate(netlist.token(cell["connections"][pin][0]), values) << bit for bit, pin in enumerate(PINS[:width]))
        return (int(cell["parameters"]["LUT"], 2) >> address) & 1
    expected = sum(int(literals[token]) << bit for bit, token in enumerate(boundary))
    table = []
    for row in range(1 << count):
        values = {token: (row >> bit) & 1 for bit, token in enumerate(boundary)}
        value = evaluate((root, "Q", 0), values)
        require(value == int(row == expected), "conditional cube truth differs on row " + str(row))
        table.append(value)
    require(g8.essential(table, count) == set(range(count)), "cube contains an inessential literal")
    return {"root": root, "source_reference": relative(reference), "source_cone": sorted(cone), "source_nodes": nodes,
            "external_boundary_order": boundary, "conditional_required_values": [literals[token] for token in boundary],
            "assignments_checked": 1 << count, "true_rows": sum(table), "conditional_true_row": expected,
            "truth_sha256": hashlib.sha256(bytes(table)).hexdigest(),
            "raw_masks_and_native_ffq_identities_from_actual_supplied_placement": True,
            "all_lut_and_boundary_logical_pin_states_assumed_plain_signal": True,
            "independent_actual_listing_pin_polarity_truth_proved": False}, cone, literals


def cell_schema(g8, old, new, name, width, movable):
    before, after = old.cells[name], new.cells[name]
    mutable = {"type", "parameters", "port_directions", "connections", "attributes"}
    require({key: value for key, value in before.items() if key not in mutable} ==
            {key: value for key, value in after.items() if key not in mutable}, "declared cell changed unknown metadata: " + name)
    table = after["parameters"].get("LUT")
    require(after["type"] == f"MISTRAL_ALUT{width}" and set(before["parameters"]) == set(after["parameters"]) == {"LUT"} and
            type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"}, "declared cell LUT schema changed: " + name)
    allowed = {"NEXTPNR_BEL"} if movable else set()
    require({key: value for key, value in before["attributes"].items() if key not in allowed} ==
            {key: value for key, value in after["attributes"].items() if key not in allowed}, "declared cell changed non-placement attributes: " + name)


def applied_eleven(g8, baseline_top, candidate_top, initial_proof, selected, root, baseline_path, candidate_path):
    source, cone, literals = conditional_cube(g8, baseline_top, root, 11, baseline_path)
    current, new_cone, new_literals = conditional_cube(g8, candidate_top, root, 11, candidate_path)
    cached = initial_proof["conditional_eleven_literal_cube"]
    for key in ("root", "source_cone", "source_nodes", "external_boundary_order", "conditional_required_values",
                "assignments_checked", "true_rows", "conditional_true_row", "truth_sha256"):
        require(serial(source[key]) == cached[key], "actual source differs from cached fresh eleven cube: " + key)
    require(cone == new_cone and literals == new_literals and source["truth_sha256"] == current["truth_sha256"],
            "selected eleven changed original support or conditional truth")
    old, new = graph(g8, baseline_top), graph(g8, candidate_top)
    leaves = sorted(cone - {root})
    require(g8.previous.bel(old.cells[root]) == g8.previous.bel(new.cells[root]) and
            int(new.cells[root]["parameters"]["LUT"], 2) == 8 and
            new.inputs(root) == {pin: [(name, "Q", 0)] for pin, name in zip("AB", leaves)},
            "public eleven root moved or is not the direct ordered two-leaf AND")
    cell_schema(g8, old, new, root, 2, False)
    require([g8.previous.bel(new.cells[name]) for name in leaves] == selected["leaf_bels"],
            "actual selected eleven leaf BELs differ from the fresh guarded trial")
    partitions = []
    for index, name in enumerate(leaves):
        width = 6 - index
        cell_schema(g8, old, new, name, width, True)
        inputs = [new.token(new.cells[name]["connections"][pin][0]) for pin in PINS[:width]]
        require(len(inputs) == len(set(inputs)) == width and set(inputs) <= set(literals), "eleven leaf has a repeated or new literal")
        require(new.direct_users.get((name, "Q", 0), []) == [(root, "AB"[index], 0)], "eleven leaf output acquired a side user")
        partitions.append(set(inputs))
    require(partitions[0].isdisjoint(partitions[1]) and partitions[0] | partitions[1] == set(literals),
            "selected eleven leaves do not partition all eleven original inputs")
    require(old.direct_users.get((root, "Q", 0), []) == new.direct_users.get((root, "Q", 0), []), "public eleven root users changed")
    return {"root": root, "reused_cells": sorted(cone), "reused_leaves": leaves,
            "source_conditional_cube": source, "actual_conditional_cube": current, "selected_trial": selected,
            "public_root_bel_output_net_and_consumers_preserved": True,
            "three_existing_cells_reused_without_owner_or_output_net_additions": True,
            "current_pin_states_and_physical_mapping_available": False}, cone


def outside_graph(g8, baseline_top, candidate_top, cone):
    old, new = graph(g8, baseline_top), graph(g8, candidate_top)
    require(set(old.cells) == set(new.cells) and not any(cell["type"] == "MISTRAL_BUF" for cell in new.cells.values()),
            "pre-route selected listing changed owners or contains route-created buffers")
    for name in old.cells:
        if name not in cone:
            require(g8.dictionary_cell(old, name) == g8.dictionary_cell(new, name) and
                    g8.direct_connections(old, name) == g8.direct_connections(new, name), "outside declared eleven cells changed: " + name)
        require(new.cells[name]["attributes"].get("NEXTPNR_BEL") and not new.cells[name]["attributes"].get("FES_PINMAP_V1"),
                "selected listing has an unplaced cell or partial physical pin export")
    for token in set(old.direct_users) | set(new.direct_users):
        before, after = old.direct_users.get(token, []), new.direct_users.get(token, [])
        require([user for user in before if user[0] not in cone] == [user for user in after if user[0] not in cone],
                "an outside named consumer entry changed: " + repr(token))
        require(sum(user[0] in cone for user in before) == sum(user[0] in cone for user in after),
                "a declared eleven input changed its native source consumer multiplicity")
    g8.compare_named_nets(baseline_top, candidate_top, old, new)
    g8.ranking.top_ports(baseline_top, candidate_top, old, new)
    require({key: value for key, value in baseline_top.items() if key not in {"cells", "netnames", "ports"}} ==
            {key: value for key, value in candidate_top.items() if key not in {"cells", "netnames", "ports"}} and
            not candidate_top["attributes"].get("FES_LABSTATE_V1"), "same-phase settings/attributes changed or routed LAB state appeared")
    orders = {}
    for dictionary in ("cells", "netnames"):
        names = list(baseline_top[dictionary])
        require(names == list(candidate_top[dictionary]), "original named owner export order changed")
        orders[dictionary] = {"count": len(names), "exact_name_order_identical": True,
                              "name_order_sha256": hashlib.sha256("\n".join(names).encode()).hexdigest()}
    return {"exact_outside_declared_three_cell_dictionaries_and_native_consumers": True,
            "all_original_ff_named_connections_bels_and_attributes_exact": True,
            "all_named_net_aliases_metadata_and_public_ports_preserved": True,
            "all_unmodified_input_consumer_entries_preserved": True, "only_derived_eleven_cone_input_entries_replaced": True,
            "named_owner_export_order": orders, "lossless_pll_port_audit": g8.pll_port_audit(old, new),
            "indexed_user_slots_free_lists_or_owner_bucket_identity_proved": False,
            "current_full_logical_physical_pin_or_route_buffer_preservation_proved": False}


def downstream(g8, module, root):
    netlist = graph(g8, module)
    visited, active, endpoints = set(), set(), set()
    def collect(token):
        require(token not in active and token not in visited and len(visited) + len(active) < 64,
                "narrow endpoint closure is cyclic, reconvergent or too large")
        active.add(token)
        for name, pin, index in netlist.direct_users.get(token, []):
            cell = netlist.cells[name]
            require(index == 0 and cell["port_directions"].get(pin) == "input", "endpoint edge is not a scalar input")
            if g8.ready.is_lut(cell):
                collect((name, "Q", 0))
            else:
                require(cell["type"] == "MISTRAL_FF" and pin != "CLK", "endpoint is not an ordinary FF input")
                endpoints.add((name, pin, index))
        active.remove(token)
        visited.add(token)
    collect((root, "Q", 0))
    require(endpoints, "twelve source has no ordinary endpoint")
    return {"net_count": len(visited), "nets": sorted(visited), "endpoint_count": len(endpoints), "ff_inputs": sorted(endpoints)}


def upstream_messages(log):
    markers = ("Balanced four-LUT reduction", "Enable replication", "Local-remap plan step ",
               "Local remap ", "Comb remap ", "Capture locality")
    return [line for line in log.splitlines() if any(marker in line for marker in markers)]


def comparison(folder):
    context = seal.load_profile()
    profile, g8, base, source, control, prior = context
    require(folder.resolve() == seal.phase_folder("list-twelve").resolve(), "only the fresh twelve listing is supported")
    record, phase, log = completed_phase(folder, context)
    prior_record, prior_proof = prior["record"], prior["proof"]
    require(prior_proof["candidate_completed"] is True and prior_proof["partial_graph_evidence_available"] is True and
            prior_proof["graph_proof_available"] is False and prior_proof["parent_qualification_inherited"] is False and
            prior_record["compiler_commit"] == record["compiler_commit"] == source["result_commit"] and
            seal.SELECTED_ELEVEN in prior_proof["qualified_eleven_ordinals"], "initial current qualification is absent or stale")
    require(prior_proof["generator"] == {
        "path": relative(seal.INITIAL_GENERATOR_PATH), "sha256": seal.INITIAL_GENERATOR_SHA,
        "pure_helper_path": relative(seal.INITIAL / "compare_first11.py"),
        "pure_helper_sha256": seal.INITIAL_PURE_HELPER_SHA,
    }, "initial proof does not identify its actual flat generator and frozen pure helper")
    baseline_folder, initial_folder = seal.INITIAL / "baseline-placement", seal.INITIAL / "list-eleven"
    baseline_record = read(baseline_folder / "run.json")
    require(baseline_record["completed"] is True and type(baseline_record["exit_code"]) is int and baseline_record["exit_code"] == 0 and
            baseline_record["compiler_commit"] == source["result_commit"], "actual own unbalanced baseline is incomplete")
    digests, original_paths, execution_digests = {}, {}, {}
    def bind(path, digest=None):
        path = Path(path).absolute()
        canonical = path.resolve()
        relative(canonical)
        if canonical not in digests:
            digests[canonical] = sha(path)
        observed = digests[canonical]
        digest = observed if digest is None else digest
        require(observed == digest and (path not in original_paths or original_paths[path] == digest),
                "comparison input changed or has conflicting identities: " + str(path))
        original_paths[path] = digest
    for name, digest in prior_proof["artifact_sha256"].items():
        bind(ROOT / name, digest)
    for name, digest in record["input_sha256"].items():
        bind(name, digest)
    for path in (Path(__file__), seal.PROFILE, HERE / "seal_profile.py", HERE / "route.py", seal.INITIAL_PROOF_PATH,
                 seal.INITIAL_GENERATOR_PATH,
                 *(folder / name for name in ("run.json", "route.log", "placed.json")),
                 *(baseline_folder / name for name in ("run.json", "route.log", "placed.json")),
                 *(initial_folder / name for name in ("run.json", "route.log", "placed.json"))):
        bind(path)
    require(prior_proof["execution_file_sha256"] == record["execution"]["files"], "fresh selected phase changed controlled execution files")
    for name, digest in record["execution"]["files"].items():
        path = Path(name)
        execution_digests[path] = digest
        if path.resolve().is_relative_to(ROOT):
            bind(path, digest)
    baseline_log, initial_log = [(directory / "route.log").read_text() for directory in (baseline_folder, initial_folder)]
    metrics = [g8.previous.PLACEMENT_METRICS.findall(value) for value in (baseline_log, initial_log, log)]
    require(len(metrics[0]) == 71 and metrics[0] == metrics[1] == metrics[2] and
            hashlib.sha256("\n".join(metrics[0]).encode()).hexdigest() == prior_proof["placement_metrics_sha256"],
            "ordinary placement metrics differ from the actual baseline/fresh eleven proof")
    prefix, blocks = stage_blocks(log, phase["specs"])
    require(upstream_messages(log) == upstream_messages(baseline_log) == upstream_messages(initial_log) and
            upstream_messages(log) == upstream_messages(prefix), "retained locals/comb/capture messages changed or ran after reduction")
    baseline_top, candidate_top = top(g8, baseline_folder), top(g8, folder)
    eleven_spec, twelve_spec = phase["specs"]
    eleven_closure = downstream(g8, baseline_top, eleven_spec["root"])
    require(serial(eleven_closure) == prior_proof["actual_endpoint_closure"], "actual source eleven endpoint closure differs from cached proof")
    eleven_qualification = qualification(blocks[0], eleven_spec, eleven_closure["endpoint_count"], 11)
    candidates = [row for row in prior_proof["qualification"]["candidates"] if row["candidate"] == seal.SELECTED_ELEVEN]
    require(len(candidates) == 1 and eleven_qualification["candidates"][-1] == candidates[0], "selected eleven trial differs from its fresh qualification")
    actual_messages = [line for line in blocks[0].splitlines() if "Placed reduction" in line or "Balanced three-LUT reduction" in line]
    fresh_messages = [line for line in initial_log.splitlines() if "Placed reduction" in line or "Balanced three-LUT reduction" in line]
    require(fresh_messages.count(candidates[0]["candidate_log"]) == 1 and actual_messages ==
            fresh_messages[:fresh_messages.index(candidates[0]["candidate_log"]) + 1], "selected eleven discovery/probe prefix changed")
    applied, cone = applied_eleven(g8, baseline_top, candidate_top, prior_proof, candidates[0], eleven_spec["root"],
                                 baseline_folder / "placed.json", folder / "placed.json")
    outside = outside_graph(g8, baseline_top, candidate_top, cone)
    before12, cone12, literals12 = conditional_cube(g8, baseline_top, twelve_spec["root"], 12, baseline_folder / "placed.json")
    after12, current_cone12, current_literals12 = conditional_cube(g8, candidate_top, twelve_spec["root"], 12, folder / "placed.json")
    require(cone.isdisjoint(cone12) and cone12 == current_cone12 and literals12 == current_literals12 and
            before12["truth_sha256"] == after12["truth_sha256"] and not any(literals12.values()),
            "twelve listing did not restore its disjoint twelve-literal NOR source")
    closure12, current_closure12 = [downstream(g8, module, twelve_spec["root"]) for module in (baseline_top, candidate_top)]
    require(closure12 == current_closure12 and closure12["endpoint_count"] == 227,
            "twelve listing changed the actual complete227-endpoint source closure")
    twelve_qualification = qualification(blocks[1], twelve_spec, closure12["endpoint_count"], 12)
    require(all(sha(path) == digest for path, digest in {**original_paths, **execution_digests}.items()),
            "artifacts or controlled execution files changed during comparison")
    return {"phase": "list-twelve", "status": "selected eleven named partial proof; fresh twelve rolled-back listing; conditional truth only",
            "compiler_commit": source["result_commit"], "base_compiler_commit": record["base_compiler_commit"],
            "profile_sha256": sha(seal.PROFILE), "initial_eleven_proof_sha256": seal.INITIAL_PROOF_SHA,
            "initial_generator_sha256": seal.INITIAL_GENERATOR_SHA,
            "initial_pure_helper_sha256": seal.INITIAL_PURE_HELPER_SHA,
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
            "selected_eleven_ordinal": seal.SELECTED_ELEVEN, "parent_qualification_inherited": False,
            "initial_current_proof_qualification_used": True,
            "qualified_twelve_ordinals": twelve_qualification["qualified_ordinals"], "qualified_ac_ordinals": [],
            "applied_eleven_evidence": applied, "selected_eleven_qualification_replayed_exactly": eleven_qualification,
            "outside_declared_eleven_graph": outside,
            "source_twelve_conditional_cube": before12, "rolled_back_twelve_conditional_cube": after12,
            "actual_twelve_downstream_closure": closure12, "new12_qualification": twelve_qualification,
            "graph_proof_available": False, "partial_graph_evidence_available": True,
            "route_started": False, "timing_acceptance_available": False,
            "matched_placement_metrics": 71, "placement_metrics_identical": True,
            "placement_metrics_sha256": hashlib.sha256("\n".join(metrics[0]).encode()).hexdigest(),
            "retained_upstream_stack_message_sha256": hashlib.sha256("\n".join(upstream_messages(log)).encode()).hexdigest(),
            "cached_old_comparisons_reexecuted": False, "default_recipe_selected": False, "hardware_tested": False,
            "final_metadata_stable_during_comparison": True,
            "execution_file_sha256": {str(path): digest for path, digest in sorted(execution_digests.items())},
            "proof_limitations": [
                "The actual unbalanced baseline and fresh eleven proof come from this same frozen producer; no balanced old route is substituted.",
                "All 2048 applied-eleven and 4096 twelve raw-mask rows assume unexported LUT and boundary logical pin states are plain signal.",
                "Exactly three existing eleven cells change types/masks/inputs and declared leaf BELs; every outside named dictionary and direct consumer remains strict.",
                "The twelve stage applies no candidate; all its source masks/ports/BELs remain in the final placement export.",
                "Named consumer triples/export order are serialized; indexed-store slot IDs/free lists, owner pointers/buckets are not proved.",
                "No current logical/physical pin map, route-created BUF population, LAB configuration, final timing/hold/RBF or hardware acceptance is claimed.",
                "Any later selected twelve/AC/full route requires its own freshly qualified ordinal and independently proved actual graph/physical scope.",
            ],
            "artifact_sha256": {relative(path): digest for path, digest in sorted(digests.items())}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    require(not (args.folder / "comparison.json").exists(), "comparison output already exists")
    result = comparison(args.folder)
    with (args.folder / "comparison.json").open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({key: result[key] for key in
                      ("phase", "candidate_completed", "graph_proof_available", "qualified_twelve_ordinals")}, indent=2))


if __name__ == "__main__":
    main()
