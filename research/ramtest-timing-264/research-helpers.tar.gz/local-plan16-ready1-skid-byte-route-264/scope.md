# Ninth-stage full-route recorder

This new recorder may activate only after the ninth predicted run is actually
closed and its independent native prefix is positive. Both actual SHA-256 pins
are required by `prepare`; the actual closed predicted run `899a21d8…` is now
pinned and the independent prefix SHA remains an explicit activation argument.
No future proof is presumed. The prepared
profile binds actual ninth identity `aceefeba…`, nine-plan `9acacb23…`, recorder
`51ff54f3…` and scope `1533f18f…`, the new compiler's positive exact eight-stage
control `1cff85d6…`, current host `0f3c11a5…`, source commit `d7e5c61f…`, compiler
`41c2afe1…` and archive `4fbebd5e…`. Historical compiler checks do not qualify
this source. The host's committed source/dependency paths and flat closure are
rehashed at their original paths. Loaded historical build/test processes are
not reconstructed or claimed.

The immutable first prefix `0a121998…`, its `0d824c45…` generator and
`2b61d270…` scope remain bound as an explicit structural rejection with valid
current timing topology. Only the separate positive V2 output may activate this
recorder. V2 must include those immutable paths in its flat closure and declare
exactly four named private output owners: comb 120724→120726, decomposition
code0 120726→120728, code1 120728→120730, root 120730→120732. This recorder
checks each actual before/current Q, alias record and entire named consumer
manifest. All eight existing local-copy output IDs remain literal; no global
numeric translation is used. The ninth Q can reuse the freed old comb-private
number only through the independently proven four-owner partition. The full
routed frame still needs a fresh independent proof.

The only imported historical executable definitions called are pure hash/JSON
binding, flat manifest adoption, allowlisted definition loading, current host
validation, command/runtime comparison, and local/driver log parsers. None of
the old prepare, run, route, source-authentication or main entrypoints is called.
This recorder owns its live clean-source query. Its project runtime imports are
the five pinned scripts, including their project transitive imports; original
paths and hashes are checked after import and again after the actual run.

Two independent command derivations must agree: the actual old eighth full
command `3ef0c0b6…` with current executable, ninth plan/current predicted driver
guide and fresh output aliases; and the actual ninth baseline command with only
one `--no-route` removed, fresh driver candidate 0 and RBF output appended. All
other arguments and diagnostic environment stay exact. The current execution
must equal the ninth baseline and must equal the old eighth full execution
after changing only the compiler file/hash and PATH. The actual HIP device is 1;
no ambient `NEXTPNR_MISTRAL_*` setting is admitted.

The ninth prefix must prove its complete current native topology and conditional
16-row ordinary composition. Eight existing copies retain complete native
records, literal output bits and their 21/2/10/1/6/1/1/3 named ENA cohorts. The
ninth copy has exactly the two authorized skid-byteenable FF3/7 ENAs and the
freshly selected BEL. All 8221 original FF BELs are checked. Complete FF records
are predeclared for all local cones/copies/cohort LABs and the DDR0 source, carry
operand and its immediate CO-to-CI successor. The fresh driver site is dynamic;
its final whole LAB must be added and independently checked by the later proof.
No guessed clone Q, BEL, pin map, cached state or physical function is accepted.

The driver guide is the untouched current ninth predicted report. Its violated
ordinary LUT-to-arithmetic edges must contain exactly the existing burst-decoder
to command-counter A edge. The current source has three distinct scalar inputs,
mask 0x20/eight rows and exactly 49 consumers, including that selected operand.
The driver log parser preserves the existing minimum 250 ps gain and all four
compiled guards. Its fresh complete domain summary must be 334 endpoints, 331
timed pairs, three unrelated pairs, 331 hold pairs and reference-free analysis
enabled. Candidate 0's actual site and gain are recorded, never inherited.

`route` requires the explicit prepared profile SHA. It makes exclusive outputs,
runs the authenticated current compiler/read-audit invocation, checks all nine
fresh models against the positive prefix, actual HIP completion, normal RBF
signoff, 16384 report cap/15290 paths and positive finite reported Fmax entries.
Both the literal final hold marker and broad final hold/min warning scan must be
clear. Current input/output/runtime bytes and live committed source are checked
on success and failure; failures retain partial output hashes and do not become
acceptance. The recorder does not independently evaluate the seven clock windows.

The old eighth native/physical proof `f74c76d8…` is construction provenance with
timing gain false. Current accepted fifth proof `6dcf8c4b…`/run `5ed3c077…` remains
the numerical reference: memory must later exceed 117.77175903320312 MHz and all
six other required windows must retain positive headroom, clock constraints and
zero final hold violations. This recorder records timing; every native, physical,
routed-gain and hardware acceptance field remains false until a new independent
full comparison checks final exported pins, shared banks, whole LAB/FF controls,
carry, all original/BUF/private-owner frames and complete current timing.

Root is the sole executor. These two new files change no compiler/default policy,
old runner, evidence, guide, placement, routed image or RBF.
