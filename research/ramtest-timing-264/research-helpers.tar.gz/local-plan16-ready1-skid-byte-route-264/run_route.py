"""Record a fresh driver/GPU/RBF route only after a proved ninth-stage prefix."""
import hashlib
import importlib.util
import math
from pathlib import Path
import re
import subprocess
import sys
import time
import argparse

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
BASELINE = RAW / "local-plan16-ready1-skid-byte-stage-264"
PROOF = BASELINE / "baseline/comparison-prefix-v2.json"
STRICT = BASELINE / "baseline/comparison-prefix.json"
STRICT_SHA = "0a121998881b8ac94e0b816c315579d0789e7a714fb875356b5c758d239ea60c"
STRICT_HELPER_SHA = "0d824c45fde97ac6ae3c524b1d411c83cb36f06fc95deadec1ca28a150db831f"
STRICT_SCOPE_SHA = "2b61d270ac09da2bf2ecfab5a25fbc50f4841d50ec17c8c3865ceccc051b698d"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "route-c0"
PREFIX_PROFILE_SHA = "aceefeba07c0b3f3d7e98d09d336742b10a31aac734dccfe9c6df6dd71971d51"
PREFIX_RUN_SHA = "899a21d86764d2904aeab4632724b68e7db8e23cccd5ddc6a84be932dd4de4a6"
PLAN_SHA = "9acacb2358c2e41aba147c445ec626f9c25f0ae29e2f557b416160860720f9bd"
NINTH_SHA = "51ff54f38b122f9d6bef47b2feb9a64916855b3523215df8b06e0c3cc99dd487"
NINTH_SCOPE_SHA = "1533f18f01efebf3b3dc3010d054d91b3ad1a565206f4b0b9205a988615d8702"
OLD = RAW / "local-multicopy-ready1-route-264/run_route.py"
OLD_SHA = "3e81198bb1c9c89c8c63144b0354138514c5c10ba5b0ef5ecd82d15e3956ccf3"
OLD_SCOPE_SHA = "6f98611a39b498b329909bff3b0d764dab10f94214ae85039528812ecdf8f414"
EXPERIMENT = RAW / "local-multicopy-port0-skid-address-route-proof-264/comparison.json"
EXPERIMENT_SHA = "f74c76d8ee455ccc499e86a99256c771537953615b0136762dae1ed85a33a4e3"
TEMPLATE_FOLDER = RAW / "local-multicopy-port0-skid-address-route-264"
TEMPLATE_RUN_SHA = "3ef0c0b68f5bcb5d9fc0c7667663c88b1cdc086869973929c2c8e3b4450b7497"
TEMPLATE_PROFILE_SHA = "539376c79a565e3f114c20349a1a764059443217c68b088c2892bc66de1960c0"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
ACCEPTED_FOLDER = RAW / "local-multicopy-ready1-address-route-264"
ACCEPTED_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
MINIMUM_MEMORY_MHZ = 117.77175903320312
COMB_OWNER = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMPOSITION = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C$"
PRIVATE_OUTPUTS = {COMB_OWNER: (120724, 120726), DECOMPOSITION + "code0": (120726, 120728),
                   DECOMPOSITION + "code1": (120728, 120730), DECOMPOSITION + "root": (120730, 120732)}


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure definition bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure definition pathname differs")
    return module


def definitions():
    ninth = load(BASELINE / "run_baseline.py", NINTH_SHA, "ninth_route_baseline_pure")
    control, local = ninth.local_definitions()
    driver = load(OLD, OLD_SHA, "ninth_route_driver_log_pure")
    return ninth, control, local, driver


def clean_source(ninth, host):
    def git(repo, *args):
        return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(ninth.SOURCE, "rev-parse", "HEAD") == ninth.COMMIT and
            not git(ninth.SOURCE, "status", "--porcelain", "--untracked-files=all") and
            git(ninth.SOURCE, "merge-base", ninth.BASE, ninth.COMMIT) == ninth.BASE and
            set(git(ninth.SOURCE, "diff", "--name-only", ninth.BASE, ninth.COMMIT).splitlines()) == set(host["changed_source_files"]),
            "current compiler is not its clean committed host delta")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
            [(ninth.SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected compiler dependency changed")


def command(baseline, template, ninth, control):
    result, predicted = list(template["command"]), list(baseline["command"])
    require(result[0] == str(control.OLD_BINARY) and predicted[0] == str(ninth.BINARY) and "--no-route" not in result and
            "--compress-rbf" not in result and result.count("--router") == result.count("--gpu-device") ==
            result.count("--remap-lut-driver-candidate") == 1 and result[result.index("--router") + 1] == "gpu" and
            result[result.index("--gpu-device") + 1] == "1" and result[result.index("--remap-lut-driver-candidate") + 1] == "0",
            "actual old eighth full command selectors differ")
    require(predicted.count("--no-route") == 1 and not any(flag in predicted for flag in
            ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "current ninth predicted role differs")
    result[0] = str(ninth.BINARY)
    for flag, path in (("--remap-plan", BASELINE / "local-plan.json"),
            ("--remap-lut-driver-critical", BASELINE / "baseline/timing.json"),
            ("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json"), ("--rbf", FOLDER / "core.rbf")):
        require(result.count(flag) == 1, "ambiguous old full selector")
        result[result.index(flag) + 1] = str(path)
    predicted.remove("--no-route")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json")):
        require(predicted.count(flag) == 1, "ambiguous ninth output selector")
        predicted[predicted.index(flag) + 1] = str(path)
    predicted += ["--remap-lut-driver-critical", str(BASELINE / "baseline/timing.json"),
                  "--remap-lut-driver-candidate", "0", "--rbf", str(FOLDER / "core.rbf")]
    require(result == predicted, "full command differs outside current ELF/nine-plan/guide/fresh output aliases")
    return result


def scalar(cell, port):
    values = cell["connections"][port]
    require(len(values) == 1 and type(values[0]) is int, "actual port is not a native scalar")
    return values[0]


def users(top, bit):
    return sorted((name, port, index, 0) for name, cell in top["cells"].items()
        for port, bits in cell["connections"].items() if cell["port_directions"][port] == "input"
        for index, value in enumerate(bits) if value == bit)


def prepare(prefix_sha, run_sha, self_sha, scope_sha):
    require(all(type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) and value != "0" * 64
            for value in (prefix_sha, run_sha, self_sha, scope_sha)) and run_sha == PREFIX_RUN_SHA and not PROFILE.exists() and not FOLDER.exists(),
            "actual positive ninth prefix/closed run/helper/scope pins and exclusive outputs required")
    ninth, control, local, driver = definitions()
    inputs = {}
    for path, expected in ((PROOF, prefix_sha), (STRICT, STRICT_SHA),
            (BASELINE / "compare_prefix.py", STRICT_HELPER_SHA), (BASELINE / "prefix-scope.md", STRICT_SCOPE_SHA),
            (BASELINE / "baseline/run.json", run_sha),
            (BASELINE / "source-identity.json", PREFIX_PROFILE_SHA), (BASELINE / "local-plan.json", PLAN_SHA),
            (BASELINE / "run_baseline.py", NINTH_SHA), (BASELINE / "scope.md", NINTH_SCOPE_SHA),
            (Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (OLD, OLD_SHA), (OLD.parent / "scope.md", OLD_SCOPE_SHA),
            (EXPERIMENT, EXPERIMENT_SHA), (TEMPLATE_FOLDER / "route-c0/run.json", TEMPLATE_RUN_SHA),
            (TEMPLATE_FOLDER / "source-identity.json", TEMPLATE_PROFILE_SHA), (ACCEPTED, ACCEPTED_SHA),
            (ACCEPTED_FOLDER / "route-c0/run.json", ACCEPTED_RUN_SHA),
            (ninth.BINARY, ninth.BINARY_SHA), (ninth.ARCHIVE, ninth.ARCHIVE_SHA), (ninth.HOST, ninth.HOST_SHA)):
        ninth.bind(inputs, path, expected)
    proof, identity, baseline, template, accepted, experiment, accepted_proof, host, prerequisite = (ninth.read(path) for path in
        (PROOF, BASELINE / "source-identity.json", BASELINE / "baseline/run.json", TEMPLATE_FOLDER / "route-c0/run.json",
         ACCEPTED_FOLDER / "route-c0/run.json", EXPERIMENT, ACCEPTED, ninth.HOST, ninth.CONTROL / "baseline/comparison-control.json"))
    strict = ninth.read(STRICT)
    for manifest in (proof, strict, experiment, accepted_proof, prerequisite): ninth.adopt(inputs, manifest)
    require(strict["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-bounded-native-prefix" and
            strict["generator_sha256"] == STRICT_HELPER_SHA and strict["scope_sha256"] == STRICT_SCOPE_SHA and
            strict["source_identity_sha256"] == PREFIX_PROFILE_SHA and strict["current_baseline_run_sha256"] == run_sha and
            strict["native_path_topology_rejection"] is None and strict["native_graph_proof_available"] is
            strict["fresh_driver_guide_available_after_conditional_prefix_proof"] is False and
            strict["structural_rejection"] == {"exception_type": "ValueError", "reason": "original alias/raw bits/metadata differs: " +
                "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E$Q"},
            "immutable strict ninth rejection provenance differs")
    control.host_valid(host, ninth.HOST_SHA)
    require(proof["schema"] == 1 and proof["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-explicit-private-owner-native-prefix" and
            proof["compiler_commit"] == ninth.COMMIT and proof["delta_base_commit"] == ninth.BASE and
            proof["immutable_strict_prefix_rejection_sha256"] == STRICT_SHA and
            proof["source_identity_sha256"] == PREFIX_PROFILE_SHA and proof["current_baseline_run_sha256"] == run_sha and
            proof["control_proof_sha256"] == ninth.CONTROL_PROOF_SHA and proof["previous_baseline_run_sha256"] == ninth.CONTROL_RUN_SHA and
            proof["runner_sha256"] == NINTH_SHA and proof["runner_scope_sha256"] == NINTH_SCOPE_SHA and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and all(proof[key] is True for key in
            ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
             "all_eight_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "final_original_path_metadata_and_runtime_hashes_stable")),
            "actual ninth prefix is not independently positive")
    require(inputs.get(str(BASELINE / "compare_prefix_v2.py")) == proof["generator_sha256"] and
            inputs.get(str(BASELINE / "prefix-v2-scope.md")) == proof["scope_sha256"] and
            all(proof["artifact_sha256"].get(str(path.relative_to(ROOT))) == expected for path, expected in
                ((STRICT, STRICT_SHA), (BASELINE / "compare_prefix.py", STRICT_HELPER_SHA), (BASELINE / "prefix-scope.md", STRICT_SCOPE_SHA))) and
            inputs.get(str(ninth.CONTROL / "baseline/comparison-control.json")) == ninth.CONTROL_PROOF_SHA and
            inputs.get(str(ninth.CONTROL / "run_baseline.py")) == ninth.CONTROL_HELPER_SHA and
            prerequisite["source_identity_sha256"] == ninth.CONTROL_PROFILE_SHA and
            prerequisite["current_baseline_run_sha256"] == ninth.CONTROL_RUN_SHA and
            prerequisite["fresh_ninth_stage_control_prerequisite_proved"] is prerequisite["complete_predicted_report_exact"] is True and
            prerequisite["structural_rejection"] is prerequisite["native_path_topology_rejection"] is None,
            "independent prefix/helper/new-compiler control closure differs")
    require(identity["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-predicted-baseline" and
            identity["helper_sha256"] == NINTH_SHA and identity["scope_sha256"] == NINTH_SCOPE_SHA and identity["local_plan_sha256"] == PLAN_SHA and
            identity["control_proof_sha256"] == ninth.CONTROL_PROOF_SHA and identity["host_validation_sha256"] == ninth.HOST_SHA and
            identity["experimental_current_full_proof_sha256"] == EXPERIMENT_SHA and identity["accepted_current_full_proof_sha256"] == ACCEPTED_SHA and
            baseline["source_identity_sha256"] == PREFIX_PROFILE_SHA and baseline["original_eight_complete_trial_models_exact"] is True and
            all(ninth.canonical(baseline[key]) == ninth.canonical(value) for key, value in identity.items() if key != "input_sha256") and
            baseline["input_sha256"] == {**identity["input_sha256"], str(BASELINE / "source-identity.json"): PREFIX_PROFILE_SHA},
            "ninth record/profile union differs")
    require(experiment["current_full_run_sha256"] == TEMPLATE_RUN_SHA and experiment["source_identity_sha256"] == TEMPLATE_PROFILE_SHA and
            experiment["accepted_full_proof_sha256"] == ACCEPTED_SHA and experiment["structural_rejection"] is None and
            experiment["native_graph_proof_available"] is experiment["physical_scope_proved"] is True and
            experiment["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and
            accepted_proof["current_full_run_sha256"] == ACCEPTED_RUN_SHA and accepted_proof["structural_rejection"] is None and
            accepted_proof["native_graph_proof_available"] is accepted_proof["physical_scope_proved"] is
            accepted_proof["routed_gain_accepted_under_confirmed_target_clock_rule"] is True, "old eighth construction/current accepted-five roles differ")
    for record in (baseline, template, accepted):
        require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
                record["final_original_input_output_runtime_hashes_stable"] is True and not any(key in record for key in
                ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")), "actual closed run is incomplete")
        for ledger in (record["input_sha256"], record["output_sha256"], record["execution"]["files"]):
            for path, expected in ledger.items(): ninth.bind(inputs, path, expected)
    for key in control.HOST_MAPS:
        for path, expected in host[key].items(): ninth.bind(inputs, path, expected)
    require(baseline["compiler_commit"] == ninth.COMMIT and baseline["delta_base_commit"] == ninth.BASE and
            baseline["binary_sha256"] == ninth.BINARY_SHA and baseline["source_archive_sha256"] == ninth.ARCHIVE_SHA and
            baseline["execution"] == identity["baseline_execution"] == control.expected_execution(template) and
            template["compiler_commit"] == accepted["compiler_commit"] == control.OLD_COMMIT and
            template["binary_sha256"] == accepted["binary_sha256"] == control.OLD_BINARY_SHA and
            template["source_archive_sha256"] == accepted["source_archive_sha256"] == control.OLD_ARCHIVE_SHA and
            baseline["diagnostic_environment"] == template["diagnostic_environment"] == accepted["diagnostic_environment"] and
            baseline["cwd"] == template["cwd"] == accepted["cwd"] == str(MODULE), "runtime/source substitution differs outside current ELF/PATH")
    for name, expected in control.SCRIPTS.items(): ninth.bind(inputs, MODULE / "scripts" / name, expected)
    for path, expected in control.PARSERS: ninth.bind(inputs, path, expected)
    models = ninth.qualification((BASELINE / "baseline/phase.log").read_text(), control, local)
    require(len(models) == 9 and ninth.canonical(models) == ninth.canonical(baseline["actual_selected_local_qualification"]) ==
            ninth.canonical(proof["fresh_local_models"]) and ninth.canonical(models[:8]) == ninth.canonical(identity["retained_local_models"]) ==
            ninth.canonical(proof["previous_local_models"]) and ninth.read(BASELINE / "local-plan.json")["steps"] == identity["local_plan_steps"] and
            len(identity["local_plan_steps"]) == 9 and identity["local_plan_steps"][:8] == ninth.read(ninth.CONTROL / "source-identity.json")["local_plan_steps"],
            "fresh nine models/exact eight descriptors differ")
    ninth.bind(inputs, ninth.NATIVE, ninth.NATIVE_SHA)
    native = load(ninth.NATIVE, ninth.NATIVE_SHA, "ninth_route_native_pure")
    top = native.read_netlist(BASELINE / "baseline/placed.json")["modules"]["top"]
    graph = proof["native_graph_evidence"]
    require(graph["serialized_native_scope_proved"] is graph["complete_native_driver_and_user_tables_proved"] is True and
            graph["new_clone"] == identity["expected_additional_copy_name"] == models[8]["outer"] + "$local_remap$3" and
            graph["declared_ena_redirect_count"] == len(graph["declared_ena_redirects"]) == models[8]["ena_users"] == 2 and
            graph["assignments_checked"] == 16 and graph["original_root_users_before"] == 102 and graph["original_root_users_after"] == 100 and
            ninth.canonical(graph["retained_copy_cohorts"]) == ninth.canonical(identity["retained_copy_cohorts"]), "ninth graph/cohort scope differs")
    private_rows = graph["explicit_private_output_owners"]
    require(graph["private_output_owner_count"] == len(private_rows) == 4 and graph["private_output_frame_alignment_used"] is
            graph["all_original_nonprivate_raw_slots_exact"] is True and
            {row["owner"] for row in private_rows} == set(PRIVATE_OUTPUTS), "explicit four-owner partition differs")
    prior_top = native.read_netlist(ninth.CONTROL / "baseline/placed.json")["modules"]["top"]
    for row in private_rows:
        owner, alias = row["owner"], row["alias"]
        before_q, after_q = PRIVATE_OUTPUTS[owner]
        slots = sorted(tuple(slot) for slot in row["named_consumer_slots"])
        require(alias == owner + "$Q" and row["before_raw_bit"] == scalar(prior_top["cells"][owner], "Q") == before_q and
                row["after_raw_bit"] == scalar(top["cells"][owner], "Q") == after_q and
                row["before_driver"] == row["after_driver"] == [owner, "Q", 0, 0] and
                users(prior_top, before_q) == users(top, after_q) == slots and
                ninth.canonical(prior_top["netnames"][alias]) == ninth.canonical(row["before_alias_record"]) and
                ninth.canonical(top["netnames"][alias]) == ninth.canonical(row["after_alias_record"]), "named private owner/Q/alias/all consumers differ")
    rows, frames = graph["retained_copy_cohorts"], graph["actual_retained_copy_output_rows"]
    require(len(rows) == len(frames) == 8 and [len(row["consumer_slots"]) for row in rows] == [21, 2, 10, 1, 6, 1, 1, 3], "eight retained cohorts differ")
    cohort, owners, labs = set(), {graph["new_clone"], driver.SOURCE, driver.SINK}, {tuple(model["primary_lab"]) for model in models}
    for row, frame, model in zip(rows, frames, models[:8]):
        name, cell = row["cell"], top["cells"][row["cell"]]
        require(frame["cell"] == name and frame["before_raw_bit"] == frame["after_raw_bit"] == scalar(row["record"], "Q") == scalar(cell, "Q") and
                frame["consumer_slots"] == row["consumer_slots"] and users(top, scalar(cell, "Q")) == [tuple(slot) for slot in row["consumer_slots"]] and
                ninth.canonical(cell) == ninth.canonical(row["record"]) and cell["attributes"]["NEXTPNR_BEL"] == model["bel"],
                "retained named owner/Q/record/consumer slots differ")
        cohort.update(slot[0] for slot in row["consumer_slots"]); owners.add(name)
    clone = top["cells"][graph["new_clone"]]
    require(clone["attributes"]["NEXTPNR_BEL"] == models[8]["bel"] == graph["actual_clone_bel"] and
            scalar(clone, "Q") == graph["actual_clone_q"] and users(top, scalar(clone, "Q")) == [(name, "ENA", 0, 0) for name in ninth.TARGETS] and
            {row["cell"] for row in graph["declared_ena_redirects"]} == set(ninth.TARGETS), "actual ninth clone/two named ENAs differ")
    cohort.update(ninth.TARGETS)
    source, sink = top["cells"][driver.SOURCE], top["cells"][driver.SINK]
    q, lut = scalar(source, "Q"), source["parameters"].get("LUT")
    source_users = users(top, q)
    require(source["type"] == "MISTRAL_ALUT3" and sink["type"] == "MISTRAL_ALUT_ARITH" and scalar(sink, "A") == q and
            type(lut) is str and len(lut) == 8 and set(lut) <= {"0", "1"} and int(lut, 2) == 0x20 and
            len({scalar(source, port) for port in ("A", "B", "C")}) == 3 and len(source_users) == 49 and
            (driver.SINK, "A", 0, 0) in source_users and all(q not in port["bits"] for port in top["ports"].values()), "current source49/eight-row/carry operand edge differs")
    carry = scalar(sink, "CO")
    successors = [(name, cell) for name, cell in top["cells"].items() if name != driver.SINK and
        cell["type"] == "MISTRAL_ALUT_ARITH" and cell["connections"].get("CI") == [carry]]
    require(len(successors) == 1, "actual immediate CO-to-CI successor is not unique")
    owners.add(successors[0][0])
    for model in models: owners.update((model["inner"], model["outer"]))
    for name in owners | cohort:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared owner/cohort lacks a placed BEL")
        labs.add(tuple(map(int, match.groups())))
    ff_rows = []
    for name, cell in top["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", cell["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None and identity["all_original_ff_bel_manifest"].get(name) == cell["attributes"]["NEXTPNR_BEL"], "original FF BEL manifest differs")
        if tuple(map(int, match.groups())) in labs: ff_rows.append({"cell": name, "record": cell})
    require(len(identity["all_original_ff_bel_manifest"]) == 8221 and cohort <= {row["cell"] for row in ff_rows} and
            all(top["cells"][name]["connections"]["CLK"] == [3549] for name in cohort), "complete FF/common-clock/whole-LAB scope differs")
    report, parent_report = ninth.read(BASELINE / "baseline/timing.json"), ninth.read(ACCEPTED_FOLDER / "route-c0/timing.json")
    relevant = set()
    for path in report["critical_paths"]:
        if math.fsum(segment["delay"] for segment in path["path"]) <= path["max_delay"]: continue
        for segment in path["path"]:
            if segment["type"] != "routing": continue
            launch, capture = segment["from"], segment["to"]
            if top["cells"][launch["cell"]]["type"] in {"MISTRAL_ALUT" + str(width) for width in range(2, 7)} and \
                    top["cells"][capture["cell"]]["type"] == "MISTRAL_ALUT_ARITH" and capture["port"] in {"A", "B", "C", "D0", "D1"}:
                relevant.add((launch["cell"], capture["cell"], capture["port"]))
    require(relevant == {(driver.SOURCE, driver.SINK, "A")} and report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            parent_report["fmax"]["ram_clock.clocks[0]"]["achieved"] == MINIMUM_MEMORY_MHZ, "current guide membership/cap/count/accepted threshold differs")
    result = {"schema": 1, "phase": "local-plan16-ready1-skid-byte-ninth-stage-fresh-driver-full-route", "compiler_commit": ninth.COMMIT,
        "delta_base_commit": ninth.BASE, "binary_sha256": ninth.BINARY_SHA, "source_archive_sha256": ninth.ARCHIVE_SHA,
        "prefix_proof_sha256": prefix_sha, "prefix_source_identity_sha256": PREFIX_PROFILE_SHA, "prefix_baseline_run_sha256": run_sha,
        "prefix_generator_sha256": proof["generator_sha256"], "prefix_scope_sha256": proof["scope_sha256"],
        "local_plan_sha256": PLAN_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha, "host_validation_sha256": ninth.HOST_SHA,
        "control_proof_sha256": ninth.CONTROL_PROOF_SHA, "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": ACCEPTED_RUN_SHA,
        "experimental_eighth_full_proof_sha256": EXPERIMENT_SHA, "experimental_eighth_full_run_sha256": TEMPLATE_RUN_SHA,
        "experimental_eighth_routed_gain_accepted": False, "command": command(baseline, template, ninth, control), "cwd": baseline["cwd"],
        "diagnostic_environment": baseline["diagnostic_environment"], "baseline_execution": baseline["execution"], "input_sha256": dict(sorted(inputs.items())),
        "prefix_fresh_local_models": models, "declared_driver_edge": [driver.SOURCE, driver.SINK, "A"], "driver_candidate": 0,
        "driver_site_must_qualify_freshly": True, "declared_ena_redirects": graph["declared_ena_redirects"],
        "new_ready_clone": graph["new_clone"], "new_ready_clone_bel": models[8]["bel"], "retained_copy_cohorts": rows,
        "actual_retained_copy_output_rows": frames, "prefix_private_output_frame_alignment_used": graph["private_output_frame_alignment_used"],
        "prefix_explicit_private_output_owners": private_rows, "immutable_strict_prefix_rejection_sha256": STRICT_SHA,
        "driver_current_source_record": source, "driver_current_source_consumer_slots": [list(slot) for slot in source_users],
        "driver_source_conditional_truth_rows": [{"assignment": i, "Q": (int(lut, 2) >> i) & 1} for i in range(8)],
        "driver_current_sink_record": sink, "driver_current_immediate_carry_successor": {"cell": successors[0][0], "record": successors[0][1]},
        "declared_original_local_driver_and_carry_cells": sorted(owners), "affected_whole_labs": sorted(map(list, labs)),
        "all_original_ff_members_in_affected_labs": sorted(ff_rows, key=lambda row: row["cell"]),
        "actual_fresh_driver_site_neighborhood_requires_independent_full_proof": True,
        "minimum_accepted_memory_mhz": MINIMUM_MEMORY_MHZ, "accepted_fmax": parent_report["fmax"],
        "routed_graph_proof_available": False, "physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    ninth.finish(inputs); clean_source(ninth, host)
    with PROFILE.open("x") as stream: stream.write(ninth.canonical(result) + "\n")
    print(ninth.canonical({"profile_sha256": ninth.sha(PROFILE), "inputs": len(inputs), "whole_labs": len(labs), "original_ffs": len(ff_rows)}))


def route(profile_sha):
    ninth, control, local, driver = definitions(); inputs = {}
    ninth.bind(inputs, PROFILE, profile_sha); profile = ninth.read(PROFILE)
    for path, expected in profile["input_sha256"].items(): ninth.bind(inputs, path, expected)
    baseline, template, host = (ninth.read(path) for path in (BASELINE / "baseline/run.json", TEMPLATE_FOLDER / "route-c0/run.json", ninth.HOST))
    require(not FOLDER.exists() and profile["compiler_commit"] == ninth.COMMIT and profile["command"] == command(baseline, template, ninth, control) and
            profile["baseline_execution"] == baseline["execution"] and profile["diagnostic_environment"] == baseline["diagnostic_environment"] and
            inputs[str(BASELINE / "baseline/run.json")] == profile["prefix_baseline_run_sha256"] and inputs[str(PROOF)] == profile["prefix_proof_sha256"] and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
            profile["minimum_accepted_memory_mhz"] == MINIMUM_MEMORY_MHZ, "frozen exclusive full-route role differs")
    control.host_valid(host, ninth.HOST_SHA); clean_source(ninth, host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in control.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(inputs.get(str(MODULE / "scripts" / name)) == expected and Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and
                ninth.sha(loaded.__file__) == expected, "executed project dependency differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(ninth.BINARY,
        f"base_commit={ninth.BASE}; experimental_source_sha256={ninth.ARCHIVE_SHA}; sha256={ninth.BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual current runtime/ambient diagnostics changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(ninth.canonical(record) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            result = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = result.returncode, True
        invocation.verify(); require(result.returncode == 0, "actual ninth-stage full compiler failed")
        log = (FOLDER / "route.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                "Running the GPU router" in log and "Running signoff timing analysis..." in log and
                "Running predicted placed timing analysis for --report" not in log, "actual GPU/RBF signoff provenance absent")
        models = ninth.qualification(log, control, local)
        require(ninth.canonical(models) == ninth.canonical(profile["prefix_fresh_local_models"]), "actual nine fresh local models differ from positive prefix")
        trial = driver.qualification(log)
        require(trial["domain_summary"] == ["334", "331", "3", "331", "1"], "actual complete timed/unrelated/hold domain coverage differs")
        record["actual_selected_local_qualification"], record["actual_fresh_driver_qualification"] = models, trial
        report = ninth.read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()),
                "actual full report cap/count/Fmax differs")
        record["fmax"], record["actual_live_gpu_backend"] = report["fmax"], board._require_gpu_backend(log)
        require(record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log), "actual HIP completion absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        record["final_reported_hold_violations"] = "Hold/min time violation" in last
        record["last_signoff_hold_warning_lines"] = [line for line in last.splitlines() if re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not record["final_reported_hold_violations"] and not record["last_signoff_hold_warning_lines"], "LAST signoff hold/min violation")
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual full output absent")
            record["output_sha256"][str(path)] = ninth.sha(path)
        ninth.finish({**inputs, **record["output_sha256"]}); clean_source(ninth, host); record["completed"] = True
        print(ninth.canonical({"completed": True, "fmax": record["fmax"], "driver": trial, "routed_gain_accepted": False}))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): ninth.sha(FOLDER / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); ninth.finish({**inputs, **record.get("output_sha256", {})}); clean_source(ninth, host)
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False; record["final_original_input_output_runtime_hashes_stable"] = False; record["final_rehash_failure"] = repr(error)
                    raise
                finally:
                    (FOLDER / "run.json").write_text(ninth.canonical(record) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "route"))
    for name in ("prefix-sha256", "run-sha256", "self-sha256", "scope-sha256", "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(args.prefix_sha256 and args.run_sha256 and args.self_sha256 and args.scope_sha256, "actual positive prefix/closed run/helper/scope activation pins required")
        prepare(args.prefix_sha256, args.run_sha256, args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256, "before-run full profile activation pin required")
        route(args.profile_sha256)


if __name__ == "__main__":
    main()
