The generic wide-reduction compiler candidate now reproduces the successful scratch route: **108.944328 MHz memory**, up **2.625558%** on the frozen baseline.

| Frozen-input route | Memory MHz | Pixel MHz | Capture MHz |
| --- | ---: | ---: | ---: |
| Merged diagnostic baseline | 106.157112 | 94.500099 | 347.793488 |
| Slot-preserving compiler candidate | 108.944328 | 95.229019 | 378.582397 |

The earlier in-process candidate fell to 100.030014 MHz because its sequential disconnect/reconnect rewrite moved eight of the 19 selected consumers to different indexed-store slots. HeAP traverses those lists. Replacing each consumer in its existing slot recovers all 71 placement metrics and 213 GPU routing iteration metrics, identical BELs across all 20,115 common routed cells, and a compressed RBF **byte-identical** to the working pre-load rewrite. This explains this candidate regression; it does not explain the entire Quartus/OSS gap.

The generic opt-in pass is committed and pushed as [nextpnr b95ac420](https://github.com/DeanoC/nextpnr/commit/b95ac42012894628638b3d0e0e8c92d570baee30). It recognizes a four-LUT conjunction of sixteen distinct literals, preserves cells/root output/consumer slots, and rejects protected or special nets, implicit clocks, shared intermediates, and undefined or malformed LUT tables. No RAM-test names are embedded in the compiler.

Validation: frozen BUILD_ID `7168b508ab424b70f1c0f87b2035d821`, unchanged synthesis SHA256 `61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28`, GPU1/seed2/w10/c2/replication4; legal audited full route, no final reported hold violations, every required clock improves. The complete compiler CTest suite passes 3/3 targets; the consumer-slot and safety regressions were observed failing before their fixes; exhaustive normal/mixed-polarity truth checks and independent review pass. Local evidence is under `out/ramtest-wide-reduction-264/`, including source/archive hashes and a reproducible route comparison.

The existing FES recipe still selects **106.157112 MHz**; **108.944328 MHz is a validated opt-in compiler candidate pending integration**. No RTL, recipe, lock, ABI or hardware changes. Historical 116.918 MHz recovery and 130 MHz closure remain unresolved.

The next physical lead is now concrete: OSS's limiting `rd_data_0[48]`→`port0.returned_data[48]` path places its capture FF at X25/Y23 and spends 7.704 ns on read-data routing. Querying the saved Quartus fit puts the same RTL bit at X25/Y56, with 3.192 ns data delay and +3.254 ns setup slack at 130 MHz; the physical HPS output exits at X51/Y62. That Quartus fit has a different BUILD_ID, so this is a locality hint rather than timing-model calibration. The next experiment should move a bounded capture region using actual HPS output endpoints and setup/hold/control-set guards.
