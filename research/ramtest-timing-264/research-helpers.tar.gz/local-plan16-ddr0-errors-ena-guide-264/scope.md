# DDR0 errors-ENA search guide

This helper derives one unchanged path object at source index 2975 from the
completed tenth-stage route. Its endpoint is
`ddr0_errors_MISTRAL_FF_Q_11.ENA` in LAB 33.14. The path violates its actual
7.691999912261963 ns memory window at about 8.505 ns. It is not the global worst
path. The guide retains every other original report field and changes only the
`critical_paths` array, preserving the selected object's fields and segment
order. No source, clock, window, location or delay is projected or replaced.

The current construction is the positive native/physical V2 proof
`cd8ad7ff8fd40b7136ff265d645806e3d661cde186b3da819975658040b8f74a`, full run
`1a6d4f7b8efcc1e22c3af4c73b07a6fcfe609ce9ee07cc36c6d618a40c699428`,
profile `ea03398546c1a1c8f9f099d0ed6ce4b156661d3276e0ec2057c7f09e563fe305`,
and tenth predicted prefix `bf9d312c140f349f75244c087be5a90f59c6fb6a87d28437051936f178884fe3`.
The helper binds all eight explicit V2 helper/scope hashes and the immutable
strict rejection `fffb82ee2965c2ae9120a3f43ad59ca6c633cbfdf66aa5e35c6a716dd8fcd20f`.
That rejection concerned one named paired-half pin assignment, independently
closed by V2; its native and physical failure flags remain recorded. Current
V2 timing must remain exactly the strict record's timing. Current memory
116.808784 MHz is a rejected gain experiment.

The accepted timing reference remains the fifth-stage proof
`6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65` at
117.77175903320312 MHz. Its positive gain is a separate role; this guide does
not inherit it. Compiler d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f, base ec0a8d0c,
frozen ELF 41c2afe1, source archive 4fbebd5e, host validation 0f3c11a5 and fresh
eight-stage control 1cff85d6 are bound through the actual current profile.

The earlier ready0 eleventh append is separately bound as rejected provenance:
profile 616f85a4, partial run
`f87673b62e2260f9aef74d8dfe229f8b724505428a18e66c82984c97140ad564`, and only
phase-log output 3bed3c71. It completed false with exit 125 and a passing compiler
read audit; its appended step had zero qualified candidates and no trial rows.
It produced no placed or timing document and started no route. The helper
rehashes its frozen input/runtime frame and partial log, preserves its failure,
and never uses it as positive graph evidence or a stacked eleventh stage.

The new hypothesis uses the terminal ordinary pair
`ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT2_B` (ALUT2, mask 0xd,
Q 4973, COMB 24.22.54) and
`ddr0_errors_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_Q` (ALUT5, mask 0x7fff0000,
Q 4300, COMB 10.22.42). The second LUT receives the first on E. Six distinct
literal boundary nets, in proposed composed A–F order, are
`[4242, 15932, 4969, 4970, 4971, 4972]`. Each has one ordinary native driver.
The helper independently enumerates all 64 logical assignments of the existing
pair and checks mask `0x0ddddddddddddddd`:
`(!4242 || 15932) && !(4969 && 4970 && 4971 && 4972)`.
Both existing LUTs must have complete plain-SIG snapshots. These rows prove the
existing native composition only; a future ALUT6's site, pins, sharing and
function still require independent proof.

All 32 original outer-Q consumers are scalar FF ENAs on native CLK 3549. The
whole original-root cohort in LAB 33.14 has exactly eight members: errors FFs
5, 4, 3, 28, 23, 16, 12 and 11. All are retained as complete named native slots
and full records. The other 24 outer-Q consumers are explicitly inventoried.
The inner Q's 160 FF-ENA side consumers and the original outer-E slot are
retained separately. No new input loads or redirects have happened in this
guide. The proposed first `$local_remap` cell and private-Q name must be absent
from both current cell and net namespaces. No future ordinal, Q ID, BEL,
qualification, gain or legal ALUT6 capacity is assumed.

The exact current ten models and copy cohorts 21/2/10/1/6/1/1/3/2/8 are retained,
including literal copy Q IDs, sole private aliases, unique drivers and complete
FF-ENA consumer slots. The target group is disjoint from them. Complete pin
snapshots and native records cover the terminal pair, selected launch/upstream
owners, all six boundary drivers, target eight FFs and ten retained copies.
The output includes aliases and all original FF records in those known whole
LABs, plus all 8,221 original FF BELs. These inventories do not establish a
future placement or physical equivalence.

The common clock is the actual SIG CLKBUF Q 3549 from A 112726, driven by the
second serialized duplicate `outclk` occurrence of the paired PLL
112724/112726. The lossless parser preserves both occurrences. This is no
logical-channel ordinal or frequency-model claim, and no buffer is collapsed.

Only pinned pure definitions from parser 32fd10eb, topology 72131acf and its
locally isolated freeze dependency 8601df44 are loaded. No old authenticator,
generator, comparison, runner or main is invoked. The full current document and
own tenth predicted report are checked for all 15,290 native paths, seven domain
pairs, finite terms, native continuity and actual endpoint/window membership.
The flat current and accepted artifact/runtime maps and failed-attempt frame
are bound at original paths. All hashes are rechecked before exclusive guide
creation and after its hash is added to the closure.

ROOT alone supplies explicit self, scope, current proof and current run hashes,
reviews the helper, and executes it. Exclusive outputs are `errors-ena-guide.json`
and `derivation.json`. This is search evidence, with no new full timing report,
candidate/native/physical acceptance, independent STA, route-model calibration,
RBF/CRAM decode, unexported cache state, GPU-state equivalence or hardware claim.
