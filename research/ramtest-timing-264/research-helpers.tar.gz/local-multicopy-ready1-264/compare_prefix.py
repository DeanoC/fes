"""Conditional native prefix proof for one additive copy of the ready1 cone."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
CONTROL = RAW / "local-multicopy-264/baseline/comparison-control.json"
CONTROL_SHA = "f3e1f1e84d408db29088c39006b205284ad173bfe900a36f89c6b6122bdb076c"
PROFILE_SHA = "8678aa88a57a59c43fc94bab14ff71fdff47b95a9e95d8bc308c82ad7826e88b"
RUNNER_SHA = "440013e34d68841d103ca0bea4e3d927a9fd9f50917e10800ad604caa1aec36a"
RUNNER_SCOPE_SHA = "a62cb693434bdaa996f00e1694f4768543c98c4794d2c6f4ca3521736e89e170"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE = SELECTED.parent / "freeze.py"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
COMB_OWNER = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMPOSITION = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C"
PRIVATE_OWNERS = (COMB_OWNER, DECOMPOSITION + "$code0", DECOMPOSITION + "$code1", DECOMPOSITION + "$root")
PINS = "ABCDEF"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure helper pin/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure helper pathname differs")
    return module


def scalar(cell, port):
    bits = cell["connections"][port]
    require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0,
            "required native signal is not a scalar")
    return bits[0]


def lab(cell):
    match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
    require(match is not None, "original placed owner lacks a BEL")
    return [int(match[1]), int(match[2])]


def lut(cell):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    require(match is not None and set(cell["parameters"]) == {"LUT"}, "ordinary LUT schema differs")
    width, text = int(match[1]), cell["parameters"]["LUT"]
    directions = {pin: "input" for pin in PINS[:width]} | {"Q": "output"}
    require(type(text) is str and len(text) == 1 << width and set(text) <= {"0", "1"} and
            cell["port_directions"] == directions and set(cell["connections"]) == set(directions),
            "ordinary LUT table/port schema differs")
    return width, int(text, 2), [scalar(cell, pin) for pin in PINS[:width]], scalar(cell, "Q")


def private_ledger(native, a, b, old_drivers, old_users, new_drivers, new_users):
    rows, allowed = [], {}
    for owner in PRIVATE_OWNERS:
        alias = owner + "$Q"
        require(owner in a["cells"] and owner in b["cells"] and alias in a["netnames"] and alias in b["netnames"],
                "declared private owner/alias missing: " + owner)
        old_bit, new_bit = scalar(a["cells"][owner], "Q"), scalar(b["cells"][owner], "Q")
        lut(a["cells"][owner]); lut(b["cells"][owner])
        require(old_drivers.get(old_bit) == new_drivers.get(new_bit) == [(owner, "Q", 0, 0)] and
                old_users.get(old_bit) and old_users[old_bit] == new_users.get(new_bit),
                "private output unique driver/named consumer set differs: " + owner)
        for top, bit in ((a, old_bit), (b, new_bit)):
            require([name for name, net in top["netnames"].items() if bit in net["bits"]] == [alias] and
                    top["netnames"][alias]["bits"] == [bit] and
                    all(bit not in port["bits"] for port in top["ports"].values()),
                    "private output lacks its sole alias/no-public boundary: " + owner)
        left, right = dict(a["netnames"][alias]), dict(b["netnames"][alias])
        left.pop("bits"); right.pop("bits")
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs")
        for slot, role in [((owner, "Q", 0, 0), "private_output_driver")] + [
                (slot, "private_output_consumer") for slot in old_users[old_bit]]:
            require(slot not in allowed and slot[3] == 0, "private output slot ledgers overlap or use unsupported occurrences")
            if role == "private_output_consumer":
                require(a["cells"][slot[0]]["port_directions"][slot[1]] == b["cells"][slot[0]]["port_directions"][slot[1]] == "input" and
                        a["cells"][slot[0]]["connections"][slot[1]][slot[2]] == old_bit and
                        b["cells"][slot[0]]["connections"][slot[1]][slot[2]] == new_bit, "private consumer slot attribution differs")
            allowed[slot] = {"old_raw_bit": old_bit, "new_raw_bit": new_bit, "role": role, "owner": owner}
        rows.append({"owner": owner, "alias": alias, "old_raw_bit": old_bit, "new_raw_bit": new_bit,
                     "raw_bit_changed": old_bit != new_bit, "native_driver": [owner, "Q", 0, 0],
                     "named_consumer_slots": [list(slot) for slot in old_users[old_bit]],
                     "before_alias_record": a["netnames"][alias], "after_alias_record": b["netnames"][alias]})
    require(len({row["old_raw_bit"] for row in rows}) == len({row["new_raw_bit"] for row in rows}) == 4,
            "four private owners are not distinct in each image")
    return rows, allowed


def prove(native, selected, before_doc, after_doc, model, old_model):
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "native document metadata differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    old_copy, clone = model["outer"] + "$local_remap", model["outer"] + "$local_remap$1"
    alias = clone + "$Q"
    require(set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and list(a) == list(b) and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (14900, 14901, 16638, 16639) and
            set(b["cells"]) == set(a["cells"]) | {clone} and clone not in a["cells"] and
            set(b["netnames"]) == set(a["netnames"]) | {alias} and alias not in a["netnames"] and
            [name for name in b["cells"] if name != clone] == list(a["cells"]) and
            [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "module metadata/order/PLL or exact one-cell/one-net population differs")
    require(all("FES_LABSTATE_V1" not in top["attributes"] and
                all(cell["type"] != "MISTRAL_BUF" and "FES_PINMAP_V1" not in cell["attributes"] for cell in top["cells"].values())
                for top in (a, b)), "predicted graph unexpectedly contains physical snapshots or late buffers")
    old_drivers, old_users = selected.native_tables(a)
    new_drivers, new_users = selected.native_tables(b)
    private, allowed = private_ledger(native, a, b, old_drivers, old_users, new_drivers, new_users)
    private_aliases = {row["alias"] for row in private}
    for name, old in a["netnames"].items():
        if name not in private_aliases:
            require(native.canonical(old) == native.canonical(b["netnames"][name]), "non-private native alias/raw bit/metadata differs: " + name)
    wi, mi, ai, qi = lut(a["cells"][model["inner"]])
    wo, mo, ao, qo = lut(a["cells"][model["outer"]])
    wc, mc, ac, qc = lut(b["cells"][clone])
    wp, mp, ap, qp = lut(a["cells"][old_copy])
    require((wi, wo, wc, wp, mi, mo, mc, mp) == (2, 3, 4, 4, 0xb, 0x32, 0x4440, 0x4440) and
            ao.count(qi) == 1 and len(set(ac)) == len(set(ap)) == 4 and
            set(ac) == set(ap) == set(ai + [bit for bit in ao if bit != qi]) and
            not ({qi, qo, qc, qp} & set(ac)) and len({qi, qo, qc, qp}) == 4 and
            b["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
            a["cells"][old_copy]["attributes"]["NEXTPNR_BEL"] == old_model["bel"] == "MISTRAL_COMB.29.13.0" and
            b["netnames"][alias]["bits"] == [qc], "actual inner/outer/retained/additive composition or placement differs")
    old_attrs, new_attrs = a["cells"][old_copy]["attributes"], b["cells"][clone]["attributes"]
    require(set(old_attrs) == set(new_attrs) and all(old_attrs[key] == new_attrs[key] for key in old_attrs if key != "NEXTPNR_BEL"),
            "additional clone attributes differ beyond its freshly qualified BEL")
    require(set(a["cells"][old_copy]) == set(b["cells"][clone]) and
            native.canonical({key: value for key, value in a["cells"][old_copy].items() if key not in ("attributes", "connections")}) ==
            native.canonical({key: value for key, value in b["cells"][clone].items() if key not in ("attributes", "connections")}) and
            list(a["cells"][old_copy]["connections"]) == list(b["cells"][clone]["connections"]) and
            list(a["cells"][old_copy]["port_directions"]) == list(b["cells"][clone]["port_directions"]) and
            native.canonical({key: value for key, value in a["netnames"][old_copy + "$Q"].items() if key != "bits"}) ==
            native.canonical({key: value for key, value in b["netnames"][alias].items() if key != "bits"}),
            "additional clone/private alias has undeclared metadata or port ordering")
    require(new_drivers.get(qc) == [(clone, "Q", 0, 0)] and
            [name for name, net in b["netnames"].items() if qc in net["bits"]] == [alias] and
            all(qc not in port["bits"] for port in b["ports"].values()), "new clone Q is not a unique private native signal")
    expected_drivers = dict(old_drivers)
    for row in private:
        del expected_drivers[row["old_raw_bit"]]
    require(qc not in expected_drivers and old_drivers[qo] == [(model["outer"], "Q", 0, 0)], "clone overlaps a non-private driver")
    for row in private:
        bit = row["new_raw_bit"]
        require(bit not in expected_drivers and bit != qc, "private owner overlaps another retained/new driver")
        expected_drivers[bit] = [(row["owner"], "Q", 0, 0)]
    expected_drivers[qc] = [(clone, "Q", 0, 0)]
    require(new_drivers == expected_drivers, "complete native driver table differs outside explicit owners/new clone")
    leaves = []
    for index, bit in enumerate(ac):
        require(len(old_drivers.get(bit, [])) == 1 and new_drivers.get(bit) == old_drivers[bit] and
                a["cells"][old_drivers[bit][0][0]]["type"] != "MISTRAL_CONST", "leaf lacks its exact ordinary native driver")
        leaves.append({"clone_port": PINS[index], "raw_bit": bit, "native_driver": list(old_drivers[bit][0])})
    truth = []
    for assignment in range(16):
        values = {bit: (assignment >> index) & 1 for index, bit in enumerate(ac)}
        inner_row = sum(values[bit] << index for index, bit in enumerate(ai))
        inner_value = (mi >> inner_row) & 1
        outer_row = sum((inner_value if bit == qi else values[bit]) << index for index, bit in enumerate(ao))
        retained_row = sum(values[bit] << index for index, bit in enumerate(ap))
        original, retained, added = (mo >> outer_row) & 1, (mp >> retained_row) & 1, (mc >> assignment) & 1
        require(original == retained == added, "conditional original/retained/new function differs")
        truth.append({"assignment": assignment, "inner_row": inner_row, "inner_value": inner_value,
                      "outer_row": outer_row, "retained_copy_row": retained_row,
                      "original_value": original, "retained_value": retained, "additional_value": added})
    require(len(old_users.get(qo, [])) == 109 and len(old_users.get(qp, [])) == 2 and
            old_users[qp] == new_users.get(qp) and native.canonical(a["cells"][old_copy]) == native.canonical(b["cells"][old_copy]),
            "original two-user copy or its exact native consumers changed")
    chosen = new_users.get(qc, [])
    require(chosen and len(chosen) == model["ena_users"] and model["selected_groups"] == 1 and
            chosen == [slot for slot in old_users[qo] if lab(a["cells"][slot[0]]) == model["primary_lab"]],
            "new users are not the entire fresh compatible LAB cohort")
    for slot in old_users[qo] + old_users[qp]:
        cell = a["cells"][slot[0]]
        require(cell["type"] == "MISTRAL_FF" and slot[1:] == ("ENA", 0, 0) and
                cell["port_directions"]["ENA"] == cell["port_directions"]["CLK"] == "input" and scalar(cell, "CLK") == 3549,
                "original ready1 cohort is not the known common-clock FF ENA union")
    require(not set(chosen) & set(old_users[qp]), "additional cohort overlaps the retained copy")
    for slot in chosen:
        require(slot not in allowed, "ENA redirect overlaps a private-output ledger")
        allowed[slot] = {"old_raw_bit": qo, "new_raw_bit": qc, "role": "selected_ff_ena", "owner": clone}
    redirects = []
    for name, old in a["cells"].items():
        new = b["cells"][name]
        left, right = dict(old), dict(new)
        left.pop("connections"); right.pop("connections")
        require(native.canonical(left) == native.canonical(right) and list(old["connections"]) == list(new["connections"]) and
                list(old["port_directions"]) == list(new["port_directions"]), "original metadata/params/BEL/pins/port order differs: " + name)
        for port, bits in old["connections"].items():
            now = new["connections"][port]
            require(type(bits) is list and type(now) is list and len(bits) == len(now), "original port vector shape differs")
            for index, (old_bit, new_bit) in enumerate(zip(bits, now)):
                slot = (name, port, index, 0)
                if old_bit != new_bit:
                    row = allowed.get(slot)
                    require(row is not None and (old_bit, new_bit) == (row["old_raw_bit"], row["new_raw_bit"]),
                            "undeclared original raw connection changed: " + name + "." + port)
                    if row["role"] == "selected_ff_ena":
                        redirects.append({"cell": name, "port": "ENA", "vector_index": 0, "occurrence": 0,
                                          "old_raw_bit": qo, "new_raw_bit": qc, "bel": old["attributes"]["NEXTPNR_BEL"]})
    require({(row["cell"], "ENA", 0, 0) for row in redirects} == set(chosen), "actual ENA redirect ledger differs")
    for bit in set(old_users) | set(new_users) | set(ac):
        expected = list(old_users.get(bit, []))
        for slot, row in allowed.items():
            if row["role"] == "private_output_driver":
                continue
            if row["old_raw_bit"] == bit:
                expected.remove(slot)
            if row["new_raw_bit"] == bit:
                expected.append(slot)
        expected.extend((clone, PINS[index], 0, 0) for index, signal in enumerate(ac) if signal == bit)
        require(sorted(expected) == new_users.get(bit, []), "complete native user/load table differs outside declared named slots")
    members = [{"cell": name, "before": cell, "after": b["cells"][name]} for name, cell in a["cells"].items()
               if cell["type"] == "MISTRAL_FF" and lab(cell) == model["primary_lab"]]
    return {"serialized_native_scope_proved": True, "retained_copy": old_copy, "retained_copy_q": qp,
            "retained_two_consumer_slots": [list(slot) for slot in old_users[qp]], "retained_copy_and_consumers_exact": True,
            "new_clone": clone, "new_private_alias": alias, "clone_q": qc, "original_root_q": qo,
            "declared_ena_redirects": redirects, "declared_ena_redirect_count": len(redirects),
            "original_root_consumers": 109, "remaining_root_consumers": len(new_users.get(qo, [])),
            "explicit_private_output_owners": private, "private_output_owner_count": len(private),
            "declared_original_raw_slot_changes": [{"slot": list(slot), **row} for slot, row in sorted(allowed.items())],
            "new_clone_reuses_only_declared_old_private_bit": qc in {row["old_raw_bit"] for row in private},
            "clone_input_load_slots": leaves, "assignments_checked": 16, "conditional_plain_sig_truth_rows": truth,
            "whole_selected_lab": model["primary_lab"], "whole_selected_lab_original_ff_members": members,
            "all_original_ff_placements_and_nonprivate_raw_slots_exact": True, "exported_common_clock_raw_bit": 3549,
            "pin_assumptions": "Original inner/outer, retained copy and new copy use ordinary PIN_SIG inputs and outputs.",
            "unexported_pin_lab_cache_or_numerical_sta_proved": False}


def compare(self_sha, scope_sha, run_sha):
    native = load(NATIVE, NATIVE_SHA, "additive_ready1_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha),
            (HERE / "source-identity.json", PROFILE_SHA), (HERE / "baseline/run.json", run_sha),
            (HERE / "run_baseline.py", RUNNER_SHA), (HERE / "scope.md", RUNNER_SCOPE_SHA),
            (CONTROL, CONTROL_SHA), (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    runner = load(HERE / "run_baseline.py", RUNNER_SHA, "additive_ready1_runner_pure")
    profile, record, control = (native.read(path) for path in (HERE / "source-identity.json", HERE / "baseline/run.json", CONTROL))
    for path, expected in profile["input_sha256"].items():
        audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    require(control["structural_rejection"] is None and control["fresh_additive_stage_control_prerequisite_proved"] is True and
            control["complete_predicted_report_exact"] is True and profile["control_proof_sha256"] == CONTROL_SHA and
            all(audit.paths.get(ROOT / name) == digest for name, digest in control["artifact_sha256"].items()) and
            all(audit.paths.get(Path(name)) == digest for name, digest in control["execution_file_sha256"].items()),
            "positive original-three control/complete flat closure differs")
    old = native.read(runner.SELECTED / "baseline/run.json")
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel", "partial_outputs_only")) and
            record["source_identity_sha256"] == PROFILE_SHA and
            all(record[key] == value for key, value in profile.items() if key != "input_sha256") and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): PROFILE_SHA} and
            record["execution"] == profile["baseline_execution"] == old["execution"] == control["current_actual_execution"] and
            profile["command"] == runner.command(old) and profile["diagnostic_environment"] == old["diagnostic_environment"] and
            profile["cwd"] == old["cwd"] == str(runner.MODULE) and
            profile["compiler_commit"] == old["compiler_commit"] == runner.COMMIT and profile["delta_base_commit"] == runner.BASE and
            profile["binary_sha256"] == old["binary_sha256"] == runner.BINARY_SHA and
            profile["source_archive_sha256"] == old["source_archive_sha256"] == runner.ARCHIVE_SHA and
            profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            profile["host_validation_sha256"] == runner.HOST_SHA,
            "closed actual four-stage run/profile/selected compiler/runtime differs")
    require(audit.paths.get(runner.SELECTED / "baseline/run.json") == control["current_baseline_run_sha256"] and
            audit.paths.get(runner.GUIDE) == runner.GUIDE_SHA and audit.paths.get(runner.DERIVATION) == runner.DERIVATION_SHA and
            native.read(HERE / "local-plan.json")["steps"] == profile["local_plan_steps"] and
            profile["local_plan_steps"][:3] == old["local_plan_steps"] and
            profile["local_plan_steps"][3] == {"report": str(runner.GUIDE), "candidate": 0, "groups": 1,
                                             "optimize_pins": False, "preserve_ff_placement": True},
            "exact original-three/additional current109 descriptor differs")
    for path, expected in record["execution"]["files"].items():
        audit.bind(Path(path), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")},
            "actual output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "empty actual output")
        audit.bind(Path(path), expected)
    old_log, log = (runner.SELECTED / "baseline/phase.log").read_text(), (HERE / "baseline/phase.log").read_text()
    models = runner.local_qualification(log)
    old_models = control["fresh_local_models"]
    require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
            native.canonical(old_models) == native.canonical(old["actual_selected_local_qualification"]) == native.canonical(profile["retained_local_models"]),
            "actual current/retained log-model records differ")
    selected_exact = [{key: row[key] for key in runner.MODEL_KEYS} for row in models[:3]] == \
                     [{key: row[key] for key in runner.MODEL_KEYS} for row in old_models]
    require(record["original_three_selected_model_fields_exact"] is selected_exact, "selected-model equality diagnostic differs")
    metrics = native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(old_log) and len(native.PLACEMENT_METRICS.findall(log)) == 71
    frozen = load(FREEZE, FREEZE_SHA, "additive_ready1_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "additive_ready1_selected_pure", frozen)
    before, after = native.read_netlist(runner.SELECTED / "baseline/placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    evidence, rejection = None, None
    try:
        require(selected_exact, "original three freshly selected model fields differ")
        require(metrics, "original 71 placement metrics differ")
        evidence = prove(native, selected, before, after, models[3], old_models[1])
    except (ValueError, TypeError, KeyError, IndexError) as error:
        rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(runner.SELECTED / "baseline/timing.json")
    topology = selected.report_topology(after, report, old_report)
    require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and
            report["timing_report_paths"] == 16384 and report["fmax"] == record["actual_predicted_fmax"] and
            "Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...", "LUT driver copy")),
            "actual predicted report/phase role differs")
    audit.finish()
    return {"schema": 1, "phase": "local-multicopy-ready1-additive-conditional-native-prefix", "source_identity_sha256": PROFILE_SHA,
            "current_baseline_run_sha256": run_sha, "control_proof_sha256": CONTROL_SHA,
            "compiler_commit": runner.COMMIT, "delta_base_commit": runner.BASE, "generator_sha256": self_sha, "scope_sha256": scope_sha,
            "candidate_completed": True, "old_local_models": old_models, "fresh_local_models": models,
            "original_three_selected_model_fields_exact": selected_exact, "all_71_placement_metrics_exact": metrics,
            "structural_rejection": rejection, "native_graph_proof_available": rejection is None, "native_graph_evidence": evidence,
            "current_predicted_native_paths": topology, "complete_predicted_report_exact": native.canonical(report) == native.canonical(old_report),
            "fresh_driver_guide_available_after_conditional_prefix_proof": rejection is None,
            "global_raw_bit_translation_or_buffer_normalization_used": False, "independent_physical_equivalence_proved": False,
            "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "run-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    output = HERE / "baseline/comparison-prefix.json"
    require(not output.exists(), "immutable additive comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.run_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
                      "structural_rejection": result["structural_rejection"]}, indent=2))


if __name__ == "__main__":
    main()
