# Additive ready1 remap under the multicopy compiler

Root alone activates this runner. Preparation requires the actual future
--control-sha256 of the closed new-binary comparison-control.json. That
comparison must positively prove the unchanged 14,900/16,638 native module,
original selected models/71 metrics and exact complete predicted report.
Profile75bd, comparatoracb637bc/scope79f023d1 and host98c1 are fixed; an
incomplete or rejected control cannot create this profile or plan.

The control's complete flat artifact/runtime closure and closed current
baseline record are rehashed together with current compiler81243,
binary91a, archivec947, current host46 cases and this new helper/scope.
The exact existing selected executable/archive paths are retained. The
current109 guide428a4af0 and derivation2519b49d are separately bound with
their full flat closure; original paths, real windows, clock terms, native
ports and numerical delays remain untouched. The guide is search
provenance from the accepted report; neither candidate qualification nor
new timing/physical evidence is inherited from that derivation.

The only plan delta appends zero-based stage3: current109 report,
candidate0, groups1, pinsfalse and fixed FF placement. The first three
8/1/1 descriptor values are copied exactly from the current proved
control; the older stage1 report remains selected. The old ready1 copy
model is explicitly retained at COMB29.13.0 with two ENA users. The
additional copy is expected to have the distinct $local_remap$1 name;
its actual site/cohort comes from fresh qualification and is never
assumed to match a prior experiment. The runner records the requirement
that the existing copy and its two users remain untouched. Fresh log
model equality alone does not prove that retention in the new graph;
the independent native-prefix comparison must establish it later.

The invocation changes only the plan/write/report output aliases. All
other command options, seed, device, input RTL/headers/BUILD_ID, stage
order, preceding/later transforms and diagnostic environment remain
those of the current new-binary control. FunctionalInvocation must
capture exactly the control's current actual runtime, including the
same compiler path/hash, controlled environment, libraries, tracer,
machine/kernel/KFD files and GPU device1. It runs through the unchanged
authenticated compiler-read-audit API; the five loaded project Python
module paths/hashes are explicitly checked. No fourth-stage old binary,
recentered replacement, driver-copy stage, GPU route, signoff or RBF is run.

All four stages must freshly qualify/apply candidate0 bound to their
actual final preceding trial, with groups within 8/1/1/1, zero FF shift,
clock/hold/boundary guards and the unchanged minimum250ps predicted gain.
Rejected earlier trial rows are retained. The fourth stage must select
the original ready1 ALUT2→ALUT3 cone. First-three selected model fields
are compared to the proved control as a diagnostic; graph equivalence
is not inferred. The actual predicted report must have cap16384,
15,290 paths and finite positive Fmax fields. Qualification failure
remains an incomplete, explicitly failed record with actual status and
partial output hashes, not an accepted prefix.

prepare/execute are explicit main-guard activation paths with exclusive
new profile/plan/phase outputs. No older helper, generator, authenticator,
test, build or main is invoked. Git subprocesses only read current
source cleanliness, exact HEAD/ancestry/two-file delta. All original
byte paths, source and actual runtime are checked before and after;
the private invocation home is always cleaned up. Successful compiler
completion establishes neither native/Boolean/physical equivalence nor
STA, routing gain, holds, RBF identity or hardware acceptance. Later
prefix proof and fresh driver qualification/full routing are required.
