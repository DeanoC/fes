# Additive ready1 conditional native prefix comparison

Root alone executes this new comparator after the actual four-stage run
closes, supplying its --run-sha256. Profile8678aa88, runner440013e3 and
scopea62cb693 are fixed, together with the positive original-three
controlf3e1f1e8 and its complete flat artifact/runtime closure. Current
compiler81243/binary91a/archivec947/host98c1, all exact input/runtime
paths and the three actual predicted outputs are rehashed. Record/profile
input union, command, current execution and the sole appended current109
guide descriptor must agree. Historical closure files are not represented
as currently loaded build/test libraries. No compiler, helper main,
generator, authenticator, test, build or route is run by this comparator.

Only pure pinned32fd lossless native parsing/Audit, 72131 native table and
report topology functions, its local8601 require module, and the new
runner's command/log parser definitions are used. The runner's preparation,
execution and source-cleanliness subprocess function are never called.
All four fresh compiled local qualifications are bound to the actual log
and record; original three selected model fields and all71 placement
metrics must match the proved control. The fourth model provides its real
chosen BEL, primary LAB and ENA user count; these are not inherited from
an earlier experiment.

The structural branch preserves the complete original14,900-cell and
16,638-net module, settings/attributes/public ports, owner and port order,
lossless paired PLL entries, every original mask/type/parameter/BEL and
all non-private numeric connection/alias fields. The sole population
addition is the ALUT4 named original-outer$local_remap$1 and its private
$Q. The original first copy at COMB29.13.0 and its exact two named ENA
consumers must remain unchanged. The original root has109 remaining
ENA consumers; only the complete fresh selected compatible LAB cohort
may move to the additional copy. All111 original root/first-copy users
must be scalar FF.ENA inputs sharing the exported clock3549; their FF
placements and all other connections remain exact. Complete selected-LAB
FF records are retained for future physical comparison.

The only additional raw-ID permission covers four explicit named private
output owners already characterized by the separate DDR0 prefix:
the retained DDR1 comb remap and decomposition code0/code1/root. Each
image independently must give each owner its unique Q driver, sole exact
private alias, no public boundary and the same full named consumer slots.
Owner metadata, masks, BELs and alias metadata stay exact. Unchanged IDs
are allowed; changed IDs are recorded per owner/slot. There is no global
offset, copied input mutation, general alias alignment or BUF collapse.
A new clone Q can reuse only a released declared private-output number;
it cannot collide with any actual retained driver. Complete raw native
driver and user/load tables are independently reconstructed from these
explicit slots, the selected ENA redirects and four new clone input loads.

The actual inner0xb/outer0x32, retained0x4440 and additional0x4440 tables
are evaluated for all16 assignments of four distinct exact native leaf
drivers. This proves conditional plain-PIN_SIG logical composition only.
Predicted images must not contain physical pin/LAB snapshots or late BUF
cells. Hidden inversions/constants, physical banks/control selectors,
unexported caches, GPU state and numerical STA are not proved.

Even on structural rejection, all15,290 actual current report paths and
seven domain-pair endpoint/window sets are checked through the complete
lossless document and actual emitted cap16384. Current report delays may
change; complete report equality is recorded only as a diagnostic and is
not required. The report is not borrowed from the control, and no windows,
clock terms, delays or paths are invented or altered. Before either result
is published, all bound byte paths are rehashed. Exclusive new
baseline/comparison-prefix.json retains any concrete structural rejection.
No physical equivalence, independently reconstructed STA, routed gain,
hold/signoff, RBF identity or hardware acceptance is claimed. A positive
conditional prefix only makes this fresh actual guide available for the
next driver qualification and full-route experiment.
