"""Record one additive ready1 remap after a proved new-compiler control."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SELECTED = RAW / "local-multicopy-264"
CONTROL = SELECTED / "baseline/comparison-control.json"
CONTROL_HELPER_SHA = "acb637bc0f2e99a9a26adecd6125f35e6eeac0ad2b11a3d5e1d1c72a698feefc"
CONTROL_SCOPE_SHA = "79f023d135f87aa16b19bbd431ece25bedfd7323dd68f3624f67973281cb9c1f"
CONTROL_PROFILE_SHA = "75bdbee671bf186440705bfc4c9f33f2d58318e88569516582060cab50cde59e"
HOST = SELECTED / "validation/host-validation.json"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
COMMIT, BASE = "81243a1300304d7e598156c692be2fcbf2c16268", "5dd69a8ddece6280d576816d2277c73f80607f52"
BINARY, ARCHIVE = SELECTED / "nextpnr-mistral", SELECTED / "source.tar.gz"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-local-multicopy-264"
GUIDE_FOLDER = RAW / "driver-copy-ready-current-guide-264"
GUIDE, DERIVATION = GUIDE_FOLDER / "ready-guide.json", GUIDE_FOLDER / "derivation.json"
GUIDE_SHA = "428a4af08667d939739030c479b35c617c001ae89da357637cfd30b6282cbf74"
DERIVATION_SHA = "2519b49d44c9b6d3721d2c087ce0f8b4836c13e33df8c97a7c119aaff16a1899"
GUIDE_GENERATOR_SHA = "026317bcc0fe2d668451ca0ce65f51f0dc86691547caab460b012e6595fab2c9"
GUIDE_SCOPE_SHA = "54e069c77eba0dbe619f0f7703b6e5168e59fb3e5cef7d80d9a5b398887c1d15"
PROFILE, PLAN, FOLDER = HERE / "source-identity.json", HERE / "local-plan.json", HERE / "baseline"
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}
MODEL_KEYS = ("index", "candidate", "groups_budget", "selected_groups", "inner", "outer", "primary_lab", "bel",
              "ena_users", "gain_ps", "ff_shift", "compiled_clock_hold_boundary_guards_passed")
INNER, OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected), "invalid hash")
    require(path not in inputs or inputs[path] == expected, "conflicting original path identity")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path)
        inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, artifacts, external):
    for name, expected in artifacts.items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in external.items():
        require(Path(name).is_absolute(), "historical external path is not absolute")
        bind(inputs, name, expected)


def clean_source():
    def git(*args):
        return subprocess.run(["git", "-C", str(SOURCE), *args], check=True, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()
    require(git("rev-parse", "HEAD") == COMMIT and not git("status", "--porcelain", "--untracked-files=all") and
            git("merge-base", BASE, COMMIT) == BASE and set(git("diff", "--name-only", BASE, COMMIT).splitlines()) ==
            {"mistral/local_remap.cc", "mistral/tests/remap_plan.cc"}, "selected compiler is not the clean two-file result")


def command(control_run):
    result = list(control_run["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == 1 and
            not any(flag in result for flag in ("--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "control command role differs")
    for flag, path in (("--remap-plan", PLAN), ("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous plan/output selector")
        result[result.index(flag) + 1] = str(path)
    return result


def local_qualification(log):
    budgets = (8, 1, 1, 1)
    headers = list(re.finditer(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, row.groups())) for row in headers] == [(i, 0, budget, 0, 1) for i, budget in enumerate(budgets)], "fresh four-stage headers differ")
    models = []
    for index, header in enumerate(headers):
        block = log[header.end():headers[index + 1].start() if index + 1 < len(headers) else len(log)]
        trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
        choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
        applications = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
        require(trials and len(choices) == len(applications) == 1 and choices[0][1] == applications[0][1] == "0" and
                trials[-1].end() < choices[0].start() < applications[0].start(), "fresh candidate0/application lacks its final trial")
        row, choice = trials[-1].groups(), choices[0].groups()[1:]
        require((row[0], row[1], row[4], row[12], row[7]) == choice and row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and
                1 <= int(row[11]) <= budgets[index] and int(row[7]) >= 250, "fresh fixed-FF/clock/hold/boundary/gain guards differ")
        models.append({"index": index, "candidate": 0, "groups_budget": budgets[index], "selected_groups": int(row[11]),
            "inner": row[0], "outer": row[1], "primary_lab": [int(row[2]), int(row[3])], "bel": row[4],
            "ena_users": int(row[12]), "gain_ps": int(row[7]), "actual_trial_count": len(trials),
            "prior_trial_rows": [x.groups() for x in trials[:-1]], "ff_shift": [0, 0],
            "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False})
    require(models[3]["inner"] == INNER and models[3]["outer"] == OUTER, "fourth stage qualified another cone")
    return models


def prepare(control_sha, self_sha, scope_sha):
    require(not any(path.exists() for path in (PROFILE, PLAN, FOLDER)), "additive profile/plan/outputs already exist")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (CONTROL, control_sha),
            (SELECTED / "source-identity.json", CONTROL_PROFILE_SHA), (HOST, HOST_SHA), (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA),
            (GUIDE, GUIDE_SHA), (DERIVATION, DERIVATION_SHA)):
        bind(inputs, path, expected)
    control, derived = read(CONTROL), read(DERIVATION)
    require(control["phase"] == "local-multicopy-exact-three-stage-native-control" and control["source_identity_sha256"] == CONTROL_PROFILE_SHA and
            control["generator_sha256"] == CONTROL_HELPER_SHA and control["scope_sha256"] == CONTROL_SCOPE_SHA and
            control["compiler_commit"] == COMMIT and control["delta_base_commit"] == BASE and control["structural_rejection"] is None and
            all(control[key] is True for key in ("candidate_completed", "native_graph_proof_available", "complete_predicted_report_exact",
                "fresh_additive_stage_control_prerequisite_proved", "selected_local_model_fields_exact", "all_71_placement_metrics_exact",
                "final_original_path_metadata_and_runtime_hashes_stable")), "actual current control is not proved unchanged with its complete report")
    adopt(inputs, control["artifact_sha256"], control["execution_file_sha256"])
    control_run_path = SELECTED / "baseline/run.json"
    bind(inputs, control_run_path, control["current_baseline_run_sha256"])
    control_run, host = read(control_run_path), read(HOST)
    require(control_run["completed"] is True and control_run["exit_code"] == 0 and control_run["compiler_read_audit_passed"] is True and
            control_run["source_identity_sha256"] == CONTROL_PROFILE_SHA and control_run["compiler_commit"] == COMMIT and
            control_run["binary_sha256"] == BINARY_SHA and control_run["source_archive_sha256"] == ARCHIVE_SHA and
            control_run["execution"] == control["current_actual_execution"] and control_run["cwd"] == str(MODULE) and
            all(inputs.get(path) == expected for path, expected in {**control_run["input_sha256"], **control_run["output_sha256"],
                **control_run["execution"]["files"]}.items()) and
            host["compiler_commit"] == host["result_commit"] == COMMIT and host["binary_sha256"] == BINARY_SHA and
            host["source_archive_sha256"] == ARCHIVE_SHA and host["build_passed"] is host["clean_committed_checkout"] is True,
            "closed current control/source/host/runtime closure differs")
    require(derived["completed"] is True and derived["generator_sha256"] == GUIDE_GENERATOR_SHA and derived["scope_sha256"] == GUIDE_SCOPE_SHA and
            derived["guide_path"] == str(GUIDE) and derived["guide_sha256"] == GUIDE_SHA and
            (derived["paths"], derived["reported_window_violations"], derived["labs"]) == (109, 91, 21) and
            derived["exact_path_objects_and_original_source_order_preserved"] is True and
            derived["clock_terms_locations_nets_sources_windows_or_segment_delays_modified"] is False and
            derived["postdriver_private_path_references_exported"] is False and derived["new_local_or_driver_candidate_qualified"] is False,
            "exact current109 guide derivation differs")
    adopt(inputs, derived["artifact_sha256"], derived["historical_execution_file_sha256_rehashed"])
    require(control_run["command"].count("--remap-plan") == 1, "ambiguous original control plan")
    original_plan = Path(control_run["command"][control_run["command"].index("--remap-plan") + 1])
    require(str(original_plan) in inputs, "original three-stage plan is not bound")
    plan = read(original_plan)
    require(set(plan) == {"steps"} and len(plan["steps"]) == 3 and plan["steps"] == control_run["local_plan_steps"] and
            [step["groups"] for step in plan["steps"]] == [8, 1, 1], "exact current three-stage plan differs")
    retained = control_run["actual_selected_local_qualification"]
    require(retained == control["fresh_local_models"] and len(retained) == 3 and
            retained[1]["inner"] == INNER and retained[1]["outer"] == OUTER and retained[1]["ena_users"] == 2 and
            retained[1]["bel"] == "MISTRAL_COMB.29.13.0", "original two-user first ready1 copy/model differs")
    for name, expected in SCRIPTS.items():
        bind(inputs, MODULE / "scripts" / name, expected)
    fresh = copy.deepcopy(plan)
    fresh["steps"].append({"report": str(GUIDE), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True})
    require(fresh["steps"][:3] == plan["steps"], "original descriptor bytes changed")
    clean_source(); finish(inputs)
    with PLAN.open("x") as stream:
        stream.write(json.dumps(fresh, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, PLAN, sha(PLAN))
    profile = {"schema": 1, "phase": "local-multicopy-ready1-additive-four-stage-predicted-baseline", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA,
        "host_validation_sha256": HOST_SHA, "control_proof_sha256": control_sha, "control_baseline_run_sha256": control["current_baseline_run_sha256"],
        "control_source_identity_sha256": CONTROL_PROFILE_SHA, "guide_sha256": GUIDE_SHA, "guide_derivation_sha256": DERIVATION_SHA,
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "original_plan_path": str(original_plan),
        "original_plan_sha256": inputs[str(original_plan)], "local_plan_sha256": inputs[str(PLAN)], "local_plan_steps": fresh["steps"],
        "authorized_plan_delta": {"append_index": 3, "step": fresh["steps"][3], "original_three_descriptors_exact": True},
        "retained_local_models": retained, "retained_first_ready1_copy_model": retained[1],
        "expected_additional_copy_name": OUTER + "$local_remap$1", "existing_first_copy_and_two_users_must_remain_unchanged": True,
        "command": command(control_run), "cwd": control_run["cwd"], "diagnostic_environment": control_run["diagnostic_environment"],
        "baseline_execution": control_run["execution"], "input_sha256": dict(sorted(inputs.items())),
        "driver_pass_executed": False, "native_graph_or_physical_equivalence_inherited": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source()
    with PROFILE.open("x") as stream:
        stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source()
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "local_plan_sha256": inputs[str(PLAN)]}, indent=2))


def execute(profile_sha):
    inputs = {}
    bind(inputs, PROFILE, profile_sha)
    profile, control_run = read(PROFILE), read(SELECTED / "baseline/run.json")
    require(not FOLDER.exists() and profile["command"] == command(control_run) and profile["baseline_execution"] == control_run["execution"] and
            profile["diagnostic_environment"] == control_run["diagnostic_environment"] and profile["compiler_commit"] == COMMIT,
            "fresh additive profile/command/runtime role differs")
    for path, expected in profile["input_sha256"].items():
        bind(inputs, path, expected)
    require(inputs[str(CONTROL)] == profile["control_proof_sha256"] and inputs[str(HOST)] == HOST_SHA and inputs[str(BINARY)] == BINARY_SHA and
            inputs[str(ARCHIVE)] == ARCHIVE_SHA and inputs[str(SELECTED / "baseline/run.json")] == profile["control_baseline_run_sha256"] and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
            inputs[str(PLAN)] == profile["local_plan_sha256"] and read(PLAN)["steps"] == profile["local_plan_steps"], "frozen current control/helper/plan differs")
    clean_source()
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs,
              "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual current runtime changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"],
                env={**invocation.env, **profile["diagnostic_environment"]}, stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify()
        require(actual.returncode == 0, "fresh additive candidate did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis...", "LUT driver copy")) and
                not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual additive role is not predicted-only")
        record["actual_selected_local_qualification"] = local_qualification(log)
        record["original_three_selected_model_fields_exact"] = [{key: row[key] for key in MODEL_KEYS} for row in record["actual_selected_local_qualification"][:3]] == \
            [{key: row[key] for key in MODEL_KEYS} for row in profile["retained_local_models"]]
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "predicted report cap/count/Fmax differs")
        record["actual_predicted_fmax"], record["output_sha256"] = report["fmax"], {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual predicted output is absent")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source()
        record["completed"] = True
        print(json.dumps({"completed": True, "original_three_selected_model_fields_exact": record["original_three_selected_model_fields_exact"],
                          "actual_fourth_qualification": record["actual_selected_local_qualification"][3], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("control-sha256", "self-sha256", "scope-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(args.control_sha256 and args.self_sha256 and args.scope_sha256, "positive control and helper preparation pins are required")
        prepare(args.control_sha256, args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256, "profile activation pin is required")
        execute(args.profile_sha256)


if __name__ == "__main__":
    main()
