# HPS read-data locality probe (2026-09-29)

Throwaway post-placement move of the bit-48 read capture FF from X25/Y23 to X25/Y56, guided by the saved Quartus fit. Quartus BUILD_ID differs; locality hint only. All 71 HeAP metrics reproduce the accepted reduction candidate. Only the FF and its feed-through LUT differ among all 20115 placed cells. Frozen synthesis, constraints, GPU1/seed2 and compiler reduction/replication options retained. Authenticated full route completed in 735.71s with legal RBF and no final hold warnings.

| Clock | Accepted baseline MHz | Locality probe MHz |
| --- | ---: | ---: |
| memory | 108.944328 | 111.024757 |
| pixel | 95.229019 | 93.650490 |
| capture | 378.582397 | 300.242950 |

Rejected as an accepted stack: pixel/capture regress. Memory critical moves from rd_data_0[48] to rd_data_0[22] at unchanged capture X24/Y24; routing 7.524ns, total9.007ns. One-bit relocation does not solve the bus-level problem.

Saved JSON reroute control is not qualified: packing generates PLL periods/phase relationships and JSON does not preserve them. Its report loses capture and defaults memory to74.25MHz. Routed JSON scaffold reload additionally rejects unused PLL outclk pin-map entries. Physical arc queries trim only absent outclk[0]/outclk[1] entries and require byte-identical reconstructed RBF; their Fmax is never used. HPS read-data analogue query is incomplete, so no complete incoming analogue-delay claim or model calibration. See query run records for supported outgoing FF arc observations.

No production change retained. Compiler source and built binary restored to validated b95ac420 source/c96a0184 binary; FES remains7ce99269 clean. Both probe binaries and patches are archived here. Accepted proof helper now reads the retained binary and archived source bytes, rather than mutable build paths. No RTL, lock, ABI or hardware changes. Next investigate generic report-guided local placement for clocked hard-IP capture endpoints, with actual pin geometry and incoming/outgoing/setup/hold/all-clock checks.
