"""Conditional native proof of one additional port0 burst ENA copy."""
import argparse
import copy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PREVIOUS = RAW / "local-multicopy-ready1-address-stage-264"
OLD = RAW / "local-multicopy-ready1-264"
PROFILE_SHA = "65406398d115457e974639a99e1a962e932853935856166575f2fb250074ea1c"
RUNNER_SHA = "57ec4a9c788d3fbf59f1a5123ee1f197bb967f4390fb4daf9642345aee6b0362"
RUNNER_SCOPE_SHA = "405b30eb0fe6a5af663832195047f2ca93dd4d1a5d0fb1fec0d878c1589d27e0"
PREFIX_SHA = "a7e83fc3c117c614f289a0697e7ee30858d7812704e6324877b56105ab2bc3c9"
PREVIOUS_RUN_SHA = "00c9eba006c6be653c5546f50a3f84412f9641db68e2601bb889115a29f774b8"
OLD_HELPER_SHA = "0a52299ec2c2547dd24407bbad78caa904093ee0514c0c28ea6eda04e1e44744"
COMMIT, BASE = "81243a1300304d7e598156c692be2fcbf2c16268", "5dd69a8ddece6280d576816d2277c73f80607f52"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, expected, name):
    import hashlib
    import importlib.util
    import sys
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def prove(native, selected, old, before_doc, after_doc, profile, models):
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "predicted document schema/creator differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    model = models[5]
    inner, outer = model["inner"], model["outer"]
    retained, clone = outer + "$local_remap", outer + "$local_remap$1"
    alias = clone + "$Q"
    require((inner, outer) == ("hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B") and
            clone == profile["expected_additional_copy_name"] and
            all(name not in a["cells"] and name not in a["netnames"] for name in (clone, alias)) and
            set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and list(a) == list(b) and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (14902, 14903, 16640, 16641) and
            set(b["cells"]) == set(a["cells"]) | {clone} and set(b["netnames"]) == set(a["netnames"]) | {alias} and
            [name for name in b["cells"] if name != clone] == list(a["cells"]) and
            [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports), "exact module/order/PLL/one-cell/one-net population differs")
    require(all("FES_LABSTATE_V1" not in top["attributes"] and
            all(cell["type"] != "MISTRAL_BUF" and "FES_PINMAP_V1" not in cell["attributes"] for cell in top["cells"].values())
            for top in (a, b)), "predicted frame unexpectedly contains physical snapshots or late buffers")
    od, ou = selected.native_tables(a)
    nd, nu = selected.native_tables(b)
    allowed, frames = {}, []
    port1 = "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B$local_remap"
    shifted_copies = [port1 + suffix for suffix in ("$1", "$2")
        if old.scalar(a["cells"][port1 + suffix], "Q") != old.scalar(b["cells"][port1 + suffix], "Q")]
    for owner in (*old.PRIVATE_OWNERS, *shifted_copies):
        named_alias = owner + "$Q"
        old.lut(a["cells"][owner]); old.lut(b["cells"][owner])
        old_bit, new_bit = old.scalar(a["cells"][owner], "Q"), old.scalar(b["cells"][owner], "Q")
        users = ou.get(old_bit)
        require(od.get(old_bit) == nd.get(new_bit) == [(owner, "Q", 0, 0)] and users and users == nu.get(new_bit),
                "declared private owner unique driver/complete named consumers differ: " + owner)
        for top, bit in ((a, old_bit), (b, new_bit)):
            require([name for name, net in top["netnames"].items() if bit in net["bits"]] == [named_alias] and
                    top["netnames"][named_alias]["bits"] == [bit] and all(bit not in p["bits"] for p in top["ports"].values()),
                    "private output sole alias/no-public boundary differs: " + owner)
        left, right = copy.deepcopy(a["netnames"][named_alias]), copy.deepcopy(b["netnames"][named_alias])
        left.pop("bits"); right.pop("bits")
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + owner)
        for slot in [(owner, "Q", 0, 0)] + users:
            require(slot not in allowed and slot[3] == 0 and
                    a["cells"][slot[0]]["connections"][slot[1]][slot[2]] == old_bit and
                    b["cells"][slot[0]]["connections"][slot[1]][slot[2]] == new_bit, "private named slots overlap or differ")
            allowed[slot] = (old_bit, new_bit)
        frames.append({"owner": owner, "alias": named_alias, "old_raw_bit": old_bit, "new_raw_bit": new_bit,
            "raw_bit_changed": old_bit != new_bit, "named_consumer_slots": [list(slot) for slot in users],
            "native_driver": [owner, "Q", 0, 0]})
    require(len({row["old_raw_bit"] for row in frames}) == len({row["new_raw_bit"] for row in frames}) == len(frames) and
            4 <= len(frames) <= 6, "declared private output frames overlap")
    wi, mi, ai, qi = old.lut(a["cells"][inner])
    wo, mo, ao, qo = old.lut(a["cells"][outer])
    wp, mp, ap, qp = old.lut(a["cells"][retained])
    wc, mc, ac, qc = old.lut(b["cells"][clone])
    require((wi, wo, wp, wc, mi, mo, mp, mc) == (2, 3, 4, 4, 0xb, 0x32, 0x4440, 0x4440) and
            ao.count(qi) == 1 and len(set(ac)) == 4 and ac == ap and
            set(ac) == set(ai + [bit for bit in ao if bit != qi]) and not ({qi, qo, qp, qc} & set(ac)) and
            len({qi, qo, qp, qc}) == 4 and b["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
            b["netnames"][alias]["bits"] == [qc] and nd.get(qc) == [(clone, "Q", 0, 0)] and
            [name for name, net in b["netnames"].items() if qc in net["bits"]] == [alias] and
            all(qc not in p["bits"] for p in b["ports"].values()), "actual port0 composition/new private site differs")
    left, right = copy.deepcopy(a["cells"][retained]), copy.deepcopy(b["cells"][clone])
    for cell in (left, right):
        cell["attributes"].pop("NEXTPNR_BEL")
        cell["connections"].pop("Q")
    require(native.canonical(left) == native.canonical(right) and
            list(a["cells"][retained]["connections"]) == list(b["cells"][clone]["connections"]) and
            list(a["cells"][retained]["port_directions"]) == list(b["cells"][clone]["port_directions"]),
            "new copy metadata/input/port order differs beyond its fresh BEL/Q")
    left, right = dict(a["netnames"][retained + "$Q"]), dict(b["netnames"][alias])
    left.pop("bits"); right.pop("bits")
    require(native.canonical(left) == native.canonical(right), "new private alias metadata differs")
    retained_rows, retained_outputs, retained_slots = profile["retained_copy_cohorts"], [], set()
    require(len(retained_rows) == 5 and len({row["cell"] for row in retained_rows}) == 5, "five retained owner declarations differ")
    for row, earlier in zip(retained_rows, models[:5]):
        name, cell = row["cell"], a["cells"][row["cell"]]
        before_q, after_q = old.scalar(cell, "Q"), old.scalar(b["cells"][name], "Q")
        slots = sorted(tuple(slot) for slot in row["consumer_slots"])
        require(native.canonical(cell) == native.canonical(row["record"]) and cell["attributes"]["NEXTPNR_BEL"] == earlier["bel"] and
                ou.get(before_q) == nu.get(after_q) == slots and len(slots) == earlier["ena_users"] and
                not retained_slots & set(slots) and name.startswith(earlier["outer"] + "$local_remap"),
                "retained copy record/fresh model/complete consumers differ: " + name)
        if name not in shifted_copies:
            require(before_q == after_q and native.canonical(cell) == native.canonical(b["cells"][name]), "retained literal copy differs: " + name)
        retained_slots.update(slots)
        retained_outputs.append({"cell": name, "before_raw_bit": before_q, "after_raw_bit": after_q,
            "consumer_slots": [list(slot) for slot in slots]})
    require(next(row for row in retained_rows if row["cell"] == retained)["consumer_slots"] == [list(slot) for slot in ou[qp]] and
            len(ou[qp]) == 10, "retained port0 ten-user cohort differs")
    chosen = nu.get(qc, [])
    declared = sorted((row["cell"], row["port"], row["vector_index"], row["occurrence"]) for row in profile["declared_ena_cohort"])
    group = sorted(slot for slot in ou.get(qo, []) if old.lab(a["cells"][slot[0]]) == model["primary_lab"])
    require(model["primary_lab"] == [34, 30] and model["selected_groups"] == model["ena_users"] == 1 and
            len(ou.get(qo, [])) == 172 and len(nu.get(qo, [])) == 171 and chosen == group == declared ==
            [("hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_6", "ENA", 0, 0)] and
            sorted(slot for slot in ou[qo] if slot not in chosen) == nu[qo] and not set(chosen) & retained_slots,
            "original172→171/sixth1/retained five cohorts differ")
    for slot in ou[qo] + list(retained_slots):
        cell = a["cells"][slot[0]]
        require(slot[1:] == ("ENA", 0, 0) and cell["type"] == "MISTRAL_FF" and old.scalar(cell, "CLK") == 3549,
                "original ready union is not a common-clock scalar FF ENA cohort")
    redirects = []
    for slot in chosen:
        require(slot not in allowed and old.scalar(a["cells"][slot[0]], "ENA") == qo and
                old.scalar(b["cells"][slot[0]], "ENA") == qc, "declared sixth ENA slot overlaps or differs")
        declaration = profile["declared_ena_cohort"][0]
        require(native.canonical(a["cells"][slot[0]]) == native.canonical(declaration["before_record"]) and
                declaration["old_raw_bit"] == qo and declaration["clock_raw_bit"] == 3549 and
                declaration["bel"] == a["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"] == "MISTRAL_FF.34.30.32",
                "predeclared target FF record/clock/BEL differs")
        allowed[slot] = (qo, qc)
        redirects.append({"cell": slot[0], "port": "ENA", "vector_index": 0, "occurrence": 0,
            "old_raw_bit": qo, "new_raw_bit": qc, "bel": declaration["bel"]})
    truth, leaves = [], []
    for i, bit in enumerate(ac):
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit) and a["cells"][od[bit][0][0]]["type"] != "MISTRAL_CONST",
                "ready boundary lacks a unique unchanged ordinary driver")
        leaves.append({"port": old.PINS[i], "raw_bit": bit, "native_driver": list(od[bit][0])})
    for assignment in range(16):
        values = {bit: (assignment >> i) & 1 for i, bit in enumerate(ac)}
        iv = (mi >> sum(values[bit] << i for i, bit in enumerate(ai))) & 1
        original = (mo >> sum((iv if bit == qi else values[bit]) << i for i, bit in enumerate(ao))) & 1
        first = (mp >> sum(values[bit] << i for i, bit in enumerate(ap))) & 1
        new = (mc >> assignment) & 1
        require(original == first == new, "conditional original/retained/new port0 function differs")
        truth.append({"assignment": assignment, "original": original, "retained_first": first, "additional": new})
    expected_drivers = dict(od)
    for row in frames: del expected_drivers[row["old_raw_bit"]]
    require(qc not in expected_drivers, "new output overlaps an undeclared retained driver")
    for row in frames:
        bit = row["new_raw_bit"]
        require(bit not in expected_drivers and bit != qc, "private output frames overlap another retained/new owner")
        expected_drivers[bit] = [(row["owner"], "Q", 0, 0)]
    expected_drivers[qc] = [(clone, "Q", 0, 0)]
    require(nd == expected_drivers, "complete native driver table differs beyond named frames/new copy")
    expected_users = {}
    for bit, slots in ou.items():
        for slot in slots: expected_users.setdefault(allowed[slot][1] if slot in allowed else bit, []).append(slot)
    for i, bit in enumerate(ac): expected_users.setdefault(bit, []).append((clone, old.PINS[i], 0, 0))
    require(nu == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete users differ beyond named slots/four new input loads")
    for name, cell in a["cells"].items():
        expected = copy.deepcopy(cell)
        for port, bits in expected["connections"].items():
            for index, bit in enumerate(bits):
                slot = (name, port, index, 0)
                if slot in allowed:
                    require(allowed[slot][0] == bit, "original named slot bit differs")
                    bits[index] = allowed[slot][1]
        require(native.canonical(expected) == native.canonical(b["cells"][name]) and
                list(cell["connections"]) == list(b["cells"][name]["connections"]) and
                list(cell["port_directions"]) == list(b["cells"][name]["port_directions"]), "original cell metadata/BEL/order/undeclared raw slot differs: " + name)
    private_aliases = {row["alias"]: row for row in frames}
    for name, net in a["netnames"].items():
        expected = copy.deepcopy(net)
        if name in private_aliases: expected["bits"] = [private_aliases[name]["new_raw_bit"]]
        require(native.canonical(expected) == native.canonical(b["netnames"][name]), "original alias/raw bits/metadata differs: " + name)
    ff_bels = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ff_bels) == 8221 and ff_bels == profile["all_original_ff_bel_manifest"], "complete8221 FF BEL declaration differs")
    declared_labs = {tuple(lab) for lab in profile["declared_whole_labs"]}
    known_members = sorted(({"cell": name, "record": cell} for name, cell in a["cells"].items()
        if cell["type"] == "MISTRAL_FF" and tuple(old.lab(cell)) in declared_labs), key=lambda row: row["cell"])
    require(native.canonical(known_members) == native.canonical(profile["original_ffs_in_declared_labs"]), "predeclared whole-LAB FF records differ")
    selected_lab = old.lab(b["cells"][clone])
    members = sorted(({"cell": name, "record": cell} for name, cell in a["cells"].items()
        if cell["type"] == "MISTRAL_FF" and old.lab(cell) == selected_lab), key=lambda row: row["cell"])
    return {"serialized_native_scope_proved": True, "inner": inner, "outer": outer, "new_clone": clone,
        "new_private_alias": alias, "actual_clone_q": qc, "original_root_q": qo,
        "declared_ena_redirects": redirects, "declared_ena_redirect_count": 1,
        "retained_copy_cohorts": retained_rows, "actual_retained_copy_output_rows": retained_outputs,
        "retained_port0_copy": retained, "retained_port0_copy_consumers": [list(slot) for slot in ou[qp]],
        "original_root_users_before": 172, "original_root_users_after": 171,
        "explicit_private_output_owners": frames, "private_output_owner_count": len(frames),
        "shifted_existing_port1_copy_owners": shifted_copies,
        "actual_new_output_reuses_only_declared_old_private_bit": qc not in od or qc in {row["old_raw_bit"] for row in frames},
        "whole_selected_lab": selected_lab, "original_ffs_in_selected_lab": members,
        "whole_selected_lab_native_ff_count": len(members), "predeclared_whole_labs": profile["declared_whole_labs"],
        "conditional_boundary": leaves, "assignments_checked": 16, "conditional_plain_sig_truth_rows": truth,
        "all_original_ff_placements_and_nonprivate_raw_slots_exact": True, "complete_native_driver_and_user_tables_proved": True,
        "original_export_order_and_paired_pll_records_exact": True,
        "physical_pins_lab_cache_gpu_or_independent_sta_proved": False}


def comparison(args):
    require(not (HERE / "baseline/comparison-prefix.json").exists(), "prefix comparison output already exists")
    native = load(PURE, PURE_SHA, "port0_prefix_native")
    audit = native.Audit()
    for path, expected in ((PURE, PURE_SHA), (Path(__file__), args.self_sha256), (HERE / "comparison-scope.md", args.scope_sha256),
            (HERE / "run_baseline.py", RUNNER_SHA), (HERE / "scope.md", RUNNER_SCOPE_SHA), (HERE / "source-identity.json", PROFILE_SHA),
            (HERE / "baseline/run.json", args.run_sha256), (PREVIOUS / "baseline/comparison-prefix.json", PREFIX_SHA),
            (PREVIOUS / "baseline/run.json", PREVIOUS_RUN_SHA), (OLD / "compare_prefix.py", OLD_HELPER_SHA)):
        audit.bind(path, expected)
    runner = load(HERE / "run_baseline.py", RUNNER_SHA, "port0_prefix_current_runner_defs")
    profile, record = native.read(HERE / "source-identity.json"), native.read(HERE / "baseline/run.json")
    previous_proof, previous = native.read(PREVIOUS / "baseline/comparison-prefix.json"), native.read(PREVIOUS / "baseline/run.json")
    for name, expected in previous_proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in previous_proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        audit.bind(Path(name), expected, execution=True)
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    require(previous_proof["structural_rejection"] is None and previous_proof["native_graph_proof_available"] is True and
            previous_proof["compiler_commit"] == COMMIT and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            profile["phase"] == "local-multicopy-port0-burst-sixth-stage-predicted-baseline" and
            profile["previous_prefix_proof_sha256"] == PREFIX_SHA and profile["previous_baseline_run_sha256"] == PREVIOUS_RUN_SHA and
            profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            profile["binary_sha256"] == runner.BINARY_SHA and profile["source_archive_sha256"] == runner.ARCHIVE_SHA and
            profile["host_validation_sha256"] == runner.HOST_SHA and profile["control_proof_sha256"] == runner.CONTROL_SHA,
            "positive prior prefix/current compiler/profile roles differ")
    for key, value in profile.items():
        if key != "input_sha256": require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["source_identity_sha256"] == PROFILE_SHA and record["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): PROFILE_SHA} and
            record["command"] == runner.command(previous) and record["execution"] == profile["baseline_execution"] == previous["execution"] and
            record["diagnostic_environment"] == previous["diagnostic_environment"] and record["cwd"] == previous["cwd"] and
            record["original_five_selected_models_exact"] is True, "closed fresh six-stage record/current runtime differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is outside frozen closure")
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")}, "complete predicted output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output empty")
        audit.bind(Path(name), expected)
    for path, expected in ((runner.SELECTED, runner.SELECTED_SHA), (runner.FREEZE, runner.FREEZE_SHA),
            (PREVIOUS / "run_baseline.py", runner.LOCAL_SHA), (runner.FOUR_PARSER, runner.FOUR_PARSER_SHA)):
        require(audit.paths.get(path) == expected, "pure dependency is not in frozen closure")
    frozen = runner.load(runner.FREEZE, runner.FREEZE_SHA, "port0_prefix_freeze")
    selected = runner.load(runner.SELECTED, runner.SELECTED_SHA, "port0_prefix_tables", frozen)
    old = runner.load(OLD / "compare_prefix.py", OLD_HELPER_SHA, "port0_prefix_old_pure_lut_defs")
    log = (HERE / "baseline/phase.log").read_text()
    five_parser = runner.load(PREVIOUS / "run_baseline.py", runner.LOCAL_SHA, "port0_prefix_five_log_parser")
    four_parser = runner.load(runner.FOUR_PARSER, runner.FOUR_PARSER_SHA, "port0_prefix_four_log_parser")
    models = runner.qualification(log, five_parser, four_parser)
    require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
            native.canonical(models[:5]) == native.canonical(previous["actual_selected_local_qualification"]) == native.canonical(profile["retained_local_models"]),
            "actual fresh six/retained five log models differ")
    placement_exact = native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall((PREVIOUS / "baseline/phase.log").read_text())
    before, after = native.read_netlist(PREVIOUS / "baseline/placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(PREVIOUS / "baseline/timing.json")
    topology = selected.report_topology(after, report, old_report)
    require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and
            report["fmax"] == record["actual_predicted_fmax"], "current complete native report topology/count/Fmax differs")
    evidence, rejection = None, None
    try:
        require(placement_exact, "original71 placement metric sequence differs")
        evidence = prove(native, selected, old, before, after, profile, models)
    except (ValueError, KeyError, TypeError, IndexError, AttributeError, StopIteration) as error:
        rejection = str(error)
    audit.finish()
    return {"schema": 1, "phase": "local-multicopy-port0-burst-sixth-stage-bounded-native-prefix",
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "source_identity_sha256": PROFILE_SHA,
        "current_baseline_run_sha256": args.run_sha256, "previous_prefix_proof_sha256": PREFIX_SHA,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256,
        "candidate_completed": True, "structural_rejection": rejection, "native_graph_proof_available": rejection is None,
        "fresh_driver_guide_available_after_conditional_prefix_proof": rejection is None,
        "native_graph_evidence": evidence, "fresh_local_models": models, "previous_local_models": models[:5],
        "all_71_placement_metrics_exact": placement_exact, "current_complete_native_report_topology": topology,
        "actual_predicted_fmax": report["fmax"], "complete_predicted_report_exact_required": False,
        "conditional_plain_sig_equivalence_only": True, "physical_pin_lab_cache_gpu_or_sta_acceptance_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "run-sha256"): parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    import json
    with (HERE / "baseline/comparison-prefix.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_graph_proof_available")}, indent=2))


if __name__ == "__main__":
    main()
