# Generic internal LUT cut experiment

The optional compiler change is committed and pushed as `664599e39086d89104a0eeeaa44f192038f88ae6` on `experiment/mistral-comb-cut-remap-264`, based on `2019b389e9aaaa2b28ec7ea2dd96a61e8511a51c`. All nine frozen source files match the commit.

The generic method composes two or three ordinary LUTs with at most six distinct external signals, prunes nonessential variables, and clones the result into one legal nearby LUT. It redirects one internal downstream LUT input, preserves the original shared graph, validates continuous current report paths, and applies only with modeled input improvement of at least 250 ps plus endpoint, boundary, clock, hold and legality guards. It is disabled by default and does not match RAM-test names or coordinates.

Validation: 23 pure/backend tests and 12 CLI tests passed; independent reviews found no correctness blocker. Disabled-option JSON-loader modules hash matches the retained control exactly. Both fresh full GPU1 routes used the same fixed BUILD_ID, synthesis artifact, constraints, seed and retained compiler stack. Both preserve all 71 placement metrics, all 8,221 original FFs and 6,509 original LUT BELs/parameters/pin states, all original FF connections, and 106 unselected shared-root consumers. The selected three-LUT function equals the ALUT5 `0x70205000` clone for all 32 input rows. No buffers were added or removed. No final reported hold violations; HIP routing, complete timing reports and RBFs authenticated. Detailed comparisons were regenerated after final commit metadata and passed.

| Trial | Memory MHz | Pixel MHz | Phase MHz | Decision |
| --- | ---: | ---: | ---: | --- |
| Retained experimental control | 115.380180 | 93.580383 | 307.631805 | Retain |
| Internal cut alone | 113.726822 | 93.274887 | 378.582397 | Reject as overall gain |
| Internal cut plus earlier ready clone | 115.300354 | 92.841888 | 305.033325 | Reject as overall gain |
| Internal cut plus ready clone, four groups | 114.064102 | 94.652161 | 378.582397 | Reject as overall gain |
| Internal cut plus ready clone, eight groups | 114.012085 | 92.747177 | 378.582397 | Reject as overall gain |

The cut stacks structurally with the earlier ready clone, all 60 capture moves, sixteen-input preplacement reduction and eleven-input placed reduction. Compared with the old ready-only 113.778595 MHz route, the combination recovers 1.521759 MHz and improves all eight selected downstream arrivals by 303–554 ps. Compared with the retained 115 control, the selected worst endpoint improves 171 ps but another worsens 76 ps; global and other-clock nonregression gates fail. The new memory critical path is HPS ready through the original ALUT2/ALUT4 to address[3].ENA at LAB(24,12), 8.673 ns. These arrivals and sites are diagnostic observations, not compiler matching rules.

Best experimental memory remains 115.380 MHz; strict accepted control remains 108.944 MHz. The 130 MHz constraint is unresolved. Neither candidate changes producer selection, RTL, recipes, compiler locks, ABI or hardware. No PR was opened; hardware acceptance was not performed.

The broader group trials used this same frozen compiler and unchanged fixed inputs. Four groups redirected eleven ENA users; eight groups redirected twenty-one. Complete whole-LAB and Boolean checks passed; all original FF/LUT placements, pins and parameters and the other accepted transforms remain identical. Neither trial reports a final hold violation. Four groups expose ready1 through the retained two-LUT skid enable to skid_burstcount[4].ENA; eight groups instead expose DDR0 idle[16] to address[21].ENA. Both fail global memory and all-clock nonregression. They are rejected as overall gains.

Next investigation: a generic staged-remap plan can combine the separate address-command and skid enable roots in one fresh placement while preserving every original FF BEL. The implementation is in progress on a separate experimental branch, with preloaded reports, strict current-path validation and failure before routing. The private 24-literal comparator remains a separate generic mapping target; see placed24-plan.md. Minor future cleanup: use full ordered node names for deterministic tie-breaking among equally ranked internal cuts.
