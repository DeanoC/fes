"""Fresh full route of the frozen generic internal-cut experiment."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / 'sources/misteross'
RAW = HERE.parent
sys.path.insert(0,str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation
from scripts.search_placer_qor import _score_report, has_failed_route_arc
from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate',type=int,default=0)
parser.add_argument('--stack-ready',action='store_true')
parser.add_argument('--ready-groups',type=int,default=1,choices=range(1,9))
args = parser.parse_args()
assert args.candidate >= 0
assert args.stack_ready or args.ready_groups == 1
control = RAW / 'placed-reduction-root-slack/route-local-r6-s0'
previous = json.loads((control / 'run.json').read_text())
assert previous['completed'] and previous['exit_code'] == 0
for filename,digest in previous['input_sha256'].items(): assert sha(Path(filename)) == digest
freeze = json.loads((HERE / 'source-identity.json').read_text())
binary = HERE / 'nextpnr-mistral'
archive = HERE / 'source.tar.gz'
assert sha(binary) == freeze['binary_sha256'] and sha(archive) == freeze['source_archive_sha256']
identity = f"base_commit={freeze['base_commit']}; experimental_source_sha256={sha(archive)}; sha256={sha(binary)}"
source = Path(previous['command'][previous['command'].index('--json')+1])
qsf = MODULE / 'cores/fes-ramtest/constraints.qsf'
sdc = MODULE / 'boards/de10nano/clocks.sdc'
capture_report = RAW / 'route-slots-final/timing.json'
guide = RAW / 'ready-remap-264/route-g1-c0/timing.json'
guide_run = json.loads((guide.parent / 'run.json').read_text())
assert guide_run['completed'] and guide_run['exit_code'] == 0
guide_comparison = guide.parent / 'comparison.json'
trusted = json.loads(guide_comparison.read_text())['artifact_sha256']
for artifact in (guide, guide.parent / 'run.json', control / 'run.json', control / 'timing.json', capture_report):
    assert sha(artifact) == trusted[str(artifact.relative_to(ROOT))]
suffix = ('-ready' if args.stack_ready else '')
if args.ready_groups != 1: suffix += f'-g{args.ready_groups}'
output = HERE / (f'route-c{args.candidate}' + suffix)
output.mkdir(exist_ok=False)
invocation = FunctionalInvocation({'nextpnr-mistral':board.AuthenticatedTool(binary,identity)},1)
cmd = [str(binary),'--json',str(source),'--device','5CSEBA6U23I7','--qsf',str(qsf),'--sdc',str(sdc),
       '--freq','74.25','--seed','2','--placer-heap-timingweight','10','--placer-heap-critexp','2',
       '--router','gpu','--replicate-enables','4','--timing-allow-fail','--detailed-timing-report',
       '--balance-reduction-root','ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT6_F_E_MISTRAL_ALUT5_Q_1',
       '--remap-comb-critical',str(guide),'--remap-comb-candidate',str(args.candidate),
       '--write',str(output / 'routed.json'),'--report',str(output / 'timing.json'),
       '--rbf',str(output / 'core.rbf'),'--compress-rbf','--gpu-device','1']
inputs = [binary,archive,source,qsf,sdc,capture_report,guide,guide.parent / 'run.json',
          guide_comparison,control / 'run.json']
if args.stack_ready:
    ready_report = control / 'timing.json'
    cmd += ['--remap-critical',str(ready_report),'--remap-candidate','0','--remap-groups',str(args.ready_groups)]
    inputs.append(ready_report)
env = dict(invocation.env)
env['NEXTPNR_MISTRAL_CAPTURE_LOCALITY'] = previous['experimental_capture_locality']
env['NEXTPNR_MISTRAL_PLACED_REDUCTION'] = previous['experimental_placed_reduction']
record = {'kind':'scratch full route; no producer/package selection','command':cmd,'cwd':str(MODULE),
          'tool_identity':identity,'base_compiler_commit':freeze['base_commit'],
          'compiler_commit':freeze.get('result_commit',freeze['base_commit']+'+comb-remap-experiment'),
          'build_id':previous['build_id'],'execution':invocation.inputs,'completed':False,
          'control_run_sha256':sha(control / 'run.json'),'input_sha256':{str(p):sha(p) for p in inputs},
          'source_archive_sha256':sha(archive),'experimental_capture_locality':env['NEXTPNR_MISTRAL_CAPTURE_LOCALITY'],
          'experimental_placed_reduction':env['NEXTPNR_MISTRAL_PLACED_REDUCTION'],
          'comb_report_sha256':sha(guide),'comb_candidate':args.candidate,'stack_ready':args.stack_ready,
          'remap_groups':args.ready_groups if args.stack_ready else 0,'remap_candidate':0 if args.stack_ready else None,
          'capture_report_sha256':sha(capture_report)}
manifest = output / 'run.json'
manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
start = time.monotonic()
try:
    with (output / 'route.log').open('w') as log:
        result = audited_run(cmd,source_root=MODULE,cwd=MODULE,env=env,stdout=log,
                             stderr=subprocess.STDOUT,check=False,timeout=2400)
    record['exit_code'] = result.returncode
    record['elapsed_seconds'] = time.monotonic()-start
    invocation.verify()
    for filename,digest in record['input_sha256'].items(): assert sha(Path(filename)) == digest
    log = (output / 'route.log').read_text()
    assert result.returncode == 0 and 'Info: Program finished normally.' in log and not has_failed_route_arc(log)
    board._require_gpu_backend(log)
    assert (output / 'core.rbf').stat().st_size > 0 and 'Running signoff timing analysis...' in log
    record['final_reported_hold_violations'] = 'Hold/min time violation' in log.rsplit('Running signoff timing analysis...',1)[1]
    report = json.loads((output / 'timing.json').read_text())
    _score_report(report,REQUIRED_CLOCKS)
    assert set(report['fmax']) == {name for name,_ in REQUIRED_CLOCKS}
    record['fmax'] = report['fmax']; record['completed'] = True
    print(json.dumps({'elapsed_seconds':record['elapsed_seconds'],'fmax':record['fmax'],
                      'final_reported_hold_violations':record['final_reported_hold_violations']},indent=2),flush=True)
except BaseException as exc:
    record['failure'] = repr(exc)
    raise
finally:
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    invocation.close()
