# Existing broader ready-group experiments and next priorities

Read-only assessment against the completed `route-c0-ready` and frozen 115.380
route. No compiler edits, builds, routes, or hardware actions were performed.
This ignored note is the only file added for this assessment. Root owns the
budget-4 then budget-8 GPU trials, using the frozen comb-cut compiler
`664599e39086d89104a0eeeaa44f192038f88ae6` and unchanged functional inputs.

## Evidence identity and the current limiting group

The completed `comb-remap-264/route-c0-ready/comparison.json` authenticates all
five input artifacts below; their current SHA256 digests match its
`artifact_sha256` entries.

| Artifact | SHA256 |
| --- | --- |
| `route-c0-ready/run.json` | `46fbb05ae42571e622c2d6b8ea439f406b97da609d1f21fd9814f9bfe57a0bbd` |
| `route-c0-ready/timing.json` | `db7332482d678c30aab2330277647dac9d75bcd51fd83d22ccdb1437ff973722` |
| `route-c0-ready/routed.json` | `cac90345e341bd6730b72d7e7a05abce688b14ef45cfa9d96d86869580a252ea` |
| frozen115 `timing.json` | `2e301287ab5109ffae6f4ed801d94a9f5fd68923adb3031596fd54692ea2b4f4` |
| frozen115 `routed.json` | `12b2b6e334d38ea113918d0c1800853cc77f1e6d6fbbf3a91d05b2d7b09b016e` |

The frozen115 artifacts are under
`placed-reduction-root-slack/route-local-r6-s0`. The frozen comb-cut binary hash
is `7c60d4a5e4a763fec35ab4c3ed77f50e8fe7486a17b72843321cd9dfd3f19a52`;
its source archive hash is
`c6107f8f5936452de9457180d63da6fbfc523330c0bfda60e1383aabbca126b2`.

Current memory Fmax is 115.300354 MHz versus 115.380180 MHz for frozen115. The
complete setup path is 8.673 ns versus 8.667 ns: a 6 ps regression at a different
uncloned endpoint. Current pixel/capture Fmax are 92.841888/305.033325 MHz, both
above their nominal constraints but below the corresponding frozen115 values.
These are completed route measurements, not modeled forecasts.

The current memory path is:

```
cmd_ready_1 -> original ALUT2 at (33,19)
            -> original ALUT4 at (25,19)
            -> m1_address_MISTRAL_FF_Q_3.ENA at (24,12)
```

Its delay is 0.209 ns clock skew + 1.177 ns clock-to-Q + 4.137 ns first route +
0.400 ns logic + 0.966 ns route + 0.400 ns logic + 1.580 ns last route -
0.196 ns setup = 8.673 ns. The hard-IP-to-first-LUT route remains the dominant
single segment. A broader group budget rewires FF ENA consumers and leaves this
original shared two-LUT path available to unselected groups.

Address3 shares LAB `(24,12)` with address16/21/24/26. Those five FFs all consume
the same original ready root and form one whole group. This means all five must
be selected together; unrelated FFs sharing that LAB are outside the group.
The original ready root has 109 FF ENA users in 22 LABs. Current budget1 rewires
only address14/18 at `(24,13)`, leaving 107 users on the original root.

## Cross-check of the static selection order

In `mistral/local_remap.cc`, secondary groups are sorted by their minimum fresh
placed-model ENA setup slack, then LAB coordinates. The group budget includes
the primary LAB. Each secondary group must pass whole-group legality and every
endpoint must improve by at least 250 ps. Final complete STA, clock Fmax, hold,
and hard-input boundary checks can still reject the candidate.

All 8,221 original FF BELs match frozen115 in the completed current route. All
original LUT types, parameters, and BELs also match. This supports using the
same ready-cone geometry for the forecast; the intended comb-cut input rewire
and ready FF ENA rewires are separate logical changes.

The primary candidate remains ALUT5 at `(25,13)`, shift `(0,0)`, with logged
model gain 1,117 ps. Its output-route improvement to the primary LAB is 850 ps,
so the inferred shared root-arrival improvement is 267 ps. Model routing is
300 ps within a LAB; otherwise `650 + (dy ? 250 : 0) + 35*dx + 100*dy` ps.
FF ENA setup is uniform, and this local STA leaves clock-skew analysis disabled.
Thus the relative old-root route delays reproduce the secondary ordering.
This is a forecast for the same candidate, not a guarantee that a live trial
accepts every group.

| Secondary rank | LAB | FF users, suffixes of `hps_ddr.m1_*_MISTRAL_FF_Q` | Users | Predicted gain | First budget reaching it |
| --- | --- | --- | --- | --- | --- |
| primary | `(24,13)` | address14/18 | 2 | 1,117 ps | 1 |
| 1 | `(30,13)` | burstcount6/7 | 2 | 1,117 ps | 2 |
| 2 | `(29,13)` | burstcount1/4 | 2 | 1,117 ps | 3 |
| 3 | `(24,12)` | address3/16/21/24/26 | 5 | 867 ps | 4 |
| 4 | `(23,14)` | address5 | 1 | 667 ps | 5 |
| 5 | `(29,15)` | burstcount5 | 1 | 467 ps | 6 |
| 6 | `(24,14)` | address2/12/13/27/28, burstcount3 | 6 | 667 ps | 7 |
| 7 | `(23,15)` | address11/17 | 2 | 467 ps | 8 |
| 8 | `(25,15)` | address1/20 | 2 | 467 ps | 9, outside existing cap |
| 9 | `(25,16)` | address4/6/15/19/22, burstcount, writedata20/61 | 8 | 267 ps | 10, outside existing cap |

Budget4 therefore predicts 11 selected ENA users, including the current
address3 group. Budget8 predicts 21 selected users, including address17's group.
The model cap is eight groups, so the last two qualifying LABs remain outside
this particular candidate's accepted budget even though their modeled gain is
positive. Budget2 would have selected the first burstcount group rather than
the address17 group. This confirms the previous turn's ranking.

Secondary groups are never moved. The primary group's Q nets feed hard-IP
inputs, which disables primary movement here as well. Neither trial should
change any FF BEL. Existing backend tests cover budget2 whole-group selection
with a preserved inverted ENA and unchanged secondary BELs, plus budget8 list
mode exact-index rollback. They do not substitute for these full-route trials.

## Which unselected paths to inspect next

The following arrivals come from the current route's `detailed_net_timings`.
They include launch-clock travel and do not subtract each endpoint's capture
clock delay. They provide an endpoint shortlist, not setup-slack ordering,
predicted Fmax, or proof of the critical launch source. Rerouting broader fanout
can also change them, and newly selected clone paths remain candidates for the
next worst path.

After the expected budget4 selections, the largest remaining arrivals in the
original m1 ready family are:

| LAB | Remaining family | Current maximum arrival |
| --- | --- | --- |
| `(23,14)` | address5 ENA | 9.998 ns |
| `(24,14)` | address2/12/13/27/28 and burstcount3 ENA | 9.945 ns |
| `(29,15)` | burstcount5 ENA | 9.912 ns |
| `(23,15)` | address11/17 ENA | 9.780 ns |

After the expected budget8 selections, the largest remaining m1 ready arrivals
are address1/20 at `(25,15)` (9.731 ns), the mixed address/burst/writedata group
at `(25,16)` (9.691 ns), byteenable7 at `(25,22)` (9.687 ns), writedata26 at
`(30,18)` (9.682 ns), and writedata18/3/35/50 at `(29,21)` (9.677 ns). Most
of the latter write/byteenable groups would not improve by 250 ps from the
current clone site; adding fanout blindly is not supported by the model gates.

Other roots remain untouched by either group budget. The following shortlist
was independently cross-checked by the evidence review agent:

| Direct endpoint family | Current maximum arrival | Representative endpoint / LAB | Direct FF endpoints |
| --- | --- | --- | --- |
| port0 skid ENA from `port0.slot_free_MISTRAL_ALUT3_B` | 10.121 ns | skid_burstcount6 / `(34,30)` | 182 |
| port1 skid ENA from `port1.slot_free_MISTRAL_ALUT3_B` | 10.034 ns | skid_byteenable7/3 / `(27,21)` | 111 |
| DDR0 expected DATAIN | 10.006 ns | expected13 / `(22,22)` | 1 for this terminal root |
| DDR0 cmd_end DATAIN | 9.985 ns | cmd_end / `(34,27)` | 1 |
| port0 m0 ENA from `port0.slot_free_MISTRAL_ALUT4_C` | 9.971 ns | address27/16 / `(34,24)` | 180 |
| DDR1 address ENA from its cmd_end ALUT3 | 9.967 ns | address18/16 / `(21,20)` | 29 |
| DDR1 beats_left ENA from pass_end | 9.713 ns | beats_left6 / `(25,33)` | 8 |

For comparison, frozen115 arrivals at the first three representative endpoints
are 10.079, 9.952, and 9.060 ns. The large DDR0 expected13 change is a reminder
that routing perturbations can expose a different family despite unchanged
FF/LUT placement and parameters. The DDR1 beats_left6 arrival is lower than
the 10.263 ns observed in the preceding standalone ready clone route; the cut
improves that particular measured arrival without guaranteeing global gain.

## Existing generic support and recommended next scope

The port0 and port1 skid roots are ALUT3 `0x32`. Their ready input is ALUT2
`0xb`. Composing those final two LUTs uses four distinct essential inputs:
ready, valid, enter_read Q, and enter_write Q. In that signal order the composed
mask is `0x4440`. Thus the existing generic local remapper can represent this
branch without a compiler change if a finalized relevant critical report
actually selects that final pair and all runtime guards qualify. Their
enter_write ALUT2 branch also gives a four-input pair. Their enter_read ALUT5
branch has seven structural inputs with the outer LUT and is rejected by the
existing six-input bound. The critical launch branch must therefore be checked.

The frozen115 port0 m0 root also has five-input ready/enter_write pairs, and the
DDR1 address cmd_end ALUT3 has a four-input inner ALUT2 pair. Conversely, the
DDR0 expected13 DATAIN endpoint is outside the existing FF ENA-only local
remapper's terminal selection. These are support observations, not candidate
qualification; no synthetic guide, list run, or trial was made here.

The immediate priority is to finish and authenticate the existing budget4/8
full routes, prove their actual whole-LAB sink sets and identical FF BELs, and
compare complete clock-aware critical paths plus all clocks and hold signoff.
If budget8 transfers the limit to a skid family, inspect that finalized path's
last pair before proposing further compiler work. If the path still ends at an
unselected m1 group, assess the newly measured route and guide before changing
placement or increasing a budget. A higher group count alone is not a timing
guarantee.

One invocation applies one qualified local composition. The group budget
expands consumers of that one original output; it cannot optimize a separate
skid or m0 root at the same time. A later experiment targeting another root
must explicitly account for retention or replacement of the current ready
clone. Report names/locations/edges also have to match the graph at the hook;
using a report containing an already-created clone on a fresh graph can be
stale. Keep these as generic selection/guard questions, not hard-IP-specific
compiler rules. The placed24 comparator proposal remains a separate fallback
when a finalized DDR1 path actually becomes limiting.

## Port1 skid final-pair guidance if it becomes critical

Use the finalized, authenticated budget8 timing report only if its actual
violated memory setup path ends at a skid FF ENA and traverses a supported final
pair. Do not manufacture a path from the raw-arrival shortlist. The current
collector accepts every violated FF ENA path in its report without hard-IP
names, deduplicates by the two LUTs and sink LAB, and validates all reported
ports, locations and routing edges against the graph at the hook. A report
path containing an earlier transient clone cannot be assumed valid on a fresh
graph; the retained original skid LUTs and FFs do match the current fresh
placement. The primary LAB comes from the report's actual sink.

The expected ready-branch final routing edges are the original slot_free
ALUT2 Q at `(33,19)` -> skid ALUT3 B at `(27,16)` -> selected skid FF ENA. The
alternative write branch is enter_write ALUT2 Q at `(33,12)` -> the same ALUT3
C -> FF ENA. Both pairs satisfy the structural four-input bound. The ready
pair has mask `0x4440` in order `[cmd_ready, cmd_valid_Q, enter_read_Q,
enter_write_Q]`. The write pair has mask `0x00fe` in order `[write_input_A,
write_input_B, enter_read_Q, slot_free_Q]`. All four inputs are essential in
each table. These orders explain truth equivalence, not a hardcoded pin policy.
Runtime net, placement, clock, full-model and polarity guards remain required.

If the report selects skid_byteenable7 or skid_byteenable3 at `(27,21)`, its
primary group is exactly those two FFs. The root drives 111 FF ENAs across
22 LABs; group budget1 isolates these two consumers and preserves the other
109 on the original root. Each selected FF Q feeds a separate m1_byteenable
ALUT3 mux in the same `(27,21)` LAB. That makes this a small first target with
local output geometry worth preserving. Other currently prominent primary
groups are seven skid_writedata FFs at `(29,20)` and two skid_burstcount FFs at
`(29,12)`; the actual report should determine the choice.

The clone search stays within Manhattan radius3 of the selected primary LAB.
The ready pair retains external drivers at `(52,53)`, `(33,19)`, `(31,12)` and
`(33,12)`. The write pair retains its two write-input drivers at `(31,12)`, plus
enter_read Q at `(31,12)` and slot_free Q at `(33,19)`. Moving a clone toward
the byteenable sinks consequently changes input geometry as well as its short
output routes; fresh complete STA must qualify the tradeoff.

Unlike the m1 address target, the selected skid FF Q nets have ordinary fabric
consumers. The existing `may_move` guard therefore permits the primary skid
group to shift one LAB. Existing flags do not themselves force its FF BELs to
remain fixed. To preserve the two local mux connections, inspect qualified
trial/list output, choose a candidate explicitly logged with `shift=0,0`, and
verify exact FF BEL equality in routed evidence. Candidate zero is not assumed
to have that property. There is no existing explicit no-movement flag in this
path; a fixed-placement experiment must fail its evidence check if it moves
FFs. Secondary groups, if subsequently added, remain fixed by the code.

Keep the original inner and outer LUTs and every unselected connection. The
scalar `port1.skid_MISTRAL_FF_Q` at `(36,21)` is outside this root's ENA group;
its SCLR remains driven by the original slot_free ALUT2, and its 116-user Q
feedback network remains intact. Its dependencies through enter_read and the
output muxes are preserved rather than recomputed in place. A zero-shift clone
changes only the selected FF ENA function's physical implementation: it adds
no state or pipeline stage and preserves all feedback truth assignments.

An eventual skid-target invocation still applies only one local composition.
It does not automatically retain the current separate m1 ready clone. Decide
and prove that stacking scope before claiming the prior broader-ready gains
are preserved. No compiler or helper change is proposed or performed here.
