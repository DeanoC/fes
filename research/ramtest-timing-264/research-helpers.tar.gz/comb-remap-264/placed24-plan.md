# Optional placed 24-literal conjunction reduction

Read-only implementation proposal. FES base is
`7ce9926941a5f72cc3ca4b0ed61b7b06e76e5304`. Source inspection covers
`mistral/placed_reduction.cc`, `reduction_balance.cc`, the reduction plan/policy,
and the established generic remap guards. No compiler edits, builds or routes
were performed for this proposal. This note is the only new file.

This is a possible next experiment after the current internal-cut routes. Root
reports that standalone comb candidate zero completed at 113.7268 MHz with an
original HPS-ready path worst; the run stacking the previous ready clone is still
pending. Those are root-provided progress facts, not newly authenticated evidence
from this assessment. A comparator rewrite cannot by itself guarantee improvement
of a different ready path.

## Verified target in the frozen 115.380 graph

Artifact: `placed-reduction-root-slack/route-local-r6-s0/routed.json`, SHA256
`12b2b6e334d38ea113918d0c1800853cc77f1e6d6fbbf3a91d05b2d7b09b016e`.

The root is
`ddr1_test.pass_end_MISTRAL_ALUT5_D_1_Q_MISTRAL_ALUT3_Q`, ALUT3 `0x80` at
`MISTRAL_MCOMB.34.16.30`. Its exclusive cone contains seven LUTs, 24 distinct
external FF Q inputs and three logic levels. Three eight-bit branches each use
ALUT4 then ALUT5. All six intermediate outputs have one internal consumer and
no top-level observation. Every one of the 30 cone input nets (24 external plus
six internal) has exactly one cone input consumer slot. The root has eight
ordinary-LUT consumers in this control; implementation must preserve whatever
complete root-user set exists in the actual current context, including any
earlier experimental clone.

Recursive unique-row recognition proves **idle == 24'd1000000 (`0x0f4240`)**.
Required high bits are 6, 9, 14, 16, 17, 18 and 19; the other 17 bits are low.
The existing logical-cone fingerprint, excluding BELs/physical maps/JSON bit IDs,
is `3e23bfe7ba716ab6e25d7195c9be510b322273db383401a4d61dfbbd81f99853`.
See `ready-remap-264/next-remap-design.md` for its canonical serialization.

Twenty source FFs are in LAB `(37,16)` and four are in `(42,16)`. The existing root
ALM has no opposite LUT: its only other occupant is the unrelated
`ddr2_address_MISTRAL_FF_Q_22` at z32. A fixed-site change from ALUT3 to ALUT4 is
therefore a credible candidate, subject to full ALM/LAB legality.

Two original ALUT5 sites, `(39,16,42)` and `(34,16,48)`, share their ALM with an
unrelated ALUT2/ALUT3. Other original child sites share ALMs with source FFs using
fabric DATAIN. These sites are not automatically legal for ALUT6. Post-route
feedthrough BUFs are also not fresh-placement occupants. Only enumeration of real
BELs and live legality checks can establish available ALUT6 sites; an empty JSON
tile does not establish that a physical LAB exists.

## Bounded scope and default behavior

Add a separate explicit placed-only shape/mode for exactly seven ordinary LUTs
and exactly 24 distinct literals. Preserve the existing three-LUT/11 and
four-LUT/16 behavior and their call sites. The new mode must not be enabled by
serialized settings or by existing `--balance-reduction-root` calls. An explicit
root/radius/candidate option or diagnostic hook can enable it; default is off,
list is nonmutating, and an unqualified requested index must stop before routing.

Run it after ordinary full-design HeAP placement and the retained control stack.
For this experiment, append it after the current capture64/r24 and placed11/r6/c0
hooks, so the earlier sixteen-input balancing, enable-replication budget four,
optional ready remap, capture moves and existing placed11 prefix remain intact.
Reject packed-only/no-place/cart/scaffold modes and any routed design. The
effective placer check belongs in `Arch::place()` as well as CLI parsing.

Implementation must remain generic: no DDR/HPS names, comparator value, pin masks
or coordinates in recognition, rewriting or search. The named root is an explicit
experiment input, not a matching rule.

Merely adding seven/24 recognition is insufficient:

- `plan_reduction()` currently caps traversal at four cells and accepts only
  three/four-cell cones.
- `rewrite_reduction()` assumes every nonroot cell remains an active leaf. Its
  shape selection and root width are fixed to two/three children.
- `placed_reduction()` requires three cells, two site lists and two root inputs.
- Its endpoint collector rejects completed repeated net visits, so the known
  benign downstream reconvergence would still reject this target.

## Boolean plan and graph contract

Extend the pure cube recognizer through an explicit shape request. Continue
recursive recognition of a unique satisfying row for the polarity requested by
the parent, propagate logical input inversion, reject duplicate external signal
identities, cycles, repeated internal nodes, missing nodes and noncube functions.
Do not flatten the 24-input function into a uint64_t mask or use the six-input
generic cut composer. A list of 24 `(source, required_value)` literals is the
complete proof; at most 64 local rows per node are inspected. No exhaustive
2^24 loop is needed.

The active replacement is four ALUT6 leaves and an ALUT4 root. Each leaf receives
six distinct literals. Its logical table has one true row, with those six
required values encoded in the mask; polarity is absorbed into the table and all
new input pin states are `PIN_SIG`. The root table is `0x8000` and ANDs the four
positive leaf outputs. This has five active LUTs and two levels, with no added
FFs, latency, state assumptions or output inversion.

The plan needs explicit `active_leaves` and `retired_cells` rather than deriving
all children from `plan.cells`. Reuse four of the six private cells and retain
the original root object, root Q net, driver and every root-output user slot.
A deterministic initial identity choice is the three old direct root children
plus one old grandchild, ordered by existing root pins and then lexical cell
name. This can preserve the original three root-input net identities while
adding a fourth. Leaf cell names do not constrain their candidate placement.
Do not multiply the first search by all fifteen choices of four survivors.

For the new wiring, reuse the 24 external live user slots and the four selected
private Q-net slots, replacing the PortRef in each slot. Remove exactly the two
unused internal slots. The selected four Q nets become the root's four inputs.
All external source side users and all root output users retain their exact
indices. This avoids a disconnect/reconnect sequence changing their free-list or
traversal order.

Keep the two surplus cell objects available during trials, unbound and with their
old input edges removed, so list/invalid-index rollback needs no cell-dictionary
reinsertion. They have no observable output consumers. Only after final
qualification retire them, clear their Q drivers and remove their cell entries.
For an initial conservative implementation, keep their now-empty private NetInfo
objects and aliases rather than deleting alias targets; these nets have no
driver or users and cannot be functional observations. If removing private nets
as well, explicitly remove/restore every alias targeting them and test that path.
No unplaced surplus cells may survive into routing.

## Guards before mutation or timing analysis

Use live graph checks, not routed JSON assumptions. Require weak movable bound
cells, no cluster/region/pseudo/keep/dont-touch, ordinary ALUT2..6, `PIN_SIG` Q,
one fully defined numeric LUT property of exactly 2^width bits, supported logical
input pin states and correct driver/port/user-slot relationships. Bound the
upstream traversal to seven cells and reject all nonroot external consumers and
top-level observations. For every net reject routes, globals, clock constraints,
regions, protection attributes, constants/undriven inputs and implicit clock
consumers. Treat hard/I/O data boundaries conservatively: either reject them or
require the same modeled, physically mapped, constrained timing checks already
used by the generic remapper. All 24 actual sources here are ordinary FF Qs.

Build protected LABs for strong/clustered/region/pseudo/protected occupants and
MLABs; retain full arithmetic/shared-ALM checks. Reject protected original cone
LABs and prospective destinations. No unrelated cell may move or change type,
parameters, ports or pin state.

Downstream structural preflight from root Q should use unseen/active/completed
states: active repeat means cycle; completed repeat means safe reconvergence.
Keep a bounded net count (64 suffices for the observed roughly 31-net closure),
ordinary/protected/boundary checks, valid downstream LUT tables and timing-class
checks. Stop only at supported modeled register inputs; reject clocks and
unsupported hard boundaries. Collect all endpoint keys before constructing STA.
The observed closure has 283 distinct FF inputs (278 ENA, five DATAIN). This is a
dynamic set to validate in the current context, not a hardcoded count.

## Local search after placement

Fix the root BEL and strength. After rewriting, bind the ALUT4 root at its original
site and reject if it or any affected neighbor cannot be legal. Search the four
ALUT6 leaves within Manhattan radius three of the original cone LABs initially;
an explicit bounded radius up to six can widen a later experiment. Do not run
HeAP again or evict/move any unrelated occupant.

Use two deterministic partitions at most: the existing bus/name literal order in
chunks of six, and a source-location order in chunks of six with name ties. The
latter naturally groups the actual 20 colocated FFs and four more distant FFs.
Any partition has the same conjunction proof. If pin ordering is optimized, use
the existing bounded mask-permutation helper and include actual logical source
arrival when practical; any approximate ranking still requires full STA gates.

For each leaf enumerate actual type-compatible free BELs, bind it temporarily,
check both ALM halves and every bound neighbor in the LAB, then unbind it. Rank by
worst input arrival plus predicted source-to-leaf route, cell delay and leaf-to-
fixed-root route/root arc. Keep at most 24 sites per leaf with ALM/LAB diversity;
include the old site if it is genuinely legal. Different BELs in one ALM cannot
hold two ALUT6 leaves. Root's ALM also cannot hold an ALUT6 leaf.

Avoid 24^4 full timing trials. Use a deterministic beam of at most 64 partial
placements, binding each proposed next leaf and rejecting joint ALM/LAB/control/
input-count illegality immediately. Rank complete states by the worst branch
score with coordinates and partition index as stable ties. Time at most 16 fully
legal complete placements, retaining spatial diversity in the four-LAB tuples.
Check all affected original/destination LAB occupants and then full-design
legality before a state can qualify.

## Timing gates, rollback and evidence

Take one fresh baseline TimingAnalyser after structural preflight and before
mutation. Require finite modeled root-output and endpoint setup slacks. Preserve
the existing root-branch metric: root Q setup slack must improve by at least
250 ps, while every reachable endpoint setup slack is nonregressing. Another
fanin can dominate an endpoint and hide the improved branch, so endpoint minimum
gain alone is not the objective. Every constrained clock must remain present and
have nonregressing predicted Fmax, and all hold violations must satisfy the
existing hold-nonregression gate. Include modeled external hard-data boundary
slacks if such inputs were permitted. Approximate source/leaf scores never replace
these gates.

Snapshot all seven cells' identities, types, complete ports, LUT properties,
pin_data, BELs/strengths; all 30 input nets' complete indexed_store values; the
retired output drivers and any modified alias state; and all unrelated placements.
Root Q users must be asserted untouched. Rejected states/list/invalid-index must
unbind active leaves/root, restore cell structures and net stores exactly, assign
ArchInfo, restore original BELs/strengths and run ctx->check(). Check future
allocation indices on copies of restored stores, not only live users. Keep graph
mutation once per partition and restore a canonical snapshot before another
partition; do not swap already-swapped snapshots twice without reinitializing.

Only a selected qualified state may retire the two surplus cells. Finish cleanup,
assert all remaining cells placed, all unrelated placements intact, root users
intact and full legality, then ctx->check(). Full routing and final all-clock/hold
evidence are still required; no predicted or partial-route result is acceptance.

Focused tests should cover seven-node mixed-polarity unique-row proof, alias/
contradiction/noncube/bounds rejection, leaf bit63 and root mask construction,
unobservable-intermediate guard failures, downstream reconvergence/cycles before
STA, root ALUT4 and four-leaf joint legality, positive qualification, and repeated
list/invalid-index rollback with indexed-store holes. Applied tests should check
retirement of exactly two private cells, no dangling drivers/aliases, all root
consumer slots, all unrelated cells/placements, and every external assignment in
small analogous fixtures plus compositional proof for the actual 24 literals.

Evidence should authenticate the frozen compiler/source and unchanged synthesis/
QSF/SDC/execution identity, compare the retained stack/prefix, record the partition
and four final BELs, prove the literal set and five-cell result, and compare final
Fmax/hold against both the 115.380 control and the applicable ready/comb route.
The saved 4.076 ns comparator prefix comes from the 113.779 ready route, not the
exact old 115.380 path. Routing can expose a different limiting branch. This
proposal changes no RTL, shared contract, producer selection or hardware status.
