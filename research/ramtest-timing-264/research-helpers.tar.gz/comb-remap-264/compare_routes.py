#!/usr/bin/env python3
"""Authenticate an experimental internal-edge combinational remap.

Run after the root-owned runner finalizes run.json. The selected cut is read
from the actual new LUT input connection and proved over every external input
assignment. This writes comparison.json only; it does not build, route or load.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
READY_HELPER = RAW / "ready-remap-264/compare_routes.py"
spec = importlib.util.spec_from_file_location("ready_remap_evidence", READY_HELPER)
ready = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ready)
previous = ready.previous
require, read, sha, relative = ready.require, ready.read, ready.sha, ready.relative
BASE = ready.BASE
CONTROL = ready.CONTROL
READY_CONTROL = ready.HERE / "route-g1-c0"
PIN_CONTROL = ready.HERE / "route-g1-c0-pins"
PIN_SOURCE = ready.PIN_ORDER
GUIDE_REPORT = READY_CONTROL / "timing.json"
COMB_READY_G1 = HERE / "route-c0-ready"
MEMORY_CLOCK = ready.MEMORY_CLOCK
REQUIRED_CLOCKS = ready.REQUIRED_CLOCKS
SOURCE_BASE = "2019b389e9aaaa2b28ec7ea2dd96a61e8511a51c"


class Netlist(ready.Netlist):
    """Apply the exported logical pin states as well as LUT parameters."""
    def __init__(self, cells):
        super().__init__(cells)
        self.direct_users = {}
        for name, cell in cells.items():
            for port, direction in cell["port_directions"].items():
                if direction != "input":
                    continue
                for index, bit in enumerate(cell["connections"][port]):
                    driver = self.drivers.get(bit)
                    if driver is not None:
                        self.direct_users.setdefault(driver, []).append((name, port, index))
        self.direct_users = {driver: sorted(users) for driver, users in self.direct_users.items()}

    def pin_states(self, name):
        payload = self.cells[name]["attributes"].get("FES_PINMAP_V1")
        if not payload:
            return {pin: 0 for pin in self.cells[name]["port_directions"]}
        snapshot = json.loads(bytes.fromhex(payload).decode())
        pins = snapshot["pins"]
        require(snapshot["count"] == len(pins) and all(
            isinstance(data, list) and data and data[0] in (0, 1, 2, 3) for data in pins.values()),
            f"invalid logical pin snapshot: {name}")
        return {pin: data[0] for pin, data in pins.items()}

    def lut_inputs(self, name):
        cell = self.cells[name]
        require(ready.is_lut(cell), f"not a Boolean LUT: {name}")
        states = self.pin_states(name)
        result = []
        for pin in "ABCDEF"[:int(cell["type"].removeprefix("MISTRAL_ALUT"))]:
            state = states.get(pin, 0)
            if state in (1, 2):
                require(not cell["connections"].get(pin), f"constant pin also has a signal: {name}.{pin}")
                result.append(("constant", state - 1))
            else:
                require(len(cell["connections"].get(pin, [])) == 1, f"missing Boolean pin: {name}.{pin}")
                result.append(self.token(cell["connections"][pin][0]))
        return result

    def expression(self, token, leaves, visited, stack=frozenset()):
        if token[0] == "constant":
            return token
        if token in leaves:
            return ("variable", token)
        require(token not in stack and len(token) == 3 and token[0] in self.cells,
                f"cyclic or unmatched retained cut input: {token}")
        name, port, index = token
        cell = self.cells[name]
        states = self.pin_states(name)
        require(ready.is_lut(cell) and port == "Q" and index == 0 and states.get("Q", 0) == 0,
                f"invalid retained cut output: {token}")
        visited.add(name)
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        mask = int(cell["parameters"]["LUT"], 2)
        inversions = sum((states.get(pin, 0) == 3) << i for i, pin in enumerate("ABCDEF"[:width]))
        effective = sum(((mask >> (row ^ inversions)) & 1) << row for row in range(1 << width))
        return ("lut", effective,
                [self.expression(t, leaves, visited, stack | {token}) for t in self.lut_inputs(name)])


def fixed_command(command):
    ignored_values = {"--write", "--report", "--rbf", "--remap-critical", "--remap-candidate", "--remap-groups",
                      "--remap-comb-critical", "--remap-comb-candidate"}
    fixed, index = [], 1
    while index < len(command):
        if command[index] in ignored_values:
            index += 2
        elif command[index] == "--remap-optimize-pins":
            index += 1
        else:
            fixed.append(command[index])
            index += 1
    return fixed


def ready_group_budget(record):
    stacked = "--remap-critical" in record["command"]
    budget = int(ready.argument(record["command"], "--remap-groups")) if stacked else 0
    require(not stacked or 1 <= budget <= 8, "ready group budget is outside the frozen compiler's 1..8 range")
    for key in ("ready_groups", "remap_groups", "ready_remap_groups", "remap_group_budget", "ready_group_budget"):
        if key in record:
            require(type(record[key]) is int and record[key] == budget, "ready group budget record disagrees with command")
    for key in ("ready_candidate", "remap_candidate", "ready_remap_candidate"):
        if key in record:
            require(stacked and record[key] == int(ready.argument(record["command"], "--remap-candidate")),
                    "ready candidate record disagrees with command")
    return budget


def structural_reference(record):
    if "--remap-critical" not in record["command"]:
        require("--remap-optimize-pins" not in record["command"], "pin-order requested without the ready remap")
        return CONTROL
    require(ready.argument(record["command"], "--remap-critical") == str(CONTROL / "timing.json"),
            "stacked ready remap must use its frozen 115.380 report")
    require(ready.argument(record["command"], "--remap-candidate") == "0", "stacked ready candidate changed")
    ready_group_budget(record)
    require(record["input_sha256"].get(str(CONTROL / "timing.json")) == sha(CONTROL / "timing.json"),
            "stacked ready report is not authenticated")
    return PIN_CONTROL if "--remap-optimize-pins" in record["command"] else READY_CONTROL


def authenticate_compiler(record):
    binary = Path(record["command"][0])
    require(binary == HERE / "nextpnr-mistral", "candidate must use the frozen comb-remap compiler")
    source = previous.source_identity(HERE, record)
    parent_record = read(PIN_CONTROL / "run.json")
    parent_source = previous.source_identity(PIN_SOURCE, parent_record)
    require(source["base_commit"] == SOURCE_BASE == parent_source["result_commit"],
            "comb-remap compiler base is not the authenticated 2019b389 compiler")
    fields = dict(part.strip().split("=", 1) for part in record["tool_identity"].split(";") if "=" in part)
    require(fields.get("base_commit") == source["base_commit"] and
            fields.get("experimental_source_sha256") == source["archive_sha256"] and
            fields.get("sha256") == source["binary_sha256"], "compiler identity text disagrees with the freeze")
    archive = HERE / "source.tar.gz"
    require(record["source_archive_sha256"] == record["input_sha256"].get(str(archive)) == sha(archive),
            "comb-remap source archive is not authenticated")
    if record.get("base_compiler_commit"):
        require(record["base_compiler_commit"] == source["base_commit"], "recorded compiler base changed")
    result = source.get("result_commit")
    result_recorded = isinstance(result, str) and previous.re.fullmatch(r"[0-9a-f]{40}", result) is not None
    if result_recorded:
        require(record.get("compiler_commit") == result, "recorded compiler result changed")
    return {**source, "freeze_path": relative(HERE), "result_commit_recorded": result_recorded}, parent_source


def logic_path(report):
    path = next(p for p in report["critical_paths"] if p["from"] == p["to"] == "posedge " + MEMORY_CLOCK)
    cells = {step["from"]["cell"] for step in path["path"] if step["type"] == "logic"}
    require(len(cells) >= 3, "the frozen comb guidance contains no bounded internal LUT cut")
    return path, cells


def selected_candidate(log, candidate):
    pattern = previous.re.compile(
        r"^Info: Comb remap candidate (\d+): root=(\S+) sink=(\S+)\.([ABCDEF]) cut=([23]) -> (\S+), predicted gain ([\d.]+)ps\.$",
        previous.re.M)
    found = [match for match in pattern.finditer(log) if int(match[1]) == candidate]
    require(len(found) == 1 and f"Comb remap applied candidate {candidate};" in log,
            "the selected comb candidate was not uniquely reported and applied")
    match = found[0]
    trial_prefix = (f"Info: Comb remap trial root={match[2]} sink={match[3]}.{match[4]} "
                    f"cut={match[5]} bel={match[6]} gain={match[7]}ps ")
    trials = [line for line in log.splitlines() if line == trial_prefix +
              "endpoints=1 clocks=1 hold=1 boundaries=1"]
    require(len(trials) == 1 and float(match[7]) >= 250,
            "the selected placement trial does not satisfy all modeled timing gates")
    return {"candidate": candidate, "root": match[2], "sink": match[3], "port": match[4],
            "cut_lut_count": int(match[5]), "bel": match[6], "predicted_gain_ps": float(match[7]),
            "candidate_log": match[0], "qualified_trial_log": trials[0],
            "placement_endpoints_clocks_holds_boundaries_passed": True}


def recover_cut(old, edge, report, plan=None):
    """Recover the exact original report-edge cut before inspecting pruning."""
    paths = report["critical_paths"] if "critical_paths" in report else [report]
    found = {}
    for path in paths:
        if not path["path"] or sum(s["delay"] for s in path["path"]) <= path["max_delay"]:
            continue
        last = path["path"][-1]
        if last["type"] != "setup" or last["to"]["port"] not in ("ENA", "DATAIN") or \
                old.cells[last["to"]["cell"]]["type"] != "MISTRAL_FF":
            continue
        edges = [(step["from"], step["to"]) for step in path["path"] if step["type"] == "routing"]
        for end, (_, sink) in enumerate(edges):
            if sink["cell"] != edge["sink"] or sink["port"] != edge["port"]:
                continue
            for length in (3, 2):
                if end + 1 < length or (plan and plan["cut_lut_count"] != length):
                    continue
                selected_edges = edges[end + 1 - length:end + 1]
                nodes = [source["cell"] for source, _ in selected_edges]
                if len(set(nodes)) != length or edge["sink"] in nodes:
                    continue
                if any(source["port"] != "Q" or source["cell"] not in old.cells or
                       not ready.is_lut(old.cells[source["cell"]]) for source, _ in selected_edges):
                    continue
                if any(selected_edges[i][1]["cell"] != nodes[i + 1] for i in range(length - 1)):
                    continue
                if any(old.inputs(target["cell"]).get(target["port"]) != [(source["cell"], "Q", 0)]
                       for source, target in selected_edges):
                    continue
                if tuple(edge["control_driver"]) != (nodes[-1], "Q", 0):
                    continue
                if plan and (plan["root"] != nodes[-1] or plan["sink"] != edge["sink"] or plan["port"] != edge["port"]):
                    continue
                found[tuple(nodes)] = path
    require(len(found) == 1, "the selected two-or-three-LUT report cut is not uniquely recoverable")
    nodes, path = next(iter(found.items()))
    node_set = set(nodes)
    raw_inputs = []
    for index, name in enumerate(nodes):
        for token in old.lut_inputs(name):
            if len(token) == 3 and token[0] in node_set:
                require(token[1:] == ("Q", 0) and nodes.index(token[0]) < index,
                        "report cut contains a non-topological internal dependency")
            elif token not in raw_inputs:
                raw_inputs.append(token)
    external = set(raw_inputs) - {("constant", 0), ("constant", 1)}
    require(len(external) <= 6 and all(t[0] != "undriven" for t in external),
            "original raw cut exceeds six external variables or has an undriven input")
    return nodes, raw_inputs, external, path


def consumers(netlist, token, original_names):
    result = []
    for name in sorted(original_names):
        if netlist.cells[name]["type"] == "MISTRAL_BUF":
            continue
        for port, tokens in netlist.inputs(name).items():
            for index, current in enumerate(tokens):
                if current == token:
                    result.append((name, port, index))
    return sorted(result)


def cell_lab(cell):
    coordinates = previous.bel(cell).rsplit(".", 3)
    require(len(coordinates) == 4 and all(value.isdigit() for value in coordinates[1:]), "invalid exported cell BEL")
    return tuple(map(int, coordinates[1:3]))


def discover_ready_reference(baseline_cells, reference_cells):
    """Discover and independently prove the authenticated group-1 ready clone."""
    old, reference = Netlist(baseline_cells), Netlist(reference_cells)
    added = set(reference_cells) - set(baseline_cells)
    require(len(added) == 1 and not (set(baseline_cells) - set(reference_cells)),
            "group-1 ready reference must retain every cell and add one clone")
    clone = added.pop()
    require(ready.is_lut(reference_cells[clone]), "group-1 ready addition is not a Boolean clone")
    selected = []
    for name, cell in baseline_cells.items():
        current = reference_cells[name]
        require(cell["type"] == current["type"] and cell["parameters"] == current["parameters"] and
                previous.bel(cell) == previous.bel(current) and old.pin_states(name) == reference.pin_states(name),
                f"group-1 ready reference changed an original cell: {name}")
        a, b = old.inputs(name), reference.inputs(name)
        require(set(a) == set(b), f"group-1 ready input-port set changed: {name}")
        for port in a:
            if a[port] == b[port]:
                continue
            require(cell["type"] == "MISTRAL_FF" and port == "ENA" and len(a[port]) == len(b[port]) == 1 and
                    b[port] == [(clone, "Q", 0)], f"invalid group-1 ready rewire: {name}.{port}")
            selected.append({"ff": name, "bel": previous.bel(current), "control_driver": a[port][0],
                             "candidate_driver": b[port][0]})
    require(selected and len({tuple(row["control_driver"]) for row in selected}) == 1,
            "group-1 ready clone does not replace one original shared root")
    proof = ready.prove_clone(old, reference, clone, selected)
    require(proof["assignments_checked"] == 32 and old.pin_states(proof["control_root"][0]).get("Q", 0) == 0 and
            all(reference.pin_states(clone).get(pin, 0) == 0 for pin in "ABCDEF"[:len(reference.lut_inputs(clone))] + "Q"),
            "group-1 ready function or pin polarity changed")
    return {"clone": clone, "root": tuple(proof["control_root"]), "group1_selected": selected,
            "baseline_cells": baseline_cells, "proof": proof}


def prove_ready_extension(old, new, context, extra, budget):
    clone, root = context["clone"], context["root"]
    baseline = Netlist(context["baseline_cells"])
    primary = {row["ff"] for row in context["group1_selected"]}
    selected = primary | {row["ff"] for row in extra}
    require(budget > 1 or not extra, "group-1 budget unexpectedly rewired secondary ready users")
    for row in extra:
        require(tuple(row["control_driver"]) == root and tuple(row["candidate_driver"]) == (clone, "Q", 0) and
                baseline.inputs(row["ff"])["ENA"] == [root], "secondary ready ENA changed from a different root")
    before = consumers(baseline, root, set(baseline.cells))
    after = consumers(new, root, set(baseline.cells))
    require(after == [user for user in before if not (user[0] in selected and user[1:] == ("ENA", 0))],
            "an unselected original shared-ready consumer changed")
    existing_clone_users = consumers(old, (clone, "Q", 0), set(old.cells))
    clone_users = consumers(new, (clone, "Q", 0), set(old.cells))
    require(clone_users == sorted(existing_clone_users + [(row["ff"], "ENA", 0) for row in extra]),
            "existing ready-clone consumers changed outside additional ENAs")
    groups = {}
    for name in selected:
        groups.setdefault(cell_lab(new.cells[name]), []).append(name)
        require(new.inputs(name)["ENA"] == [(clone, "Q", 0)] and
                baseline.pin_states(name).get("ENA", 0) == new.pin_states(name).get("ENA", 0),
                "selected ready function or FF ENA polarity changed")
    primary_labs = {cell_lab(baseline.cells[name]) for name in primary}
    require(len(primary_labs) == 1 and len(groups) <= budget, "selected ready LAB group count exceeds its budget")
    primary_ff = next(iter(primary))
    clock = baseline.inputs(primary_ff)["CLK"]
    clock_state = baseline.pin_states(primary_ff).get("CLK", 0)
    for lab, members in groups.items():
        users = [user for user in before if cell_lab(baseline.cells[user[0]]) == lab]
        require(all(baseline.cells[name]["type"] == "MISTRAL_FF" and port == "ENA" and index == 0 and
                    baseline.inputs(name)["CLK"] == clock and baseline.pin_states(name).get("CLK", 0) == clock_state
                    for name, port, index in users) and sorted(name for name, _, _ in users) == sorted(members),
                "ready selection did not retain a complete compatible LAB group")
    return {"requested_group_budget": budget, "selected_group_count": len(groups),
            "primary_lab": next(iter(primary_labs)),
            "group1_selected_ff_count": len(primary), "additional_ff_ena_count": len(extra),
            "selected_ff_ena_count": len(selected), "additional_ff_ena_connections": extra,
            "selected_lab_groups": [{"lab": lab, "ffs": sorted(names)} for lab, names in sorted(groups.items())],
            "original_root": root, "existing_clone": ready.detail(clone, new.cells[clone]),
            "group1_clone_equivalence": context["proof"], "existing_clone_function_inputs_bel_parameters_preserved": True,
            "selected_ena_polarities_preserved": True, "whole_compatible_lab_groups_proved": True,
            "original_root_consumers": before, "retained_original_root_consumers": after,
            "unselected_original_root_consumers_preserved": True, "existing_clone_consumers": existing_clone_users,
            "candidate_clone_consumers": clone_users}


def verify_ready_log(log, extension):
    root, clone = extension["original_root"][0], extension["existing_clone"]
    nodes = set(extension["group1_clone_equivalence"]["retained_cone"])
    require(root in nodes and len(nodes) == 2, "group-1 ready proof is not the frozen two-LUT composition")
    inner = (nodes - {root}).pop()
    pattern = previous.re.compile(r"^Info: Local remap candidate (\d+): (\S+) \+ (\S+) -> (\S+), "
                                  r"(\d+) ENA users, predicted gain ([\d.]+)ps\.$", previous.re.M)
    matches = [match for match in pattern.finditer(log) if int(match[1]) == 0]
    require(len(matches) == 1 and matches[0][2] == inner and matches[0][3] == root and
            matches[0][4] == clone["bel"] and int(matches[0][5]) == extension["selected_ff_ena_count"] and
            "Local remap applied candidate 0;" in log, "selected ready candidate log disagrees with actual ENA rewires")
    match = matches[0]
    trial = previous.re.compile(r"^Info: Local remap trial inner=" + previous.re.escape(inner) + r" outer=" +
        previous.re.escape(root) + r" lab=(\d+),(\d+) bel=" + previous.re.escape(clone["bel"]) +
        r" shift=0,0 gain=" + previous.re.escape(match[6]) + r"ps clocks=1 hold=1 boundaries=1 groups=(\d+) sinks=(\d+)$",
        previous.re.M)
    found = list(trial.finditer(log[:match.start()]))
    require(found and tuple(map(int, (found[-1][1], found[-1][2]))) == tuple(extension["primary_lab"]) and
            int(found[-1][3]) == extension["selected_group_count"] and
            int(found[-1][4]) == extension["selected_ff_ena_count"] and float(match[6]) >= 250,
            "selected ready placement trial disagrees with whole-group evidence")
    return {"candidate_log": match[0], "qualified_trial_log": found[-1][0], "predicted_primary_gain_ps": float(match[6])}


def endpoint_arrival_comparison(cells, sink, reports):
    """Use final reported register arrivals; internal LUT arrivals are not exported."""
    netlist = Netlist(cells)
    todo, seen, endpoints = [(sink, "Q", 0)], set(), set()
    while todo:
        token = todo.pop()
        require(token not in seen, "cyclic downstream selected cut")
        seen.add(token)
        for name, port, _ in consumers(netlist, token, set(cells)):
            if ready.is_lut(cells[name]):
                target = (name, "Q", 0)
                if target not in seen and target not in todo:
                    todo.append(target)
            else:
                endpoints.add((name, port))
    values = {}
    for label, report in reports.items():
        current = {}
        for row in report["detailed_net_timings"]:
            for endpoint in row["endpoints"]:
                if (endpoint["cell"], endpoint["port"]) not in endpoints:
                    continue
                key = (endpoint["cell"], endpoint["port"], row["event"], endpoint["event"])
                require(key not in current, "duplicate selected downstream register arrival")
                current[key] = endpoint["delay"]
        values[label] = current
    candidate = values.pop("candidate")
    require(candidate and all(set(rows) == set(candidate) for rows in values.values()),
            "selected downstream register timing endpoint set changed")
    comparisons = {}
    for label, previous_rows in values.items():
        rows = []
        for key, arrival in sorted(candidate.items()):
            control = previous_rows[key]
            rows.append({"cell": key[0], "port": key[1], "launch_event": key[2], "capture_event": key[3],
                         "control_arrival_ns": control, "candidate_arrival_ns": arrival,
                         "min_arrival_change_ns": arrival[0] - control[0],
                         "max_arrival_gain_ns": control[1] - arrival[1]})
        comparisons[label] = {"endpoint_count": len(rows), "rows": rows,
                              "all_max_arrivals_nonregressing": all(row["max_arrival_gain_ns"] >= 0 for row in rows),
                              "minimum_max_arrival_gain_ns": min(row["max_arrival_gain_ns"] for row in rows),
                              "maximum_max_arrival_gain_ns": max(row["max_arrival_gain_ns"] for row in rows)}
    return comparisons


def prove_cut(old, new, clone, selected, guide_report, plan=None):
    require(len(selected) == 1, "one internal input must consume the selected composed clone")
    edge = selected[0]
    order = new.lut_inputs(clone)
    clone_inputs = set(order)
    nodes, raw_inputs, leaves, report_path = recover_cut(old, edge, guide_report, plan)
    require(2 <= len(order) <= 6 and len(clone_inputs) == len(order) and clone_inputs <= leaves,
            "the composed clone is not a valid two-to-six-input cut")
    if plan:
        require(plan["bel"] == previous.bel(new.cells[clone]), "the clone BEL disagrees with the selected trial")
    states = new.pin_states(clone)
    require(all(states.get(pin, 0) == 0 for pin in "ABCDEF"[:len(order)] + "Q"),
            "the composed clone contains an unexpected logical pin state")
    visited = set()
    tree = old.expression(tuple(edge["control_driver"]), leaves, visited)
    require(visited == set(nodes), "the recovered report cut does not match the retained original Boolean cone")
    mask = int(new.cells[clone]["parameters"]["LUT"], 2)
    tokens = sorted(leaves)
    rows, expected_mask, original_table = [], 0, []
    for assignment in range(1 << len(tokens)):
        values = {token: (assignment >> i) & 1 for i, token in enumerate(tokens)}
        physical_row = sum((t[1] if t[0] == "constant" else values[t]) << i for i, t in enumerate(order))
        expected = previous.evaluate(tree, values)
        original_table.append(expected)
        actual = (mask >> physical_row) & 1
        require(actual == expected, f"composed internal-edge function changed: {clone}, row {assignment}")
        expected_mask |= expected << physical_row
        rows.append({"assignment": assignment, "clone_row": physical_row,
                     "inputs": [(assignment >> i) & 1 for i in range(len(tokens))],
                     "retained_cone_output": expected, "clone_output": actual})
    essential = {token for index, token in enumerate(tokens) if any(
        not (row & (1 << index)) and original_table[row] != original_table[row | (1 << index)]
        for row in range(len(original_table)))}
    require(clone_inputs == essential, "the clone inputs do not match the exact essential-variable pruning policy")
    root = tuple(edge["control_driver"])
    before = consumers(old, root, set(old.cells))
    after = consumers(new, root, set(old.cells))
    selected_consumer = (edge["sink"], edge["port"], 0)
    require(selected_consumer in before and after == [user for user in before if user != selected_consumer],
            "an unselected consumer of the retained original cut root changed")
    return {"clone": ready.detail(clone, new.cells[clone]), "selected_internal_input": edge,
            "control_root": root, "retained_cone": {n: ready.detail(n, old.cells[n]) for n in sorted(visited)},
            "external_inputs": tokens, "clone_input_order": dict(zip("ABCDEF", order)),
            "original_raw_cut_inputs": raw_inputs, "report_cut_nodes": nodes,
            "retained_essential_inputs": sorted(essential), "pruned_unused_inputs": sorted(leaves - essential),
            "exact_essential_input_pruning_proved": True, "selected_report_path": report_path,
            "equivalent": True, "assignments_checked": len(rows), "truth_rows": rows,
            "clone_mask_hex": hex(mask), "composed_reachable_mask_hex": hex(expected_mask),
            "control_lut_depth": previous.depth(tree), "candidate_lut_depth": 1,
            "cut_lut_count": len(visited), "original_root_consumers": before,
            "retained_original_root_consumers": after, "unselected_root_consumers_preserved": True}


def compare_netlists(old_cells, new_cells, guide_report, plan=None, ready_context=None, group_budget=0):
    old, new = Netlist(old_cells), Netlist(new_cells)
    common = set(old_cells) & set(new_cells)
    added = sorted(set(new_cells) - set(old_cells))
    removed = sorted(set(old_cells) - set(new_cells))
    require(not removed, "an original cell or buffer was removed")
    clones = [n for n in added if ready.is_lut(new_cells[n])]
    require(len(clones) == 1 and added == clones, "one composed ALUT2..6 and no new BUFs are required")
    old_ffs = {n for n, c in old_cells.items() if c["type"] == "MISTRAL_FF"}
    new_ffs = {n for n, c in new_cells.items() if c["type"] == "MISTRAL_FF"}
    require(old_ffs == new_ffs, "FF population changed")
    old_luts = {n for n, c in old_cells.items() if c["type"].startswith("MISTRAL_ALUT")}
    changed_bels = {"ff": [], "original_lut": [], "transparent_buffer": [], "other": []}
    edges, extra_ena = [], []
    for name in sorted(common):
        a, b = old_cells[name], new_cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"],
                f"original type or parameters changed: {name}")
        category = "ff" if name in old_ffs else "original_lut" if name in old_luts else \
                   "transparent_buffer" if a["type"] == "MISTRAL_BUF" else "other"
        if previous.bel(a) != previous.bel(b):
            changed_bels[category].append({"cell": name, "control_bel": previous.bel(a), "candidate_bel": previous.bel(b)})
        if category == "transparent_buffer":
            require(previous.bel(a) == previous.bel(b) and old.inputs(name) == new.inputs(name) and
                    old.pin_states(name) == new.pin_states(name) and
                    old.direct_users.get((name, "Q", 0), []) == new.direct_users.get((name, "Q", 0), []),
                    f"original BUF changed: {name}")
            continue
        require(old.pin_states(name) == new.pin_states(name), f"original logical pin states changed: {name}")
        ai, bi = old.inputs(name), new.inputs(name)
        require(set(ai) == set(bi), f"original input-port set changed: {name}")
        for port in sorted(ai):
            if ai[port] == bi[port]:
                continue
            if ready_context and name in old_ffs and port == "ENA":
                require(len(ai[port]) == len(bi[port]) == 1 and
                        ai[port] == [ready_context["root"]] and
                        bi[port] == [(ready_context["clone"], "Q", 0)],
                        f"FF ENA rewire is outside the existing shared-ready clone: {name}")
                extra_ena.append({"ff": name, "bel": previous.bel(b), "control_net": a["connections"][port],
                                  "candidate_net": b["connections"][port], "control_driver": ai[port][0],
                                  "candidate_driver": bi[port][0]})
                continue
            require(ready.is_lut(a) and port in "ABCDEF" and len(ai[port]) == len(bi[port]) == 1,
                    f"an input changed outside an ordinary Boolean LUT: {name}.{port}")
            require(bi[port][0][0] in clones and bi[port][0][1:] == ("Q", 0),
                    f"the selected internal input does not use the composed clone: {name}.{port}")
            edges.append({"sink": name, "port": port, "bel": previous.bel(b),
                          "control_net": a["connections"][port], "candidate_net": b["connections"][port],
                          "control_driver": ai[port][0], "candidate_driver": bi[port][0]})
    require(all(not changed_bels[k] for k in ("ff", "original_lut", "other")), "original non-BUF BEL changed")
    require(len(edges) == 1, "exactly one original internal LUT input must change")
    proof = prove_cut(old, new, clones[0], edges, guide_report, plan)
    extension = prove_ready_extension(old, new, ready_context, extra_ena, group_budget) if ready_context else None
    return {"common_cells": len(common), "common_ff_cells": len(old_ffs), "original_lut_cells": len(old_luts),
            "ff_placements_identical": True, "original_lut_placements_identical": True,
            "original_type_parameters_preserved": True, "all_original_ff_logical_connections_preserved": not extra_ena,
            "all_original_ff_connections_preserved_except_selected_ready_enas": True,
            "all_original_logical_pin_states_preserved": True,
            "all_unselected_original_logical_connections_preserved": True,
            "all_original_output_consumers_preserved_except_selected_internal_edge": not extra_ena,
            "all_original_output_consumers_preserved_except_selected_internal_edge_and_ready_enas": True,
            "changed_common_bels_by_kind": changed_bels, "selected_internal_lut_inputs": edges,
            "added_cells": [ready.detail(n, new_cells[n]) for n in added],
            "removed_cells": [ready.detail(n, old_cells[n]) for n in removed],
            "added_clone_count": len(clones),
            "added_buffer_count": sum(new_cells[n]["type"] == "MISTRAL_BUF" for n in added),
            "removed_buffer_count": len(removed), "all_original_buffers_preserved": True,
            "ready_group_extension": extension, "composed_cut_equivalence": proof}


def comparison(folder):
    record = read(folder / "run.json")
    require(record.get("completed") and record.get("exit_code") == 0, "candidate metadata is not final")
    reference = structural_reference(record)
    group_budget = ready_group_budget(record)
    control_paths = {"baseline_108": BASE, "control_115": CONTROL, "ready_control_113": READY_CONTROL}
    if reference == PIN_CONTROL:
        control_paths["pin_control_113"] = PIN_CONTROL
    if group_budget > 1:
        require(reference == READY_CONTROL, "larger ready budgets must extend the original group-1 clone")
        control_paths["comb_ready_g1"] = COMB_READY_G1
    artifacts = [p / name for p in (folder, *control_paths.values(), PIN_CONTROL) for name in ready.ARTIFACT_NAMES]
    artifacts += [p / name for p in (HERE, ready.FROZEN, PIN_SOURCE)
                  for name in ("source-identity.json", "source.tar.gz", "nextpnr-mistral")]
    artifacts += [Path(__file__).resolve(), READY_HELPER, ready.PREVIOUS_HELPER,
                  RAW / "validated-nextpnr-mistral", RAW / "nextpnr-slots-fixed-source.tar.gz",
                  RAW / "slot-fixed-source-hashes.json"]
    digests = {p: sha(p) for p in artifacts}
    record, report, cells, log, route = previous.route_evidence(folder)
    controls = {}
    for name, p in control_paths.items():
        r, t, c, l, e = previous.route_evidence(p)
        controls[name] = {"path": p, "record": r, "report": t, "cells": c, "log": l, "route": e}
    parent_record, _, _, _, parent_route = previous.route_evidence(PIN_CONTROL)
    require(all(item["record"]["build_id"] == record["build_id"] for item in controls.values()) and
            parent_record["build_id"] == record["build_id"], "fixed synthesis BUILD_ID changed")
    inputs = previous.authenticate_inputs(record)
    source, parent_source = authenticate_compiler(record)
    parent_inputs = previous.authenticate_inputs(parent_record)
    for name, item in controls.items():
        item["authenticated_inputs"] = previous.authenticate_inputs(item["record"],
            RAW / "validated-nextpnr-mistral" if name == "baseline_108" else None)
        item["source"] = previous.verify_archive(RAW / "nextpnr-slots-fixed-source.tar.gz",
            read(RAW / "slot-fixed-source-hashes.json")) if name == "baseline_108" else \
            previous.source_identity(HERE if item["path"].parent == HERE else
                                    PIN_SOURCE if item["path"] == PIN_CONTROL else ready.FROZEN, item["record"])
        if item["path"].parent == HERE:
            authenticate_compiler(item["record"])
            require(ready_group_budget(item["record"]) == 1 and structural_reference(item["record"]) == READY_CONTROL and
                    ready.argument(item["record"]["command"], "--remap-comb-critical") == str(GUIDE_REPORT) and
                    ready.argument(item["record"]["command"], "--remap-comb-candidate") == "0",
                    "frozen same-compiler group-1 control command changed")
    control_record = controls["control_115"]["record"]
    require(fixed_command(record["command"]) == fixed_command(control_record["command"]), "fixed route command changed")
    require(all(fixed_command(item["record"]["command"]) == fixed_command(control_record["command"])
                for item in controls.values()), "a frozen control's fixed route command changed")
    for option in ("--json", "--qsf", "--sdc"):
        path = ready.argument(record["command"], option)
        expected = record["input_sha256"].get(path)
        require(expected and all(ready.argument(item["record"]["command"], option) == path and
                                item["record"]["input_sha256"].get(path) == expected for item in controls.values()),
                f"fixed synthesis/constraint input changed: {option}")
    require(ready.argument(record["command"], "--remap-comb-critical") == str(GUIDE_REPORT), "wrong comb guidance report")
    comb_candidate = int(ready.argument(record["command"], "--remap-comb-candidate"))
    for key in ("comb_candidate", "comb_remap_candidate", "remap_comb_candidate"):
        if key in record:
            require(record[key] == comb_candidate, "comb candidate record disagrees with command")
    require(record["input_sha256"].get(str(GUIDE_REPORT)) == sha(GUIDE_REPORT), "comb guidance report is not authenticated")
    for key in ("comb_report_sha256", "comb_remap_report_sha256", "remap_comb_report_sha256"):
        if key in record:
            require(record[key] == sha(GUIDE_REPORT), "comb report record disagrees with the authenticated report")
    if "stack_ready" in record:
        require(record["stack_ready"] is (reference != CONTROL), "ready-stack record disagrees with command")
    if group_budget:
        for key in ("ready_report_sha256", "remap_report_sha256", "ready_remap_report_sha256"):
            if key in record:
                require(record[key] == sha(CONTROL / "timing.json"), "ready report alias changed")
    if "control_run_sha256" in record:
        require(record["control_run_sha256"] in {sha(CONTROL / "run.json"), sha(READY_CONTROL / "run.json"),
                                                sha(reference / "run.json")}, "referenced control metadata changed")
    require(record["experimental_capture_locality"] == control_record["experimental_capture_locality"] ==
            str(BASE / "timing.json") + " 64 24", "capture64r24 settings changed")
    require(record["experimental_placed_reduction"] == control_record["experimental_placed_reduction"] ==
            previous.ROOT_CELL + " 6 0", "placed eleven-input reduction settings changed")
    capture_sha = sha(BASE / "timing.json")
    for current in (record, control_record):
        require(current["input_sha256"].get(str(BASE / "timing.json")) == capture_sha,
                "capture report input changed")
        if "capture_report_sha256" in current:
            require(current["capture_report_sha256"] == capture_sha, "capture report alias changed")
    ready.authenticate_execution(record, control_record)
    for option, filename in (("--write", "routed.json"), ("--report", "timing.json"), ("--rbf", "core.rbf")):
        require(ready.argument(record["command"], option) == str(folder / filename), f"output path mismatch: {option}")
    metrics = previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and all(previous.PLACEMENT_METRICS.findall(item["log"]) == metrics
                                      for item in controls.values()), "the 71 ordinary HeAP placement metrics changed")
    require(set(report["fmax"]) == set(REQUIRED_CLOCKS) and
            all(report["fmax"][clock]["constraint"] >= nominal for clock, nominal in REQUIRED_CLOCKS.items()),
            "required clock set or nominal constraints changed")
    guide_path, _ = logic_path(controls["ready_control_113"]["report"])
    plan = selected_candidate(log, comb_candidate)
    ref = next(item for item in controls.values() if item["path"] == reference)
    ready_context = discover_ready_reference(controls["control_115"]["cells"], ref["cells"]) if group_budget else None
    placement = compare_netlists(ref["cells"], cells, controls["ready_control_113"]["report"], plan,
                                ready_context, group_budget)
    if ready_context:
        placement["ready_group_extension"]["selected_ready_log"] = verify_ready_log(log, placement["ready_group_extension"])
    extension = placement["ready_group_extension"]
    ready_summary = {key: extension[key] for key in ("requested_group_budget", "selected_group_count",
        "group1_selected_ff_count", "additional_ff_ena_count", "selected_ff_ena_count", "primary_lab",
        "selected_lab_groups", "unselected_original_root_consumers_preserved")} if extension else None
    stacked = ready.transform_stack(log, controls["control_115"]["log"])
    clocks = {name: previous.compare_clocks(item["report"], report) for name, item in controls.items()}
    selected = placement["selected_internal_lut_inputs"][0]
    clone = placement["composed_cut_equivalence"]["clone"]["cell"]
    arrival_rows = [{**entry, "endpoints": [e for e in entry["endpoints"] if
                                          e["cell"] == selected["sink"] and e["port"] == selected["port"]]}
                    for entry in report["detailed_net_timings"] if entry["driver"] == clone]
    downstream_arrivals = endpoint_arrival_comparison(cells, selected["sink"],
        {"candidate": report, **{name: item["report"] for name, item in controls.items()}})
    require(all(sha(p) == digest for p, digest in digests.items()), "evidence changed during comparison")
    return {"status": "experimental internal-edge combinational remap; unselected", "build_id": record["build_id"],
            "compiler_commit": record.get("compiler_commit"), "base_compiler_commit": source["base_commit"],
            "capture_report_sha256": capture_sha,
            "elapsed_seconds": record["elapsed_seconds"], "comb_remap_candidate": comb_candidate,
            "ready_group_budget": group_budget,
            "ready_group_summary": ready_summary,
            "ready_remap_stacked": reference != CONTROL, "bel_and_connection_reference": relative(reference),
            "candidate_route": route, "source": source, "authenticated_inputs": inputs,
            "compiler_parent_2019": {"path": relative(PIN_CONTROL), "source": parent_source, "route": parent_route,
                                     "authenticated_inputs": parent_inputs},
            "controls": {name: {"path": relative(item["path"]), "route": item["route"], "source": item["source"],
                                "authenticated_inputs": item["authenticated_inputs"]} for name, item in controls.items()},
            "fmax_comparisons": clocks,
            "all_clock_nonregression": {name: all(row["gain_mhz"] >= 0 for row in rows.values()) for name, rows in clocks.items()},
            "passes_all_clock_constraints": all(row["meets_constraint"] for row in clocks["control_115"].values()),
            "nonmemory_required_clocks_close": all(row["meets_constraint"] for clock, row in
                clocks["control_115"].items() if clock != MEMORY_CLOCK),
            "memory_improved_vs_115": clocks["control_115"][MEMORY_CLOCK]["gain_mhz"] > 0,
            "passes_strict_diagnostic_gate_vs_115": all(row["gain_mhz"] >= 0 for row in clocks["control_115"].values()) and
                clocks["control_115"][MEMORY_CLOCK]["gain_mhz"] > 0 and not route["final_reported_hold_violations"],
            "placement_metrics_identical": True, "matched_placement_metrics": len(metrics),
            "placement_metrics_sha256": hashlib.sha256("\n".join(metrics).encode()).hexdigest(),
            **placement, "transform_stack": stacked, "comb_guidance_critical_path": guide_path,
            "selected_comb_candidate": plan,
            "critical_path_comparisons": ready.critical_path_comparison(controls["control_115"]["report"], report),
            "critical_memory_path": next(p for p in report["critical_paths"] if p["from"] == p["to"] == "posedge " + MEMORY_CLOCK),
            "selected_internal_input_report_arrivals": arrival_rows,
            "internal_lut_arrivals_exported": False,
            "selected_downstream_register_arrival_comparisons": downstream_arrivals,
            "remap_log": [line for line in log.splitlines() if "remap" in line.lower()],
            "execution_inputs_authenticated": True, "final_metadata_stable_during_comparison": True,
            "artifact_sha256": {relative(p): digest for p, digest in digests.items()},
            "default_recipe_selected": False, "hardware_tested": False,
            "caveats": ["The Boolean proof covers the selected cut and preserved downstream connections.",
                        "Final reported hold warnings are a screen, not package or hardware acceptance."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", nargs="?", default="route-c0", help="finalized candidate directory under comb-remap-264")
    args = parser.parse_args()
    folder = (HERE / args.route).resolve()
    require(folder.parent == HERE, "candidate must be a direct directory under comb-remap-264")
    result = comparison(folder)
    (folder / "comparison.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    keys = ("status", "compiler_commit", "elapsed_seconds", "comb_remap_candidate", "ready_remap_stacked",
            "ready_group_budget", "ready_group_summary",
            "candidate_route", "fmax_comparisons", "all_clock_nonregression", "passes_all_clock_constraints",
            "memory_improved_vs_115", "matched_placement_metrics", "common_ff_cells", "original_lut_cells",
            "ff_placements_identical", "original_lut_placements_identical", "added_clone_count", "added_buffer_count",
            "removed_buffer_count", "selected_internal_lut_inputs", "default_recipe_selected", "hardware_tested")
    print(json.dumps({key: result[key] for key in keys}, indent=2))


if __name__ == "__main__":
    main()
