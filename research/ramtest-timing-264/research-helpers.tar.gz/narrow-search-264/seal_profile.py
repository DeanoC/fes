"""Root-only fresh same-phase baseline and eleven-literal qualification profile.

Only cached authenticator APIs are called. Earlier comparisons are not replayed
or inherited as current qualifications. Future selected stages need a separate
versioned profile; this profile cannot route or apply an eleven-literal ordinal.
"""
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PARENT = RAW / "placed12-minimum-264"
PARENT_SEAL_SHA = "8974d472e4185d12f4aeb6040b35fce4f95e03a6cb78e1bf12523bb415aa098b"
BASE = "6552942de15ed48e1bb9fbc71e3c08f189486313"
PROFILE, LOCAL_PLAN = HERE / "profile.json", HERE / "local-plan.json"
PLAN = HERE / "experiment-plan.json"
PLAN_SHA = "a9916fce5a69ba1f5ab9e80331d5ecac86ab8181000323a7c7bd3ef74ac959a2"
FULL, LIST = RAW / "ready-g8-decomposition-264/route-c0", RAW / "ready-g8-decomposition-264/list"
PHASES = ("baseline-placement", "list-eleven")
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    return json.loads(path.read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite: " + value)))


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def references():
    require(sha(PARENT / "seal_profile.py") == PARENT_SEAL_SHA, "frozen parent authenticator changed")
    old = module_at(PARENT / "seal_profile.py", "narrow_search_cached_parent_authenticator")
    parent_profile, g8, base, _, _, parent_source, _ = old.load_profile()
    require(parent_source["result_commit"] == BASE and base["compiler_commit"] == g8.RESULT_COMMIT,
            "cached measured/parent lineage changed")
    return old, parent_profile, g8, base


def current_control():
    checker = module_at(HERE / "check_disabled_control.py", "narrow_search_current_disabled_control")
    source, control = checker.authenticate_control()
    require(source["base_commit"] == BASE and source["result_commit"] != BASE and
            source["binary_sha256"] == sha(HERE / "nextpnr-mistral"), "new validated producer identity changed")
    return source, control


def profile_aliases(base, source):
    old = base["experimental_placed_reduction"].split()
    require(len(old) == 3 and old[1:] == ["6", "0"], "accepted eleven-literal root/radius changed")
    return {"schema": 1, "scope": "same-phase baseline and fresh eleven-literal listing only",
            "base_compiler_commit": BASE, "compiler_commit": source["result_commit"],
            "reference_full": str(FULL), "reference_listing": str(LIST),
            "source_identity_sha256": sha(HERE / "source-identity.json"),
            "disabled_control_sha256": sha(HERE / "disabled-control/comparison.json"),
            "experiment_plan_sha256": PLAN_SHA, "local_plan": base["remap_plan"],
            "eleven_stage": {"root": old[0], "radius": 6, "minimum_branch_gain_ps": 250},
            "parent_qualification_inherited": False, "selected_ordinal_allowed": False,
            "default_recipe_selected": False, "hardware_tested": False}


def load_profile():
    profile = read(PROFILE)
    require("input_sha256" in profile, "profile lacks its input closure")
    for filename, digest in profile["input_sha256"].items():
        path = Path(filename)
        require(path.is_absolute() and path.is_relative_to(ROOT) and sha(path) == digest,
                "sealed input changed: " + filename)
    _, _, g8, base = references()
    source, control = current_control()
    aliases = profile_aliases(base, source)
    require(set(profile) == set(aliases) | {"input_sha256"} and
            all(profile[key] == value for key, value in aliases.items()) and
            read(LOCAL_PLAN) == base["remap_plan"], "sealed profile aliases changed")
    for path in (Path(__file__), HERE / "route.py", HERE / "compare_first11.py",
                 HERE / "freeze.py", HERE / "check_disabled_control.py", PLAN, LOCAL_PLAN,
                 HERE / "source-identity.json", HERE / "nextpnr-mistral"):
        require(profile["input_sha256"].get(str(path.resolve())) == sha(path), "profile omits current input")
    return profile, g8, base, source, control


def phase_folder(phase, eleven=None, twelve=None, ac=None):
    require(phase in PHASES and twelve is None and ac is None and
            eleven == (-1 if phase == "list-eleven" else None), "this profile permits no selected ordinal")
    return HERE / phase


def specifications(base, phase):
    require(phase in PHASES, "unknown phase")
    if phase == "baseline-placement":
        return []
    parts = base["experimental_placed_reduction"].split()
    require(len(parts) == 3 and parts[1:] == ["6", "0"], "accepted eleven stage changed")
    return [{"root": parts[0], "radius": 6, "candidate": -1, "minimum_branch_gain_ps": 250}]


def expected_diagnostic_environment(base, phase):
    env = {"NEXTPNR_MISTRAL_CAPTURE_LOCALITY": base["experimental_capture_locality"]}
    specs = specifications(base, phase)
    if specs:
        # Default250 remains its original three-token spelling.
        env["NEXTPNR_MISTRAL_PLACED_REDUCTION"] = "\n".join(
            f"{row['root']} {row['radius']} {row['candidate']}" for row in specs)
    return env


def expected_command(base, phase):
    command = base["command"]
    removed = {"--remap-decompose-critical", "--remap-decompose-candidate", "--write", "--report", "--rbf"}
    result, index = [str(HERE / "nextpnr-mistral")], 1
    while index < len(command):
        token = command[index]
        if token in removed:
            require(index + 1 < len(command), "missing reference option value")
            index += 2
        elif token == "--remap-plan":
            require(index + 1 < len(command), "missing reference remap plan")
            result.extend([token, str(LOCAL_PLAN)])
            index += 2
        else:
            result.append(token)
            index += 1
    require(not any(token in result for token in ("--no-pack", "--no-place", "--no-route")),
            "full reference has suppressed ordinary placement")
    return result + ["--no-route", "--write", str(phase_folder(phase, -1 if phase == "list-eleven" else None) / "placed.json")]


def sealed_input_map(profile, phase):
    require(phase in PHASES, "unknown phase")
    inputs = {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}
    if phase == "list-eleven":
        folder = HERE / "baseline-placement"
        record = read(folder / "run.json")
        require(record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0,
                "fresh same-phase baseline is not complete")
        authenticate_phase(record)
        require("Info: Program finished normally." in (folder / "route.log").read_text(), "baseline failed")
        for name in ("run.json", "route.log", "placed.json"):
            inputs[str(folder / name)] = sha(folder / name)
    return inputs


def authenticate_phase(record):
    profile, _, base, source, _ = load_profile()
    phase = record["phase"]
    require(phase in PHASES and record["command"] == expected_command(base, phase) and
            record["diagnostic_environment"] == expected_diagnostic_environment(base, phase) and
            record["placed_reduction_plan"] == specifications(base, phase) and
            record["compiler_commit"] == source["result_commit"] and record["base_compiler_commit"] == BASE and
            record["profile_sha256"] == sha(PROFILE) and record["runner_sha256"] == sha(HERE / "route.py") and
            record["input_sha256"] == sealed_input_map(profile, phase) and
            record["parent_qualification_inherited"] is False and record["list_only"] is True and
            record["fresh_listing"] is True and record["decomposition_selection"] is None,
            "phase differs from the unselected fresh qualification profile")
    return {"phase": phase, "folder": phase_folder(phase, -1 if phase == "list-eleven" else None),
            "specs": specifications(base, phase), "command": expected_command(base, phase),
            "environment": expected_diagnostic_environment(base, phase)}


def authenticate_cached(folder, required=()):
    proof, record = read(folder / "comparison.json"), read(folder / "run.json")
    require(proof["candidate_completed"] is True and proof["final_metadata_stable_during_comparison"] is True and
            record["completed"] is True and record["exit_code"] == 0, "fresh proof is not finalized")
    for filename, digest in proof["artifact_sha256"].items():
        path = ROOT / filename
        require(path.is_relative_to(ROOT) and sha(path) == digest, "fresh proof artifact changed")
    for path in (folder / "run.json", folder / "route.log", *required, *(Path(name) for name in record["input_sha256"])):
        require(proof["artifact_sha256"].get(str(path.relative_to(ROOT))) == sha(path), "fresh proof omits input")
    return record, proof


def main():
    require(not PROFILE.exists() and not LOCAL_PLAN.exists(), "profile outputs already exist")
    require(sha(PLAN) == PLAN_SHA, "predeclared experiment changed")
    _, parent_profile, _, base = references()
    source, control = current_control()
    inputs = {**parent_profile["input_sha256"], **source["input_sha256"], **control["input_sha256"]}
    for path in (Path(__file__), HERE / "route.py", HERE / "compare_first11.py", HERE / "freeze.py",
                 HERE / "check_disabled_control.py", PLAN, HERE / "source-identity.json", HERE / "source.tar.gz",
                 HERE / "change.patch", HERE / "nextpnr-mistral", HERE / "disabled-control/comparison.json",
                 HERE / "disabled-control/candidate.json", HERE / "disabled-control/loader.log"):
        require(path.exists(), "profile input is absent: " + str(path))
        inputs[str(path.resolve())] = sha(path)
    with LOCAL_PLAN.open("x") as output:
        output.write(json.dumps(base["remap_plan"], indent=2, sort_keys=True) + "\n")
    inputs[str(LOCAL_PLAN)] = sha(LOCAL_PLAN)
    require(all(sha(Path(name)) == digest for name, digest in inputs.items()), "input closure changed")
    profile = {**profile_aliases(base, source), "input_sha256": inputs}
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True) + "\n")
    load_profile()
    print(json.dumps({"profile_sha256": sha(PROFILE), "sealed_inputs": len(inputs), "scope": profile["scope"]}, indent=2))


if __name__ == "__main__":
    main()
