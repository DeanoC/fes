"""Root-operated fresh eleven listing proof with flat pinned authentication.

Only the frozen first comparator's pure graph/truth/log functions are reused.
Cached source/control proofs are hash-bound rather than recursively replayed.
The new output is first-fast-proof-v2/comparison.json; earlier outputs are untouched.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE, SOURCE = HERE / "profile.json", HERE / "source-identity.json"
CONTROL = HERE / "disabled-control/comparison.json"
BASELINE, LISTING = HERE / "baseline-placement", HERE / "list-eleven"
OUTPUT = HERE / "first-fast-proof-v2/comparison.json"
FULL, LIST = RAW / "ready-g8-decomposition-264/route-c0", RAW / "ready-g8-decomposition-264/list"
PURE_HELPER = HERE / "compare_first11.py"
SEAL = HERE / "seal_profile.py"
G8_HELPER = RAW / "ready-g8-decomposition-264/compare_control_decomposition.py"
PROFILE_SHA = "e84365ed02c169d622f2735b05b4eb144ffa159c7e14cc981bef25ddcf51a5b8"
SOURCE_SHA = "882cc97ad05b3af4ce99f5686d7e73d816d2e77c8eb4b9122acf4bdff26cef52"
CONTROL_SHA = "e04f5fe62f1281ee96f6a27d4aff12f48c912005dab5d3beb2c96ea5f8091221"
PURE_HELPER_SHA = "b9b7e62b4a7eaec22a2e064127da1b9332c66de7de1c1fe6509b37c1e6ed7027"
SEAL_SHA = "6df06f16ec4b025cf2f991e2555b84e3ed30947d9002827d4598a4c899d711c9"
RUNNER_SHA = "c30d7e0c742aa524689636fb08f1f5b08889cf77e04e196849051ddb2e7866e7"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
FULL_PROOF_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
BASE_COMMIT = "6552942de15ed48e1bb9fbc71e3c08f189486313"
RESULT_COMMIT = "cc00795f772def091160da354018992600c82869"
SEALED_INPUT_COUNT = 242
DIGEST = re.compile(r"[0-9a-f]{64}")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite: " + value)))


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def relative(path):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT), "artifact is outside the active FES checkout")
    return str(path.relative_to(ROOT))


class Audit:
    """Hash each unique input once on entry, then independently rehash at exit."""
    def __init__(self):
        self.digests, self.paths, self.artifacts, self.execution = {}, {}, {}, {}

    def bind(self, path, expected=None, execution=False):
        path = Path(path)
        require(path.is_absolute(), "input path is not absolute")
        canonical = path.resolve()
        require(execution or canonical.is_relative_to(ROOT), "non-runtime input is outside ROOT")
        if expected is not None:
            require(type(expected) is str and DIGEST.fullmatch(expected), "invalid input digest")
        if canonical not in self.digests:
            self.digests[canonical] = sha(path)
        digest = self.digests[canonical]
        require(expected is None or digest == expected, "input changed: " + str(path))
        require(path not in self.paths or self.paths[path] == digest, "input path identities conflict")
        self.paths[path] = digest
        if canonical.is_relative_to(ROOT):
            self.artifacts[relative(canonical)] = digest
        if execution:
            require(str(path) not in self.execution or self.execution[str(path)] == digest,
                    "execution file identity conflicts")
            self.execution[str(path)] = digest
        return digest

    def closure(self, mapping):
        require(type(mapping) is dict, "input closure is not a dictionary")
        for filename, digest in mapping.items():
            self.bind(Path(filename), digest)

    def finish(self):
        require(all(sha(path) == digest for path, digest in self.paths.items()),
                "artifact or runtime input changed during authentication/comparison")


def runtime(audit, record, base):
    """The frozen ready.authenticate_execution predicates with memoized hashes."""
    current, old = record["execution"], base["execution"]
    binary, old_binary = record["command"][0], base["command"][0]
    require({path: digest for path, digest in current["files"].items() if path != binary} ==
            {path: digest for path, digest in old["files"].items() if path != old_binary},
            "noncompiler execution identity changed")
    require(current["files"].get(binary) == record["input_sha256"].get(binary),
            "compiler runtime/input identities disagree")
    require(current["environment"] ==
            {**old["environment"], "PATH": str(Path(binary).parent) + ":/usr/bin:/bin"} and
            {key: value for key, value in current.items() if key not in {"files", "environment"}} ==
            {key: value for key, value in old.items() if key not in {"files", "environment"}},
            "controlled runtime environment/platform/GPU identity changed")
    for filename, digest in current["files"].items():
        audit.bind(Path(filename), digest, execution=True)


def cached_closure(profile, cached):
    """Require every cached declared artifact within the already audited seal."""
    for filename, digest in cached.get("artifact_sha256", {}).items():
        path = (ROOT / filename).resolve()
        require(path.is_relative_to(ROOT) and profile["input_sha256"].get(str(path)) == digest,
                "cached artifact is not closed by the exact current profile: " + filename)
    for filename, digest in cached.get("input_sha256", {}).items():
        require(profile["input_sha256"].get(filename) == digest,
                "cached input is not closed by the exact current profile: " + filename)
    for filename, digest in cached.get("output_sha256", {}).items():
        require(profile["input_sha256"].get(filename) == digest,
                "cached output is not closed by the exact current profile: " + filename)


def context(audit):
    audit.bind(Path(__file__).resolve())
    audit.bind(PROFILE, PROFILE_SHA)
    profile = read(PROFILE)
    require(len(profile["input_sha256"]) == SEALED_INPUT_COUNT, "sealed input count changed")
    audit.closure(profile["input_sha256"])
    for path, digest in ((SOURCE, SOURCE_SHA), (CONTROL, CONTROL_SHA), (SEAL, SEAL_SHA),
                         (PURE_HELPER, PURE_HELPER_SHA), (HERE / "route.py", RUNNER_SHA),
                         (G8_HELPER, G8_HELPER_SHA), (FULL / "comparison.json", FULL_PROOF_SHA)):
        audit.bind(path, digest)
        require(profile["input_sha256"].get(str(path)) == digest, "profile omits a pinned cached input")
    seal = module_at(SEAL, "first_fast_initial_seal_primitives")
    g8 = module_at(G8_HELPER, "first_fast_lossless_graph_primitives")
    base, source, control = read(FULL / "run.json"), read(SOURCE), read(CONTROL)
    full_proof, list_proof = read(FULL / "comparison.json"), read(LIST / "comparison.json")
    for cached in (source, control, base, full_proof, list_proof):
        cached_closure(profile, cached)
    require(source["base_commit"] == BASE_COMMIT and source["result_commit"] == RESULT_COMMIT and
            source["clean_committed_checkout_at_freeze"] is True and
            source["unchanged_655_implementation_except_declared_delta"] is True and
            source["parent_qualification_inherited"] is False and
            source["binary_sha256"] == audit.bind(HERE / "nextpnr-mistral") and
            source["source_archive_sha256"] == audit.bind(HERE / "source.tar.gz"),
            "pinned cached source identity changed")
    require(control["completed"] is True and type(control["exit_code"]) is int and control["exit_code"] == 0 and
            control["compiler_commit"] == RESULT_COMMIT and control["base_compiler_commit"] == BASE_COMMIT and
            control["source_identity_sha256"] == SOURCE_SHA and
            control["source_archive_sha256"] == source["source_archive_sha256"] and
            control["binary_sha256"] == source["binary_sha256"] and
            control["modules_equivalent"] is True and control["original_module_dictionaries_identical"] is True and
            control["all_transform_options_disabled"] is True and control["actual_pll_clock_vectors_preserved"] is True and
            control["parent_qualification_inherited"] is False,
            "cached positive disabled-loader proof differs from the pinned producer")
    require(base["completed"] is True and base["exit_code"] == 0 and base["compiler_commit"] == g8.RESULT_COMMIT and
            full_proof["candidate_completed"] is True and full_proof["graph_proof_available"] is True and
            full_proof.get("structural_rejection") is None and full_proof["final_metadata_stable_during_comparison"] is True and
            list_proof["candidate_completed"] is True and list_proof["partial_graph_evidence_available"] is True and
            list_proof["graph_proof_available"] is False and list_proof["final_metadata_stable_during_comparison"] is True and
            source["cached_accepted_g8_full_proof_sha256"] == FULL_PROOF_SHA,
            "cached measured/listing proof identities or claim boundaries changed")
    old = base["experimental_placed_reduction"].split()
    require(len(old) == 3 and old[1:] == ["6", "0"], "accepted eleven stage changed")
    aliases = {
        "schema": 1, "scope": "same-phase baseline and fresh eleven-literal listing only",
        "base_compiler_commit": BASE_COMMIT, "compiler_commit": RESULT_COMMIT,
        "reference_full": str(FULL), "reference_listing": str(LIST),
        "source_identity_sha256": SOURCE_SHA, "disabled_control_sha256": CONTROL_SHA,
        "experiment_plan_sha256": seal.PLAN_SHA, "local_plan": base["remap_plan"],
        "eleven_stage": {"root": old[0], "radius": 6, "minimum_branch_gain_ps": 250},
        "parent_qualification_inherited": False, "selected_ordinal_allowed": False,
        "default_recipe_selected": False, "hardware_tested": False,
    }
    require(set(profile) == set(aliases) | {"input_sha256"} and
            all(profile[key] == value for key, value in aliases.items()) and
            read(HERE / "local-plan.json") == base["remap_plan"], "exact profile aliases/local plan changed")
    runtime(audit, control, base)
    return profile, g8, base, source, control, seal


def completed_phase(audit, ctx, expected):
    profile, _, base, source, _, seal = ctx
    folder = BASELINE if expected == "baseline-placement" else LISTING
    for name in ("run.json", "route.log", "placed.json"):
        audit.bind(folder / name)
    record, log = read(folder / "run.json"), (folder / "route.log").read_text()
    specs = seal.specifications(base, expected)
    diagnostics = seal.expected_diagnostic_environment(base, expected)
    inputs = {**profile["input_sha256"], str(PROFILE): PROFILE_SHA}
    if expected == "list-eleven":
        inputs.update({str(BASELINE / name): audit.bind(BASELINE / name)
                       for name in ("run.json", "route.log", "placed.json")})
    identity = f"base_commit={BASE_COMMIT}; experimental_source_sha256={source['source_archive_sha256']}; sha256={source['binary_sha256']}"
    require(record["phase"] == expected and record["command"] == seal.expected_command(base, expected) and
            record["diagnostic_environment"] == diagnostics and record["placed_reduction_plan"] == specs and
            record["experimental_placed_reduction"] == diagnostics.get("NEXTPNR_MISTRAL_PLACED_REDUCTION", "") and
            record["experimental_capture_locality"] == base["experimental_capture_locality"] and
            record["compiler_commit"] == RESULT_COMMIT and record["base_compiler_commit"] == BASE_COMMIT and
            record["measured_compiler_commit"] == base["compiler_commit"] and
            record["profile_sha256"] == PROFILE_SHA and record["runner_sha256"] == RUNNER_SHA and
            record["source_identity_sha256"] == SOURCE_SHA and
            record["source_archive_sha256"] == source["source_archive_sha256"] and
            record["disabled_control_sha256"] == CONTROL_SHA and record["tool_identity"] == identity and
            record["reference_run_sha256"] == audit.bind(FULL / "run.json") and
            record["remap_plan"] == base["remap_plan"] and
            record["remap_plan_sha256"] == audit.bind(HERE / "local-plan.json") and
            record["input_sha256"] == inputs and record["cwd"] == base["cwd"] and
            record["parent_qualification_inherited"] is False and record["compiler_bytes_unchanged"] is False and
            record["list_only"] is True and record["fresh_listing"] is True and
            record["decomposition_selection"] is None and record["decomposition_report_sha256"] is None and
            record["reduction_selection"] == (-1 if expected == "list-eleven" else None) and
            record["hardware_acceptance"] is False,
            "actual phase command/profile/source/environment/dependency aliases changed")
    require(record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0 and not any(key in record for key in
            ("failure", "exit_code_is_adapter_sentinel", "fmax", "final_reported_hold_violations")),
            "actual phase is not finalized successful placement-only evidence")
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            not any(marker in log for marker in
                    ("Info: Decomposition", "Running the GPU router", "Running signoff timing analysis")) and
            not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
            "phase failed or ran a later transform/router/final output")
    if expected == "baseline-placement":
        require(specs == [] and "NEXTPNR_MISTRAL_PLACED_REDUCTION" not in diagnostics and
                not any(marker in log for marker in ("Placed reduction", "Placed-reduction", "Balanced three-LUT reduction")),
                "fresh baseline already ran a placed reduction")
    else:
        require(len(specs) == 1 and specs[0]["candidate"] == -1 and specs[0]["radius"] == 6 and
                specs[0]["minimum_branch_gain_ps"] == 250 and not any(marker in log for marker in
                ("Placed reduction stage ", "Placed-reduction", "Placed reduction minimum branch gain:",
                 "Placed reduction geometry probes:")), "sole default250 listing/header grammar changed")
    runtime(audit, record, base)
    return record, {"phase": expected, "folder": folder, "specs": specs,
                    "command": record["command"], "environment": diagnostics}, log


def pure_functions(audit):
    # Lazy by design: importing this module from a later seal never imports b9b.
    pure = module_at(PURE_HELPER, "first_fast_frozen_pure_graph_checks")
    require(Path(pure.seal.__file__).resolve() == SEAL and pure.HERE == HERE and
            audit.bind(PURE_HELPER, PURE_HELPER_SHA) == PURE_HELPER_SHA and
            audit.bind(SEAL, SEAL_SHA) == SEAL_SHA,
            "pure helper bound a different seal module; no global patch is permitted")
    return pure


def comparison():
    audit = Audit()
    ctx = context(audit)
    profile, g8, base, source, _, _ = ctx
    before, _, before_log = completed_phase(audit, ctx, "baseline-placement")
    record, phase, log = completed_phase(audit, ctx, "list-eleven")
    pure = pure_functions(audit)
    accepted_log = (LIST / "route.log").read_text()
    metrics = [g8.previous.PLACEMENT_METRICS.findall(value) for value in (before_log, log, accepted_log)]
    require(len(metrics[0]) == 71 and metrics[0] == metrics[1] == metrics[2],
            "fresh baseline/listing/accepted ordinary placement metrics changed")
    before_top, after_top = pure.top(g8, BASELINE), pure.top(g8, LISTING)
    restored = pure.restored_graph(g8, before_top, after_top)
    retained = pure.retained_stack(g8, before_log, log, accepted_log)
    spec = phase["specs"][0]
    cube = pure.conditional_cube(g8, before_top, spec["root"])
    closure = pure.endpoint_closure(g8, before_top, spec["root"])
    fresh = pure.qualification(log, spec, closure["endpoint_count"])
    audit.finish()
    return {
        "phase": "list-eleven", "status": "fresh eleven-literal listing; exact named rollback; conditional truth only",
        "compiler_commit": source["result_commit"], "base_compiler_commit": BASE_COMMIT,
        "profile_sha256": PROFILE_SHA, "new_disabled_control_sha256": CONTROL_SHA,
        "source_identity_sha256": SOURCE_SHA, "candidate_completed": True,
        "elapsed_seconds": record["elapsed_seconds"],
        "generator": {"path": relative(Path(__file__)), "sha256": audit.artifacts[relative(Path(__file__))],
                      "pure_helper_path": relative(PURE_HELPER), "pure_helper_sha256": PURE_HELPER_SHA},
        "flat_cached_authentication": {"sealed_profile_inputs": len(profile["input_sha256"]),
                                       "each_unique_input_hashed_once_on_entry": True,
                                       "final_all_artifact_and_runtime_rehash": True,
                                       "cached_source_control_archive_proofs_replayed": False,
                                       "old_recursive_profile_authenticators_called": False},
        "baseline_reference": {"folder": relative(BASELINE), "compiler_commit": before["compiler_commit"],
                               "run_sha256": audit.artifacts[relative(BASELINE / "run.json")],
                               "log_sha256": audit.artifacts[relative(BASELINE / "route.log")],
                               "placed_sha256": audit.artifacts[relative(BASELINE / "placed.json")],
                               "no_placed_reduction_or_ac_enabled": True},
        "parent_qualification_inherited": False, "qualified_eleven_ordinals": fresh["qualified_ordinals"],
        "qualified_twelve_ordinals": [], "qualified_ac_ordinals": [],
        "graph_proof_available": False, "partial_graph_evidence_available": True,
        "route_started": False, "timing_acceptance_available": False,
        "matched_placement_metrics": 71, "placement_metrics_identical": True,
        "placement_metrics_sha256": hashlib.sha256("\n".join(metrics[0]).encode()).hexdigest(),
        "restored_listing": restored, "retained_stack": retained, "conditional_eleven_literal_cube": cube,
        "actual_endpoint_closure": closure, "qualification": fresh,
        "cached_old_comparisons_reexecuted": False, "default_recipe_selected": False, "hardware_tested": False,
        "fresh_execution_identities_authenticated": True, "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_metadata_stable_during_comparison": True,
        "proof_limitations": [
            "Exact pinned positive source/control proofs and their 242-input seal are authenticated, not re-proved from source archives.",
            "Rollback uses this producer's actual fresh unbalanced baseline rather than the old balanced g8 listing.",
            "The 2048 raw-mask rows assume every unexported LUT and boundary logical pin state is plain signal.",
            "Named dictionaries/native consumers/export order are proved; indexed slots/free lists, owner pointers/buckets and current physical pins are not serialized.",
            "No route-created BUF, setup/hold, RBF, hardware or applied-stage acceptance is claimed; later stages need fresh proofs.",
        ],
        "artifact_sha256": dict(sorted(audit.artifacts.items())),
    }


def authenticate_cached_first(expected_proof_sha):
    """Authenticate the flat proof for later drafts without replaying its checks."""
    require(type(expected_proof_sha) is str and DIGEST.fullmatch(expected_proof_sha),
            "a concrete finalized first-fast proof SHA must be pinned")
    audit = Audit()
    ctx = context(audit)
    profile, g8, base, source, control, _ = ctx
    before, _, _ = completed_phase(audit, ctx, "baseline-placement")
    record, _, _ = completed_phase(audit, ctx, "list-eleven")
    audit.bind(OUTPUT, expected_proof_sha)
    proof = read(OUTPUT)
    require(proof["phase"] == "list-eleven" and proof["candidate_completed"] is True and
            proof["final_metadata_stable_during_comparison"] is True and
            proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False and
            proof["route_started"] is False and proof["timing_acceptance_available"] is False and
            proof["profile_sha256"] == PROFILE_SHA and proof["source_identity_sha256"] == SOURCE_SHA and
            proof["new_disabled_control_sha256"] == CONTROL_SHA and proof["compiler_commit"] == RESULT_COMMIT and
            proof["base_compiler_commit"] == BASE_COMMIT and proof["parent_qualification_inherited"] is False and
            proof["generator"] == {"path": relative(Path(__file__)), "sha256": audit.bind(Path(__file__).resolve()),
                                  "pure_helper_path": relative(PURE_HELPER), "pure_helper_sha256": PURE_HELPER_SHA} and
            proof["cached_old_comparisons_reexecuted"] is False and proof["matched_placement_metrics"] == 71 and
            proof["placement_metrics_identical"] is True,
            "cached first-fast proof generator/identity/claim limits changed")
    for filename, digest in proof["artifact_sha256"].items():
        audit.bind(ROOT / filename, digest)
    for filename, digest in proof["execution_file_sha256"].items():
        audit.bind(Path(filename), digest, execution=True)
    expected_artifacts = {name: digest for name, digest in audit.artifacts.items() if name != relative(OUTPUT)}
    require(proof["artifact_sha256"] == expected_artifacts and proof["execution_file_sha256"] == audit.execution and
            proof["qualified_eleven_ordinals"] == proof["qualification"]["qualified_ordinals"] ==
            list(range(proof["qualification"]["qualified_candidates"])),
            "cached proof does not exactly close the current inputs/runtime/fresh ordinal sequence")
    audit.finish()
    return profile, g8, base, source, control, before, record, proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", nargs="?", type=Path, default=LISTING)
    args = parser.parse_args()
    require(args.folder.resolve() == LISTING, "only the actual initial fresh eleven listing is supported")
    require(not OUTPUT.exists(), "first-fast proof already exists")
    result = comparison()
    OUTPUT.parent.mkdir(exist_ok=True)
    with OUTPUT.open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({key: result[key] for key in
                      ("phase", "candidate_completed", "graph_proof_available", "qualified_eleven_ordinals")}, indent=2))


if __name__ == "__main__":
    main()
