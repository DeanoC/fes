"""Root-only same-phase placement control or fresh eleven-literal listing."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
import seal_profile as seal


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=seal.PHASES, required=True)
    args = parser.parse_args()
    profile, g8, base, source, _ = seal.load_profile()
    folder = seal.phase_folder(args.phase, -1 if args.phase == "list-eleven" else None)
    seal.require(not folder.exists(), "phase output already exists")
    inputs = seal.sealed_input_map(profile, args.phase)
    module = Path(base["cwd"])
    sys.path.insert(0, str(module))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    from scripts.search_placer_qor import has_failed_route_arc
    binary = seal.HERE / "nextpnr-mistral"
    identity = f"base_commit={seal.BASE}; experimental_source_sha256={seal.sha(seal.HERE / 'source.tar.gz')}; sha256={source['binary_sha256']}"
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, identity)}, 1)
    try:
        seal.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                     "ambient compiler diagnostic environment")
        diagnostics = seal.expected_diagnostic_environment(base, args.phase)
        env = {**invocation.env, **diagnostics}
        record = {**base, "kind": "generic narrow-search same-phase control/fresh eleven qualification; unselected",
                  "phase": args.phase, "command": seal.expected_command(base, args.phase),
                  "diagnostic_environment": diagnostics, "placed_reduction_plan": seal.specifications(base, args.phase),
                  "experimental_placed_reduction": diagnostics.get("NEXTPNR_MISTRAL_PLACED_REDUCTION", ""),
                  "reduction_selection": -1 if args.phase == "list-eleven" else None,
                  "decomposition_selection": None, "decomposition_report_sha256": None,
                  "parent_qualification_inherited": False, "compiler_bytes_unchanged": False,
                  "base_compiler_commit": seal.BASE, "compiler_commit": source["result_commit"],
                  "measured_compiler_commit": base["compiler_commit"],
                  "source_identity_sha256": seal.sha(seal.HERE / "source-identity.json"),
                  "source_archive_sha256": seal.sha(seal.HERE / "source.tar.gz"),
                  "disabled_control_sha256": seal.sha(seal.HERE / "disabled-control/comparison.json"),
                  "runner_sha256": seal.sha(Path(__file__)), "profile_sha256": seal.sha(seal.PROFILE),
                  "reference_run_sha256": seal.sha(seal.FULL / "run.json"),
                  "remap_plan_sha256": seal.sha(seal.LOCAL_PLAN), "tool_identity": identity,
                  "list_only": True, "fresh_listing": True, "execution": invocation.inputs,
                  "input_sha256": inputs, "completed": False, "hardware_acceptance": False}
        for key in ("elapsed_seconds", "exit_code", "failure", "fmax", "final_reported_hold_violations",
                    "exit_code_is_adapter_sentinel"):
            record.pop(key, None)
        seal.authenticate_phase(record)
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
        try:
            with (folder / "route.log").open("x") as log:
                result = audited_run(record["command"], source_root=module, cwd=module, env=env,
                                     stdout=log, stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"] = result.returncode
            record["elapsed_seconds"] = time.monotonic() - started
            invocation.verify()
            seal.require(all(seal.sha(Path(name)) == digest for name, digest in inputs.items()), "phase input changed")
            log = (folder / "route.log").read_text()
            seal.require(result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log),
                         "phase did not finish normally")
            seal.require((folder / "placed.json").exists() and "Decomposition" not in log and
                         "Running the GPU router" not in log and "Running signoff timing analysis..." not in log and
                         not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
                         "unselected phase produced route/AC/final outputs")
            if args.phase == "baseline-placement":
                seal.require("Placed reduction" not in log and "Placed-reduction" not in log,
                             "baseline executed placed reduction")
            else:
                seal.require("Placed reduction minimum branch gain:" not in log,
                             "initial eleven listing changed the default250 minimum")
            record["completed"] = True
            print(json.dumps({key: record[key] for key in ("phase", "elapsed_seconds", "completed", "exit_code")}, indent=2))
        except BaseException as error:
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
