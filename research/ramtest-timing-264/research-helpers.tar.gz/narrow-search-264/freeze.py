"""Root-operated committed three-file narrow-search freeze.

Only cached parent authenticators are called. No old comparison/main, build,
route or qualification is replayed. Post-freeze authentication uses frozen
objects and Git objects, never the producer binaries that may later be rebuilt.
Root must pin HOST_VALIDATION_SHA after final passing validation, before use.
"""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SRC = ROOT / "sources/misteross/build/toolchain-ramtest-timing/src/nextpnr"
BUILD = ROOT / "sources/misteross/build/toolchain-ramtest-timing/build/nextpnr"
PARENT = HERE.parent / "placed12-minimum-264"
G8 = HERE.parent / "ready-g8-decomposition-264"
BASE = "6552942de15ed48e1bb9fbc71e3c08f189486313"
MEASURED = "6ad210a60991f93a607ac4490d6282b1267ec64a"
CUMULATIVE_BASE = "91f3ad1bd8bbebd09e5a7ffb92e5026c5558e771"
HOST_VALIDATION = HERE / "validation/host-validation.json"
HOST_VALIDATION_SHA = "49d0ba11c780e8c241f9500a2569a414c080d09fe09b153138a37696803dc450"
PLAN = HERE / "experiment-plan.json"
PLAN_SHA = "a9916fce5a69ba1f5ab9e80331d5ecac86ab8181000323a7c7bd3ef74ac959a2"
CHANGED = {"mistral/placed_reduction.cc", "mistral/reduction_balance.md", "mistral/tests/placed_reduction.cc"}
REGRESSION_CASES = {
    "NarrowSearchTest.FutureAlut2ArcsChooseTheActualFasterFirstTuple",
    "NarrowSearchTest.BlockedOriginalUpgradesStillReachTwoSameLabAlms",
}
PARENT_FILES = {
    "freeze.py": "f4576e7829bc92c6862d15200d345a28651b0d22005cc2c81c8e991ebd770898",
    "check_disabled_control.py": "f8a5e0c2c1f02260331880b682dd1ba2f67333b505ee979aa5d338c654c10df1",
    "source-identity.json": "fd475c47e32fc6595168d8c130b0573a53e6d86a9d588f844291a61256f2a693",
    "disabled-control/comparison.json": "39d335aa9cc72ba297b5b2b372e51bb92222427b3c836910c4a88303270a235c",
    "disabled-control/candidate.json": "4d9333b4ce26872c6a77ff24b699e361b498b0c2cb7193dcaf87b5eedf5a0835",
    "list-reduction/comparison.json": "750971e50c611efdf7c0db909f50630a645dcacb4872b0f391899b3b4756a0b6",
    "list-ac-r0/comparison.json": "af4ab4f5e229ce846587e2fd86e16ef42f7fc1f85517138d35c33d53457beab2",
}
FULL = G8 / "route-c0/comparison.json"
FULL_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
G8_HELPER = G8 / "compare_control_decomposition.py"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata value: " + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def git(*args, text=True):
    return subprocess.check_output(["git", *args], cwd=SRC, text=text)


def add_input(inputs, path, expected):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT) and digest(expected) and sha(path) == expected,
            "frozen input changed: " + str(path))
    require(str(path) not in inputs or inputs[str(path)] == expected, "input digest collision: " + str(path))
    inputs[str(path)] = expected


def load_pinned(path, expected, name):
    require(sha(path) == expected, "cached helper changed: " + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_parent = load_pinned(PARENT / "freeze.py", PARENT_FILES["freeze.py"], "sealed_narrow_parent_freeze")


def archive_payloads(path, expected):
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        require(len(members) == len(expected) and all(member.isfile() for member in members) and
                {member.name for member in members} == set(expected), "archive member set differs: " + str(path))
        payloads = {member.name: archive.extractfile(member).read() for member in members}
    require(all(hashlib.sha256(payload).hexdigest() == expected[name] for name, payload in payloads.items()),
            "archive payload differs: " + str(path))
    return payloads


def parent_source():
    """Authenticate cached 655/g8 records without replaying comparisons."""
    inputs = {}
    for name, expected in PARENT_FILES.items():
        add_input(inputs, PARENT / name, expected)
    parent = _parent.authenticate_freeze()
    require(parent["result_commit"] == BASE and parent["measured_base_commit"] == MEASURED and
            parent["cumulative_base_commit"] == CUMULATIVE_BASE and set(parent["source_sha256"]) == CHANGED,
            "cached 655 source identity is not the declared parent")
    for path, expected in parent["input_sha256"].items():
        add_input(inputs, path, expected)
    for name, expected in (("nextpnr-mistral", parent["binary_sha256"]),
                           ("source.tar.gz", parent["source_archive_sha256"]),
                           ("change.patch", parent["change_patch_sha256"])):
        add_input(inputs, PARENT / name, expected)
    control_helper = load_pinned(PARENT / "check_disabled_control.py", PARENT_FILES["check_disabled_control.py"],
                                 "sealed_narrow_parent_control")
    control_source, control = control_helper.authenticate_control()
    require(control_source == parent and control["compiler_commit"] == BASE and
            control["candidate_sha256"] == PARENT_FILES["disabled-control/candidate.json"],
            "cached 655 disabled control differs from the parent source")
    for mapping in (control["input_sha256"], control["output_sha256"]):
        for path, expected in mapping.items():
            add_input(inputs, path, expected)
    for phase, filename in (("list-reduction", "list-reduction/comparison.json"),
                            ("list-ac", "list-ac-r0/comparison.json")):
        proof = read(PARENT / filename)
        require(proof["phase"] == phase and proof["compiler_commit"] == BASE and
                proof["candidate_completed"] is True and proof["final_metadata_stable_during_comparison"] is True and
                proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False and
                proof["parent_qualification_inherited"] is False,
                "cached parent listing is not the finalized partial phase: " + phase)
        for path, expected in proof["artifact_sha256"].items():
            add_input(inputs, ROOT / path, expected)
    add_input(inputs, FULL, FULL_SHA)
    add_input(inputs, G8_HELPER, G8_HELPER_SHA)
    full = read(FULL)
    require(full["graph_proof_available"] is True and full["final_metadata_stable_during_comparison"] is True,
            "cached accepted g8 structural proof is incomplete")
    for path, expected in full["artifact_sha256"].items():
        add_input(inputs, ROOT / path, expected)
    # No failed minimum full-route result is admitted as an acceptance input.
    return parent, inputs


def host_validation(source_hashes=None):
    require(digest(HOST_VALIDATION_SHA), "root must pin the final HOST_VALIDATION_SHA before execution")
    require(sha(HOST_VALIDATION) == HOST_VALIDATION_SHA and sha(PLAN) == PLAN_SHA,
            "root validation or predeclared plan changed")
    validation, plan = read(HOST_VALIDATION), read(PLAN)
    require(validation["delta_base_commit"] == BASE and type(validation["result_commit"]) is str and
            re.fullmatch(r"[0-9a-f]{40}", validation["result_commit"]) and validation["result_commit"] != BASE and
            set(validation["source_sha256"]) == CHANGED and
            all(digest(value) for value in validation["source_sha256"].values()) and
            digest(validation["binary_sha256"]) and digest(validation["test_binary_sha256"]),
            "host validation source/binary identity is malformed")
    if source_hashes is not None:
        require(validation["source_sha256"] == source_hashes, "host validation source bytes differ")
    require(validation["build_passed"] is True and validation["clean_committed_checkout"] is True and
            validation["build_performed_before_commit_with_identical_committed_file_bytes"] is True and
            set(validation["build_targets"]) == {"nextpnr-mistral", "nextpnr-mistral-test"} and
            type(validation["backend_tests"]) is int and validation["backend_tests"] >= 37 and
            type(validation["backend_passed"]) is int and validation["backend_passed"] == validation["backend_tests"] and
            type(validation["backend_exit_code"]) is int and validation["backend_exit_code"] == 0 and
            type(validation["new_regression_cases"]) is list and len(validation["new_regression_cases"]) == 2 and
            set(validation["new_regression_cases"]) == REGRESSION_CASES and validation["diff_check"] == "pass" and
            type(validation["independent_review"]) is str and validation["independent_review"] and
            type(validation["cli_suite_executed_for_this_delta"]) is bool and
            validation["experiment_plan_sha256"] == PLAN_SHA and validation["default_recipe_selected"] is False and
            validation["hardware_tested"] is False and validation["new_timing_gain_proved"] is False,
            "root validation does not bind reviewed passing current builds and both new regressions")
    require(plan["schema"] == 1 and plan["base_compiler_commit"] == BASE and
            plan["accepted_reference"] == "ready-g8-decomposition-264/route-c0" and
            plan["accepted_memory_mhz"] == 116.27906799316406 and plan["new_timing_gain_proved"] is False and
            plan["default_recipe_selected"] is False and plan["hardware_tested"] is False,
            "predeclared narrow-search experiment identity differs")
    inputs = {}
    add_input(inputs, HOST_VALIDATION, HOST_VALIDATION_SHA)
    artifacts = validation["artifact_sha256"]
    require(type(artifacts) is dict and artifacts.get(str(PLAN.relative_to(ROOT))) == PLAN_SHA,
            "host validation does not bind the predeclared plan")
    logs = []
    for name, expected in artifacts.items():
        path = (ROOT / name).resolve()
        require(str(path.relative_to(ROOT)) == name and
                (path == PLAN or path.is_relative_to(HOST_VALIDATION.parent) and path.suffix == ".log"),
                "unexpected host validation artifact: " + name)
        add_input(inputs, path, expected)
        if path.suffix == ".log":
            logs.append(path)
    require(len(logs) >= 2, "host validation must bind current build and backend logs")
    backend_logged = False
    for path in logs:
        log = path.read_text()
        totals = re.findall(r"^\[==========\] (?:Running )?(\d+) tests from .+$", log, re.M)
        passed = re.findall(r"^\[  PASSED  \] (\d+) tests\.$", log, re.M)
        cases = all(re.search(r"^\[ RUN      \] " + re.escape(name) + r"$", log, re.M) and
                    re.search(r"^\[       OK \] " + re.escape(name) + r" \(\d+ ms\)$", log, re.M)
                    for name in REGRESSION_CASES)
        backend_logged |= (len(totals) == 2 and all(int(count) == validation["backend_tests"] for count in totals) and
                           passed == [str(validation["backend_passed"])] and cases and "[  FAILED  ]" not in log)
    require(backend_logged, "bound backend log does not show the exact passing count and both new regressions")
    return validation, inputs


def committed_delta(result, hashes, parent):
    require(git("rev-parse", BASE + "^{commit}").strip() == BASE and
            git("rev-parse", BASE + "^{tree}").strip() == parent["source_tree_git_id"],
            "Git parent differs from the frozen 655 source tree")
    subprocess.run(["git", "merge-base", "--is-ancestor", BASE, result], cwd=SRC, check=True)
    require(set(git("diff", "--name-only", "--no-renames", BASE, result, "--").splitlines()) == CHANGED,
            "committed delta is not exactly the three authorized files")
    for name in sorted(CHANGED):
        require(hashlib.sha256(git("show", f"{BASE}:{name}", text=False)).hexdigest() == parent["source_sha256"][name] and
                hashlib.sha256(git("show", f"{result}:{name}", text=False)).hexdigest() == hashes[name],
                "Git source bytes differ from the frozen parent or current validation: " + name)
    return git("diff", "--binary", "--no-ext-diff", "--no-textconv", BASE, result, "--", text=False)


def authenticate_freeze():
    """Read-only sealed API; a subsequent producer rebuild is irrelevant."""
    parent, parent_inputs = parent_source()
    source = read(HERE / "source-identity.json")
    validation, host_inputs = host_validation(source["source_sha256"])
    result = validation["result_commit"]
    require(source["base_commit"] == source["delta_base_commit"] == BASE and source["result_commit"] == result and
            source["measured_base_commit"] == MEASURED and source["cumulative_base_commit"] == CUMULATIVE_BASE and
            source["source_tree_git_id"] == git("rev-parse", result + "^{tree}").strip() and
            source["changed_files"] == sorted(CHANGED) and source["binary_sha256"] == validation["binary_sha256"] and
            source["validated_test_binary_sha256"] == validation["test_binary_sha256"] and
            source["clean_committed_checkout_at_freeze"] is True and source["unchanged_655_implementation_except_declared_delta"] is True and
            source["parent_source_identity_sha256"] == PARENT_FILES["source-identity.json"] and
            source["cached_parent_initial_proof_sha256"] == PARENT_FILES["list-reduction/comparison.json"] and
            source["cached_parent_applied_listing_proof_sha256"] == PARENT_FILES["list-ac-r0/comparison.json"] and
            source["cached_accepted_g8_full_proof_sha256"] == FULL_SHA and
            source["cached_comparison_helpers_reexecuted"] is False and source["parent_qualification_inherited"] is False,
            "source identity differs from the validated committed narrow-search delta")
    require(sha(HERE / "nextpnr-mistral") == source["binary_sha256"] and
            sha(HERE / "source.tar.gz") == source["source_archive_sha256"] and
            sha(HERE / "change.patch") == source["change_patch_sha256"], "new frozen binary/archive/patch changed")
    archive_payloads(HERE / "source.tar.gz", source["source_sha256"])
    require(hashlib.sha256(committed_delta(result, source["source_sha256"], parent)).hexdigest() == source["change_patch_sha256"],
            "frozen patch differs from the exact committed delta")
    expected_inputs = dict(parent_inputs)
    for path, expected in host_inputs.items():
        add_input(expected_inputs, path, expected)
    add_input(expected_inputs, Path(__file__).resolve(), sha(Path(__file__).resolve()))
    require(source["input_sha256"] == expected_inputs and source["host_validation_sha256"] == HOST_VALIDATION_SHA and
            source["preserved_parent_delta_sha256"] == parent["preserved_parent_delta_sha256"],
            "new freeze omits or changes its cached parent/host/helper closure")
    return source


def freeze():
    parent, inputs = parent_source()
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json", "change.patch")),
            "new freeze artifacts already exist")
    validation, host_inputs = host_validation()
    result = validation["result_commit"]
    require(git("rev-parse", "HEAD^{commit}").strip() == result and
            not git("status", "--porcelain", "--untracked-files=all").strip(), "compiler checkout is not the clean validated committed HEAD")
    payloads = {name: git("show", f"{result}:{name}", text=False) for name in sorted(CHANGED)}
    hashes = {name: hashlib.sha256(payload).hexdigest() for name, payload in payloads.items()}
    require(hashes == validation["source_sha256"], "committed source differs from passing host validation")
    patch = committed_delta(result, hashes, parent)
    require(all((SRC / name).is_file() and not (SRC / name).is_symlink() and (SRC / name).read_bytes() == payload
                for name, payload in payloads.items()), "working source differs from committed HEAD")
    producer, test_producer = BUILD / "nextpnr-mistral", BUILD / "nextpnr-mistral-test"
    require(producer.is_file() and not producer.is_symlink() and test_producer.is_file() and not test_producer.is_symlink() and
            sha(producer) == validation["binary_sha256"] and sha(test_producer) == validation["test_binary_sha256"],
            "root-built binaries differ from current passing validation")
    for path, expected in host_inputs.items():
        add_input(inputs, path, expected)
    add_input(inputs, Path(__file__).resolve(), sha(Path(__file__).resolve()))
    shutil.copy2(producer, HERE / "nextpnr-mistral")
    require(sha(HERE / "nextpnr-mistral") == validation["binary_sha256"] == sha(producer) and
            sha(test_producer) == validation["test_binary_sha256"], "producer binaries changed while freezing")
    timestamp = int(git("show", "-s", "--format=%ct", result).strip())
    with tarfile.open(HERE / "source.tar.gz", "w:gz") as archive:
        for name, payload in payloads.items():
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = len(payload), 0o644, timestamp
            archive.addfile(member, io.BytesIO(payload))
    with (HERE / "change.patch").open("xb") as output:
        output.write(patch)
    require(git("rev-parse", "HEAD^{commit}").strip() == result and
            not git("status", "--porcelain", "--untracked-files=all").strip(), "checkout changed while freezing")
    require(all(sha(Path(path)) == expected for path, expected in inputs.items()), "frozen inputs changed while freezing")
    record = {"base_commit": BASE, "delta_base_commit": BASE, "result_commit": result,
              "measured_base_commit": MEASURED, "cumulative_base_commit": CUMULATIVE_BASE,
              "source_tree_git_id": git("rev-parse", result + "^{tree}").strip(), "changed_files": sorted(CHANGED),
              "source_sha256": hashes, "binary_sha256": validation["binary_sha256"],
              "source_archive_sha256": sha(HERE / "source.tar.gz"), "change_patch_sha256": sha(HERE / "change.patch"),
              "validated_test_binary_sha256": validation["test_binary_sha256"], "input_sha256": inputs,
              "host_validation_path": str(HOST_VALIDATION), "host_validation_sha256": HOST_VALIDATION_SHA,
              "parent_source_identity_sha256": PARENT_FILES["source-identity.json"],
              "cached_parent_initial_proof_sha256": PARENT_FILES["list-reduction/comparison.json"],
              "cached_parent_applied_listing_proof_sha256": PARENT_FILES["list-ac-r0/comparison.json"],
              "cached_accepted_g8_full_proof_sha256": FULL_SHA, "cached_comparison_helpers_reexecuted": False,
              "parent_qualification_inherited": False, "preserved_parent_delta_sha256": parent["preserved_parent_delta_sha256"],
              "clean_committed_checkout_at_freeze": True, "unchanged_655_implementation_except_declared_delta": True,
              "archive_scope": "Exactly3 changed committed payloads; remaining tree is bound by frozen655 parent tree/closure and exact base/result Git diff.",
              "producer_binary_path": str(producer), "branch": git("branch", "--show-current").strip(),
              "status": "Generic narrow-search experiment; fresh11/12/AC qualification and final route still required; no gain/default/package/hardware acceptance."}
    with (HERE / "source-identity.json").open("x") as output:
        output.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
    authenticate_freeze()
    print(json.dumps(record, indent=2), flush=True)


if __name__ == "__main__":
    freeze()
