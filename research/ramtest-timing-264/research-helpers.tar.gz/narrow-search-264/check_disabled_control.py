"""Root-operated disabled loader control for the frozen narrow-search delta.

Exact655 disabled bytes/modules are required. The source JSON has ordinary PLL
clock vectors, not duplicate outclk keys: both vector elements and direct users
are audited explicitly. No pack/place/route or transform is enabled.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location("narrow_search_freeze_source", HERE / "freeze.py")
_freeze = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_freeze)
ROOT, PARENT, G8, MEASURED = _freeze.ROOT, _freeze.PARENT, _freeze.G8, _freeze.MEASURED
sha, require, read, authenticate_freeze = _freeze.sha, _freeze.require, _freeze.read, _freeze.authenticate_freeze
MODULE = ROOT / "sources/misteross"
CONTROL = PARENT / "disabled-control/comparison.json"
CONTROL_SHA = _freeze.PARENT_FILES["disabled-control/comparison.json"]
ACCEPTED = PARENT / "disabled-control/candidate.json"
ACCEPTED_SHA = _freeze.PARENT_FILES["disabled-control/candidate.json"]


def load_reference(g8=None):
    """Use cached records and the pinned parser APIs; never replay comparisons."""
    _, inputs = _freeze.parent_source()
    old = read(CONTROL)
    require(old["completed"] is True and type(old["exit_code"]) is int and old["exit_code"] == 0 and
            old["compiler_commit"] == _freeze.BASE and old["candidate_sha256"] == ACCEPTED_SHA,
            "cached direct-parent disabled control is incomplete")
    if g8 is None:
        g8 = _freeze.load_pinned(_freeze.G8_HELPER, _freeze.G8_HELPER_SHA, "sealed_narrow_g8_netlist_parser")
    else:
        require(Path(g8.__file__).resolve() == _freeze.G8_HELPER and sha(_freeze.G8_HELPER) == _freeze.G8_HELPER_SHA,
                "supplied g8 parser is not the pinned module")
    expected = g8.read_netlist(ACCEPTED)["modules"]
    modules_sha = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    require(modules_sha == old["modules_sha256"], "cached parent normalized module dictionaries changed")
    return g8, old, expected, modules_sha, inputs


def expected_command(old):
    command = list(old["command"])
    require(command.count("--json") == command.count("--write") == command.count("--balance-reduction-root") == 1,
            "cached disabled command is ambiguous")
    source = Path(command[command.index("--json") + 1])
    selector = command[command.index("--balance-reduction-root") + 1]
    expected = [str(PARENT / "nextpnr-mistral"), "--json", str(source), "--device", "5CSEBA6U23I7",
                "--no-pack", "--no-place", "--no-route", "--balance-reduction-root", selector,
                "--write", str(PARENT / "disabled-control/candidate.json")]
    require(command == expected and source.is_relative_to(ROOT), "cached disabled command/input/options differ")
    command[0] = str(HERE / "nextpnr-mistral")
    command[-1] = str(HERE / "disabled-control/candidate.json")
    return source, command


def control_inputs(source_identity, reference_inputs, source):
    inputs = dict(reference_inputs)
    for path, expected in source_identity["input_sha256"].items():
        _freeze.add_input(inputs, path, expected)
    for path in (HERE / "nextpnr-mistral", HERE / "source.tar.gz", HERE / "source-identity.json", HERE / "change.patch",
                 HERE / "freeze.py", Path(__file__).resolve(), source):
        _freeze.add_input(inputs, path, sha(path))
    return inputs


def pll_clock_vectors(g8, modules):
    vectors, duplicates = {}, 0
    for module, top in modules.items():
        netlist = g8.Netlist(top["cells"], top["netnames"])
        duplicates += len(netlist.pll_ports)
        clocks = {}
        for name, cell in top["cells"].items():
            if cell["type"] != "altera_pll":
                continue
            count = cell["parameters"].get("number_of_clocks")
            outputs = cell["connections"].get("outclk")
            require(type(count) is str and count and set(count) <= {"0", "1"} and
                    type(outputs) is list and len(outputs) == int(count, 2) and len(outputs) > 0 and
                    all(type(bit) is int and bit >= 0 for bit in outputs) and len(set(outputs)) == len(outputs) and
                    cell["port_directions"].get("outclk") == "output", "malformed PLL clock vector: " + name)
            items = []
            for index, bit in enumerate(outputs):
                token = (name, "outclk", index)
                require(tuple(netlist.token(bit)) == token, "PLL vector element does not have its unique indexed driver")
                items.append({"index": index, "bit": bit, "driver": token,
                              "named_net_aliases": netlist.external_names.get(bit, ()),
                              "direct_consumers": netlist.direct_users.get(token, [])})
            clocks[name] = {"number_of_clocks": int(count, 2), "outclk": items}
        vectors[module] = clocks
    require(duplicates == 0, "disabled reference/current export unexpectedly has duplicate PLL keys")
    counts = [clock["number_of_clocks"] for clocks in vectors.values() for clock in clocks.values()]
    require(sorted(counts) == [1, 2], "disabled export no longer has the authenticated scalar/two-element PLL vectors")
    return json.loads(json.dumps({"duplicate_pll_export_count": duplicates, "clock_vectors": vectors,
                                 "two_output_vector_elements_and_consumers_preserved": True}))


def actual_modules(g8, expected):
    candidate = HERE / "disabled-control/candidate.json"
    require(sha(candidate) == ACCEPTED_SHA, "disabled actual export is not byte-identical to the parent control")
    actual = g8.read_netlist(candidate)["modules"]
    require(actual == expected, "disabled actual module dictionaries changed")
    before, after = pll_clock_vectors(g8, expected), pll_clock_vectors(g8, actual)
    require(before == after, "actual PLL vector outputs, aliases or indexed direct consumers changed")
    modules_sha = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return modules_sha, after


def tool_identity(source):
    return f"base_commit={source['base_commit']}; experimental_source_sha256={sha(HERE / 'source.tar.gz')}; sha256={sha(HERE / 'nextpnr-mistral')}"


def completed_log():
    log = (HERE / "disabled-control/loader.log").read_text()
    require("Info: Program finished normally." in log and not any(marker in log for marker in
            ("Running the GPU router", "Local remap", "Comb remap", "Decomposition", "Capture locality", "Placed reduction")),
            "disabled loader executed a transform or did not finish normally")


def authenticate_control(g8=None):
    """Read-only API returning (sealed source identity, completed control)."""
    source_identity = authenticate_freeze()
    g8, old, expected, modules_sha, reference_inputs = load_reference(g8)
    source, command = expected_command(old)
    inputs = control_inputs(source_identity, reference_inputs, source)
    output = HERE / "disabled-control"
    record = read(output / "comparison.json")
    require(record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and record["elapsed_seconds"] >= 0 and
            record["command"] == command and record["cwd"] == str(MODULE) and record["tool_identity"] == tool_identity(source_identity) and
            record["compiler_commit"] == source_identity["result_commit"] and record["base_compiler_commit"] == _freeze.BASE and
            record["measured_base_commit"] == MEASURED and record["source_identity_sha256"] == sha(HERE / "source-identity.json") and
            record["source_archive_sha256"] == sha(HERE / "source.tar.gz") and record["binary_sha256"] == source_identity["binary_sha256"] and
            record["reference_comparison_sha256"] == CONTROL_SHA and record["reference_sha256"] == ACCEPTED_SHA and
            record["cached_measured_full_proof_sha256"] == _freeze.FULL_SHA and
            record["cached_parent_initial_proof_sha256"] == _freeze.PARENT_FILES["list-reduction/comparison.json"] and
            record["cached_parent_applied_listing_proof_sha256"] == _freeze.PARENT_FILES["list-ac-r0/comparison.json"] and
            record["cached_comparison_helpers_reexecuted"] is False and record["parent_qualification_inherited"] is False and
            record["input_sha256"] == inputs and record["all_transform_options_disabled"] is True and
            record["root_selector_only_is_not_balance_reduction_enable"] is True and record["modules_equivalent"] is True and
            record["original_module_dictionaries_identical"] is True and record["exact_parent_export_bytes_preserved"] is True and
            record["actual_pll_clock_vectors_preserved"] is True and record["default_recipe_selected"] is False and record["hardware_tested"] is False,
            "completed disabled control differs from its frozen source/command/evidence contract")
    require(record["output_sha256"] == {str(output / name): sha(output / name) for name in ("candidate.json", "loader.log")} and
            record["candidate_sha256"] == ACCEPTED_SHA == sha(output / "candidate.json") and
            record["loader_log_sha256"] == sha(output / "loader.log"), "disabled outputs changed")
    completed_log()
    actual_sha, audit = actual_modules(g8, expected)
    require(record["modules_sha256"] == modules_sha == actual_sha and record["pll_clock_vector_audit"] == audit,
            "disabled normalized modules or actual PLL vector audit differs")
    base = read(G8 / "route-c0/run.json")
    require(read(_freeze.FULL)["artifact_sha256"].get(str((G8 / "route-c0/run.json").relative_to(ROOT))) == sha(G8 / "route-c0/run.json"),
            "cached full proof omits its runtime reference")
    g8.ready.authenticate_execution(record, base)
    require(not any(key.startswith("NEXTPNR_MISTRAL_") for key in record["execution"]["environment"]),
            "disabled execution has a transform environment")
    return source_identity, record


def main():
    source_identity = authenticate_freeze()
    g8, old, expected, modules_sha, reference_inputs = load_reference()
    source, command = expected_command(old)
    inputs = control_inputs(source_identity, reference_inputs, source)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    output = HERE / "disabled-control"
    require(not output.exists(), "new disabled-control output already exists")
    output.mkdir()
    identity = tool_identity(source_identity)
    record = {"command": command, "cwd": str(MODULE), "tool_identity": identity,
              "base_compiler_commit": _freeze.BASE, "compiler_commit": source_identity["result_commit"],
              "measured_base_commit": MEASURED, "source_identity_sha256": sha(HERE / "source-identity.json"),
              "source_archive_sha256": sha(HERE / "source.tar.gz"), "binary_sha256": source_identity["binary_sha256"],
              "execution": None, "input_sha256": inputs, "completed": False,
              "kind": "Host-only exact disabled-transform JSON-loader control",
              "reference_comparison_sha256": CONTROL_SHA, "reference_sha256": ACCEPTED_SHA,
              "cached_measured_full_proof_sha256": _freeze.FULL_SHA,
              "cached_parent_initial_proof_sha256": _freeze.PARENT_FILES["list-reduction/comparison.json"],
              "cached_parent_applied_listing_proof_sha256": _freeze.PARENT_FILES["list-ac-r0/comparison.json"],
              "cached_comparison_helpers_reexecuted": False, "parent_qualification_inherited": False,
              "all_transform_options_disabled": True, "root_selector_only_is_not_balance_reduction_enable": True,
              "default_recipe_selected": False, "hardware_tested": False,
              "proof_limitations": ["Actual disabled bytes/modules, PLL clock-vector elements and consumers are compared; this export has zero duplicate PLL keys.",
                                    "No pack/place/route: physical pins, setup/hold, RBF and hardware behavior are not proved."]}
    invocation, start = None, time.monotonic()
    try:
        invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(HERE / "nextpnr-mistral", identity)}, 1)
        record["execution"] = invocation.inputs
        require(not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "disabled control has a transform environment")
        with (output / "loader.log").open("x") as log:
            result = audited_run(command, source_root=MODULE, cwd=MODULE, env=invocation.env, stdout=log,
                                 stderr=subprocess.STDOUT, check=False, timeout=300)
        record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - start
        require(result.returncode == 0, "disabled loader failed")
        invocation.verify()
        completed_log()
        actual_sha, audit = actual_modules(g8, expected)
        require(actual_sha == modules_sha, "disabled normalized module digest changed")
        require(all(sha(Path(path)) == expected for path, expected in inputs.items()), "control inputs changed during execution")
        record.update({"completed": True, "modules_equivalent": True, "original_module_dictionaries_identical": True,
                       "exact_parent_export_bytes_preserved": True, "actual_pll_clock_vectors_preserved": True,
                       "modules_sha256": modules_sha, "pll_clock_vector_audit": audit,
                       "candidate_sha256": sha(output / "candidate.json"), "loader_log_sha256": sha(output / "loader.log"),
                       "output_sha256": {str(output / name): sha(output / name) for name in ("candidate.json", "loader.log")}})
        print(json.dumps({key: record[key] for key in ("completed", "modules_sha256", "candidate_sha256",
                                                     "actual_pll_clock_vectors_preserved")}), flush=True)
    except BaseException as error:
        record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - start
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        with (output / "comparison.json").open("x") as metadata:
            metadata.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
        if invocation is not None:
            invocation.close()


if __name__ == "__main__":
    main()
