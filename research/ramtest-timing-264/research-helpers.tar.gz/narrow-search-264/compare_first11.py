"""Root-operated partial proof for fresh eleven-literal qualification.

The rollback reference is an actual fresh, unbalanced placement from this
producer. Cached accepted proofs are authenticated as lineage, never replayed.
Listing exports do not prove final pin states, route-created buffers or timing.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re

import seal_profile as seal

HERE, ROOT = seal.HERE, seal.ROOT
require, read, sha = seal.require, seal.read, seal.sha
BASE_COMMIT = "6552942de15ed48e1bb9fbc71e3c08f189486313"
PINS = "ABCDEF"
MINIMUM_PS = 250
TRIAL = re.compile(
    r"^Info: Placed reduction trial root=(\S+) leaves=(\S+) "
    r"branch_gain=([+-]?\d+(?:\.\d+)?)ps endpoint_gain=([+-]?\d+(?:\.\d+)?)ps "
    r"improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])\.$"
)
CANDIDATE = re.compile(
    r"^Info: Placed reduction candidate (\d+), (\d+) endpoints, "
    r"branch gain ([+-]?\d+(?:\.\d+)?)ps\.$"
)
BEL = re.compile(r"MISTRAL_(?:M)?COMB\.(\d+)\.(\d+)\.(\d+)")


def relative(path):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT), "artifact lies outside the active FES checkout")
    return str(path.relative_to(ROOT))


def top(g8, folder):
    document = g8.read_netlist(folder / "placed.json")
    require(set(document["modules"]) == {"top"}, "unexpected exported module set")
    return document["modules"]["top"]


def graph(g8, module):
    return g8.Netlist(module["cells"], module["netnames"])


def completed_phase(folder, expected):
    record = read(folder / "run.json")
    phase = seal.authenticate_phase(record)
    require(phase["phase"] == expected and phase["folder"].resolve() == folder.resolve() and
            record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0, "fresh placement phase is not finalized")
    require(not any(key in record for key in ("fmax", "final_reported_hold_violations")) and
            record["decomposition_selection"] is None and
            record["reduction_selection"] == (-1 if expected == "list-eleven" else None),
            "placement record claims a selected rewrite or final timing")
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()) and
            not any(marker in log for marker in
                    ("Info: Decomposition", "Running the GPU router", "Running signoff timing analysis")) and
            not any((folder / name).exists() for name in ("routed.json", "timing.json", "core.rbf")),
            "placement phase ran a later transform/router or did not finish")
    if expected == "baseline-placement":
        require(phase["specs"] == [] and
                "NEXTPNR_MISTRAL_PLACED_REDUCTION" not in phase["environment"] and
                not any(marker in log for marker in ("Placed reduction", "Placed-reduction", "Balanced three-LUT reduction")),
                "fresh rollback baseline already contains a placed reduction")
    else:
        require(len(phase["specs"]) == 1 and phase["specs"][0]["candidate"] == -1 and
                phase["specs"][0]["radius"] == 6 and phase["specs"][0]["minimum_branch_gain_ps"] == MINIMUM_PS and
                not any(marker in log for marker in
                        ("Placed reduction stage ", "Placed-reduction", "Placed reduction minimum branch gain:",
                         "Placed reduction geometry probes:")),
                "eleven listing is not the sole default250 two-leaf stage")
    require(record["placed_reduction_plan"] == phase["specs"] and
            record["experimental_placed_reduction"] ==
            phase["environment"].get("NEXTPNR_MISTRAL_PLACED_REDUCTION", ""),
            "recorded placed plan/environment differs from its authenticated phase")
    return record, phase, log


def restored_graph(g8, baseline_top, listing_top):
    before, after = graph(g8, baseline_top), graph(g8, listing_top)
    require(set(before.cells) == set(after.cells) and
            not any(cell["type"] == "MISTRAL_BUF" for cell in before.cells.values()),
            "unrouted listing changed owners or contains route-created BUF cells")
    for name in before.cells:
        require(g8.dictionary_cell(before, name) == g8.dictionary_cell(after, name) and
                g8.direct_connections(before, name) == g8.direct_connections(after, name),
                "listing did not restore an exact original/retained named cell: " + name)
        require(after.cells[name]["attributes"].get("NEXTPNR_BEL") and
                not after.cells[name]["attributes"].get("FES_PINMAP_V1"),
                "listing has an unplaced cell or partial routed pin snapshot")
    require(before.direct_users == after.direct_users,
            "listing changed an original named input-consumer entry")
    g8.compare_named_nets(baseline_top, listing_top, before, after)
    g8.ranking.top_ports(baseline_top, listing_top, before, after)
    require({key: value for key, value in baseline_top.items() if key not in {"cells", "netnames", "ports"}} ==
            {key: value for key, value in listing_top.items() if key not in {"cells", "netnames", "ports"}},
            "same-phase module settings or attributes changed")
    require(not listing_top["attributes"].get("FES_LABSTATE_V1"),
            "listing unexpectedly exports routed LAB configuration")
    orders = {}
    for dictionary in ("cells", "netnames"):
        names = list(baseline_top[dictionary])
        require(names == list(listing_top[dictionary]), "original relative export order changed: " + dictionary)
        orders[dictionary] = {
            "count": len(names), "exact_name_order_identical": True,
            "name_order_sha256": hashlib.sha256("\n".join(names).encode()).hexdigest(),
        }
    return {
        "same_phase_reference": relative(HERE / "baseline-placement/placed.json"),
        "same_current_producer_before_any_placed_reduction": True,
        "named_cell_types_parameters_attributes_ports_bels_restored": True,
        "all_original_ff_named_connections_and_bels_restored": True,
        "all_named_input_consumer_entries_restored": True,
        "module_metadata_and_public_ports_identical": True,
        "named_owner_export_order": orders,
        "lossless_pll_port_audit": g8.pll_port_audit(before, after),
        "in_memory_owner_bucket_identity_proved": False,
        "indexed_user_slot_ids_and_free_list_proved": False,
        "current_logical_pin_states_and_physical_mapping_proved": False,
        "final_route_buffer_population_preservation_proved": False,
    }


def retained_messages(log):
    markers = (
        "Balanced four-LUT reduction", "Enable replication", "Local-remap plan step ",
        "Local remap ", "Comb remap ", "Capture locality",
    )
    return [line for line in log.splitlines() if any(marker in line for marker in markers)]


def retained_stack(g8, baseline_log, listing_log, accepted_log):
    before, after, accepted = [retained_messages(log) for log in (baseline_log, listing_log, accepted_log)]
    require(before == after == accepted, "retained local/comb/capture transform messages changed")
    capture = [line for line in before if "Capture locality" in line]
    require(len(capture) == 61 and "eligible 64, retained 60 moves" in capture[-1] and
            sum("Local remap applied candidate 0;" in line for line in before) == 3 and
            sum("Comb remap applied candidate 0;" in line for line in before) == 1,
            "retained selected transform count changed")
    return {
        "messages_identical_to_fresh_baseline_and_accepted_g8_listing": True,
        "message_sha256": hashlib.sha256("\n".join(before).encode()).hexdigest(),
        "retained_local_stages": 3, "retained_comb_stages": 1, "retained_capture_moves": 60,
        "original_and_retained_named_graphs_restored_to_actual_baseline": True,
        "cached_prior_truth_proofs_reexecuted": False,
        "current_unserialized_pin_polarities_not_independently_proved": True,
    }


def conditional_cube(g8, module, root):
    """Evaluate actual baseline masks under an explicitly unproved SIG state."""
    netlist = graph(g8, module)
    cone, literals, nodes = set(), {}, []
    def descend(token, required):
        require(len(token) == 3 and token[0] in netlist.cells and token[1:] == ("Q", 0),
                "conditional cube has an unsupported native driver")
        name, cell = token[0], netlist.cells[token[0]]
        if not g8.ready.is_lut(cell):
            require(cell["type"] == "MISTRAL_FF" and token not in literals,
                    "conditional cube boundary is not eleven distinct FFQ drivers")
            literals[token] = required
            return
        require(name not in cone and len(cone) < 3, "conditional cube is cyclic, reconvergent or too large")
        cone.add(name)
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        require(2 <= width <= 6 and cell["port_directions"] ==
                {**{pin: "input" for pin in PINS[:width]}, "Q": "output"} and
                set(cell["connections"]) == set(PINS[:width] + "Q") and
                all(len(values) == 1 for values in cell["connections"].values()),
                "conditional source LUT has a noncanonical scalar port schema")
        table = cell["parameters"].get("LUT")
        require(set(cell["parameters"]) == {"LUT"} and type(table) is str and
                len(table) == 1 << width and set(table) <= {"0", "1"} and
                not cell["attributes"].get("FES_PINMAP_V1"), "conditional source LUT table or listing pin state invalid")
        mask = int(table, 2)
        matches = [row for row in range(1 << width) if bool((mask >> row) & 1) == required]
        require(len(matches) == 1, "raw conditional source node is not a cube")
        row = matches[0]
        for index, pin in enumerate(PINS[:width]):
            descend(netlist.token(cell["connections"][pin][0]), bool((row >> index) & 1))
        nodes.append({"cell": name, "type": cell["type"], "mask_hex": hex(mask),
                      "required_output": required, "unique_required_row": row,
                      "rows_checked": 1 << width, "bel": g8.previous.bel(cell)})
    descend((root, "Q", 0), True)
    require(len(cone) == 3 and len(literals) == 11, "fresh source is not a three-cell eleven-literal raw cube")
    boundary = sorted(literals)
    top_tokens = {netlist.token(bit) for port in module["ports"].values() for bit in port["bits"]}
    for name in cone - {root}:
        users = netlist.direct_users.get((name, "Q", 0), [])
        require((name, "Q", 0) not in top_tokens and len(users) == 1 and users[0][0] in cone,
                "conditional source intermediate is not private")
    for token in boundary:
        require(sum(user[0] in cone for user in netlist.direct_users.get(token, [])) == 1,
                "conditional cube repeats an external source")
    def evaluate(token, values):
        if token in values:
            return values[token]
        cell = netlist.cells[token[0]]
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        address = sum(evaluate(netlist.token(cell["connections"][pin][0]), values) << index
                      for index, pin in enumerate(PINS[:width]))
        return (int(cell["parameters"]["LUT"], 2) >> address) & 1
    table = []
    expected_row = sum(int(literals[token]) << bit for bit, token in enumerate(boundary))
    for row in range(2048):
        values = {token: (row >> bit) & 1 for bit, token in enumerate(boundary)}
        value = evaluate((root, "Q", 0), values)
        require(value == int(row == expected_row), "conditional eleven-literal cube truth mismatch")
        table.append(value)
    require(g8.essential(table, 11) == set(range(11)), "conditional cube has an inessential literal")
    return {
        "root": root, "source_reference": relative(HERE / "baseline-placement/placed.json"),
        "source_cone": sorted(cone), "source_nodes": nodes,
        "external_boundary_order": boundary, "conditional_required_values": [literals[token] for token in boundary],
        "assignments_checked": 2048, "true_rows": sum(table), "conditional_true_row": expected_row,
        "truth_sha256": hashlib.sha256(bytes(table)).hexdigest(),
        "raw_source_masks_and_native_ffq_identities_from_actual_current_baseline": True,
        "all_lut_and_boundary_logical_pin_states_assumed_plain_signal": True,
        "independent_actual_listing_pin_polarity_truth_proved": False,
    }


def endpoint_closure(g8, module, root):
    netlist = graph(g8, module)
    visited, active, endpoints = set(), set(), set()
    def descend(token):
        require(token not in active and token not in visited and len(visited) + len(active) < 64,
                "narrow endpoint cone is cyclic, reconvergent or exceeds its net bound")
        active.add(token)
        for name, pin, index in netlist.direct_users.get(token, []):
            cell = netlist.cells[name]
            require(index == 0 and cell["port_directions"].get(pin) == "input", "endpoint edge is not scalar input")
            if g8.ready.is_lut(cell):
                descend((name, "Q", 0))
            else:
                require(cell["type"] == "MISTRAL_FF" and pin != "CLK", "endpoint is not an ordinary FF input")
                endpoints.add((name, pin, index))
        active.remove(token)
        visited.add(token)
    descend((root, "Q", 0))
    require(endpoints, "eleven-literal root has no endpoint")
    return {"net_count": len(visited), "nets": sorted(visited),
            "endpoint_count": len(endpoints), "ff_inputs": sorted(endpoints)}


def qualification(log, spec, endpoints):
    root = spec["root"]
    balanced = f"Info: Balanced three-LUT reduction at '{root}' into 6+5 inputs."
    trials, candidates, pending = [], [], None
    started, finished = False, False
    lab_tuples = set()
    for line in log.splitlines():
        if line == balanced:
            require(not started and not finished, "eleven-literal rewrite discovery repeated")
            started = True
        elif line.startswith("Info: Placed reduction trial "):
            require(started and not finished, "trial lies outside its discovered listing stage")
            match = TRIAL.fullmatch(line)
            require(match and match[1] == root, "malformed or misattributed eleven-literal trial")
            bels = match[2].split(",")
            require(len(bels) == len(set(bels)) == 2 and all(BEL.fullmatch(bel) for bel in bels),
                    "trial does not have two distinct combinational BELs")
            lab_tuple = tuple(tuple(int(value) for value in BEL.fullmatch(bel).groups()[:2]) for bel in bels)
            require(lab_tuple not in lab_tuples, "ordered leaf LAB geometry was timed twice")
            lab_tuples.add(lab_tuple)
            gain, endpoint_gain = float(match[3]), float(match[4])
            guards = [int(value) for value in match.groups()[4:]]
            require(math.isfinite(gain) and math.isfinite(endpoint_gain) and
                    guards[0] == int(gain > 0 and gain >= MINIMUM_PS) and
                    (not guards[1] or endpoint_gain >= 0),
                    "logged improvement guard differs from the positive default250 margin")
            pending = {"root": root, "leaf_bels": bels, "branch_gain_ps": gain,
                       "endpoint_gain_ps": endpoint_gain, "guards": guards, "trial_log": line}
            trials.append(pending)
        elif line.startswith("Info: Placed reduction candidate "):
            require(started and not finished, "candidate lies outside its discovered listing stage")
            match = CANDIDATE.fullmatch(line)
            require(match and pending and int(match[1]) == len(candidates) and
                    int(match[2]) == endpoints and pending["guards"] == [1, 1, 1, 1] and
                    pending["branch_gain_ps"] >= MINIMUM_PS and float(match[3]) == pending["branch_gain_ps"],
                    "fresh candidate lacks its consecutive ordinal and guarded default250 trial")
            candidates.append({**pending, "candidate": int(match[1]), "endpoints": int(match[2]), "candidate_log": line})
            pending = None
        elif line.startswith("Info: Placed reduction: "):
            require(started and not finished and line ==
                    f"Info: Placed reduction: {len(candidates)} qualified candidates; none applied.",
                    "listing completion disagrees with its actual candidate sequence")
            finished = True
        elif "Placed reduction" in line or "Balanced three-LUT reduction" in line:
            require(False, "unsupported placed-reduction message in the sole eleven stage")
    summaries = re.findall(r"^Info: Placed reduction: (\d+) qualified candidates; none applied\.$", log, re.M)
    require(started and finished and log.count(balanced) == 1 and
            summaries == [str(len(candidates))] and len(trials) <= 16 and
            sum(trial["guards"] == [1, 1, 1, 1] for trial in trials) == len(candidates),
            "fresh eleven listing did not complete its bounded guarded probes and rollback")
    return {"minimum_branch_gain_ps": MINIMUM_PS, "timed_trial_count": len(trials),
            "sole_authenticated_stage": spec,
            "stage_header_count": 0,
            "single_stage_header_omission_matches_frozen_compiler": True,
            "qualified_candidates": len(candidates), "qualified_ordinals": list(range(len(candidates))),
            "trials": trials, "candidates": candidates, "final_listing_applied_no_reduction": True,
            "modeled_qualification_only_no_routed_timing_claim": True}


def comparison(folder):
    profile, g8, accepted, source, control = seal.load_profile()
    baseline_folder = seal.phase_folder("baseline-placement", None, None, None)
    require(folder.resolve() == seal.phase_folder("list-eleven", -1, None, None).resolve(),
            "this comparator accepts only the initial fresh eleven listing")
    before_record, before_phase, before_log = completed_phase(baseline_folder, "baseline-placement")
    record, phase, log = completed_phase(folder, "list-eleven")
    for current in (before_record, record):
        g8.ready.authenticate_execution(current, accepted)
    require(source["base_commit"] == BASE_COMMIT and source["result_commit"] != BASE_COMMIT and
            record["compiler_commit"] == before_record["compiler_commit"] == source["result_commit"] and
            record["base_compiler_commit"] == before_record["base_compiler_commit"] == BASE_COMMIT,
            "fresh baseline/listing did not use the same newly frozen producer")
    digests, execution_digests = {}, {}
    def bind(path, digest=None):
        path = Path(path).resolve()
        relative(path)
        digest = sha(path) if digest is None else digest
        require(path not in digests or digests[path] == digest, "conflicting artifact identities")
        require(sha(path) == digest, "comparison input changed: " + relative(path))
        digests[path] = digest
    for current in (before_record, record):
        for path, digest in current["input_sha256"].items():
            bind(path, digest)
        for path, digest in current["execution"]["files"].items():
            path = Path(path)
            require(path not in execution_digests or execution_digests[path] == digest,
                    "fresh baseline/listing execution file identities disagree")
            execution_digests[path] = digest
            if path.resolve().is_relative_to(ROOT):
                bind(path, digest)
    for current_folder in (baseline_folder, folder):
        for name in ("run.json", "route.log", "placed.json"):
            bind(current_folder / name)
    for path in (Path(__file__), seal.PROFILE, seal.HERE / "source-identity.json",
                 seal.HERE / "disabled-control/comparison.json", seal.LIST / "route.log",
                 seal.LIST / "placed.json", seal.LIST / "comparison.json",
                 seal.FULL / "comparison.json"):
        bind(path)
    accepted_log = (seal.LIST / "route.log").read_text()
    metric_rows = [g8.previous.PLACEMENT_METRICS.findall(value) for value in (before_log, log, accepted_log)]
    require(len(metric_rows[0]) == 71 and metric_rows[0] == metric_rows[1] == metric_rows[2],
            "ordinary placement metrics differ between fresh baseline/listing/accepted g8")
    baseline_top, listing_top = top(g8, baseline_folder), top(g8, folder)
    restored = restored_graph(g8, baseline_top, listing_top)
    retained = retained_stack(g8, before_log, log, accepted_log)
    spec = phase["specs"][0]
    cube = conditional_cube(g8, baseline_top, spec["root"])
    closure = endpoint_closure(g8, baseline_top, spec["root"])
    fresh = qualification(log, spec, closure["endpoint_count"])
    require(all(sha(path) == digest for path, digest in {**digests, **execution_digests}.items()),
            "artifacts or execution files changed during comparison")
    return {
        "phase": "list-eleven", "status": "fresh eleven-literal listing; exact named rollback; conditional truth only",
        "compiler_commit": source["result_commit"], "base_compiler_commit": BASE_COMMIT,
        "profile_sha256": sha(seal.PROFILE), "new_disabled_control_sha256": sha(HERE / "disabled-control/comparison.json"),
        "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "baseline_reference": {"folder": relative(baseline_folder), "compiler_commit": before_record["compiler_commit"],
                               "run_sha256": sha(baseline_folder / "run.json"),
                               "log_sha256": sha(baseline_folder / "route.log"),
                               "placed_sha256": sha(baseline_folder / "placed.json"),
                               "no_placed_reduction_or_ac_enabled": True},
        "parent_qualification_inherited": False, "qualified_eleven_ordinals": fresh["qualified_ordinals"],
        "qualified_twelve_ordinals": [], "qualified_ac_ordinals": [],
        "graph_proof_available": False, "partial_graph_evidence_available": True,
        "route_started": False, "timing_acceptance_available": False,
        "matched_placement_metrics": 71, "placement_metrics_identical": True,
        "placement_metrics_sha256": hashlib.sha256("\n".join(metric_rows[0]).encode()).hexdigest(),
        "restored_listing": restored, "retained_stack": retained, "conditional_eleven_literal_cube": cube,
        "actual_endpoint_closure": closure, "qualification": fresh,
        "cached_old_comparisons_reexecuted": False, "default_recipe_selected": False, "hardware_tested": False,
        "fresh_execution_identities_authenticated": True,
        "execution_file_sha256": {str(path): digest for path, digest in sorted(execution_digests.items())},
        "final_metadata_stable_during_comparison": True,
        "proof_limitations": [
            "The rollback reference is this producer's actual fresh unbalanced placement, not the old balanced g8 listing.",
            "The 2048 raw-mask rows assume every unexported LUT and boundary logical pin state is plain signal.",
            "Exported named cell/net dictionaries, native consumer entries and relative export order are proved; indexed-user slots/free lists, owner pointers and buckets are not serialized.",
            "No current final logical/physical pin, route-created BUF, timing/hold/RBF or applied reduction acceptance is claimed.",
            "Subsequent selected stages must use freshly proved ordinals and independent actual graph/physical proofs.",
        ],
        "artifact_sha256": {relative(path): digest for path, digest in sorted(digests.items())},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    require(not (args.folder / "comparison.json").exists(), "comparison output already exists")
    result = comparison(args.folder)
    with (args.folder / "comparison.json").open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({key: result[key] for key in
                      ("phase", "candidate_completed", "graph_proof_available", "qualified_eleven_ordinals")}, indent=2))


if __name__ == "__main__":
    main()
