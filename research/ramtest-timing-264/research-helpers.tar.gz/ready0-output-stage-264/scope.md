# Retained 8/1/1 prefix plus fresh port0 output stage

Root alone prepares and executes this no-route benchmark. The closed accepted
a4a proof and completed port0 guide72879e/derivation571edd are rehashed through
their flat original artifact/runtime maps. No generator, old authenticator,
comparison, compiler build or test replays. The existing DOMAIN binary2ebe29
and source archive840e7a paths/bytes and its d2afc1 baseline invocation/runtime
remain authoritative. The recentered g1 stage1 guide and rejected g1 full route
are not selected. G1 pre-route evidence bound by the guide derivation remains
historical provenance only.

The original three DOMAIN local-plan descriptors remain exact8/1/1,
candidate0/pinsfalse/FFfixed with their original reports. Only a fourth
descriptor is appended: the exact port0 output guide, candidate0/groups1,
pinsfalse and FFfixed. The current command changes solely the plan and
write/report output paths. All other inputs, existing comb/capture/placed/AC
transforms, flags, seed, cap16384, GPU1 selector and diagnostic environment
remain byte-exact. No driver stage, GPU routing, RBF or analogue signoff runs.

Each selected stage must freshly log candidate0 and its last preceding
guarded trial and application. Actual groups may be1..budget; preceding
rejected probes remain diagnostics. The old first three selected models must
remain exact, with FFshift0 and compiled clock/hold/boundary flags all1. The
new fourth cone must be the actual port0 ALUT2_Q→ALUT4_C pair and freshly pass
the same250ps guard; no old ordinal, site, cohort, modeled gain or qualification
is inherited. Failure retains actual status/log and available partial outputs.

New profile/plan/phase outputs are exclusive. Its record inputs include the
profile's complete inputs union the profile's own original path/hash. The five
direct FES project imports are bound before execution and checked at their
actual loaded paths; FunctionalInvocation runtime must exactly match d2afc1,
with compiler read audit and final original input/output/runtime rehash.

Completion supplies only predicted report15290/current Fmax and fresh compiled
guards. Before any future driver guide or route, a separate bounded native
proof must identify the actual new clone/ENA users, logical function and
load multiplicities and preserve every other original FF/control/BEL/PLL,
cell/net/port and serialized pin field. Missing pre-route pin/LAB/cache state
remains unproved. No native physical, routed timing/gain, RBF, hardware or
acceptance claim is made here; the accepted117.343MHz result is retained.
