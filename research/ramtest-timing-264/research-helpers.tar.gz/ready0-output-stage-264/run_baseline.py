"""Record retained 8/1/1 plus fresh port0 output candidate0; no routing."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
DOMAIN = RAW / "driver-domains-264"
OLD = DOMAIN / "baseline/run.json"
OLD_SHA = "d2afc1e34789d2974748cc86587bf62780b2441a186e05276ee8e9df8ba88156"
PARENT = RAW / "driver-copy-route-proof-v2-264/comparison.json"
PARENT_SHA = "a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304"
GUIDE_FOLDER = RAW / "ready0-output-current-guide-264"
GUIDE, DERIVATION = GUIDE_FOLDER / "ready-guide-v2.json", GUIDE_FOLDER / "derivation-v2.json"
GUIDE_SHA = "72879e5022e6528ae2db630469c6bcfc49e7aa74ddc9e47b216601c823863aca"
DERIVATION_SHA = "571edd65140bf99f54d7ea391a8a4810895f3c72598a952b2f2daf5a02cd23e7"
GUIDE_GENERATOR_SHA = "95da958165cf835cc7f9131c5d00f6b20ae8dc90155d1f12f5cf14897cf22414"
GUIDE_SCOPE_SHA = "44cdb24c114fd9b0ec661788e7151ada0d3a823ca28ec6bae0d46be69be93a7a"
COMMIT, BASE = "5dd69a8ddece6280d576816d2277c73f80607f52", "9dc3633aa0c5395df9a81be8437d1a746ba54b5d"
BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
PROFILE, PLAN, FOLDER = HERE / "source-identity.json", HERE / "local-plan.json", HERE / "baseline"
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected), "invalid hash")
    if path in inputs:
        require(inputs[path] == expected, "conflicting original input identity")
    else:
        require(sha(path) == expected, "bound original path changed: " + path)
        inputs[path] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "original input/output changed: " + path)


def adopt(inputs, artifacts, external):
    for name, expected in artifacts.items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in external.items():
        require(Path(name).is_absolute(), "historical external pathname is not absolute")
        bind(inputs, name, expected)


def command(old):
    result = list(old["command"])
    require(result[0] == str(DOMAIN / "nextpnr-mistral") and result.count("--no-route") == 1 and
        not any(flag in result for flag in ("--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "old baseline role differs")
    for flag, path in (("--remap-plan", PLAN), ("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous plan/output selector")
        result[result.index(flag) + 1] = str(path)
    return result


def local_qualification(log, budgets=(8, 1, 1, 1)):
    headers = list(re.finditer(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, row.groups())) for row in headers] == [(index, 0, budget, 0, 1) for index, budget in enumerate(budgets)], "fresh local headers differ")
    result = []
    for index, header in enumerate(headers):
        block = log[header.end():headers[index + 1].start() if index + 1 < len(headers) else len(log)]
        trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
        choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
        applications = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
        require(trials and len(choices) == len(applications) == 1 and choices[0][1] == applications[0][1] == "0" and
            trials[-1].end() < choices[0].start() < applications[0].start(), "fresh local candidate0/application missing")
        row, choice = trials[-1].groups(), choices[0].groups()[1:]
        require((row[0], row[1], row[4], row[12], row[7]) == choice and row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and
            1 <= int(row[11]) <= budgets[index] and int(row[7]) >= 250, "fresh selected local trial lacks binding/fixedFF/guards")
        result.append({"index": index, "candidate": 0, "groups_budget": budgets[index], "selected_groups": int(row[11]),
            "inner": row[0], "outer": row[1], "primary_lab": [int(row[2]), int(row[3])], "bel": row[4],
            "ena_users": int(row[12]), "gain_ps": int(row[7]), "actual_trial_count": len(trials), "prior_trial_rows": [x.groups() for x in trials[:-1]],
            "ff_shift": [0, 0], "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False})
    if len(budgets) == 4:
        require(result[3]["inner"] == "hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q" and
            result[3]["outer"] == "hps_ddr.port0.slot_free_MISTRAL_ALUT4_C", "fresh fourth stage selected another reported cone")
    return result


def prepare(derivation_sha, self_sha, scope_sha):
    require(derivation_sha == DERIVATION_SHA and not any(path.exists() for path in (PROFILE, PLAN, FOLDER)), "wrong derivation or outputs exist")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (PARENT, PARENT_SHA),
            (DERIVATION, derivation_sha), (GUIDE, GUIDE_SHA), (OLD, OLD_SHA)):
        bind(inputs, path, expected)
    parent, derived, old = read(PARENT), read(DERIVATION), read(OLD)
    require(parent["compiler_commit"] == COMMIT and parent["structural_rejection"] is None and
        all(parent[key] is True for key in ("candidate_completed", "graph_proof_available", "full_graph_and_pin_equivalence_proved",
            "candidate_accepted_under_confirmed_target_clock_rule", "final_original_path_metadata_and_runtime_hashes_stable")), "accepted parent is not closed")
    adopt(inputs, parent["artifact_sha256"], parent["execution_file_sha256"])
    require(derived["completed"] is True and derived["compiler_commit"] == COMMIT and derived["parent_proof_sha256"] == PARENT_SHA and
        derived["phase"] == "exact-accepted-port0-ready-output-guide-explicit-input-buffer-v2" and
        derived["generator_sha256"] == GUIDE_GENERATOR_SHA and derived["scope_sha256"] == GUIDE_SCOPE_SHA and
        derived["guide_path"] == str(GUIDE) and derived["guide_sha256"] == GUIDE_SHA and
        (derived["paths"], derived["reported_window_violations"], derived["labs"]) == (180, 71, 29) and
        derived["exact_path_objects_and_original_source_order_preserved"] is True and
        derived["clock_terms_locations_nets_sources_windows_or_segment_delays_modified"] is False and
        derived["global_normalization_or_buf_collapse_used"] is False and derived["new_candidate_qualified"] is False and
        derived["composition_eligibility"]["essential_inputs"] == 5 and
        derived["composition_eligibility"]["g1_unexported_pin_states_or_physical_composition_proved"] is False,
        "completed exact port0 guide derivation differs")
    adopt(inputs, derived["artifact_sha256"], derived["historical_execution_file_sha256_rehashed"])
    require(old["completed"] is True and old["exit_code"] == 0 and old["compiler_read_audit_passed"] is True and
        old["compiler_commit"] == COMMIT and old["delta_base_commit"] == BASE and old["binary_sha256"] == BINARY_SHA and
        old["source_archive_sha256"] == ARCHIVE_SHA and old["phase"] == "baseline" and old["cwd"] == str(MODULE) and
        all(inputs.get(path) == expected for path, expected in {**old["input_sha256"], **old["output_sha256"], **old["execution"]["files"]}.items()),
        "same-binary retained DOMAIN baseline/source/runtime is not closed")
    require(inputs.get(str(DOMAIN / "nextpnr-mistral")) == BINARY_SHA and inputs.get(str(DOMAIN / "source.tar.gz")) == ARCHIVE_SHA,
        "existing binary/archive paths are not in closed provenance")
    for name, expected in SCRIPTS.items():
        bind(inputs, MODULE / "scripts" / name, expected)
    original_plan = Path(old["command"][old["command"].index("--remap-plan") + 1])
    require(str(original_plan) in inputs, "retained exact local plan is not closed")
    plan = read(original_plan)
    require(set(plan) == {"steps"} and len(plan["steps"]) == 3 and [step["groups"] for step in plan["steps"]] == [8, 1, 1] and
        all(set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and step["candidate"] == 0 and
            step["optimize_pins"] is False and step["preserve_ff_placement"] is True for step in plan["steps"]), "retained 8/1/1 plan differs")
    fresh_plan = copy.deepcopy(plan)
    fresh_plan["steps"].append({"report": str(GUIDE), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True})
    require(canonical(fresh_plan["steps"][:3]) == canonical(plan["steps"]), "retained stage descriptor bytes changed")
    old_log = next(Path(name) for name in old["output_sha256"] if name.endswith("/phase.log"))
    retained_models = local_qualification(old_log.read_text(), (8, 1, 1))
    with PLAN.open("x") as stream:
        stream.write(json.dumps(fresh_plan, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, PLAN, sha(PLAN))
    profile = {"schema": 1, "phase": "ready0-output-four-stage-predicted-baseline", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA,
        "parent_proof_sha256": PARENT_SHA, "guide_derivation_sha256": derivation_sha, "guide_sha256": GUIDE_SHA,
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "retained_baseline_run_sha256": OLD_SHA,
        "original_plan_path": str(original_plan), "original_plan_sha256": inputs[str(original_plan)],
        "local_plan_sha256": inputs[str(PLAN)], "local_plan_steps": fresh_plan["steps"], "retained_local_models": retained_models,
        "authorized_plan_delta": {"append_index": 3, "step": fresh_plan["steps"][3], "original_three_descriptors_exact": True},
        "command": command(old), "cwd": old["cwd"], "diagnostic_environment": old["diagnostic_environment"],
        "baseline_execution": old["execution"], "input_sha256": dict(sorted(inputs.items())),
        "rejected_g1_stage1_guide_or_full_route_selected": False, "fresh_local_qualification_required": True, "driver_pass_executed": False,
        "native_graph_or_physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs)
    with PROFILE.open("x") as stream:
        stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "local_plan_sha256": inputs[str(PLAN)]}, indent=2))


def run(profile_sha):
    inputs = {}
    bind(inputs, PROFILE, profile_sha)
    profile, old = read(PROFILE), read(OLD)
    require(not FOLDER.exists() and profile["command"] == command(old) and profile["baseline_execution"] == old["execution"] and
        profile["diagnostic_environment"] == old["diagnostic_environment"] and profile["compiler_commit"] == COMMIT, "phase/profile role differs")
    for path, expected in profile["input_sha256"].items():
        bind(inputs, path, expected)
    require(inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
        inputs[str(PLAN)] == profile["local_plan_sha256"] and read(PLAN)["steps"] == profile["local_plan_steps"], "frozen helper/plan differs")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(Path(profile["command"][0]),
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs,
        "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == old["execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual runtime/ambient diagnostics differ")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify()
        require(actual.returncode == 0, "fresh no-route four-stage prefix failed")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and "Running predicted placed timing analysis for --report" in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()) and not any(label in log for label in
                ("Running the GPU router", "Running signoff timing analysis...", "Info: LUT driver copy")), "predicted-only provenance differs")
        record["actual_selected_local_qualification"] = local_qualification(log)
        keys = ("index", "candidate", "groups_budget", "selected_groups", "inner", "outer", "primary_lab", "bel", "ena_users", "gain_ps", "ff_shift", "compiled_clock_hold_boundary_guards_passed")
        require(canonical([{key: row[key] for key in keys} for row in record["actual_selected_local_qualification"][:3]]) ==
            canonical([{key: row[key] for key in keys} for row in profile["retained_local_models"]]), "retained first three selected models changed")
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "predicted report count/Fmax differs")
        record["actual_predicted_fmax"], record["output_sha256"] = report["fmax"], {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual predicted output missing")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]})
        record["completed"] = True
        print(json.dumps({"completed": True, "actual_local_qualification": record["actual_selected_local_qualification"], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        record["elapsed_seconds"] = time.monotonic() - started
        if FOLDER.exists():
            if not record["completed"]:
                record["partial_outputs_only"] = True
                record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in
                    ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
            (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "run"))
    for name in ("guide-derivation-sha256", "self-sha256", "scope-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(all((args.guide_derivation_sha256, args.self_sha256, args.scope_sha256)), "preparation pins missing")
        prepare(args.guide_derivation_sha256, args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256 is not None, "profile pin missing")
        run(args.profile_sha256)


if __name__ == "__main__":
    main()
