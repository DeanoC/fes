"""Fourth-stage predicted prefix proof with four explicit private-owner ledgers."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE_SHA = "8124ca6545ec7ea290b1fb55564ac13b4dee53babd9c7bd34356b1ba5f9fc037"
RUN_SHA = "2cf31706c59712fa7a3ea527d1ae8420ee82ca4bb1ae698bf38abad2d3dc83ca"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
RUNNER_SHA = "2f3cb31c7e9a7a770e7afdac11ce4e8632ec4b1f4e07ee3e7b7e82e4475d8114"
RUNNER_SCOPE_SHA = "c3af533d466150b9aaaa2544de36e3e4eccb50a6bdbd3f60c3a76200b69500cc"
V1_SHA = "7c1d6a10fdde024c7a6c0df67aca9644c2d18d5c9cdba7a476bccaf1868285dc"
V1_SCOPE_SHA = "801c2b581a2e77ce50be3df3d465dc311e7dcc905793a3dfb0d968cb6336f263"
V1_PROOF_SHA = "4d8dcc4f171e689d7c626c0f134ca53a6b39703e440dd02a417710beb743de60"
COMB_OWNER = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMPOSITION = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C"
PRIVATE_OWNERS = (COMB_OWNER, DECOMPOSITION + "$code0", DECOMPOSITION + "$code1", DECOMPOSITION + "$root")
MODEL_KEYS = ("index", "candidate", "groups_budget", "selected_groups", "inner", "outer", "primary_lab", "bel",
              "ena_users", "gain_ps", "ff_shift", "compiled_clock_hold_boundary_guards_passed")
PINS = "ABCDEF"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module pin/name differs")
    value = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(module, globals=None, locals=None, fromlist=(), level=0):
            return frozen if module == "freeze" and level == 0 else builtins.__import__(module, globals, locals, fromlist, level)
        value.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = value
    exec(compile(data, str(path), "exec"), value.__dict__)
    return value


def scalar(cell, port):
    bits = cell["connections"][port]
    require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0,
            "required native logical port is not a scalar signal")
    return bits[0]


def lab(cell):
    match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
    require(match is not None, "placed cell lacks a native BEL")
    return [int(match[1]), int(match[2])]


def lut(cell):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    require(match is not None and set(cell["parameters"]) == {"LUT"}, "composition requires an ordinary LUT")
    width, table = int(match[1]), cell["parameters"]["LUT"]
    directions = {pin: "input" for pin in PINS[:width]} | {"Q": "output"}
    require(type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"} and
            cell["port_directions"] == directions and set(cell["connections"]) == set(directions),
            "composition logical table/port schema differs")
    return width, int(table, 2), [scalar(cell, pin) for pin in PINS[:width]], scalar(cell, "Q")


def private_ledger(native, a, b, old_drivers, old_users, new_drivers, new_users):
    """Validate each actual output frame independently; never translate a raw-ID domain."""
    rows, allowed = [], {}
    for owner in PRIVATE_OWNERS:
        alias = owner + "$Q"
        require(owner in a["cells"] and owner in b["cells"] and alias in a["netnames"] and alias in b["netnames"],
                "declared private owner/alias is absent: " + owner)
        old_cell, new_cell = a["cells"][owner], b["cells"][owner]
        lut(old_cell); lut(new_cell)
        old_bit, new_bit = scalar(old_cell, "Q"), scalar(new_cell, "Q")
        require(old_bit != new_bit and old_drivers.get(old_bit) == new_drivers.get(new_bit) == [(owner, "Q", 0, 0)] and
                old_users.get(old_bit) and old_users[old_bit] == new_users.get(new_bit),
                "declared private output lacks its exact unique driver/named consumer slots: " + owner)
        frames = []
        for top, cell, bit, users in ((a, old_cell, old_bit, old_users), (b, new_cell, new_bit, new_users)):
            require([name for name, net in top["netnames"].items() if bit in net["bits"]] == [alias] and
                    top["netnames"][alias]["bits"] == [bit] and
                    all(bit not in port["bits"] for port in top["ports"].values()),
                    "private output is not a sole alias with no public boundary: " + owner)
            require(all(slot[3] == 0 and top["cells"][slot[0]]["port_directions"][slot[1]] == "input" and
                        top["cells"][slot[0]]["connections"][slot[1]][slot[2]] == bit for slot in users[bit]),
                    "private output consumer is not its actual named scalar/vector input slot")
            frames.append({"raw_bit": bit, "native_driver": [owner, "Q", 0, 0],
                           "named_consumer_slots": [list(slot) for slot in users[bit]],
                           "sole_private_alias": alias, "alias_record": top["netnames"][alias],
                           "owner_type": cell["type"], "owner_bel": cell["attributes"]["NEXTPNR_BEL"]})
        left, right = dict(a["netnames"][alias]), dict(b["netnames"][alias])
        left.pop("bits"); right.pop("bits")
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + alias)
        for slot, role in [((owner, "Q", 0, 0), "private_output_driver")] + [
                (slot, "private_output_consumer") for slot in old_users[old_bit]]:
            require(slot not in allowed, "private output ledgers overlap one named slot")
            allowed[slot] = {"old_raw_bit": old_bit, "new_raw_bit": new_bit, "role": role, "owner": owner}
        rows.append({"owner": owner, "alias": alias, "before": frames[0], "after": frames[1],
                     "named_driver_and_all_consumer_slots_preserved": True, "public_boundary_consumers": 0})
    require(len({row["before"]["raw_bit"] for row in rows}) == len({row["after"]["raw_bit"] for row in rows}) == 4,
            "four private output owners are not a per-image bijection")
    return rows, allowed


def prove(native, selected, before_doc, after_doc, model):
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and
            before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "native document metadata differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    clone, alias = model["outer"] + "$local_remap", model["outer"] + "$local_remap$Q"
    require(set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            len(a["cells"]) == 14900 and len(b["cells"]) == 14901 and
            len(a["netnames"]) == 16638 and len(b["netnames"]) == 16639 and
            set(b["cells"]) - set(a["cells"]) == {clone} and set(a["cells"]) <= set(b["cells"]) and
            set(b["netnames"]) - set(a["netnames"]) == {alias} and set(a["netnames"]) <= set(b["netnames"]) and
            [name for name in b["cells"] if name != clone] == list(a["cells"]) and
            [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "complete metadata/owner order/lossless PLL or exact one-cell/one-net population differs")
    require("FES_LABSTATE_V1" not in a["attributes"] and "FES_LABSTATE_V1" not in b["attributes"] and
            all(cell["type"] != "MISTRAL_BUF" and "FES_PINMAP_V1" not in cell["attributes"]
                for top in (a, b) for cell in top["cells"].values()),
            "predicted image unexpectedly exports physical pin/LAB state or late buffers")
    old_drivers, old_users = selected.native_tables(a)
    new_drivers, new_users = selected.native_tables(b)
    private, allowed = private_ledger(native, a, b, old_drivers, old_users, new_drivers, new_users)
    private_aliases = {row["alias"] for row in private}
    for name, old in a["netnames"].items():
        if name not in private_aliases:
            require(native.canonical(old) == native.canonical(b["netnames"][name]),
                    "existing non-private native alias/raw bit/complete net metadata differs: " + name)
    wi, mi, ai, qi = lut(a["cells"][model["inner"]])
    wo, mo, ao, qo = lut(a["cells"][model["outer"]])
    wc, mc, ac, qc = lut(b["cells"][clone])
    require((wi, wo, wc, mi, mo, mc) == (2, 4, 5, 0xb, 0xf0e0, 0xbbbbbbb0) and
            ao.count(qi) == 1 and len(set(ac)) == 5 and set(ac) == set(ai + [bit for bit in ao if bit != qi]) and
            not ({qi, qo, qc} & set(ac)) and len({qi, qo, qc}) == 3 and
            b["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
            b["netnames"][alias]["bits"] == [qc], "actual five-leaf composition/site/private output differs")
    expected_drivers = dict(old_drivers)
    for row in private:
        del expected_drivers[row["before"]["raw_bit"]]
    require(qc not in expected_drivers and old_drivers[qo] == [(model["outer"], "Q", 0, 0)],
            "new clone output overlaps an original non-private driver")
    for row in private:
        bit = row["after"]["raw_bit"]
        require(bit not in expected_drivers and bit != qc, "declared private output overlaps a non-private/new-clone driver")
        expected_drivers[bit] = [(row["owner"], "Q", 0, 0)]
    expected_drivers[qc] = [(clone, "Q", 0, 0)]
    require(new_drivers == expected_drivers, "native driver table differs outside four private owners and new clone")
    sources, truth = [], []
    for index, bit in enumerate(ac):
        require(len(old_drivers.get(bit, [])) == 1 and
                a["cells"][old_drivers[bit][0][0]]["type"] != "MISTRAL_CONST", "ambiguous or hidden-constant leaf")
        sources.append({"clone_input_port": PINS[index], "raw_bit": bit, "native_driver": list(old_drivers[bit][0])})
    for assignment in range(32):
        values = {bit: (assignment >> index) & 1 for index, bit in enumerate(ac)}
        inner_row = sum(values[bit] << index for index, bit in enumerate(ai))
        inner_value = (mi >> inner_row) & 1
        outer_row = sum((inner_value if bit == qi else values[bit]) << index for index, bit in enumerate(ao))
        expected, actual = (mo >> outer_row) & 1, (mc >> assignment) & 1
        require(expected == actual, "conditional raw-mask composition differs at row " + str(assignment))
        truth.append({"assignment": assignment, "inner_row": inner_row, "inner_value": inner_value,
                      "outer_row": outer_row, "original_value": expected, "clone_value": actual})
    chosen = new_users.get(qc, [])
    require(len(old_users.get(qo, [])) == 180 and len(chosen) == model["ena_users"] == 3 and
            chosen == [slot for slot in old_users[qo] if lab(a["cells"][slot[0]]) == model["primary_lab"]] and
            model["selected_groups"] == 1, "actual selected cohort is not the complete three-user compatible LAB group")
    clock, redirects = None, []
    for slot in old_users[qo]:
        name, port, index, occurrence = slot
        cell = a["cells"][name]
        require(cell["type"] == "MISTRAL_FF" and (port, index, occurrence) == ("ENA", 0, 0) and
                cell["port_directions"]["CLK"] == cell["port_directions"]["ENA"] == "input", "original root user is not FF ENA")
        value = scalar(cell, "CLK")
        clock = value if clock is None else clock
        require(value == clock == 3549, "actual FF clock differs")
    for slot in chosen:
        require(slot not in allowed, "ENA redirect overlaps a declared private-output slot")
        allowed[slot] = {"old_raw_bit": qo, "new_raw_bit": qc, "role": "selected_ff_ena", "owner": clone}
    for name, old in a["cells"].items():
        new = b["cells"][name]
        left, right = dict(old), dict(new)
        left.pop("connections"); right.pop("connections")
        require(native.canonical(left) == native.canonical(right) and list(old["connections"]) == list(new["connections"]),
                "original metadata/params/attrs/BEL/directions/port order differs: " + name)
        for port, bits in old["connections"].items():
            now = new["connections"][port]
            require(type(bits) is list and type(now) is list and len(bits) == len(now), "original vector port shape differs")
            for index, (old_bit, new_bit) in enumerate(zip(bits, now)):
                slot = (name, port, index, 0)
                if old_bit != new_bit:
                    row = allowed.get(slot)
                    require(row is not None and (old_bit, new_bit) == (row["old_raw_bit"], row["new_raw_bit"]),
                            "undeclared original connection/raw bit differs: " + name + "." + port + "[" + str(index) + "]")
                    if row["role"] == "selected_ff_ena":
                        redirects.append({"cell": name, "port": port, "vector_index": index, "occurrence": 0,
                                          "old_raw_bit": qo, "new_raw_bit": qc, "bel": old["attributes"]["NEXTPNR_BEL"]})
    require({(row["cell"], "ENA", 0, 0) for row in redirects} == set(chosen), "actual ENA redirect ledger differs")
    for bit in set(old_users) | set(new_users) | set(ac):
        expected = list(old_users.get(bit, []))
        for slot, row in allowed.items():
            if row["role"] == "private_output_driver":
                continue
            if row["old_raw_bit"] == bit:
                expected.remove(slot)
            if row["new_raw_bit"] == bit:
                expected.append(slot)
        expected.extend((clone, PINS[index], 0, 0) for index, signal in enumerate(ac) if signal == bit)
        require(sorted(expected) == new_users.get(bit, []), "native user/load slots differ outside named private/clone/ENA ledgers")
    return {"serialized_native_scope_proved": True, "clone": clone, "private_alias": alias, "clone_raw_bit": qc,
            "original_root_raw_bit": qo, "declared_ena_redirects": redirects, "declared_ena_redirect_count": 3,
            "explicit_private_output_owner_bijections": private, "private_output_owner_count": 4,
            "declared_original_raw_slot_changes": [{"slot": list(slot), **row} for slot, row in sorted(allowed.items())],
            "new_clone_reuses_only_a_declared_old_private_output_bit": qc in {row["before"]["raw_bit"] for row in private},
            "whole_compatible_lab_group": model["primary_lab"], "actual_exported_clock_bit": clock,
            "clone_input_load_slots": sources, "assignments_checked": 32, "conditional_plain_sig_truth_rows": truth,
            "all_non_private_original_raw_bits_records_order_and_pll_exact": True,
            "pin_assumptions": "All original inner/outer and new clone input/Q states are plain PIN_SIG.",
            "unexported_pin_lab_cache_state_or_numerical_sta_independently_proved": False}


def compare(self_sha, scope_sha):
    native = load(NATIVE, NATIVE_SHA, "ready0_prefix_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope-v2.md", scope_sha),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (SELECTED.parent / "freeze.py", FREEZE_SHA),
            (HERE / "run_baseline.py", RUNNER_SHA), (HERE / "scope.md", RUNNER_SCOPE_SHA),
            (HERE / "source-identity.json", PROFILE_SHA), (HERE / "baseline/run.json", RUN_SHA),
            (HERE / "compare_prefix.py", V1_SHA), (HERE / "comparison-scope.md", V1_SCOPE_SHA),
            (HERE / "baseline/comparison.json", V1_PROOF_SHA)):
        audit.bind(path, expected)
    profile, record = native.read(HERE / "source-identity.json"), native.read(HERE / "baseline/run.json")
    v1 = native.read(HERE / "baseline/comparison.json")
    require(v1["phase"] == "ready0-output-fourth-stage-strict-native-prefix-v1" and
            v1["source_identity_sha256"] == PROFILE_SHA and v1["current_baseline_run_sha256"] == RUN_SHA and
            v1["generator_sha256"] == V1_SHA and v1["scope_sha256"] == V1_SCOPE_SHA and
            v1["candidate_completed"] is True and v1["native_graph_proof_available"] is False and
            v1["native_graph_evidence"] is None and v1["routed_gain_accepted"] is False and
            v1["structural_rejection"] == {"exception_type": "ValueError",
                "reason": "existing native alias/raw bit/complete net metadata differs: " + COMB_OWNER + "$Q"} and
            v1["final_original_path_metadata_and_runtime_hashes_stable"] is True,
            "immutable actual v1 rejection differs")
    for path, expected in profile["input_sha256"].items():
        audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    for name, expected in v1["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "v1 artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for path, expected in v1["execution_file_sha256"].items():
        audit.bind(Path(path), expected, execution=True)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["source_identity_sha256"] == PROFILE_SHA and record["execution"] == profile["baseline_execution"] and
            all(record[key] == value for key, value in profile.items() if key != "input_sha256") and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): PROFILE_SHA} and
            "failure" not in record and "exit_code_is_adapter_sentinel" not in record, "closed actual run/profile/runtime differs")
    for path, expected in record["execution"]["files"].items():
        audit.bind(Path(path), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in
            ("phase.log", "placed.json", "timing.json")}, "actual output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "empty actual predicted output")
        audit.bind(Path(path), expected)
    runner = load(HERE / "run_baseline.py", RUNNER_SHA, "ready0_prefix_recorder_pure")
    old, parent, derivation = native.read(runner.OLD), native.read(runner.PARENT), native.read(runner.DERIVATION)
    require(audit.paths.get(runner.OLD) == runner.OLD_SHA and audit.paths.get(runner.PARENT) == runner.PARENT_SHA and
            audit.paths.get(runner.DERIVATION) == runner.DERIVATION_SHA and audit.paths.get(runner.GUIDE) == runner.GUIDE_SHA and
            parent["structural_rejection"] is None and parent["candidate_accepted_under_confirmed_target_clock_rule"] is True and
            derivation["completed"] is True and derivation["guide_sha256"] == runner.GUIDE_SHA and
            profile["command"] == runner.command(old) and profile["baseline_execution"] == old["execution"] and
            profile["diagnostic_environment"] == old["diagnostic_environment"] and
            profile["compiler_commit"] == old["compiler_commit"] == runner.COMMIT and
            profile["binary_sha256"] == runner.BINARY_SHA and profile["source_archive_sha256"] == runner.ARCHIVE_SHA and
            profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            native.read(HERE / "local-plan.json")["steps"] == profile["local_plan_steps"] and
            profile["local_plan_steps"][:3] == native.read(Path(profile["original_plan_path"]))["steps"],
            "closed accepted/derived provenance or exact retained invocation differs")
    for artifact, external in ((parent["artifact_sha256"], parent["execution_file_sha256"]),
            (derivation["artifact_sha256"], derivation["historical_execution_file_sha256_rehashed"])):
        require(all(audit.paths.get(ROOT / name) == digest for name, digest in artifact.items()) and
                all(audit.paths.get(Path(name)) == digest for name, digest in external.items()), "flat cached proof closure is incomplete")
    old_log, log = (runner.OLD.parent / "phase.log").read_text(), (HERE / "baseline/phase.log").read_text()
    old_models, models = runner.local_qualification(old_log, (8, 1, 1)), runner.local_qualification(log)
    require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
            native.canonical(models) == native.canonical(v1["fresh_local_models"]) and
            native.canonical(old_models) == native.canonical(v1["old_local_models"]) and
            native.canonical(old_models) == native.canonical(profile["retained_local_models"]) and
            [{key: row[key] for key in MODEL_KEYS} for row in models[:3]] ==
            [{key: row[key] for key in MODEL_KEYS} for row in old_models], "fresh qualification/retained selected models differ")
    frozen = load(SELECTED.parent / "freeze.py", FREEZE_SHA, "ready0_prefix_frozen_pure")
    selected = load(SELECTED, SELECTED_SHA, "ready0_prefix_selected_pure", frozen)
    before, after = native.read_netlist(runner.OLD.parent / "placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    metrics = native.PLACEMENT_METRICS.findall(old_log) == native.PLACEMENT_METRICS.findall(log) and len(native.PLACEMENT_METRICS.findall(log)) == 71
    evidence, rejection = None, None
    try:
        require(metrics, "original 71 placement metrics differ")
        evidence = prove(native, selected, before, after, models[3])
    except (ValueError, TypeError, KeyError, IndexError) as error:
        rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    report = native.read(HERE / "baseline/timing.json")
    topology = selected.report_topology(after, report, native.read(runner.OLD.parent / "timing.json"))
    require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and
            native.canonical(topology) == native.canonical(v1["current_predicted_native_paths"]) and
            record["actual_predicted_fmax"] == report["fmax"] and "Info: Program finished normally." in log and
            "Running predicted placed timing analysis for --report" in log and not any(text in log for text in
            ("Running the GPU router", "Running signoff timing analysis...", "Info: LUT driver copy")), "predicted report/phase role differs")
    audit.finish()
    return {"schema": 1, "phase": "ready0-output-fourth-stage-explicit-private-owner-prefix-v2", "source_identity_sha256": PROFILE_SHA,
            "current_baseline_run_sha256": RUN_SHA, "compiler_commit": profile["compiler_commit"],
            "generator_sha256": self_sha, "scope_sha256": scope_sha,
            "immutable_strict_v1_rejection_sha256": V1_PROOF_SHA,
            "immutable_strict_v1_rejection": v1["structural_rejection"],
            "pure_function_helper_sha256": {str(NATIVE): NATIVE_SHA, str(SELECTED): SELECTED_SHA,
                                           str(SELECTED.parent / "freeze.py"): FREEZE_SHA},
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"], "old_local_models": old_models,
            "fresh_local_models": models, "all_71_placement_metrics_exact": metrics, "structural_rejection": rejection,
            "native_graph_proof_available": rejection is None, "native_graph_evidence": evidence,
            "current_predicted_native_paths": topology, "fresh_driver_guide_available_after_conditional_prefix_proof": rejection is None,
            "four_explicit_private_owner_bijections_proved": rejection is None,
            "global_raw_bit_translation_or_buffer_normalization_used": False, "independent_physical_equivalence_proved": False,
            "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True)
    parser.add_argument("--scope-sha256", required=True)
    args = parser.parse_args()
    output = HERE / "baseline/comparison-v2.json"
    require(not output.exists(), "immutable prefix comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
                      "structural_rejection": result["structural_rejection"], "routed_gain_accepted": False}, indent=2))


if __name__ == "__main__":
    main()
