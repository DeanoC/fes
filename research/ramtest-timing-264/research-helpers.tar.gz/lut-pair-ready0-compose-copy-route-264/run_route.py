"""Record a fresh routed RBF after a positive selected composed-copy native proof."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-compose-copy-264"
COMPILER, SELECTED = RAW / "lut-pair-compose-copy-264", RAW / "lut-pair-ready0-compose-copy-selected-264"
COMMIT, BASE = "cae5eb9a326507b688414ba934421286f648a43b", "e137ca5bda7c5e68e6da65f37b5830d12f58727a"
BINARY, ARCHIVE, HOST = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz", COMPILER / "validation/host-validation.json"
BINARY_SHA = "a2b5da93a9a91cd95d411fb5773e86136ff62e1fce7896d371c97c756004885e"
ARCHIVE_SHA, HOST_SHA = "c64eb65c4e1ac01a277322bddc90172be836fddd60f2d3a0baf66bad62522dd2", "84416288f9a9b4f85c956ad32dc264efc14d007d2d3278c3abc952a006cc6a1e"
TEST_SHA, CHECKS_SHA = "b0e912b15ebd4ce11cb56cec7a356809ce4bf84ef347851fbcccfbf978a20484", "f0b694224d40ae6eb8c081d13fd0cc1fc75c1e337bd7093168a7a3759a3b6721"
HOST_HELPER_SHA, HOST_SCOPE_SHA = "e5cf3243801bcf13f4aed5086ad4914502ed1765bbff15eedf7cf4d589157439", "071a7d054e6dafd79d92962ad0f9466d5987da9aa793a38de2b1c41f019b95a3"
SELECTED_PROFILE, SELECTED_RUN = SELECTED / "source-identity.json", SELECTED / "selected/run.json"
SELECTED_PROOF = SELECTED / "selected/comparison-selected-copy.json"
SELECTED_PROFILE_SHA, SELECTED_RUN_SHA = "f429189ff69ab9c2d9c3bf9f7a59815e530cf416a3abe9f75600dc808629ab59", "84252668b4943038526a41ee6e6694a905582bcc450cf97b9874e05b27f8438f"
SELECTED_PROOF_SHA, SELECTED_COMPARER_SHA = "9034eda835a0b54238c50a1ab83f358b89c64f417c27c17b1575360ef965b2c2", "6fdfdce1841119ede82d91d36af5e65c2f57bfe871459876cc745787d02deab9"
SELECTED_HELPER_SHA, SELECTED_SCOPE_SHA = "fec8c4b4f31827c10ec834351bae7a28ae148368c73ad9a556359a0481396d9e", "936673ca3dedb50a23f8e5a774078c4628d36d7650b3128b766210ed2c8a2556"
SELECTED_COMPARISON_SCOPE_SHA = "aef919889f2aacffc40c2cb5fff17777857194b624d2d417641822b92b8989dd"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
ACCEPTED_RUN = RAW / "local-multicopy-ready1-address-route-264/route-c0/run.json"
ACCEPTED_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
MINIMUM_MEMORY_MHZ = 117.77175903320312
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
TABLES, TABLES_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = TABLES.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "route"
PHASE = "lut-pair-ready0-compose-copy-fresh-selected-full-route"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
CHANGED = {"mistral/CMakeLists.txt", "mistral/arch.h", "mistral/lut_pair_copy.cc", "mistral/lut_pair_placement.cc",
    "mistral/lut_pair_placement.h", "mistral/lut_pair_placement.md", "mistral/main.cc",
    "mistral/tests/lut_pair_placement.cc", "mistral/tests/lut_pair_placement_cli.py"}
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch("[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original pathname hash")
    if path not in inputs:
        require(sha(path) == expected, "original input differs: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat runtime entry is not absolute"); bind(inputs, name, expected)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def definitions():
    selected = load(SELECTED / "run_selected.py", SELECTED_HELPER_SHA, "ready0_copy_route_selected_pure")
    listing, control, parsers = selected.definitions()
    return selected, listing, control, parsers


def command(previous):
    result = list(previous["command"])
    flags = ("--no-route", "--write", "--report", "--remap-plan", "--remap-lut-pair-critical", "--remap-lut-pair-candidate", "--remap-lut-pair-compose-copy")
    require(result[0] == str(BINARY) and all(result.count(flag) == 1 for flag in flags) and
        result[result.index("--remap-lut-pair-candidate") + 1] == str(previous["pair_candidate_selection"]) and
        type(previous["pair_candidate_selection"]) is int and previous["pair_candidate_selection"] >= 0 and
        result[result.index("--remap-plan") + 1] == previous["original_plan_path"] and
        result[result.index("--remap-lut-pair-critical") + 1] == previous["guide_path"] and
        result.count("--router") == result.count("--gpu-device") == 1 and result[result.index("--router") + 1] == "gpu" and
        result[result.index("--gpu-device") + 1] == "1" and not any(flag in result for flag in
        ("--no-pack", "--no-place", "--rbf", "--remap-post-plan", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "proved selected command role differs")
    result.remove("--no-route")
    for flag, name in (("--write", "routed.json"), ("--report", "timing.json")):
        result[result.index(flag) + 1] = str(FOLDER / name)
    return [*result, "--rbf", str(FOLDER / "core.rbf")]


def expected_execution(previous):
    return copy.deepcopy(previous["execution"])


def validate_host(host):
    counts = {"pair_backend": 12, "copy_backend": 11, "native_plan": 25, "driver_backend": 10,
        "pair_cli": 17, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and
        host["check_results_sha256"] == CHECKS_SHA and host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and
        host["clean_committed_checkout"] is host["build_passed"] is True and set(host["changed_source_files"]) == CHANGED and
        set(host["checks"]) == set(counts) and all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
        all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"], "fresh copy host/source/check qualification differs")


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == CHANGED,
        "current copy source differs from the clean reviewed host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
        [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "current source dependency changed")


def closed_selected(record, profile, expected):
    require(record["completed"] is True and record["exit_code"] == 0 and
        record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
        record["source_identity_sha256"] == expected and record["execution"] == profile["selected_execution"] and
        record["input_sha256"] == {**profile["input_sha256"], str(SELECTED_PROFILE): expected} and
        all(canonical(record[key]) == canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "selected prerequisite is not closed")


def positive_selected(proof, previous):
    require(proof["schema"] == 1 and proof["phase"] == "lut-pair-ready0-selected-composed-copy-conditional-native-proof" and
        proof["source_identity_sha256"] == SELECTED_PROFILE_SHA and proof["current_selected_run_sha256"] == SELECTED_RUN_SHA and
        proof["compiler_commit"] == COMMIT and proof["delta_base_commit"] == BASE and proof["host_validation_sha256"] == HOST_SHA and
        proof["generator_sha256"] == SELECTED_COMPARER_SHA and proof["scope_sha256"] == SELECTED_COMPARISON_SCOPE_SHA and
        proof["recorder_sha256"] == SELECTED_HELPER_SHA and proof["recorder_scope_sha256"] == SELECTED_SCOPE_SHA and
        proof["current_actual_execution"] == previous["execution"] and proof["actual_candidate_selection"] == previous["pair_candidate_selection"] and
        canonical(proof["actual_chosen_candidate"]) == canonical(previous["expected_candidate"]) and
        canonical(proof["actual_selected_pair_copy_qualification"]) == canonical(previous["actual_selected_pair_copy_qualification"]) and
        proof["structural_rejection"] is proof["model_or_selected_prefix_rejection"] is proof["native_path_topology_rejection"] is None and
        all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact",
            "all_original_ff_bels_exact", "selected_native_graph_and_conditional_function_proved", "fresh_full_route_prerequisite_under_plain_sig_condition",
            "final_original_path_metadata_and_runtime_hashes_stable")) and
        all(proof[key] is False for key in ("actual_packed_pin_or_physical_truth_proved", "unexported_cache_or_user_storage_holes_proved",
            "independent_numerical_sta_or_hold_margin_proved", "routed_gain_accepted", "hardware_tested")), "independent selected conditional native prerequisite is not positive")
    graph = proof["native_graph_evidence"]
    require(graph["serialized_native_scope_proved"] is graph["conditional_plain_sig_raw_composition_proved"] is True and
        graph["declared_ena_redirect_count"] == len(graph["declared_ena_redirects"]) == previous["expected_candidate"]["cohort"] and
        graph["assignments_checked"] == len(graph["conditional_truth_rows"]) and graph["assignments_checked"] in (4, 8, 16, 32, 64) and
        graph["packed_physical_truth_proved"] is graph["unexported_cache_or_indexed_user_storage_holes_proved"] is False,
        "conditional clone/cohort/truth scope differs")


def accepted_reference(inputs, previous):
    proof, record = read(ACCEPTED), read(ACCEPTED_RUN)
    require(proof["schema"] == 1 and proof["candidate_completed"] is proof["native_graph_proof_available"] is proof["physical_scope_proved"] is True and
        proof["structural_rejection"] is None and proof["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and
        proof["current_full_run_sha256"] == ACCEPTED_RUN_SHA and proof["final_original_path_metadata_and_runtime_hashes_stable"] is True and
        proof["timing"]["raw_timing"]["clocks"]["ram_clock.clocks[0]"]["after_mhz"] == MINIMUM_MEMORY_MHZ and
        record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
        record["final_original_input_output_runtime_hashes_stable"] is True, "accepted fifth timing/reference closure differs")
    adopt(inputs, proof)
    for ledger in (record["input_sha256"], record["output_sha256"], record["execution"]["files"]):
        for path, expected in ledger.items(): bind(inputs, path, expected)
    flags = ("--json", "--device", "--qsf", "--sdc", "--freq", "--seed", "--placer-heap-timingweight", "--placer-heap-critexp",
        "--replicate-enables", "--router", "--gpu-device", "--timing-report-paths", "--remap-comb-critical", "--remap-comb-candidate",
        "--remap-decompose-critical", "--remap-decompose-candidate", "--balance-reduction-root")
    for flag in flags:
        require(previous["command"].count(flag) == record["command"].count(flag) == 1 and
            previous["command"][previous["command"].index(flag) + 1] == record["command"][record["command"].index(flag) + 1], "accepted source/device/clock/seed/routing flag differs: " + flag)
    require(previous["diagnostic_environment"] == record["diagnostic_environment"], "accepted diagnostic environment differs")
    runtime = copy.deepcopy(record["execution"])
    old_binary = record["command"][0]
    require(runtime["files"].pop(old_binary) == record["binary_sha256"] and str(BINARY) not in runtime["files"], "accepted runtime compiler frame differs")
    runtime["files"][str(BINARY)] = BINARY_SHA; runtime["environment"]["PATH"] = str(BINARY.parent) + ":/usr/bin:/bin"
    require(runtime == previous["execution"], "accepted/current runtime differs outside compiler/PATH substitution")
    report = read(ACCEPTED_RUN.parent / "timing.json")
    require(report["fmax"]["ram_clock.clocks[0]"]["achieved"] == MINIMUM_MEMORY_MHZ, "accepted memory reference changed")
    return report


def pair_windows(report):
    counts = {}
    for path in report["critical_paths"]:
        key = (path["from"], path["to"], path["max_delay"]); counts[key] = counts.get(key, 0) + 1
    require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and len(counts) == 7 and
        all(type(key[2]) in (int, float) and math.isfinite(key[2]) and key[2] > 0 for key in counts), "report count/window frame differs")
    return counts


def qualification(log, modules, previous):
    selected, listing, control, parsers = modules
    return selected.qualification(log, listing, control, parsers, previous["expected_candidate"], previous["expected_copy_prefix"])


def prepare(self_sha, scope_sha, profile_sha, run_sha, proof_sha):
    pins = (SELECTED_PROFILE_SHA, SELECTED_RUN_SHA, SELECTED_PROOF_SHA, SELECTED_COMPARER_SHA)
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in (self_sha, scope_sha, *pins)) and
        (profile_sha, run_sha, proof_sha) == pins[:3] and not PROFILE.exists() and not FOLDER.exists(), "actual selected pins remain UNFROZEN or outputs exist")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (SELECTED_PROFILE, profile_sha),
        (SELECTED_RUN, run_sha), (SELECTED_PROOF, proof_sha), (SELECTED / "run_selected.py", SELECTED_HELPER_SHA), (SELECTED / "scope.md", SELECTED_SCOPE_SHA),
        (SELECTED / "compare_selected_copy.py", SELECTED_COMPARER_SHA), (SELECTED / "comparison-scope.md", SELECTED_COMPARISON_SCOPE_SHA),
        (HOST, HOST_SHA), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA), (ACCEPTED, ACCEPTED_SHA), (ACCEPTED_RUN, ACCEPTED_RUN_SHA),
        (NATIVE, NATIVE_SHA), (TABLES, TABLES_SHA), (FREEZE, FREEZE_SHA)):
        bind(inputs, path, expected)
    previous, prepared, proof, host = (read(path) for path in (SELECTED_RUN, SELECTED_PROFILE, SELECTED_PROOF, HOST))
    closed_selected(previous, prepared, profile_sha); positive_selected(proof, previous); validate_host(host); adopt(inputs, proof)
    require(set(previous["output_sha256"]) == {str(SELECTED_RUN.parent / name) for name in ("phase.log", "placed.json", "timing.json")}, "closed selected output triplet differs")
    for ledger in (previous["input_sha256"], previous["output_sha256"], previous["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original closure pathname is not absolute"); bind(inputs, path, expected)
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    accepted_report = accepted_reference(inputs, previous)
    modules = definitions(); selected, listing, control, parsers = modules
    pure = {str(SELECTED / "run_selected.py"): SELECTED_HELPER_SHA, str(NATIVE): NATIVE_SHA, str(TABLES): TABLES_SHA, str(FREEZE): FREEZE_SHA,
        str(selected.LISTING / "run_listing.py"): selected.LISTING_HELPER_SHA, str(listing.CONTROL / "run_baseline.py"): listing.CONTROL_HELPER_SHA,
        **{str(path): expected for path, expected in control.PARSERS}}
    for path, expected in pure.items(): bind(inputs, path, expected)
    models, applied = qualification((SELECTED_RUN.parent / "phase.log").read_text(), modules, previous)
    require(len(models) == 10 and canonical(models) == canonical(previous["actual_selected_local_qualification"]) == canonical(proof["fresh_local_models"]) and
        canonical(applied) == canonical(previous["actual_selected_pair_copy_qualification"]) and applied["candidate_applied"] is True and
        len(previous["local_plan_steps"]) == len(previous["retained_copy_cohorts"]) == 10 and previous["compose_copy_requested"] is True,
        "closed selected TEN/copy evidence differs")
    bind(inputs, previous["guide_path"], previous["guide_sha256"]); bind(inputs, previous["original_plan_path"], previous["original_plan_sha256"])
    require(read(previous["guide_path"]) == {"critical_paths": [previous["exact_current_path_object"]]} and
        read(previous["original_plan_path"]) == {"steps": previous["local_plan_steps"]}, "literal selected guide/TEN descriptors differ")
    native = load(NATIVE, NATIVE_SHA, "ready0_copy_route_native_pure")
    top = native.read_netlist(SELECTED_RUN.parent / "placed.json")["modules"]["top"]; graph = proof["native_graph_evidence"]
    require(top["cells"][graph["new_clone"]] == graph["actual_new_clone_record"] and
        all(top["cells"][row["cell"]] == row["after_record"] for row in graph["declared_ena_redirects"]), "own selected clone/cohort records differ")
    ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ffs) == 8221 and ffs == previous["all_original_ff_bel_manifest"], "selected fixed FF manifest differs")
    labs = set(map(tuple, previous["affected_whole_labs"]))
    names = set(graph["original_pair"]) | {graph["new_clone"]} | {row["cell"] for row in graph["declared_ena_redirects"]}
    names.update(row["cell"] for row in previous["retained_copy_cohorts"])
    names.update(slot[0] for row in previous["retained_copy_cohorts"] for slot in row["consumer_slots"])
    for model in models: names.update((model["inner"], model["outer"]))
    for name in names:
        match = re.fullmatch(r"MISTRAL_(?:M?COMB|FF)\.(\d+)\.(\d+)\.\d+", top["cells"][name]["attributes"].get("NEXTPNR_BEL", ""))
        require(match, "declared original LUT/cohort owner lacks ordinary BEL"); labs.add(tuple(map(int, match.groups())))
    for key, cells in graph["whole_original_ff_lab_manifest"].items():
        pair = json.loads(key)
        require(type(pair) is list and len(pair) == 2 and all(type(value) is int and value >= 0 for value in pair), "whole leaf-LAB key malformed")
        labs.add(tuple(pair))
        require(all(selected.lab(cell) == pair for cell in cells.values()), "whole leaf-LAB FF records disagree with their key")
    ff_rows = [{"cell": name, "record": cell} for name, cell in top["cells"].items()
        if cell["type"] == "MISTRAL_FF" and tuple(selected.lab(cell)) in labs]
    selected_report = read(SELECTED_RUN.parent / "timing.json")
    require(pair_windows(selected_report) == pair_windows(accepted_report), "accepted/selected seven actual pair windows differ")
    profile = {"schema": 1, "phase": PHASE, "compiler_commit": COMMIT, "delta_base_commit": BASE, "binary_sha256": BINARY_SHA,
        "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "selected_profile_sha256": profile_sha, "selected_run_sha256": run_sha, "selected_proof_sha256": proof_sha,
        "selected_recorder_sha256": SELECTED_HELPER_SHA, "selected_recorder_scope_sha256": SELECTED_SCOPE_SHA,
        "selected_comparer_sha256": SELECTED_COMPARER_SHA, "selected_comparison_scope_sha256": SELECTED_COMPARISON_SCOPE_SHA,
        "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": ACCEPTED_RUN_SHA, "minimum_accepted_memory_mhz": MINIMUM_MEMORY_MHZ,
        "guide_path": previous["guide_path"], "guide_sha256": previous["guide_sha256"], "exact_current_path_object": previous["exact_current_path_object"],
        "original_plan_path": previous["original_plan_path"], "original_plan_sha256": previous["original_plan_sha256"], "local_plan_steps": previous["local_plan_steps"],
        "prefix_fresh_local_models": models, "expected_candidate": previous["expected_candidate"], "expected_copy_prefix": previous["expected_copy_prefix"],
        "pair_candidate_selection": previous["pair_candidate_selection"], "compose_copy_requested": True, "prefix_selected_pair_copy_qualification": applied,
        "prefix_native_graph_evidence": graph, "retained_copy_cohorts": previous["retained_copy_cohorts"],
        "declared_original_lut_pair": previous["declared_original_lut_pair"], "declared_ena_cohort": previous["declared_ena_cohort"],
        "new_local_clone": graph["new_clone"], "new_local_clone_record": graph["actual_new_clone_record"], "declared_ena_redirects": graph["declared_ena_redirects"],
        "affected_whole_labs": sorted(map(list, labs)), "all_original_ff_members_in_affected_labs": ff_rows, "all_original_ff_bel_manifest": ffs,
        "command": command(previous), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"],
        "route_execution": expected_execution(previous), "pure_function_helper_sha256": pure, "input_sha256": dict(sorted(inputs.items())),
        "post_plan_requested": False, "driver_pass_executed": False, "rbf_generation_requested": True,
        "routed_graph_proof_available": False, "physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "explicit_candidate": profile["pair_candidate_selection"], "whole_labs": len(labs)}, indent=2))


def route(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, previous, host = read(PROFILE), read(SELECTED_RUN), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    require(not FOLDER.exists() and profile["phase"] == PHASE and profile["command"] == command(previous) and
        profile["route_execution"] == expected_execution(previous) and profile["cwd"] == previous["cwd"] == str(MODULE) and
        profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
        all(inputs[str(path)] == profile[key] == expected for path, key, expected in ((SELECTED_PROFILE, "selected_profile_sha256", SELECTED_PROFILE_SHA),
            (SELECTED_RUN, "selected_run_sha256", SELECTED_RUN_SHA), (SELECTED_PROOF, "selected_proof_sha256", SELECTED_PROOF_SHA),
            (HOST, "host_validation_sha256", HOST_SHA), (BINARY, "binary_sha256", BINARY_SHA), (ARCHIVE, "source_archive_sha256", ARCHIVE_SHA))) and
        inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"], "frozen route invocation differs")
    positive_selected(read(SELECTED_PROOF), previous); validate_host(host); clean_source(host); modules = definitions()
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["route_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual route runtime differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "fresh selected copy full route did not complete")
        log = (FOLDER / "route.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            not any(label in log for label in ("Running predicted placed timing analysis for --report", "Running final routed timing analysis for --report", "LUT driver copy", "Local-remap post-plan step")),
            "full selected route completion/role differs")
        models, applied = qualification(log, modules, previous)
        require(canonical(models) == canonical(profile["prefix_fresh_local_models"]) and canonical(applied) == canonical(profile["prefix_selected_pair_copy_qualification"]),
            "fresh full TEN/copy selection differs from own positive selected prefix")
        applied_line = f"Info: LUT pair copy applied candidate {profile['pair_candidate_selection']}; full routing and signoff still required."
        require(log.count(applied_line) == 1 and log.index(applied_line) < log.index("Running the GPU router") < log.rindex("Running signoff timing analysis...") < log.index("Info: Program finished normally."),
            "actual selected copy/GPU/final RBF signoff order differs")
        record["actual_selected_local_qualification"], record["actual_selected_pair_copy_qualification"] = models, applied
        native = load(NATIVE, NATIVE_SHA, "ready0_copy_route_output_native_pure")
        metrics = native.PLACEMENT_METRICS.findall(log); prior = native.PLACEMENT_METRICS.findall((SELECTED_RUN.parent / "phase.log").read_text())
        require(len(metrics) == len(prior) == 71 and metrics == prior, "fresh full initial placement metrics differ")
        document = native.read_netlist(FOLDER / "routed.json"); top = document["modules"]["top"]
        ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"}
        require(ffs == profile["all_original_ff_bel_manifest"] and len(ffs) == 8221, "fresh full changed original FF placements")
        report, before_report, accepted_report = read(FOLDER / "timing.json"), read(SELECTED_RUN.parent / "timing.json"), read(ACCEPTED_RUN.parent / "timing.json")
        counts = pair_windows(report)
        require(counts == pair_windows(before_report) == pair_windows(accepted_report) and set(report["fmax"]) == set(accepted_report["fmax"]) and
            all(report["fmax"][key]["constraint"] == accepted_report["fmax"][key]["constraint"] for key in report["fmax"]) and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "full report count/clock/window/Fmax differs")
        frozen = load(FREEZE, FREEZE_SHA, "ready0_copy_route_freeze_pure")
        tables = load(TABLES, TABLES_SHA, "ready0_copy_route_topology_pure", frozen)
        topology = tables.report_topology(document, report, before_report)
        require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7, "actual full native topology incomplete")
        record.update({"all_ten_complete_trial_models_exact": True, "all_71_placement_metrics_exact": True, "all_original_ff_bels_exact": True,
            "actual_selected_copy_gpu_rbf_signoff_order_bound": True, "actual_current_native_report_topology": topology, "fmax": report["fmax"],
            "actual_pair_window_path_counts": [{"from": key[0], "to": key[1], "window_ns": key[2], "paths": count} for key, count in sorted(counts.items())]})
        record["actual_live_gpu_backend"] = board._require_gpu_backend(log)
        require(record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log), "actual completed HIP GPU route absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        record["final_reported_hold_violations"] = "Hold/min time violation" in last
        record["last_signoff_hold_warning_lines"] = [line for line in last.splitlines() if re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not record["final_reported_hold_violations"] and not record["last_signoff_hold_warning_lines"], "LAST RBF signoff has hold/min violations")
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "full output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "explicit_candidate": profile["pair_candidate_selection"], "fmax": record["fmax"], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); finish({**inputs, **record.get("output_sha256", {})}); clean_source(host)
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False; record["final_original_input_output_runtime_hashes_stable"] = False; record["final_rehash_failure"] = repr(error)
                    raise
                finally: (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "route"))
    names = ("self-sha256", "scope-sha256", "selected-profile-sha256", "selected-run-sha256", "selected-proof-sha256")
    for name in (*names, "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = tuple(getattr(args, name.replace("-", "_")) for name in names)
        require(all(values), "actual selected preparation SHA pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared full route SHA pin missing"); route(args.profile_sha256)


if __name__ == "__main__": main()
