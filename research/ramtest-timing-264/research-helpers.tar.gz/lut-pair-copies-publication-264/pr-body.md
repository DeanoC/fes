Adds opt-in late placement optimisation for consecutive ordinary LUTs: either relocate the pair together or compose an isolated LUT copy for a complete same-clock FF enable group. The copy keeps the shared original LUTs and their consumers, all original FF placements and other controls. Candidates must pass complete endpoint setup/hold and clock-pair checks, native LAB legality and exact rollback checks before selection.

The same stack supports local remap plans after control reductions and up to sixteen combined early/post steps. Options remain disabled by default and require fresh ordinary HeAP placement. Listing stays final; invalid or unavailable selections stop before routing even with `--force`. The implementation contains no RAM-test cell-name selectors.

Validation on the publication production source `02269d27` (rebased onto `04a22448`): Release HIP build, **60 native tests, 53 CLI cases and four shared control-set tests passed**, including the two upstream LAB pin-map regressions. Subsequent changes add documentation only.

A separately frozen, fully routed experiment at [`cae5eb9a`](https://github.com/DeanoC/nextpnr/commit/cae5eb9a326507b688414ba934421286f648a43b) reached **117.868927 MHz memory**, up **0.097168 MHz** from the prior accepted 117.771759 MHz. All six required non-target clock-pair windows remain positive and final hold checks are clear; pixel timing decreases slightly but still passes. The native/physical comparison and full 15,290-path report are bound in the [benchmark record](https://github.com/DeanoC/nextpnr/blob/266e3ef7a0821c38a18a3076f7d8b9b1638a7cd2/docs/validation/ramtest-lut-pair-copy-2026-10-02.md) and adjacent JSON.

The publication base includes the newer #108 placement change. Its timing has not yet been qualified against fresh guides; the frozen measurement is not a claim that this rebased binary reproduces it. The memory target of 130 MHz remains unmet, and no default recipe/compiler-pin change or hardware acceptance is included.

Related: https://github.com/DeanoC/fes/issues/264
