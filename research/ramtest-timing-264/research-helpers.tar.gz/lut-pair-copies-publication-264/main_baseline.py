"""Exploratory fresh-main baseline; supplies no independent equivalence or gain proof."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
SOURCE = Path('/home/deano/kepler/worktrees/nextpnr-feat-mistral-lut-pair-copies-264-54cde5d3')
MODEL = WORK / 'sources/misteross/build/toolchain-ramtest-timing/src/mistral'
BINARY = WORK / 'sources/misteross/build/toolchain-ramtest-timing/build/nextpnr-lut-pair-copies-publication-264/nextpnr-mistral'
OLD_RUN = HERE.parent / 'lut-pair-ready1-compose-copy-route-264/route/run.json'
OLD_RUN_SHA = 'c0b1b098fc096ed5c069327a1058b4221bde35925f55a714c9f98a1672e18ec4'
OUTPUT = HERE / 'main-baseline'
PROFILE = HERE / 'main-baseline-profile.json'
INPUTS = {
    'out/ramtest-merged-remap/measured-diagnostic/synth.json': '61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28',
    'sources/misteross/cores/fes-ramtest/constraints.qsf': '8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4',
    'sources/misteross/boards/de10nano/clocks.sdc': '3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041',
}
REMOVE_VALUES = {'--balance-reduction-root', '--remap-plan', '--remap-comb-critical', '--remap-comb-candidate',
                 '--remap-decompose-critical', '--remap-decompose-candidate', '--remap-lut-pair-critical', '--remap-lut-pair-candidate'}
REMOVE_FLAGS = {'--remap-lut-pair-compose-copy'}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()


def code_manifest():
    manifest = {}
    for root in (SOURCE, MODEL, SOURCE / '3rdparty/googletest'):
        for name in git(root, 'ls-files').splitlines():
            path = root / name
            if path.is_file() and (path.suffix in {'.cc', '.h', '.c', '.cpp', '.hip', '.cuh', '.inc', '.py', '.cmake'} or path.name == 'CMakeLists.txt'):
                manifest[str(path)] = sha(path)
    return manifest


def command():
    require(sha(OLD_RUN) == OLD_RUN_SHA, 'original command data changed')
    old = json.loads(OLD_RUN.read_text())['command']
    result, seen, i = [str(BINARY)], set(), 1
    while i < len(old):
        flag = old[i]
        if flag in REMOVE_VALUES:
            require(flag not in seen and i + 1 < len(old), 'unexpected duplicate/missing removable option')
            seen.add(flag); i += 2
        elif flag in REMOVE_FLAGS:
            require(flag not in seen, 'duplicate copy flag')
            seen.add(flag); i += 1
        elif flag in {'--write', '--report', '--rbf'}:
            result.extend([flag, str(OUTPUT / {'--write': 'routed.json', '--report': 'timing.json', '--rbf': 'core.rbf'}[flag])]); i += 2
        else:
            result.append(flag); i += 1
    require(seen == REMOVE_VALUES | REMOVE_FLAGS, 'expected transformations not removed exactly')
    require(not any(flag.startswith('--remap-') or flag.startswith('--balance-') for flag in result), 'guide-driven transformation remains')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-sha256', required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--profile-sha256')
    args = parser.parse_args()
    require(all(re.fullmatch('[0-9a-f]{64}', value) for value in [args.self_sha256, args.binary_sha256]), 'actual activation hashes required')
    require(sha(__file__) == args.self_sha256 and sha(BINARY) == args.binary_sha256, 'recorder/compiler changed')
    require(all(sha(WORK / name) == expected for name, expected in INPUTS.items()), 'frozen input changed')
    require(git(SOURCE, 'merge-base', '04a224483a3e01147523033351176b20ce41317c', 'HEAD') == '04a224483a3e01147523033351176b20ce41317c', 'publication base missing')
    current = {'schema': 1, 'role': 'exploratory fresh-main baseline without guide-driven remaps', 'source_head': git(SOURCE, 'rev-parse', 'HEAD'),
               'source_base': '04a224483a3e01147523033351176b20ce41317c', 'binary_sha256': args.binary_sha256, 'helper_sha256': args.self_sha256,
               'input_sha256': INPUTS, 'production_source_sha256': code_manifest(), 'command': command(), 'cwd': str(WORK / 'sources/misteross'),
               'frozen_qualified_gain_inherited': False, 'independent_equivalence_or_timing_proof_available': False}
    if args.prepare:
        require(not PROFILE.exists() and not OUTPUT.exists(), 'immutable baseline already exists')
        with PROFILE.open('x') as stream:
            stream.write(json.dumps(current, indent=2, sort_keys=True) + '\n')
        print(json.dumps({'profile_sha256': sha(PROFILE), 'production_files': len(current['production_source_sha256'])})); return
    require(args.profile_sha256 and sha(PROFILE) == args.profile_sha256, 'actual prepared profile hash required')
    require(json.loads(PROFILE.read_text()) == current and not OUTPUT.exists(), 'prepared source/command changed or output exists')
    OUTPUT.mkdir()
    env = os.environ.copy()
    removed = sorted(key for key in env if key.startswith('NEXTPNR_'))
    for key in removed:
        env.pop(key)
    env.update({'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'})
    started = time.monotonic()
    with (OUTPUT / 'route.log').open('x') as stream:
        result = subprocess.run(current['command'], cwd=current['cwd'], env=env, stdout=stream, stderr=subprocess.STDOUT)
    elapsed = time.monotonic() - started
    unchanged = sha(BINARY) == args.binary_sha256 and code_manifest() == current['production_source_sha256'] and all(sha(WORK / name) == value for name, value in INPUTS.items())
    log = (OUTPUT / 'route.log').read_text()
    record = {**current, 'source_identity_sha256': args.profile_sha256, 'exit_code': result.returncode, 'elapsed_seconds': elapsed,
              'original_production_and_input_bytes_stable': unchanged, 'cleared_diagnostic_environment_keys': removed,
              'completed_normally': result.returncode == 0 and 'Info: Program finished normally.' in log,
              'output_sha256': {p.name: sha(p) for p in sorted(OUTPUT.iterdir()) if p.is_file()},
              'native_physical_equivalence_proved': False, 'gain_accepted': False, 'hardware_tested': False}
    with (OUTPUT / 'run.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'run_sha256': sha(OUTPUT / 'run.json'), 'exit_code': result.returncode, 'elapsed_seconds': elapsed, 'stable': unchanged}))
    require(unchanged, 'production/input bytes changed during exploratory run')


if __name__ == '__main__':
    main()
