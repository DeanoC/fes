"""Exploratory current-main capture-locality trial; no independent equivalence proof."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
BASE = HERE / 'main-baseline'
BASE_SHA = '3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c'
GUIDE_SHA = 'af2cfae26e73833bf92efc598fad998da1ff4200a9ebb770da4b91755e0d217f'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-sha256', required=True)
    parser.add_argument('--mode', choices=('placed', 'routed'), required=True)
    args = parser.parse_args()
    require(sha(__file__) == args.self_sha256, 'trial recorder changed')
    require(sha(BASE / 'run.json') == BASE_SHA, 'baseline record changed')
    base = json.loads((BASE / 'run.json').read_text())
    require(base['completed_normally'] and base['original_production_and_input_bytes_stable'], 'baseline incomplete')
    require(sha(BASE / 'timing.json') == GUIDE_SHA, 'baseline report changed')
    binary = Path(base['command'][0])
    require(sha(binary) == base['binary_sha256'], 'publication compiler changed')
    sources = base['production_source_sha256']
    require(all(sha(path) == expected for path, expected in sources.items()), 'publication/model bytes changed')
    require(all(sha(WORK / path) == expected for path, expected in base['input_sha256'].items()), 'input changed')
    output = HERE / ('main-capture-b8-r24-' + args.mode)
    require(not output.exists(), 'immutable trial output exists')
    command = []
    index = 0
    while index < len(base['command']):
        flag = base['command'][index]
        if flag in ('--write', '--report', '--rbf'):
            name = {'--write': 'placed.json' if args.mode == 'placed' else 'routed.json',
                    '--report': 'timing.json', '--rbf': 'core.rbf'}[flag]
            if flag != '--rbf' or args.mode == 'routed':
                command.extend((flag, str(output / name)))
            index += 2
        else:
            command.append(flag)
            index += 1
    require(not any(flag.startswith('--remap-') or flag.startswith('--balance-') for flag in command),
            'unexpected guide-driven control transform')
    if args.mode == 'placed':
        command.append('--no-route')
    environment = os.environ.copy()
    cleared = sorted(key for key in environment if key.startswith('NEXTPNR_'))
    for key in cleared:
        environment.pop(key)
    environment.update({'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
                        'NEXTPNR_MISTRAL_CAPTURE_LOCALITY': str(BASE / 'timing.json') + ' 8 24'})
    output.mkdir()
    profile = {'schema': 1, 'role': 'exploratory current-main capture locality', 'mode': args.mode,
               'budget': 8, 'radius': 24, 'baseline_record_sha256': BASE_SHA, 'guide_sha256': GUIDE_SHA,
               'helper_sha256': args.self_sha256, 'binary_sha256': base['binary_sha256'],
               'production_source_sha256': sources, 'input_sha256': base['input_sha256'],
               'command': command, 'cwd': base['cwd'], 'cleared_diagnostic_environment_keys': cleared,
               'native_physical_equivalence_proved': False, 'gain_accepted': False, 'hardware_tested': False}
    (output / 'profile.json').write_text(json.dumps(profile, indent=2, sort_keys=True) + '\n')
    started = time.monotonic()
    with (output / 'route.log').open('x') as stream:
        result = subprocess.run(command, cwd=profile['cwd'], env=environment,
                                stdout=stream, stderr=subprocess.STDOUT)
    elapsed = time.monotonic() - started
    stable = (sha(binary) == profile['binary_sha256'] and sha(BASE / 'run.json') == BASE_SHA and
              sha(BASE / 'timing.json') == GUIDE_SHA and
              all(sha(path) == expected for path, expected in sources.items()) and
              all(sha(WORK / path) == expected for path, expected in base['input_sha256'].items()))
    log = (output / 'route.log').read_text()
    record = {'schema': 1, 'profile_sha256': sha(output / 'profile.json'), 'exit_code': result.returncode,
              'elapsed_seconds': elapsed, 'original_production_input_and_report_bytes_stable': stable,
              'completed_normally': result.returncode == 0 and 'Info: Program finished normally.' in log,
              'output_sha256': {path.name: sha(path) for path in sorted(output.iterdir()) if path.is_file()},
              'capture_messages': [line for line in log.splitlines() if 'Capture locality' in line],
              'native_physical_equivalence_proved': False, 'gain_accepted': False, 'hardware_tested': False}
    with (output / 'run.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'run_sha256': sha(output / 'run.json'), 'exit_code': result.returncode,
                      'elapsed_seconds': elapsed, 'stable': stable, 'capture_messages': record['capture_messages']}))
    require(stable and record['completed_normally'], 'trial failed or bound bytes changed')


if __name__ == '__main__':
    main()
