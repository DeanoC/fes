"""Produce a fresh pre-route guide for the unoptimized publication compiler."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
BASE = HERE / 'main-baseline/run.json'
BASE_SHA = '3389f349e09a9462be09f1ff5c7d0196c8ec775bd0844235b0624642675b529c'
OUTPUT = HERE / 'main-baseline-placed'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-sha256', required=True)
    args = parser.parse_args()
    require(sha(__file__) == args.self_sha256 and sha(BASE) == BASE_SHA, 'recorder/baseline changed')
    base = json.loads(BASE.read_text())
    binary = Path(base['command'][0])
    files = base['production_source_sha256']
    def stable():
        return (sha(binary) == base['binary_sha256'] and sha(BASE) == BASE_SHA and
                all(sha(path) == expected for path, expected in files.items()) and
                all(sha(WORK / path) == expected for path, expected in base['input_sha256'].items()))
    require(stable() and base['completed_normally'] and not OUTPUT.exists(), 'bound bytes changed or output exists')
    command, index = [], 0
    while index < len(base['command']):
        flag = base['command'][index]
        if flag == '--rbf':
            index += 2
        elif flag in ('--write', '--report'):
            command.extend((flag, str(OUTPUT / ('placed.json' if flag == '--write' else 'timing.json'))))
            index += 2
        else:
            command.append(flag)
            index += 1
    command.append('--no-route')
    require(not any(flag.startswith('--remap-') or flag.startswith('--balance-') for flag in command),
            'unexpected control remap')
    environment = {key: value for key, value in os.environ.items() if not key.startswith('NEXTPNR_')}
    environment.update({'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'})
    OUTPUT.mkdir()
    profile = {'schema': 1, 'role': 'fresh pre-route guide, no transforms or timing acceptance',
               'baseline_sha256': BASE_SHA, 'helper_sha256': args.self_sha256,
               'binary_sha256': base['binary_sha256'], 'production_source_sha256': files,
               'input_sha256': base['input_sha256'], 'command': command, 'cwd': base['cwd']}
    (OUTPUT / 'profile.json').write_text(json.dumps(profile, indent=2, sort_keys=True) + '\n')
    started = time.monotonic()
    with (OUTPUT / 'placement.log').open('x') as stream:
        result = subprocess.run(command, cwd=profile['cwd'], env=environment, stdout=stream, stderr=subprocess.STDOUT)
    unchanged = stable()
    record = {'schema': 1, 'profile_sha256': sha(OUTPUT / 'profile.json'), 'exit_code': result.returncode,
              'elapsed_seconds': time.monotonic() - started, 'original_production_and_input_bytes_stable': unchanged,
              'output_sha256': {path.name: sha(path) for path in sorted(OUTPUT.iterdir()) if path.is_file()},
              'native_physical_equivalence_proved': False, 'gain_accepted': False, 'hardware_tested': False}
    with (OUTPUT / 'run.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'run_sha256': sha(OUTPUT / 'run.json'), 'exit_code': result.returncode, 'stable': unchanged}))
    require(unchanged and result.returncode == 0, 'placement failed or bound bytes changed')


if __name__ == '__main__':
    main()
