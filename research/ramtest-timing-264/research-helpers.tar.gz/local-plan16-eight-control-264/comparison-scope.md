# Exact eight-stage control prerequisite

ROOT alone activates this pure comparison after whole-file/hash/AST and peer
review. Explicit actual self/scope, prepared profile and completed run SHA
arguments are mandatory. It does not invoke any compiler, test, GPU route,
old helper entrypoint or authenticator. The new output is exclusively
baseline/comparison-control.json, preserving all old records.

The current d7e5c61f compiler and closed host0f3c11a5 are bound independently
from the old81243 compiler. The parent is ec0a8d0c, not81243. The complete
old eighth edc2c732/profile53fe/native2706 flat closure and current original
host/dependency/profile/output/runtime path hashes are rechecked. Historical
external dependency-file bytes do not authenticate a loaded historical build
or test toolchain. Current invocation runtime must differ only by ELF/PATH
substitution, using the new recorder's pure command/runtime definitions.
The merged final-route report refresh is excluded by actual predicted-only
log role checks, independently of the cap16 source/host tests.

Only pinned32fd lossless parsing/Audit/canonical,72131 native tables/report
topology,8601's local import hook and the reviewed qualification definitions
from the new recorder and a7ef/abd/57ec/a2d/4400 are reused. No prepare/run,
comparison/main, source-clean query or recursive parent authentication is
called. Complete document inputs preserve paired duplicate PLL occurrences.

The old eight literal plan descriptors and all eight complete fresh guarded
model dictionaries, including preceding rejected trials, must match. All71
placement metric rows must match. The full14905-cell/16643-net module, every
raw bit/alias/connection/parameter/attribute/top setting/public port, original
owner and port ordering, lossless paired PLL entries and complete rebuilt
driver/user tables must match without exceptions. All8221 original FF names
and BELs must equal the original manifest. Exported pin/LAB metadata, when
present, is part of strict module equality. Unexported state is not proved.
Creator strings are recorded separately as tool diagnostics; no field of the
native top module is waived or aligned. There is no private-owner renaming,
numeric normalization, buffer collapse, topology or placement tolerance.

The complete current15290-path/seven-pair predicted report is self-validated
against its own native image and the old eighth predicted endpoint/window set.
Its entire JSON report must also equal the old report, including all segments,
clocks, max_delay windows, Fmax and detailed net timing rows. A structural or
topology rejection remains explicit, preserving completed actual report
diagnostics and final hashes. Neither a changed model nor a changed report
qualifies a ninth stage. The single prerequisite flag requires strict native,
model/metric, topology and complete-report equality together.

This is a compiler reproduction gate, not independent numerical STA,
physical equivalence, routing gain or hardware acceptance. Rejected eight-
stage full-route timing is never inherited as a gain. The accepted five-stage
117.771759MHz reference remains unchanged; only a later freshly qualified
and independently checked routed candidate can improve it.
