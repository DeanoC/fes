# Fresh plan16 eight-stage compiler control

ROOT alone activates this new recorder after whole-file/hash/AST and independent
peer review. Preparation requires explicit helper/scope, actual compiler ELF,
source archive and completed host-validation SHA pins. Execution requires the
actual exclusively prepared source-identity.json SHA. No future pin is guessed.

The compiler is clean d7e5c61f on ec0a8d0c. Its current host record must close
native_plan17 and remap_plan_cli13, bind the actual source/archive and compiled
dependency files and preserve its failed initial configure. Every absolute
host artifact/source/submodule/model/dependency pathname is bound and rehashed.
Relative committed archive member keys remain evidence inside the authenticated
host; they are not interpreted as filesystem paths. Live source/model/submodule
commits and clean state are checked again before and after the invocation.

The old baseline is edc2c732, profile53fe73fd and native prefix2706d818. Its
complete flat closure, input/output bytes and loaded runtime remain bound.
The actual original13fa3ff7 eight-stage plan pathname, all report paths,
descriptor order and 8/1/1/1/1/1/1/1 budgets stay literal. No new plan or stage is
created. The only command changes are the compiler executable and two output
aliases. The only loaded-runtime substitutions are old ELF91a51253 to current
ELF41c2afe1 and its controlled PATH directory. All other files, environment,
hardware platform, GPU-device selection, RTL/BUILD_ID, seed and options must
match the old invocation exactly. GPU routing is disabled by --no-route.

The pinned a7ef2ec6/abd9832d/57ec4a9c/a2d62625/440013e3 modules contribute only
their qualification definitions, never their prepare/run/auth/main entrypoints.
All eight new guarded trials and applications are parsed afresh. Complete
model dictionaries, including preceding rejected trials, are compared with
the old eight models as a diagnostic. A new separate comparator must prove
the complete native graph, all8221 original FF BELs,71 placement metrics and
complete15290-path/seven-pair predicted report equal before stage9 is allowed.
This recorder itself does not inherit native, report, physical or gain proof.

The merged PR104 final-route report refresh is a step=route branch. This control
must instead produce exactly one existing step=place predicted report refresh,
with no final-route refresh, signoff, driver pass or RBF. This distinction is
checked from the actual fresh log; reading source alone does not qualify it.

The selected FunctionalInvocation and compiler-read audit mechanisms bind the
actual process runtime and require only the declared compiler/PATH difference.
Exclusive output files are phase.log, placed.json and timing.json. Their hashes
and every original input/runtime pathname are rechecked after completion.
Failures preserve partial hashed outputs and never count as a completed control.
All old artifacts stay untouched. There is no routing, hardware or timing gain
acceptance in this package, and host checks do not prove sixteen transformations.
