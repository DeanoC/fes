"""Compare a closed plan16 eight-stage control with the measured eight-stage image."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE, RUN = HERE / "source-identity.json", HERE / "baseline/run.json"
PROFILE_SHA = "8aa53a2e8fbf0299ddab4d528b22e4c372e996684f81d9c08a73d61204029e3d"
RUNNER = HERE / "run_baseline.py"
RUNNER_SHA = "b5e0f6ad4b09c3d051174e9dd4409f9f02c030a0db9b6626741dec7c715a5749"
RUNNER_SCOPE_SHA = "6df5d7f730aae63cf95710eead246834aa181cba15a2a137867b9fb01e10e7fb"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def prove_module(native, selected, before, after, ff_manifest):
    require(set(before) == set(after) == {"creator", "modules"} and set(before["modules"]) == set(after["modules"]) == {"top"},
            "complete native document shape differs")
    a, b = before["modules"]["top"], after["modules"]["top"]
    require(len(a["cells"]) == len(b["cells"]) == 14905 and len(a["netnames"]) == len(b["netnames"]) == 16643 and
            native.canonical(a) == native.canonical(b), "complete native module metadata/cells/nets/raw IDs differ")
    require(list(a) == list(b) and list(a["cells"]) == list(b["cells"]) and list(a["netnames"]) == list(b["netnames"]) and
            list(a["ports"]) == list(b["ports"]) and native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "native module/owner/public-port order or lossless paired PLL entries differ")
    for name, cell in a["cells"].items():
        other = b["cells"][name]
        require(list(cell["connections"]) == list(other["connections"]) and list(cell["port_directions"]) == list(other["port_directions"]),
                "original cell port/direction order differs: " + name)
    require(selected.native_tables(a) == selected.native_tables(b), "complete raw driver/user slot tables differ")
    actual_a = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_FF"}
    actual_b = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in b["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ff_manifest) == 8221 and actual_a == actual_b == ff_manifest, "all8221 original FF names/BELs differ")
    return {"complete_native_module_exact": True, "original_owner_and_port_order_exact": True,
        "lossless_paired_pll_entries_exact": True, "native_driver_and_user_slot_tables_exact": True,
        "all_original_ff_bels_exact": True, "original_ff_count": 8221, "cells": 14905, "netnames": 16643,
        "raw_id_translation_or_native_field_waiver_used": False, "unexported_pins_lab_caches_or_physical_state_proved": False}


def compare(self_sha, scope_sha, profile_sha, run_sha):
    require(profile_sha == PROFILE_SHA, "actual prepared control profile pin differs")
    native = load(NATIVE, NATIVE_SHA, "plan16_eight_native_pure")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha),
            (PROFILE, profile_sha), (RUN, run_sha), (RUNNER, RUNNER_SHA), (HERE / "scope.md", RUNNER_SCOPE_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    runner = load(RUNNER, RUNNER_SHA, "plan16_eight_runner_pure")
    for path, expected in ((runner.OLD, runner.OLD_SHA), (runner.OLD_PREFIX, runner.OLD_PREFIX_SHA), (runner.HOST, runner.HOST_SHA), *runner.PARSERS):
        audit.bind(path, expected)
    profile, record, old, host, prefix = (native.read(path) for path in (PROFILE, RUN, runner.OLD, runner.HOST, runner.OLD_PREFIX))
    runner.host_valid(host, runner.HOST_SHA)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == profile_sha and
            all(record[key] == value for key, value in profile.items() if key != "input_sha256") and
            record["input_sha256"] == {**profile["input_sha256"], str(PROFILE): profile_sha} and
            not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel", "partial_outputs_only")),
            "current baseline is not its closed exact profile/input-union record")
    require(profile["phase"] == "local-plan16-exact-eight-stage-predicted-control" and
            profile["command"] == runner.command(old) and record["execution"] == profile["baseline_execution"] == runner.expected_execution(old) and
            profile["diagnostic_environment"] == old["diagnostic_environment"] and profile["cwd"] == old["cwd"] == str(runner.MODULE) and
            profile["compiler_commit"] == host["compiler_commit"] == runner.COMMIT and profile["delta_base_commit"] == host["delta_base_commit"] == runner.BASE and
            old["compiler_commit"] == runner.OLD_COMMIT and profile["binary_sha256"] == runner.BINARY_SHA and
            profile["source_archive_sha256"] == runner.ARCHIVE_SHA and profile["helper_sha256"] == RUNNER_SHA and
            profile["scope_sha256"] == RUNNER_SCOPE_SHA and profile["host_validation_sha256"] == runner.HOST_SHA and
            profile["committed_archive_member_sha256"] == host["committed_archive_manifest_sha256"], "new compiler/host/archive/runtime role differs")
    for ledger in (profile["input_sha256"], old["input_sha256"], old["output_sha256"], *(host[key] for key in runner.HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "host/control flat entry is not absolute")
            audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    for runtime in (old["execution"], record["execution"]):
        for path, expected in runtime["files"].items(): audit.bind(Path(path), expected, execution=True)
    for path, expected in prefix["artifact_sha256"].items():
        require(not Path(path).is_absolute() and ".." not in Path(path).parts, "old flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    for path, expected in prefix["execution_file_sha256"].items(): audit.bind(Path(path), expected, execution=True)
    require(old["completed"] is True and old["exit_code"] == 0 and old["compiler_read_audit_passed"] is True and
            old["final_original_input_output_runtime_hashes_stable"] is True and old["source_identity_sha256"] == runner.OLD_PROFILE_SHA and
            old["binary_sha256"] == runner.OLD_BINARY_SHA and old["source_archive_sha256"] == runner.OLD_ARCHIVE_SHA and
            profile["retained_baseline_run_sha256"] == runner.OLD_SHA and profile["retained_baseline_profile_sha256"] == runner.OLD_PROFILE_SHA and
            profile["retained_prefix_proof_sha256"] == runner.OLD_PREFIX_SHA and prefix["native_graph_proof_available"] is True and
            prefix["structural_rejection"] is None and prefix["current_baseline_run_sha256"] == runner.OLD_SHA and
            prefix["source_identity_sha256"] == runner.OLD_PROFILE_SHA and
            profile["current_host_case_counts"] == {key: value["cases"] for key, value in host["checks"].items()}, "old eighth reference/new host closure differs")
    require(audit.paths.get(Path(profile["original_plan_path"])) == profile["original_plan_sha256"] == runner.OLD_PLAN_SHA and
            profile["original_plan_path"] == str(runner.OLD_FOLDER / "local-plan.json") and
            native.read(profile["original_plan_path"])["steps"] == profile["local_plan_steps"] and len(profile["local_plan_steps"]) == 8 and
            [step["groups"] for step in profile["local_plan_steps"]] == [8, 1, 1, 1, 1, 1, 1, 1] and
            all(step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True for step in profile["local_plan_steps"]),
            "literal original eight-stage plan changed")
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")}, "predicted output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "empty current predicted output")
        audit.bind(Path(path), expected)
    definitions = runner.local_definitions()
    old_log, log = (runner.OLD.parent / "phase.log").read_text(), (HERE / "baseline/phase.log").read_text()
    old_models, models = runner.qualification(old_log, definitions), runner.qualification(log, definitions)
    require(native.canonical(old_models) == native.canonical(old["actual_selected_local_qualification"]) == native.canonical(profile["retained_local_models"]) and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]), "actual complete trial bindings differ")
    models_exact = native.canonical(models) == native.canonical(old_models)
    require(record["all_eight_complete_trial_models_exact"] is models_exact, "recorded complete-model diagnostic differs")
    metrics = len(native.PLACEMENT_METRICS.findall(log)) == 71 and native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(old_log)
    frozen = load(FREEZE, FREEZE_SHA, "plan16_eight_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "plan16_eight_selected_pure", frozen)
    before, after = native.read_netlist(runner.OLD.parent / "placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    evidence, rejection = None, None
    try:
        require(models_exact and metrics, "eight complete trial models or71 placement metrics differ")
        require(profile["all_original_ff_bel_manifest"] == old["all_original_ff_bel_manifest"], "original FF manifest changed")
        evidence = prove_module(native, selected, before, after, profile["all_original_ff_bel_manifest"])
    except (ValueError, TypeError, KeyError, IndexError) as error:
        rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(runner.OLD.parent / "timing.json")
    topology, topology_rejection = None, None
    try:
        topology = selected.report_topology(after, report, old_report)
        require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7, "predicted native topology count/pairs differ")
    except (ValueError, TypeError, KeyError, IndexError) as error:
        topology_rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    report_exact = native.canonical(report) == native.canonical(old_report)
    require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and record["actual_predicted_fmax"] == report["fmax"] and
            "Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy")), "predicted report/phase role differs")
    audit.finish()
    return {"schema": 1, "phase": "local-plan16-exact-eight-stage-native-control", "source_identity_sha256": profile_sha,
        "current_baseline_run_sha256": run_sha, "retained_baseline_run_sha256": runner.OLD_SHA, "retained_prefix_proof_sha256": runner.OLD_PREFIX_SHA,
        "compiler_commit": runner.COMMIT, "delta_base_commit": runner.BASE, "generator_sha256": self_sha, "scope_sha256": scope_sha,
        "host_validation_sha256": runner.HOST_SHA, "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "current_actual_execution": record["execution"], "authorized_runtime_delta": profile["authorized_runtime_delta"],
        "pure_function_helper_sha256": {str(path): expected for path, expected in ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (RUNNER, RUNNER_SHA), *runner.PARSERS)},
        "creator_strings": {"before": before["creator"], "after": after["creator"]}, "creator_strings_equal": before["creator"] == after["creator"],
        "old_local_models": old_models, "fresh_local_models": models, "all_eight_complete_trial_models_exact": models_exact,
        "all_71_placement_metrics_exact": metrics, "structural_rejection": rejection, "native_graph_proof_available": rejection is None,
        "native_graph_evidence": evidence, "current_predicted_native_paths": topology, "native_path_topology_rejection": topology_rejection,
        "complete_predicted_report_exact": report_exact, "actual_predicted_fmax": report["fmax"],
        "fresh_ninth_stage_control_prerequisite_proved": rejection is None and topology_rejection is None and report_exact,
        "raw_id_alignment_or_native_module_field_waiver_used": False, "independent_physical_equivalence_proved": False,
        "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "run-sha256"): parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    output = HERE / "baseline/comparison-control.json"
    require(not output.exists(), "immutable control comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.profile_sha256, args.run_sha256)
    with output.open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "complete_predicted_report_exact": result["complete_predicted_report_exact"],
        "fresh_ninth_stage_control_prerequisite_proved": result["fresh_ninth_stage_control_prerequisite_proved"]}, indent=2))


if __name__ == "__main__": main()
