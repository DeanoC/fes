"""Record fresh ready0 candidate0 selection after exact control and listing proofs."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-placement-264"
COMPILER, CONTROL, LISTING = (RAW / name for name in
    ("lut-pair-placement-264", "lut-pair-ten-control-264", "lut-pair-ready0-listing-264"))
COMMIT, BASE = "UNFROZEN_COMMIT", "b3d036549c29a333e67c61bd1b23e705bce75d41"
BINARY, ARCHIVE, HOST = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz", COMPILER / "validation/host-validation.json"
BINARY_SHA, ARCHIVE_SHA, HOST_SHA = "UNFROZEN_BINARY", "UNFROZEN_ARCHIVE", "UNFROZEN_HOST"
HOST_HELPER_SHA = "80af57eefb926577426c7043e46a438b938c282b5bb57d87301e88a9a7467d1c"
HOST_SCOPE_SHA = "a32cf00ffef05c9260c2b1ffea9668bd83db231bc35a89e10fb6741b5eb98c98"
CONTROL_PROFILE, CONTROL_RUN, CONTROL_PROOF = CONTROL / "source-identity.json", CONTROL / "baseline/run.json", CONTROL / "baseline/comparison-control.json"
CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA = "UNFROZEN_CONTROL_PROFILE", "UNFROZEN_CONTROL_RUN", "UNFROZEN_CONTROL_PROOF"
CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA = "UNFROZEN_CONTROL_HELPER", "UNFROZEN_CONTROL_SCOPE"
CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA = "UNFROZEN_CONTROL_COMPARER", "UNFROZEN_CONTROL_COMPARISON_SCOPE"
LISTING_PROFILE, LISTING_RUN, LISTING_PROOF = LISTING / "source-identity.json", LISTING / "listing/run.json", LISTING / "listing/comparison-listing.json"
LISTING_PROFILE_SHA, LISTING_RUN_SHA, LISTING_PROOF_SHA = "UNFROZEN_LISTING_PROFILE", "UNFROZEN_LISTING_RUN", "UNFROZEN_LISTING_PROOF"
LISTING_HELPER_SHA, LISTING_SCOPE_SHA = "UNFROZEN_LISTING_HELPER", "UNFROZEN_LISTING_SCOPE"
LISTING_COMPARER_SHA, LISTING_COMPARISON_SCOPE_SHA = "UNFROZEN_LISTING_COMPARER", "UNFROZEN_LISTING_COMPARISON_SCOPE"
GUIDE = LISTING / "ready0-guide.json"
GUIDE_SHA = "9bdad54100c802d4a4aa366203afcaaffcfd4f69456d0ec2b0f6ac58ac786d41"
OLD_PLAN = RAW / "local-plan16-ready1-command-stage-264/local-plan.json"
OLD_PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "selected"
INNER, OUTER = "hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B"
SINK = "hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_1"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}
TRIAL = re.compile(r"^Info: LUT pair placement trial inner=(\S+) outer=(\S+) sink=(\S+) inner_bel=(\S+) outer_bel=(\S+) gain=(-?\d+)ps improve=(\d+) endpoints=(\d+) clocks=(\d+) hold=(\d+) fixed=(\d+)$", re.M)
CHOICE = re.compile(r"^Info: LUT pair placement candidate (\d+): inner=(\S+) outer=(\S+) sink=(\S+) inner_bel=(\S+) outer_bel=(\S+) gain=(-?\d+)ps\.$", re.M)


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch("[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original pathname hash")
    if path not in inputs:
        require(sha(path) == expected, "original input differs: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat runtime entry is not absolute"); bind(inputs, name, expected)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def definitions():
    control = load(CONTROL / "run_baseline.py", CONTROL_HELPER_SHA, "ready0_selected_control_pure")
    return control, control.definitions()


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and
        set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == set(host["changed_source_files"]), "current source differs from the clean host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
        [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def closed_record(record, profile, path, expected):
    require(record["completed"] is True and record["exit_code"] == 0 and
        record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
        record["source_identity_sha256"] == expected and record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(canonical(record[key]) == canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "prerequisite profile/run is not closed")


def command(control, folder=FOLDER, selection=0):
    result = list(control["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == result.count("--remap-plan") == 1 and
        result[result.index("--remap-plan") + 1] == str(OLD_PLAN) and not any(flag in result for flag in
        ("--no-pack", "--no-place", "--rbf", "--remap-post-plan", "--remap-lut-pair-critical", "--remap-lut-pair-candidate", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "proved control command role differs")
    for flag, path in (("--write", folder / "placed.json"), ("--report", folder / "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector"); result[result.index(flag) + 1] = str(path)
    return result + ["--remap-lut-pair-critical", str(GUIDE), "--remap-lut-pair-candidate", str(selection)]


def guarded_candidate(choice, trial):
    require(trial.groups()[:6] == choice.groups()[1:] and trial.groups()[6:] == ("1",) * 5 and int(trial[6]) >= 250,
        "candidate lacks its complete all-guarded preceding trial")
    return {"candidate": int(choice[1]), "inner": choice[2], "outer": choice[3], "sink": choice[4],
        "inner_bel": choice[5], "outer_bel": choice[6], "gain_ps": int(choice[7]), "actual_guarded_trial": list(trial.groups())}


def listing_candidate(log):
    discovery = list(re.finditer(r"^Info: LUT pair placement discovery: (\d+) bounded pairs\.$", log, re.M))
    summary = list(re.finditer(r"^Info: LUT pair placement: (\d+) qualified candidates; no candidate applied\.$", log, re.M))
    require(len(discovery) == len(summary) == 1 and discovery[0].end() < summary[0].start() and int(discovery[0][1]) <= 8 and
        not re.search(r"^Info: LUT pair placement applied candidate", log, re.M), "prerequisite is not a complete bounded listing")
    block = log[discovery[0].end():summary[0].start()]; trials, choices = list(TRIAL.finditer(block)), list(CHOICE.finditer(block))
    require(len(trials) <= 128 and [int(row[1]) for row in choices] == list(range(int(summary[0][1]))) and choices,
        "listing has no actual candidate0 or its candidate/trial bounds differ")
    candidates = []
    for choice in choices:
        prior = [trial for trial in trials if trial.end() < choice.start()]; require(prior, "listing candidate has no preceding actual trial")
        candidates.append(guarded_candidate(choice, prior[-1]))
    return candidates[0]


def qualification(log, control, parsers, expected_candidate):
    discovery = list(re.finditer(r"^Info: LUT pair placement discovery: (\d+) bounded pairs\.$", log, re.M))
    applied = list(re.finditer(r"^Info: LUT pair placement applied candidate (\d+); full routing and signoff still required\.$", log, re.M))
    require(len(discovery) == len(applied) == 1 and discovery[0].end() < applied[0].start() and int(discovery[0][1]) <= 8 and
        int(applied[0][1]) == 0 and not re.search(r"^Info: LUT pair placement: .*no candidate applied", log, re.M), "actual candidate0 selected-return phase differs")
    models = control.qualification(log[:discovery[0].start()], parsers)
    block = log[discovery[0].end():applied[0].start()]; trials, choices = list(TRIAL.finditer(block)), list(CHOICE.finditer(block))
    require(len(trials) <= 128 and len(choices) == 1 and int(choices[0][1]) == 0 and not TRIAL.search(log[applied[0].end():]) and
        not CHOICE.search(log[applied[0].end():]), "selected candidate ordinal/trial/early-return bounds differ")
    prior = [trial for trial in trials if trial.end() < choices[0].start()]; require(prior, "selected candidate lacks a prior trial")
    candidate = guarded_candidate(choices[0], prior[-1])
    require(canonical(candidate) == canonical(expected_candidate) and candidate["inner"] == INNER and candidate["outer"] == OUTER and
        candidate["sink"] == SINK + ".ENA", "fresh candidate0 identity/site/gain/trial differs from proved listing")
    return models, {**candidate, "candidate_applied": True, "actual_trial_count": len(trials),
        "actual_trial_rows": [list(row.groups()) for row in trials], "all_pair_diagnostic_lines": [line for line in log.splitlines() if line.startswith("Info: LUT pair placement")],
        "selected_graph_or_physical_equivalence_proved": False, "routed_gain_accepted": False}


def prepare(self_sha, scope_sha, control_profile_sha, control_run_sha, control_proof_sha, listing_profile_sha, listing_run_sha, listing_proof_sha, binary_sha, archive_sha, host_sha):
    actual = (control_profile_sha, control_run_sha, control_proof_sha, listing_profile_sha, listing_run_sha, listing_proof_sha, binary_sha, archive_sha, host_sha)
    pinned = (CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA, LISTING_PROFILE_SHA, LISTING_RUN_SHA, LISTING_PROOF_SHA, BINARY_SHA, ARCHIVE_SHA, HOST_SHA)
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in
        (self_sha, scope_sha, *pinned, CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA, CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA,
         LISTING_HELPER_SHA, LISTING_SCOPE_SHA, LISTING_COMPARER_SHA, LISTING_COMPARISON_SCOPE_SHA)), "actual current/control/listing pins remain UNFROZEN")
    require(actual == pinned and not PROFILE.exists() and not FOLDER.exists(), "actual activation pins and exclusive selected outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (CONTROL_PROFILE, control_profile_sha),
        (CONTROL_RUN, control_run_sha), (CONTROL_PROOF, control_proof_sha), (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA),
        (CONTROL / "scope.md", CONTROL_SCOPE_SHA), (CONTROL / "compare_control.py", CONTROL_COMPARER_SHA),
        (CONTROL / "comparison-scope.md", CONTROL_COMPARISON_SCOPE_SHA), (LISTING_PROFILE, listing_profile_sha), (LISTING_RUN, listing_run_sha),
        (LISTING_PROOF, listing_proof_sha), (LISTING / "run_listing.py", LISTING_HELPER_SHA), (LISTING / "scope.md", LISTING_SCOPE_SHA),
        (LISTING / "compare_listing.py", LISTING_COMPARER_SHA), (LISTING / "comparison-scope.md", LISTING_COMPARISON_SCOPE_SHA),
        (HOST, host_sha), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (BINARY, binary_sha), (ARCHIVE, archive_sha), (GUIDE, GUIDE_SHA), (OLD_PLAN, OLD_PLAN_SHA)):
        bind(inputs, path, expected)
    control_profile, previous, control_proof, listing_profile, listed, listing_proof, host = (read(path) for path in
        (CONTROL_PROFILE, CONTROL_RUN, CONTROL_PROOF, LISTING_PROFILE, LISTING_RUN, LISTING_PROOF, HOST))
    closed_record(previous, control_profile, CONTROL_PROFILE, control_profile_sha); closed_record(listed, listing_profile, LISTING_PROFILE, listing_profile_sha)
    require(previous["execution"] == control_profile["baseline_execution"] == listed["execution"] == listing_profile["listing_execution"] and
        listed["command"] == command(previous, LISTING / "listing", -1) and listed["cwd"] == previous["cwd"] == str(MODULE) and
        listed["diagnostic_environment"] == previous["diagnostic_environment"] and listing_profile["guide_path"] == str(GUIDE) and
        listing_profile["guide_sha256"] == GUIDE_SHA and listing_profile["control_profile_sha256"] == control_profile_sha and
        listing_profile["control_run_sha256"] == control_run_sha and listing_profile["control_proof_sha256"] == control_proof_sha,
        "current listing does not retain the proved control/guide/command/runtime")
    require(control_proof["schema"] == 1 and control_proof["phase"] == "lut-pair-disabled-ten-stage-native-control" and
        control_proof["source_identity_sha256"] == control_profile_sha and control_proof["current_baseline_run_sha256"] == control_run_sha and
        control_proof["generator_sha256"] == CONTROL_COMPARER_SHA and control_proof["scope_sha256"] == CONTROL_COMPARISON_SCOPE_SHA and
        control_proof["recorder_sha256"] == CONTROL_HELPER_SHA and control_proof["recorder_scope_sha256"] == CONTROL_SCOPE_SHA and
        control_proof["compiler_commit"] == COMMIT and control_proof["delta_base_commit"] == BASE and control_proof["host_validation_sha256"] == HOST_SHA and
        control_proof["current_actual_execution"] == previous["execution"] and control_proof["structural_rejection"] is control_proof["native_path_topology_rejection"] is None and
        all(control_proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact", "complete_predicted_report_exact", "fresh_lut_pair_control_prerequisite_proved", "final_original_path_metadata_and_runtime_hashes_stable")) and
        all(control_proof[key] == {"d7e_original_ten": True, "b3d_disabled_post_ten": True} for key in ("ten_model_equality_by_reference", "placement_metric_equality_by_reference", "complete_report_equality_by_reference")),
        "fresh dual-reference disabled control prerequisite is not positive")
    require(listing_proof["schema"] == 1 and listing_proof["phase"] == "lut-pair-ready0-listing-native-reproduction" and
        listing_proof["source_identity_sha256"] == listing_profile_sha and
        listing_proof["current_listing_run_sha256"] == listing_run_sha and listing_proof["control_proof_sha256"] == control_proof_sha and
        listing_proof["control_profile_sha256"] == control_profile_sha and listing_proof["control_run_sha256"] == control_run_sha and
        listing_proof["generator_sha256"] == LISTING_COMPARER_SHA and listing_proof["scope_sha256"] == LISTING_COMPARISON_SCOPE_SHA and
        listing_proof["recorder_sha256"] == LISTING_HELPER_SHA and listing_proof["recorder_scope_sha256"] == LISTING_SCOPE_SHA and
        listing_proof["compiler_commit"] == COMMIT and listing_proof["delta_base_commit"] == BASE and listing_proof["host_validation_sha256"] == HOST_SHA and
        listing_proof["current_actual_execution"] == listed["execution"] and
        listing_proof["structural_rejection"] is listing_proof["model_or_listing_rejection"] is listing_proof["native_path_topology_rejection"] is None and
        all(listing_proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
            "all_71_placement_metrics_exact", "complete_predicted_report_exact", "recorded_reproduction_diagnostics_exact",
            "fresh_lut_pair_listing_reproduction_proved", "final_original_path_metadata_and_runtime_hashes_stable")) and
        canonical(listing_proof["actual_pair_listing"]) == canonical(listed["actual_pair_listing"]),
        "separate fresh listing reproduction prerequisite is not positive")
    counts = {"pair_backend": 12, "native_plan": 25, "driver_backend": 10, "pair_cli": 11, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["compiler_commit"] == host["result_commit"] == previous["compiler_commit"] == COMMIT and
        host["delta_base_commit"] == previous["delta_base_commit"] == BASE and host["binary_sha256"] == previous["binary_sha256"] == BINARY_SHA and
        host["source_archive_sha256"] == previous["source_archive_sha256"] == ARCHIVE_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and set(host["checks"]) == set(counts) and
        all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()), "current independent host/compiler qualification differs")
    for proof in (control_proof, listing_proof): adopt(inputs, proof)
    for record in (previous, listed):
        output_folder = Path(record["command"][record["command"].index("--write") + 1]).parent
        require(set(record["output_sha256"]) == {str(output_folder / name) for name in ("phase.log", "placed.json", "timing.json")},
            "prerequisite three-output set differs")
    for ledger in (previous["input_sha256"], previous["output_sha256"], listed["input_sha256"], listed["output_sha256"],
        previous["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original closure path is not absolute"); bind(inputs, path, expected)
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    control, parsers = definitions()
    require(control.COMMIT == COMMIT and control.BINARY_SHA == BINARY_SHA and control.ARCHIVE_SHA == ARCHIVE_SHA and control.HOST_SHA == HOST_SHA,
        "called current pure parser identity differs")
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    models = control.qualification((CONTROL_RUN.parent / "phase.log").read_text(), parsers)
    listing_log = (LISTING_RUN.parent / "phase.log").read_text(); candidate = listing_candidate(listing_log)
    discovery = re.search(r"^Info: LUT pair placement discovery:", listing_log, re.M)
    require(canonical(models) == canonical(control.qualification(listing_log[:discovery.start()], parsers)) ==
        canonical(previous["actual_selected_local_qualification"]) == canonical(listed["actual_selected_local_qualification"]) == canonical(control_proof["fresh_local_models"]) and len(models) == 10 and
        listed["actual_pair_listing"]["candidate0_reported"] is True and listed["actual_pair_listing"]["candidate_applied"] is False and
        canonical(candidate) == canonical(listed["actual_pair_listing"]["actual_qualified_candidates"][0]) and
        candidate["candidate"] == 0 and candidate["inner"] == INNER and candidate["outer"] == OUTER and candidate["sink"] == SINK + ".ENA",
        "actual listing candidate0 or retained ten complete models differ")
    guide = read(GUIDE)
    require(guide == {"critical_paths": [listing_profile["exact_current_path_object"]]} and len(previous["all_original_ff_bel_manifest"]) == 8221 and
        SINK in previous["all_original_ff_bel_manifest"] and read(OLD_PLAN)["steps"] == previous["local_plan_steps"] == listing_profile["local_plan_steps"] and
        len(previous["local_plan_steps"]) == 10, "exact current guide/plan/fixed FF manifest differs")
    profile = {"schema": 1, "phase": "lut-pair-ready0-candidate0-predicted-selection", "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA,
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "control_profile_sha256": control_profile_sha, "control_run_sha256": control_run_sha,
        "control_proof_sha256": control_proof_sha, "listing_profile_sha256": listing_profile_sha, "listing_run_sha256": listing_run_sha,
        "listing_proof_sha256": listing_proof_sha, "control_recorder_sha256": CONTROL_HELPER_SHA, "control_recorder_scope_sha256": CONTROL_SCOPE_SHA,
        "listing_recorder_sha256": LISTING_HELPER_SHA, "listing_recorder_scope_sha256": LISTING_SCOPE_SHA,
        "listing_comparer_sha256": LISTING_COMPARER_SHA, "listing_comparison_scope_sha256": LISTING_COMPARISON_SCOPE_SHA,
        "guide_path": str(GUIDE), "guide_sha256": GUIDE_SHA, "exact_current_path_object": listing_profile["exact_current_path_object"],
        "original_plan_path": str(OLD_PLAN), "original_plan_sha256": OLD_PLAN_SHA, "local_plan_steps": previous["local_plan_steps"],
        "retained_local_models": models, "retained_copy_cohorts": previous["retained_copy_cohorts"], "all_original_ff_bel_manifest": previous["all_original_ff_bel_manifest"],
        "fixed_terminal_ff": {"cell": SINK, "bel": previous["all_original_ff_bel_manifest"][SINK]}, "expected_candidate0": candidate,
        "declared_movable_lut_cells": [INNER, OUTER], "pair_candidate_selection": 0, "command": command(previous), "cwd": previous["cwd"],
        "diagnostic_environment": previous["diagnostic_environment"], "selected_execution": copy.deepcopy(previous["execution"]),
        "post_plan_requested": False, "driver_pass_executed": False, "native_or_physical_reproduction_inherited": False,
        "selected_graph_or_physical_equivalence_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "input_sha256": dict(sorted(inputs.items()))}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "candidate0": candidate}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, previous, host = read(PROFILE), read(CONTROL_RUN), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    require(not FOLDER.exists() and profile["phase"] == "lut-pair-ready0-candidate0-predicted-selection" and
        profile["command"] == command(previous) and profile["selected_execution"] == previous["execution"] and profile["cwd"] == previous["cwd"] == str(MODULE) and
        profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
        all(inputs[str(path)] == profile[key] == expected for path, key, expected in
            ((CONTROL_PROFILE, "control_profile_sha256", CONTROL_PROFILE_SHA), (CONTROL_RUN, "control_run_sha256", CONTROL_RUN_SHA),
             (CONTROL_PROOF, "control_proof_sha256", CONTROL_PROOF_SHA), (LISTING_PROFILE, "listing_profile_sha256", LISTING_PROFILE_SHA),
             (LISTING_RUN, "listing_run_sha256", LISTING_RUN_SHA), (LISTING_PROOF, "listing_proof_sha256", LISTING_PROOF_SHA),
             (HOST, "host_validation_sha256", HOST_SHA), (BINARY, "binary_sha256", BINARY_SHA), (ARCHIVE, "source_archive_sha256", ARCHIVE_SHA),
             (GUIDE, "guide_sha256", GUIDE_SHA))) and inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and
        inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and read(GUIDE) == {"critical_paths": [profile["exact_current_path_object"]]},
        "frozen selected profile/guide/command/runtime differs")
    control, parsers = definitions(); clean_source(host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["selected_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "loaded runtime differs from the proved control")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "fresh selected ready0 placement did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step")) and
            not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual selection is not predicted-only/no post or driver")
        models, selected = qualification(log, control, parsers, profile["expected_candidate0"])
        record["actual_selected_local_qualification"], record["actual_selected_pair_qualification"] = models, selected
        record["all_ten_complete_trial_models_exact"] = canonical(models) == canonical(profile["retained_local_models"])
        metric = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
        rows, prior_rows = metric.findall(log), metric.findall((CONTROL_RUN.parent / "phase.log").read_text())
        record["all_71_placement_metrics_exact"] = len(rows) == len(prior_rows) == 71 and rows == prior_rows
        require(record["all_ten_complete_trial_models_exact"] and record["all_71_placement_metrics_exact"], "selected run changed earlier ten models or placement metrics")
        report, before_report = read(FOLDER / "timing.json"), read(CONTROL_RUN.parent / "timing.json")
        def pairs(document):
            counts = {}
            for path in document["critical_paths"]:
                key = (path["from"], path["to"], path["max_delay"]); counts[key] = counts.get(key, 0) + 1
            return counts
        current_pairs, original_pairs = pairs(report), pairs(before_report)
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and len(current_pairs) == 7 and current_pairs == original_pairs and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "complete selected predicted report cap/count/pair-window/Fmax differs")
        record["actual_predicted_fmax"] = report["fmax"]
        record["actual_predicted_pair_window_path_counts"] = [{"from": key[0], "to": key[1], "window_ns": key[2], "paths": count} for key, count in sorted(current_pairs.items())]
        record["complete_predicted_report_exact_diagnostic"] = canonical(report) == canonical(before_report)
        record["output_sha256"] = {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "selected output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "candidate0_applied": True, "selected_graph_or_physical_equivalence_proved": False, "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute"))
    names = ("self-sha256", "scope-sha256", "control-profile-sha256", "control-run-sha256", "control-proof-sha256", "listing-profile-sha256", "listing-run-sha256", "listing-proof-sha256", "binary-sha256", "archive-sha256", "host-sha256")
    for name in (*names, "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = tuple(getattr(args, name.replace("-", "_")) for name in names)
        require(all(values), "actual preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
