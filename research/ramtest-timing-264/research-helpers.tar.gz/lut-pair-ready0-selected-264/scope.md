# Fresh ready0 candidate0 predicted selection

This helper owns only its new source-identity.json and selected output folder.
ROOT alone fills actual compiler/control/listing pins, reviews final whole bytes
and hashes, runs AST and peer checks, then activates prepare and execute.
UNFROZEN pins prevent preparation. Explicit self/scope/current control profile,
run and proof/listing profile, run and proof/ELF/archive/host hashes are mandatory;
execute requires the actual exclusive prepared profile hash. Existing source,
compiler, guides, controls, listing helpers and evidence are unchanged.

The current disabled-ten control must reproduce both the original d7e5 ten
control and the closed b3d disabled-post ten control exactly. The separate fresh
listing comparison must prove fresh_lut_pair_listing_reproduction_proved. Both
closed profile/run input unions and actual execution files, three output files,
proof artifact/runtime maps, current host source/dependency maps and selected
clean committed source/submodule/model identities are checked before and after
preparation and execution. Current host checks remain47 native and45 CLI cases.
Only the current control's definition loader and pure ten-model qualification
chain are called. No old authentication, prepare, execute, main or comparison
entrypoint is activated.

The guide is the literal current single-path ready0-guide.json9bdad541 produced
by the listing profile53f82bb5. It remains critical_paths-only with the exact
proved current report object. The actual listing log must contain candidate0
for the original port0 inner ALUT2/outer ALUT3_B and fixed skid_burstcount FF1.ENA.
Its complete preceding trial must have all five guards1 and gain at least250ps.
The candidate identity, both new BELs, reported gain and every guarded trial
field are recorded without assuming candidate existence or qualified placement.

The fresh argv retains the literal ten-stage plan00bf, every original descriptor,
source JSON/QSF/SDC/device/seed/option and diagnostic environment. It changes
only output paths and adds the exact current guide with pair selection0. It
retains --no-route; no replay, post plan, driver copy or RBF output is introduced.
The loaded five project-module paths/hashes, FunctionalInvocation inputs and
compiler-read audit must match the proved control runtime exactly.

The selected backend logs a discovery, guarded trial and candidate0, then returns
immediately after its applied-candidate marker. A listing summary is absent.
The fresh selected record independently parses this ordering, requires the
actual candidate's identity/sites/gain/complete trial to equal the proved
listing's candidate0, and retains all earlier trial rows and pair diagnostics.
It requires all ten earlier complete models and71 placement metrics exact,
records all8221 original FF BELs and the fixed terminal BEL, and requires a full
16384-cap/15290-path predicted report with the same seven pair/window path
counts. Report delays and Fmax may change; full-report equality is diagnostic.
Normal completion, no route/post/driver/signoff and pre/post full-byte closure
are mandatory. Failure and partial outputs remain explicitly incomplete.

Only the two original ordinary LUTs are declared movable; the selected native
image must undergo a separate comparator for their actual BEL/pin/cache/LAB
effects and all graph/raw-ID/alias/FF invariants. This recorder does not prove
native or physical equivalence, inherit listing Boolean/physical acceptance,
calibrate numerical STA, claim routed gain, decode a bitstream or test hardware.
The accepted fifth117.771759 MHz remains the independent routed gain reference.
