"""Root-only host validation and runtime binding of the ordinary LAB port query.

This authenticates query inputs/output and the same backend static library. It
does not prove a routed graph, configuration bits, timing or hardware behavior.
"""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
TOOLCHAIN = MODULE / "build/toolchain-ramtest-timing"
BINARY = HERE / "physical_port_query_v2"
SOURCE = HERE / "physical_port_query_v2.cc"
LIBRARY = TOOLCHAIN / "build/nextpnr/mistral/libmistral/libmistral.a"
EXPECTED = {
    BINARY: "e5faaca4f116085156ed6c1ac866239801e9fe85b47177e0c26a83c1d51e77cf",
    SOURCE: "da48e2de2b0ab817bb03fe721f9c3246c4b7bd1adeaa4beec95a82fb01693360",
    LIBRARY: "3d98c6cc4577d619a706e74e3a2d74dcb0bd3c48fe459d2e5b718896c98225d6",
}
MODEL = "5CSEBA6U23I7"
OUTPUT = HERE / "port-query-validation.json"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    require(not OUTPUT.exists(), "query validation already exists")
    sys.path.insert(0, str(MODULE))
    from scripts.fes_build_common import AuthenticatedTool
    from scripts.functional_execution import FunctionalInvocation
    for path, digest in EXPECTED.items():
        require(sha(path) == digest, "query input changed: " + str(path))
    inputs = dict(EXPECTED)
    inputs[Path(__file__).resolve()] = sha(Path(__file__))
    for relative in ("scripts/functional_execution.py", "scripts/fes_build_common.py",
                     "scripts/compiler_read_audit.py"):
        path = MODULE / relative
        inputs[path] = sha(path)
    invocation = FunctionalInvocation({"physical-port-query": AuthenticatedTool(BINARY, EXPECTED[BINARY])}, 0)
    try:
        command = ["/usr/bin/c++", "-std=c++17", "-M",
                   "-I", str(TOOLCHAIN / "src/mistral/libmistral"),
                   "-I", str(TOOLCHAIN / "build/nextpnr/mistral/tools"), str(SOURCE)]
        dependency = subprocess.run(command, env=invocation.env, capture_output=True, text=True, check=True)
        require(not dependency.stderr, "query dependency discovery emitted diagnostics")
        body = dependency.stdout.replace("\\\n", " ")
        require(":" in body, "query dependency output has no target")
        headers = [Path(name).absolute() for name in shlex.split(body.split(":", 1)[1])]
        require(SOURCE in headers and headers, "query dependency closure omits its source")
        for path in headers:
            inputs[path] = sha(path)
        inputs[Path(command[0])] = sha(Path(command[0]))
        cases = [
            ("actual_removed_added_buf_ports", MODEL, "17 16 2 1\n17 16 3 1\n", 0),
            ("incomplete_final_tuple", MODEL, "17 16 2\n", 2),
            ("unsupported_half", MODEL, "17 16 2 2\n", 2),
            ("malformed_token", MODEL, "17 16 bad 1\n", 2),
            ("unknown_model", "not-a-cyclonev-model", "17 16 2 1\n", 2),
        ]
        results = []
        stdout_path = HERE / "diagnostic-port-v2-output.tsv"
        for label, model, text, expected in cases:
            argv = [str(BINARY), model]
            result = subprocess.run(argv, input=text, env=invocation.env,
                                    capture_output=True, text=True, timeout=60, check=False)
            require(result.returncode == expected, "query validation case failed: " + label)
            if expected == 0:
                require(not result.stderr and result.stdout.splitlines() == [
                    "17\t16\t2\t1\tLAB.017.016.2:D\tGOUT.017.016.0021\t0",
                    "17\t16\t3\t1\tLAB.017.016.3:D\tGOUT.017.016.0029\t0"],
                    "actual query physical port round trips changed")
                with stdout_path.open("x") as output:
                    output.write(result.stdout)
            else:
                require(not result.stdout and result.stderr, "query negative failed without explicit rejection")
            results.append({"case": label, "command": argv, "stdin": text,
                            "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
        invocation.verify()
        require(all(sha(path) == digest for path, digest in inputs.items()), "query dependency changed during checks")
        with OUTPUT.open("x") as output:
            json.dump({"schema": 1, "status": "five host-only query checks passed",
                       "diagnostic_only": True, "timing_acceptance_available": False,
                       "whole_graph_equivalence_proved": False, "hardware_acceptance": False,
                       "model": MODEL, "binary_sha256": EXPECTED[BINARY],
                       "source_sha256": EXPECTED[SOURCE], "backend_static_library_sha256": EXPECTED[LIBRARY],
                       "source_dependency_command": command, "source_dependency_stdout": dependency.stdout,
                       "input_sha256": {str(path): digest for path, digest in sorted(inputs.items())},
                       "execution": invocation.inputs, "cases": results,
                       "positive_stdout_path": str(stdout_path), "positive_stdout_sha256": sha(stdout_path),
                       "final_original_path_rehash_passed": True,
                       "limitations": ["Dependency discovery authenticates current headers/library; no reproducible query-binary rebuild is claimed.",
                                       "This proves two actual database port queries, not any routed connectivity or RBF bits."]},
                      output, indent=2, sort_keys=True)
            output.write("\n")
        print(json.dumps({"status": "passed", "cases": len(results), "output": str(OUTPUT)}, indent=2))
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
