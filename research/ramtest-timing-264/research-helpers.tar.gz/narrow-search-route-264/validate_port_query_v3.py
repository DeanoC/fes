"""Root-only validation of an explicit ordinary-LAB BUF.A query payload.

This version permits variable exact tuples within an authenticated scope.
It never runs a compiler/router or modifies any existing run/profile/proof.
The resulting supplemental capsule supplies host query evidence only.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
TOOLCHAIN = MODULE / "build/toolchain-ramtest-timing"
BINARY = HERE / "physical_port_query_v2"
SOURCE = HERE / "physical_port_query_v2.cc"
LIBRARY = TOOLCHAIN / "build/nextpnr/mistral/libmistral/libmistral.a"
TOOLCHAIN_REFERENCE = HERE / "port-query-validation.json"
TOOLCHAIN_REFERENCE_SHA = "6e49f085d244789713eb6ea75b3ca33b8024b7e0fa09feaa0ead3dcc1da0c857"
EXPECTED = {BINARY: "e5faaca4f116085156ed6c1ac866239801e9fe85b47177e0c26a83c1d51e77cf",
            SOURCE: "da48e2de2b0ab817bb03fe721f9c3246c4b7bd1adeaa4beec95a82fb01693360",
            LIBRARY: "3d98c6cc4577d619a706e74e3a2d74dcb0bd3c48fe459d2e5b718896c98225d6"}
MODEL = "5CSEBA6U23I7"
DIGEST = re.compile(r"[0-9a-f]{64}")
PNODE = re.compile(r"LAB\.([0-9]+)\.([0-9]+)\.([0-9]+):([CD])")
RNODE = re.compile(r"GOUT\.([0-9]+)\.([0-9]+)\.([0-9]+)")
BEL = re.compile(r"MISTRAL_FF\.([0-9]+)\.([0-9]+)\.([0-9]+)")


def require(condition, message):
    if not condition:
        raise ValueError("query-v3 validation: " + message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    def unique(items):
        values = {}
        for key, value in items:
            require(key not in values, "duplicate metadata key: " + key)
            values[key] = value
        return values
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite " + value)))


def tuple_rows(rows, nonempty=True):
    require(type(rows) is list and (rows or not nonempty), "missing tuple list")
    require(all(type(row) is list and len(row) == 4 and all(type(value) is int for value in row) and
                0 <= row[0] <= 127 and 0 <= row[1] <= 127 and 0 <= row[2] < 10 and row[3] in (0, 1)
                for row in rows), "tuple list contains unsupported ordinary LAB coordinates/half")
    values = [tuple(row) for row in rows]
    require(values == sorted(set(values)), "tuple list is not unique and canonically sorted")
    return values


def authenticate_scope(path):
    """Pure scope reader; returns every referenced original path identity."""
    path = Path(path).absolute()
    scope = read(path)
    require(type(scope) is dict and set(scope) == {"schema", "kind", "reference_kind", "reference", "eligible_halves"} and
            type(scope["schema"]) is int and scope["schema"] == 1 and scope["kind"] == "buffer A query scope",
            "scope is not exact schema1")
    row = scope["reference"]
    require(type(row) is dict and set(row) == {"path", "sha256"} and type(row["path"]) is str and
            Path(row["path"]).is_absolute() and type(row["sha256"]) is str and DIGEST.fullmatch(row["sha256"]) and
            sha(row["path"]) == row["sha256"], "scope reference identity changed")
    reference = read(row["path"])
    allowed = tuple_rows(scope["eligible_halves"])
    if scope["reference_kind"] == "full_profile":
        physical = reference["predeclared_physical_scope"]
        require(physical["scope_was_derived_before_full_route"] is True and
                physical["postroute_observed_deltas_do_not_expand_scope"] is True,
                "full scope was not declared before routing")
        alms = physical["allowed_alms"]
        require(type(alms) is list and all(type(alm) is list and len(alm) == 3 and
                all(type(value) is int for value in alm) for alm in alms) and
                len({tuple(alm) for alm in alms}) == len(alms), "full ALM closure is malformed")
        derived, ff_names = set(), set()
        for ff in physical["eligible_original_ffs"]:
            match = BEL.fullmatch(ff["bel"])
            require(match and type(ff["cell"]) is str and ff["cell"] not in ff_names,
                    "eligible original FF lacks a unique physical identity")
            ff_names.add(ff["cell"])
            x, y, z = map(int, match.groups())
            require(0 <= z < 60 and 2 <= z % 6 <= 5 and ff["alm"] == [x, y, z // 6] and
                    type(ff["ff_slot"]) is int and ff["ff_slot"] == z % 6 and ff["alm"] in alms and
                    all(type(ff[key]) is str and DIGEST.fullmatch(ff[key]) for key in
                        ("old_full_cell_sha256", "old_full_pinmap_sha256")), "eligible FF metadata/ALM half differs")
            derived.add((x, y, z // 6, (z % 6 - 2) // 2))
        require(allowed == sorted(derived) == tuple_rows(physical["eligible_buffer_halves"]),
                "query scope differs from the full profile's fixed-FF half closure")
    elif scope["reference_kind"] == "native_buffer_diagnostic":
        require(reference["diagnostic_only"] is True and reference["acceptance_proof_available"] is False and
                reference["practical_acceptance"] is False and reference["final_original_path_hash_audit_passed"] is True,
                "diagnostic scope is not a successful partial native exercise")
        ledger = reference["positive_native_buffer_ledger"]
        require(ledger["late_buffer_proof_available"] is True and ledger["hardware_acceptance"] is False,
                "diagnostic scope lacks its native buffer ledger")
        derived = sorted({(*entry["alm"], entry["half"]) for side in
                          (ledger["removed_buffers"], ledger["added_buffers"]) for entry in side})
        require(allowed == derived, "diagnostic tuple scope differs from its exact buffer ledger")
    else:
        raise ValueError("query-v3 validation: unsupported scope reference kind")
    return scope, {str(path): sha(path), row["path"]: row["sha256"]}


def input_rows(text):
    lines, rows = text.splitlines(), []
    require(lines, "empty query input")
    for line in lines:
        values = line.split()
        require(len(values) == 4 and all(re.fullmatch(r"[0-9]+", value) for value in values),
                "query stdin requires exactly four nonnegative fields per line")
        rows.append(list(map(int, values)))
    result = tuple_rows(rows)
    require(text == "".join(" ".join(map(str, row)) + "\n" for row in result),
            "query stdin is not the canonical sorted tuple serialization")
    return result


def output_rows(text, inputs):
    lines, result = text.splitlines(), {}
    require(len(lines) == len(inputs), "query TSV row count differs from exact input")
    for key, line in zip(inputs, lines):
        values = line.split("\t")
        require(len(values) == 7 and all(re.fullmatch(r"[0-9]+", value) for value in values[:4]) and
                tuple(map(int, values[:4])) == key and values[6] == "0", "TSV tuple or fixed inversion differs")
        physical, routing = PNODE.fullmatch(values[4]), RNODE.fullmatch(values[5])
        require(physical and routing and tuple(map(int, physical.groups()[:3])) == key[:3] and
                physical[4] == ("D" if key[3] else "C") and tuple(map(int, routing.groups()[:2])) == key[:2],
                "TSV is not the exact ordinary LAB C/D physical-node round trip")
        result[key] = {"tuple": list(key), "physical_port": values[4], "queried_rnode": values[5],
                       "actual_arch_wire": "GOUT." + ".".join(str(int(value)) for value in routing.groups()),
                       "rnode_inversion_enum": 0, "port_rnode_round_trip_from_pinned_query": True}
    return result


class Audit:
    def __init__(self):
        self.paths = {}

    def bind(self, path, expected=None):
        path = Path(path).absolute()
        digest = sha(path)
        require(expected is None or digest == expected, "input changed: " + str(path))
        require(path not in self.paths or self.paths[path] == digest, "conflicting original input paths")
        self.paths[path] = digest
        return digest

    def finish(self):
        require(all(sha(path) == digest for path, digest in self.paths.items()),
                "original dependency/runtime/query path changed during validation")


def identity(path):
    path = Path(path).absolute()
    return {"path": str(path), "sha256": sha(path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--scope", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    input_path, scope_path, folder = args.input.absolute(), args.scope.absolute(), args.output_dir.absolute()
    require(folder.resolve().is_relative_to(HERE) and not folder.exists(),
            "output must be a new directory within the private proof folder")
    audit = Audit()
    audit.bind(Path(__file__))
    audit.bind(input_path)
    audit.bind(scope_path)
    scope, reference_files = authenticate_scope(scope_path)
    for path, digest in reference_files.items():
        audit.bind(path, digest)
    text = input_path.read_text()
    tuples = input_rows(text)
    require(set(tuples) <= set(tuple_rows(scope["eligible_halves"])), "input expands the authenticated half scope")
    audit.bind(TOOLCHAIN_REFERENCE, TOOLCHAIN_REFERENCE_SHA)
    baseline = read(TOOLCHAIN_REFERENCE)
    require(baseline["status"] == "five host-only query checks passed" and
            baseline["binary_sha256"] == EXPECTED[BINARY] and baseline["source_sha256"] == EXPECTED[SOURCE] and
            baseline["backend_static_library_sha256"] == EXPECTED[LIBRARY] and
            baseline["final_original_path_rehash_passed"] is True, "toolchain reference identity differs")
    for path, digest in EXPECTED.items():
        audit.bind(path, digest)
    sys.path.insert(0, str(MODULE))
    for relative in ("scripts/functional_execution.py", "scripts/fes_build_common.py", "scripts/compiler_read_audit.py"):
        path = MODULE / relative
        audit.bind(path, baseline["input_sha256"][str(path)])
    from scripts.fes_build_common import AuthenticatedTool
    from scripts.functional_execution import FunctionalInvocation
    invocation = FunctionalInvocation({"physical-port-query": AuthenticatedTool(BINARY, EXPECTED[BINARY])}, 0)
    try:
        dependency_command = ["/usr/bin/c++", "-std=c++17", "-M", "-I", str(TOOLCHAIN / "src/mistral/libmistral"),
                              "-I", str(TOOLCHAIN / "build/nextpnr/mistral/tools"), str(SOURCE)]
        audit.bind(dependency_command[0], baseline["input_sha256"][dependency_command[0]])
        dependency = subprocess.run(dependency_command, env=invocation.env, capture_output=True, text=True, check=True)
        require(not dependency.stderr, "dependency discovery emitted diagnostics")
        body = dependency.stdout.replace("\\\n", " ")
        require(":" in body, "dependency discovery has no target")
        headers = [Path(name).absolute() for name in shlex.split(body.split(":", 1)[1])]
        require(SOURCE in headers and headers, "dependency closure omits query source")
        for path in headers:
            require(str(path) in baseline["input_sha256"], "query gained an unauthenticated source/header dependency")
            audit.bind(path, baseline["input_sha256"][str(path)])
        for path, digest in invocation.inputs["files"].items():
            audit.bind(path, digest)
        source_inputs = {str(path): digest for path, digest in audit.paths.items()
                         if str(path) not in invocation.inputs["files"]}
        # The binary belongs in both dependency and execution closures.
        source_inputs[str(BINARY)] = EXPECTED[BINARY]
        x, y, alm, half = tuples[0]
        cases = [("actual_requested_buf_ports", MODEL, text, 0),
                 ("incomplete_final_tuple", MODEL, f"{x} {y} {alm}\n", 2),
                 ("unsupported_half", MODEL, f"{x} {y} {alm} 2\n", 2),
                 ("malformed_token", MODEL, f"{x} {y} bad {half}\n", 2),
                 ("unknown_model", "not-a-cyclonev-model", f"{x} {y} {alm} {half}\n", 2)]
        results = []
        for label, model, stdin, expected in cases:
            command = [str(BINARY), model]
            result = subprocess.run(command, input=stdin, env=invocation.env,
                                    capture_output=True, text=True, timeout=60, check=False)
            require(result.returncode == expected, "host query case failed: " + label)
            if expected == 0:
                require(not result.stderr, "positive query emitted diagnostics")
                output_rows(result.stdout, tuples)
            else:
                require(not result.stdout and result.stderr, "negative query lacked explicit rejection")
            results.append({"case": label, "command": command, "stdin": stdin, "exit_code": result.returncode,
                            "stdout": result.stdout, "stderr": result.stderr})
        invocation.verify()
        audit.finish()
        folder.mkdir()
        stdout_path, validation_path, binding_path = folder / "query-output.tsv", folder / "validation.json", folder / "query-binding.json"
        with stdout_path.open("x") as output:
            output.write(results[0]["stdout"])
        validation = {"schema": 2, "kind": "exact scoped BUF.A host query validation",
            "status": "five scoped host-only query checks passed", "producer_sha256": sha(Path(__file__)),
            "diagnostic_only": True, "timing_acceptance_available": False, "whole_graph_equivalence_proved": False,
            "hardware_acceptance": False, "model": MODEL, "binary_sha256": EXPECTED[BINARY],
            "source_sha256": EXPECTED[SOURCE], "backend_static_library_sha256": EXPECTED[LIBRARY],
            "toolchain_reference_sha256": TOOLCHAIN_REFERENCE_SHA, "scope": identity(scope_path),
            "reference_kind": scope["reference_kind"], "scope_reference": scope["reference"],
            "eligible_halves": scope["eligible_halves"], "queried_halves": [list(row) for row in tuples],
            "stdin": identity(input_path), "source_dependency_command": dependency_command,
            "source_dependency_stdout": dependency.stdout, "input_sha256": source_inputs,
            "execution": invocation.inputs, "cases": results, "positive_stdout_path": str(stdout_path),
            "positive_stdout_sha256": sha(stdout_path), "final_original_path_rehash_passed": True,
            "limitations": ["Only this exact input payload was executed; another payload needs its own completed capsule.",
                            "The pinned query performs physical/routing-node round trips; no design, pip, RBF or timing acceptance is proved.",
                            "Native-buffer-diagnostic scope is for host exercises only; full callers require their own presealed full profile reference."]}
        with validation_path.open("x") as output:
            output.write(json.dumps(validation, indent=2, sort_keys=True, allow_nan=False) + "\n")
        binding = {"schema": 2, "model": MODEL, "command": results[0]["command"], "completed": True, "exit_code": 0,
            "source": identity(SOURCE), "binary": identity(BINARY), "backend_library": identity(LIBRARY),
            "stdin": identity(input_path), "stdout": identity(stdout_path), "validation": identity(validation_path),
            "scope": identity(scope_path), "dependency_sha256": source_inputs,
            "runtime_file_sha256": invocation.inputs["files"], "execution": invocation.inputs}
        invocation.verify()
        audit.finish()
        with binding_path.open("x") as output:
            output.write(json.dumps(binding, indent=2, sort_keys=True, allow_nan=False) + "\n")
        print(json.dumps({"validation": identity(validation_path), "query_binding": identity(binding_path),
                          "queried_halves": binding["stdin"], "tuple_count": len(tuples)}, indent=2))
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
