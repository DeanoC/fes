"""Partial proof of actual routing to a declared late buffer's physical A pin.

Consume original routed modules, an independently proved native buffer ledger,
and the root's completed query binding. No subprocess, graph normalization,
old proof invocation, output mutation, timing or RBF decoding occurs here.
The present query-validation pin supports only its authenticated queried rows;
a different query payload needs a separately tested and pinned validation.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
BUFFER_MODULE = HERE / "prove_route_buffers_v2.py"
BUFFER_MODULE_SHA = "220e0dc45b9948d746dc9372b6951bfe1566419ddc76a9ae4c2eda3b6ecef06c"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
QUERY_SOURCE_SHA = "da48e2de2b0ab817bb03fe721f9c3246c4b7bd1adeaa4beec95a82fb01693360"
QUERY_BINARY_SHA = "e5faaca4f116085156ed6c1ac866239801e9fe85b47177e0c26a83c1d51e77cf"
BACKEND_LIBRARY_SHA = "3d98c6cc4577d619a706e74e3a2d74dcb0bd3c48fe459d2e5b718896c98225d6"
VALIDATION_SHA = "6e49f085d244789713eb6ea75b3ca33b8024b7e0fa09feaa0ead3dcc1da0c857"
VALIDATOR_SHA = "af662b0b1f00691fb7beac8ed3d00a127ddc621dfbc1f56cae461b1ae4a343f7"
DIGEST = re.compile(r"[0-9a-f]{64}")
PNODE = re.compile(r"LAB\.([0-9]+)\.([0-9]+)\.([0-9]+):([CD])")
RNODE = re.compile(r"GOUT\.([0-9]+)\.([0-9]+)\.([0-9]+)")


def require(condition, message):
    if not condition:
        raise ValueError("buffer-A route proof: " + message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate query metadata key: " + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite " + value)))


class Audit:
    """Bind original absolute paths on entry, reopen those paths on exit."""
    def __init__(self):
        self.paths, self.targets = {}, {}

    def bind(self, path, digest):
        require(type(path) is str or isinstance(path, Path), "input path has an unsupported type")
        path = Path(path)
        require(path.is_absolute() and type(digest) is str and DIGEST.fullmatch(digest),
                "input lacks an absolute path and concrete SHA256")
        target = path.resolve()
        if target not in self.targets:
            self.targets[target] = sha(path)
        require(self.targets[target] == digest and (path not in self.paths or self.paths[path] == digest),
                "input changed or has conflicting identities: " + str(path))
        self.paths[path] = digest
        return path

    def identity(self, row, expected=None):
        require(type(row) is dict and set(row) == {"path", "sha256"}, "malformed query file identity")
        require(expected is None or row["sha256"] == expected, "query file identity has a different pinned digest")
        return self.bind(row["path"], row["sha256"])

    def closure(self, values):
        require(type(values) is dict and values, "missing query dependency/runtime closure")
        for path, digest in values.items():
            self.bind(path, digest)

    def finish(self):
        require(all(sha(path) == digest for path, digest in self.paths.items()),
                "an original dependency/runtime/query path changed during proof")


def query_rows(binding, audit):
    fields = {"schema", "model", "command", "completed", "exit_code", "source", "binary",
              "backend_library", "stdin", "stdout", "dependency_sha256", "runtime_file_sha256",
              "validation", "execution"}
    require(type(binding) is dict and set(binding) == fields and type(binding["schema"]) is int and
            binding["schema"] == 1 and binding["completed"] is True and
            type(binding["exit_code"]) is int and binding["exit_code"] == 0,
            "query binding is not an exact completed schema1 record")
    source = audit.identity(binding["source"], QUERY_SOURCE_SHA)
    binary = audit.identity(binding["binary"], QUERY_BINARY_SHA)
    library = audit.identity(binding["backend_library"], BACKEND_LIBRARY_SHA)
    stdin, stdout = audit.identity(binding["stdin"]), audit.identity(binding["stdout"])
    validation_path = audit.identity(binding["validation"], VALIDATION_SHA)
    audit.closure(binding["dependency_sha256"])
    audit.closure(binding["runtime_file_sha256"])
    validation = read(validation_path)
    execution = binding["execution"]
    require(type(binding["model"]) is str and binding["model"] and
            binding["command"] == [str(binary), binding["model"]] and
            validation["schema"] == 1 and validation["status"] == "five host-only query checks passed" and
            validation["diagnostic_only"] is True and validation["timing_acceptance_available"] is False and
            validation["whole_graph_equivalence_proved"] is False and validation["hardware_acceptance"] is False and
            validation["final_original_path_rehash_passed"] is True and
            validation["model"] == binding["model"] and validation["binary_sha256"] == QUERY_BINARY_SHA and
            validation["source_sha256"] == QUERY_SOURCE_SHA and
            validation["backend_static_library_sha256"] == BACKEND_LIBRARY_SHA and
            binding["dependency_sha256"] == validation["input_sha256"] and
            execution == validation["execution"] and type(execution) is dict and
            binding["runtime_file_sha256"] == execution["files"] and
            execution["files"].get(str(binary)) == QUERY_BINARY_SHA,
            "query/model/library/dependency/runtime aliases differ from the pinned validation")
    require(binding["dependency_sha256"].get(str(source)) == QUERY_SOURCE_SHA and
            binding["dependency_sha256"].get(str(binary)) == QUERY_BINARY_SHA and
            binding["dependency_sha256"].get(str(library)) == BACKEND_LIBRARY_SHA and
            binding["dependency_sha256"].get(str(HERE / "validate_port_query.py")) == VALIDATOR_SHA,
            "query dependency closure omits an exact producer identity")
    cases = validation["cases"]
    labels = ["actual_removed_added_buf_ports", "incomplete_final_tuple", "unsupported_half",
              "malformed_token", "unknown_model"]
    require(type(cases) is list and len(cases) == len(labels) and
            [row["case"] for row in cases] == labels and
            [row["exit_code"] for row in cases] == [0, 2, 2, 2, 2] and
            cases[0]["command"] == binding["command"] and cases[0]["stderr"] == "" and
            all(row["stdout"] == "" and row["stderr"] for row in cases[1:]),
            "pinned host validation has incomplete positive/negative cases")
    input_text, output_text = stdin.read_text(), stdout.read_text()
    require(input_text == cases[0]["stdin"] and output_text == cases[0]["stdout"] and
            validation["positive_stdout_path"] == str(stdout) and
            validation["positive_stdout_sha256"] == binding["stdout"]["sha256"],
            "actual queried payload differs from the authenticated positive case")
    inputs, rows = [], {}
    for line in input_text.splitlines():
        values = line.split()
        require(len(values) == 4 and all(re.fullmatch(r"[0-9]+", value) for value in values),
                "query stdin is not four nonnegative tuple fields per line")
        key = tuple(map(int, values))
        require(0 <= key[0] <= 127 and 0 <= key[1] <= 127 and 0 <= key[2] < 10 and key[3] in (0, 1) and
                key not in inputs, "duplicate or unsupported queried ALM/half")
        inputs.append(key)
    lines = output_text.splitlines()
    require(inputs and len(inputs) == len(lines), "query tuple/TSV row counts differ")
    for key, line in zip(inputs, lines):
        values = line.split("\t")
        require(len(values) == 7 and all(re.fullmatch(r"[0-9]+", value) for value in values[:4]) and
                tuple(map(int, values[:4])) == key and values[6] == "0", "query row identity or fixed inversion differs")
        physical, routing = PNODE.fullmatch(values[4]), RNODE.fullmatch(values[5])
        require(physical and routing and tuple(map(int, physical.groups()[:3])) == key[:3] and
                physical[4] == ("D" if key[3] else "C") and
                tuple(map(int, routing.groups()[:2])) == key[:2],
                "query TSV does not map the exact ordinary LAB half-specific C/D pin")
        # libmistral formats coordinates with padding; Arch::getWireName uses
        # decimal IdStrings for x/y/z. Preserve the queried type and values.
        wire = "GOUT." + ".".join(str(int(value)) for value in routing.groups())
        rows[key] = {"tuple": list(key), "physical_port": values[4],
                     "queried_rnode": values[5], "actual_arch_wire": wire,
                     "rnode_inversion_enum": 0, "port_rnode_round_trip_from_pinned_query": True}
    return rows


def frozen_buffers(audit):
    audit.bind(BUFFER_MODULE, BUFFER_MODULE_SHA)
    spec = importlib.util.spec_from_file_location("proved_buffer_A_native_utilities_v2", BUFFER_MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prove_buffer_a_routes(g8, before_top, after_top, buffer_ledger, query_binding):
    """Prove queried BUF.A ingress-to-native-source paths on actual graphs.

    The caller must authenticate the actual routed documents, g8 utility
    closure, buffer-ledger output and query-binding record in its own sealed
    artifact map. This API checks the concrete query/dependency/runtime bytes
    and all related actual native edges/pins/routes again, without mutation.
    It supplies neither the selected LUT function proof nor full acceptance.
    """
    audit = Audit()
    require(hasattr(g8, "__file__"), "missing pinned lossless netlist utilities")
    audit.bind(Path(g8.__file__).absolute(), G8_HELPER_SHA)
    rows = query_rows(query_binding, audit)
    buffers = frozen_buffers(audit)
    old, new = buffers.Native(before_top), buffers.Native(after_top)
    require(type(buffer_ledger) is dict and buffer_ledger["late_buffer_proof_available"] is True and
            buffer_ledger["native_tables_built_before_any_buffer_collapse"] is True and
            buffer_ledger["hardware_acceptance"] is False, "missing independently proved native buffer ledger")
    allowed_rows = buffer_ledger["allowed_alms"]
    require(type(allowed_rows) is list and all(type(row) is list and len(row) == 3 and
            all(type(value) is int and value >= 0 for value in row) and row[2] < 10 for row in allowed_rows),
            "invalid ledger affected-ALM closure")
    allowed = {tuple(row) for row in allowed_rows}
    require(len(allowed) == len(allowed_rows), "duplicate affected ALM in native ledger")
    delta_lists = [buffer_ledger["removed_buffers"], buffer_ledger["added_buffers"]]
    require(all(type(side) is list for side in delta_lists), "malformed buffer addition/removal ledger")
    delta_sets = [{row["cell"] for row in side} for side in delta_lists]
    require(all(len(names) == len(side) for names, side in zip(delta_sets, delta_lists)), "duplicate buffer ledger row")
    actual_sets = [{name for name, cell in native.cells.items() if cell["type"] == "MISTRAL_BUF"}
                   for native in (old, new)]
    require(delta_sets == [actual_sets[0] - actual_sets[1], actual_sets[1] - actual_sets[0]],
            "buffer ledger addition/removal set differs from the actual native graphs")
    traces, used = [], set()
    for native, side, operation in zip((old, new), delta_lists, ("remove", "add")):
        device, lab_rows = buffers._lab_rows(native.top)
        require(device == query_binding["model"], "query model differs from the actual LAB device snapshot")
        occupants = buffers._occupants(native, allowed)
        for row in side:
            name = row["cell"]
            # Re-evaluate each relevant native edge, actual BUF/pair pins, L5
            # half image/private Q/local FF route; never rely on a collapsed Q.
            actual = buffers._buffer(g8, native, name, allowed, lab_rows, occupants)
            require(actual == row, "buffer ledger no longer matches its actual native/pin/mask/private-route proof")
            key = (*actual["alm"], actual["half"])
            require(key in rows, "actual BUF.A half lacks its exact authenticated physical-port query")
            used.add(key)
            source = tuple(actual["native_source"])
            cell = native.cells[name]
            source_bit = cell["connections"]["A"][0]
            require(native.token(source_bit) == source and
                    native.connections[name]["A"] == [source] and
                    actual["actual_pins"]["A"] == [0, "D" if key[3] else "C"],
                    "actual buffer A native source/pin differs from the ledger")
            nodes = buffers._routing(native, source_bit)
            physical = rows[key]["actual_arch_wire"]
            require(physical in nodes, "native source ROUTING does not reach the queried physical BUF.A node")
            path, current, seen = [], physical, set()
            while current is not None:
                require(current not in seen and current in nodes, "cycle or missing parent in BUF.A native route")
                seen.add(current)
                path.append(current)
                current = nodes[current]
            output = buffers._driver_wire(g8, native, source)
            require(path[-1] == output, "queried BUF.A route ancestry ends at a different native source output")
            edges = [{"from": parent, "to": child, "exported_pip": parent + "." + child}
                     for child, parent in zip(path, path[1:])]
            traces.append({"operation": operation, "buffer": name, "ff": actual["ff"],
                           "alm": actual["alm"], "half": actual["half"],
                           "actual_A_pins": actual["actual_pins"]["A"], "native_source": list(source),
                           "source_net_raw_bit": source_bit,
                           "source_net_named_aliases": [list(alias) for alias in native.aliases.get(source_bit, [])],
                           "physical_query": rows[key], "actual_native_output_wire": output,
                           "root_to_buffer_A_wires": list(reversed(path)),
                           "root_to_buffer_A_exported_pips": list(reversed(edges)),
                           "source_route_node_count": len(nodes),
                           "complete_exported_source_route_is_one_acyclic_rooted_tree": True,
                           "actual_native_source_identity_and_physical_A_ancestry_match": True})
    require(used == set(rows), "query payload has an unaccounted physical-port row")
    audit.finish()
    return {"buffer_A_native_route_proof_available": True, "native_graphs_normalized_or_mutated": False,
            "buffer_A_routes": traces, "queried_distinct_alm_halves": len(used),
            "query_source_sha256": QUERY_SOURCE_SHA, "query_binary_sha256": QUERY_BINARY_SHA,
            "same_backend_library_sha256": BACKEND_LIBRARY_SHA, "query_validation_sha256": VALIDATION_SHA,
            "buffer_module_sha256": BUFFER_MODULE_SHA,
            "entry_and_final_original_dependency_runtime_query_paths_rehashed": True,
            "query_executed_by_this_module": False, "old_proof_functions_called": False,
            "whole_graph_equivalence_proved": False, "timing_acceptance_available": False,
            "RBF_configuration_bits_decoded": False, "hardware_acceptance": False,
            "caller_still_must_close": ["Actual routed document, g8 utility, native ledger and query-binding artifact identities.",
                                       "Selected11/12/AC and retained-stack function/physical/native-user/alias proofs.",
                                       "All outside cells/pins, whole-ALM/control preservation and FF.DATAIN mux/private-Q proof.",
                                       "Backend whole-route legality/connectivity and genuine chipdb validity of every exported pip.",
                                       "All clock/PLL/constraint/window/hold/final timing and practical acceptance gates."],
            "limitations": ["The exact BUF.A pnode-to-rnode comes from the pinned same-backend query; route ancestry comes from original native ROUTING metadata.",
                            "This validates source-to-buffer-A ancestry and pin identity, not independent CRAM or RBF configuration.",
                            "The root's pinned query validation supports only its authenticated queried payload; no implicit new query occurs.",
                            "Numeric net reuse supplies no source renaming or equivalence authorization."],
            "authenticated_file_sha256": {str(path): digest for path, digest in sorted(audit.paths.items())}}
