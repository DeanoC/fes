"""Root-only V3 scoped BUF.A route exercise on two authenticated actual graphs.

This does not run a query, an old comparison, a compiler or a router. The
negative cases mutate copies or a temporary copied query payload only. The
historical rejected route remains rejected regardless of this diagnostic.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tempfile
import types


HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
OUTPUT = HERE / "diagnostic-buffer-a-routes-v3.json"
MODULE = HERE / "prove_buffer_a_routes_v3.py"
MODULE_SHA = "0434ef77bf1b203cf6650de90f16e94c43a2807e7c5a79caad419479a17b574a"
VALIDATOR = HERE / "validate_port_query_v3.py"
VALIDATOR_SHA = "52d06cc9c70fe5c809ccc2920f8298d466a541fd1b763d5e1ab79015570a655e"
BUFFERS = HERE / "prove_route_buffers_v2.py"
BUFFERS_SHA = "220e0dc45b9948d746dc9372b6951bfe1566419ddc76a9ae4c2eda3b6ecef06c"
LEDGER = HERE / "diagnostic-buffer-v2-checked.json"
LEDGER_SHA = "e29d44004852ded5d13dfd75394f1c8ccdf2c0fd2863c98332bf66543aad2463"
BINDING = HERE / "port-query-v3-diagnostic/query-binding.json"
BINDING_SHA = "6afeb1950b04b8000f4a8062e505e976945cc5406aecc6e96016a51e5ede36de"
VALIDATION_SHA = "179852055bda21a59074a82af1bdc00cb85c0d46193da3ef21a2ec5dcf9eef53"
SCOPE = HERE / "query-v3-host-scope.json"
SCOPE_SHA = "b37749359105abe1d898bcdc599cc828aebb85d4180a276ef0819c9c9b0873ec"
G8 = RAW / "ready-g8-decomposition-264"
G8_HELPER = G8 / "compare_control_decomposition.py"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
G8_PROOF = G8 / "route-c0/comparison.json"
G8_PROOF_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
BEFORE = G8 / "route-c0/routed.json"
BEFORE_SHA = "afb35eb2c43388d34c24a189b99ed283742cdb3d3375145b4d6dc66bcf2ae8bf"
AFTER = RAW / "placed12-minimum-264/route-reduction0-ac0/routed.json"
AFTER_SHA = "37ddb764483b666b7d5af8d8578974560983631f9eb98adec48eedbccf059cb4"
DIGEST = re.compile(r"[0-9a-f]{64}")


def require(condition, message):
    if not condition:
        raise ValueError("buffer-A diagnostic: " + message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "duplicate diagnostic metadata key: " + key)
        value[key] = item
    return value


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite " + value)))


def relative(path):
    path = Path(path).absolute()
    require(path.is_relative_to(ROOT), "artifact is outside the designated checkout")
    return str(path.relative_to(ROOT))


class Audit:
    """Memoize entry bytes while retaining every original path for final reads."""
    def __init__(self):
        self.paths, self.targets = {}, {}

    def bind(self, path, expected=None):
        path = Path(path).absolute()
        require(expected is None or type(expected) is str and DIGEST.fullmatch(expected),
                "input has no concrete expected SHA256")
        target = path.resolve()
        if target not in self.targets:
            self.targets[target] = sha(path)
        digest = self.targets[target]
        require(expected is None or digest == expected, "input changed: " + str(path))
        require(path not in self.paths or self.paths[path] == digest, "conflicting original path identities")
        self.paths[path] = digest
        return digest

    def closure(self, entries, checkout_relative=False):
        require(type(entries) is dict and entries, "missing sealed input closure")
        for path, digest in entries.items():
            require(type(path) is str and (not checkout_relative or not Path(path).is_absolute()),
                    "closure path has an unsupported form")
            original = ROOT / path if checkout_relative else Path(path)
            require(original.is_absolute() and (not checkout_relative or original.resolve().is_relative_to(ROOT)),
                    "closure path escapes its declared scope")
            self.bind(original, digest)

    def finish(self):
        require(all(sha(path) == digest for path, digest in self.paths.items()),
                "an original artifact/dependency/runtime path changed during the diagnostic")


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def imported_helpers(g8, expected, audit):
    seen, pending, actual = set(), [g8], {}
    while pending:
        module = pending.pop()
        if id(module) in seen:
            continue
        seen.add(id(module))
        path = getattr(module, "__file__", None)
        if not path or not Path(path).resolve().is_relative_to(RAW):
            continue
        key = relative(path)
        require(key in expected, "actual imported utility lacks a sealed identity: " + key)
        audit.bind(path, expected[key])
        actual[key] = expected[key]
        pending.extend(value for value in vars(module).values() if isinstance(value, types.ModuleType))
    require(actual == expected, "actual utility import closure differs from the native-ledger diagnostic")
    return actual


def top(g8, path):
    document = g8.read_netlist(path)
    require(set(document["modules"]) == {"top"}, "actual routed module set differs")
    return document["modules"]["top"]


def copied_route(top_value, native, bit, transform):
    """Modify every ROUTING-bearing alias consistently, preserving other data."""
    names = list(dict.fromkeys(name for name, _ in native.aliases.get(bit, [])
                              if "ROUTING" in top_value["netnames"][name].get("attributes", {})))
    require(names, "negative route fixture has no original ROUTING aliases")
    originals = {top_value["netnames"][name]["attributes"]["ROUTING"] for name in names}
    require(len(originals) == 1, "negative fixture source route aliases disagree")
    fields = next(iter(originals)).split(";")
    require(len(fields) % 3 == 0, "negative fixture route is malformed")
    triples = [fields[index:index + 3] for index in range(0, len(fields), 3)]
    changed_triples = transform(triples)
    route = ";".join(value for row in changed_triples for value in row)
    require(route != next(iter(originals)), "negative fixture did not change its route")
    result = copy.copy(top_value)
    result["cells"] = copy.copy(top_value["cells"])
    result["netnames"] = dict(top_value["netnames"])
    require(getattr(result["cells"], "pll_ports", {}) == getattr(top_value["cells"], "pll_ports", {}),
            "copied graph lost lossless PLL occurrences")
    for name in names:
        result["netnames"][name] = copy.deepcopy(top_value["netnames"][name])
        result["netnames"][name]["attributes"]["ROUTING"] = route
    return result, names


def negative_probes(g8, buffers, module, before, after, ledger, binding, eligible_halves, positive):
    native = buffers.Native(after)
    traces = [row for row in positive["buffer_A_routes"] if row["operation"] == "add"]
    require(len(traces) == 1, "expected one added actual BUF for copied route probes")
    trace = traces[0]
    bit = trace["source_net_raw_bit"]
    physical = trace["physical_query"]["actual_arch_wire"]
    nodes = buffers._routing(native, bit)
    require(physical in nodes and nodes[physical] is not None, "actual BUF.A node is missing or is its source root")
    results = []

    def reject(case, changed, query, mutation, message):
        try:
            module.prove_buffer_a_routes(g8, before, changed, ledger, query,
                                         binding["validation"]["sha256"], eligible_halves)
        except ValueError as error:
            reason = str(error)
            require(message in reason, "negative case reached the wrong gate: " + case + ": " + reason)
            results.append({"case": case, "copied_fixture_mutation": mutation, "rejected": True,
                            "exception_type": "ValueError", "reason": reason})
        else:
            raise ValueError("buffer-A diagnostic: copied invalid fixture accepted: " + case)

    parent = nodes[physical]
    def omit_a(triples):
        changed = []
        for wire, pip, strength in triples:
            if wire == physical:
                continue
            predecessor = pip[:-(len(wire) + 1)] if pip else None
            if predecessor == physical:
                pip = parent + "." + wire
            changed.append([wire, pip, strength])
        return changed
    changed, aliases = copied_route(after, native, bit, omit_a)
    require(physical not in buffers._routing(buffers.Native(changed), bit),
            "missing-A copied fixture is not a complete rooted tree without the A node")
    reject("missing_actual_physical_A_node", changed, binding,
           {"buffer": trace["buffer"], "removed_wire": physical, "updated_all_route_aliases": aliases},
           "native source ROUTING does not reach the queried physical BUF.A node")

    root = trace["actual_native_output_wire"]
    alternate = None
    for name in sorted(native.cells):
        cell = native.cells[name]
        if cell["type"] != "MISTRAL_FF" or len(cell["connections"].get("Q", [])) != 1:
            continue
        token = ("cell", name, "Q", 0)
        wire = buffers._driver_wire(g8, native, token)
        if wire not in nodes:
            alternate = (token, wire)
            break
    require(alternate is not None, "actual graph lacks another native FF output for a wrong-root fixture")
    def wrong_root(triples):
        changed = []
        for wire, pip, strength in triples:
            predecessor = pip[:-(len(wire) + 1)] if pip else None
            if wire == root:
                require(predecessor is None, "actual source output is not the original route root")
                wire = alternate[1]
            if predecessor == root:
                pip = alternate[1] + "." + wire
            changed.append([wire, pip, strength])
        return changed
    changed, aliases = copied_route(after, native, bit, wrong_root)
    changed_nodes = buffers._routing(buffers.Native(changed), bit)
    require(physical in changed_nodes and changed_nodes[alternate[1]] is None and root not in changed_nodes,
            "wrong-root copied fixture does not preserve a complete rooted tree and its A node")
    reject("wrong_actual_native_route_source_root", changed, binding,
           {"buffer": trace["buffer"], "original_native_source": trace["native_source"],
            "wrong_root_native_owner": list(alternate[0]), "original_root_wire": root,
            "wrong_root_wire": alternate[1], "updated_all_route_aliases": aliases},
           "queried BUF.A route ancestry ends at a different native source output")

    # The query module accepts only the exact payload of this pinned completed
    # validation. A copied row is rejected at the binding identity boundary;
    # this does not counterfeit another valid query execution or TSV mapping.
    original = Path(binding["stdin"]["path"]).read_text()
    lines = original.splitlines()
    values = lines[0].split()
    require(len(values) == 4, "copied query row fixture is malformed")
    values[2] = str((int(values[2]) + 1) % 10)
    lines[0] = " ".join(values)
    changed_text = "\n".join(lines) + "\n"
    with tempfile.TemporaryDirectory(prefix="buffer-A-copied-query-", dir=HERE) as folder:
        path = Path(folder) / "mismatched-row.txt"
        path.write_text(changed_text)
        query = copy.deepcopy(binding)
        query["stdin"] = {"path": str(path), "sha256": sha(path)}
        reject("copied_query_row_mismatch", after, query,
               {"original_authenticated_stdin_sha256": binding["stdin"]["sha256"],
                "copied_stdin": changed_text, "copied_stdin_sha256": query["stdin"]["sha256"],
                "rejection_scope": "exact stdin identity in the completed pinned scoped host validation"},
               "scoped query/model/library/producer/dependency/runtime aliases differ")
        require(path.read_text() == changed_text and sha(path) == query["stdin"]["sha256"],
                "copied query negative payload changed during its diagnostic")
    return results


def main():
    require(not OUTPUT.exists(), "diagnostic output already exists")
    audit = Audit()
    for path, expected in ((MODULE, MODULE_SHA), (VALIDATOR, VALIDATOR_SHA), (SCOPE, SCOPE_SHA),
                           (BUFFERS, BUFFERS_SHA), (LEDGER, LEDGER_SHA),
                           (BINDING, BINDING_SHA), (G8_HELPER, G8_HELPER_SHA),
                           (G8_PROOF, G8_PROOF_SHA), (BEFORE, BEFORE_SHA), (AFTER, AFTER_SHA)):
        audit.bind(path, expected)
    wrapper_sha = audit.bind(Path(__file__))
    diagnostic, binding, accepted = read(LEDGER), read(BINDING), read(G8_PROOF)
    scope = read(SCOPE)
    require(binding["validation"]["sha256"] == VALIDATION_SHA and
            binding["scope"] == {"path": str(SCOPE), "sha256": SCOPE_SHA} and
            scope["reference_kind"] == "native_buffer_diagnostic" and
            scope["reference"] == {"path": str(LEDGER), "sha256": LEDGER_SHA},
            "V3 exercise does not bind the root-completed diagnostic validation/scope")
    require(diagnostic["diagnostic_only"] is True and diagnostic["acceptance_proof_available"] is False and
            diagnostic["practical_acceptance"] is False and diagnostic["actual_graphs_normalized_or_mutated"] is False and
            diagnostic["final_original_path_hash_audit_passed"] is True and
            diagnostic["module_sha256"] == BUFFERS_SHA and diagnostic["rejected_route_sha256"] == AFTER_SHA and
            diagnostic["reference_full_proof_sha256"] == G8_PROOF_SHA and
            diagnostic["artifact_sha256"].get(relative(BEFORE)) == BEFORE_SHA and
            diagnostic["artifact_sha256"].get(relative(AFTER)) == AFTER_SHA and
            diagnostic["artifact_sha256"].get(relative(BUFFERS)) == BUFFERS_SHA and
            len(diagnostic["negative_probes"]) == 6 and all(row["rejected"] is True for row in diagnostic["negative_probes"]),
            "native-ledger diagnostic is not the pinned successful partial exercise")
    require(accepted["graph_proof_available"] is True and accepted["candidate_completed"] is True and
            accepted["artifact_sha256"].get(relative(BEFORE)) == BEFORE_SHA and
            accepted["artifact_sha256"].get(relative(G8_HELPER)) == G8_HELPER_SHA,
            "accepted reference does not bind its actual graph/parser")
    audit.closure(diagnostic["artifact_sha256"], checkout_relative=True)
    imports = diagnostic["imported_pinned_utilities"]
    require(all(diagnostic["artifact_sha256"].get(path) == digest for path, digest in imports.items()),
            "utility closure is absent from the native diagnostic artifact map")
    for field in ("source", "binary", "backend_library", "stdin", "stdout", "validation", "scope"):
        row = binding[field]
        require(type(row) is dict and set(row) == {"path", "sha256"}, "malformed actual query binding identity")
        audit.bind(row["path"], row["sha256"])
    audit.closure(binding["dependency_sha256"])
    audit.closure(binding["runtime_file_sha256"])
    g8 = module_at(G8_HELPER, "diagnostic_buffer_A_pinned_g8")
    actual_imports = imported_helpers(g8, imports, audit)
    buffers = module_at(BUFFERS, "diagnostic_buffer_A_native_v2")
    module = module_at(MODULE, "diagnostic_frozen_buffer_A_routes_v3")
    before, after = top(g8, BEFORE), top(g8, AFTER)
    ledger = diagnostic["positive_native_buffer_ledger"]
    require(len(ledger["removed_buffers"]) == len(ledger["added_buffers"]) == 1 and
            len(ledger["permitted_original_ff_datain_deltas"]) == 2,
            "actual native ledger does not exercise one removal, one addition and two FF DATAIN deltas")
    positive = module.prove_buffer_a_routes(g8, before, after, ledger, binding,
                                          binding["validation"]["sha256"], scope["eligible_halves"])
    traces = positive["buffer_A_routes"]
    require(positive["buffer_A_native_route_proof_available"] is True and
            positive["queried_distinct_alm_halves"] == len(traces) == 2 and
            sorted(row["operation"] for row in traces) == ["add", "remove"] and
            all(row["actual_native_source_identity_and_physical_A_ancestry_match"] is True and
                len(row["root_to_buffer_A_wires"]) > 1 and
                row["root_to_buffer_A_wires"][0] == row["actual_native_output_wire"] and
                row["root_to_buffer_A_wires"][-1] == row["physical_query"]["actual_arch_wire"] and
                len(row["root_to_buffer_A_exported_pips"]) + 1 == len(row["root_to_buffer_A_wires"])
                for row in traces), "actual positive exercise lacks the two full native-source-to-A ancestries")
    audit.closure(positive["authenticated_file_sha256"])
    negatives = negative_probes(g8, buffers, module, before, after, ledger, binding, scope["eligible_halves"], positive)
    require(len(negatives) == 3 and all(row["rejected"] is True for row in negatives),
            "copied negative exercise is incomplete")
    audit.finish()
    artifacts = {relative(path): digest for path, digest in sorted(audit.paths.items()) if path.is_relative_to(ROOT)}
    external = {str(path): digest for path, digest in sorted(audit.paths.items()) if not path.is_relative_to(ROOT)}
    result = {"schema": 1, "kind": "diagnostic exercise of the frozen V3 scoped actual BUF.A route proof",
              "status": "two actual native source-to-A paths and three copied negative probes passed; rejected route remains unaccepted",
              "diagnostic_only": True, "acceptance_proof_available": False, "practical_acceptance": False,
              "whole_graph_equivalence_proved": False, "timing_acceptance_available": False,
              "hardware_acceptance": False, "full_phase_activated": False,
              "wrapper_sha256": wrapper_sha, "module_sha256": MODULE_SHA, "buffer_module_sha256": BUFFERS_SHA,
              "native_ledger_diagnostic_sha256": LEDGER_SHA, "query_binding_sha256": BINDING_SHA,
              "query_validator_sha256": VALIDATOR_SHA, "query_validation_sha256": binding["validation"]["sha256"],
              "query_scope_sha256": SCOPE_SHA,
              "reference_full_proof_sha256": G8_PROOF_SHA, "actual_before_graph_sha256": BEFORE_SHA,
              "historical_rejected_graph_sha256": AFTER_SHA,
              "positive_actual_buffer_A_route_proof": positive, "negative_probes": negatives,
              "actual_graphs_normalized_or_mutated": False, "query_or_compiler_or_router_executed": False,
              "old_comparisons_reexecuted": False, "imported_pinned_utilities": actual_imports,
              "final_original_path_hash_audit_passed": True,
              "limitations": ["This supplies no fresh experiment qualification or full acceptance of the historical rejected route.",
                              "Only the two queried physical A-node ancestries and the bounded native-ledger slice are exercised.",
                              "Every exported pip's chipdb legality, selected LUT/retained-stack truth, all outside native/physical gates, PLL/clock windows/holds and final timing remain caller obligations.",
                              "The mismatched query row is rejected at the completed validation's exact stdin identity boundary; no alternate query was executed.",
                              "No RBF configuration bits, hardware behavior or in-memory owner/slot identities are proved."],
              "artifact_sha256": artifacts, "external_dependency_runtime_sha256": external}
    with OUTPUT.open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({"output": str(OUTPUT), "actual_A_paths": len(traces),
                      "negative_probes": len(negatives), "practical_acceptance": False}, indent=2))


if __name__ == "__main__":
    main()
