"""Root-only diagnostic exercise of the frozen native route-buffer v2 proof.

The actual accepted g8 and rejected 655 graphs are never normalized or edited.
Copied-graph negative probes exercise only this partial buffer proof. This is
not a full graph, timing, RBF, hardware or experiment acceptance validator.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import types


HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
G8 = RAW / "ready-g8-decomposition-264"
REJECTED = RAW / "placed12-minimum-264/route-reduction0-ac0"
LISTING = RAW / "placed12-minimum-264/list-ac-r0"
OUTPUT = HERE / "diagnostic-buffer-v2.json"
MODULE = HERE / "prove_route_buffers_v2.py"
MODULE_SHA = "220e0dc45b9948d746dc9372b6951bfe1566419ddc76a9ae4c2eda3b6ecef06c"
PLAN = HERE / "route-equivalence-plan.json"
PLAN_SHA = "164862996efc5550dd64d801444533846700f127d6b75ff060a19a8550c642bf"
G8_HELPER = G8 / "compare_control_decomposition.py"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
G8_PROOF = G8 / "route-c0/comparison.json"
G8_PROOF_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
BEFORE = G8 / "route-c0/routed.json"
BEFORE_SHA = "afb35eb2c43388d34c24a189b99ed283742cdb3d3375145b4d6dc66bcf2ae8bf"
AFTER = REJECTED / "routed.json"
AFTER_SHA = "37ddb764483b666b7d5af8d8578974560983631f9eb98adec48eedbccf059cb4"
REJECTED_RUN_SHA = "c9cae19b10b317279b3945c8f5b4eae94a1c4860b4fdee4f834a469affe1693b"
LISTING_PROOF_SHA = "af4ab4f5e229ce846587e2fd86e16ef42f7fc1f85517138d35c33d53457beab2"
BEL = re.compile(r"MISTRAL_(M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)")
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError("buffer-v2 diagnostic: " + message)


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate metadata key: " + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite " + value)))


def relative(path):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT), "diagnostic artifact is outside the checkout")
    return str(path.relative_to(ROOT))


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Audit:
    def __init__(self):
        self.paths, self.canonical = {}, {}

    def bind(self, path, expected=None):
        path = Path(path).absolute()
        target = path.resolve()
        relative(target)
        if target not in self.canonical:
            self.canonical[target] = sha(path)
        value = self.canonical[target]
        require(expected is None or value == expected, "artifact changed: " + str(path))
        require(path not in self.paths or self.paths[path] == value, "conflicting input path identity")
        self.paths[path] = value
        return value

    def finish(self):
        require(all(sha(path) == value for path, value in self.paths.items()),
                "an original input path changed during the diagnostic")


def imported_helpers(g8, proof, audit):
    """Close the actual imported evidence modules without invoking their proofs."""
    seen, pending, bound = set(), [g8], {}
    while pending:
        module = pending.pop()
        if id(module) in seen:
            continue
        seen.add(id(module))
        filename = getattr(module, "__file__", None)
        if not filename or not Path(filename).resolve().is_relative_to(RAW):
            continue
        path = Path(filename)
        digest = proof["artifact_sha256"].get(relative(path))
        require(type(digest) is str and re.fullmatch(r"[0-9a-f]{64}", digest),
                "imported helper lacks the pinned g8 artifact identity: " + str(path))
        audit.bind(path, digest)
        bound[relative(path)] = digest
        pending.extend(value for value in vars(module).values() if isinstance(value, types.ModuleType))
    return bound


def top(g8, path):
    document = g8.read_netlist(path)
    require(set(document["modules"]) == {"top"}, "unexpected routed module set")
    return document["modules"]["top"]


def placement(name, cell):
    bel = cell["attributes"].get("NEXTPNR_BEL", "")
    match = BEL.fullmatch(bel)
    require(match and match[1] != "FF", "selected LUT has no COMB BEL: " + name)
    x, y, z = map(int, match.groups()[1:])
    require(0 <= z < 60 and z % 6 < 2, "invalid selected LUT ALM position")
    return {"cell": name, "bel": bel, "alm": [x, y, z // 6]}


def affected_closure(before, after, accepted_proof, listing_proof):
    """Declare ALMs from selected LUT placements, never from BUF differences."""
    reduction = listing_proof["current_twelve_reduction"]
    names = reduction["reused_cells"]
    require(len(names) == len(set(names)) == 3 and reduction["root"] in names and
            reduction["selected_trial"]["candidate"] == 0 and reduction["assignments_checked"] == 4096,
            "pinned applied-twelve listing does not identify three reused cells")
    original = {row["cell"]: row for row in reduction["original_nodes"]}
    current = {row["cell"]: row for row in reduction["actual_nodes"]}
    require(set(original) == set(current) == set(names), "twelve placement evidence has a different cell set")
    evidence = []
    for name in sorted(names):
        old, new = placement(name, before["cells"][name]), placement(name, after["cells"][name])
        require(old["bel"] == original[name]["bel"] and new["bel"] == current[name]["bel"],
                "actual routed reduction placement differs from its pinned listing")
        evidence.append({"role": "selected twelve reused cell", "before": old, "after": new})
    ac = accepted_proof["decomposition_equivalence_on_ready_aligned_original_graph"]
    clone_rows = [ac["root"], *ac["encoders"]]
    require(len(clone_rows) == 3 and ac["assignments_checked"] == 128,
            "accepted graph does not identify the two-encoder AC clone")
    trial = listing_proof["decomposition_selection"]["geometry_probes"]["rows"][0]
    require(trial["definition"] == 0 and listing_proof["qualified_ac_ordinals"][0] == 0,
            "new listing lacks its observed candidate-zero AC geometry")
    actual_new_bels = []
    for row in clone_rows:
        name = row["cell"]
        old, new = placement(name, before["cells"][name]), placement(name, after["cells"][name])
        require(old["bel"] == row["bel"], "accepted AC placement differs from its proof")
        actual_new_bels.append(new["bel"])
        evidence.append({"role": "selected AC clone", "before": old, "after": new})
    require(actual_new_bels == [trial["root_bel"], *trial["encoder_bels"]],
            "rejected route AC clone placement differs from its own fresh listing")
    alms = sorted({tuple(row[side]["alm"]) for row in evidence for side in ("before", "after")})
    return alms, evidence


def observed_ena_declaration(buffers, before, after):
    """Declare at most one observed actual ENA edge; never infer its function."""
    old, new = buffers.Native(before), buffers.Native(after)
    ffs = [{name for name, cell in native.cells.items() if cell["type"] == "MISTRAL_FF"}
           for native in (old, new)]
    require(ffs[0] == ffs[1], "diagnostic original FF set differs")
    result = []
    for name in sorted(ffs[0]):
        a, b = old.connections[name], new.connections[name]
        require(set(a) == set(b), "diagnostic original FF port set differs")
        for port in a:
            if port == "DATAIN" or a[port] == b[port]:
                continue
            require(port == "ENA" and len(a[port]) == len(b[port]) == 1,
                    "actual non-DATAIN delta is outside the v2 scalar ENA exception")
            result.append({"ff": name, "port": "ENA", "index": 0,
                           "before_native_driver": list(a[port][0]), "after_native_driver": list(b[port][0])})
    require(len(result) <= 1, "more than one observed scalar ENA delta")
    return result


def graph_copy(top, cells=(), nets=()):
    """Copy containers and every modified object; retain lossless PLL records."""
    value = copy.copy(top)
    value["cells"] = copy.copy(top["cells"])
    value["netnames"] = dict(top["netnames"])
    require(getattr(value["cells"], "pll_ports", {}) == getattr(top["cells"], "pll_ports", {}),
            "copied graph lost lossless PLL occurrence records")
    for name in cells:
        value["cells"][name] = copy.deepcopy(top["cells"][name])
    for name in nets:
        value["netnames"][name] = copy.deepcopy(top["netnames"][name])
    return value


def negative_probes(g8, buffers, before, after, alms, declarations, positive):
    added = positive["added_buffers"][0]
    ff, buf, private = added["ff"], added["cell"], added["private_q_net"]
    q_bit = after["cells"][buf]["connections"]["Q"][0]
    others = sorted(name for name, cell in after["cells"].items()
                    if cell["type"] == "MISTRAL_FF" and name != ff and
                    cell["connections"].get("DATAIN") and cell["connections"].get("Q"))
    require(others, "actual graph lacks another original FF for bounded negative probes")
    alternate = next(name for name in others if ["cell", name, "Q", 0] != added["native_source"])
    results = []
    def reject(label, changed, allowed, mutation, messages):
        try:
            buffers.prove_buffers(g8, before, changed, allowed, declarations)
        except ValueError as error:
            text = str(error)
            require(any(message in text for message in messages),
                    "negative probe failed at an unintended gate: " + label + ": " + text)
            results.append({"case": label, "copied_graph_mutation": mutation,
                            "rejected": True, "exception_type": "ValueError", "reason": text})
        else:
            raise ValueError("buffer-v2 diagnostic: invalid copied graph accepted: " + label)
    reject("outside_declared_alm", graph_copy(after), [alm for alm in alms if list(alm) != added["alm"]],
           {"removed_allowed_alm": added["alm"]}, ["outside declared", "outside declared affected"])
    changed = graph_copy(after, cells=(others[0],))
    changed["cells"][others[0]]["connections"]["DATAIN"] = [q_bit]
    reject("private_q_extra_native_user", changed, alms,
           {"consumer": [others[0], "DATAIN", 0], "new_driver": added["native_q"]},
           ["BUF Q is not private to one FF DATAIN"])
    changed = graph_copy(after)
    extra_alias = buf + "$diagnostic_public_alias"
    require(extra_alias not in changed["netnames"], "negative alias name already exists")
    changed["netnames"][extra_alias] = {"hide_name": 0, "bits": [q_bit], "attributes": {}}
    reject("private_q_public_alias", changed, alms, {"added_alias": extra_alias},
           ["BUF Q has a public/extra alias or top port"])
    changed = graph_copy(after, cells=(ff,))
    pins = json.loads(bytes.fromhex(changed["cells"][ff]["attributes"]["FES_PINMAP_V1"]).decode())
    pins["pins"]["DATAIN"][0] = 3
    changed["cells"][ff]["attributes"]["FES_PINMAP_V1"] = json.dumps(pins, separators=(",", ":")).encode().hex()
    reject("original_ff_physical_pin_changed", changed, alms,
           {"ff": ff, "pin": "DATAIN", "new_state": 3},
           ["original FF physical/state metadata changed", "unsupported FF DATAIN physical state"])
    changed = graph_copy(after, cells=(buf,))
    changed["cells"][buf]["connections"]["A"] = list(after["cells"][alternate]["connections"]["Q"])
    reject("terminal_native_source_changed", changed, alms,
           {"buffer": buf, "old_source": added["native_source"], "new_source": ["cell", alternate, "Q", 0]},
           ["buffer substitution changed terminal native source", "shared ALM physical input has different native drivers"])
    changed = graph_copy(after, nets=(private,))
    original = buffers._routing(buffers.Native(after), q_bit)
    require(len(original) == 2, "positive private route is not the expected two-node route")
    wires = list(original)
    source_wire = buffers._driver_wire(g8, buffers.Native(after), tuple(added["native_source"]))
    require(source_wire not in original, "negative route needs a distinct actual terminal-source root wire")
    changed["netnames"][private]["attributes"]["ROUTING"] = ";".join([
        wires[0], wires[1] + "." + wires[0], "1",
        wires[1], wires[0] + "." + wires[1], "1", source_wire, "", "1"])
    reject("disconnected_route_cycle", changed, alms,
           {"private_q_net": private, "cyclic_native_wires": wires, "separate_root_wire": source_wire},
           ["cyclic native route branch"])
    return results


def main():
    require(not OUTPUT.exists(), "diagnostic output already exists")
    audit = Audit()
    for path, expected in ((MODULE, MODULE_SHA), (PLAN, PLAN_SHA), (G8_HELPER, G8_HELPER_SHA),
                           (G8_PROOF, G8_PROOF_SHA), (BEFORE, BEFORE_SHA), (AFTER, AFTER_SHA),
                           (REJECTED / "run.json", REJECTED_RUN_SHA),
                           (LISTING / "comparison.json", LISTING_PROOF_SHA)):
        audit.bind(path, expected)
    audit.bind(Path(__file__))
    accepted, listing, rejected = read(G8_PROOF), read(LISTING / "comparison.json"), read(REJECTED / "run.json")
    require(accepted["graph_proof_available"] is True and accepted["candidate_completed"] is True and
            accepted["artifact_sha256"].get(relative(BEFORE)) == BEFORE_SHA and
            accepted["artifact_sha256"].get(relative(G8_HELPER)) == G8_HELPER_SHA,
            "actual g8 graph/parser is not bound by the accepted reference proof")
    require(rejected["compiler_commit"] == "6552942de15ed48e1bb9fbc71e3c08f189486313" and
            rejected["completed"] is True and type(rejected["exit_code"]) is int and rejected["exit_code"] == 0 and
            rejected["reduction_selection"] == rejected["decomposition_selection"] == 0 and
            listing["phase"] == "list-ac" and listing["compiler_commit"] == rejected["compiler_commit"] and
            listing["partial_graph_evidence_available"] is True and listing["graph_proof_available"] is False,
            "diagnostic rejected route/listing provenance changed")
    plan = read(PLAN)
    require(all(value is None for value in plan["full_phase_bindings"].values()) and
            plan["execution_authorized_by_this_file"] is False, "diagnostic unexpectedly activates a full-route plan")
    # Verify the byte identities of the imported reference utilities before
    # importing them; never run an old comparison/authenticator/main function.
    for name, digest in accepted["artifact_sha256"].items():
        if name.endswith(".py"):
            audit.bind(ROOT / name, digest)
    g8 = module_at(G8_HELPER, "diagnostic_buffer_v2_pinned_g8")
    imports = imported_helpers(g8, accepted, audit)
    buffers = module_at(MODULE, "diagnostic_frozen_route_buffers_v2")
    before, after = top(g8, BEFORE), top(g8, AFTER)
    alms, closure = affected_closure(before, after, accepted, listing)
    declarations = observed_ena_declaration(buffers, before, after)
    positive = buffers.prove_buffers(g8, before, after, alms, declarations)
    require(positive["late_buffer_proof_available"] is True and len(positive["removed_buffers"]) == 1 and
            len(positive["added_buffers"]) == 1 and len(positive["permitted_original_ff_datain_deltas"]) == 2,
            "actual route pair does not exercise the expected removal/addition native ledger")
    negatives = negative_probes(g8, buffers, before, after, alms, declarations, positive)
    require(len(negatives) == 6 and all(row["rejected"] for row in negatives), "negative exercise is incomplete")
    audit.finish()
    result = {"schema": 1, "kind": "diagnostic exercise of frozen native route-buffer v2",
              "status": "partial buffer proof and copied-graph negative probes passed; rejected route remains unaccepted",
              "diagnostic_only": True, "acceptance_proof_available": False, "practical_acceptance": False,
              "whole_graph_equivalence_proved": False, "timing_acceptance_available": False,
              "hardware_acceptance": False, "full_phase_activated": False,
              "reference_full_proof_sha256": G8_PROOF_SHA, "rejected_route_sha256": AFTER_SHA,
              "module_sha256": MODULE_SHA, "plan_sha256": PLAN_SHA,
              "allowed_alm_source": "actual old/new selected twelve reused-cell and AC-clone placements from pinned evidence",
              "selected_placement_alm_closure": closure,
              "observed_declared_ena_edges": declarations,
              "any_ena_exception_truth_proved_by_this_diagnostic": False,
              "positive_native_buffer_ledger": positive, "negative_probes": negatives,
              "actual_graphs_normalized_or_mutated": False, "old_comparisons_reexecuted": False,
              "imported_pinned_utilities": imports, "final_original_path_hash_audit_passed": True,
              "limitations": ["This historical rejected route supplies no fresh experiment qualification or acceptance.",
                              "The selected twelve/AC placement closure is diagnostic evidence, not full non-BUF truth or physical proof.",
                              "An observed ENA exception, if any, requires the caller's separate fresh AC128 truth and native-user closure.",
                              "BUF.A chipdb connectivity, all remaining graph/alias/physical gates and timing remain unproved here.",
                              "No RBF configuration, hardware behavior or in-memory owner/slot identities are proved."],
              "artifact_sha256": {relative(path): digest for path, digest in sorted(audit.paths.items())}}
    with OUTPUT.open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({"output": str(OUTPUT), "removed": len(positive["removed_buffers"]),
                      "added": len(positive["added_buffers"]), "negative_probes": len(negatives),
                      "practical_acceptance": False}, indent=2))


if __name__ == "__main__":
    main()
