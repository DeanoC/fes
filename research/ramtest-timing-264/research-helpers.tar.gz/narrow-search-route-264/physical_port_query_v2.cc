// Host-only query of the same libmistral database linked into the measured backend.
// Reads ordinary LAB x/y/ALM/half tuples. It does not load or change any design.
#include "cyclonev.h"
#include <iostream>
#include <memory>
#include <string>

int main(int argc, char **argv)
{
    if (argc != 2) {
        std::cerr << "usage: physical_port_query MODEL < x-y-alm-half-tuples\n";
        return 2;
    }
    std::unique_ptr<mistral::CycloneV> model(mistral::CycloneV::get_model(argv[1]));
    if (!model) {
        std::cerr << "unsupported model\n";
        return 2;
    }
    int x, y, alm, half;
    while (std::cin >> x) {
        if (!(std::cin >> y >> alm >> half)) {
            std::cerr << "incomplete ordinary LAB tuple\n";
            return 2;
        }
        if (x < 0 || x > 127 || y < 0 || y > 127 || alm < 0 || alm > 9 || half < 0 || half > 1) {
            std::cerr << "invalid ordinary LAB tuple\n";
            return 2;
        }
        using CV = mistral::CycloneV;
        const CV::pnode_coords port{CV::LAB, static_cast<unsigned>(x), static_cast<unsigned>(y),
                                   half ? CV::D : CV::C, static_cast<int8_t>(alm), -1};
        const auto node = model->pnode_to_rnode(port);
        if (node == 0xffffffff) {
            std::cerr << "unmapped ordinary LAB input\n";
            return 2;
        }
        const auto coordinates = model->ri2rc(node);
        if (!coordinates || model->rc2ri(coordinates) != node || model->rnode_to_pnode(node) != port) {
            std::cerr << "physical port/routing-node round trip failed\n";
            return 2;
        }
        std::cout << x << '\t' << y << '\t' << alm << '\t' << half << '\t'
                  << port.to_string() << '\t' << coordinates.to_string() << '\t'
                  << static_cast<int>(model->rnode_is_inverting(node)) << '\n';
    }
    if (!std::cin.eof()) {
        std::cerr << "malformed tuple input\n";
        return 2;
    }
    return 0;
}
