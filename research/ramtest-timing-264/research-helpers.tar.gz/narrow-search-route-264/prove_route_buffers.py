"""Independent native proof of the predeclared late FF DATAIN buffer class.

No helper, compiler or route is run here. Inputs must be actual routed modules
read by the pinned lossless g8 reader. This module does not normalize or mutate
either graph, prove selected LUT rewrites, decode an RBF or accept timing.
"""
import json
import re


BEL = re.compile(r"MISTRAL_(M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)")
COMB_TYPES = {f"MISTRAL_ALUT{i}" for i in range(2, 7)} | {"MISTRAL_NOT", "MISTRAL_BUF"}
BUF_ATTRS = {"NEXTPNR_BEL", "BEL_STRENGTH", "FES_PINMAP_V1"}


def require(condition, message):
    if not condition:
        raise ValueError("route-buffer proof: " + message)


def _unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate physical snapshot key")
        result[key] = value
    return result


def _decode(value):
    require(type(value) is str, "missing hex physical snapshot")
    try:
        return json.loads(bytes.fromhex(value).decode(), object_pairs_hook=_unique,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    except (UnicodeError, ValueError) as error:
        raise ValueError("route-buffer proof: malformed physical snapshot") from error


def _bit(value):
    require(type(value) is int and value >= 0 or type(value) is str and value in {"0", "1", "x", "z"},
            "unsupported native bit")
    return value


class Native:
    """Build native output drivers/users before any transparent interpretation."""
    def __init__(self, top):
        self.top, self.cells = top, top["cells"]
        self.drivers, self.users, self.connections = {}, {}, {}
        self.aliases, self.top_users = {}, {}
        self.pll_ports = getattr(self.cells, "pll_ports", {})
        self.entries = {}
        for name, cell in self.cells.items():
            require(type(name) is str and type(cell) is dict and
                    set(cell["port_directions"]) == set(cell["connections"]), "malformed native cell ports")
            fields = self.pll_ports.get(name)
            if fields:
                require(cell["type"] == "altera_pll" and set(fields) == {"port_directions", "connections"},
                        "unsupported duplicate PLL export")
                directions, connections = fields["port_directions"], fields["connections"]
                require([p for p, _ in directions] == [p for p, _ in connections], "unpaired PLL entries")
                occurrence = {}
                entries = []
                for (port, direction), (_, bits) in zip(directions, connections):
                    current = occurrence.get(port, 0)
                    occurrence[port] = current + 1
                    require(port == "outclk" or current == 0, "unsupported repeated native port")
                    require(port != "outclk" or direction == "output" and len(bits) == 1,
                            "unsupported duplicate PLL clock shape")
                    entries.append((port, direction, bits, current if port == "outclk" else 0))
            else:
                entries = [(port, direction, cell["connections"][port], 0)
                           for port, direction in cell["port_directions"].items()]
            self.entries[name] = entries
            for port, direction, bits, occurrence in entries:
                require(direction in {"input", "output", "inout"} and type(bits) is list, "unsupported native port")
                for index, value in enumerate(bits):
                    bit = _bit(value)
                    slot = occurrence if fields and port == "outclk" else index
                    if direction == "output":
                        require(type(bit) is int and bit not in self.drivers, "ambiguous native output driver")
                        self.drivers[bit] = ("cell", name, port, slot)
        for name, port in top.get("ports", {}).items():
            require(port["direction"] in {"input", "output", "inout"} and type(port["bits"]) is list,
                    "malformed top port")
            for index, bit in enumerate(port["bits"]):
                _bit(bit)
                if port["direction"] == "input":
                    require(type(bit) is int and bit not in self.drivers, "ambiguous top input driver")
                    self.drivers[bit] = ("top", name, "input", index)
                else:
                    self.top_users.setdefault(bit, []).append((name, index, port["direction"]))
        for name, entries in self.entries.items():
            ports = {}
            for port, direction, bits, occurrence in entries:
                tokens = [self.token(bit) for bit in bits]
                key = (port, occurrence) if name in self.pll_ports else port
                ports[key] = tokens
                if direction in {"input", "inout"}:
                    for index, bit in enumerate(bits):
                        self.users.setdefault(self.token(bit), []).append((name, port, index))
            self.connections[name] = ports
        for token in self.users:
            self.users[token].sort()
        for name, net in top.get("netnames", {}).items():
            require(type(name) is str and type(net) is dict and type(net.get("bits")) is list,
                    "malformed named net")
            for index, bit in enumerate(net["bits"]):
                _bit(bit)
                self.aliases.setdefault(bit, []).append((name, index))

    def token(self, bit):
        if type(bit) is str:
            return ("constant", bit)
        return self.drivers.get(bit, ("undriven", bit))


def _location(cell):
    match = BEL.fullmatch(cell.get("attributes", {}).get("NEXTPNR_BEL", ""))
    require(match is not None, "missing or unsupported COMB/FF BEL")
    kind, x, y, z = match.groups()
    x, y, z = int(x), int(y), int(z)
    require(0 <= z < 60 and (z % 6 >= 2 if kind == "FF" else z % 6 < 2), "invalid ALM BEL position")
    return kind, x, y, z


def _pins(g8, name, cell):
    value = _decode(cell.get("attributes", {}).get("FES_PINMAP_V1"))
    require(set(value) == {"count", "pins"} and type(value["count"]) is int and
            type(value["pins"]) is dict and value["count"] == len(value["pins"]), "invalid pin snapshot schema")
    for pin in value["pins"].values():
        require(type(pin) is list and len(pin) >= 1 and type(pin[0]) is int and 0 <= pin[0] <= 3 and
                all(type(name) is str for name in pin[1:]), "invalid physical pin entry")
    # Use the pinned reader's pin utility only after Native built its tables;
    # additionally retain strict duplicate-key/schema checking above.
    require(g8.ready.detail(name, cell).get("physical_pinmap") == value, "pinned pin utility disagrees")
    return value["pins"]


def _metadata(cell):
    return {key: value for key, value in cell.items() if key != "connections"}


def _lab_rows(top):
    value = _decode(top.get("attributes", {}).get("FES_LABSTATE_V1"))
    require(set(value) == {"device", "labs"} and type(value["device"]) is str and type(value["labs"]) is list,
            "invalid LAB snapshot schema")
    rows = {}
    for row in value["labs"]:
        require(type(row) is list and len(row) == 4 and all(type(n) is int for n in row[:3]) and
                row[0] >= 0 and row[1] >= 0 and row[2] in (0, 1) and
                type(row[3]) is list and len(row[3]) == 62, "invalid LAB row")
        for index, item in enumerate(row[3]):
            maximum = 2 if index >= 2 and (index - 2) % 6 in (2, 3) else 1
            require(type(item) is int and 0 <= item <= maximum, "invalid LAB state field")
        key = tuple(row[:2])
        require(key not in rows, "duplicate LAB row")
        rows[key] = row
    return value["device"], rows


def _occupants(native):
    result, bels = {}, set()
    for name, cell in native.cells.items():
        bel = cell.get("attributes", {}).get("NEXTPNR_BEL", "")
        if not BEL.fullmatch(bel):
            continue
        kind, x, y, z = _location(cell)
        require(bel not in bels, "multiple owners of an ALM BEL")
        bels.add(bel)
        result.setdefault((x, y, z // 6), []).append((name, kind, z % 6))
    return result


def _physical_labs(old, new, allowed):
    a_device, a_rows = _lab_rows(old.top)
    b_device, b_rows = _lab_rows(new.top)
    require(a_device == b_device and list(a_rows) == list(b_rows), "LAB device/geometry/order changed")
    occupants = [_occupants(old), _occupants(new)]
    changes = []
    for key, a in a_rows.items():
        b = b_rows[key]
        require(a[:3] == b[:3], "LAB identity changed")
        for index, (before, after) in enumerate(zip(a[3], b[3])):
            if index >= 2 and (index - 2) % 6 == 0:
                alm = (index - 2) // 6
                for native, used, state in zip((old, new), occupants, (before, after)):
                    combs = [name for name, kind, _ in used.get((*key, alm), []) if kind != "FF"]
                    six = [name for name in combs if native.cells[name]["type"] == "MISTRAL_ALUT6"]
                    require(state == int(bool(six)) and (not six or len(six) == len(combs) == 1),
                            "LUT6 mode/whole-ALM occupancy mismatch")
                if before != after:
                    require((*key, alm) in allowed, "LUT6 mode changed outside declared affected ALMs")
                    changes.append({"alm": [*key, alm], "before": before, "after": after})
            else:
                require(before == after, "carry/clock-enable/clear LAB state changed")
    return a_rows, b_rows, occupants, changes


def _routing(native, bit):
    values = []
    for name, _ in native.aliases.get(bit, []):
        value = native.top["netnames"][name].get("attributes", {}).get("ROUTING")
        if value is not None:
            require(type(value) is str, "malformed ROUTING metadata")
            values.append(value)
    require(values and len(set(values)) == 1, "missing or conflicting actual net route")
    fields = values[0].split(";")
    require(len(fields) % 3 == 0, "malformed route triples")
    nodes = {}
    for index in range(0, len(fields), 3):
        wire, pip, strength = fields[index:index + 3]
        require(wire and wire not in nodes and re.fullmatch(r"[0-9]+", strength) is not None,
                "duplicate/malformed routed wire")
        if pip:
            require(pip.endswith("." + wire), "route pip does not terminate at its recorded wire")
            parent = pip[:-(len(wire) + 1)]
            require(parent and parent != wire, "invalid route parent")
        else:
            parent = None
        nodes[wire] = parent
    require(sum(parent is None for parent in nodes.values()) == 1 and
            all(parent is None or parent in nodes for parent in nodes.values()), "route is not one rooted native tree")
    return nodes


def _driver_wire(g8, native, token):
    require(len(token) == 4 and token[0] == "cell" and token[2:] == ("Q", 0),
            "unsupported terminal source identity")
    name = token[1]
    cell = native.cells[name]
    require(type(cell["connections"].get("Q")) is list and len(cell["connections"]["Q"]) == 1,
            "terminal source output is not scalar")
    kind, x, y, z = _location(cell)
    pins = _pins(g8, name, cell)
    if cell["type"] == "MISTRAL_FF":
        require(kind == "FF" and pins.get("Q") == [0, "Q"], "unsupported source FF output pin")
        return f"WIRE.{x}.{y}.FFOUT[{4 * (z // 6) + z % 6 - 2}]"
    require(cell["type"] in COMB_TYPES - {"MISTRAL_BUF"} and kind != "FF" and
            pins.get("Q") == [0, "COMBOUT"], "unsupported source COMB output pin")
    return f"WIRE.{x}.{y}.COMBOUT[{2 * (z // 6) + z % 6}]"


def _ff_route(g8, native, ff, token, buffer=None):
    cell = native.cells[ff]
    kind, x, y, z = _location(cell)
    require(kind == "FF", "DATAIN consumer is not a physical FF")
    pins = _pins(g8, ff, cell)
    require(pins.get("DATAIN") == [0, "DATAIN"], "unsupported FF DATAIN physical state")
    bit = cell["connections"]["DATAIN"][0]
    nodes = _routing(native, bit)
    sink = f"WIRE.{x}.{y}.FFIN[{4 * (z // 6) + z % 6 - 2}]"
    require(sink in nodes, "actual route does not reach the fixed FF DATAIN wire")
    path, current, seen = [], sink, set()
    while current is not None:
        require(current not in seen and len(path) < len(nodes) + 1, "cyclic FF input route")
        seen.add(current)
        path.append(current)
        current = nodes[current]
    if buffer:
        _, bx, by, bz = _location(native.cells[buffer])
        source = f"WIRE.{bx}.{by}.COMBOUT[{2 * (bz // 6) + bz % 6}]"
        require(path == [sink, source] and set(nodes) == {sink, source}, "private BUF Q is not its exact local FF route")
        choice = "paired LUT COMBOUT to FFIN"
    else:
        require(path[-1] == _driver_wire(g8, native, token), "unbuffered FF route root differs from its native source")
        comb = f"WIRE.{x}.{y}.COMBOUT[{2 * (z // 6) + (z % 6 - 2) // 2}]"
        ef = f"WIRE.{x}.{y}.{'B' if z % 6 >= 4 else 'T'}EF[{z // 6}]"
        require(len(path) >= 2 and path[1] in {comb, ef}, "unsupported FF DATAIN ingress mux path")
        choice = "paired LUT COMBOUT to FFIN" if path[1] == comb else "paired EF to FFIN"
    return {"root_to_datain_wires": list(reversed(path)), "actual_ff_ingress": choice,
            "lab_snapshot_alone_does_not_prove_data_mux": True}


def _alm_mask(g8, native, key, occupants):
    """Derive both occupied L5 banks and shared physical-input consistency."""
    raw_mask, physical_sources, halves = 0, {}, []
    for name, kind, half in occupants.get(key, []):
        if kind == "FF":
            continue
        cell = native.cells[name]
        require(cell["type"] in COMB_TYPES - {"MISTRAL_ALUT6"}, "unsupported BUF neighbor LUT mode")
        width = 1 if cell["type"] in {"MISTRAL_BUF", "MISTRAL_NOT"} else int(cell["type"].removeprefix("MISTRAL_ALUT"))
        if cell["type"] in {"MISTRAL_BUF", "MISTRAL_NOT"}:
            require(cell["parameters"] == {}, "one-input LUT has an unexpected parameter")
            table = 2 if cell["type"] == "MISTRAL_BUF" else 1
        else:
            value = cell["parameters"].get("LUT")
            require(set(cell["parameters"]) == {"LUT"} and type(value) is str and
                    len(value) == 1 << width and set(value) <= {"0", "1"}, "invalid BUF neighbor LUT table")
            table = int(value, 2)
        pins = _pins(g8, name, cell)
        require(pins.get("Q") == [0, "COMBOUT"], "unsupported BUF neighbor output polarity")
        allowed_pins = {"A": 0, "B": 1, "D" if half else "C": 2, f"E{half}": 3, f"F{half}": 4}
        for pin in "ABCDE"[:width]:
            state = pins.get(pin)
            require(state is not None and type(cell["connections"].get(pin)) is list,
                    "missing BUF neighbor input pin")
            if state[0] in (1, 2):
                continue
            require(len(state) == 2 and state[1] in allowed_pins and len(cell["connections"][pin]) == 1,
                    "unsupported BUF neighbor physical input")
            source = native.token(cell["connections"][pin][0])
            require(source[0] not in {"constant", "undriven"}, "unresolved shared physical input")
            require(state[1] not in physical_sources or physical_sources[state[1]] == source,
                    "shared ALM physical input has different native drivers")
            physical_sources[state[1]] = source
        occupied = 0
        for row in range(32):
            address = 0
            for index, pin in enumerate("ABCDE"[:width]):
                state = pins[pin]
                value = 0 if state[0] == 1 else 1 if state[0] == 2 else (
                    ((row >> allowed_pins[state[1]]) & 1) ^ int(state[0] != 3))
                address |= value << index
            output = (table >> address) & 1
            raw_mask |= output << (32 * half + row)
            occupied |= (1 ^ output) << row
        halves.append({"cell": name, "half": half, "physical_rows_checked": 32,
                       "derived_stored_half_mask_hex": hex(occupied)})
    return {"derived_stored_whole_alm_mask_hex": hex(raw_mask ^ ((1 << 64) - 1)),
            "occupied_half_images": sorted(halves, key=lambda row: row["half"]),
            "shared_physical_input_native_drivers": {pin: list(source) for pin, source in sorted(physical_sources.items())},
            "configuration_bits_independently_decoded": False}


def _buffer(g8, native, name, allowed, rows, occupancy):
    cell = native.cells[name]
    require(set(cell) == {"hide_name", "type", "parameters", "attributes", "port_directions", "connections"} and
            cell["type"] == "MISTRAL_BUF" and cell["parameters"] == {} and
            cell["port_directions"] == {"A": "input", "Q": "output"} and
            set(cell["connections"]) == {"A", "Q"} and
            all(type(bits) is list and len(bits) == 1 and type(bits[0]) is int for bits in cell["connections"].values()),
            "late BUF shape differs from scalar identity")
    kind, x, y, z = _location(cell)
    key, half = (x, y, z // 6), z % 6
    require(kind == "COMB" and key in allowed and rows[(x, y)][2] == 0,
            "BUF lies outside declared ordinary LAB ALMs or requires unsupported MLAB mask permutation")
    token = ("cell", name, "Q", 0)
    users = native.users.get(token, [])
    require(len(users) == 1 and users[0][1:] == ("DATAIN", 0), "BUF Q is not private to one FF DATAIN")
    ff = users[0][0]
    require(native.cells[ff]["type"] == "MISTRAL_FF", "BUF DATAIN consumer is not an original FF")
    fk, fx, fy, fz = _location(native.cells[ff])
    require(fk == "FF" and (fx, fy, fz // 6) == key and (fz % 6 - 2) // 2 == half,
            "BUF and FF do not share an ALM half")
    attrs = cell["attributes"]
    expected_attrs = BUF_ATTRS | ({"FES_SLOT"} if "FES_SLOT" in native.cells[ff]["attributes"] else set())
    require(set(attrs) == expected_attrs and attrs["BEL_STRENGTH"] == format(2, "032b") and
            attrs.get("FES_SLOT") == native.cells[ff]["attributes"].get("FES_SLOT"), "unexpected late BUF attributes")
    pins = _pins(g8, name, cell)
    require(pins == {"A": [0, "D" if half else "C"], "Q": [0, "COMBOUT"]},
            "late BUF is not actual SIG C/D to COMBOUT")
    state = rows[(x, y)][3]
    require(state[2 + 6 * key[2]:4 + 6 * key[2]] == [0, 0], "BUF shares LUT6/carry mode")
    lut_cells = [(owner, slot) for owner, occupant_kind, slot in occupancy.get(key, []) if occupant_kind != "FF"]
    require(all(native.cells[owner]["type"] in COMB_TYPES - {"MISTRAL_ALUT6"} for owner, _ in lut_cells),
            "BUF shares unsupported arithmetic/memory/LUT6 occupancy")
    require(sum(1 if native.cells[owner]["type"] in {"MISTRAL_BUF", "MISTRAL_NOT"} else
                int(native.cells[owner]["type"].removeprefix("MISTRAL_ALUT")) for owner, _ in lut_cells) <= 8,
            "BUF ALM input capacity exceeded")
    bit = cell["connections"]["Q"][0]
    aliases = native.aliases.get(bit, [])
    require(aliases == [(name + "$conn$Q", 0)] and not native.top_users.get(bit), "BUF Q has a public/extra alias or top port")
    private_name = aliases[0][0]
    net = native.top["netnames"][private_name]
    require(set(net) == {"hide_name", "bits", "attributes"} and type(net["hide_name"]) is int and net["hide_name"] in (0, 1) and
            set(net["attributes"]) == {"ROUTING"}, "BUF private Q has extra semantic metadata")
    source = native.token(cell["connections"]["A"][0])
    _driver_wire(g8, native, source)
    # In L5 mode C/D both occupy address bit2. Logical init=2 evaluates
    # NOT(physical bit2) for SIG; final active-low storage complement reverses
    # it. Derive the occupied half rather than equating init2 with CRAM bits.
    mask = 0
    for row in range(32):
        physical = (row >> 2) & 1
        logical = 1 ^ physical
        output = (2 >> logical) & 1
        require(output == logical, "identity truth derivation failed")
        mask |= (1 ^ output) << row
    require(mask == 0xf0f0f0f0, "BUF physical half truth image differs")
    alm_truth = _alm_mask(g8, native, key, occupancy)
    require(next(row for row in alm_truth["occupied_half_images"] if row["cell"] == name)[
        "derived_stored_half_mask_hex"] == hex(mask), "joint ALM image differs from BUF identity half")
    return {"cell": name, "ff": ff, "alm": list(key), "half": half,
            "native_source": list(source), "native_q": list(token), "q_bit": bit,
            "private_q_net": private_name, "native_q_users": [list(user) for user in users],
            "logical_rows": [[0, 0], [1, 1]], "physical_half_rows": 32,
            "derived_stored_half_mask_hex": hex(mask), "actual_pins": pins, "joint_alm_truth": alm_truth,
            "q_route": _ff_route(g8, native, ff, token, name)}


def prove_buffers(g8, before_top, after_top, allowed_alms):
    """Return buffer ledger and permitted FF.DATAIN deltas; raise on rejection.

    The caller authenticates allowed_alms from predeclared selected placements,
    proves every selected non-BUF rewrite, and closes all remaining graph,
    alias, route, control, timing and artifact gates. No graphs are changed.
    """
    require(type(allowed_alms) in (list, tuple, set, frozenset) and all(
        type(alm) in (list, tuple) and len(alm) == 3 and all(type(n) is int and n >= 0 for n in alm) and alm[2] < 10
        for alm in allowed_alms), "invalid predeclared affected ALM closure")
    allowed = {tuple(alm) for alm in allowed_alms}
    require(len(allowed) == len(allowed_alms), "duplicate affected ALM identity")
    old, new = Native(before_top), Native(after_top)
    # Tables above deliberately precede all g8 helpers and BUF interpretation.
    old_rows, new_rows, occupants, mode_changes = _physical_labs(old, new, allowed)
    buffers = [{name for name, cell in native.cells.items() if cell["type"] == "MISTRAL_BUF"}
               for native in (old, new)]
    removed, added = sorted(buffers[0] - buffers[1]), sorted(buffers[1] - buffers[0])
    for name in sorted(buffers[0] & buffers[1]):
        require(_metadata(old.cells[name]) == _metadata(new.cells[name]) and
                old.connections[name] == new.connections[name] and
                old.users.get(("cell", name, "Q", 0), []) == new.users.get(("cell", name, "Q", 0), []),
                "unchanged BUF metadata/native input/users changed: " + name)
        _location(old.cells[name])
        require(set(old.cells[name]["port_directions"]) <= set(_pins(g8, name, old.cells[name])),
                "unchanged BUF lacks a complete physical snapshot")
    proofs = [{name: _buffer(g8, native, name, allowed, rows, used) for name in names}
              for native, names, rows, used in zip((old, new), (removed, added),
                                                   (old_rows, new_rows), occupants)]
    by_ff = [{proof["ff"]: proof for proof in side.values()} for side in proofs]
    require(all(len(side) == len(index) for side, index in zip(proofs, by_ff)), "multiple delta BUFs for one FF")
    ffs = [{name for name, cell in native.cells.items() if cell["type"] == "MISTRAL_FF"} for native in (old, new)]
    require(ffs[0] == ffs[1], "original FF set changed")
    deltas = []
    for ff in sorted(ffs[0]):
        require(_metadata(old.cells[ff]) == _metadata(new.cells[ff]), "original FF physical/state metadata changed: " + ff)
        require(_location(old.cells[ff])[0] == "FF" and
                set(old.cells[ff]["port_directions"]) <= set(_pins(g8, ff, old.cells[ff])),
                "original FF lacks a complete fixed physical snapshot")
        before, after = old.connections[ff], new.connections[ff]
        require(set(before) == set(after) and all(before[p] == after[p] for p in before if p != "DATAIN"),
                "original FF non-DATAIN port changed: " + ff)
        if before.get("DATAIN") == after.get("DATAIN"):
            require(ff not in by_ff[0] and ff not in by_ff[1], "declared BUF delta has no FF DATAIN native delta")
            continue
        require(ff in by_ff[0] or ff in by_ff[1], "unexplained original FF DATAIN delta: " + ff)
        require(len(before.get("DATAIN", [])) == len(after.get("DATAIN", [])) == 1, "nonscalar FF DATAIN")
        sources, route_proofs, native_edges = [], [], []
        for native, index, connection in zip((old, new), by_ff, (before, after)):
            proof = index.get(ff)
            source = tuple(proof["native_source"]) if proof else connection["DATAIN"][0]
            require(source[0] == "cell" and native.cells[source[1]]["type"] != "MISTRAL_BUF",
                    "unsupported/cyclic/multiple-buffer terminal source")
            sources.append(source)
            route_proofs.append(proof["q_route"] if proof else _ff_route(g8, native, ff, source))
            native_edges.append([
                {"driver": list(source), "consumer": [proof["cell"], "A", 0]},
                {"driver": proof["native_q"], "consumer": [ff, "DATAIN", 0]}
            ] if proof else [{"driver": list(source), "consumer": [ff, "DATAIN", 0]}])
        require(sources[0] == sources[1], "buffer substitution changed terminal native source: " + ff)
        deltas.append({"ff": ff, "port": "DATAIN", "index": 0,
                       "before_native_driver": list(before["DATAIN"][0]), "after_native_driver": list(after["DATAIN"][0]),
                       "proved_terminal_source": list(sources[0]),
                       "before_native_edges": native_edges[0], "after_native_edges": native_edges[1],
                       "removed_buffer": by_ff[0].get(ff, {}).get("cell"), "added_buffer": by_ff[1].get(ff, {}).get("cell"),
                       "before_input_route": route_proofs[0], "after_input_route": route_proofs[1]})
    require({row["ff"] for row in deltas} == set(by_ff[0]) | set(by_ff[1]), "BUF/FF delta ledger is not closed")
    alias_deltas = []
    for side, other, names, side_proofs, operation in ((old, new, removed, proofs[0], "remove"),
                                                    (new, old, added, proofs[1], "add")):
        for name in names:
            proof = side_proofs[name]
            private = proof["private_q_net"]
            require(private not in other.top["netnames"], "private BUF Q name survived with a different meaning")
            alias_deltas.append({"operation": operation, "name": private, "native_driver": proof["native_q"],
                                 "raw_bit": proof["q_bit"], "users": proof["native_q_users"]})
    return {"late_buffer_proof_available": True, "native_tables_built_before_any_buffer_collapse": True,
            "allowed_alms": [list(alm) for alm in sorted(allowed)],
            "removed_buffers": list(proofs[0].values()), "added_buffers": list(proofs[1].values()),
            "permitted_original_ff_datain_deltas": deltas, "permitted_private_q_alias_deltas": alias_deltas,
            "unchanged_buffer_count": len(buffers[0] & buffers[1]), "unchanged_buffers_exact": True,
            "all_original_ffs_physical_metadata_and_other_ports_exact": True,
            "actual_lut6_mode_deltas": mode_changes, "all_other_lab_control_fields_exact": True,
            "raw_bit_reuse_is_not_a_rename": True,
            "caller_still_must_close": ["selected non-BUF function/physical proofs", "all remaining native graph/users/aliases",
                                       "actual routing to BUF physical A input using the authenticated chip database",
                                       "outside non-FF physical preservation and ALM sharing", "whole routed legality/connectivity",
                                       "PLL/clock/constraint/window/hold/timing gates", "authenticated artifact closure"],
            "limitations": ["Derived pin/mask and actual input-wire checks do not decode RBF configuration bits.",
                            "Changed BUF proofs support ordinary LAB L5 banks only; MLAB, carry, LUT6 and longer BUF chains fail closed.",
                            "LAB snapshots alone do not serialize or prove FF data mux choices.",
                            "No selected transformation, timing, whole-RBF or hardware acceptance is supplied.",
                            "JSON does not expose indexed-user slot/free-list or dictionary owner/bucket identities."],
            "hardware_acceptance": False}
