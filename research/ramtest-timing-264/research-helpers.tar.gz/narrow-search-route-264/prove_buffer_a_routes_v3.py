"""Partial native BUF.A ancestry proof using a separately pinned scoped query.

The producer implementation is frozen before routing; exact payload/output
evidence is supplied afterward with its concrete validation SHA. Historical
900/6e49 files stay immutable. No query, normalization or old proof is run.
"""
import importlib.util
from pathlib import Path

HERE = Path(__file__).resolve().parent
UTILITIES = HERE / "prove_buffer_a_routes.py"
UTILITIES_SHA = "900afadc2b62ca9f636418eafcb1c8c8745b4e9b3a83918066f5044136d299f4"
VALIDATOR = HERE / "validate_port_query_v3.py"
VALIDATOR_SHA = "52d06cc9c70fe5c809ccc2920f8298d466a541fd1b763d5e1ab79015570a655e"
BUFFER_MODULE_SHA = "220e0dc45b9948d746dc9372b6951bfe1566419ddc76a9ae4c2eda3b6ecef06c"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
QUERY_SOURCE_SHA = "da48e2de2b0ab817bb03fe721f9c3246c4b7bd1adeaa4beec95a82fb01693360"
QUERY_BINARY_SHA = "e5faaca4f116085156ed6c1ac866239801e9fe85b47177e0c26a83c1d51e77cf"
BACKEND_LIBRARY_SHA = "3d98c6cc4577d619a706e74e3a2d74dcb0bd3c48fe459d2e5b718896c98225d6"


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def utilities():
    import hashlib
    if hashlib.sha256(UTILITIES.read_bytes()).hexdigest() != UTILITIES_SHA:
        raise ValueError("buffer-A v3 proof: frozen pure utilities changed")
    return module_at(UTILITIES, "buffer_A_v3_frozen_pure_utilities")


def query_rows(binding, expected_validation_sha256, eligible_halves, audit, pure):
    require = pure.require
    audit.bind(VALIDATOR, VALIDATOR_SHA)
    validator = module_at(VALIDATOR, "buffer_A_v3_pinned_scoped_producer")
    eligible = validator.tuple_rows(eligible_halves)
    require(type(expected_validation_sha256) is str and pure.DIGEST.fullmatch(expected_validation_sha256),
            "missing caller-pinned exact completed query validation SHA256")
    fields = {"schema", "model", "command", "completed", "exit_code", "source", "binary",
              "backend_library", "stdin", "stdout", "dependency_sha256", "runtime_file_sha256",
              "validation", "execution", "scope"}
    require(type(binding) is dict and set(binding) == fields and type(binding["schema"]) is int and
            binding["schema"] == 2 and binding["completed"] is True and
            type(binding["exit_code"]) is int and binding["exit_code"] == 0,
            "query binding is not an exact completed schema2 record")
    source = audit.identity(binding["source"], QUERY_SOURCE_SHA)
    binary = audit.identity(binding["binary"], QUERY_BINARY_SHA)
    library = audit.identity(binding["backend_library"], BACKEND_LIBRARY_SHA)
    stdin, stdout = audit.identity(binding["stdin"]), audit.identity(binding["stdout"])
    validation_path = audit.identity(binding["validation"], expected_validation_sha256)
    scope_path = audit.identity(binding["scope"])
    audit.closure(binding["dependency_sha256"])
    audit.closure(binding["runtime_file_sha256"])
    scope, references = validator.authenticate_scope(scope_path)
    audit.closure(references)
    require(validator.tuple_rows(scope["eligible_halves"]) == eligible,
            "postroute query expands or changes the caller's sealed eligible half scope")
    validation, execution = pure.read(validation_path), binding["execution"]
    require(validation["schema"] == 2 and validation["kind"] == "exact scoped BUF.A host query validation" and
            validation["status"] == "five scoped host-only query checks passed" and
            validation["producer_sha256"] == VALIDATOR_SHA and validation["diagnostic_only"] is True and
            validation["timing_acceptance_available"] is False and validation["whole_graph_equivalence_proved"] is False and
            validation["hardware_acceptance"] is False and validation["final_original_path_rehash_passed"] is True and
            binding["model"] == validation["model"] == validator.MODEL and
            binding["command"] == [str(binary), binding["model"]] and
            validation["binary_sha256"] == QUERY_BINARY_SHA and validation["source_sha256"] == QUERY_SOURCE_SHA and
            validation["backend_static_library_sha256"] == BACKEND_LIBRARY_SHA and
            validation["toolchain_reference_sha256"] == validator.TOOLCHAIN_REFERENCE_SHA and
            validation["scope"] == binding["scope"] and validation["scope_reference"] == scope["reference"] and
            validation["reference_kind"] == scope["reference_kind"] and validation["eligible_halves"] == eligible_halves and
            validation["stdin"] == binding["stdin"] and binding["dependency_sha256"] == validation["input_sha256"] and
            execution == validation["execution"] and type(execution) is dict and
            binding["runtime_file_sha256"] == execution["files"] and
            execution["files"].get(str(binary)) == QUERY_BINARY_SHA,
            "scoped query/model/library/producer/dependency/runtime aliases differ")
    for path, digest in ((source, QUERY_SOURCE_SHA), (binary, QUERY_BINARY_SHA),
                         (library, BACKEND_LIBRARY_SHA), (VALIDATOR, VALIDATOR_SHA),
                         (stdin, binding["stdin"]["sha256"]), (scope_path, binding["scope"]["sha256"]),
                         (validator.TOOLCHAIN_REFERENCE, validator.TOOLCHAIN_REFERENCE_SHA)):
        require(binding["dependency_sha256"].get(str(path)) == digest,
                "query dependency closure omits an exact producer/input identity")
    require(all(binding["dependency_sha256"].get(path) == digest for path, digest in references.items()),
            "query dependency closure omits its authenticated scope reference")
    cases = validation["cases"]
    labels = ["actual_requested_buf_ports", "incomplete_final_tuple", "unsupported_half", "malformed_token", "unknown_model"]
    require(type(cases) is list and len(cases) == len(labels) and [row["case"] for row in cases] == labels and
            [row["exit_code"] for row in cases] == [0, 2, 2, 2, 2] and
            cases[0]["command"] == binding["command"] and cases[0]["stderr"] == "" and
            all(row["stdout"] == "" and row["stderr"] for row in cases[1:]),
            "scoped host validation lacks the exact positive and four rejecting cases")
    input_text, output_text = stdin.read_text(), stdout.read_text()
    inputs = validator.input_rows(input_text)
    x, y, alm, half = inputs[0]
    require(input_text == cases[0]["stdin"] and output_text == cases[0]["stdout"] and
            validation["positive_stdout_path"] == str(stdout) and
            validation["positive_stdout_sha256"] == binding["stdout"]["sha256"] and
            validation["queried_halves"] == [list(row) for row in inputs] and set(inputs) <= set(eligible) and
            [row["stdin"] for row in cases[1:]] == [f"{x} {y} {alm}\n", f"{x} {y} {alm} 2\n",
                f"{x} {y} bad {half}\n", f"{x} {y} {alm} {half}\n"] and
            [row["command"] for row in cases[1:]] == [binding["command"]] * 3 +
                [[str(binary), "not-a-cyclonev-model"]],
            "actual scoped query payload or negative-case inputs differ from their completed validation")
    return validator.output_rows(output_text, inputs), scope


def prove_buffer_a_routes(g8, before_top, after_top, buffer_ledger, query_binding,
                          expected_validation_sha256, eligible_halves):
    """Prove exact current native BUF.A paths under a predeclared tuple scope.

    Full callers must separately pin the binding document SHA and require its
    scope.reference_kind == full_profile with their own sealed profile identity.
    The diagnostic scope variant supplies host exercise evidence only. No graph
    or binding object is changed, and no producer/main function is invoked.
    """
    pure = utilities()
    require, audit = pure.require, pure.Audit()
    audit.bind(UTILITIES, UTILITIES_SHA)
    require(hasattr(g8, "__file__"), "missing pinned lossless netlist utilities")
    audit.bind(Path(g8.__file__).absolute(), G8_HELPER_SHA)
    rows, scope = query_rows(query_binding, expected_validation_sha256, eligible_halves, audit, pure)
    buffers = pure.frozen_buffers(audit)
    old, new = buffers.Native(before_top), buffers.Native(after_top)
    require(type(buffer_ledger) is dict and buffer_ledger["late_buffer_proof_available"] is True and
            buffer_ledger["native_tables_built_before_any_buffer_collapse"] is True and
            buffer_ledger["hardware_acceptance"] is False, "missing independently proved native buffer ledger")
    allowed_rows = buffer_ledger["allowed_alms"]
    require(type(allowed_rows) is list and all(type(row) is list and len(row) == 3 and
            all(type(value) is int and value >= 0 for value in row) and row[2] < 10 for row in allowed_rows),
            "invalid ledger affected-ALM closure")
    allowed = {tuple(row) for row in allowed_rows}
    require(len(allowed) == len(allowed_rows) and all(tuple(row[:3]) in allowed for row in eligible_halves),
            "duplicate affected ALM or eligible query half outside native ledger closure")
    delta_lists = [buffer_ledger["removed_buffers"], buffer_ledger["added_buffers"]]
    require(all(type(side) is list for side in delta_lists), "malformed buffer addition/removal ledger")
    delta_sets = [{row["cell"] for row in side} for side in delta_lists]
    require(all(len(names) == len(side) for names, side in zip(delta_sets, delta_lists)), "duplicate buffer ledger row")
    actual_sets = [{name for name, cell in native.cells.items() if cell["type"] == "MISTRAL_BUF"}
                   for native in (old, new)]
    require(delta_sets == [actual_sets[0] - actual_sets[1], actual_sets[1] - actual_sets[0]],
            "buffer ledger addition/removal set differs from the actual native graphs")
    traces, used = [], set()
    for native, side, operation in zip((old, new), delta_lists, ("remove", "add")):
        device, lab_rows = buffers._lab_rows(native.top)
        require(device == query_binding["model"], "query model differs from actual LAB device snapshot")
        occupants = buffers._occupants(native, allowed)
        for row in side:
            actual = buffers._buffer(g8, native, row["cell"], allowed, lab_rows, occupants)
            require(actual == row, "buffer ledger differs from actual native/pin/mask/private-route proof")
            key = (*actual["alm"], actual["half"])
            require(key in rows, "actual BUF.A half lacks its exact completed physical-port query")
            used.add(key)
            source = tuple(actual["native_source"])
            cell = native.cells[row["cell"]]
            source_bit = cell["connections"]["A"][0]
            require(native.token(source_bit) == source and native.connections[row["cell"]]["A"] == [source] and
                    actual["actual_pins"]["A"] == [0, "D" if key[3] else "C"],
                    "actual buffer A source/pin differs from native ledger")
            nodes = buffers._routing(native, source_bit)
            physical = rows[key]["actual_arch_wire"]
            require(physical in nodes, "native source ROUTING does not reach the queried physical BUF.A node")
            path, current, seen = [], physical, set()
            while current is not None:
                require(current not in seen and current in nodes, "cycle or missing parent in BUF.A native route")
                seen.add(current)
                path.append(current)
                current = nodes[current]
            output = buffers._driver_wire(g8, native, source)
            require(path[-1] == output, "queried BUF.A route ancestry ends at a different native source output")
            edges = [{"from": parent, "to": child, "exported_pip": parent + "." + child}
                     for child, parent in zip(path, path[1:])]
            traces.append({"operation": operation, "buffer": row["cell"], "ff": actual["ff"],
                           "alm": actual["alm"], "half": actual["half"], "actual_A_pins": actual["actual_pins"]["A"],
                           "native_source": list(source), "source_net_raw_bit": source_bit,
                           "source_net_named_aliases": [list(alias) for alias in native.aliases.get(source_bit, [])],
                           "physical_query": rows[key], "actual_native_output_wire": output,
                           "root_to_buffer_A_wires": list(reversed(path)),
                           "root_to_buffer_A_exported_pips": list(reversed(edges)),
                           "source_route_node_count": len(nodes),
                           "complete_exported_source_route_is_one_acyclic_rooted_tree": True,
                           "actual_native_source_identity_and_physical_A_ancestry_match": True})
    require(used == set(rows), "query payload has an omitted/spare actual physical-port row")
    audit.finish()
    return {"buffer_A_native_route_proof_available": True, "native_graphs_normalized_or_mutated": False,
            "buffer_A_routes": traces, "queried_distinct_alm_halves": len(used),
            "query_source_sha256": QUERY_SOURCE_SHA, "query_binary_sha256": QUERY_BINARY_SHA,
            "same_backend_library_sha256": BACKEND_LIBRARY_SHA, "query_validation_sha256": expected_validation_sha256,
            "query_validator_sha256": VALIDATOR_SHA, "buffer_module_sha256": BUFFER_MODULE_SHA,
            "query_scope_reference_kind": scope["reference_kind"], "query_scope_reference": scope["reference"],
            "caller_eligible_halves": eligible_halves, "exact_completed_payload_used": True,
            "entry_and_final_original_dependency_runtime_query_paths_rehashed": True,
            "query_executed_by_this_module": False, "old_proof_functions_called": False,
            "whole_graph_equivalence_proved": False, "timing_acceptance_available": False,
            "RBF_configuration_bits_decoded": False, "hardware_acceptance": False,
            "caller_still_must_close": ["Actual routed documents, utilities, native ledger and supplemental binding artifact SHA identities.",
                "For full use, scope reference must be exactly the caller's own presealed full profile, never a diagnostic scope.",
                "Selected11/12/AC and retained-stack truth/native-user/alias/physical proofs; outside cells/pins and FF DATAIN mux proof.",
                "Whole-route legality and genuine chipdb validity of every exported pip, all PLL/clock windows/holds/final timing and acceptance gates."],
            "authenticated_file_sha256": {str(path): digest for path, digest in sorted(audit.paths.items())}}
