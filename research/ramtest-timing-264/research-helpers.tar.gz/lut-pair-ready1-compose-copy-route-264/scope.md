# Fresh port1 selected composed-copy full route recorder

This new inactive pair owns only run_route.py and this scope. ROOT alone performs
imports, AST, preparation, compiler/test/GPU/Git and helper operations. Current
compiler cae5eb9a on e137ca5b, ELFa2b5da93/archivec64eb65c, host84416288 and all
58 native/51 CLI cases are explicit. Selected profile/run/positive proof/comparer
remain UNFROZEN until ROOT supplies the actual closed identities. No candidate
index is assumed and no route can start with an absent or rejected prerequisite.

Preparation requires the independently positive selected/comparison-selected-copy.json
with phase lut-pair-ready1-selected-composed-copy-conditional-native-proof and BOTH
selected_native_graph_and_conditional_function_proved and
fresh_full_route_prerequisite_under_plain_sig_condition. The exact closed selected
profile, run, recorder, comparer, scopes, candidate, ten models and raw graph
evidence are bound. Its conditional plain-SIG truth is retained as the prerequisite
limit: physical pins, unexported caches and routed gain remain explicitly unproved.
The own positive ready1 listing cf485b65/run540bb108/profile6616243a and every
transitive direct reference remain bound through the independently produced flat
artifact/runtime ledger. The prior ready0 extra copy is absent from this fresh
TEN graph. The guide's rejected ready0 routed source is provenance only.

The fresh command copies the actual selected argv. Its ONLY delta removes the
sole --no-route, changes --write and --report to this new route directory and adds
--rbf pointing to the exclusive local core.rbf. Literal TEN00bf, current one-path
guideea8e and originc95a, explicit actual candidate, compose-copy flag, source
JSON/QSF/SDC/device/seed,
router gpu/device1, placement flags and diagnostic environment remain exact.
Neither a post plan nor a LUT driver selector is added. RBF generation is a local
artifact operation; no hardware programming, deployment or RBF decoding occurs.
The same current FunctionalInvocation runtime is required without substitution.

Only pinned lower pure definitions are loaded: current selected recorder's
definitions/qualification (and current listing/control/TEN log parser chain),
32fd lossless native reader/metrics, 72131 report topology with isolated8601.
No prior prepare, execute, route, main, authenticate, compare, native prove or
physical/timing evaluator is invoked. This recorder implements its own host and
closure checks. All called pure/project modules are pinned at their original
paths before loading; the five project modules actually loaded by ROOT must match.

Complete current host source/submodule/model/object-dependency maps, executable,
archive, checks, both selected input/output/runtime closures and positive proof
ledgers are rehashed before preparation and after execution. The checkout remains
clean at the declared current commit and model/submodule identities. Preparation
publishes source-identity.json exclusively; routing publishes route/run.json and
route/route.log/routed.json/timing.json/core.rbf exclusively. Compiler read auditing
binds every actual read. Failed attempts preserve actual exit status, raw logs,
available partial outputs and final independent source/runtime/hash outcome.

The whole original FF manifest is literal for all8221 FFs. Original LUT, selected
clone, whole two-FF enable cohort and every retained ten-copy cohort LAB are
predeclared from the verified selected image, with all original FF records in
those LABs.
All15 original target-LAB FF records are derived from the own selected image,
with the proof's two ENA changes applied and the remaining13 controls exact.
The exact current path1 and tied2975, origin/source hashes and the selected
guide-native bridge remain bound. Actual clone name/Q/BEL and affected LAB
union are derived from the positive selected proof; no old site or BUF count
is assumed. Leaf neighborhoods are retained through that proof's independent
whole FF manifests. The fresh compiler must reproduce all ten complete guarded
models, the exact selected copy prefix/application and all71 placement metrics.
No original FF may move. Actual copy application must precede GPU routing, final
RBF signoff and normal completion. The completed live backend must be HIP/device1;
the LAST signoff must contain no hold/min violation or warning. All four full
outputs must exist, be nonempty and remain hash-stable.

The full report retains cap16384, all15290 native paths and seven actual registered
clock-pair/window counts, validated against its own selected report. Its actual
topology is reconstructed from fresh routed JSON. Current Fmax values must be
finite with the same exact clock constraints as accepted FIVE. Numerical changes
are recorded even when below the acceptance threshold. This recorder does not
require a timing gain and never promotes an execution result to acceptance.

The accepted FIVE proof6dcf8c4b/run5ed3c077 and memory117.77175903320312MHz are bound
directly as the timing reference, with identical RTL/QSF/SDC/device/seed/router
inputs and environment/runtime apart from the explicitly different compiler/PATH.
Its original physical graph is not a reference for new-copy physical equality:
it contains other transformations and a separate driver copy. Independent later
proof must evaluate every fresh actual physical LUT/ALM, original shared-bank
mates, protected carry neighbors and whole FF CLK/ENA/control banks against the
own verified selected native graph and conditional tables, including effective
constants/inversions and any routing BUF/private-owner frames. No blanket ID,
pin-map, cache or graph normalization is authorized. Acceptance requires that
fresh physical/native proof, strict memory gain above accepted117.771759, all six
other windows positive (capture5ns/half-cycle3.845999956ns) and LAST holds0. No
hardware or achieved130MHz claim is made here.
