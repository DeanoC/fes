# Conditional five-stage full-route recorder

Root alone prepares or runs this new helper. Preparation requires an explicit
`--prefix-sha256` of the future completed positive five-stage native-prefix
proof; there is no guessed or default positive proof/run hash. It must be the
address fifth-stage phase for compiler81243/base5dd, actual profilea1bb561a and
plan4221d99b, with structural rejection null and fresh driver guide available.
The future actual baseline run, prefix generator and comparison scope are bound
from that hash-pinned proof and checked against their actual closed files.

The complete flat prefix artifact and external execution maps are rehashed,
including the retained positive10016 four-stage proof, accepted fulla4a/71b,
current controlf3e1, host98c1, guide704a/derivationc953, actual five-stage inputs,
outputs and runtime. No historical authentication, preparation, runner,
comparison, validator or main entrypoint executes. Only definitions from frozen
3e81198b are reused for byte binding, duplicate-safe JSON, clean-source checking
and the fresh driver log parser. The pinned a2d62625 fifth-stage parser and its
440013 four-stage parser authenticate actual local qualification. Pure32fd is
used only to read the lossless actual native image. No helper globals change.

Source, ELF91a, archivec947 and all original paths remain untouched. The actual
runtime must equal the proved five-stage baseline, and differ from the accepted
full runtime only in the explicitly bound compiler file and controlled PATH.
Device1, libraries, HIP environment, platform, tracer, RTL, constraints, seed,
BUILD_ID and all existing diagnostic options remain exact. Every input and
output is rehashed at the end, including failure paths.

The full command is constructed independently from both the accepted full
command and the current proved baseline command. Both constructions must agree:
use the current five-stage plan and actual predicted timing guide, remove the
sole `--no-route`, select a freshly qualifying driver candidate0, add actual RBF
output and replace only fresh output paths. No source/constraint/report-window,
router repair, pin, ordinal, BEL or placement option changes are authorized.

All five complete fresh local model records must match the positive prefix.
The first four descriptors retain the accepted original2 and additional1 ready
consumers. The new third ready copy must be the independently proved $2 owner,
with exactly six current LAB24.12 original-root ENA transfers and a site derived
from the closed fifth-stage model. The profile binds the five individual private
output-owner frames from that proof without treating their raw IDs as a global
renaming rule. Logical evidence here authorizes the experimental input only;
actual final native and physical equivalence still require separate proof.

Preparation reconstructs the actual ordinary ALUT3-source49-user arithmetic-A
edge and unique immediate CO-to-CI successor from the five-stage snapshot. The
actual current predicted guide must contain precisely that reported violated
ordinary-LUT-to-arithmetic edge. No driver candidate/site is inherited. Actual
source8-row/domain coverage, candidate0, its final preceding trial and all four
compiled timing guards must freshly match the frozen driver parser.

Whole-LAB FF closure includes every selected local primary cohort, each local
inner/outer, all three ready copies, the original driver source, arithmetic
operand and unique immediate carry successor. Their actual prefix BELs and
every original FF record in those LABs are bound before execution. The fresh
driver-copy site is dynamic; its actual old/current site and whole-LAB neighbors
must be closed by the later full physical proof. This recorder grants no BUF,
original-pin, control-set or LAB-state waiver.

Full completion requires actual HIP GPU routing, nonempty routed JSON/report/RBF,
cap16384/15,290 finite reported paths/Fmax fields, normal completion and no LAST
signoff hold/min warning or violation. It records all gain/native/physical
acceptance fields false. Reported Fmax alone does not establish a gain. The
later independent proof must establish the complete actual raw/native ledger,
physical pin/function/ALM/FF/BUF scope, all current clock windows and strict
memory gain above117.34334564208984MHz. No cache/GPU-index, independent numerical
STA, RBF decode or hardware behavior is claimed. Preparation/output paths are
exclusive, and an unqualified/failing prefix cannot activate this route.
