"""Record fresh driver candidate0/full routing only after a proved five-stage prefix."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
BASELINE = RAW / "local-multicopy-ready1-address-stage-264"
PROOF = BASELINE / "baseline/comparison-prefix.json"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "route-c0"
PREFIX_PROFILE_SHA = "a1bb561addd651de30f027006ec9e69665090d4d5bb9b8dca7f22a5b368c01dc"
PLAN_SHA = "4221d99b826ff7dfebf1e4433065e7e36749dc7087cceb61abb22048f0b9138b"
FIFTH_SHA = "a2d626253826a6b187713f42904720ecdb1d06754ab2776c1fa9d7b39437e2f4"
FIFTH_SCOPE_SHA = "b21d94fd2180981a84abb697044ca41f85051e17a04bcc66f683bfff752d7c52"
OLD = RAW / "local-multicopy-ready1-route-264/run_route.py"
OLD_SHA = "3e81198bb1c9c89c8c63144b0354138514c5c10ba5b0ef5ecd82d15e3956ccf3"
OLD_SCOPE_SHA = "6f98611a39b498b329909bff3b0d764dab10f94214ae85039528812ecdf8f414"


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure definition hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure definition original path differs")
    return module


def old_definitions():
    return load(OLD, OLD_SHA, "address_route_frozen_definitions")


def command(baseline, accepted, old):
    result = list(accepted["command"])
    require("--no-route" not in result and "--compress-rbf" not in result and
            result.count("--router") == result.count("--gpu-device") == result.count("--remap-lut-driver-candidate") == 1 and
            result[result.index("--router") + 1] == "gpu" and result[result.index("--gpu-device") + 1] == "1" and
            result[result.index("--remap-lut-driver-candidate") + 1] == "0", "accepted full selectors differ")
    predicted = list(baseline["command"])
    require(predicted[0] == str(old.COMPILER / "nextpnr-mistral") and predicted.count("--no-route") == 1 and
            not any(flag in predicted for flag in ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")),
            "proved five-stage predicted selectors differ")
    result[0] = predicted[0]
    for flag, path in (("--remap-plan", BASELINE / "local-plan.json"),
            ("--remap-lut-driver-critical", BASELINE / "baseline/timing.json"),
            ("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json"), ("--rbf", FOLDER / "core.rbf")):
        require(result.count(flag) == 1, "ambiguous full selector")
        result[result.index(flag) + 1] = str(path)
    predicted.remove("--no-route")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json")):
        require(predicted.count(flag) == 1, "ambiguous predicted selector")
        predicted[predicted.index(flag) + 1] = str(path)
    predicted += ["--remap-lut-driver-critical", str(BASELINE / "baseline/timing.json"),
                  "--remap-lut-driver-candidate", "0", "--rbf", str(FOLDER / "core.rbf")]
    require(result == predicted, "full command differs outside current compiler/five-plan/guide/outputs")
    return result


def adopt(old, inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
        old.bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "execution pathname is not absolute")
        old.bind(inputs, name, expected)


def prepare(prefix_sha, self_sha, scope_sha):
    old = old_definitions()
    require(not PROFILE.exists() and not FOLDER.exists(), "exclusive profile/route outputs already exist")
    inputs = {}
    for path, expected in ((PROOF, prefix_sha), (Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha),
            (OLD, OLD_SHA), (OLD.parent / "scope.md", OLD_SCOPE_SHA), (BASELINE / "source-identity.json", PREFIX_PROFILE_SHA),
            (BASELINE / "run_baseline.py", FIFTH_SHA), (BASELINE / "scope.md", FIFTH_SCOPE_SHA),
            (BASELINE / "local-plan.json", PLAN_SHA)):
        old.bind(inputs, path, expected)
    proof = old.read(PROOF)
    require(proof["schema"] == 1 and proof["phase"] == "local-multicopy-ready1-address-fifth-stage-conditional-native-prefix" and
            proof["compiler_commit"] == old.COMMIT and proof["delta_base_commit"] == old.BASE and
            proof["source_identity_sha256"] == PREFIX_PROFILE_SHA and proof["previous_prefix_proof_sha256"] == old.PROOF_SHA and
            proof["structural_rejection"] is None and all(proof[key] is True for key in
                ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
                 "final_original_path_metadata_and_runtime_hashes_stable")), "future five-stage prefix is not independently positive")
    adopt(old, inputs, proof)
    old.bind(inputs, BASELINE / "baseline/run.json", proof["current_baseline_run_sha256"])
    require(inputs.get(str(BASELINE / "compare_prefix.py")) == proof["generator_sha256"] and
            inputs.get(str(BASELINE / "comparison-scope.md")) == proof["scope_sha256"] and
            inputs.get(str(old.CONTROL)) == old.CONTROL_SHA and inputs.get(str(old.HOST)) == old.HOST_SHA and
            inputs.get(str(old.ACCEPTED)) == old.ACCEPTED_SHA and inputs.get(str(old.ACCEPTED_RUN)) == old.ACCEPTED_RUN_SHA,
            "positive proof/helper/control/accepted anchors absent from closure")
    identity, baseline = old.read(BASELINE / "source-identity.json"), old.read(BASELINE / "baseline/run.json")
    require(identity["phase"] == "local-multicopy-ready1-address-fifth-stage-predicted-baseline" and
            identity["helper_sha256"] == FIFTH_SHA and identity["scope_sha256"] == FIFTH_SCOPE_SHA and
            identity["previous_prefix_proof_sha256"] == old.PROOF_SHA and identity["local_plan_sha256"] == PLAN_SHA and
            identity["compiler_commit"] == baseline["compiler_commit"] == old.COMMIT and
            identity["delta_base_commit"] == baseline["delta_base_commit"] == old.BASE and
            identity["binary_sha256"] == baseline["binary_sha256"] == old.BINARY_SHA and
            identity["source_archive_sha256"] == baseline["source_archive_sha256"] == old.ARCHIVE_SHA and
            baseline["source_identity_sha256"] == PREFIX_PROFILE_SHA and baseline["completed"] is True and baseline["exit_code"] == 0 and
            baseline["compiler_read_audit_passed"] is baseline["original_four_selected_models_exact"] is True and
            baseline["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in baseline for key in ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")),
            "future actual closed five-stage compiler/run role differs")
    require(all(old.canonical(baseline[key]) == old.canonical(value) for key, value in identity.items() if key != "input_sha256") and
            baseline["input_sha256"] == {**identity["input_sha256"], str(BASELINE / "source-identity.json"): PREFIX_PROFILE_SHA} and
            all(inputs.get(path) == expected for path, expected in {**baseline["input_sha256"], **baseline["output_sha256"],
                **baseline["execution"]["files"]}.items()) and baseline["execution"] == identity["baseline_execution"] and
            baseline["cwd"] == str(MODULE) and baseline["execution"]["gpu_device"] == 1,
            "current profile-union/output/runtime closure differs")
    accepted = old.read(old.ACCEPTED_RUN)
    require(accepted["completed"] is True and accepted["exit_code"] == 0 and accepted["compiler_read_audit_passed"] is True and
            accepted["binary_sha256"] == old.OLD_BINARY_SHA and accepted["source_archive_sha256"] == old.OLD_ARCHIVE_SHA and
            accepted["compiler_commit"] == old.BASE and accepted["cwd"] == baseline["cwd"] and
            accepted["diagnostic_environment"] == baseline["diagnostic_environment"], "accepted full role differs")
    expected = copy.deepcopy(accepted["execution"])
    require(expected["files"].pop(accepted["command"][0]) == old.OLD_BINARY_SHA, "accepted executable frame differs")
    expected["files"][str(old.COMPILER / "nextpnr-mistral")] = old.BINARY_SHA
    expected["environment"]["PATH"] = str(old.COMPILER) + ":/usr/bin:/bin"
    require(expected == baseline["execution"] and inputs.get(str(old.COMPILER / "nextpnr-mistral")) == old.BINARY_SHA and
            inputs.get(str(old.COMPILER / "source.tar.gz")) == old.ARCHIVE_SHA, "current hardware/runtime changes beyond compiler/PATH")
    for name, expected in old.SCRIPTS.items():
        old.bind(inputs, MODULE / "scripts" / name, expected)
    old.bind(inputs, old.PURE, old.PURE_SHA)
    old.bind(inputs, old.LOCAL, old.LOCAL_SHA)
    fifth = load(BASELINE / "run_baseline.py", FIFTH_SHA, "address_route_fifth_log_definitions")
    parser = load(old.LOCAL, old.LOCAL_SHA, "address_route_four_log_definitions")
    models = fifth.qualification((BASELINE / "baseline/phase.log").read_text(), parser)
    require(old.canonical(models) == old.canonical(baseline["actual_selected_local_qualification"]) == old.canonical(proof["fresh_local_models"]) and
            old.canonical(models[:4]) == old.canonical(proof["previous_local_models"]) == old.canonical(identity["retained_local_models"]) and
            old.read(BASELINE / "local-plan.json")["steps"] == identity["local_plan_steps"] and len(models) == 5,
            "all fresh five guarded models/descriptors differ")
    native = load(old.PURE, old.PURE_SHA, "address_route_lossless_native")
    top = native.read_netlist(BASELINE / "baseline/placed.json")["modules"]["top"]
    graph = proof["native_graph_evidence"]
    require(graph["serialized_native_scope_proved"] is graph["all_original_ff_placements_and_nonprivate_raw_slots_exact"] is True and
            graph["new_clone"] == identity["expected_additional_copy_name"] == models[4]["outer"] + "$local_remap$2" and
            graph["declared_ena_redirect_count"] == len(graph["declared_ena_redirects"]) == models[4]["ena_users"] == 6 and
            graph["assignments_checked"] == 16 and graph["private_output_owner_count"] == len(graph["explicit_private_output_owners"]) == 5 and
            top["cells"][graph["new_clone"]]["attributes"]["NEXTPNR_BEL"] == models[4]["bel"], "proved third copy/six-ENA scope differs")
    source, sink = top["cells"][old.SOURCE], top["cells"][old.SINK]
    require(source["type"] == "MISTRAL_ALUT3" and sink["type"] == "MISTRAL_ALUT_ARITH" and
            len(source["connections"]["Q"]) == 1 and source["connections"]["Q"] == sink["connections"]["A"], "current ordinary-to-carry edge differs")
    q = source["connections"]["Q"][0]
    users = [(name, port, index) for name, cell in top["cells"].items() for port, bits in cell["connections"].items()
        if cell["port_directions"][port] == "input" for index, bit in enumerate(bits) if bit == q]
    require(type(q) is int and len(users) == 49 and (old.SINK, "A", 0) in users and
            not any(q in port["bits"] for port in top["ports"].values()), "actual original source49 boundary differs")
    carry = sink["connections"]["CO"]
    successors = [(name, cell) for name, cell in top["cells"].items() if name != old.SINK and cell["type"] == "MISTRAL_ALUT_ARITH" and
        cell["connections"].get("CI") == carry]
    require(len(carry) == 1 and type(carry[0]) is int and len(successors) == 1, "immediate carry successor is not unique")
    labs = {tuple(model["primary_lab"]) for model in models}
    owners, seen = {old.SOURCE, old.SINK, successors[0][0]}, {}
    for model in models:
        outer = model["outer"]
        occurrence = seen.get(outer, 0); seen[outer] = occurrence + 1
        name = outer + "$local_remap" + ("$" + str(occurrence) if occurrence else "")
        require(top["cells"][name]["attributes"]["NEXTPNR_BEL"] == model["bel"], "actual selected local owner/site differs")
        owners.update((model["inner"], outer, name))
    for name in owners:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared cone/source/operand/carry owner lacks a placed BEL")
        labs.add(tuple(map(int, match.groups())))
    ff_rows = []
    for name, cell in top["cells"].items():
        if cell["type"] != "MISTRAL_FF":
            continue
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", cell["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None, "original FF lacks placed BEL")
        if tuple(map(int, match.groups())) in labs:
            ff_rows.append({"cell": name, "record": cell})
    first_slots, second_slots = graph["retained_first_copy_consumers"], graph["retained_second_copy_consumers"]
    require(all(type(slot) is list and len(slot) == 4 and slot[1:] == ["ENA", 0, 0]
                for slot in first_slots + second_slots) and
            first_slots == identity["retained_first_copy_consumers"] and
            second_slots == [[row["cell"], row["port"], row["vector_index"], row["occurrence"]]
                             for row in identity["retained_second_copy_consumers"]],
            "proved retained copy slots differ from prepared five-stage cohorts")
    cohort = {row["cell"] for row in graph["declared_ena_redirects"]} | {
        slot[0] for slot in first_slots + second_slots}
    require(cohort <= {row["cell"] for row in ff_rows} and len(graph["retained_first_copy_consumers"]) == 2 and
            len(graph["retained_second_copy_consumers"]) == 1, "complete three-copy FF cohorts miss whole-LAB scope")
    report = old.read(BASELINE / "baseline/timing.json")
    relevant = set()
    for path in report["critical_paths"]:
        if math.fsum(segment["delay"] for segment in path["path"]) <= path["max_delay"]:
            continue
        for segment in path["path"]:
            if segment["type"] != "routing":
                continue
            launch, capture = segment["from"], segment["to"]
            if (top["cells"][launch["cell"]]["type"] in {"MISTRAL_ALUT" + str(width) for width in range(2, 7)} and
                    top["cells"][capture["cell"]]["type"] == "MISTRAL_ALUT_ARITH" and capture["port"] in {"A", "B", "C", "D0", "D1"}):
                relevant.add((launch["cell"], capture["cell"], capture["port"]))
    require(relevant == {(old.SOURCE, old.SINK, "A")} and report["timing_report_paths"] == 16384 and
            len(report["critical_paths"]) == 15290, "fresh current driver guide relevant edge/report differs")
    result = {"schema": 1, "phase": "local-multicopy-ready1-address-fifth-stage-fresh-driver-full-route", "compiler_commit": old.COMMIT,
        "delta_base_commit": old.BASE, "binary_sha256": old.BINARY_SHA, "source_archive_sha256": old.ARCHIVE_SHA,
        "prefix_proof_sha256": prefix_sha, "prefix_source_identity_sha256": PREFIX_PROFILE_SHA,
        "prefix_baseline_run_sha256": proof["current_baseline_run_sha256"], "prefix_generator_sha256": proof["generator_sha256"],
        "prefix_scope_sha256": proof["scope_sha256"], "local_plan_sha256": PLAN_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "host_validation_sha256": old.HOST_SHA, "control_proof_sha256": old.CONTROL_SHA,
        "accepted_full_proof_sha256": old.ACCEPTED_SHA, "accepted_full_run_sha256": old.ACCEPTED_RUN_SHA,
        "command": command(baseline, accepted, old), "cwd": baseline["cwd"], "diagnostic_environment": baseline["diagnostic_environment"],
        "baseline_execution": baseline["execution"], "input_sha256": dict(sorted(inputs.items())), "prefix_fresh_local_models": models,
        "declared_driver_edge": [old.SOURCE, old.SINK, "A"], "driver_candidate": 0, "driver_site_must_qualify_freshly": True,
        "declared_ena_redirects": graph["declared_ena_redirects"], "new_ready_clone": graph["new_clone"], "new_ready_clone_bel": models[4]["bel"],
        "retained_first_copy": graph["retained_first_copy"], "retained_first_copy_consumers": graph["retained_first_copy_consumers"],
        "retained_second_copy": graph["retained_second_copy"], "retained_second_copy_consumers": graph["retained_second_copy_consumers"],
        "prefix_private_output_owner_bijections": graph["explicit_private_output_owners"],
        "driver_current_source_record": source, "driver_current_sink_record": sink,
        "driver_current_immediate_carry_successor": {"cell": successors[0][0], "record": successors[0][1]},
        "declared_original_local_driver_and_carry_cells": sorted(owners), "affected_whole_labs": sorted(map(list, labs)),
        "all_original_ff_members_in_affected_labs": sorted(ff_rows, key=lambda row: row["cell"]),
        "actual_fresh_driver_site_neighborhood_requires_independent_full_proof": True,
        "minimum_accepted_memory_mhz": 117.34334564208984, "routed_graph_proof_available": False,
        "physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    old.finish(inputs); old.clean_source()
    with PROFILE.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"profile_sha256": old.sha(PROFILE), "inputs": len(inputs), "whole_labs": len(labs), "original_ffs": len(ff_rows)}, indent=2))


def route(profile_sha):
    old = old_definitions()
    inputs = {}
    old.bind(inputs, PROFILE, profile_sha)
    profile = old.read(PROFILE)
    for path, expected in profile["input_sha256"].items():
        old.bind(inputs, path, expected)
    baseline, accepted = old.read(BASELINE / "baseline/run.json"), old.read(old.ACCEPTED_RUN)
    require(not FOLDER.exists() and profile["compiler_commit"] == old.COMMIT and profile["command"] == command(baseline, accepted, old) and
            profile["baseline_execution"] == baseline["execution"] and profile["diagnostic_environment"] == baseline["diagnostic_environment"] and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"],
            "frozen exclusive full-route role differs")
    old.clean_source()
    fifth = load(BASELINE / "run_baseline.py", FIFTH_SHA, "address_full_fifth_log_definitions")
    parser = load(old.LOCAL, old.LOCAL_SHA, "address_full_four_log_definitions")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in old.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(inputs.get(str(MODULE / "scripts" / name)) == expected and
                Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and old.sha(loaded.__file__) == expected,
                "executed project dependency differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(Path(profile["command"][0]),
        f"base_commit={old.BASE}; experimental_source_sha256={old.ARCHIVE_SHA}; sha256={old.BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs,
        "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env),
                "actual hardware/runtime/ambient diagnostics changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            result = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = result.returncode, True
        invocation.verify()
        require(result.returncode == 0, "actual five-stage full compiler failed")
        log = (FOLDER / "route.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                "Running the GPU router" in log and "Running signoff timing analysis..." in log and
                "Running predicted placed timing analysis for --report" not in log, "full GPU/RBF signoff provenance absent")
        models = fifth.qualification(log, parser)
        require(old.canonical(models) == old.canonical(profile["prefix_fresh_local_models"]), "actual five local model records differ from positive prefix")
        record["actual_selected_local_qualification"] = models
        record["actual_fresh_driver_qualification"] = old.qualification(log)
        report = old.read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()),
                "actual full timing cap/count/Fmax differs")
        record["fmax"], record["actual_live_gpu_backend"] = report["fmax"], board._require_gpu_backend(log)
        require(record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log), "actual HIP completion absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        record["final_reported_hold_violations"] = "Hold/min time violation" in last
        record["last_signoff_hold_warning_lines"] = [line for line in last.splitlines() if
            re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not record["final_reported_hold_violations"] and not record["last_signoff_hold_warning_lines"], "LAST signoff hold/min violation")
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual full output absent")
            record["output_sha256"][str(path)] = old.sha(path)
        old.finish({**inputs, **record["output_sha256"]}); old.clean_source()
        record["completed"] = True
        print(json.dumps({"completed": True, "fmax": record["fmax"], "driver": record["actual_fresh_driver_qualification"], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): old.sha(FOLDER / name) for name in
                        ("route.log", "routed.json", "timing.json", "core.rbf") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); old.finish({**inputs, **record.get("output_sha256", {})}); old.clean_source()
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False
                    record["final_original_input_output_runtime_hashes_stable"] = False
                    record["final_rehash_failure"] = repr(error)
                    raise
                finally:
                    (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "route"))
    for name in ("prefix-sha256", "self-sha256", "scope-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(args.prefix_sha256 and args.self_sha256 and args.scope_sha256, "actual positive prefix/helper/scope pins required")
        prepare(args.prefix_sha256, args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256, "before-run full profile activation pin required")
        route(args.profile_sha256)


if __name__ == "__main__":
    main()
