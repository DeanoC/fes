"""Record a fresh driver/full route after a positive late DDR0 errors prefix."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
LATE = RAW / "post-remap-plan-ddr0-errors-stage-264"
LATE_PROFILE_SHA = "0e74e43ec78af51766d1b681c0727222f24ff3bc7635efdbb47e7c9da948b063"
LATE_RUN_SHA = "48ae5d992e2c4c966c671c741a45126aeb068e059e8c5279d8eb28e8287ba560"
PREFIX_PROOF_SHA = "459f3880009f37cbab05d13332bea503c9c347c924b3880d7dbb8db012741636"
LATE_HELPER_SHA = "3bf57664d00c97120bf900dac76d35136f5656f5ca5d2364fc386511b4f50008"
LATE_SCOPE_SHA = "6360afec6b94dee7e6e15635a926db14383069483c0a5b9b66d82292a41b2fbb"
PREFIX_HELPER_SHA = "25c049cb377c69a2d739892509a07032c96f2781eeec6c47e2b9b9bff1bd9e77"
PREFIX_SCOPE_SHA = "00d66d06b6bfc166da37d50522a5297cf91322194c1ef22129095b08e00d5c31"
POST_PLAN_SHA = "b3ad7db8d95fbc0f2704d2050b546ccf090bc4cb5ebafef66e3960c0d70f7bd5"
CONTROL = RAW / "post-remap-plan-ten-control-264"
CONTROL_PROFILE_SHA = "2294abbbadb2d74df4657344f841a2dcbaaf57854e33d7484a5e3e7841f9ab06"
CONTROL_RUN_SHA = "3eb274cc9d2d2a40ba348e35b0055b14f0d39edc035ac8c49b8dc7da13b27dee"
CONTROL_PROOF_SHA = "323846d51ef9c76047ba243f55d7505395fcb793dab4b32dd963f56c72b0a746"
COMPILER = RAW / "post-remap-plan-264"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-post-remap-plan-264"
COMMIT, BASE = "b3d036549c29a333e67c61bd1b23e705bce75d41", "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA = "0c8805598c4e59ad77683956cdc1739b8d2ed183c73eab51c85c9b7a52ea18ad"
ARCHIVE_SHA = "338f71f67188fa29dbb9f6fa616f6d33f4bc926b3acd00bfb5122ef543a8c2fb"
HOST, HOST_SHA = COMPILER / "validation/host-validation.json", "3751b2ebc0c0f802ac2b4251150a693764487939c0b08e42fe100c2047eb6fe0"
OLD = RAW / "local-plan16-ready1-command-route-264"
OLD_PROFILE_SHA = "ea03398546c1a1c8f9f099d0ed6ce4b156661d3276e0ec2057c7f09e563fe305"
OLD_RUN_SHA = "1a6d4f7b8efcc1e22c3af4c73b07a6fcfe609ce9ee07cc36c6d618a40c699428"
OLD_PROOF = RAW / "local-plan16-ready1-command-route-proof-264/comparison-v2.json"
OLD_PROOF_SHA = "cd8ad7ff8fd40b7136ff265d645806e3d661cde186b3da819975658040b8f74a"
OLD_BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
EARLY_PLAN = RAW / "local-plan16-ready1-command-stage-264/local-plan.json"
EARLY_PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
ACCEPTED_RUN = RAW / "local-multicopy-ready1-address-route-264/route-c0/run.json"
ACCEPTED_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
DRIVER = RAW / "local-multicopy-ready1-route-264/run_route.py"
DRIVER_SHA = "3e81198bb1c9c89c8c63144b0354138514c5c10ba5b0ef5ecd82d15e3956ccf3"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "route-c0"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
CHANGED = {"mistral/arch.h", "mistral/arch.cc", "mistral/lut_driver_copy.h", "mistral/lut_driver_copy.cc", "mistral/main.cc",
    "mistral/remap_plan.cc", "mistral/tests/remap_plan.cc", "mistral/tests/remap_plan_cli.py", "mistral/remap_plan.md"}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original pathname hash")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute"); bind(inputs, name, expected)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def definitions():
    late = load(LATE / "run_baseline.py", LATE_HELPER_SHA, "late_errors_route_local_pure")
    driver = load(DRIVER, DRIVER_SHA, "late_errors_route_driver_pure")
    return late, late.definitions(), driver


def qualification(log, definitions):
    late, local_definitions, driver = definitions
    boundary = list(re.finditer(r"^Info: LUT driver copy discovery: (\d+) bounded data edges\.$", log, re.M))
    require(len(boundary) == 1 and boundary[0][1] == "1", "fresh actual driver phase header is not unique")
    early, post = late.qualification(log[:boundary[0].start()], local_definitions)
    trial = driver.qualification(log[boundary[0].start():])
    require(trial["domain_summary"] == ["334", "331", "3", "331", "1"], "fresh complete driver domain classification differs")
    applied = list(re.finditer(r"^Info: LUT driver copy applied candidate 0; full routing and signoff still required\.$", log, re.M))
    gpu = list(re.finditer(r"^Info: Running the GPU router\.\.\.$", log, re.M))
    signoff = list(re.finditer(r"^Info: Running signoff timing analysis\.\.\.$", log, re.M))
    normal = list(re.finditer(r"^Info: Program finished normally\.$", log, re.M))
    require(len(applied) == len(normal) == 1 and gpu and signoff and
        boundary[0].start() < applied[0].start() < gpu[0].start() < signoff[-1].start() < normal[0].start(),
        "actual post-to-driver-to-GPU-to-final-signoff order differs")
    return early, post, trial


def command(baseline, old_full):
    result = list(baseline["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == result.count("--remap-plan") == result.count("--remap-post-plan") == 1 and
        result[result.index("--remap-plan") + 1] == str(EARLY_PLAN) and result[result.index("--remap-post-plan") + 1] == str(LATE / "post-plan.json") and
        not any(flag in result for flag in ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "closed late predicted command selectors differ")
    result.remove("--no-route")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous actual output selector"); result[result.index(flag) + 1] = str(path)
    result += ["--remap-lut-driver-critical", str(LATE / "baseline/timing.json"), "--remap-lut-driver-candidate", "0", "--rbf", str(FOLDER / "core.rbf")]
    expected = list(old_full["command"]); expected[0] = str(BINARY)
    require("--no-route" not in expected and "--remap-post-plan" not in expected and "--compress-rbf" not in expected and
        expected.count("--router") == expected.count("--gpu-device") == expected.count("--remap-lut-driver-candidate") == 1 and
        expected[expected.index("--router") + 1] == "gpu" and expected[expected.index("--gpu-device") + 1] == "1" and
        expected[expected.index("--remap-lut-driver-candidate") + 1] == "0", "old actual full command selectors differ")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json"),
        ("--remap-lut-driver-critical", LATE / "baseline/timing.json"), ("--rbf", FOLDER / "core.rbf")):
        require(expected.count(flag) == 1, "ambiguous old full selector"); expected[expected.index(flag) + 1] = str(path)
    position = expected.index("--remap-lut-driver-critical"); expected[position:position] = ["--remap-post-plan", str(LATE / "post-plan.json")]
    require(result == expected, "full command differs outside ELF/late plan/fresh driver guide/output aliases")
    return result


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == CHANGED,
        "current compiler is not the clean committed host source")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + [(SOURCE / name, value) for name, value in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def prepare(self_sha, scope_sha, run_sha, prefix_sha):
    require(all(type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) and value != "0" * 64 for value in
        (self_sha, scope_sha, run_sha, prefix_sha)) and run_sha == LATE_RUN_SHA and prefix_sha == PREFIX_PROOF_SHA and
        not PROFILE.exists() and not FOLDER.exists(), "actual closed pins and exclusive full outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (LATE / "source-identity.json", LATE_PROFILE_SHA),
        (LATE / "baseline/run.json", run_sha), (LATE / "baseline/comparison-prefix.json", prefix_sha), (LATE / "run_baseline.py", LATE_HELPER_SHA),
        (LATE / "scope.md", LATE_SCOPE_SHA), (LATE / "compare_prefix.py", PREFIX_HELPER_SHA), (LATE / "prefix-scope.md", PREFIX_SCOPE_SHA),
        (LATE / "post-plan.json", POST_PLAN_SHA), (EARLY_PLAN, EARLY_PLAN_SHA), (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA), (HOST, HOST_SHA),
        (OLD / "source-identity.json", OLD_PROFILE_SHA), (OLD / "route-c0/run.json", OLD_RUN_SHA), (OLD_PROOF, OLD_PROOF_SHA),
        (ACCEPTED, ACCEPTED_SHA), (ACCEPTED_RUN, ACCEPTED_RUN_SHA), (DRIVER, DRIVER_SHA), (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        bind(inputs, path, expected)
    original, baseline, proof, host, old_full, old_proof, accepted, accepted_run = (read(path) for path in
        (LATE / "source-identity.json", LATE / "baseline/run.json", LATE / "baseline/comparison-prefix.json", HOST,
         OLD / "route-c0/run.json", OLD_PROOF, ACCEPTED, ACCEPTED_RUN))
    require(proof["phase"] == "post-remap-plan-ddr0-errors-ena-eleventh-stage-strict-native-prefix" and proof["source_identity_sha256"] == LATE_PROFILE_SHA and
        proof["current_baseline_run_sha256"] == run_sha and proof["compiler_commit"] == COMMIT and proof["delta_base_commit"] == BASE and
        proof["generator_sha256"] == PREFIX_HELPER_SHA and proof["scope_sha256"] == PREFIX_SCOPE_SHA and proof["runner_sha256"] == LATE_HELPER_SHA and
        proof["runner_scope_sha256"] == LATE_SCOPE_SHA and proof["control_profile_sha256"] == CONTROL_PROFILE_SHA and proof["control_run_sha256"] == CONTROL_RUN_SHA and
        proof["control_proof_sha256"] == CONTROL_PROOF_SHA and proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and
        all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
            "all_ten_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "final_original_path_metadata_and_runtime_hashes_stable")), "actual late prefix is not complete and positive")
    require(baseline["completed"] is True and baseline["exit_code"] == 0 and baseline["compiler_read_audit_passed"] is baseline["final_original_input_output_runtime_hashes_stable"] is True and
        baseline["source_identity_sha256"] == LATE_PROFILE_SHA and baseline["compiler_commit"] == COMMIT and baseline["delta_base_commit"] == BASE and
        baseline["binary_sha256"] == BINARY_SHA and baseline["source_archive_sha256"] == ARCHIVE_SHA and baseline["host_validation_sha256"] == HOST_SHA and
        baseline["execution"] == original["baseline_execution"] and baseline["input_sha256"] == {**original["input_sha256"], str(LATE / "source-identity.json"): LATE_PROFILE_SHA} and
        all(canonical(baseline[key]) == canonical(value) for key, value in original.items() if key != "input_sha256") and
        not any(key in baseline for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "closed late profile/run/current runtime differs")
    for manifest in (proof, old_proof, accepted): adopt(inputs, manifest)
    for ledger in (baseline["input_sha256"], baseline["output_sha256"], baseline["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "flat host/input/runtime pathname is not absolute"); bind(inputs, path, expected)
    require(host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and host["binary_sha256"] == BINARY_SHA and
        host["source_archive_sha256"] == ARCHIVE_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        {key: row["cases"] for key, row in host["checks"].items()} == {"native_plan": 25, "driver_backend": 10, "remap_plan_cli": 24, "driver_cli": 10} and
        all(row["passed"] is True and row["exit_code"] == 0 for row in host["checks"].values()), "current host/source/checks differ")
    require(old_proof["structural_rejection"] is None and old_proof["native_graph_proof_available"] is old_proof["physical_scope_proved"] is True and
        old_proof["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and old_proof["current_full_run_sha256"] == OLD_RUN_SHA and
        old_proof["source_identity_sha256"] == OLD_PROFILE_SHA and old_full["completed"] is True and old_full["exit_code"] == 0 and
        old_full["compiler_read_audit_passed"] is old_full["final_original_input_output_runtime_hashes_stable"] is True and old_full["source_identity_sha256"] == OLD_PROFILE_SHA and
        old_full["compiler_commit"] == BASE and old_full["binary_sha256"] == OLD_BINARY_SHA and old_full["cwd"] == baseline["cwd"] == str(MODULE) and
        old_full["diagnostic_environment"] == baseline["diagnostic_environment"] and accepted["structural_rejection"] is None and
        accepted["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and accepted_run["completed"] is True and
        accepted_run["fmax"]["ram_clock.clocks[0]"]["achieved"] == 117.77175903320312, "old rejected construction or accepted fifth timing roles differ")
    runtime = copy.deepcopy(old_full["execution"])
    require(runtime["files"].pop(old_full["command"][0]) == OLD_BINARY_SHA and str(BINARY) not in runtime["files"] and
        runtime["environment"]["PATH"] == str(Path(old_full["command"][0]).parent) + ":/usr/bin:/bin", "old full compiler/PATH frame differs")
    runtime["files"][str(BINARY)] = BINARY_SHA; runtime["files"] = dict(sorted(runtime["files"].items()))
    runtime["environment"]["PATH"] = str(BINARY.parent) + ":/usr/bin:/bin"
    require(runtime == baseline["execution"], "current full runtime differs outside compiler ELF and controlled PATH")
    late, local_defs, driver = definitions(); control, _ = local_defs
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    for name, expected in control.SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    early, post = late.qualification((LATE / "baseline/phase.log").read_text(), local_defs); models = early + post
    require(canonical(models) == canonical(proof["fresh_local_models"]) == canonical(baseline["actual_selected_local_qualification"]) and
        canonical(early) == canonical(baseline["actual_early_selected_local_qualification"]) and canonical(post) == canonical(baseline["actual_post_selected_local_qualification"]),
        "actual closed early10/post0 models differ")
    require(original["original_ten_plan_path"] == str(EARLY_PLAN) and original["original_ten_plan_sha256"] == EARLY_PLAN_SHA and
        read(EARLY_PLAN) == {"steps": original["local_plan_steps"]} and len(original["local_plan_steps"]) == 10 and
        original["post_plan_path"] == str(LATE / "post-plan.json") and original["post_plan_sha256"] == POST_PLAN_SHA and
        read(original["post_plan_path"]) == {"steps": original["post_plan_steps"]} and len(original["post_plan_steps"]) == 1 and original["combined_requested_step_count"] == 11,
        "literal ten early and sole late descriptor differ")
    native = load(NATIVE, NATIVE_SHA, "late_errors_route_native_pure")
    frozen = load(FREEZE, FREEZE_SHA, "late_errors_route_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "late_errors_route_tables_pure", frozen)
    top = native.read_netlist(LATE / "baseline/placed.json")["modules"]["top"]
    drivers, users = selected.native_tables(top); graph = proof["native_graph_evidence"]
    require(graph["serialized_native_scope_proved"] is True and graph["assignments_checked"] == 64 and graph["declared_ena_redirect_count"] == 8 and
        len(graph["declared_ena_redirects"]) == 8 and graph["original_root_users_before"] == 32 and graph["original_root_users_after"] == 24 and
        graph["original_inner_q_and_all161_consumers_exact"] is True and graph["private_output_frame_alignment_used"] is False,
        "positive late local clone/whole cohort/side-user scope differs")
    source, sink = top["cells"][driver.SOURCE], top["cells"][driver.SINK]
    require(source["type"] == "MISTRAL_ALUT3" and set(source["parameters"]) == {"LUT"} and
        re.fullmatch("[01]{8}", source["parameters"]["LUT"]) and sink["type"] == "MISTRAL_ALUT_ARITH" and
        source["connections"]["Q"] == sink["connections"]["A"] and len(source["connections"]["Q"]) == 1,
        "current native driver source eight-row/operand edge differs")
    q = source["connections"]["Q"][0]
    require(type(q) is int and drivers[q] == [(driver.SOURCE, "Q", 0, 0)] and len(users[q]) == 49 and (driver.SINK, "A", 0, 0) in users[q] and
        not any(q in port["bits"] for port in top["ports"].values()), "actual source Q49 users/public boundary differs")
    carry = sink["connections"]["CO"]
    successors = [name for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_ALUT_ARITH" and cell["connections"].get("CI") == carry and name != driver.SINK]
    require(len(carry) == 1 and type(carry[0]) is int and len(successors) == 1, "immediate carry successor is not unique")
    names = {driver.SOURCE, driver.SINK, successors[0], graph["new_clone"]}
    names.update(row["cell"] for row in graph["retained_copy_cohorts"])
    names.update(row["cell"] for row in graph["declared_ena_redirects"])
    names.update(slot[0] for row in graph["retained_copy_cohorts"] for slot in row["consumer_slots"])
    for model in models: names.update((model["inner"], model["outer"]))
    labs = {tuple(model["primary_lab"]) for model in models}
    for name in names:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared original local/driver/carry owner lacks placed BEL"); labs.add(tuple(map(int, match.groups())))
    ff_bels, ff_rows = {}, []
    for name, cell in top["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", cell["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None, "original FF lacks placed BEL"); ff_bels[name] = cell["attributes"]["NEXTPNR_BEL"]
        if tuple(map(int, match.groups())) in labs: ff_rows.append({"cell": name, "record": cell})
    require(len(ff_bels) == 8221 and ff_bels == original["all_original_ff_bel_manifest"], "all original FF BEL declaration differs")
    report = read(LATE / "baseline/timing.json"); relevant = set()
    for path in report["critical_paths"]:
        if math.fsum(segment["delay"] for segment in path["path"]) <= path["max_delay"]: continue
        for segment in path["path"]:
            if segment["type"] != "routing": continue
            launch, capture = segment["from"], segment["to"]
            if (top["cells"][launch["cell"]]["type"] in {"MISTRAL_ALUT" + str(width) for width in range(2, 7)} and
                top["cells"][capture["cell"]]["type"] == "MISTRAL_ALUT_ARITH" and capture["port"] in {"A", "B", "C", "D0", "D1"}):
                relevant.add((launch["cell"], capture["cell"], capture["port"]))
    require(relevant == {(driver.SOURCE, driver.SINK, "A")} and report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290,
        "actual fresh driver guide relevant edge/report differs")
    profile = {"schema": 1, "phase": "post-remap-plan-ddr0-errors-late-fresh-driver-full-route", "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "prefix_proof_sha256": prefix_sha, "prefix_source_identity_sha256": LATE_PROFILE_SHA, "prefix_baseline_run_sha256": run_sha,
        "prefix_generator_sha256": PREFIX_HELPER_SHA, "prefix_scope_sha256": PREFIX_SCOPE_SHA,
        "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": CONTROL_RUN_SHA, "control_proof_sha256": CONTROL_PROOF_SHA,
        "experimental_current_full_proof_sha256": OLD_PROOF_SHA, "experimental_current_full_run_sha256": OLD_RUN_SHA,
        "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": ACCEPTED_RUN_SHA, "minimum_accepted_memory_mhz": 117.77175903320312,
        "original_ten_plan_path": str(EARLY_PLAN), "original_ten_plan_sha256": EARLY_PLAN_SHA, "local_plan_steps": original["local_plan_steps"],
        "post_plan_path": original["post_plan_path"], "post_plan_sha256": POST_PLAN_SHA, "post_plan_steps": original["post_plan_steps"], "combined_requested_step_count": 11,
        "prefix_fresh_local_models": models, "prefix_fresh_early_local_models": early, "prefix_fresh_post_local_models": post,
        "prefix_native_graph_evidence": graph, "retained_copy_cohorts": graph["retained_copy_cohorts"], "new_local_clone": graph["new_clone"],
        "new_local_clone_record": graph["actual_new_clone_record"], "declared_ena_redirects": graph["declared_ena_redirects"],
        "declared_driver_edge": [driver.SOURCE, driver.SINK, "A"], "driver_candidate": 0, "driver_site_must_qualify_freshly": True,
        "driver_current_source_record": source, "driver_current_sink_record": sink,
        "driver_current_immediate_carry_successor": {"cell": successors[0], "record": top["cells"][successors[0]]},
        "declared_original_local_driver_and_carry_cells": sorted(names), "affected_whole_labs": sorted(map(list, labs)),
        "all_original_ff_members_in_affected_labs": sorted(ff_rows, key=lambda row: row["cell"]), "all_original_ff_bel_manifest": dict(sorted(ff_bels.items())),
        "command": command(baseline, old_full), "cwd": baseline["cwd"], "diagnostic_environment": baseline["diagnostic_environment"], "baseline_execution": baseline["execution"],
        "input_sha256": dict(sorted(inputs.items())), "routed_graph_proof_available": False, "physical_equivalence_independently_proved": False,
        "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "whole_labs": len(labs), "original_ffs": len(ff_rows)}, indent=2))


def route(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, baseline, old_full, host = read(PROFILE), read(LATE / "baseline/run.json"), read(OLD / "route-c0/run.json"), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    require(not FOLDER.exists() and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
        inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
        inputs[str(LATE / "source-identity.json")] == profile["prefix_source_identity_sha256"] == LATE_PROFILE_SHA and
        inputs[str(LATE / "baseline/run.json")] == profile["prefix_baseline_run_sha256"] == LATE_RUN_SHA and
        inputs[str(LATE / "baseline/comparison-prefix.json")] == profile["prefix_proof_sha256"] == PREFIX_PROOF_SHA and
        inputs[str(BINARY)] == profile["binary_sha256"] == BINARY_SHA and inputs[str(ARCHIVE)] == profile["source_archive_sha256"] == ARCHIVE_SHA and
        inputs[str(HOST)] == profile["host_validation_sha256"] == HOST_SHA and inputs[str(LATE / "post-plan.json")] == profile["post_plan_sha256"] == POST_PLAN_SHA and
        profile["command"] == command(baseline, old_full) and profile["baseline_execution"] == baseline["execution"] and
        profile["diagnostic_environment"] == baseline["diagnostic_environment"] and profile["cwd"] == baseline["cwd"] == str(MODULE), "frozen full helper/profile/current command/runtime differs")
    modules = definitions(); late, local_defs, _ = modules; control, _ = local_defs; clean_source(host)
    native = load(NATIVE, NATIVE_SHA, "late_errors_full_native_pure")
    frozen = load(FREEZE, FREEZE_SHA, "late_errors_full_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "late_errors_full_topology_pure", frozen)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in control.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded current project module differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual runtime/ambient diagnostics differ")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "full late selected route did not complete")
        log = (FOLDER / "route.log").read_text()
        require(not any(line.startswith("ERROR:") for line in log.splitlines()) and "Running predicted placed timing analysis for --report" not in log,
            "full route has errors or a predicted-only report")
        early, post, trial = qualification(log, modules)
        require(canonical(early + post) == canonical(profile["prefix_fresh_local_models"]) and canonical(early) == canonical(profile["prefix_fresh_early_local_models"]) and
            canonical(post) == canonical(profile["prefix_fresh_post_local_models"]), "fresh full early/post models differ from the positive prefix")
        record.update({"actual_selected_local_qualification": early + post, "actual_early_selected_local_qualification": early,
            "actual_post_selected_local_qualification": post, "actual_fresh_driver_qualification": trial, "all_eleven_complete_local_models_exact": True,
            "actual_post_driver_gpu_signoff_order_bound": True})
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "full report cap/count/Fmax invalid")
        record["fmax"] = report["fmax"]
        topology = selected.report_topology(native.read_netlist(FOLDER / "routed.json"), report, read(LATE / "baseline/timing.json"))
        require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7, "full native report seven-pair coverage differs")
        record["actual_current_native_report_topology"] = topology
        record["actual_live_gpu_backend"] = board._require_gpu_backend(log)
        require(record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log), "actual completed HIP routing backend absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        record["final_reported_hold_violations"] = "Hold/min time violation" in last
        record["last_signoff_hold_warning_lines"] = [line for line in last.splitlines() if
            re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not record["final_reported_hold_violations"] and not record["last_signoff_hold_warning_lines"], "LAST signoff contains a hold/min warning or violation")
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "full output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "fmax": record["fmax"], "driver": trial, "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); finish({**inputs, **record.get("output_sha256", {})}); clean_source(host)
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False; record["final_original_input_output_runtime_hashes_stable"] = False; record["final_rehash_failure"] = repr(error)
                    raise
                finally: (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "route"))
    for name in ("self-sha256", "scope-sha256", "run-sha256", "prefix-proof-sha256", "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.run_sha256, args.prefix_proof_sha256)
        require(all(values), "actual preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared full profile activation pin missing"); route(args.profile_sha256)


if __name__ == "__main__": main()
