# Fresh late-errors full-route recorder

ROOT alone prepares and runs this new experiment after whole-file, hash, AST and
independent peer review. Preparation requires actual self/scope hashes, the closed
late predicted run hash and its positive strict-prefix hash. The prepared profile
hash activates routing. No unknown qualification, run, proof, Q or site is guessed.
Source-identity and route-c0 outputs are exclusive; failures preserve partial
outputs, real compiler exit or a labelled adapter sentinel and final rehash status.

The current compiler is committed b3d03654 based on d7e5c61f, frozen ELF0c880559,
archive338f71f6 and host3751b2eb. Current25 plan/10 driver native and24 plan/10
driver CLI checks are bound to their own source/archive/dependency closure.
Current source, child/model repositories, original inputs and runtime files are
checked before/after operations. No old build/runtime, physical or gain acceptance
is inherited. Old generators, authenticators, comparisons, validators and main
entrypoints are never invoked.

The immediate source is the actual late profile0e74/post-planb3ad, whose completed
run and independently positive strict native prefix must be supplied. Its fresh
ten-stage disabled-post control2294/run3eb274/proof323846 remains bound. The literal
ten early descriptors and00bf pathname stay exact; the single errors post-plan
step0 also stays exact. The full command is derived from that actual late predicted
command by removing its sole --no-route, replacing write/report aliases, and adding
fresh driver candidate0 with the actual late timing report plus an RBF output.
It is independently checked against the completed old10 full command1a6d4f7b:
only compiler ELF, late post-plan, fresh driver guide and output aliases differ.
Controlled PATH changes with the ELF; every other execution field/file, GPU1,
device, constraints, seed, existing passes and diagnostic environment stays exact.

Old10 cd8ad7ff/1a6d4f7b is native/physical-positive rejected116.809 MHz construction.
Accepted fifth6dcf8c4b/5ed3c077 is the separate117.771759 MHz strict gain reference.
Neither the failed early errors attempt nor a completed late predicted trial
supplies full acceptance. Their original flat closures remain byte provenance.
Preparation rehashes all flat current prefix/host/control/runtime/old construction
and accepted-reference maps, including the exact pure helper dependencies.

Only the pinned current late recorder's pure definitions/qualification methods,
the explicit ten-stage parser chain, frozen3e81198 driver's qualification and
source/sink constants,32fd lossless parser and72131 native tables/report topology
with8601's local import hook are reused. No prior prepare/run/auth/source validation
or high-level proof/evaluator is called. Executed project runtime imports and their
direct dependencies are byte/path bound before import and checked after loading.

The full original log is preserved. Its sole actual driver discovery header is
the boundary for early10/post1 parsing, since the predicted parser excludes a
following driver. All eleven complete model dictionaries, including prior rejected
probes, must match the positive prefix canonically. The actual post application
precedes driver discovery/application, which precedes the first GPU router and
LAST final signoff before normal completion. The driver independently qualifies
candidate0 through its final preceding guarded trial, source49 users/eight table
rows, domain coverage334 endpoints/331 timed/3 unrelated/331 hold/reference-free1,
minimum250 ps gain and all four compiled guards true. Its actual BEL is dynamic.
This count/flag evidence does not independently recompute per-pair numerical STA.

Preparation records the actual late clone/eight ENAs, all ten retained copy cohorts,
complete original source/operand/immediate carry successor, all8221 FF BELs and
every original FF record in the known local/driver/carry LAB union. The freshly
selected driver's actual LAB/ALM neighbors must be added by the later full proof.
No pre-route pin or physical function claim is made from this scope ledger.

The full actual report must contain15290 paths under cap16384 and seven actual
clock pairs. Pure topology checks bind every current native path, clock, finite
segment, endpoint/window set and constraint to the current routed image and own
late predicted report; numerical delays are the compiler's report, not independent
STA. Actual Fmax and HIP backend/completion are recorded. The LAST signoff has
zero hold/min violations and no broader hold/min warnings. Output hashes include
the actual RBF, routed JSON, report and full log, with original-path revalidation.

The recorder always labels native/physical equivalence, routed gain and hardware
acceptance unproved. A separate full proof must close original native slots and
owner frames, actual LUT/pin/shared-bank/FF/carry truth, all seven windows and six
positive non-target headrooms, LAST holds and memory strictly above117.771759 MHz.
There is no numerical calibration, RBF/CRAM decoding, cache or hardware claim.
