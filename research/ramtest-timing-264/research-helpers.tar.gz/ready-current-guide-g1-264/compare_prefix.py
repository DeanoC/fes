"""Bounded current-guide prefix proof; no full routed/physical acceptance."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
PROFILE_SHA = "74ae1b7b030ff00dcd42eabb111318f270c6ee1d3d75f93060385815ce2877d2"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
RUNNER_SHA = "a60a526a7a92a883936e081b109061e2252cbbc3b4685e682ff3020bc494c9ed"
RUNNER_SCOPE_SHA = "2091a81b5beb58cefd25be5829401044ee3a4b73ca620f6f6c9540ae4679a658"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module pin/name differs")
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    if frozen is not None:
        def local_import(module, globals=None, locals=None, fromlist=(), level=0):
            return frozen if module == "freeze" and level == 0 else builtins.__import__(module, globals, locals, fromlist, level)
        value.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = value
    exec(compile(data, str(path), "exec"), value.__dict__)
    return value


def compare(self_sha, scope_sha, graph_sha, graph_scope_sha):
    native = load(NATIVE, NATIVE_SHA, "g1_prefix_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha),
                           (HERE / "native_scope.py", graph_sha), (HERE / "native-scope.md", graph_scope_sha),
                           (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (SELECTED.parent / "freeze.py", FREEZE_SHA),
                           (HERE / "run_baseline.py", RUNNER_SHA), (HERE / "scope.md", RUNNER_SCOPE_SHA),
                           (HERE / "source-identity.json", PROFILE_SHA)):
        audit.bind(path, expected)
    profile = native.read(HERE / "source-identity.json")
    for path, expected in profile["input_sha256"].items():
        audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    audit.bind(HERE / "baseline/run.json")
    record = native.read(HERE / "baseline/run.json")
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["source_identity_sha256"] == PROFILE_SHA and record["execution"] == profile["baseline_execution"] and
            all(record[key] == value for key, value in profile.items() if key != "input_sha256") and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): PROFILE_SHA} and
            "failure" not in record and "exit_code_is_adapter_sentinel" not in record, "actual closed prefix/profile/runtime differs")
    for path, expected in record["execution"]["files"].items():
        audit.bind(Path(path), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in
            ("phase.log", "placed.json", "timing.json")}, "actual predicted output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "empty actual predicted output")
        audit.bind(Path(path), expected)
    runner = load(HERE / "run_baseline.py", RUNNER_SHA, "g1_prefix_recorder_pure")
    old = native.read(runner.OLD)
    require(audit.paths.get(runner.OLD) == runner.OLD_SHA and profile["command"] == runner.command(old), "closed original baseline command differs")
    old_log, log = (runner.OLD.parent / "phase.log").read_text(), (HERE / "baseline/phase.log").read_text()
    old_models, models = runner.local_qualification(old_log), runner.local_qualification(log)
    require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]), "actual fresh local model record differs")
    frozen = load(SELECTED.parent / "freeze.py", FREEZE_SHA, "g1_prefix_frozen_pure")
    selected = load(SELECTED, SELECTED_SHA, "g1_prefix_selected_pure", frozen)
    graph = load(HERE / "native_scope.py", graph_sha, "g1_prefix_graph_pure")
    old_graph_models = [{key: model[key] for key in graph.MODEL_KEYS} for model in old_models]
    graph_models = [{key: model[key] for key in graph.MODEL_KEYS} for model in models]
    before, after = native.read_netlist(runner.OLD.parent / "placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    evidence, rejection = None, None
    try:
        require(native.PLACEMENT_METRICS.findall(old_log) == native.PLACEMENT_METRICS.findall(log) and
                len(native.PLACEMENT_METRICS.findall(log)) == 71, "original placement metrics differ")
        evidence = graph.prove(native, selected, before, after, old_graph_models, graph_models)
    except (ValueError, TypeError, KeyError) as error:
        rejection = str(error)
    report = native.read(HERE / "baseline/timing.json")
    topology = selected.report_topology(after, report, native.read(runner.OLD.parent / "timing.json"))
    require(record["actual_predicted_fmax"] == report["fmax"] and
            "Info: Program finished normally." in log and not any(text in log for text in
            ("Running the GPU router", "Running signoff timing analysis...", "Info: LUT driver copy")), "actual report/no-route role differs")
    audit.finish()
    return {"schema": 1, "phase": "current-guide-g1-bounded-native-prefix", "source_identity_sha256": PROFILE_SHA,
            "compiler_commit": profile["compiler_commit"], "generator_sha256": self_sha, "scope_sha256": scope_sha,
            "native_scope_sha256": graph_sha, "native_scope_document_sha256": graph_scope_sha,
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"], "old_local_models": old_models,
            "fresh_local_models": models, "native_graph_proof_available": rejection is None, "structural_rejection": rejection,
            "native_graph_evidence": evidence, "current_predicted_native_paths": topology,
            "fresh_driver_guide_available_after_conditional_prefix_proof": rejection is None,
            "independent_physical_equivalence_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "native-scope-sha256", "native-scope-document-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    output = HERE / "baseline/comparison.json"
    require(not output.exists(), "immutable prefix comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.native_scope_sha256, args.native_scope_document_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
                      "structural_rejection": result["structural_rejection"], "routed_gain_accepted": False}, indent=2))


if __name__ == "__main__":
    main()
