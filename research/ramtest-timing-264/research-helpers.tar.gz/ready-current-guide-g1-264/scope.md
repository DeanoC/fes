# Fresh current-ready guide, one whole LAB

Root alone prepares and executes this predicted baseline. The finalized
accepted a4a91235 proof and actual ready-guide derivation2519b49d are read as
closed flat evidence; their original artifact and historical external hashes
are rebound once and finally rehashed. No old generator or recursive source,
profile or graph authenticator is executed. The new helper, scope, exact
guide428a4af0, derived plan and immutable profile are bound separately.
Historical compile inputs and runtime hashes remain provenance; the actual
current runtime snapshot is exactly the old driver-domains baseline snapshot.

The existing driver-domains compiler path, binary2ebe29ca, source840e7a44,
commit5dd69a8d and base9dc3633a remain unchanged; no alias or archive is copied.
The original baseline command is copied exactly except its remap-plan and
placed/report output paths. The new 8/1/1 plan copies all original fields and
changes only zero-based step1.report to the actual109-path guide. All three
steps request candidate0, pinsfalse and fixed FF placement. Original other
guides, constraints, source synthesis, seed, options, capture and placed11/12
environment, retained comb and AC stages, GPU selector and cap16384 stay exact.
The sole no-route flag remains. Current project import bytes, including the
two board dependencies absent from the old flat closures, are explicitly
pinned and their loaded paths are checked.

Preparation and execution reject any output overwrite. Controlled
FunctionalInvocation must reproduce the complete old baseline runtime/PATH
with GPU1 and no ambient diagnostics; audited_run executes with only the exact
retained diagnostic environment. Actual fresh local headers, prior rejected
probes, unique candidate0/application and final preceding guarded trial are
recorded for each stage. Actual selected groups may range1..budget, their FF
shift must be0,0, gain at least250ps and all compiled clock/hold/boundary guards
must pass. No site, group membership, gain or function proof is inherited.
Compiler, qualification or downstream failures remain failed actual records,
with any available partial log/export/report hashes labelled separately.

Normal predicted report refresh and nonempty placed/report/log outputs are
required; routing, driver-copy and final signoff labels are forbidden. The
report must have cap16384,15,290 paths and finite positive Fmax/constraints.
These are recorder checks, not independent current native path, Boolean,
physical pin, ALM/cache/GPU, RBF, final hold or routed gain proof. The actual
selected old/new FF transfer ledger, all original BELs/control ports, selected
LUT functions and downstream transforms require a later independent graph
comparison before the new predicted report can serve as a fresh driver guide.
Neither successful preparation nor this no-route run inherits the accepted
117.343MHz performance or qualifies a driver-copy candidate. No hardware test
or default recipe selection occurs.
