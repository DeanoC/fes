"""Pure bounded predicted-prefix comparison; caller authenticates every input."""
import re

PINS = "ABCDEF"
MODEL_KEYS = {"index", "candidate", "groups_budget", "selected_groups", "inner", "outer", "primary_lab", "bel",
              "ena_users", "gain_ps", "ff_shift", "compiled_clock_hold_boundary_guards_passed"}


def require(value, message):
    if not value:
        raise ValueError("current-guide native scope: " + message)


def lab(cell):
    match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
    require(match is not None, "placed cell lacks a native BEL")
    return [int(match[1]), int(match[2])]


def scalar(cell, port):
    bits = cell["connections"][port]
    require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0,
            "required logical signal port is not a scalar native bit")
    return bits[0]


def lut(cell):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    require(match is not None and set(cell["parameters"]) == {"LUT"}, "composition cell is not an ordinary LUT")
    width, table = int(match[1]), cell["parameters"]["LUT"]
    directions = {pin: "input" for pin in PINS[:width]} | {"Q": "output"}
    require(type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"} and
            cell["port_directions"] == directions and set(cell["connections"]) == set(directions),
            "composition table or logical port schema is incomplete")
    return width, int(table, 2), [scalar(cell, pin) for pin in PINS[:width]], scalar(cell, "Q")


def composition(top, model, clone, drivers):
    cells = top["cells"]
    wi, mi, ai, qi = lut(cells[model["inner"]])
    wo, mo, ao, qo = lut(cells[model["outer"]])
    wc, mc, ac, qc = lut(cells[clone])
    require((wi, wo, wc, mi, mo, mc) == (2, 3, 4, 0xb, 0x32, 0x4440) and ao.count(qi) == 1 and
            len({qi, qo, qc}) == 3 and qi not in ai + ac and qo not in ai + ao + ac and qc not in ai + ao + ac and
            len(set(ac)) == 4 and set(ac) == set(ai + [bit for bit in ao if bit != qi]),
            "actual four-leaf ready composition or expected logical masks differ")
    sources = []
    for index, bit in enumerate(ac):
        require(len(drivers.get(bit, [])) == 1 and drivers[bit][0][0] in cells and
                cells[drivers[bit][0][0]]["type"] != "MISTRAL_CONST", "ambiguous or hidden-constant leaf driver")
        sources.append({"port": PINS[index], "raw_bit": bit, "native_driver": list(drivers[bit][0])})
    require(len({tuple(row["native_driver"]) for row in sources}) == 4, "leaf signal driver identities are not distinct")
    rows = []
    for assignment in range(16):
        values = {bit: (assignment >> index) & 1 for index, bit in enumerate(ac)}
        inner_row = sum(values[bit] << index for index, bit in enumerate(ai))
        inner_value = (mi >> inner_row) & 1
        outer_row = sum((inner_value if bit == qi else values[bit]) << index for index, bit in enumerate(ao))
        expected, actual = (mo >> outer_row) & 1, (mc >> assignment) & 1
        require(expected == actual, "raw logical composition differs at assignment" + str(assignment))
        rows.append({"assignment": assignment, "inner_row": inner_row, "inner_value": inner_value,
                     "outer_row": outer_row, "root_value": expected, "clone_value": actual})
    return {"inner": model["inner"], "outer": model["outer"], "clone": clone, "root_raw_bit": qo,
            "clone_raw_bit": qc, "inner_mask_hex": hex(mi), "outer_mask_hex": hex(mo), "clone_mask_hex": hex(mc),
            "clone_actual_input_order": sources, "truth_rows": rows, "assignments_checked": 16,
            "conditional_plain_sig_composition_proved": True, "actual_pin_states_serialized": False}


def net_metadata(net):
    value = dict(net)
    attributes = dict(net["attributes"])
    if "ROUTING" in attributes:
        require(type(attributes["ROUTING"]) is str, "existing net ROUTING is not a string")
        del attributes["ROUTING"]
    value["attributes"] = attributes
    return value


def prove(native, selected, before_doc, after_doc, old_models, new_models):
    """Inputs are complete lossless32fd documents and normalized authenticated log models."""
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and
            before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "native document metadata differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    require(set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            len(a["cells"]) == len(b["cells"]) == 14900 and len(a["netnames"]) == len(b["netnames"]) == 16638 and
            list(a["cells"]) == list(b["cells"]) and list(a["netnames"]) == list(b["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "complete top metadata, raw owner order, counts or lossless PLL occurrences differ")
    require("FES_LABSTATE_V1" not in a["attributes"] and all(cell["type"] != "MISTRAL_BUF" and
            "FES_PINMAP_V1" not in cell["attributes"] for top in (a, b) for cell in top["cells"].values()),
            "predicted image unexpectedly exports late buffers, physical pins or LAB state")
    for name, old in a["netnames"].items():
        new = b["netnames"][name]
        require(set(old["attributes"]) == set(new["attributes"]) and
                native.canonical(net_metadata(old)) == native.canonical(net_metadata(new)),
                "native alias/raw bit/non-ROUTING net metadata differs: " + name)
    require(len(old_models) == len(new_models) == 3 and native.canonical(old_models[0]) == native.canonical(new_models[0]) and
            native.canonical(old_models[2]) == native.canonical(new_models[2]),
            "preceding or later selected local model differs")
    for models in (old_models, new_models):
        for index, model in enumerate(models):
            require(set(model) == MODEL_KEYS and all(type(model[key]) is int for key in
                    ("index", "candidate", "groups_budget", "selected_groups", "ena_users", "gain_ps")) and
                    type(model["primary_lab"]) is list and len(model["primary_lab"]) == 2 and
                    all(type(value) is int and value >= 0 for value in model["primary_lab"]) and model["ena_users"] > 0 and
                    model["index"] == index and model["candidate"] == 0 and
                    model["groups_budget"] == [8, 1, 1][index] and 1 <= model["selected_groups"] <= model["groups_budget"] and
                    model["ff_shift"] == [0, 0] and model["gain_ps"] >= 250 and
                    model["compiled_clock_hold_boundary_guards_passed"] is True, "normalized local qualification differs")
    old_model, new_model = old_models[1], new_models[1]
    allowed = {"primary_lab", "bel", "ena_users", "gain_ps"}
    require({key: value for key, value in old_model.items() if key not in allowed} ==
            {key: value for key, value in new_model.items() if key not in allowed} and
            old_model["selected_groups"] == new_model["selected_groups"] == 1, "stage1 identity or single-group budget differs")
    clone, outer = new_model["outer"] + "$local_remap", new_model["outer"]
    for top, model in ((a, old_model), (b, new_model)):
        require(clone in top["cells"] and top["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"],
                "clone actual BEL does not match its respective fresh qualified model")
    old_drivers, old_users = selected.native_tables(a)
    new_drivers, new_users = selected.native_tables(b)
    require(old_drivers == new_drivers, "an original raw output driver changed")
    old_truth, new_truth = composition(a, old_model, clone, old_drivers), composition(b, new_model, clone, new_drivers)
    root_bit, clone_bit = old_truth["root_raw_bit"], old_truth["clone_raw_bit"]
    require((new_truth["root_raw_bit"], new_truth["clone_raw_bit"]) == (root_bit, clone_bit) and
            old_drivers[root_bit] == [(outer, "Q", 0, 0)] and old_drivers[clone_bit] == [(clone, "Q", 0, 0)] and
            b["netnames"].get(clone + "$Q", {}).get("bits") == [clone_bit], "root/clone owner or exact private alias differs")
    union = sorted(old_users.get(root_bit, []) + old_users.get(clone_bit, []))
    require(len(old_users.get(root_bit, [])) == 109 and len(old_users.get(clone_bit, [])) == 2 and
            len(union) == len(set(union)) == 111 and
            sorted(new_users.get(root_bit, []) + new_users.get(clone_bit, [])) == union, "actual root+clone user union differs")
    clock, cohorts = None, []
    for top, users, model in ((a, old_users, old_model), (b, new_users, new_model)):
        chosen = users.get(clone_bit, [])
        require(len(chosen) == model["ena_users"] and chosen and
                all(lab(top["cells"][slot[0]]) == model["primary_lab"] for slot in chosen), "actual chosen cohort/count/LAB differs")
        expected = [slot for slot in union if lab(top["cells"][slot[0]]) == model["primary_lab"]]
        require(chosen == expected, "selected single LAB omits part of its actual root+clone cohort")
        for name, port, index, occurrence in union:
            cell = top["cells"][name]
            require(cell["type"] == "MISTRAL_FF" and (port, index, occurrence) == ("ENA", 0, 0) and
                    cell["port_directions"]["ENA"] == cell["port_directions"]["CLK"] == "input", "union contains a non-FF/non-ENA slot")
            value = scalar(cell, "CLK")
            clock = value if clock is None else clock
            require(value == clock, "actual original FF clock network differs")
        cohorts.append({"primary_lab": model["primary_lab"], "clone_users": [list(slot) for slot in chosen]})
    redirects = []
    for name, old in a["cells"].items():
        new = b["cells"][name]
        left, right = dict(old), dict(new)
        left.pop("connections"); right.pop("connections")
        if name == clone:
            left["attributes"], right["attributes"] = dict(left["attributes"]), dict(right["attributes"])
            left["attributes"].pop("NEXTPNR_BEL"); right["attributes"].pop("NEXTPNR_BEL")
        require(native.canonical(left) == native.canonical(right) and list(old["connections"]) == list(new["connections"]),
                "original metadata/params/ports/attrs/BEL differs outside stage1 clone BEL: " + name)
        for port, bits in old["connections"].items():
            now = new["connections"][port]
            if bits == now:
                continue
            slot = (name, port, 0, 0)
            require(old["type"] == "MISTRAL_FF" and port == "ENA" and slot in union and
                    bits == [clone_bit if slot in old_users[clone_bit] else root_bit] and
                    now == [clone_bit if slot in new_users[clone_bit] else root_bit], "unlisted original input slot differs")
            redirects.append({"cell": name, "port": port, "vector_index": 0, "occurrence": 0, "old_raw_bit": bits[0],
                              "new_raw_bit": now[0], "bel": old["attributes"]["NEXTPNR_BEL"]})
    changes = {(row["cell"], "ENA", 0, 0) for row in redirects}
    require(changes == set(old_users[clone_bit]) ^ set(new_users[clone_bit]), "declared ENA delta is not the exact cohort symmetric difference")
    for bit in set(old_users) | set(new_users):
        expected = list(old_users.get(bit, []))
        for row in redirects:
            slot = (row["cell"], "ENA", 0, 0)
            if row["old_raw_bit"] == bit:
                expected.remove(slot)
            if row["new_raw_bit"] == bit:
                expected.append(slot)
        require(sorted(expected) == new_users.get(bit, []), "native user/load table differs outside named ENA ledger")
    return {"serialized_native_scope_proved": True, "declared_ena_redirects": redirects, "declared_ena_redirect_count": len(redirects),
            "stage1_clone": clone, "old_clone_bel": old_model["bel"], "new_clone_bel": new_model["bel"],
            "old_new_actual_cohorts": cohorts, "actual_original_root_plus_clone_union": [list(slot) for slot in union],
            "exported_CLK_raw_bit": clock, "before_conditional_composition": old_truth, "after_conditional_composition": new_truth,
            "all_original_ff_bels_and_non_ena_records_exact": True, "all_other_cell_and_non_routing_net_records_exact": True,
            "existing_net_routing_values_independently_proved": False, "raw_driver_table_exact_user_table_matches_ledger": True,
            "owner_order_lossless_pll_and_all_other_raw_bits_exact": True, "pre_step_graph_serialized_or_independently_proved": False,
            "pin_assumptions": "All inner/outer/clone input and Q pins are plain PIN_SIG; logical raw-mask composition only.",
            "physical_pin_lab_controls_cache_gpu_or_independent_boolean_equivalence_proved": False,
            "numerical_sta_routing_gain_or_hardware_acceptance_proved": False}
