# Current-guide g1 predicted-prefix comparison

Root alone executes this new comparison after a completed audited g1 prefix.
The exact74ae profile and full original input closure are rehashed; current
execution must equal its baseline snapshot. All profile fields remain exact,
except record.input_sha256 must be precisely profile.input_sha256 union the
profile's own original pathname/hash. Its three actual outputs are bound.
External historical profile files retain exact original hashes and are marked
as historical execution evidence; the separate actual runtime stays exact.

The frozen a60 recorder is imported only to parse both actual 8/1/1 logs and
derive the retained command. Its prepare/run/main never execute.
Parsed rejected-trial tuples are compared through canonical JSON against the
actual serialized record's arrays, preserving every field/value/order and
changing neither input object.
The pure graph helper receives its explicit twelve-field MODEL_KEYS projection
of each parsed model after this complete record comparison. Full prior-trial
and qualification diagnostics remain bound and emitted unchanged; no native
graph, ID, record or old helper is normalized or patched.
The pinned32fd parser preserves paired PLL outputs. The72131 pure native tables and
report-topology APIs use their exact8601 module through a local import binding;
no caller globals or old freeze module is replaced. No old authenticator or
comparison generator runs.

The separately pinned native_scope.py and native-scope.md declare all allowed
native deltas before execution. Stages0/2, all original cell/net/raw identities,
port/metadata/FF placement/control records and order remain strict outside
the explicit whole-cohort ENA transfers and stage1 clone BEL. Its actual old
and new sites, memberships and functions must bind the respective fresh log
models, with no inferred pre-step snapshot or physical pin-state waiver.
All71 ordinary placement metrics are exact. Every current predicted native
report path is independently checked against the actual current graph and
old pair/window/endpoint coverage, without inheriting old numerical delays.

This is a conditional serialized/logical prefix proof, not independently
exported physical Boolean, hidden-cache, numerical STA, driver, routed gain,
CRAM or hardware acceptance. Only a positive bounded graph result can make
this fresh predicted report available for a new driver qualification. Final
GPU routing, full graph/physical scope, all actual windows and LAST holds
still need separate validation before a gain can be accepted.
