# Pure native scope for the current-guide groups1 prefix

Root alone authenticates and executes this helper. `prove(native, selected,
before_doc, after_doc, old_models, new_models)` performs no file reads, imports
of other helpers, generator/authentication replay, compiler execution or STA.
The wrapper supplies the pinned32fd parser/canonical API, pinned72131
`native_tables` API, complete lossless native documents and separately
authenticated models parsed from each actual local qualification log.

Each normalized model has exactly these fields: index, candidate,
groups_budget, selected_groups, inner, outer, primary_lab, bel, ena_users,
gain_ps, ff_shift and compiled_clock_hold_boundary_guards_passed. The wrapper
must derive the combined guard boolean from the actual clock/hold/boundary
trial fields and bind candidate0 to its final preceding guarded trial and
application. Original and current models0/2 are exact. Model1 retains the same
inner/outer, candidate0, groups1 and fixed FFs; only its actual qualified
primary LAB, clone BEL, user count and gain may differ. No LAB or clone site is
predicted here.

Both documents must have14900 cells and16638 nets with exact top settings,
attributes, public ports, creator, owner order and both ordered PLL port
occurrences. All original cell records are exact except the existing stage1
clone's NEXTPNR_BEL and the explicitly named FF.ENA scalar slots. Every FF BEL,
parameter, direction, control and non-ENA connection remains exact. Net names,
numeric bits, metadata and attribute key sets remain exact; only a present
string ROUTING value is excluded from comparison. No raw IDs are renamed, no
BUF is collapsed, and both predicted images must lack late MISTRAL_BUF,
FES_PINMAP and FES_LABSTATE snapshots.

The old image's actual root109 and clone2 ENA users form a disjoint111-slot
union. The current image must preserve that union. In each image the single
selected primary LAB contains the complete actual union cohort at that LAB,
with the respective fresh log's user count and a common unchanged native CLK.
The exact old/new clone-cohort symmetric difference defines the only permitted
ENA transfers: old clone users leaving the cohort return to the original
root; newly selected root users move to the existing clone. Entire native
driver/user tables are rebuilt through the supplied72131 API, with all outputs
and every user/load outside those named slots exact. Public ports are compared
strictly separately. These available images do not reconstruct or prove an
unserialized pre-step111-user snapshot.

Both actual compositions are checked independently across16 assignments to
four distinct native leaf drivers. Logical inner ALUT2 mask0xb and outer
ALUT3 mask0x32 compose to the actual ALUT4 clone mask0x4440 using each image's
real port order and raw bits. This is conditional raw-table algebra under
explicit plain PIN_SIG assumptions for all input and Q pins. Actual physical
polarity/constants/shared banks, whole-LAB FF controls/selectors, unexported
caches/GPU identities and independent Boolean equivalence remain unproved.
The enclosing wrapper must separately validate current report topology and
bind all source, profile, runtime, helper and output paths. Successful native
scope alone grants no independent numerical STA, fresh driver qualification,
routing, signoff, timing gain, RBF/CRAM or hardware acceptance.
