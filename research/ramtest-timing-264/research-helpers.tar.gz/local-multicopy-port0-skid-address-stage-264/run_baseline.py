"""Record an eighth port0 address remap while retaining the exact seven-stage prefix."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
PREVIOUS = RAW / "local-multicopy-ready1-byteenable-stage-264"
FULL = RAW / "local-multicopy-ready1-byteenable-route-264"
FULL_PROOF = RAW / "local-multicopy-ready1-byteenable-route-proof-264/comparison.json"
FULL_PROOF_SHA = "4653836bce4881dbde29261ad689368c77339357bf456c34acbdff5a2802ef19"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
GUIDE_FOLDER = RAW / "local-multicopy-port0-skid-address-guide-264"
COMPILER = RAW / "local-multicopy-264"
COMMIT, BASE = "81243a1300304d7e598156c692be2fcbf2c16268", "5dd69a8ddece6280d576816d2277c73f80607f52"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-local-multicopy-264"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
CONTROL_SHA = "f3e1f1e84d408db29088c39006b205284ad173bfe900a36f89c6b6122bdb076c"
PREVIOUS_PROFILE_SHA = "f3daa31872e004631389e899b9e4fe581b6704f7fe865e0b4bb3aa492c54fd2e"
PREVIOUS_RUN_SHA = "73788bd5a7b5d88a2288575669c35f6a5250357ee80fe987eb5b91f5fd2aa6e3"
PREFIX_SHA = "0db217de56826b701ae59ad006d562b67e9e8e43ef47465579eb00d859f35551"
SEVEN_PARSER, SEVEN_SHA = PREVIOUS / "run_baseline.py", "abd9832d33e9705a75deb404b7349282921ff5321216b4ec8d526391e90040bd"
SEVEN_SCOPE_SHA = "83590ba4442ff274ad7d272a350705dc74fae9546f06c949a000a857726ae0f5"
SIX_PARSER, SIX_SHA = RAW / "local-multicopy-port0-burst-stage-264/run_baseline.py", "57ec4a9c788d3fbf59f1a5123ee1f197bb967f4390fb4daf9642345aee6b0362"
SIX_SCOPE_SHA = "405b30eb0fe6a5af663832195047f2ca93dd4d1a5d0fb1fec0d878c1589d27e0"
FIVE_PARSER = RAW / "local-multicopy-ready1-address-stage-264/run_baseline.py"
FIVE_SHA = "a2d626253826a6b187713f42904720ecdb1d06754ab2776c1fa9d7b39437e2f4"
FOUR_PARSER = RAW / "local-multicopy-ready1-264/run_baseline.py"
FOUR_SHA = "440013e34d68841d103ca0bea4e3d927a9fd9f50917e10800ad604caa1aec36a"
FULL_PROFILE_SHA = "a1b5b12727cd0c2161f6fff8b54e8dd7e04d8f543f484615a8e31dc7e00c4c7a"
FULL_RUN_SHA = "e45404227879c7896abdf9fe6e63caa0f0e5f3c0ed98303c86d6897bd9368017"
GUIDE, DERIVATION = GUIDE_FOLDER / "address-guide.json", GUIDE_FOLDER / "derivation.json"
GUIDE_SHA = "962f79644a2fa110a8fef740599b82333f35f48c95d8d39f9fde93ccc853a9ee"
DERIVATION_SHA = "287a906dd22e4dac3e14c4a90e937f239483064531e3122110aed3e21b7c8173"
GUIDE_HELPER_SHA = "fbf5b268425fa330f0d72bd26e497a0970dc80854eaea23dd73f41dca5bd10fe"
GUIDE_SCOPE_SHA = "ec2876528609300e3728ab6337204dbbea6c652841b4238637cbfab16ffd021a"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PROFILE, PLAN, FOLDER = HERE / "source-identity.json", HERE / "local-plan.json", HERE / "baseline"
INNER, OUTER = "hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B"
TARGET = "hps_ddr.port0.skid_address_MISTRAL_FF_Q_23"
TARGETS = tuple("hps_ddr.port0.skid_address_MISTRAL_FF_Q_" + str(i) for i in (18, 20, 23))
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected) and
            (path not in inputs or inputs[path] == expected), "invalid/conflicting original path hash")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path)
        inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original byte pathname changed")


def adopt(inputs, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        bind(inputs, name, expected)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure helper hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure helper path differs")
    return module


def clean_source():
    def git(*args):
        return subprocess.run(["git", "-C", str(SOURCE), *args], check=True, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()
    require(git("rev-parse", "HEAD") == COMMIT and not git("status", "--porcelain", "--untracked-files=all") and
            git("merge-base", BASE, COMMIT) == BASE and set(git("diff", "--name-only", BASE, COMMIT).splitlines()) ==
            {"mistral/local_remap.cc", "mistral/tests/remap_plan.cc"}, "compiler is not the clean committed two-file result")


def command(previous):
    result = list(previous["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == 1 and
            not any(flag in result for flag in ("--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "previous predicted role differs")
    for flag, path in (("--remap-plan", PLAN), ("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous plan/output selector")
        result[result.index(flag) + 1] = str(path)
    return result


def qualification(log, seven_parser, six_parser, five_parser, four_parser):
    headers = list(re.finditer(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, h.groups())) for h in headers] == [(i, 0, g, 0, 1) for i, g in enumerate((8, 1, 1, 1, 1, 1, 1, 1))],
            "fresh eight-stage headers differ")
    models = seven_parser.qualification(log[:headers[7].start()], six_parser, five_parser, four_parser)
    block = log[headers[7].end():]
    trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
    choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
    applications = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
    require(trials and len(choices) == len(applications) == 1 and choices[0][1] == applications[0][1] == "0" and
            trials[-1].end() < choices[0].start() < applications[0].start(), "fresh eighth candidate0/application lacks a final guarded trial")
    row, choice = trials[-1].groups(), choices[0].groups()[1:]
    require((row[0], row[1], row[4], row[12], row[7]) == choice and row[:2] == (INNER, OUTER) and
            row[2:4] == ("33", "23") and row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and
            row[11:13] == ("1", "3") and int(row[7]) >= 250, "fresh three-ENA fixed-FF/clock/hold/boundary/gain guards differ")
    models.append({"index": 7, "candidate": 0, "groups_budget": 1, "selected_groups": 1, "inner": INNER, "outer": OUTER,
        "primary_lab": [33, 23], "bel": row[4], "ena_users": 3, "gain_ps": int(row[7]), "actual_trial_count": len(trials),
        "prior_trial_rows": [x.groups() for x in trials[:-1]], "ff_shift": [0, 0],
        "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False})
    return models


def prepare(self_sha, scope_sha, guide_sha, derivation_sha):
    require(guide_sha == GUIDE_SHA and derivation_sha == DERIVATION_SHA, "actual executed guide/derivation pins required")
    require(not any(path.exists() for path in (PROFILE, PLAN, FOLDER)), "eighth-stage profile/plan/outputs already exist")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (GUIDE, guide_sha),
            (DERIVATION, derivation_sha), (GUIDE_FOLDER / "derive_guide.py", GUIDE_HELPER_SHA), (GUIDE_FOLDER / "scope.md", GUIDE_SCOPE_SHA),
            (PREVIOUS / "source-identity.json", PREVIOUS_PROFILE_SHA), (PREVIOUS / "baseline/run.json", PREVIOUS_RUN_SHA),
            (PREVIOUS / "baseline/comparison-prefix.json", PREFIX_SHA), (SEVEN_PARSER, SEVEN_SHA), (PREVIOUS / "scope.md", SEVEN_SCOPE_SHA),
            (SIX_PARSER, SIX_SHA), (SIX_PARSER.parent / "scope.md", SIX_SCOPE_SHA),
            (FIVE_PARSER, FIVE_SHA), (FOUR_PARSER, FOUR_SHA), (FULL_PROOF, FULL_PROOF_SHA), (ACCEPTED, ACCEPTED_SHA),
            (FULL / "source-identity.json", FULL_PROFILE_SHA), (FULL / "route-c0/run.json", FULL_RUN_SHA),
            (COMPILER / "baseline/comparison-control.json", CONTROL_SHA), (COMPILER / "validation/host-validation.json", HOST_SHA),
            (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA), (PURE, PURE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        bind(inputs, path, expected)
    prefix, derived, experiment, accepted = (read(path) for path in
        (PREVIOUS / "baseline/comparison-prefix.json", DERIVATION, FULL_PROOF, ACCEPTED))
    for manifest in (prefix, derived, experiment, accepted):
        adopt(inputs, manifest)
    require(prefix["structural_rejection"] is None and prefix["native_graph_proof_available"] is True and
            prefix["compiler_commit"] == COMMIT and prefix["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and
            prefix["current_baseline_run_sha256"] == PREVIOUS_RUN_SHA and experiment["structural_rejection"] is None and
            experiment["native_graph_proof_available"] is experiment["physical_scope_proved"] is True and
            experiment["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and
            experiment["current_full_run_sha256"] == FULL_RUN_SHA and experiment["source_identity_sha256"] == FULL_PROFILE_SHA and
            experiment["prefix_proof_sha256"] == PREFIX_SHA and experiment["accepted_full_proof_sha256"] == ACCEPTED_SHA and
            accepted["structural_rejection"] is None and accepted["native_graph_proof_available"] is accepted["physical_scope_proved"] is
            accepted["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and
            derived["phase"] == "local-multicopy-port0-skid-address-exact-current-path-guide" and
            derived["route_profile_sha256"] == FULL_PROFILE_SHA and derived["current_full_run_sha256"] == FULL_RUN_SHA and
            derived["prefix_proof_sha256"] == PREFIX_SHA and derived["experimental_full_proof_sha256"] == FULL_PROOF_SHA and
            derived["accepted_reference_full_proof_sha256"] == ACCEPTED_SHA and derived["accepted_memory_reference_mhz"] == 117.77175903320312 and
            derived["source_seventh_experiment_timing_gain_accepted"] is False and derived["new_candidate_qualified"] is False and
            derived["generator_sha256"] == GUIDE_HELPER_SHA and derived["scope_sha256"] == GUIDE_SCOPE_SHA and
            derived["guide_path"] == str(GUIDE) and derived["guide_sha256"] == guide_sha and
            derived["selected_lab"] == [33, 23] and derived["selected_endpoint"] == TARGET and derived["selected_paths"] == 1 and
            derived["expected_next_copy_name"] == OUTER + "$local_remap$2" and derived["existing_function_assignments_checked"] == 16 and
            derived["exact_path_objects_and_original_source_order_preserved"] is True and
            derived["all_original_report_metadata_except_filtered_critical_paths_exact"] is True and
            derived["clock_terms_locations_sources_windows_or_segment_delays_modified"] is False,
            "seventh prefix/experimental native-physical result/accepted reference or actual one-path guide differs")
    previous, original, full, host = (read(path) for path in (PREVIOUS / "baseline/run.json", PREVIOUS / "source-identity.json",
        FULL / "route-c0/run.json", COMPILER / "validation/host-validation.json"))
    require(previous["completed"] is full["completed"] is True and previous["exit_code"] == full["exit_code"] == 0 and
            previous["compiler_read_audit_passed"] is full["compiler_read_audit_passed"] is True and
            previous["compiler_commit"] == full["compiler_commit"] == host["compiler_commit"] == COMMIT and
            previous["binary_sha256"] == full["binary_sha256"] == host["binary_sha256"] == BINARY_SHA and
            previous["source_archive_sha256"] == full["source_archive_sha256"] == host["source_archive_sha256"] == ARCHIVE_SHA and
            previous["execution"] == original["baseline_execution"] == full["execution"] and
            previous["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and full["source_identity_sha256"] == FULL_PROFILE_SHA and
            previous["actual_selected_local_qualification"] == prefix["fresh_local_models"] == full["actual_selected_local_qualification"] and
            previous["input_sha256"] == {**original["input_sha256"], str(PREVIOUS / "source-identity.json"): PREVIOUS_PROFILE_SHA} and
            previous["final_original_input_output_runtime_hashes_stable"] is full["final_original_input_output_runtime_hashes_stable"] is True and
            host["result_commit"] == COMMIT and host["build_passed"] is host["clean_committed_checkout"] is True and
            not any(key in record for record in (previous, full) for key in
                ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")),
            "closed compiler/source/seven-stage/runtime roles differ")
    for record in (previous, full):
        require(all(inputs.get(path) == expected for path, expected in {**record["input_sha256"], **record["output_sha256"],
                **record["execution"]["files"]}.items()), "closed original input/output/runtime closure differs")
    old_plan = read(PREVIOUS / "local-plan.json")
    require(set(old_plan) == {"steps"} and old_plan["steps"] == previous["local_plan_steps"] == original["local_plan_steps"] and
            len(old_plan["steps"]) == 7 and [step["groups"] for step in old_plan["steps"]] == [8, 1, 1, 1, 1, 1, 1],
            "exact first-seven descriptors differ")
    native = load(PURE, PURE_SHA, "skid_address_stage_native")
    frozen = load(FREEZE, FREEZE_SHA, "skid_address_stage_freeze")
    selected = load(SELECTED, SELECTED_SHA, "skid_address_stage_tables", frozen)
    before_doc, full_doc = native.read_netlist(PREVIOUS / "baseline/placed.json"), native.read_netlist(FULL / "route-c0/routed.json")
    before, routed = before_doc["modules"]["top"], full_doc["modules"]["top"]
    guide, full_report = read(GUIDE), read(FULL / "route-c0/timing.json")
    indices = derived["selected_path_source_indices"]
    require(type(indices) is list and len(indices) == 1 and type(indices[0]) is int and 0 <= indices[0] < len(full_report["critical_paths"]),
            "actual selected source index differs")
    expected_paths = [full_report["critical_paths"][index] for index in indices]
    require(canonical(guide) == canonical({**full_report, "critical_paths": expected_paths}) and
            expected_paths[0]["path"][-1]["to"]["cell"] == TARGET and expected_paths[0]["path"][-1]["to"]["port"] == "ENA",
            "guide object/source order or other report fields changed")
    for segment in expected_paths[0]["path"]:
        for endpoint in (segment["from"], segment["to"]):
            name, port = endpoint["cell"], endpoint["port"]
            a, b = before["cells"][name], routed["cells"][name]
            require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and
                    a["attributes"]["NEXTPNR_BEL"] == b["attributes"]["NEXTPNR_BEL"] and
                    a["port_directions"][port] == b["port_directions"][port] and a["connections"][port] == b["connections"][port],
                    "current guide references a changed prior-driver native endpoint")
    _, users = selected.native_tables(before)
    q = before["cells"][OUTER]["connections"]["Q"][0]
    cohort = [slot for slot in users[q] if before["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"].startswith("MISTRAL_FF.33.23.")]
    require(len(users[q]) == 171 and cohort == [(name, "ENA", 0, 0) for name in TARGETS] and
            derived["declared_target_lab_ena_slots"] == [list(slot) for slot in cohort],
            "eighth cohort is not exactly the three current ready0 address ENAs in LAB33.23")
    target_bels = {TARGETS[0]: "MISTRAL_FF.33.23.52", TARGETS[1]: "MISTRAL_FF.33.23.34", TARGETS[2]: "MISTRAL_FF.33.23.26"}
    target_rows = []
    for name in TARGETS:
        require(before["cells"][name]["type"] == "MISTRAL_FF" and
                before["cells"][name]["connections"]["CLK"] == routed["cells"][name]["connections"]["CLK"] == [3549] and
                before["cells"][name]["attributes"]["NEXTPNR_BEL"] == target_bels[name],
                "actual address cohort clock or original FF BEL differs")
        target_rows.append({"cell": name, "port": "ENA", "vector_index": 0, "occurrence": 0, "old_raw_bit": q,
            "clock_raw_bit": 3549, "bel": target_bels[name], "before_record": before["cells"][name]})
    models, copies, seen = previous["actual_selected_local_qualification"], [], {}
    labs, owners = {(33, 23)}, {INNER, OUTER}
    for model in models:
        outer = model["outer"]; ordinal = seen.get(outer, 0); seen[outer] = ordinal + 1
        name = outer + "$local_remap" + ("$" + str(ordinal) if ordinal else "")
        cell = before["cells"][name]; bit = cell["connections"]["Q"][0]
        require(cell["attributes"]["NEXTPNR_BEL"] == model["bel"] and len(users[bit]) == model["ena_users"] and
                not set(users[bit]) & set(cohort) and all(slot[1:] == ("ENA", 0, 0) and
                    before["cells"][slot[0]]["type"] == "MISTRAL_FF" and before["cells"][slot[0]]["connections"]["CLK"] == [3549]
                    for slot in users[bit]), "retained selected copy/cohort/site differs")
        copies.append({"cell": name, "record": cell, "consumer_slots": [list(slot) for slot in users[bit]]})
        owners.update((model["inner"], outer, name)); labs.add(tuple(model["primary_lab"]))
        owners.update(slot[0] for slot in users[bit])
    require([len(row["consumer_slots"]) for row in copies] == [21, 2, 10, 1, 6, 1, 1] and
            copies[2]["cell"] == OUTER + "$local_remap" and copies[5]["cell"] == OUTER + "$local_remap$1" and
            len(copies[2]["consumer_slots"]) == 10 and len(copies[5]["consumer_slots"]) == 1,
            "seven retained cohorts or existing port0 ten/one-user copies differ")
    expected_name = OUTER + "$local_remap$2"
    require(all(name not in before["cells"] and name not in before["netnames"] for name in (expected_name, expected_name + "$Q")),
            "expected next ready0 clone pair is occupied in cell/net/alias namespace")
    for name in owners:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", before["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared cone/copy/cohort owner lacks a placed BEL")
        labs.add(tuple(map(int, match.groups())))
    ff_bels, neighborhoods = {}, []
    for name, cell in before["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        bel = cell["attributes"].get("NEXTPNR_BEL", "")
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", bel)
        require(match is not None, "original FF lacks a placed BEL")
        ff_bels[name] = bel
        if tuple(map(int, match.groups())) in labs: neighborhoods.append({"cell": name, "record": cell})
    require(len(ff_bels) == 8221, "complete original FF placement count differs")
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    plan = copy.deepcopy(old_plan)
    plan["steps"].append({"report": str(GUIDE), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True})
    require(len(plan["steps"]) == 8 and plan["steps"][:7] == old_plan["steps"], "eight-step cap/count or first-seven descriptor order/path/value changed")
    finish(inputs); clean_source()
    with PLAN.open("x") as stream: stream.write(json.dumps(plan, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, PLAN, sha(PLAN))
    profile = {"schema": 1, "phase": "local-multicopy-port0-skid-address-eighth-stage-predicted-baseline", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA,
        "control_proof_sha256": CONTROL_SHA, "previous_prefix_proof_sha256": PREFIX_SHA, "previous_source_identity_sha256": PREVIOUS_PROFILE_SHA,
        "previous_baseline_run_sha256": PREVIOUS_RUN_SHA, "experimental_current_full_proof_sha256": FULL_PROOF_SHA,
        "accepted_current_full_proof_sha256": ACCEPTED_SHA, "minimum_accepted_memory_mhz": 117.77175903320312,
        "current_full_profile_sha256": FULL_PROFILE_SHA, "current_full_run_sha256": FULL_RUN_SHA,
        "guide_sha256": guide_sha, "guide_derivation_sha256": derivation_sha, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "original_seven_plan_sha256": inputs[str(PREVIOUS / "local-plan.json")], "local_plan_sha256": inputs[str(PLAN)], "local_plan_steps": plan["steps"],
        "retained_local_models": models, "authorized_plan_delta": {"append_index": 7, "step": plan["steps"][7], "first_seven_descriptors_exact": True},
        "expected_additional_copy_name": expected_name, "declared_ena_cohort": target_rows, "retained_copy_cohorts": copies,
        "declared_whole_labs": sorted(map(list, labs)), "original_ffs_in_declared_labs": sorted(neighborhoods, key=lambda row: row["cell"]),
        "all_original_ff_bel_manifest": dict(sorted(ff_bels.items())), "actual_eighth_site_neighborhood_requires_later_prefix_proof": True,
        "command": command(previous), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"],
        "baseline_execution": previous["execution"], "input_sha256": dict(sorted(inputs.items())),
        "driver_pass_executed": False, "native_graph_or_physical_equivalence_inherited": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source()
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "plan_sha256": inputs[str(PLAN)],
        "declared_ena_slots": 3, "original_ff_bels": len(ff_bels)}, indent=2))


def execute(profile_sha):
    inputs = {}
    bind(inputs, PROFILE, profile_sha)
    profile = read(PROFILE)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    previous = read(PREVIOUS / "baseline/run.json")
    require(not FOLDER.exists() and profile["command"] == command(previous) and profile["baseline_execution"] == previous["execution"] and
            profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["cwd"] == previous["cwd"] == str(MODULE) and
            profile["compiler_commit"] == COMMIT and profile["retained_local_models"] == previous["actual_selected_local_qualification"] and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
            inputs[str(BINARY)] == BINARY_SHA and inputs[str(ARCHIVE)] == ARCHIVE_SHA and inputs[str(PLAN)] == profile["local_plan_sha256"] and
            read(PLAN)["steps"] == profile["local_plan_steps"], "frozen current role/helper/command/runtime/plan differs")
    clean_source()
    seven_parser = load(SEVEN_PARSER, SEVEN_SHA, "skid_address_stage_seven_log_parser")
    six_parser = load(SIX_PARSER, SIX_SHA, "skid_address_stage_six_log_parser")
    five_parser = load(FIVE_PARSER, FIVE_SHA, "skid_address_stage_five_log_parser")
    four_parser = load(FOUR_PARSER, FOUR_SHA, "skid_address_stage_four_log_parser")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected,
                "loaded project module differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env),
                "actual current runtime or ambient diagnostics changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            result = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"],
                env={**invocation.env, **profile["diagnostic_environment"]}, stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = result.returncode, True
        invocation.verify()
        require(result.returncode == 0, "fresh eighth-stage compiler did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis...", "LUT driver copy")) and
                not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual role is not predicted-only")
        record["actual_selected_local_qualification"] = qualification(log, seven_parser, six_parser, five_parser, four_parser)
        record["original_seven_selected_models_exact"] = canonical(record["actual_selected_local_qualification"][:7]) == canonical(profile["retained_local_models"])
        require(record["original_seven_selected_models_exact"], "fresh first-seven models differ from the closed seventh-stage baseline")
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()),
                "actual predicted report cap/count/Fmax differs")
        record["actual_predicted_fmax"], record["output_sha256"] = report["fmax"], {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual predicted output absent")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source()
        record["completed"] = True
        print(json.dumps({"completed": True, "first_seven_models_exact": True,
            "actual_eighth_qualification": record["actual_selected_local_qualification"][7], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); finish({**inputs, **record.get("output_sha256", {})}); clean_source()
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False
                    record["final_original_input_output_runtime_hashes_stable"] = False
                    record["final_rehash_failure"] = repr(error)
                    raise
                finally:
                    (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "guide-sha256", "derivation-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(args.self_sha256 and args.scope_sha256 and args.guide_sha256 and args.derivation_sha256, "actual helper/scope/guide/derivation pins required")
        prepare(args.self_sha256, args.scope_sha256, args.guide_sha256, args.derivation_sha256)
    else:
        require(args.profile_sha256, "profile activation pin required")
        execute(args.profile_sha256)


if __name__ == "__main__":
    main()
