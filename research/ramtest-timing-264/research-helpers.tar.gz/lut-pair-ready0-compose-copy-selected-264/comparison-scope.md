# Selected composed-copy conditional native proof

This new inactive comparator owns only compare_selected_copy.py and this scope.
The independently completed current compiler is cae5eb9a on e137ca5b, host84416288,
ELFa2b5da93/archivec64eb65c. Actual listing00c6e15c/runc9b58c4e/proof5096a9d8
and selected recorderfec8c4b4/scope936673ca are bound. Actual selected profile/run
remain UNFROZEN until ROOT supplies real pins. No candidate index is assumed.
ROOT alone performs
imports, AST, prepare/execute, compiler/test/GPU and publication operations.

The prerequisite is the fresh positive composed-copy listing reproduction,
including exact current native/model/report rollback and the bound e137 diagnostic,
5a listing and dual-reference disabled-TEN control proofs. Its flat artifacts and
runtime ledgers, both exact closed profile input unions, all outputs, the actual
current host/source/submodule/model/object-dependency closure, current executable,
archive and every called helper/module byte are rehashed at original paths.
The actual selected invocation retains literal TEN00bf, one-path guide9bdad541,
source JSON/QSF/SDC/device/seed and complete execution environment. Only candidate
selection and fresh output paths differ from that same-binary listing invocation.
The selected parser independently reproduces the original listing prefix through
the chosen actual guarded candidate before its sole application marker.

Only lower reviewed definitions are reused:32fd lossless read/Audit/metrics,
72131 native tables/report topology with8601 isolated dependency, and the newly
bound selected recorder's pure command/runtime/definition/qualification APIs.
No prior comparison, prepare, execute, main, authenticator or high-level native,
physical or numerical timing evaluator is called. Current TEN parsers and actual
five loaded project modules must all appear in the frozen input closure.

The graph proof starts from the fresh listing image. Exactly one new ALUT2..6 and
one new private owner+$Q alias are permitted:14907→14908 cells and16645→16646 nets.
The first-free paired namespace is derived from actual original cell/net names.
New Q must be absent from every original alias/driver/user; no private-ID alignment,
global numerical renaming, BUF collapse, creator exception or metadata waiver is
used. All original owner/alias/port/nested orders, paired PLL entries, tables,
attributes, controls, ports and literal raw IDs remain exact except precisely the
whole same-root scalar FF.ENA cohort in the chosen target LAB with the same clock.
Every other original consumer stays on the original root. Complete reconstructed
driver/user occurrence tables admit only the new clone's literal external loads,
its unique Q driver and those named ENA transfers. Every8221 original FF BEL is
literal; all original FF records in pair/target/leaf/destination LAB neighborhoods
are retained. The clone's actual selected site must lie within radius3 and occupy
an ALM with no original serialized COMB/MCOMB/FF occupant.

Composition is independently rebuilt from the actual fully defined inner/outer
tables and literal logical A..F signal identities, including shared leaves.
The cut has at most six distinct external signals and no feedback; every leaf has
one actual native driver. Clone leaf order and width are derived, not borrowed
from compiler composition logs. Every2^width assignment (up to64) independently
evaluates both original tables and the actual clone mask. Padded clone ports are
enumerated for BOTH Boolean values so equivalence cannot depend on an assumed
constant value. Original disconnected inputs or unsupported native literals fail
closed; constants/inversions cannot be invented from absent packed metadata.

This is explicitly conditional on connected original/copy signals having their
native logical polarity. Placed JSON does not export effective packed pin states,
ENA polarity, ALM banks, complete LAB/cache selectors or indexed-store holes.
Their equivalence is FALSE/unproved here. Later fresh routed FES_PINMAP/LABSTATE
evidence must independently prove actual constants/inversions, clone/input/mate
truth, FF ENA equivalence and protected carry/shared-bank/LAB controller neighbors.
Backend native tests and guard logs are separate evidence, never substituted for
that physical proof. The prototype does not claim independent numerical STA,
hold margins, calibration, RBF decoding or hardware behavior.

Own actual selected and listing reports each validate all15290 native paths and
seven real clock-pair endpoint/window sets with complete finite signed terms and
clock attribution. TEN complete models and71 placement rows must remain exact;
selected report delay/Fmax changes are legitimate and whole-report equality is
diagnostic only. Recorded guard/hold flags bind the chosen actual trial but do
not constitute independent numerical timing proof. Graph, prefix and topology
rejections are separate and current report evidence survives any graph rejection.
The complete original-path closure is rehashed before writing the exclusive
selected/comparison-selected-copy.json. Only all gates permit the conditional
native route prerequisite. No routed gain or accepted130MHz result is claimed;
the accepted117.771759MHz full route remains separate.
