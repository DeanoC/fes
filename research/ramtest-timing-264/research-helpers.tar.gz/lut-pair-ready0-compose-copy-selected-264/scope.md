# Fresh explicit composed-copy selection recorder

This new author-only recorder is inactive until the fresh composed-copy listing
has a closed run and positive independent reproduction. Its profile/run/proof
and final comparer/scope identities remain UNFROZEN. Actual compiler cae5eb9a,
ELF a2b5da93, archive c64eb65c and host84416288 are already closed; the host binds
the reviewed nine-file delta, source/submodule/model/dependency/archive bytes,
all58 native cases and51 CLI methods. Historical failed build/native attempts
remain separate. ROOT alone imports, AST-checks, prepares or executes helpers.

Preparation requires explicit actual self/scope, listing profile/run/proof,
compiler/archive/host hashes and a nonnegative --candidate value. There is no
default candidate0 and no assumption that any candidate exists. Missing or
rejected listing proof, an absent chosen candidate, invalid guards or existing
new outputs reject before publishing the new profile. The fresh listing's
native/model/71-metric/full-report reproduction must be positive against all
three directly bound references: e137 diagnostic12a957, prior5a listing94627
and disabled-control9498. Their flat closures are retained transitively through
the independently pinned listing proof; no previous operational entrypoint runs.

The immutable one-path guide9bdad541 and literal TEN plan00bf remain unchanged.
The actual selected inner/outer/FF.ENA identity must match the complete guide's
last two routing edges. Candidate identity, clone BEL, gain, cohort and complete
guarded trial are taken from the actual re-parsed closed listing, rather than
guessed. The source graph is freshly packed and placed. Only the existing
candidate selector and write/report aliases differ from the proved listing
argv; compose-copy and no-route remain. Post-plan, driver, replay, RBF and route
are excluded. FunctionalInvocation environment and runtime files are exactly
the same current compiler snapshot, including controlled PATH.

Only the new listing's pinned definitions and complete-listing qualification,
its eight lower TEN parsers and32fd lossless native JSON reader are called.
No old prepare/execute/main/authentication/comparison/equivalence evaluator
runs. The full input union binds all called pure helpers, exact five loaded
project-module paths, current host maps, original source/library inputs and
runtime files. Clean committed source and all dependencies are rechecked.

Before execution the recorder independently declares the whole original root-Q
consumer cohort in the terminal LAB, requiring every such user to be a same-
clock FF.ENA and the cardinality to equal the actual guarded trial. It saves
complete original pair/terminal/cohort records, all8,221 FF BELs and every
original FF in the source, terminal and actual listed clone LABs. This is a
declared graph scope, not an exported pin-state or FF-cache proof. The later
independent comparator must derive and prove the actual selected graph again.

The selected compiler returns immediately at the requested qualified index.
Its fresh copy diagnostic prefix through that candidate must reproduce the
closed listing prefix byte for byte, followed by exactly one matching applied
line and no later copy events or listing summary. This binds all preceding
rejected cones/trials and every candidate ordinal, including nonzero selections,
without manufacturing a synthetic listing log. The original TEN complete
models and71 placement rows remain exact. Every original FF BEL remains exact.

Outputs are exclusive source-identity.json and selected/{run.json,phase.log,
placed.json,timing.json}. Actual loaded runtime/read audit, full original input
and output hashes and clean current source close before completed=true.
Partial failures retain actual exit status, partial files and final independent
rehash/runtime/source result. The predicted report must retain cap16,384,
15,290 paths and all seven actual pair/window cardinalities, with finite positive
reported Fmax. Full report equality is only recorded diagnostically; no native
path topology, selected LUT truth, physical state or timing gain is inferred.

Fresh selected graph/functional equivalence requires a separate strict proof of
one new LUT/private Q plus only declared leaf loads and ENAs, all originals and
raw IDs/order outside that scope, and independent exhaustive effective-input
truth. Placed JSON does not export PIN0/PIN1/PIN_INV, indexed-store holes or FF
controller caches. Actual physical pins/masks/shared banks/protected carry
neighbors/whole LAB FF controls require later fresh routed FES snapshots and
independent evaluation. The recorder grants no selected graph/function/cache
proof, routed gain, numerical calibration, bitstream decoding or hardware claim.
The accepted routed five-stage117.771759MHz reference remains separate.
