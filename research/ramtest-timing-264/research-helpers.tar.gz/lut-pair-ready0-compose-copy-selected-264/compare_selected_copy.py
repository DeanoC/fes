"""Inspect one selected composed copy using conditional native truth and exact slots."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
LISTING = RAW / "lut-pair-ready0-compose-copy-listing-264"
PROFILE, RUN, RUNNER = HERE / "source-identity.json", HERE / "selected/run.json", HERE / "run_selected.py"
COMPILER = RAW / "lut-pair-compose-copy-264"
COMMIT, BASE = "cae5eb9a326507b688414ba934421286f648a43b", "e137ca5bda7c5e68e6da65f37b5830d12f58727a"
BINARY_SHA = "a2b5da93a9a91cd95d411fb5773e86136ff62e1fce7896d371c97c756004885e"
ARCHIVE_SHA = "c64eb65c4e1ac01a277322bddc90172be836fddd60f2d3a0baf66bad62522dd2"
HOST_SHA = "84416288f9a9b4f85c956ad32dc264efc14d007d2d3278c3abc952a006cc6a1e"
TEST_SHA, CHECKS_SHA = "b0e912b15ebd4ce11cb56cec7a356809ce4bf84ef347851fbcccfbf978a20484", "f0b694224d40ae6eb8c081d13fd0cc1fc75c1e337bd7093168a7a3759a3b6721"
HOST_HELPER_SHA, HOST_SCOPE_SHA = "e5cf3243801bcf13f4aed5086ad4914502ed1765bbff15eedf7cf4d589157439", "071a7d054e6dafd79d92962ad0f9466d5987da9aa793a38de2b1c41f019b95a3"
LISTING_PROFILE_SHA, LISTING_RUN_SHA, LISTING_PROOF_SHA = "00c6e15c40c80d114061521d06ba0bec2b59c2ad5c5fefa2fcbb746bfaa21eeb", "c9b58c4e88e1203738ea3a9502a1d9b7c44e3d0c16c0cbd0d76ab5dd4b2b8685", "5096a9d8c58b6518a62abc887738d4ba486ce4f4783654ab040a6c0ee91c1201"
LISTING_RUNNER_SHA, LISTING_SCOPE_SHA = "e2c19bc4825083ba2d1ba8feab83d36c346ec9d6630b544cb11bb890aa440395", "7a1010462db6dabbf47e90bd303978640907fa6c3397c4d6bcdc1b2af042cdff"
LISTING_COMPARER_SHA, LISTING_COMPARISON_SCOPE_SHA = "67e64f3ee7da1a70491a2609962a6515257d1c4da544b4f83b0551d6b2ccd3f0", "c6d58dcec994c8784265c9182ed2b2e8003168653deddac5f436855747889548"
PROFILE_SHA, RUN_SHA = "f429189ff69ab9c2d9c3bf9f7a59815e530cf416a3abe9f75600dc808629ab59", "84252668b4943038526a41ee6e6694a905582bcc450cf97b9874e05b27f8438f"
RUNNER_SHA, RUNNER_SCOPE_SHA = "fec8c4b4f31827c10ec834351bae7a28ae148368c73ad9a556359a0481396d9e", "936673ca3dedb50a23f8e5a774078c4628d36d7650b3128b766210ed2c8a2556"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def bind_absolute(audit, ledger, runtime=False):
    for name, expected in ledger.items():
        path = Path(name); require(path.is_absolute(), "flat original pathname is not absolute")
        audit.bind(path, expected, execution=runtime or not path.resolve().is_relative_to(ROOT))


def bind_proof(audit, proof):
    for name, expected in proof["artifact_sha256"].items():
        path = Path(name); require(not path.is_absolute() and ".." not in path.parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    bind_absolute(audit, proof["execution_file_sha256"], True)


def order_frame(value):
    if isinstance(value, dict): return [(key, order_frame(item)) for key, item in value.items()]
    if isinstance(value, list): return [order_frame(item) for item in value]
    return None


def location(cell):
    match = re.fullmatch(r"MISTRAL_(COMB|MCOMB|FF)\.(\d+)\.(\d+)\.(\d+)", cell.get("attributes", {}).get("NEXTPNR_BEL", ""))
    return (match[1], *map(int, match.groups()[1:])) if match else None


def scalar(cell, port, direction):
    bits = cell["connections"].get(port)
    require(cell["port_directions"].get(port) == direction and type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0,
        "conditional native proof requires one connected literal signal: " + port)
    return bits[0]


def lut(cell):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    require(match is not None, "source/copy is not an ordinary ALUT2..6")
    width = int(match[1]); pins = list("ABCDEF"[:width]); directions = {pin: "input" for pin in pins} | {"Q": "output"}
    table = cell["parameters"].get("LUT")
    require(set(cell["parameters"]) == {"LUT"} and type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"} and
        cell["port_directions"] == directions and set(cell["connections"]) == set(directions), "actual logical LUT ports/table schema differs")
    return pins, int(table, 2)


def prove(native, selected, before, after, candidate, profile):
    require(set(before) == set(after) == {"creator", "modules"} and list(before) == list(after) and before["creator"] == after["creator"] and
        set(before["modules"]) == set(after["modules"]) == {"top"}, "same-compiler native root/creator differs")
    old, new = before["modules"]["top"], after["modules"]["top"]
    cells, nets = old["cells"], old["netnames"]
    old_metadata = {key: value for key, value in old.items() if key not in ("cells", "netnames")}
    new_metadata = {key: value for key, value in new.items() if key not in ("cells", "netnames")}
    require(list(old) == list(new) and native.canonical(old_metadata) == native.canonical(new_metadata) and
        order_frame(old_metadata) == order_frame(new_metadata), "top settings/controls/ports/metadata or nested order differ")
    added = set(new["cells"]) - set(cells); aliases = set(new["netnames"]) - set(nets)
    require(len(cells) == 14907 and len(new["cells"]) == 14908 and len(nets) == 16645 and len(new["netnames"]) == 16646 and
        len(added) == len(aliases) == 1 and set(cells) <= set(new["cells"]) and set(nets) <= set(new["netnames"]), "not exactly one new cell/net alias")
    clone_name, alias = next(iter(added)), next(iter(aliases)); clone = new["cells"][clone_name]
    inner_name, outer_name = candidate["inner"], candidate["outer"]
    sink_name, separator, sink_port = candidate["sink"].rpartition(".")
    require(separator and sink_port == "ENA" and inner_name != outer_name and all(name in cells for name in (inner_name, outer_name, sink_name)), "candidate original pair/FF endpoint differs")
    inner, outer, sink = (cells[name] for name in (inner_name, outer_name, sink_name))
    inner_pins, inner_mask = lut(inner); outer_pins, outer_mask = lut(outer); clone_pins, clone_mask = lut(clone)
    mid, root, q = scalar(inner, "Q", "output"), scalar(outer, "Q", "output"), scalar(clone, "Q", "output")
    require(mid != root and sink["type"] == "MISTRAL_FF" and scalar(sink, "ENA", "input") == root and location(sink), "candidate native final routing edge differs")
    inner_bits = [scalar(inner, pin, "input") for pin in inner_pins]
    outer_bits = [scalar(outer, pin, "input") for pin in outer_pins]
    require(mid in outer_bits and not any(bit in (mid, root) for bit in inner_bits) and root not in outer_bits, "composition feedback/intermediate boundary differs")
    leaves = list(dict.fromkeys(inner_bits + [bit for bit in outer_bits if bit != mid]))
    require(0 < len(leaves) <= 6 and len(clone_pins) == max(2, len(leaves)), "actual cut/copy width differs")
    drivers, users = selected.native_tables(old); after_drivers, after_users = selected.native_tables(new)
    require(all(len(drivers.get(bit, [])) == 1 for bit in leaves) and drivers.get(mid) == [(inner_name, "Q", 0, 0)] and
        drivers.get(root) == [(outer_name, "Q", 0, 0)] and q not in drivers and q not in users and
        all(q not in row["bits"] for row in nets.values()) and all(q not in row["bits"] for row in old["ports"].values()),
        "leaf/root/new Q driver/private or public identity differs")
    occupied = set(cells) | set(nets); stem = outer_name + "$lut_pair_copy"; expected = stem; suffix = 0
    while expected in occupied or expected + "$Q" in occupied:
        suffix += 1; require(suffix <= len(occupied), "paired name probe bound exceeded"); expected = stem + "$" + str(suffix)
    require(clone_name == expected and alias == clone_name + "$Q" and new["netnames"][alias] == {"hide_name": int(alias.startswith("$")), "bits": [q], "attributes": {"ROUTING": " "}} and
        [name for name, row in new["netnames"].items() if q in row["bits"]] == [alias] and
        clone["attributes"] == {"BEL_STRENGTH": "0" * 31 + "1", "NEXTPNR_BEL": candidate["clone_bel"]} and
        set(clone) == {"hide_name", "type", "parameters", "attributes", "port_directions", "connections"} and clone["hide_name"] == int(clone_name.startswith("$")), "new paired owner/sole alias/metadata differs")
    clone_site, target_site = location(clone), location(sink)
    require(clone_site and clone_site[0] in ("COMB", "MCOMB") and clone_site[3] % 6 < 2 and
        abs(clone_site[1] - target_site[1]) + abs(clone_site[2] - target_site[2]) <= 3 and
        not any((at[1], at[2], at[3] // 6) == (clone_site[1], clone_site[2], clone_site[3] // 6) for cell in cells.values() if (at := location(cell))), "new site is not an isolated previously empty serialized ALM")
    clock = scalar(sink, "CLK", "input"); cohort = []
    for slot in users.get(root, []):
        name, port, index, occurrence = slot; cell = cells[name]; at = location(cell)
        require(at is not None, "original root has an unplaced native user")
        if at[1:3] != target_site[1:3]: continue
        require(cell["type"] == "MISTRAL_FF" and port == "ENA" and index == occurrence == 0 and scalar(cell, "CLK", "input") == clock,
            "whole target LAB root cohort is not one scalar FF clock group")
        cohort.append(slot)
    cohort = sorted(cohort)
    require(cohort and (sink_name, "ENA", 0, 0) in cohort and len(cohort) == candidate["cohort"], "actual whole target cohort/count differs")
    for index, pin in enumerate(clone_pins):
        require(clone["connections"][pin] == ([leaves[index]] if index < len(leaves) else []), "copy literal leaf order/padding differs")
    rows = []
    for assignment in range(1 << len(clone_pins)):
        values = {bit: bool(assignment & (1 << index)) for index, bit in enumerate(leaves)}
        inner_row = sum(int(values[bit]) << index for index, bit in enumerate(inner_bits)); mid_value = bool(inner_mask & (1 << inner_row))
        outer_row = sum(int(mid_value if bit == mid else values[bit]) << index for index, bit in enumerate(outer_bits))
        original, copied = bool(outer_mask & (1 << outer_row)), bool(clone_mask & (1 << assignment))
        require(original == copied, "actual composed raw LUT truth differs")
        rows.append({"assignment": assignment, "inner_row": inner_row, "outer_row": outer_row, "original": int(original), "copy": int(copied)})
    expected_cells = copy.deepcopy(dict(cells))
    for name, port, index, occurrence in cohort: expected_cells[name]["connections"][port][index] = q
    require(native.canonical(expected_cells) == native.canonical({name: new["cells"][name] for name in cells}) and
        order_frame(cells) == order_frame({name: cell for name, cell in new["cells"].items() if name != clone_name}) and
        native.canonical(cells.pll_ports) == native.canonical(new["cells"].pll_ports) and
        list(cells) == [name for name in new["cells"] if name != clone_name], "original records/raw slots/paired PLL/owner or port order differ outside declared ENAs")
    require(native.canonical(nets) == native.canonical({name: new["netnames"][name] for name in nets}) and
        order_frame(nets) == order_frame({name: row for name, row in new["netnames"].items() if name != alias}) and
        list(nets) == [name for name in new["netnames"] if name != alias], "original raw aliases/metadata/order differ")
    expected_drivers, expected_users = copy.deepcopy(drivers), copy.deepcopy(users)
    expected_drivers[q] = [(clone_name, "Q", 0, 0)]
    expected_users[root] = [slot for slot in expected_users[root] if slot not in cohort]
    if not expected_users[root]: del expected_users[root]
    for index, bit in enumerate(leaves): expected_users.setdefault(bit, []).append((clone_name, clone_pins[index], 0, 0))
    expected_users[q] = cohort
    require(after_drivers == expected_drivers and after_users == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete reconstructed driver/user slots differ outside copy loads/ENA partition")
    ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in cells.items() if cell["type"] == "MISTRAL_FF"}
    require(len(ffs) == 8221 and ffs == profile["all_original_ff_bel_manifest"] and
        ffs == {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in new["cells"].items() if cell["type"] == "MISTRAL_FF"}, "all original FF placements differ")
    labs = {location(cell)[1:3] for cell in (inner, outer, sink, clone)}
    labs.update(location(cells[drivers[bit][0][0]])[1:3] for bit in leaves if location(cells[drivers[bit][0][0]]))
    whole = {str(list(lab)): {name: cell for name, cell in cells.items() if cell["type"] == "MISTRAL_FF" and location(cell)[1:3] == lab} for lab in sorted(labs)}
    return {"serialized_native_scope_proved": True, "new_clone": clone_name, "new_private_alias": alias, "actual_clone_q": q, "actual_new_clone_record": clone, "original_root_q": root,
        "original_pair": {inner_name: inner, outer_name: outer}, "declared_ena_redirects": [{"cell": name, "port": port, "vector_index": index, "occurrence": occurrence,
            "old_raw_bit": root, "new_raw_bit": q, "clock_raw_bit": clock, "before_record": cells[name], "after_record": new["cells"][name]} for name, port, index, occurrence in cohort],
        "declared_ena_redirect_count": len(cohort), "leaf_raw_bits": leaves, "assignments_checked": len(rows), "conditional_truth_rows": rows,
        "conditional_plain_sig_raw_composition_proved": True, "actual_packed_input_constants_and_inversions_exported": False,
        "condition": "Connected source/copy input signals have their native logical polarity. Packed constants/inversions and FF ENA polarity require routed pin snapshots.",
        "padding_independent_for_all_boolean_values": True, "all_original_ff_placements_exact": True, "all_original_records_exact_except_declared_ena_slots": True,
        "complete_original_owner_port_alias_order_exact": True, "complete_raw_driver_user_slots_exact_except_declared_changes": True,
        "whole_original_ff_lab_manifest": whole, "serialized_clone_alm_previously_empty": True,
        "packed_physical_truth_proved": False, "unexported_cache_or_indexed_user_storage_holes_proved": False,
        "independent_numeric_sta_or_hold_margin_proved": False, "routed_gain_accepted": False}


def closed_record(native, record, profile, path, expected, execution_key):
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
        record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == expected and
        record["execution"] == profile[execution_key] and record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "actual record is not its exact closed profile/inputs/runtime")


def diagnostic(error):
    return {"exception_type": type(error).__name__, "reason": str(error)}


def compare(self_sha, scope_sha, profile_sha, run_sha, runner_sha, runner_scope_sha):
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in
        (LISTING_PROFILE_SHA, LISTING_RUN_SHA, LISTING_PROOF_SHA, LISTING_RUNNER_SHA, LISTING_SCOPE_SHA, LISTING_COMPARER_SHA,
         LISTING_COMPARISON_SCOPE_SHA, PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA)) and
        (profile_sha, run_sha, runner_sha, runner_scope_sha) == (PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA), "actual listing/selection activation identities remain UNFROZEN or differ")
    native = load(NATIVE, NATIVE_SHA, "selected_compose_native_pure"); audit = native.Audit()
    listing_profile_path, listing_run_path = LISTING / "source-identity.json", LISTING / "listing/run.json"
    listing_proof_path = LISTING / "listing/comparison-copy-listing.json"; host_path = COMPILER / "validation/host-validation.json"
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha), (PROFILE, profile_sha), (RUN, run_sha),
        (RUNNER, runner_sha), (HERE / "scope.md", runner_scope_sha), (listing_profile_path, LISTING_PROFILE_SHA), (listing_run_path, LISTING_RUN_SHA),
        (listing_proof_path, LISTING_PROOF_SHA), (LISTING / "run_listing.py", LISTING_RUNNER_SHA), (LISTING / "scope.md", LISTING_SCOPE_SHA),
        (LISTING / "compare_copy_listing.py", LISTING_COMPARER_SHA), (LISTING / "comparison-scope.md", LISTING_COMPARISON_SCOPE_SHA),
        (host_path, HOST_SHA), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (COMPILER / "nextpnr-mistral", BINARY_SHA), (COMPILER / "source.tar.gz", ARCHIVE_SHA), (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    profile, record, previous_profile, previous, prerequisite, host = (native.read(path) for path in
        (PROFILE, RUN, listing_profile_path, listing_run_path, listing_proof_path, host_path))
    closed_record(native, previous, previous_profile, listing_profile_path, LISTING_PROFILE_SHA, "listing_execution")
    closed_record(native, record, profile, PROFILE, profile_sha, "selected_execution")
    require(prerequisite["schema"] == 1 and prerequisite["phase"] == "lut-pair-ready0-compose-copy-listing-native-reproduction" and
        prerequisite["source_identity_sha256"] == LISTING_PROFILE_SHA and prerequisite["current_copy_listing_run_sha256"] == LISTING_RUN_SHA and
        prerequisite["compiler_commit"] == COMMIT and prerequisite["delta_base_commit"] == BASE and prerequisite["host_validation_sha256"] == HOST_SHA and
        prerequisite["generator_sha256"] == LISTING_COMPARER_SHA and prerequisite["scope_sha256"] == LISTING_COMPARISON_SCOPE_SHA and
        prerequisite["recorder_sha256"] == LISTING_RUNNER_SHA and prerequisite["recorder_scope_sha256"] == LISTING_SCOPE_SHA and
        prerequisite["current_actual_execution"] == previous["execution"] and
        prerequisite["structural_rejection"] is prerequisite["model_or_copy_listing_rejection"] is prerequisite["native_path_topology_rejection"] is None and
        all(prerequisite[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
            "all_71_placement_metrics_exact", "complete_predicted_report_exact", "fresh_lut_pair_copy_listing_reproduction_proved", "final_original_path_metadata_and_runtime_hashes_stable")) and
        prerequisite["reference_proof_sha256"] == {"endpoint_diagnostic": "12a957094445aa1e0eb12409abce889a4a69ba0d9f486f43251498aab0f347d8",
            "original_listing": "94627ac9a7ce2d8df01549d673233e914326fed48e9dd538042e5a37597f50d5", "disabled_control": "9498fb62edd6a9a25a3d8db137f1b7c32cc03dccd3be5a81233be639c81a196e"}, "fresh exact listing reproduction prerequisite is not positive")
    bind_proof(audit, prerequisite)
    counts = {"pair_backend": 12, "copy_backend": 11, "native_plan": 25, "driver_backend": 10, "pair_cli": 17, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and host["binary_sha256"] == BINARY_SHA and
        host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and host["check_results_sha256"] == CHECKS_SHA and
        host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        set(host["checks"]) == set(counts) and all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
        all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"], "current source/build/host check closure differs")
    for key in HOST_MAPS: bind_absolute(audit, host[key])
    for entry, folder in ((previous, LISTING / "listing"), (record, RUN.parent)):
        require(set(entry["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")}, "closed output triplet differs")
        bind_absolute(audit, entry["input_sha256"]); bind_absolute(audit, entry["output_sha256"]); bind_absolute(audit, entry["execution"]["files"], True)
    runner = load(RUNNER, runner_sha, "selected_compose_recorder_pure")
    listing, control, parsers = runner.definitions()
    pure = ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (RUNNER, runner_sha),
        (LISTING / "run_listing.py", LISTING_RUNNER_SHA), (RAW / "lut-pair-ten-control-264/run_baseline.py", "f72f98877a989f2457800989a69de7ef24d449cac4f6af759abc34a8ca447b13"), *control.PARSERS)
    for path, expected in pure:
        audit.bind(path, expected)
        if path not in (NATIVE, SELECTED, FREEZE): require(profile["input_sha256"].get(str(path)) == expected, "called current pure parser is outside selected input closure")
    for name, expected in listing.SCRIPTS.items():
        path = ROOT / "sources/misteross/scripts" / name; audit.bind(path, expected)
        require(profile["input_sha256"].get(str(path)) == expected, "executed project module is outside input closure")
    candidate, selection = profile["expected_candidate"], profile["pair_candidate_selection"]
    require(type(selection) is int and selection >= 0 and candidate["candidate"] == selection and
        candidate in previous["actual_pair_copy_listing"]["actual_qualified_candidates"] and
        native.canonical(prerequisite["actual_pair_copy_listing"]) == native.canonical(previous["actual_pair_copy_listing"]), "explicit chosen actual qualified listing candidate differs")
    require(profile["schema"] == 1 and profile["phase"] == "lut-pair-ready0-compose-copy-explicit-predicted-selection" and
        profile["command"] == runner.command(previous, selection) and profile["selected_execution"] == record["execution"] == previous["execution"] == runner.expected_execution(previous) and
        profile["cwd"] == previous["cwd"] == str(ROOT / "sources/misteross") and profile["diagnostic_environment"] == previous["diagnostic_environment"] and
        all(profile[key] == expected for key, expected in (("compiler_commit", COMMIT), ("delta_base_commit", BASE), ("binary_sha256", BINARY_SHA),
            ("source_archive_sha256", ARCHIVE_SHA), ("host_validation_sha256", HOST_SHA), ("helper_sha256", runner_sha), ("scope_sha256", runner_scope_sha),
            ("listing_profile_sha256", LISTING_PROFILE_SHA), ("listing_run_sha256", LISTING_RUN_SHA), ("listing_proof_sha256", LISTING_PROOF_SHA))) and
        profile["retained_copy_cohorts"] == previous["retained_copy_cohorts"] and profile["all_original_ff_bel_manifest"] == previous["all_original_ff_bel_manifest"] and
        profile["local_plan_steps"] == previous["local_plan_steps"] and profile["original_plan_path"] == previous["original_plan_path"] and
        profile["original_plan_sha256"] == previous["original_plan_sha256"] and profile["guide_path"] == previous["guide_path"] and profile["guide_sha256"] == previous["guide_sha256"] and
        profile["exact_current_path_object"] == previous["exact_current_path_object"], "current selected invocation/source/reference roles differ")
    guide, plan = Path(profile["guide_path"]), Path(profile["original_plan_path"])
    audit.bind(guide, profile["guide_sha256"]); audit.bind(plan, profile["original_plan_sha256"])
    require(native.read(guide) == {"critical_paths": [profile["exact_current_path_object"]]} and native.read(plan) == {"steps": profile["local_plan_steps"]} and
        len(profile["local_plan_steps"]) == 10 and len(profile["all_original_ff_bel_manifest"]) == 8221 and
        all(audit.paths.get(Path(path)) == expected for path, expected in profile["input_sha256"].items()), "original TEN/guide/full input closure differs")
    log = (RUN.parent / "phase.log").read_text(); listing_log = (LISTING / "listing/phase.log").read_text()
    models, observed, model_rejection = None, None, None
    try:
        listing_models, listing_observed = listing.qualification(listing_log, control, parsers)
        require(native.canonical(listing_observed) == native.canonical(previous["actual_pair_copy_listing"]) and
            native.canonical(listing_models) == native.canonical(previous["actual_selected_local_qualification"]), "immutable listing log reparse differs")
        models, observed = runner.qualification(log, listing, control, parsers, candidate, profile["expected_copy_prefix"])
        require(native.canonical(observed) == native.canonical(record["actual_selected_pair_copy_qualification"]) and observed["candidate_applied"] is True and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) == native.canonical(listing_models), "actual selected prefix/guarded candidate/model binding differs")
    except (ValueError, TypeError, KeyError, IndexError) as error: model_rejection = diagnostic(error)
    metrics, previous_metrics = native.PLACEMENT_METRICS.findall(log), native.PLACEMENT_METRICS.findall(listing_log)
    metrics_exact = len(metrics) == len(previous_metrics) == 71 and metrics == previous_metrics
    report, previous_report = native.read(RUN.parent / "timing.json"), native.read(LISTING / "listing/timing.json")
    before, after = native.read_netlist(LISTING / "listing/placed.json"), native.read_netlist(RUN.parent / "placed.json")
    frozen = load(FREEZE, FREEZE_SHA, "selected_compose_freeze_pure"); selected = load(SELECTED, SELECTED_SHA, "selected_compose_tables_pure", frozen)
    evidence, structural_rejection = None, None
    try:
        evidence = prove(native, selected, before, after, candidate, profile)
        cohort = [{"cell": row["cell"], "port": "ENA", "index": 0, "bit": row["old_raw_bit"], "record": row["before_record"]} for row in evidence["declared_ena_redirects"]]
        require(profile["declared_original_lut_pair"] == [{"cell": candidate[key], "record": before["modules"]["top"]["cells"][candidate[key]]} for key in ("inner", "outer")] and
            profile["declared_ena_cohort"] == cohort and profile["fixed_terminal_ff"] == {"cell": candidate["sink"].rsplit(".", 1)[0], "record": before["modules"]["top"]["cells"][candidate["sink"].rsplit(".", 1)[0]]} and
            profile["declared_root_q"] == evidence["original_root_q"] and profile["declared_clock_q"] == evidence["declared_ena_redirects"][0]["clock_raw_bit"], "prepared original pair/cohort/FF scope differs from independent native reconstruction")
        labs = profile["affected_whole_labs"]
        require(labs == sorted(labs) and len(labs) == len(set(map(tuple, labs))) and all(type(lab) is list and len(lab) == 2 and all(type(v) is int and v >= 0 for v in lab) for lab in labs), "declared whole LAB list is malformed")
        lab_ffs = [{"cell": name, "record": cell} for name, cell in before["modules"]["top"]["cells"].items() if cell["type"] == "MISTRAL_FF" and list(location(cell)[1:3]) in labs]
        expected_labs = sorted({location(before["modules"]["top"]["cells"][candidate[key]])[1:3] for key in ("inner", "outer")} |
            {location(before["modules"]["top"]["cells"][candidate["sink"].rsplit(".", 1)[0]])[1:3],
             location(after["modules"]["top"]["cells"][evidence["new_clone"]])[1:3]})
        require(labs == [list(lab) for lab in expected_labs] and profile["all_original_ff_members_in_affected_labs"] == lab_ffs,
            "declared original pair/target/clone whole-LAB FF records are not exact")
    except (ValueError, TypeError, KeyError, IndexError) as error: structural_rejection = diagnostic(error)
    topologies, topology_rejections = {}, {}
    for name, document, data in (("listing", before, previous_report), ("selected", after, report)):
        try:
            topologies[name] = selected.report_topology(document, data, previous_report)
            require(data["timing_report_paths"] == 16384 and topologies[name]["current_report_paths"] == 15290 and len(topologies[name]["domain_pair_endpoint_counts"]) == 7,
                "complete actual native path/clock/window coverage differs")
        except (ValueError, TypeError, KeyError, IndexError) as error: topology_rejections[name] = diagnostic(error)
    models_exact = model_rejection is None and len(models) == 10 and native.canonical(models) == native.canonical(profile["retained_local_models"])
    ffs_exact = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in after["modules"]["top"]["cells"].items() if cell["type"] == "MISTRAL_FF"} == profile["all_original_ff_bel_manifest"]
    require(record["all_ten_complete_trial_models_exact"] is models_exact and record["all_71_placement_metrics_exact"] is metrics_exact and
        record["all_original_ff_bels_exact"] is ffs_exact and record["actual_predicted_fmax"] == report["fmax"] and "Info: Program finished normally." in log and
        not any(line.startswith("ERROR:") for line in log.splitlines()) and log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
        not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step")) and
        not any((RUN.parent / name).exists() for name in ("core.rbf", "routed.json")), "actual selected completion/diagnostic flags differ")
    audit.finish(); positive = structural_rejection is model_rejection is None and not topology_rejections and models_exact and metrics_exact and ffs_exact
    return {"schema": 1, "phase": "lut-pair-ready0-selected-composed-copy-conditional-native-proof", "source_identity_sha256": profile_sha,
        "current_selected_run_sha256": run_sha, "compiler_commit": COMMIT, "delta_base_commit": BASE, "host_validation_sha256": HOST_SHA,
        "generator_sha256": self_sha, "scope_sha256": scope_sha, "recorder_sha256": runner_sha, "recorder_scope_sha256": runner_scope_sha,
        "listing_profile_sha256": LISTING_PROFILE_SHA, "listing_run_sha256": LISTING_RUN_SHA, "listing_proof_sha256": LISTING_PROOF_SHA,
        "actual_candidate_selection": selection, "actual_chosen_candidate": candidate, "candidate_completed": True, "current_actual_execution": record["execution"],
        "structural_rejection": structural_rejection, "model_or_selected_prefix_rejection": model_rejection, "native_path_topology_rejection": topology_rejections or None,
        "native_graph_proof_available": structural_rejection is None, "native_graph_evidence": evidence, "actual_selected_pair_copy_qualification": observed,
        "fresh_local_models": models, "all_ten_complete_trial_models_exact": models_exact, "all_71_placement_metrics_exact": metrics_exact,
        "all_original_ff_bels_exact": ffs_exact, "current_predicted_native_paths": topologies, "actual_predicted_fmax": report["fmax"],
        "complete_predicted_report_exact_diagnostic": native.canonical(report) == native.canonical(previous_report),
        "selected_native_graph_and_conditional_function_proved": positive, "fresh_full_route_prerequisite_under_plain_sig_condition": positive,
        "actual_packed_pin_or_physical_truth_proved": False, "unexported_cache_or_user_storage_holes_proved": False,
        "independent_numerical_sta_or_hold_margin_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "pure_function_helper_sha256": {str(path): expected for path, expected in pure}, "artifact_sha256": dict(sorted(audit.artifacts.items())),
        "execution_file_sha256": dict(sorted(audit.execution.items())), "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "run-sha256", "runner-sha256", "runner-scope-sha256"): parser.add_argument("--" + name, required=True)
    args = parser.parse_args(); require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual SHA activation pins required")
    output = HERE / "selected/comparison-selected-copy.json"; require(not output.exists(), "immutable selected copy comparison exists")
    result = compare(args.self_sha256, args.scope_sha256, args.profile_sha256, args.run_sha256, args.runner_sha256, args.runner_scope_sha256)
    with output.open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "selected_native_graph_and_conditional_function_proved": result["selected_native_graph_and_conditional_function_proved"]}, indent=2))


if __name__ == "__main__": main()
