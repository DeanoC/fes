"""Require exact native and predicted-report reproduction after a fresh pair listing."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE, RUN = HERE / "source-identity.json", HERE / "listing/run.json"
RUNNER, GUIDE = HERE / "run_listing.py", HERE / "ready0-guide.json"
CONTROL, COMPILER = RAW / "lut-pair-ten-control-264", RAW / "lut-pair-placement-264"
CONTROL_PROFILE, CONTROL_RUN, CONTROL_PROOF = CONTROL / "source-identity.json", CONTROL / "baseline/run.json", CONTROL / "baseline/comparison-control.json"
COMMIT, BASE = "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc", "b3d036549c29a333e67c61bd1b23e705bce75d41"
BINARY_SHA, ARCHIVE_SHA, HOST_SHA = "1b4e45ac1adc5adf9be8edcfa67b922d7626504dc0bbc73f24ffb69b263f4b1f", "2c8c190cab4556232cf0230213a83122fc22af6af19b76590392732eb6df6c8c", "c77030ec24ef18fc1dc64f85ad05b3e0841866cb9d03ecf46c7cc75586f415d6"
TEST_SHA, CHECKS_SHA = "5221d767e061623bb48699370b548cb2d5fa76291d318f3af20da64a1c0ae41f", "ca75e70399796e6937e9925d6470ff84916630abab741faae2b54177f687ae2d"
PROFILE_SHA, RUN_SHA = "53f82bb5adc3bcac143097cade72eefbbb076344cb4243c31f109cd8993b9103", "15e5a0c3e188811d870201e204b0cb0b9dcfadca545d0b051d2580f62e5f2fe4"
RUNNER_SHA, RUNNER_SCOPE_SHA = "6a053c8b28d5fa20ede4ba5ffdfe72f45bba48128931242407e380ac874b4964", "fb6d6ab4ce4ac93ac5d7293da2773b6756d898b1831531b7eff02b64d9a15c19"
CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA = "d8c15d6b1ec82481f4dd3131136a8e7a913488a9f2961ec5da2f9e9a19f16413", "581f3dd629fc00c7887bca7b6d8415fec214ce1cbe042c754e9eff776dbe3caa", "9498fb62edd6a9a25a3d8db137f1b7c32cc03dccd3be5a81233be639c81a196e"
CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA = "f72f98877a989f2457800989a69de7ef24d449cac4f6af759abc34a8ca447b13", "90494f8f0085b28b1d3a762508b09dff66396fab5c29994a869a319c3eaee903"
CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA = "1350e1ae0913ded6504c44bf3b75174c5121a06995e8c2924162d9a59864da2e", "a9a8951997616e288371ca9532bb573b136704f2f880b0a69e9ba9453f1cf1b2"
HOST = COMPILER / "validation/host-validation.json"
HOST_HELPER_SHA = "80af57eefb926577426c7043e46a438b938c282b5bb57d87301e88a9a7467d1c"
HOST_SCOPE_SHA = "a32cf00ffef05c9260c2b1ffea9668bd83db231bc35a89e10fb6741b5eb98c98"
FAMILY = RAW / "local-plan16-ready0-skid-burst-guide-264/ready0-guide.json"
FAMILY_SHA = "e2dde3c95c202aa2dc811100aa67c29b9ef0a0b918bf9002b1d7778684643bb7"
PLAN = RAW / "local-plan16-ready1-command-stage-264/local-plan.json"
PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
             "build_dependency_manifest_sha256", "build_dependency_file_sha256")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def bind_absolute(audit, ledger, runtime=False):
    for name, expected in ledger.items():
        path = Path(name)
        require(path.is_absolute(), "flat original pathname is not absolute")
        audit.bind(path, expected, execution=runtime or not path.resolve().is_relative_to(ROOT))


def bind_proof(audit, proof):
    for name, expected in proof["artifact_sha256"].items():
        path = Path(name)
        require(not path.is_absolute() and ".." not in path.parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    bind_absolute(audit, proof["execution_file_sha256"], True)


def closed_record(native, record, profile, profile_path, profile_sha, execution_key):
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == profile_sha and
            record["execution"] == profile[execution_key] and
            record["input_sha256"] == {**profile["input_sha256"], str(profile_path): profile_sha} and
            all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")),
            "record is not its closed exact profile/input-union/runtime")


def order_frame(value):
    if isinstance(value, dict):
        return [(key, order_frame(item)) for key, item in value.items()]
    if isinstance(value, list):
        return [order_frame(item) for item in value]
    return None


def prove_module(native, selected, before, after, manifest):
    require(set(before) == set(after) == {"creator", "modules"} and set(before["modules"]) == set(after["modules"]) == {"top"} and
            type(before["creator"]) is type(after["creator"]) is str and before["creator"] == after["creator"],
            "complete document shape or current-compiler creator differs")
    a, b = before["modules"]["top"], after["modules"]["top"]
    require(len(a["cells"]) == len(b["cells"]) == 14907 and len(a["netnames"]) == len(b["netnames"]) == 16645 and
            native.canonical(before) == native.canonical(after), "complete native document/metadata/cells/nets/raw IDs differ")
    require(order_frame(before) == order_frame(after) and native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "native document/owner/port/nested metadata order or paired PLL entries differ")
    require(selected.native_tables(a) == selected.native_tables(b), "complete raw driver/user slot tables differ")
    ffs = [{name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"}
           for top in (a, b)]
    require(len(manifest) == 8221 and ffs[0] == ffs[1] == manifest, "all8221 original FF names/BELs differ")
    return {"complete_native_document_and_creator_exact": True, "all_native_metadata_and_owner_port_order_exact": True,
        "lossless_paired_pll_entries_exact": True, "native_driver_and_user_slot_tables_exact": True,
        "all_original_ff_records_and_bels_exact": True, "original_ff_count": 8221, "cells": 14907, "netnames": 16645,
        "native_field_waiver_or_raw_id_alignment_used": False, "unexported_physical_state_proved": False}


def diagnostic(error):
    return {"exception_type": type(error).__name__, "reason": str(error)}


def compare(self_sha, scope_sha, profile_sha, run_sha, runner_sha, runner_scope_sha):
    pins = (BINARY_SHA, ARCHIVE_SHA, HOST_SHA, TEST_SHA, CHECKS_SHA, PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA,
            CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA, CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA,
            CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA)
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in pins),
            "actual completed listing/control/compiler pins remain UNFROZEN")
    require((profile_sha, run_sha, runner_sha, runner_scope_sha) == (PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA),
            "actual listing activation pins differ")
    native = load(NATIVE, NATIVE_SHA, "pair_listing_native_pure")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha), (PROFILE, profile_sha),
            (RUN, run_sha), (RUNNER, runner_sha), (HERE / "scope.md", runner_scope_sha), (CONTROL_PROFILE, CONTROL_PROFILE_SHA),
            (CONTROL_RUN, CONTROL_RUN_SHA), (CONTROL_PROOF, CONTROL_PROOF_SHA), (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA),
            (CONTROL / "scope.md", CONTROL_SCOPE_SHA), (CONTROL / "compare_control.py", CONTROL_COMPARER_SHA),
            (CONTROL / "comparison-scope.md", CONTROL_COMPARISON_SCOPE_SHA), (HOST, HOST_SHA),
            (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
            (COMPILER / "nextpnr-mistral", BINARY_SHA), (COMPILER / "source.tar.gz", ARCHIVE_SHA), (FAMILY, FAMILY_SHA), (PLAN, PLAN_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    runner = load(RUNNER, runner_sha, "pair_listing_recorder_pure")
    profile, record, control_profile, control_record, proof, host = (native.read(path) for path in
        (PROFILE, RUN, CONTROL_PROFILE, CONTROL_RUN, CONTROL_PROOF, HOST))
    closed_record(native, record, profile, PROFILE, profile_sha, "listing_execution")
    closed_record(native, control_record, control_profile, CONTROL_PROFILE, CONTROL_PROFILE_SHA, "baseline_execution")
    require((runner.COMMIT, runner.BASE, runner.BINARY_SHA, runner.ARCHIVE_SHA, runner.HOST_SHA) ==
            (COMMIT, BASE, BINARY_SHA, ARCHIVE_SHA, HOST_SHA) and
            (runner.CONTROL_PROFILE_SHA, runner.CONTROL_RUN_SHA, runner.CONTROL_PROOF_SHA, runner.CONTROL_HELPER_SHA,
             runner.CONTROL_SCOPE_SHA, runner.CONTROL_COMPARER_SHA, runner.CONTROL_COMPARISON_SCOPE_SHA) ==
            (CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA, CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA,
             CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA), "pure listing recorder identity differs")
    require(proof["schema"] == 1 and proof["phase"] == "lut-pair-disabled-ten-stage-native-control" and
            proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and proof["current_baseline_run_sha256"] == CONTROL_RUN_SHA and
            proof["generator_sha256"] == CONTROL_COMPARER_SHA and proof["scope_sha256"] == CONTROL_COMPARISON_SCOPE_SHA and
            proof["recorder_sha256"] == CONTROL_HELPER_SHA and proof["recorder_scope_sha256"] == CONTROL_SCOPE_SHA and
            proof["compiler_commit"] == COMMIT and proof["delta_base_commit"] == BASE and proof["host_validation_sha256"] == HOST_SHA and
            proof["current_actual_execution"] == control_record["execution"] and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and
            all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
                "all_71_placement_metrics_exact", "complete_predicted_report_exact", "fresh_lut_pair_control_prerequisite_proved",
                "final_original_path_metadata_and_runtime_hashes_stable")) and
            all(proof[key] == {"d7e_original_ten": True, "b3d_disabled_post_ten": True} for key in
                ("ten_model_equality_by_reference", "placement_metric_equality_by_reference", "complete_report_equality_by_reference")),
            "current fresh dual-reference control prerequisite is not positive")
    counts = {"pair_backend": 12, "native_plan": 25, "driver_backend": 10, "pair_cli": 11, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
            host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and
            host["check_results_sha256"] == CHECKS_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
            host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and set(host["checks"]) == set(counts) and
            all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
            all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"] and
            all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in host["committed_archive_manifest_sha256"]),
            "current independent source/archive/dependency/host check qualification differs")
    bind_proof(audit, proof)
    for entry in (profile, control_profile, record, control_record):
        bind_absolute(audit, entry["input_sha256"])
    for entry, folder in ((record, RUN.parent), (control_record, CONTROL_RUN.parent)):
        require(set(entry["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")}, "actual output set differs")
        bind_absolute(audit, entry["output_sha256"])
        bind_absolute(audit, entry["execution"]["files"], True)
    for key in HOST_MAPS:
        bind_absolute(audit, host[key])
    require(profile["phase"] == "lut-pair-ready0-single-path-predicted-listing" and
            control_profile["phase"] == "lut-pair-disabled-ten-stage-predicted-control" and profile["schema"] == control_profile["schema"] == 1 and
            profile["command"] == runner.command(control_record) and record["execution"] == control_record["execution"] and
            profile["cwd"] == control_record["cwd"] == str(ROOT / "sources/misteross") and
            profile["diagnostic_environment"] == control_record["diagnostic_environment"] and
            all(profile[key] == control_profile[key] == expected for key, expected in
                (("compiler_commit", COMMIT), ("delta_base_commit", BASE), ("binary_sha256", BINARY_SHA),
                 ("source_archive_sha256", ARCHIVE_SHA), ("host_validation_sha256", HOST_SHA))) and
            profile["helper_sha256"] == runner_sha and profile["scope_sha256"] == runner_scope_sha and
            profile["control_profile_sha256"] == CONTROL_PROFILE_SHA and profile["control_run_sha256"] == CONTROL_RUN_SHA and
            profile["control_proof_sha256"] == CONTROL_PROOF_SHA and profile["control_recorder_sha256"] == CONTROL_HELPER_SHA and
            profile["control_recorder_scope_sha256"] == CONTROL_SCOPE_SHA and profile["control_comparer_sha256"] == CONTROL_COMPARER_SHA and
            profile["control_comparison_scope_sha256"] == CONTROL_COMPARISON_SCOPE_SHA and profile["pair_candidate_selection"] == -1 and
            all(profile[key] is False for key in ("post_plan_requested", "driver_pass_executed", "native_or_physical_reproduction_inherited", "routed_gain_accepted", "hardware_tested")),
            "fresh listing profile/command/source/runtime roles differ")
    control, definitions = runner.control_definitions()
    require((control.COMMIT, control.BASE, control.BINARY_SHA, control.ARCHIVE_SHA, control.HOST_SHA) ==
            (COMMIT, BASE, BINARY_SHA, ARCHIVE_SHA, HOST_SHA) and set(host["changed_source_files"]) == control.CHANGED,
            "called current parser/source identity differs")
    for path, expected in control.PARSERS:
        audit.bind(path, expected)
        require(profile["input_sha256"].get(str(path)) == expected, "called parser is outside frozen listing input closure")
    for name, expected in runner.SCRIPTS.items():
        path = ROOT / "sources/misteross/scripts" / name
        audit.bind(path, expected)
        require(profile["input_sha256"].get(str(path)) == expected, "executed project module is outside frozen input closure")
    require(all(audit.paths.get(Path(path)) == expected for path, expected in profile["input_sha256"].items()) and
            audit.paths.get(runner.BINARY) == BINARY_SHA and audit.paths.get(runner.ARCHIVE) == ARCHIVE_SHA,
            "current original-path source/artifact/runtime closure is incomplete")
    plan = native.read(PLAN)
    require(profile["original_plan_path"] == control_profile["original_plan_path"] == str(PLAN) and
            profile["original_plan_sha256"] == control_profile["original_plan_sha256"] == PLAN_SHA and set(plan) == {"steps"} and
            plan["steps"] == profile["local_plan_steps"] == control_profile["local_plan_steps"] and len(plan["steps"]) == 10 and
            [step["groups"] for step in plan["steps"]] == [8] + [1] * 9 and
            all(set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and step["candidate"] == 0 and
                step["optimize_pins"] is False and step["preserve_ff_placement"] is True and Path(step["report"]) in audit.paths for step in plan["steps"]) and
            profile["retained_copy_cohorts"] == control_profile["retained_copy_cohorts"] and
            profile["all_original_ff_bel_manifest"] == control_profile["all_original_ff_bel_manifest"], "literal ten-stage plan/cohorts/FF manifest differs")
    before_report, report = native.read(CONTROL_RUN.parent / "timing.json"), native.read(RUN.parent / "timing.json")
    family, guide = native.read(FAMILY), native.read(GUIDE)
    index = profile["current_report_matched_path_index"]
    require(type(index) is int and 0 <= index < len(before_report["critical_paths"]) and len(family["critical_paths"]) == 1,
            "current path index or frozen family guide differs")
    path, signature = before_report["critical_paths"][index], runner.routing_signature(family["critical_paths"][0])
    require(profile["family_guide_path"] == str(FAMILY) and profile["family_guide_sha256"] == FAMILY_SHA and
            profile["guide_path"] == str(GUIDE) and audit.paths.get(GUIDE) == profile["guide_sha256"] and
            profile["guide_contains_only_one_current_critical_path"] is True and profile["historical_routed_metadata_copied"] is False and
            profile["matched_routing_edge_signature"] == signature == runner.routing_signature(path) and
            sum(runner.routing_signature(row) == signature for row in before_report["critical_paths"]) == 1 and
            native.canonical(guide) == native.canonical({"critical_paths": [path]}) and native.canonical(path) == native.canonical(profile["exact_current_path_object"]),
            "single guide is not the unique complete unchanged current control path")
    before_log, log = (CONTROL_RUN.parent / "phase.log").read_text(), (RUN.parent / "phase.log").read_text()
    old_models = control.qualification(before_log, definitions)
    require(native.canonical(old_models) == native.canonical(control_record["actual_selected_local_qualification"]) ==
            native.canonical(proof["fresh_local_models"]) == native.canonical(profile["retained_local_models"]) and len(old_models) == 10,
            "current closed control's complete model provenance differs")
    models, listing, model_rejection = None, None, None
    try:
        models, listing = runner.qualification(log, control, definitions)
        require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
                native.canonical(listing) == native.canonical(record["actual_pair_listing"]), "recorded actual listing/trial bindings differ")
    except (ValueError, TypeError, KeyError, IndexError) as error:
        model_rejection = diagnostic(error)
    models_exact = model_rejection is None and native.canonical(models) == native.canonical(old_models)
    metrics = native.PLACEMENT_METRICS.findall(log)
    old_metrics = native.PLACEMENT_METRICS.findall(before_log)
    metrics_exact = len(metrics) == len(old_metrics) == 71 and metrics == old_metrics
    report_exact = native.canonical(report) == native.canonical(before_report)
    recorded_diagnostics_exact = (record["all_ten_complete_trial_models_exact"] is models_exact and
        record["all_71_placement_metrics_exact"] is metrics_exact and record["complete_predicted_report_exact_diagnostic"] is report_exact)
    frozen = load(FREEZE, FREEZE_SHA, "pair_listing_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "pair_listing_selected_pure", frozen)
    before_doc, document = native.read_netlist(CONTROL_RUN.parent / "placed.json"), native.read_netlist(RUN.parent / "placed.json")
    evidence, rejection, topology, topology_rejections = None, None, {}, {}
    try:
        evidence = prove_module(native, selected, before_doc, document, profile["all_original_ff_bel_manifest"])
    except (ValueError, TypeError, KeyError, IndexError) as error:
        rejection = diagnostic(error)
    for name, doc, data in (("current_disabled_control", before_doc, before_report), ("fresh_pair_listing", document, report)):
        try:
            topology[name] = selected.report_topology(doc, data, before_report)
            require(topology[name]["current_report_paths"] == 15290 and len(topology[name]["domain_pair_endpoint_counts"]) == 7,
                    "complete native path count/clock-pair set differs")
        except (ValueError, TypeError, KeyError, IndexError) as error:
            topology_rejections[name] = diagnostic(error)
    require(report["timing_report_paths"] == before_report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            record["actual_predicted_fmax"] == report["fmax"] and "Info: Program finished normally." in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis",
                "LUT driver copy", "Local-remap post-plan step", "LUT pair placement applied candidate")) and
            not any((RUN.parent / name).exists() for name in ("core.rbf", "routed.json")), "actual listing is not final predicted-only completion")
    audit.finish()
    positive = (rejection is None and model_rejection is None and not topology_rejections and models_exact and metrics_exact and
                report_exact and recorded_diagnostics_exact and listing["candidate_applied"] is False)
    return {"schema": 1, "phase": "lut-pair-ready0-listing-native-reproduction", "source_identity_sha256": profile_sha,
        "current_listing_run_sha256": run_sha, "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": CONTROL_RUN_SHA,
        "control_proof_sha256": CONTROL_PROOF_SHA, "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "generator_sha256": self_sha, "scope_sha256": scope_sha, "recorder_sha256": runner_sha, "recorder_scope_sha256": runner_scope_sha,
        "host_validation_sha256": HOST_SHA, "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "current_actual_execution": record["execution"], "creator_strings": {"control": before_doc["creator"], "listing": document["creator"]},
        "creator_difference_permitted": False, "reference_local_models": old_models, "fresh_local_models": models,
        "actual_pair_listing": listing, "model_or_listing_rejection": model_rejection,
        "all_ten_complete_trial_models_exact": models_exact, "all_71_placement_metrics_exact": metrics_exact,
        "placement_metric_rows": metrics, "reference_placement_metric_rows": old_metrics, "recorded_reproduction_diagnostics_exact": recorded_diagnostics_exact,
        "structural_rejection": rejection, "native_graph_proof_available": rejection is None, "native_graph_evidence": evidence,
        "current_predicted_native_paths": topology, "native_path_topology_rejection": topology_rejections or None,
        "complete_predicted_report_exact": report_exact, "actual_predicted_fmax": report["fmax"],
        "fresh_lut_pair_listing_reproduction_proved": positive, "raw_id_alignment_or_native_field_waiver_used": False,
        "selected_candidate_accepted": False, "independent_physical_equivalence_proved": False, "independent_numerical_sta_proved": False,
        "routed_gain_accepted": False, "hardware_tested": False,
        "pure_function_helper_sha256": {str(path): expected for path, expected in
            ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (RUNNER, runner_sha),
             (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA), *control.PARSERS)},
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "run-sha256", "runner-sha256", "runner-scope-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual SHA activation pins required")
    output = HERE / "listing/comparison-listing.json"
    require(not output.exists(), "immutable listing comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.profile_sha256, args.run_sha256, args.runner_sha256, args.runner_scope_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "complete_predicted_report_exact": result["complete_predicted_report_exact"],
        "fresh_lut_pair_listing_reproduction_proved": result["fresh_lut_pair_listing_reproduction_proved"]}, indent=2))


if __name__ == "__main__":
    main()
