"""Record one fresh ready0 pair listing only after strict disabled-control parity."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-placement-264"
COMPILER, CONTROL = RAW / "lut-pair-placement-264", RAW / "lut-pair-ten-control-264"
COMMIT, BASE = "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc", "b3d036549c29a333e67c61bd1b23e705bce75d41"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA, ARCHIVE_SHA, HOST_SHA = "1b4e45ac1adc5adf9be8edcfa67b922d7626504dc0bbc73f24ffb69b263f4b1f", "2c8c190cab4556232cf0230213a83122fc22af6af19b76590392732eb6df6c8c", "c77030ec24ef18fc1dc64f85ad05b3e0841866cb9d03ecf46c7cc75586f415d6"
HOST = COMPILER / "validation/host-validation.json"
HOST_HELPER_SHA = "80af57eefb926577426c7043e46a438b938c282b5bb57d87301e88a9a7467d1c"
HOST_SCOPE_SHA = "a32cf00ffef05c9260c2b1ffea9668bd83db231bc35a89e10fb6741b5eb98c98"
CONTROL_PROFILE, CONTROL_RUN, CONTROL_PROOF = CONTROL / "source-identity.json", CONTROL / "baseline/run.json", CONTROL / "baseline/comparison-control.json"
CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA = "d8c15d6b1ec82481f4dd3131136a8e7a913488a9f2961ec5da2f9e9a19f16413", "581f3dd629fc00c7887bca7b6d8415fec214ce1cbe042c754e9eff776dbe3caa", "9498fb62edd6a9a25a3d8db137f1b7c32cc03dccd3be5a81233be639c81a196e"
CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA = "f72f98877a989f2457800989a69de7ef24d449cac4f6af759abc34a8ca447b13", "90494f8f0085b28b1d3a762508b09dff66396fab5c29994a869a319c3eaee903"
CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA = "1350e1ae0913ded6504c44bf3b75174c5121a06995e8c2924162d9a59864da2e", "a9a8951997616e288371ca9532bb573b136704f2f880b0a69e9ba9453f1cf1b2"
FAMILY_GUIDE = RAW / "local-plan16-ready0-skid-burst-guide-264/ready0-guide.json"
FAMILY_GUIDE_SHA = "e2dde3c95c202aa2dc811100aa67c29b9ef0a0b918bf9002b1d7778684643bb7"
OLD_PLAN = RAW / "local-plan16-ready1-command-stage-264/local-plan.json"
OLD_PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
GUIDE, PROFILE, FOLDER = HERE / "ready0-guide.json", HERE / "source-identity.json", HERE / "listing"
INNER, OUTER = "hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B"
SINK = "hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_1"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
             "build_dependency_manifest_sha256", "build_dependency_file_sha256")
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch("[0-9a-f]{64}", expected) and expected != "0" * 64 and
            (path not in inputs or inputs[path] == expected), "invalid/conflicting original path hash")
    if path not in inputs:
        require(sha(path) == expected, "original input differs: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat runtime entry is not absolute"); bind(inputs, name, expected)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def control_definitions():
    control = load(CONTROL / "run_baseline.py", CONTROL_HELPER_SHA, "ready0_listing_control_pure")
    return control, control.definitions()


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
            git(SOURCE, "merge-base", BASE, COMMIT) == BASE and
            set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == set(host["changed_source_files"]),
            "current source differs from the clean committed host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
            [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def routing_signature(path):
    return [{"net": row["net"], "from": row["from"], "to": row["to"]} for row in path["path"] if row["type"] == "routing"]


def command(control):
    result = list(control["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == result.count("--remap-plan") == 1 and
            result[result.index("--remap-plan") + 1] == str(OLD_PLAN) and not any(flag in result for flag in
            ("--rbf", "--remap-post-plan", "--remap-lut-pair-critical", "--remap-lut-pair-candidate", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")),
            "proved control command role differs")
    for flag, path in (("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector"); result[result.index(flag) + 1] = str(path)
    return result + ["--remap-lut-pair-critical", str(GUIDE), "--remap-lut-pair-candidate", "-1"]


def qualification(log, control, definitions):
    discovery = list(re.finditer(r"^Info: LUT pair placement discovery: (\d+) bounded pairs\.$", log, re.M))
    summary = list(re.finditer(r"^Info: LUT pair placement: (\d+) qualified candidates; no candidate applied\.$", log, re.M))
    require(len(discovery) == len(summary) == 1 and discovery[0].end() < summary[0].start() and int(discovery[0][1]) <= 8,
            "fresh bounded listing discovery/summary differs")
    models = control.qualification(log[:discovery[0].start()], definitions)
    block = log[discovery[0].end():summary[0].start()]
    trials = list(re.finditer(r"^Info: LUT pair placement trial inner=(\S+) outer=(\S+) sink=(\S+) inner_bel=(\S+) outer_bel=(\S+) gain=(-?\d+)ps improve=(\d+) endpoints=(\d+) clocks=(\d+) hold=(\d+) fixed=(\d+)$", block, re.M))
    choices = list(re.finditer(r"^Info: LUT pair placement candidate (\d+): inner=(\S+) outer=(\S+) sink=(\S+) inner_bel=(\S+) outer_bel=(\S+) gain=(-?\d+)ps\.$", block, re.M))
    require(len(trials) <= 128 and [int(row[1]) for row in choices] == list(range(int(summary[0][1]))) and
            not re.search(r"^Info: LUT pair placement applied candidate", log, re.M), "listing applied a candidate or candidate/trial bounds differ")
    candidates = []
    for choice in choices:
        prior = [trial for trial in trials if trial.end() < choice.start()]
        require(prior, "qualified pair has no preceding actual trial")
        trial = prior[-1]
        require(trial.groups()[:6] == choice.groups()[1:] and trial.groups()[6:] == ("1",) * 5 and int(trial[6]) >= 250,
                "qualified pair does not bind its complete guarded preceding trial")
        candidates.append({"candidate": int(choice[1]), "inner": choice[2], "outer": choice[3], "sink": choice[4],
            "inner_bel": choice[5], "outer_bel": choice[6], "gain_ps": int(choice[7]), "actual_guarded_trial": list(trial.groups())})
    return models, {"discovered_bounded_pairs": int(discovery[0][1]), "qualified_candidates": int(summary[0][1]),
        "candidate0_reported": bool(candidates), "actual_trial_count": len(trials), "actual_trial_rows": [list(row.groups()) for row in trials],
        "actual_qualified_candidates": candidates, "all_pair_diagnostic_lines": [line for line in log.splitlines() if line.startswith("Info: LUT pair placement")],
        "candidate_applied": False, "selected_candidate_or_routed_gain_accepted": False}


def prepare(self_sha, scope_sha, control_profile_sha, control_run_sha, control_proof_sha, binary_sha, archive_sha, host_sha):
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in
            (self_sha, scope_sha, CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA, CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA,
             CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA, BINARY_SHA, ARCHIVE_SHA, HOST_SHA)), "actual current/control pins remain UNFROZEN")
    require((control_profile_sha, control_run_sha, control_proof_sha, binary_sha, archive_sha, host_sha) ==
            (CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA, BINARY_SHA, ARCHIVE_SHA, HOST_SHA) and
            not any(path.exists() for path in (GUIDE, PROFILE, FOLDER)), "actual activation pins and exclusive listing outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (CONTROL_PROFILE, control_profile_sha),
            (CONTROL_RUN, control_run_sha), (CONTROL_PROOF, control_proof_sha), (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA),
            (CONTROL / "scope.md", CONTROL_SCOPE_SHA), (CONTROL / "compare_control.py", CONTROL_COMPARER_SHA),
            (CONTROL / "comparison-scope.md", CONTROL_COMPARISON_SCOPE_SHA), (HOST, host_sha),
            (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
            (BINARY, binary_sha), (ARCHIVE, archive_sha), (FAMILY_GUIDE, FAMILY_GUIDE_SHA), (OLD_PLAN, OLD_PLAN_SHA)):
        bind(inputs, path, expected)
    source_profile, previous, proof, host = (read(path) for path in (CONTROL_PROFILE, CONTROL_RUN, CONTROL_PROOF, HOST))
    require(previous["completed"] is True and previous["exit_code"] == 0 and previous["compiler_read_audit_passed"] is previous["final_original_input_output_runtime_hashes_stable"] is True and
            previous["source_identity_sha256"] == control_profile_sha and previous["execution"] == source_profile["baseline_execution"] and
            previous["input_sha256"] == {**source_profile["input_sha256"], str(CONTROL_PROFILE): control_profile_sha} and
            all(canonical(previous[key]) == canonical(value) for key, value in source_profile.items() if key != "input_sha256") and
            not any(key in previous for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "control profile/run is not closed")
    require(proof["schema"] == 1 and proof["phase"] == "lut-pair-disabled-ten-stage-native-control" and
            proof["source_identity_sha256"] == control_profile_sha and proof["current_baseline_run_sha256"] == control_run_sha and
            proof["generator_sha256"] == CONTROL_COMPARER_SHA and proof["scope_sha256"] == CONTROL_COMPARISON_SCOPE_SHA and
            proof["recorder_sha256"] == CONTROL_HELPER_SHA and proof["recorder_scope_sha256"] == CONTROL_SCOPE_SHA and
            proof["compiler_commit"] == COMMIT and proof["delta_base_commit"] == BASE and proof["host_validation_sha256"] == HOST_SHA and
            proof["current_actual_execution"] == previous["execution"] and proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and
            all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact", "complete_predicted_report_exact", "fresh_lut_pair_control_prerequisite_proved", "final_original_path_metadata_and_runtime_hashes_stable")) and
            all(proof[key] == {"d7e_original_ten": True, "b3d_disabled_post_ten": True} for key in
                ("ten_model_equality_by_reference", "placement_metric_equality_by_reference", "complete_report_equality_by_reference")),
            "fresh dual-reference disabled-control prerequisite is not positive")
    counts = {"pair_backend": 12, "native_plan": 25, "driver_backend": 10, "pair_cli": 11, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["compiler_commit"] == host["result_commit"] == previous["compiler_commit"] == COMMIT and host["delta_base_commit"] == previous["delta_base_commit"] == BASE and
            host["binary_sha256"] == previous["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == previous["source_archive_sha256"] == ARCHIVE_SHA and
            host["clean_committed_checkout"] is host["build_passed"] is True and host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and
            set(host["checks"]) == set(counts) and all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()),
            "current independent host/compiler qualification differs")
    adopt(inputs, proof)
    for ledger in (previous["input_sha256"], previous["output_sha256"], previous["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original closure path is not absolute"); bind(inputs, path, expected)
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    control, definitions = control_definitions()
    require(control.COMMIT == COMMIT and control.BINARY_SHA == BINARY_SHA and control.ARCHIVE_SHA == ARCHIVE_SHA and control.HOST_SHA == HOST_SHA, "called current parser module identity differs")
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    models = control.qualification((CONTROL_RUN.parent / "phase.log").read_text(), definitions)
    require(canonical(models) == canonical(previous["actual_selected_local_qualification"]) == canonical(proof["fresh_local_models"]) and len(models) == 10,
            "current control's ten complete model bindings differ")
    report, family = read(CONTROL_RUN.parent / "timing.json"), read(FAMILY_GUIDE)
    require(len(family["critical_paths"]) == 1 and report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290, "guide/control report count differs")
    signature = routing_signature(family["critical_paths"][0])
    require(len(signature) == 3 and [(row["from"]["cell"], row["from"]["port"], row["to"]["cell"], row["to"]["port"]) for row in signature] ==
            [("hps_ddr.f2sdram", "cmd_ready_0", INNER, "A"), (INNER, "Q", OUTER, "B"), (OUTER, "Q", SINK, "ENA")], "frozen signature is not the declared native ready0 pair")
    matched = [(index, path) for index, path in enumerate(report["critical_paths"]) if routing_signature(path) == signature]
    require(len(matched) == 1, "current proved control lacks one unique exact routing-edge match")
    index, path = matched[0]
    require(path["from"] == path["to"] == "posedge ram_clock.clocks[0]" and path["path"][-1]["to"]["cell"] == SINK and path["path"][-1]["to"]["port"] == "ENA", "current matched clocks/endpoint differ")
    plan = read(OLD_PLAN)
    require(plan["steps"] == previous["local_plan_steps"] == source_profile["local_plan_steps"] and len(plan["steps"]) == 10 and
            previous["original_plan_path"] == str(OLD_PLAN) and previous["original_plan_sha256"] == OLD_PLAN_SHA and
            len(previous["all_original_ff_bel_manifest"]) == 8221, "original ten plan/FF profile differs")
    profile = {"schema": 1, "phase": "lut-pair-ready0-single-path-predicted-listing", "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA,
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "control_profile_sha256": control_profile_sha,
        "control_run_sha256": control_run_sha, "control_proof_sha256": control_proof_sha,
        "control_recorder_sha256": CONTROL_HELPER_SHA, "control_recorder_scope_sha256": CONTROL_SCOPE_SHA,
        "control_comparer_sha256": CONTROL_COMPARER_SHA, "control_comparison_scope_sha256": CONTROL_COMPARISON_SCOPE_SHA,
        "family_guide_path": str(FAMILY_GUIDE), "family_guide_sha256": FAMILY_GUIDE_SHA, "current_report_matched_path_index": index,
        "matched_routing_edge_signature": signature, "exact_current_path_object": path, "guide_path": str(GUIDE),
        "guide_contains_only_one_current_critical_path": True, "historical_routed_metadata_copied": False,
        "original_plan_path": str(OLD_PLAN), "original_plan_sha256": OLD_PLAN_SHA, "local_plan_steps": plan["steps"],
        "retained_local_models": models, "retained_copy_cohorts": previous["retained_copy_cohorts"],
        "all_original_ff_bel_manifest": previous["all_original_ff_bel_manifest"], "pair_candidate_selection": -1,
        "command": command(previous), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"],
        "listing_execution": copy.deepcopy(previous["execution"]), "post_plan_requested": False, "driver_pass_executed": False,
        "native_or_physical_reproduction_inherited": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source(host)
    with GUIDE.open("x") as stream: stream.write(json.dumps({"critical_paths": [path]}, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, GUIDE, sha(GUIDE)); profile["guide_sha256"] = inputs[str(GUIDE)]
    require(read(GUIDE) == {"critical_paths": [path]}, "new single-path guide differs")
    profile["input_sha256"] = dict(sorted(inputs.items()))
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "guide_sha256": sha(GUIDE), "matched_path_index": index, "inputs": len(inputs)}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, previous, host = read(PROFILE), read(CONTROL_RUN), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    require(not FOLDER.exists() and profile["phase"] == "lut-pair-ready0-single-path-predicted-listing" and
            profile["command"] == command(previous) and profile["listing_execution"] == previous["execution"] and profile["cwd"] == previous["cwd"] == str(MODULE) and
            profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            inputs[str(CONTROL_PROFILE)] == profile["control_profile_sha256"] == CONTROL_PROFILE_SHA and inputs[str(CONTROL_RUN)] == profile["control_run_sha256"] == CONTROL_RUN_SHA and
            inputs[str(CONTROL_PROOF)] == profile["control_proof_sha256"] == CONTROL_PROOF_SHA and inputs[str(HOST)] == profile["host_validation_sha256"] == HOST_SHA and
            inputs[str(BINARY)] == profile["binary_sha256"] == BINARY_SHA and inputs[str(ARCHIVE)] == profile["source_archive_sha256"] == ARCHIVE_SHA and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
            inputs[str(GUIDE)] == profile["guide_sha256"] and read(GUIDE) == {"critical_paths": [profile["exact_current_path_object"]]}, "frozen listing profile/command/runtime differs")
    control, definitions = control_definitions(); clean_source(host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["listing_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual runtime differs from the proved control")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "fresh ready0 pair listing did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step")) and
                not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual listing is not final predicted-only/no post or driver")
        models, listing = qualification(log, control, definitions)
        record["actual_selected_local_qualification"], record["actual_pair_listing"] = models, listing
        record["all_ten_complete_trial_models_exact"] = canonical(models) == canonical(profile["retained_local_models"])
        metric = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
        metric_rows, old_metric_rows = metric.findall(log), metric.findall((CONTROL_RUN.parent / "phase.log").read_text())
        record["all_71_placement_metrics_exact"] = len(metric_rows) == len(old_metric_rows) == 71 and metric_rows == old_metric_rows
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "actual complete predicted report cap/count/Fmax differs")
        record["actual_predicted_fmax"] = report["fmax"]
        record["complete_predicted_report_exact_diagnostic"] = canonical(report) == canonical(read(CONTROL_RUN.parent / "timing.json"))
        record["output_sha256"] = {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "actual listing output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "candidate0_reported": listing["candidate0_reported"], "native_or_physical_reproduction_inherited": False, "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "control-profile-sha256", "control-run-sha256", "control-proof-sha256", "binary-sha256", "archive-sha256", "host-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.control_profile_sha256, args.control_run_sha256, args.control_proof_sha256, args.binary_sha256, args.archive_sha256, args.host_sha256)
        require(all(values), "actual preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
