# Fresh ready0 joint-placement listing

ROOT alone activates this helper after whole-file, hash, AST and independent
peer review. Compiler/ELF/archive/host and disabled-control profile/run/proof/
recorder/comparer pins were UNFROZEN during authoring and ROOT now pins them
from actual completed evidence before activation. Prepare requires explicit actual
self/scope/control-profile/control-run/control-proof/ELF/archive/host hashes;
execute requires the actual prepared profile hash. Existing guides, controls,
source, binaries and measurements are unchanged.

The mandatory prerequisite is the current positive disabled-ten control with
fresh_lut_pair_control_prerequisite_proved and exact parity to both the original
d7e5 control and the closed b3d disabled-post control. Its complete closed
profile/input-union record, full output/runtime ledger, current host source and
dependency maps, and both flat historical proof closures are rehashed directly.
Current host qualification must pass all47 native and45 CLI methods. The eight
reviewed pure qualification parsers are pinned through the new control recorder;
old prepare, execute, main, authentication and comparison entrypoints are never
called. The new helper performs its own fresh-source checks and invocation.

The frozen ready0-guide e2dde3c9 is used only as a native-edge signature. The
three ordered routing edges include exact net name and complete from/to endpoint
objects: HPS cmd_ready0 to port0 slot_free ALUT2.A, its Q to ALUT3_B.B, then its
Q to protected skid_burstcount FF1.ENA. Exactly one path in the proved CURRENT
control report must match. That current path object is copied without changing
any clocks, window, locations, sources, segments or delays. No assumption about
its global worst-path position is made. The exclusive new ready0-guide.json
contains only critical_paths with this one complete current object; old routed
Fmax, utilization and detailed postdriver BUF metadata are not copied.

The new argv copies the proved current control command, changing only write and
report output paths and adding --remap-lut-pair-critical for the new guide and
--remap-lut-pair-candidate -1. It retains --no-route, literal original ten-stage
plan00bf, every descriptor/report path, native input, QSF, SDC, device, seed,
option, controlled runtime file, diagnostic environment and source closure.
No post plan, driver copy or RBF output is requested. The loaded five project
module paths/hashes, FunctionalInvocation snapshot and compiler-read audit must
equal the current control. Original hashes and clean selected source/model/
submodule identities are checked before and after preparation and execution.

The exclusive source-identity.json records the exact current matching path,
signature/source index, all ten guarded models and retained copy cohorts,
all8221 FF BELs, new guide hash, command/runtime and flat input closure. Actual
listing outputs are listing/phase.log, placed.json, timing.json and run.json.
Partial outputs and failure records are retained and never treated as completed.
Normal completion, one bounded discovery/final listing summary, no applied pair,
no route/RBF/post/driver and the complete16384-cap/15290-path predicted report
are required. Every actual pair diagnostic line and trial is retained; qualified
candidates bind their preceding all-guarded trial. Candidate0 existence is a
reported diagnostic and is not presumed. Ten-model,71-metric and whole-report
equalities are diagnostics for ROOT's separate exact reproduction comparator.

A completed listing does not prove native or physical reproduction, select a
pair placement, inherit Boolean/pin/LAB-cache proof, calibrate numerical STA,
claim routed gain, decode a bitstream, test hardware or publish externally. The
accepted fifth117.771759 MHz measurement remains the separate gain reference.
