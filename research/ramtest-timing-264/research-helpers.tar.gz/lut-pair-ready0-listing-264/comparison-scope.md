# Fresh ready0 pair-listing reproduction

During authoring every compiler, host, current-control, listing-recorder, profile
and completed-run pin was `UNFROZEN`. ROOT now pins the actual completed hashes
and alone reviews and executes the comparator after an independent
whole-file peer review. Activation additionally supplies its self/scope hashes and
the exact listing profile/run/recorder/scope hashes. It writes only the exclusive
`listing/comparison-listing.json`; no earlier evidence or helper is changed.

The prerequisite is the completed current disabled-TEN control and its positive
dual-reference proof. That proof binds exact ten-model, native-module, placement
metric and full predicted-report parity against both the d7e original control and
the b3d disabled-post-plan control. Their closed flat artifact and execution-file
ledgers are rehashed at their original paths. Their previous creator allowance
does not extend to this comparison: the fresh listing and current control must
have byte-equivalent creator strings and the complete native document must match.

The comparator independently checks both completed record shapes, every profile
field, the profile-plus-own-profile input union, exact output triplets and execution
snapshots. The listing command changes only the current control's write/report
paths and adds the one-path pair guide plus candidate `-1`; post-plan, driver, RBF
and routing remain excluded. Source/archive/host identities and every current
source, submodule, external-model, object-dependency and runtime pathname/hash are
bound before comparison and rehashed after it. The host evidence must contain all
47 native and 45 CLI cases in its six named check groups, including the current
test binary and check-results hashes. Relative archive members remain member
evidence, not filesystem paths. No old host validator or operational entrypoint
is replayed.

Only reviewed pure definitions are loaded: 32fd lossless native JSON/Audit and
placement metric parsing; 72131 native driver/user tables and complete report
topology; its exact 8601 freeze dependency through a module-local import namespace;
the new listing recorder's command, routing signature and diagnostic parser; and
the current control's complete eight-module qualification chain. All called
module paths/hashes and the five modules executed by the original compiler
invocation must be in the frozen listing input closure. No prepare, execute,
clean-source, high-level comparator, legacy authenticator or old timing evaluator
is called. This comparator performs ordinary reads and writes its own manifest.

The one guide is checked against the exact unique current-control routing-edge
signature of the frozen ready0 family: HPS cmd_ready_0 to port0 ALUT2.A, its Q to
port0 ALUT3_B.B, then that Q to skid_burstcount FF1.ENA. The current report's full
chosen object, clocks, window, delays and path order must remain unchanged. The
guide contains only that object's `critical_paths` entry; historical routed BUF,
Fmax, detailed-timing or utilization metadata is not copied.

There are no native exemptions. All 14,907 cells and 16,645 named nets, top fields,
all 8,221 original FF records/BELs, types, parameters, connections, pins, attributes,
aliases, raw IDs, reconstructed native drivers/users and occurrence slots must be
exact. Recursive owner, port and nested metadata order and the lossless paired-PLL
sidecar are checked independently. No creator waiver, private-frame alignment,
buffer collapse, numeric relabeling, LUT algebra or physical-cache equivalence is
used to rescue a mismatch.

The complete ten guarded trial models, all 71 placement metric rows and the entire
predicted report must equal the current control. Both complete native images are
checked against the current report topology: 15,290 unique native paths, the exact
seven domain-pair endpoint sets/windows and finite native path terms, with report
cap 16,384. Model/listing rejection, graph rejection, metric mismatch, complete
report inequality and topology rejection remain separate diagnostics; topology and
the final original-path rehash run even when structural reproduction fails.

Actual bounded discovery, all rejected trial lines and qualified candidates are
retained. Every candidate binds its final preceding actual trial, both BELs,
minimum 250 ps gain and all five guards. Candidate zero need not exist. The final
listing must apply no candidate and finish normally in predicted-only mode. Only
all exact reproduction gates make `fresh_lut_pair_listing_reproduction_proved`
true. This does not accept a selected candidate, routed gain, independent physical
or numerical STA proof, unexported pin/LAB/cache state, RBF decode or hardware use.
