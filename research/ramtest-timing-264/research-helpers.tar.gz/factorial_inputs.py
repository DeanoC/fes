"""Disposable two-factor packed-netlist controls: numeric bit IDs vs LUT port order."""
import copy
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
scratch = json.loads((root / "packed-scratch.json").read_text())
compiler = json.loads((root / "packed-compiler.json").read_text())
a = scratch["modules"]["top"]
b = compiler["modules"]["top"]
assert list(a["cells"]) == list(b["cells"])
assert list(a["netnames"]) == list(b["netnames"])

recode = {}
for name in a["netnames"]:
    for aid, bid in zip(a["netnames"][name]["bits"], b["netnames"][name]["bits"]):
        if isinstance(aid, int):
            assert isinstance(bid, int)
            if bid in recode:
                assert recode[bid] == aid
            recode[bid] = aid
assert [(old, new) for old, new in recode.items() if old != new] == [
    (15962, 15961), (15961, 15960), (120684, 120683), (120683, 120682)
]

def change_ids(module):
    for net in module["netnames"].values():
        net["bits"] = [recode.get(x, x) if isinstance(x, int) else x for x in net["bits"]]
    for port in module["ports"].values():
        port["bits"] = [recode.get(x, x) if isinstance(x, int) else x for x in port["bits"]]
    for cell in module["cells"].values():
        for port, bits in cell["connections"].items():
            cell["connections"][port] = [recode.get(x, x) if isinstance(x, int) else x for x in bits]

def change_port_order(module):
    for name, cell in module["cells"].items():
        reference = a["cells"][name]
        for field in ("connections", "port_directions"):
            cell[field] = {key: cell[field][key] for key in reference[field]}

variants = {
    "a_scratch": copy.deepcopy(scratch),
    "b_compiler": copy.deepcopy(compiler),
    "c_scratch_ids": copy.deepcopy(compiler),
    "d_scratch_ports": copy.deepcopy(compiler),
}
change_ids(variants["c_scratch_ids"]["modules"]["top"])
change_port_order(variants["d_scratch_ports"]["modules"]["top"])
assert variants["c_scratch_ids"]["modules"]["top"] == a
for name, design in variants.items():
    path = root / f"factorial-{name}.json"
    path.write_text(json.dumps(design, indent=2) + "\n")
    print(name, hashlib.sha256(path.read_bytes()).hexdigest(), path.stat().st_size)
