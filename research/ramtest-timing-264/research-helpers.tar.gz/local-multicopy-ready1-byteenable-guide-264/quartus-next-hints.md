# Saved Quartus hints for the remaining ready1 branches

Read-only research, 2026-10-01. No Quartus query, fitter, helper, compiler, STA,
route or hardware execution was performed for this note. The seventh route is
still an experiment; the accepted reference remains the fifth-stage 117.771759
MHz result (`6dcf8c4b` / run `5ed3c077`). The sixth construction (`b97978d1` /
run `1e342f24`) passed native/physical checks and failed the gain gate.

## Actual OSS endpoints and delay distribution

Native aliases confirm output byte-enable bit 7 and skid byte-enable bits 3/7;
the mapped cell suffix alone is not the bit-identity evidence. All three paths
launch at `hps_ddr.f2sdram.cmd_ready_1`, use `cmd_port_clk_1` for the launch
clock, terminate at ENA, and have the actual 7.691999912 ns memory window.

| Endpoint | Accepted fifth complete sum | Sixth complete sum |
| --- | ---: | ---: |
| `hps_ddr.m1_byteenable_MISTRAL_FF_Q_7.ENA`, LAB 25,22 | 8.466000170 ns | 8.588999838 ns |
| `hps_ddr.port1.skid_byteenable_MISTRAL_FF_Q_3.ENA`, LAB 27,21 | 8.398000166 ns | 8.520999834 ns |
| `hps_ddr.port1.skid_byteenable_MISTRAL_FF_Q_7.ENA`, LAB 27,21 | 8.398000166 ns | 8.520999834 ns |

The shared HPS-ready wire to the unchanged inner ALUT2 at 33,19 grows from
4.031000137 to 4.153999805 ns. Both paths retain two 0.400 ns logic arcs.
For output bit 7, the inner-to-outer wire is 0.966 ns and outer-to-ENA is
1.476 ns; for skid bits 3/7 these are 1.087 and 1.305 ns. Signed complete sums
also retain their emitted clock skew, 1.177 ns clock-to-Q and -0.196 ns setup.
Thus the regression is shared input routing, without a changed mapping or
placement of these two original cones. Shortening a selected path alone does
not establish a whole-design improvement.

## Exact fitted connectivity versus timing analogies

The older saved fit's `nodes.tsv` identifies output `port1|m_byteenable[7]`
as node 339, FF36,63,N28. `inputs.tsv:2453` connects its ENA to node 4204,
`port1|m_address[0]~0` at LAB35,62,N15. This is an exact logical endpoint/control
connection. The newer `ready1-all.rpt:262-279,376-389` instead times output
**address[8]**, with two LUTs at MLAB34,63,N33/N12 and a nearby FF36,62,N47.
Its 4.329 ns data delay / +2.475 ns slack is a locality analogy for byte-enable,
not an exact byte-enable timing report or fitted truth-table proof.

The older fit resolves skid byte-enable[3]/[7] to nodes 4760/4772. Both appear
as input-port-7 consumers in node 5096's exact 109-user output list
(`outputs.tsv:950`). Node 5096, `port1|skid_write~0`, occupies LAB35,62,N9.
Its five active inputs are m_read, m_write, filler, from_core~0 and cmd_ready_1;
the previously checked 64-row physical mask implements
`(m_read | m_write) & ~cmd_ready_1 & (filler | from_core)`.
The exact saved timing endpoint is **skid_address[27]**, not skid byte-enable;
the newer `ready1-skid-address.rpt` likewise times skid_address[24]. These
reports establish one-level mapping/locality for the shared skid cohort, not
the exact timing of the two present byte-enable endpoints.

## Bounded next direction

If the seventh route leaves skid byte-enable[3]/[7] critical, the frozen
compiler already supports a fresh extra copy of their existing inner-ALUT2 /
outer-ALUT3 composition for the complete two-FF LAB27,21 cohort. It composes
four actual external leaves into ALUT4, preserves prior copies and original
cells/FFs, and requires fresh candidate guards plus full native/physical and
timing proof. This fits current two-cell `local_remap` discovery directly.

The saved five-input skid implementation suggests a later generic broader-cut
search that absorbs enter-read/enter-write preconditions. Current discovery
only composes the last two LUTs, so it cannot automatically reproduce that
broader cut. Such an extension needs independently derived current native
support, constants/inversions and exhaustive rows; the old fitted mask must
not be transplanted. Preserve original shared roots and other consumers.
Locality should use the HPS signal's physical exit (saved HIO51,64), rather
than the logical HPS BEL52,53. No expected numeric gain follows from that hint.

## Provenance and limits

The older fit BUILD_ID is `cd3e4c315005fde83065dff7483ae0d7`; the newer saved
fit is `52991ce22369904849b68bdd900f9ae1`; measured OSS is
`7168b508ab424b70f1c0f87b2035d821`. Quartus uses seed1, native PLL/SDC and its
own model, and omits RAM_OSS_HIGH_SPEED; OSS uses seed2. There is no equivalent
route-model calibration, whole elaboration equivalence or new acceptance.

Re-read artifacts: fifth timing SHA `4083965020bca2c525f7700f6f192fa2a34851a1f03b35b6404f7f834cd53f8a`;
sixth timing `b8c0e6a0c5063f19d808e6a01f21745ce0af573dce391442a0767287a8290e0e`.
Older `nodes.tsv` / `inputs.tsv` / `outputs.tsv` SHA prefixes are
`c26bc777` / `be833162` / `2147fea9`; newer ready1-all / ready1-skid-address
reports are `a855a13a` / `95126b15`. Full paths and hashes are retained in
[`../ready-remap-264/quartus-hints.md`](../ready-remap-264/quartus-hints.md),
which distinguishes the two saved fits. The older DDR idle/equality and DDR0
error-cube notes concern other endpoints and are not current critical targets.
