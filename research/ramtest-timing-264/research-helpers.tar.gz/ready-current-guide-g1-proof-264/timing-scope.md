# Actual current-guide one-group full-route timing inspection

Root alone executes this NEW wrapper after its complete read, AST check and
independent static review. The CLI pins the actual frozen full-route profile,
this wrapper and this scope. Output is created exclusively. Previous helpers,
profiles, compiler binaries, archive paths, records and outputs are immutable.

The wrapper consumes closed accepted117.34334564208984MHz proof a4a91235
and closed current conditional-prefix84afc015 as flat pathname/hash closures.
It rehashes historical runtime members without claiming they were loaded by
the fresh compiler. Actual current execution must exactly match the frozen
GPU1 baseline snapshot. The current record must preserve every profile field,
with its input map extended only by the exact profile pathname/hash. All four
actual route outputs and the complete execution snapshot are bound and all
original files are rehashed after evaluation. No old generator, authentication
driver, compiler, route or previous inspector is replayed.

Only pure existing32fd lossless parsing and e6ce77b7 timing.evaluate are used;
the latter's old folder/header refers to its first8/8/1caller, while its API
accepts arbitrary complete native/current/baseline/parent reports. Its72131
native topology,8601 module-local freeze and6c8f board imports, including29ab
source_repository and742d lockfile, must all occur in the authenticated closure.
There is no global import replacement or caller mutation of old helper state.

Every current15290path must validate against its native graph with finite
segment sums, indexed endpoints, source nets/pins, logic, locations and actual
clock domains. Seven endpoint-pair sets and windows must match the current
predicted baseline and accepted parent. All six non-target worst path margins
must be strictly positive; pixel/capture constraints must pass; memory must
strictly improve117.34334564208984MHz. Lower positive non-target headroom is
allowed and disclosed; all-clock Fmax nonregression is separate diagnostic
information. The target130.0052032470703MHz window remains an explicit policy
exception until achieved: reported_window_met and acceptance policy pass are
separate fields. The actual falling-edge windows remain5ns and3.845999956ns.

The LAST signoff block must have no literal Hold/min time violation and no
additional hold/minimum warning/violation/negative lines. The recorder's
literal hold flag and Fmax must agree with actual outputs. Normal completion
and a live HIP GPU router are required. The phase windows and physical delays
are observed, not independently recomputed or calibrated to Quartus.

Timing success alone does not accept a candidate. Original whole graph,
the three declared FF.ENA transfers, moved enable LUT's actual physical banks,
pins/shared neighbors and whole LAB controls, fresh driver copy/carry closure,
and late BUF owner/private-slot ledger need a separate bounded physical proof.
No cache/GPU identity, RBF bit equivalence, CRAM or hardware claim is made.
