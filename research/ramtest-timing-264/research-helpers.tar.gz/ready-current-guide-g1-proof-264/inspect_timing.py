"""Authenticate fresh g1 full-route timing; no graph or physical acceptance."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
FULL = RAW / "ready-current-guide-g1-route-264"
BASELINE = RAW / "ready-current-guide-g1-264/baseline"
PARENT = RAW / "driver-copy-route-264/route-c0"
PARENT_PROOF = RAW / "driver-copy-route-proof-v2-264/comparison.json"
PARENT_SHA = "a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304"
PREFIX = BASELINE / "comparison.json"
PREFIX_SHA = "84afc015cd56263ea1d1542d281952c7eb699fe09a79a8718c76896e957d7458"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
TIMING = RAW / "driver-copy-ready-groups8-proof-264/timing.py"
TIMING_SHA = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
TIMING_SCOPE = TIMING.parent / "timing-scope.md"
TIMING_SCOPE_SHA = "5088a952653ccd349edb109bd68e038cace200c911ec7707cef1d958897d8032"
COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name):
    require(sha(path) == expected and name not in sys.modules, "pure module identity differs")
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def adopt(audit, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "external runtime path is not absolute")
        audit.bind(Path(name), expected, execution=True)


def inspect(profile_sha, self_sha, scope_sha):
    native = load(NATIVE, NATIVE_SHA, "ready_current_g1_actual_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "timing-scope.md", scope_sha),
                           (NATIVE, NATIVE_SHA), (TIMING, TIMING_SHA), (TIMING_SCOPE, TIMING_SCOPE_SHA),
                           (FULL / "source-identity.json", profile_sha), (PARENT_PROOF, PARENT_SHA), (PREFIX, PREFIX_SHA)):
        audit.bind(path, expected)
    parent, prefix = native.read(PARENT_PROOF), native.read(PREFIX)
    require(parent["candidate_accepted_under_confirmed_target_clock_rule"] is True and
            parent["full_graph_and_pin_equivalence_proved"] is True and
            parent["final_original_path_metadata_and_runtime_hashes_stable"] is True,
            "accepted parent proof is not closed")
    require(prefix["native_graph_proof_available"] is True and prefix["structural_rejection"] is None and
            prefix["fresh_driver_guide_available_after_conditional_prefix_proof"] is True and
            prefix["final_original_path_metadata_and_runtime_hashes_stable"] is True,
            "current conditional prefix is not closed")
    adopt(audit, parent)
    adopt(audit, prefix)
    profile = native.read(FULL / "source-identity.json")
    require(profile["compiler_commit"] == COMMIT and profile["prefix_proof_sha256"] == PREFIX_SHA and
            profile["baseline_execution"]["gpu_device"] == 1 and profile["routed_gain_accepted"] is False,
            "fresh full route profile differs")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input path is not absolute")
        execution = (name in profile["baseline_execution"]["files"] or
                     parent["execution_file_sha256"].get(name) == expected)
        require(Path(name).resolve().is_relative_to(ROOT) or execution,
                "external profile input is neither current runtime nor closed parent runtime")
        audit.bind(Path(name), expected, execution=execution)
    folder = FULL / "route-c0"
    audit.bind(folder / "run.json")
    record = native.read(folder / "run.json")
    expected_inputs = {**profile["input_sha256"], str(FULL / "source-identity.json"): profile_sha}
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["source_identity_sha256"] == profile_sha and record["execution"] == profile["baseline_execution"] and
            record["input_sha256"] == expected_inputs and
            all(record[key] == value for key, value in profile.items() if key != "input_sha256"),
            "actual record does not bind the complete frozen profile and current runtime")
    for name, expected in record["execution"]["files"].items():
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(folder / name) for name in
            ("route.log", "routed.json", "timing.json", "core.rbf")}, "actual output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output is empty")
        audit.bind(Path(name), expected)
    require(all(path in audit.paths for path in (PARENT / "timing.json", BASELINE / "timing.json")),
            "accepted/current predicted reports are absent from closed provenance")
    timing = load(TIMING, TIMING_SHA, "ready_current_g1_actual_timing")
    result = timing.evaluate(native.read_netlist(folder / "routed.json"),
                             native.read(folder / "timing.json"), native.read(PARENT / "timing.json"),
                             native.read(BASELINE / "timing.json"), (folder / "route.log").read_text(), record)
    require(all(Path(path) in audit.paths and audit.paths[Path(path)] == expected
                for path, expected in result["evidence"]["pinned_pure_module_sha256"].items()),
            "pure timing dependencies are absent from bound closure")
    audit.finish()
    return {"schema": 1, "phase": "ready-current-guide-g1-actual-full-timing-only",
            "source_identity_sha256": profile_sha, "generator_sha256": self_sha, "scope_sha256": scope_sha,
            "accepted_parent_proof_sha256": PARENT_SHA, "prefix_proof_sha256": PREFIX_SHA,
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"], "timing": result,
            "candidate_accepted": False, "full_graph_and_physical_equivalence_proved": False,
            "rbf_sha256": record["output_sha256"][str(folder / "core.rbf")], "hardware_tested": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())),
            "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("profile-sha256", "self-sha256", "scope-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    output = HERE / "timing-inspection.json"
    require(not output.exists(), "immutable timing inspection already exists")
    result = inspect(args.profile_sha256, args.self_sha256, args.scope_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"output_sha256": sha(output), "timing_passed": result["timing"]["passes_practical_timing_gate"],
                      "clocks": result["timing"]["raw_timing"]["clocks"], "candidate_accepted": False}, indent=2))


if __name__ == "__main__":
    main()
