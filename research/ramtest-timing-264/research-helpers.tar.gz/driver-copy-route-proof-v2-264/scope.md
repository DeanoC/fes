# Explicit private-buffer identity ledger, version 2

Root alone executes this new proof. The frozen full compiler/run, selected
proof, physical evaluator and strict first proof remain unchanged. The strict
rejection `ce530420…` is authenticated and preserved. Only its pinned pure
authentication/timing support functions are reused; no earlier comparison
generator or main is called. The frozen new full recorder authenticates its
flat closure once, followed by final original-path/runtime/output rehash.

Read-only investigation found one top setting difference: accepted
`compress_rbf="1"`, current `compress_rbf="0 "`. Actual accepted command has
`--compress-rbf`, current command omits it. The frozen committed main.cc and
bitstream.cc archive members authenticate that this option selects RBF writer
compression. Version2 permits exactly that setting delta and requires every
other top setting, attribute, whole LAB state and public port to remain exact.
It claims no compressed/uncompressed RBF byte equivalence.

All 5,232 existing buffers retain the same names, types, parameters, attributes,
BELs, complete pins, source inputs and one named FF DATAIN consumer. Their
document-local Q IDs, matching FF DATAIN slot IDs and sole named private Q
aliases differ. The observed delta is +2, but the proof never computes an ID
translation from that delta. In particular, current clone Q=120722 is an old
buffer-private ID in the reference image. Every image is checked through its
own actual named driver, unique private alias and sole FF consumer; overlapping
private ID ranges are permitted only after this complete per-owner ledger.

Each ledger row checks actual before/after raw IDs, the exact Q owner/output
slot, the same unique FF DATAIN/vector/occurrence slot, unique named Q alias,
absence of public consumers, exact buffer and FF full metadata/pins except
those two scalar raw slots, and unchanged native buffer input owner. The
whole actual buffer ALM is evaluated in both images, with all occupied banks,
shared physical inputs, effective constants/inversions and saved FF controls
equal. All 32 physical buffer bank rows are derived, including actual MCOMB
logic permutation. Whole buffer-LAB FF controls are checked independently.

Every original non-private numeric bit remains exact. The only permitted raw
cell changes are the explicit buffer Q/unique FF DATAIN pairs and the previously
declared arithmetic operand. Only the corresponding named private Q aliases
may change raw IDs. Actual complete driver and consumer-slot tables are rebuilt
from each named port slot and compared to the explicit ledger, preserving
aliases and input-load multiplicity; there is no global ID normalizer or BUF
collapse. Original owner order and ordered PLL records remain strict. Exactly
one selected ALUT3 and its private Q net are added, with source Q49→48 and
private copy Q1, and all three actual copy input loads closed.

The actual source/copy/arithmetic sink/immediate carry closure uses frozen
`0f524952…` physical evaluation. Original full pins/BELs/parameters and whole
LAB snapshots stay exact outside the named raw slots. These are exported-model
mask/control checks, not independent RBF/CRAM decoding, all-pip validation,
unexported cache/index/GPU-state proof or hardware acceptance.

Timing is independently rechecked using the immutable strict helper's pure
current-report validator, and must equal its actual saved diagnostic. Memory
must strictly exceed 116.64527893066406 MHz; actual required other constraints,
every current non-target pair/window (including capture5ns and negative-edge
memory), and last-signoff zero holds remain mandatory. The historical stricter
all-clock diagnostic is retained. Any unresolved graph/physical/ledger failure
prevents acceptance and remains explicit in this separately versioned output.
