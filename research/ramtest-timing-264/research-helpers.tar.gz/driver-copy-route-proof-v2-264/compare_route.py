"""Explicit named buffer-private-bit ledger over the immutable full route."""
import argparse
from collections import Counter
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
FIRST = RAW / "driver-copy-route-proof-264"
FIRST_SHA = "cd03040cdbe2b2aa470110fece9a67c6c15b9f3f858a1f2995169153d59c2fd8"
FIRST_SCOPE_SHA = "ffb372051490be3aab5f33a1e7c6fba3abbca6e694818217dbb163724c62a039"
FIRST_PROOF_SHA = "ce5304205223356e00863b6461dad04953e04baa115df54afb2e9de5bbee1331"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def module(path, name, expected):
    require(sha(path) == expected, "frozen pure API changed before import: " + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def all_bits(top):
    result = set()
    for net in top["netnames"].values():
        result.update(net["bits"])
    for cell in top["cells"].values():
        for bits in cell["connections"].values():
            result.update(bits)
    for port in top["ports"].values():
        result.update(port["bits"])
    require(all(type(bit) is int and bit >= 0 for bit in result), "unsupported native bit partition")
    return result


def compression(native, frozen, profile, record, old, new):
    require(old["settings"]["compress_rbf"] == "1" and new["settings"]["compress_rbf"] == "0 ",
            "compression change is not the exact authenticated writer-only setting")
    reference = native.read(frozen.HERE.parent / "narrow-integrated-264/route-reproduction/run.json")
    require(reference["command"].count("--compress-rbf") == 1 and "--compress-rbf" not in record["command"],
            "compression metadata is not explained by actual authenticated commands")
    repository = profile["repositories"]["nextpnr"]
    with tarfile.open(frozen.HERE / "source.tar.gz", "r:gz") as outer:
        member = outer.getmember(repository["archive_member"])
        require(member.isfile(), "compiler archive member is not a file")
        packed = outer.extractfile(member).read()
    require(hashlib.sha256(packed).hexdigest() == repository["archive_sha256"], "nested committed compiler archive changed")
    evidence = {}
    with tarfile.open(fileobj=io.BytesIO(packed), mode="r:") as archive:
        for name in ("mistral/main.cc", "mistral/bitstream.cc"):
            member = archive.getmember(name)
            require(member.isfile(), "writer model source member is not a regular file")
            data = archive.extractfile(member).read()
            evidence[name] = {"sha256": hashlib.sha256(data).hexdigest()}
            if name.endswith("main.cc"):
                require(b'if (vm.count("compress-rbf"))' in data and
                        b'ctx->settings[id_compress_rbf] = Property::State::S1;' in data,
                        "authenticated CLI compression setting contract differs")
            else:
                require(b'if (!ctx->setting<bool>("compress_rbf", false))' in data and
                        b'cv->opt_b_set(CycloneV::COMPRESSION_DIS, true);' in data,
                        "authenticated bitstream compression-only contract differs")
    return {"setting": "compress_rbf", "before": "1", "after": "0 ", "actual_command_flags_verified": True,
            "frozen_source_archive_member_evidence": evidence,
            "only_rbf_writer_artifact_encoding_is_carved_out": True, "rbf_byte_equivalence_claimed": False}


def aliases(top):
    result = {}
    for name, net in top["netnames"].items():
        for index, bit in enumerate(net["bits"]):
            result.setdefault(bit, []).append((name, index))
    return result


def buffer_ledger(v1, native, physical, before, after):
    old, new = before["modules"]["top"], after["modules"]["top"]
    old_buffers = {name for name, cell in old["cells"].items() if cell["type"] == "MISTRAL_BUF"}
    new_buffers = {name for name, cell in new["cells"].items() if cell["type"] == "MISTRAL_BUF"}
    require(old_buffers == new_buffers and len(old_buffers) == 5232, "actual unchanged named buffer population differs")
    before_view, after_view = physical.PhysicalView(old), physical.PhysicalView(new)
    old_drivers, old_users = v1.tables(old)
    new_drivers, new_users = v1.tables(new)
    old_aliases, new_aliases = aliases(old), aliases(new)
    rows, cells, nets, old_private, new_private = [], {}, {}, set(), set()
    alms, buffer_alms, bank_cache = set(), {}, {}
    for name in sorted(old_buffers):
        a, b = old["cells"][name], new["cells"][name]
        require(a["type"] == b["type"] == "MISTRAL_BUF" and set(a["connections"]) == set(b["connections"]) == {"A", "Q"} and
                a["port_directions"] == b["port_directions"] == {"A": "input", "Q": "output"} and
                len(a["connections"]["A"]) == len(a["connections"]["Q"]) == len(b["connections"]["Q"]) == 1 and
                a["connections"]["A"] == b["connections"]["A"], "buffer raw source/port schema changed: " + name)
        qa, qb = a["connections"]["Q"][0], b["connections"]["Q"][0]
        expected = copy.deepcopy(a)
        expected["connections"]["Q"] = [qb]
        require(native.canonical(expected) == native.canonical(b), "buffer metadata/BEL/full pins changed: " + name)
        require(qa not in old_private and qb not in new_private and
                old_drivers.get(qa) == new_drivers.get(qb) == [(name, "Q", 0, 0)], "buffer Q lacks its unique exact named owner")
        old_private.add(qa)
        new_private.add(qb)
        require(len(old_users.get(qa, [])) == len(new_users.get(qb, [])) == 1 and old_users[qa] == new_users[qb],
                "buffer Q does not retain its exact sole named consumer")
        consumer = old_users[qa][0]
        ff, port, index, occurrence = consumer
        require(port == "DATAIN" and index == occurrence == 0 and old["cells"][ff]["type"] == new["cells"][ff]["type"] == "MISTRAL_FF" and
                old["cells"][ff]["connections"][port] == [qa] and new["cells"][ff]["connections"][port] == [qb],
                "buffer Q sole consumer is not its exact original FF DATAIN slot")
        require((ff, port) not in cells, "multiple buffer ledger rows claim one FF input")
        expected_ff = copy.deepcopy(old["cells"][ff])
        expected_ff["connections"][port] = [qb]
        require(native.canonical(expected_ff) == native.canonical(new["cells"][ff]),
                "consumer FF metadata/BEL/full pins/other native ports changed: " + ff)
        private = name + "$conn$Q"
        require(old_aliases.get(qa) == new_aliases.get(qb) == [(private, 0)], "buffer Q private named alias is not unique/exact")
        require(all(qa not in p["bits"] for p in old["ports"].values()) and all(qb not in p["bits"] for p in new["ports"].values()),
                "buffer private Q has a public boundary consumer")
        na, nb = copy.deepcopy(old["netnames"][private]), copy.deepcopy(new["netnames"][private])
        na["bits"] = [qb]
        na["attributes"].pop("ROUTING", None)
        nb["attributes"].pop("ROUTING", None)
        require(native.canonical(na) == native.canonical(nb), "buffer private alias semantic metadata changed")
        raw_input = a["connections"]["A"][0]
        require(old_drivers.get(raw_input) == new_drivers.get(raw_input) and len(old_drivers.get(raw_input, [])) == 1 and
                before_view.scalar(name, "A", "input") == after_view.scalar(name, "A", "input"), "buffer input source owner changed")
        where = physical._location(a)
        require(where == physical._location(b) and where[0] in {"COMB", "MCOMB"}, "buffer actual physical location differs")
        key = where[1], where[2], where[3] // 6
        alms.add(key)
        if key not in bank_cache:
            first, second = physical.evaluate_alm(before_view, key), physical.evaluate_alm(after_view, key)
            require(native.canonical(first) == native.canonical(second), "whole buffer ALM effective banks/shared pins/FF controls changed")
            bank_cache[key] = (first, second)
        first, second = bank_cache[key]
        bank_a = next(bank for bank in first["occupied_banks"] if bank["cell"] == name)
        bank_b = next(bank for bank in second["occupied_banks"] if bank["cell"] == name)
        require(bank_a["type"] == bank_b["type"] == "MISTRAL_BUF" and
                bank_a["physical_bank"]["physical_rows_derived"] == bank_b["physical_bank"]["physical_rows_derived"] == 32,
                "buffer actual physical bank not exhaustively derived")
        cells[(name, "Q")] = (qa, qb)
        cells[(ff, "DATAIN")] = (qa, qb)
        nets[private] = (qa, qb)
        buffer_alms[name] = key
        rows.append({"buffer": name, "bel": a["attributes"]["NEXTPNR_BEL"], "alm": list(key),
            "input_raw_bit": raw_input, "input_native_driver_slot": list(old_drivers[raw_input][0]),
            "input_effective_native_driver": list(before_view.scalar(name, "A", "input")),
            "q_before_raw_bit": qa, "q_after_raw_bit": qb, "observed_numeric_id_delta": qb - qa,
            "q_native_owner_slot": [name, "Q", 0, 0], "private_named_alias": private,
            "unique_ff_datain_consumer_slot": list(consumer), "ff_bel": old["cells"][ff]["attributes"]["NEXTPNR_BEL"],
            "q_users_before": [list(user) for user in old_users[qa]], "q_users_after": [list(user) for user in new_users[qb]],
            "buffer_and_ff_metadata_full_pins_exact_except_these_two_raw_slots": True,
            "actual_buffer_pin_states": bank_a["actual_pins"], "effective_buffer_truth": bank_a["effective_native_truth"],
            "physical_bank_before": bank_a["physical_bank"], "physical_bank_after": bank_b["physical_bank"]})
    evidence = []
    for key in sorted(bank_cache):
        first, second = bank_cache[key]
        evidence.append({"alm": list(key), "native_occupants": first["native_occupants"], "saved_fields": first["saved_fields"],
            "physical_input_native_drivers": first["physical_input_native_drivers"],
            "derived_active_low_mask_before_mlab_permutation_hex": first["derived_active_low_64_mask_before_mlab_permutation_hex"],
            "derived_active_low_mask_after_mlab_permutation_hex": first["derived_active_low_64_mask_after_mlab_permutation_hex"],
            "whole_actual_alm_evidence_before_sha256": hashlib.sha256(native.canonical(first).encode()).hexdigest(),
            "whole_actual_alm_evidence_after_sha256": hashlib.sha256(native.canonical(second).encode()).hexdigest(),
            "whole_alm_banks_shared_inputs_ff_controls_exact": True})
    ff_controls = physical.compare_ff_controls(before_view, after_view, sorted({key[:2] for key in alms}))
    return {"rows": rows, "buffer_count": len(rows), "buffer_alm_evidence": evidence,
            "whole_buffer_lab_ff_controls": ff_controls, "buffer_population_metadata_full_pins_and_named_consumer_identity_exact": True,
            "private_raw_ids_checked_by_explicit_owner_slot_ledger_not_global_translation": True,
            "observed_numeric_deltas": dict(sorted(Counter(row["observed_numeric_id_delta"] for row in rows).items())),
            "global_normalization_or_buffer_collapse_used": False}, cells, nets, old_private, new_private, before_view, after_view


def prove_graph(v1, native, physical, frozen, profile, record, before, after, ctx):
    old, new = before["modules"]["top"], after["modules"]["top"]
    graph = ctx["proof"]["graph_evidence"]
    source, clone, sink, port, private = (graph[key] for key in ("source", "clone", "sink", "sink_port", "private_net"))
    compression_evidence = compression(native, frozen, profile, record, old, new)
    expected_top = copy.deepcopy({key: value for key, value in old.items() if key not in {"cells", "netnames"}})
    expected_top["settings"]["compress_rbf"] = "0 "
    require(native.canonical(expected_top) == native.canonical({key: value for key, value in new.items() if key not in {"cells", "netnames"}}),
            "top/public ports/whole LAB snapshot changed beyond exact writer-only compression")
    require(set(new["cells"]) == set(old["cells"]) | {clone} and clone not in old["cells"] and
            set(new["netnames"]) == set(old["netnames"]) | {private} and private not in old["netnames"], "undeclared cell/net population delta")
    require(native.canonical(old["cells"].pll_ports) == native.canonical(new["cells"].pll_ports), "ordered PLL occurrences changed")
    selected_top = ctx["selected_document"]["modules"]["top"]
    for dictionary, addition in (("cells", clone), ("netnames", private)):
        require([name for name in new[dictionary] if name != addition] == list(old[dictionary]), "original full export owner order changed")
        require([name for name in new[dictionary] if name in selected_top[dictionary]] == list(selected_top[dictionary]),
                "selected pre-route original prefix/private suffix order changed")
    ledger, cell_slots, private_nets, old_private, new_private, before_view, after_view = buffer_ledger(v1, native, physical, before, after)
    a, copied = old["cells"][source], new["cells"][clone]
    qa, qc = a["connections"]["Q"][0], copied["connections"]["Q"][0]
    require(new["cells"][sink]["connections"][port] == [qc] and old["cells"][sink]["connections"][port] == [qa] and qc != qa,
            "selected copy redirect does not close current source/operand")
    require((sink, port) not in cell_slots, "selected operand overlaps explicit buffer ledger")
    cell_slots[(sink, port)] = (qa, qc)
    old_nonprivate = all_bits(old) - old_private
    new_nonprivate = all_bits(new) - new_private - {qc}
    require(old_nonprivate == new_nonprivate and qc not in old_nonprivate and qc not in new_private,
            "copy/buffer private native bit partitions overlap or original non-private IDs changed")
    for name, cell in old["cells"].items():
        expected = copy.deepcopy(cell)
        for pin, bits in cell["connections"].items():
            row = cell_slots.get((name, pin))
            if row:
                require(bits == [row[0]], "ledger is not the exact original scalar port slot")
                expected["connections"][pin] = [row[1]]
        require(native.canonical(expected) == native.canonical(new["cells"][name]), "original cell changed outside explicit raw slot ledger: " + name)
    for name, net in old["netnames"].items():
        expected, actual = copy.deepcopy(net), copy.deepcopy(new["netnames"][name])
        row = private_nets.get(name)
        if row:
            require(expected["bits"] == [row[0]], "ledger is not exact original private named Q alias")
            expected["bits"] = [row[1]]
        expected["attributes"].pop("ROUTING", None)
        actual["attributes"].pop("ROUTING", None)
        require(native.canonical(expected) == native.canonical(actual), "original net changed outside explicit private alias/routing ledger: " + name)
    selected_copy = selected_top["cells"][clone]
    require(set(copied) == set(selected_copy) and copied["type"] == selected_copy["type"] and
            copied["parameters"] == selected_copy["parameters"] and copied["port_directions"] == selected_copy["port_directions"] and
            copied["hide_name"] == selected_copy["hide_name"] and copied["connections"] == selected_copy["connections"] and
            {key: value for key, value in copied["attributes"].items() if key != "FES_PINMAP_V1"} == selected_copy["attributes"] and
            "FES_PINMAP_V1" in copied["attributes"], "actual copy differs from its independently selected snapshot")
    named = new["netnames"][private]
    require(set(named) == {"hide_name", "bits", "attributes"} and named["hide_name"] == int(private.startswith("$")) and
            named["bits"] == [qc] and set(named["attributes"]) == {"ROUTING"} and type(named["attributes"]["ROUTING"]) is str and
            named["attributes"]["ROUTING"].strip(), "new private copy Q alias is not precisely its actual routed net")
    old_drivers, old_users = v1.tables(old)
    new_drivers, new_users = v1.tables(new)
    expected_drivers, expected_users = {}, {}
    for bit, owners in old_drivers.items():
        for slot in owners:
            name, pin, index, occurrence = slot
            row = cell_slots.get((name, pin))
            destination = row[1] if row else bit
            require(not row or index == occurrence == 0 and bit == row[0], "output ledger vector/occurrence mismatch")
            expected_drivers.setdefault(destination, []).append(slot)
    expected_drivers.setdefault(qc, []).append((clone, "Q", 0, 0))
    for bit, users in old_users.items():
        for slot in users:
            name, pin, index, occurrence = slot
            row = cell_slots.get((name, pin))
            destination = row[1] if row else bit
            require(not row or index == occurrence == 0 and bit == row[0], "input ledger vector/occurrence mismatch")
            expected_users.setdefault(destination, []).append(slot)
    loads = []
    for pin in "ABC":
        bits = copied["connections"][pin]
        require(bits == a["connections"][pin], "copy input native signal differs")
        if bits:
            require(len(bits) == 1 and len(old_drivers.get(bits[0], [])) == 1, "copy input source identity unresolved")
            expected_users.setdefault(bits[0], []).append((clone, pin, 0, 0))
            loads.append({"logical_port": pin, "native_bit": bits[0], "native_driver": list(old_drivers[bits[0]][0])})
    expected_drivers = {bit: sorted(rows) for bit, rows in expected_drivers.items()}
    expected_users = {bit: sorted(rows) for bit, rows in expected_users.items()}
    require(new_drivers == expected_drivers and new_users == expected_users, "complete actual raw driver/user tables differ outside explicit slot ledger")
    require(loads == graph["declared_copy_input_loads"] and len(old_users[qa]) == 49 and len(new_users[qa]) == 48 and
            new_users[qc] == [(sink, port, 0, 0)] and new_drivers[qc] == [(clone, "Q", 0, 0)], "source49→48/copy1/load multiplicity differs")
    coverage = [v1.pin_coverage(physical, view) for view in (before_view, after_view)]
    copy_evidence = physical.prove_lut_copy(before_view, after_view, source, clone, sink, port, expected_original_users=49)
    declared = []
    keys = [tuple(key) for key in ctx["scope"]["declared_alm_keys"]]
    for key in keys:
        first, second = physical.evaluate_alm(before_view, key), physical.evaluate_alm(after_view, key)
        require(first["saved_fields"] == second["saved_fields"], "source/copy/sink/successor ALM/LAB/FF selectors changed")
        declared.append({"alm": list(key), "before": first, "after": second})
    controls = physical.compare_ff_controls(before_view, after_view, sorted({key[:2] for key in keys}))
    return {"original_cells_params_attrs_bels_full_pins_exact_outside_explicit_slot_ledger": True,
            "all_original_nonprivate_numeric_bits_preserved_exactly": True,
            "original_nonprivate_native_bit_count": len(old_nonprivate), "buffer_private_bits_before": len(old_private),
            "buffer_private_bits_after": len(new_private), "cross_image_private_id_overlap_count": len(old_private & new_private),
            "new_copy_id_was_an_old_buffer_private_id": qc in old_private,
            "explicit_named_buffer_private_bit_and_unique_ff_ledger": ledger,
            "compression_writer_only_metadata_carveout": compression_evidence,
            "original_full_export_order_and_selected_prefix_private_suffix_exact": True,
            "ordered_lossless_pll_records_public_ports_and_whole_lab_snapshot_exact": True,
            "complete_raw_native_output_driver_and_input_user_slot_tables_closed": True,
            "source_q_users_before": 49, "source_q_users_after": 48, "private_copy_q_users": 1,
            "actual_copy_input_loads": loads, "distinct_copy_input_net_count": len({row["native_bit"] for row in loads}),
            "actual_physical_lut_copy": copy_evidence, "declared_source_clone_sink_successor_alm_evidence": declared,
            "whole_declared_lab_ff_controls": controls, "full_scalar_vector_pin_coverage_counts": coverage,
            "global_numeric_id_normalization_or_buffer_collapse_used": False,
            "rbf_byte_equivalence_or_cram_decode_claimed": False,
            "in_memory_comb_cache_indexed_user_gpu_state_or_hardware_proved": False}


def comparison(generator_sha, scope_sha):
    v1 = module(FIRST / "compare_route.py", "copy_full_strict_v1_pure_apis", FIRST_SHA)
    native = module(v1.PURE, "copy_full_v2_native", v1.PURE_SHA)
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), generator_sha), (HERE / "scope.md", scope_sha),
                           (FIRST / "compare_route.py", FIRST_SHA), (FIRST / "scope.md", FIRST_SCOPE_SHA),
                           (FIRST / "comparison.json", FIRST_PROOF_SHA), (v1.PURE, v1.PURE_SHA),
                           (v1.FULL / "freeze.py", v1.FREEZE_SHA)):
        audit.bind(path, expected)
    rejected = native.read(FIRST / "comparison.json")
    require(rejected["candidate_completed"] is True and rejected["graph_proof_available"] is False and
            rejected["candidate_accepted_under_confirmed_target_clock_rule"] is False and
            rejected["source_identity_sha256"] == v1.FULL_ID_SHA and rejected["generator_sha256"] == FIRST_SHA and
            rejected["structural_rejection"] == "native top metadata/settings/public ports/whole LAB snapshot changed" and
            rejected["final_original_path_metadata_and_runtime_hashes_stable"] is True, "immutable strict rejection lineage differs")
    frozen = module(v1.FULL / "freeze.py", "copy_full_v2_frozen_recorder", v1.FREEZE_SHA)
    profile, inputs, ctx = frozen.authenticate_freeze(v1.FULL_ID_SHA)
    for path, expected in inputs.items():
        audit.adopt_verified(Path(path), expected)
    for path, expected in rejected["artifact_sha256"].items():
        require(not Path(path).is_absolute() and ".." not in Path(path).parts, "strict artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    for path, expected in rejected["execution_file_sha256"].items():
        audit.bind(Path(path), expected, execution=True)
    audit.bind(v1.FOLDER / "run.json")
    record = native.read(v1.FOLDER / "run.json")
    frozen.authenticate_phase(record, profile, v1.FULL_ID_SHA, ctx)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True, "full route is not completed audited execution")
    for path, expected in record["execution"]["files"].items():
        audit.bind(Path(path), expected, execution=True)
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "actual full output empty")
        audit.bind(Path(path), expected)
    require(record["output_sha256"][str(v1.FOLDER / "core.rbf")] == rejected["rbf_sha256"], "strict rejection is not the same actual full RBF")
    audit.bind(v1.REFERENCE / "comparison.json", v1.REFERENCE_PROOF_SHA)
    accepted = native.read(v1.REFERENCE / "comparison.json")
    require(accepted["reproduction_proved"] is True and accepted["native_graph_and_rbf_reproduced"] is True and
            accepted["candidate_accepted_under_confirmed_target_clock_rule"] is True, "accepted reference proof not closed")
    require(all(inputs.get(str(ROOT / path)) == expected for path, expected in accepted["artifact_sha256"].items()) and
            all(inputs.get(path) == expected for path, expected in accepted["execution_file_sha256"].items()), "accepted flat closure omitted")
    audit.bind(v1.REFERENCE / "routed.json", v1.REFERENCE_GRAPH_SHA)
    audit.bind(v1.PHYSICAL / "physical_lut.py", v1.PHYSICAL_SHA)
    audit.bind(v1.PHYSICAL / "scope.md", v1.PHYSICAL_SCOPE_SHA)
    audit.bind(v1.PHYSICAL / "reference-validation.json", v1.REFERENCE_VALIDATION_SHA)
    validation = native.read(v1.PHYSICAL / "reference-validation.json")
    require(validation["actual_reference_snapshot_validation_passed"] is True and validation["copy_or_new_route_equivalence_proved"] is False,
            "physical reference exercise invalid")
    for path, expected in validation["input_sha256"].items():
        audit.bind(Path(path), expected)
    audit.bind(v1.PHYSICAL / "validate_reference.py", validation["validator_sha256"])
    physical = module(v1.PHYSICAL / "physical_lut.py", "copy_full_v2_physical", v1.PHYSICAL_SHA)
    before, after = native.read_netlist(v1.REFERENCE / "routed.json"), native.read_netlist(v1.FOLDER / "routed.json")
    ctx["selected_document"] = native.read_netlist(frozen.SELECTED_FOLDER / "placed.json")
    log = (v1.FOLDER / "route.log").read_text()
    require("Info: Program finished normally." in log and "Running the GPU router" in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()), "full GPU/compiler normal completion missing")
    board_path = ROOT / "sources/misteross/scripts/fes_build_common.py"
    require(str(board_path) in record["input_sha256"], "board GPU guard absent from execution closure")
    audit.bind(board_path, record["input_sha256"][str(board_path)])
    sys.path.insert(0, str(ROOT / "sources/misteross"))
    board = module(board_path, "copy_full_v2_gpu_guard", record["input_sha256"][str(board_path)])
    backend = board._require_gpu_backend(log)
    require(v1.re.search(r"GPU router time [^\n]+backend hip:", log), "live HIP routing completion absent")
    report, parent, selected_report = native.read(v1.FOLDER / "timing.json"), native.read(v1.REFERENCE / "timing.json"), native.read(frozen.SELECTED_FOLDER / "timing.json")
    timing = v1.timing(native, after["modules"]["top"], report, parent, selected_report, log, record)
    require(native.canonical(timing) == native.canonical(rejected["raw_timing"]), "same actual frozen route timing diagnostic changed")
    graph, rejection = None, None
    try:
        prefixes = native.DIAGNOSTIC_PREFIXES + ("Info: LUT driver copy",)
        selected_log = (frozen.SELECTED_FOLDER / "phase.log").read_text()
        require([line for line in log.splitlines() if line.startswith(prefixes)] ==
                [line for line in selected_log.splitlines() if line.startswith(prefixes)], "current guarded selections/upstream stages changed")
        require(len(native.PLACEMENT_METRICS.findall(log)) == 71 and native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(selected_log),
                "71 ordinary placement metrics changed")
        graph = prove_graph(v1, native, physical, frozen, profile, record, before, after, ctx)
    except (ValueError, KeyError, TypeError) as error:
        rejection = str(error)
    proved = rejection is None
    audit.finish()
    return {"schema": 1, "phase": "explicit-private-buffer-ledger-lut-driver-copy-full", "compiler_commit": profile["result_commit"],
            "source_identity_sha256": v1.FULL_ID_SHA, "selected_proof_sha256": ctx["proof_sha256"],
            "superseded_strict_rejection_sha256": FIRST_PROOF_SHA, "strict_rejection_preserved_immutable": True,
            "generator_sha256": generator_sha, "scope_sha256": scope_sha, "reused_strict_pure_api_sha256": FIRST_SHA,
            "reference_proof_sha256": v1.REFERENCE_PROOF_SHA, "physical_evaluator_sha256": v1.PHYSICAL_SHA,
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"], "gpu_backend": backend,
            "structural_rejection": rejection, "graph_proof_available": proved, "full_graph_and_pin_equivalence_proved": proved,
            "actual_one_copy_one_operand_and_explicit_buffer_private_bit_proof": graph, "raw_timing": timing,
            "passes_practical_timing_gate": proved and timing["passes_practical_timing_gate"],
            "passes_strict_all_clock_diagnostic_gate": proved and timing["passes_practical_timing_gate"] and timing["all_clock_fmax_nonregression_vs_accepted_reference"],
            "candidate_accepted_under_confirmed_target_clock_rule": proved and timing["passes_practical_timing_gate"],
            "rbf_sha256": record["output_sha256"][str(v1.FOLDER / "core.rbf")], "rbf_byte_equivalence_or_cram_decode_claimed": False,
            "old_comparison_generators_or_main_executed": False, "global_id_normalization_or_buf_collapse_used": False,
            "hardware_tested": False, "default_recipe_selected": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True,
            "proof_limitations": [
                "The immutable strict first rejection remains bound and unchanged. This separately reviewed scope permits only the actual named BUF.Q/private-alias/unique FF.DATAIN raw slot ledger and exact writer-only compression setting.",
                "Numeric IDs are document-local: the clone may use a former private-buffer ID. Every actual native owner, unique private alias, sole consumer and entire driver/user table is checked in its own image; no global offset or signal collapse is applied.",
                "All original non-private numeric bits and all cell metadata/full pins/BELs/whole LAB state/PLL/public ports remain strict outside the declared operand/private slots; routing attributes may differ.",
                "Every buffer physical bank and shared ALM/FF controls is evaluated in both images, alongside the actual copy/source/arithmetic/carry closure. This derives exported-model masks, not decoded RBF/CRAM or hidden cache/index/GPU state.",
                "The complete current expanded native timing paths, all actual non-target windows, required other constraints and last reported holds are checked on the same actual route. Target130 may remain open; positive headroom reduction is allowed and disclosed.",
                "RBF compression differs by the authenticated writer flag; no RBF byte equivalence or hardware acceptance is claimed."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compare-route-py-sha256", required=True)
    parser.add_argument("--scope-md-sha256", required=True)
    args = parser.parse_args()
    output = HERE / "comparison.json"
    require(not output.exists(), "versioned proof output already exists")
    result = comparison(args.compare_route_py_sha256, args.scope_md_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("graph_proof_available", "structural_rejection", "candidate_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__":
    main()
