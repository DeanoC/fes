Latest accepted fixed-input OSS compiler result: **117.34334564208984 MHz memory**, up from **116.64527893066406 MHz** (+0.6980667114257812 MHz).

The generic compiler work is now in [nextpnr PR #104](https://github.com/DeanoC/nextpnr/pull/104), stacked on #103. It adds guarded placed LUT driver copying, complete affected endpoint clock-pair qualification and bounded actual setup endpoint reports. Production code uses timing/connectivity/device geometry, with no RAM-test cell-name or placement rules.

| Reported clock | Reference MHz | Current MHz |
| --- | ---: | ---: |
| Memory | 116.645279 | 117.343346 |
| Pixel | 93.309692 | 93.492897 |
| Capture | 307.631805 | 378.582397 |

All three improve. The complete current report covers 15,290 paths across seven actual clock pairs. Required non-target windows remain positive: capture-to-memory headroom is 3.283 ns in its 5 ns window, and falling-to-rising memory headroom is 2.091 ns in its 3.846 ns window. The last signoff reports zero hold violations.

Independent full exported-model proof `a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304` passes native topology, the one-operand LUT-copy transformation, input loads, physical masks/pins, paired arithmetic/carry state, LAB controls, PLL records and an explicit 5,232-buffer private-bit identity ledger. The first strict comparison remains preserved as a rejection; no global numeric normalization or buffer collapse was used. The proof binds 526 artifacts and 281 execution files. Measured compiler source is `5dd69a8ddece6280d576816d2277c73f80607f52`; PR documentation records the exact invocation and source/binary/run/proof hashes.

**130 MHz remains unresolved**: memory's reported window is 7.692 ns with 8.522 ns complete delay (−0.830 ns headroom). This is compiler timing evidence, with no new hardware acceptance or FES default compiler/recipe selection. The next bottleneck is HPS ready feeding DDR1 skid-register enables; the next controlled experiment expands the existing generic local fold and refreshes driver-copy qualification.
