Critical LUT-to-arithmetic paths can keep a shared decode far from one important consumer. Add an opt-in Mistral pass that copies the LUT near that operand, retains the original source and other consumers, and qualifies the new loads and dedicated carry neighborhood before routing. Production selection uses connectivity, timing and device geometry, with no RAM-test names or coordinates.

Stacked on #103. The base branch is refreshed with the already validated main revisions; the compiler and test bytes here match measured source `5dd69a8ddece6280d576816d2277c73f80607f52`.

The pass checks every affected endpoint clock pair. Timed pairs retain their actual setup/hold relationships; unrelated pairs must retain path maxima and minima in both normal and reference-free clock-skew frames. Unknown or incomplete timing rejects the candidate. Add bounded actual setup endpoint reports (`--timing-report-paths`, default 1, maximum 16,384), fresh explicitly requested predicted reports after placement, and bounded preflight rejection diagnostics. All optimizations remain opt-in.

The fixed-input RAM-test profile reaches **117.343 MHz memory**, up from **116.645 MHz**. Pixel improves to 93.493 MHz and capture to 378.582 MHz. All seven reported clock-pair windows are checked, required non-target windows retain positive headroom, and final signoff reports no hold violations. Memory still misses 130 MHz.

The independent full exported-model proof passes the one-operand/LUT-copy change, input loads, native driver/consumer identities, full pins, masks, paired arithmetic/carry banks, LAB controls and ordered PLL records. An explicit per-buffer ledger preserves all 5,232 existing route-through owners and consumers despite reassigned private export numbers. The original strict rejection is retained; there is no blanket numeric normalization or buffer collapse. The uncompressed RBF differs from the compressed reference and no RBF/CRAM decode or hardware acceptance is claimed.

Validation: Mistral build, 31 focused backend/CLI cases, generic-architecture compile, fresh candidate listing and selected native proof, full HIP GPU route and independent final proof. The earlier 37-case backend run is recorded separately. The validation record includes source/binary/input/run/proof hashes and exact invocation. FES compiler pins and default recipes remain separate integration work.

See `docs/mistral-lut-driver-copy.md` and `docs/validation/ramtest-lut-driver-copy-2026-10-01.json` for reproduction inputs, measurements and limits. Tracks DeanoC/fes#264.
