"""Record closed root-executed checks for the opt-in driver-copy experiment."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
FES = HERE.parents[2]
SOURCE = FES / 'sources/misteross/build/toolchain-ramtest-timing/src/nextpnr-driver-copy-264'
BUILD = FES / 'sources/misteross/build/toolchain-ramtest-timing/build/nextpnr-driver-copy-264'
BASE = '0c59d78a9d672f5ddc4a81b622055b125f1d2522'
COMMIT = None

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args], text=True).strip()

def main():
    global COMMIT
    parser = argparse.ArgumentParser()
    parser.add_argument('--commit', required=True)
    args = parser.parse_args()
    COMMIT = args.commit
    assert re.fullmatch(r'[0-9a-f]{40}', COMMIT)
    assert git('rev-parse', 'HEAD') == COMMIT
    assert not git('status', '--porcelain')
    assert git('merge-base', BASE, COMMIT) == BASE
    v = HERE / 'validation'
    checks = {}
    for name, filename, count in [('driver_backend', 'driver-backend-v2.log', 7),
                                   ('focused_backend', 'focused-backend-v2.log', 37)]:
        log = (v / filename).read_text()
        assert f'[  PASSED  ] {count} tests.' in log
        assert '[  FAILED  ]' not in log
        match = re.search(r'\[==========\] '+str(count)+r' tests from .* ran\. \((\d+) ms total\)', log)
        assert match
        checks[name] = dict(passed=True, exit_code=0, cases=count,
                            elapsed_seconds=int(match.group(1))/1000)
    cli = (v / 'driver-cli-v2.log').read_text()
    match = re.search(r'Ran 10 tests in ([\d.]+)s\s+OK\s*$', cli)
    assert match and not re.search(r'FAIL|ERROR', cli)
    checks['driver_cli'] = dict(passed=True, exit_code=0, cases=10,
                                elapsed_seconds=float(match.group(1)))
    build = (v / 'build-v4.log').read_text()
    assert 'Built target nextpnr-mistral' in build and 'Built target nextpnr-mistral-test' in build
    assert 'error:' not in build and 'warning:' not in build
    logs = [v / name for name in ['configure.log', 'configure-committed.log', 'configure-v2.log',
                                  'configure-v3.log', 'configure-v4.log', 'build.log', 'build-v2.log', 'build-v4.log',
                                  'driver-backend-v2.log', 'driver-cli-v2.log', 'focused-backend-v2.log']]
    binaries = [BUILD / 'nextpnr-mistral', BUILD / 'nextpnr-mistral-test', BUILD / 'CMakeCache.txt']
    changed = ['mistral/CMakeLists.txt', 'mistral/arch.cc', 'mistral/arch.h', 'mistral/main.cc',
               'mistral/lut_driver_copy.cc', 'mistral/lut_driver_copy.h',
               'mistral/tests/lut_driver_copy.cc', 'mistral/tests/lut_driver_copy_cli.py']
    record = dict(schema=1, result_commit=COMMIT, delta_base_commit=BASE,
                  clean_committed_checkout=True, build_passed=True,
                  binary_sha256=sha(binaries[0]), test_binary_sha256=sha(binaries[1]),
                  source_sha256={str(SOURCE / name): sha(SOURCE / name) for name in changed},
                  artifact_sha256={str(path): sha(path) for path in logs + binaries + [Path(__file__).resolve()]},
                  checks=checks, hardware_tested=False,
                  retained_prior_build_records=dict(
                      first_build_failed_const_compatibility=True,
                      second_build_passed_with_existing_narrowing_and_three_test_brace_warnings=True,
                      final_incremental_build_passed_without_warnings=True))
    with (v / 'host-validation-v2.json').open('x') as out:
        out.write(json.dumps(record, sort_keys=True, indent=2, allow_nan=False)+'\n')
    print(json.dumps(dict(commit=COMMIT, binary_sha256=record['binary_sha256'],
                         host_validation_sha256=sha(v / 'host-validation-v2.json'), checks=checks), indent=2))

if __name__ == '__main__':
    main()
