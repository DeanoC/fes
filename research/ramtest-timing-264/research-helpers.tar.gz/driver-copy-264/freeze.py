"""Root-only activation and flat authentication for two driver-copy listings."""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
TOOLCHAIN = MODULE / "build/toolchain-ramtest-timing"
SOURCE = TOOLCHAIN / "src/nextpnr-driver-copy-264"
MISTRAL = TOOLCHAIN / "src/mistral"
BASE = "0c59d78a9d672f5ddc4a81b622055b125f1d2522"
REFERENCE = HERE.parent / "narrow-integrated-264/route-reproduction"
REFERENCE_SHA = "01886d65d6e55f1f1c1d5345e00e3dee5358ce672b0f4a3bac3135f6ec155d4e"
PURE = HERE.parent / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
IDENTITY = HERE / "source-identity.json"
HELPERS = ("freeze.py", "run.py", "compare_listing.py", "proof-scope.md")
PHASES = {"baseline": HERE / "baseline", "list-driver": HERE / "list-driver"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def digest(value, width=64):
    return (type(value) is str and re.fullmatch(r"[0-9a-f]{%d}" % width, value) is not None
            and len(set(value)) > 1)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata: " + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def bind(inputs, path, expected):
    path = Path(path).absolute()  # Keep the supplied symlink pathname through final rehash.
    require(digest(expected), "unset/invalid input hash: " + str(path))
    if str(path) in inputs:
        require(inputs[str(path)] == expected, "conflicting input identity: " + str(path))
        return
    require(sha(path) == expected, "input changed: " + str(path))
    inputs[str(path)] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "original input path changed during operation: " + path)


def reference(inputs):
    bind(inputs, REFERENCE / "comparison.json", REFERENCE_SHA)
    proof = read(REFERENCE / "comparison.json")
    require(all(proof[key] is True for key in (
        "reproduction_proved", "native_graph_and_rbf_reproduced", "graph_proof_available",
        "candidate_accepted_under_confirmed_target_clock_rule", "passes_practical_timing_gate",
        "final_original_path_metadata_and_runtime_hashes_stable")) and
        proof["structural_rejection"] is None and proof["diagnostic_only_not_proved"] is False,
        "integrated reference is not the finalized accepted reproduction")
    require(len(proof["artifact_sha256"]) == 339 and len(proof["execution_file_sha256"]) == 281,
            "integrated cached closure shape differs")
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts,
                "cached artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "cached runtime path is not absolute")
        bind(inputs, name, expected)
    bind(inputs, PURE, PURE_SHA)
    run = read(REFERENCE / "run.json")
    require(run["completed"] is True and run["exit_code"] == 0 and
            run["compiler_commit"] == BASE and run["phase"] == "integrated-reproduction" and
            run["compiler_read_audit_passed"] is True and run["final_reported_hold_violations"] is False,
            "integrated run is not the completed accepted full profile")
    for name, expected in run["input_sha256"].items():
        require(inputs.get(name) == expected, "reference run input is outside the closed proof")
    for name in ("run.json", "route.log", "routed.json", "timing.json", "core.rbf"):
        require(str(REFERENCE / name) in inputs, "reference proof lacks actual output: " + name)
    return run, proof


def expected_command(parent, phase):
    require(phase in PHASES, "only baseline/list-driver phases are implemented")
    command = list(parent["command"])
    require("--no-route" not in command and not any(option.startswith("--remap-lut-driver") for option in command),
            "reference already has a listing/copy stage")
    for option in ("--rbf",):
        require(command.count(option) == 1, "reference output selector is ambiguous: " + option)
        index = command.index(option)
        del command[index:index + 2]
    require(command.count("--compress-rbf") == 1, "reference compression selector differs")
    command.remove("--compress-rbf")
    require(command.count("--write") == 1, "reference write selector is ambiguous")
    command[command.index("--write") + 1] = str(PHASES[phase] / "placed.json")
    require(command.count("--report") == 1, "reference report selector is ambiguous")
    command[command.index("--report") + 1] = str(PHASES[phase] / "timing.json")
    command[0] = str(HERE / "nextpnr-mistral")
    command += ["--no-route"]
    if phase == "list-driver":
        command += ["--remap-lut-driver-critical", str(PHASES["baseline"] / "timing.json"),
                    "--remap-lut-driver-candidate", "-1"]
    require(command.count("--no-route") == 1 and command.count("--router") == 1 and
            command[command.index("--router") + 1] == "gpu" and command.count("--gpu-device") == 1 and
            command[command.index("--gpu-device") + 1] == "1" and
            not any(option in command for option in ("--rbf", "--compress-rbf", "--no-place", "--no-pack")),
            "listing command changed the inherited placement profile")
    return command


def expected_runtime(parent, source):
    runtime = json.loads(json.dumps(parent["execution"]))
    old = parent["command"][0]
    require(runtime["files"].pop(old) == source["input_sha256"][old], "reference runtime executable differs")
    runtime["files"][str(HERE / "nextpnr-mistral")] = source["binary_sha256"]
    runtime["environment"]["PATH"] = str(HERE) + ":/usr/bin:/bin"
    return runtime


def baseline_binding(inputs, identity_sha):
    folder = PHASES["baseline"]
    bind(inputs, folder / "run.json", sha(folder / "run.json"))
    run = read(folder / "run.json")
    require(run["phase"] == "baseline" and run["source_identity_sha256"] == identity_sha and
            run["completed"] is True and run["exit_code"] == 0 and run["compiler_read_audit_passed"] is True,
            "own same-binary baseline is not completed")
    require(set(run["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")},
            "baseline output closure differs")
    for path, expected in run["output_sha256"].items():
        bind(inputs, path, expected)
    return {str(folder / "run.json"): inputs[str(folder / "run.json")], **run["output_sha256"]}


def record_template(source, identity_sha, phase, execution, baseline=None):
    parent = read(REFERENCE / "run.json")
    inputs = {**source["input_sha256"], str(IDENTITY): identity_sha, **(baseline or {})}
    require((phase == "list-driver") == (baseline is not None), "listing requires exactly its own baseline binding")
    return {"schema": 1, "kind": "fresh same-binary driver-copy listing", "phase": phase,
        "compiler_commit": source["result_commit"], "delta_base_commit": BASE,
        "source_identity_sha256": identity_sha, "source_archive_sha256": source["source_archive_sha256"],
        "binary_sha256": source["binary_sha256"], "host_validation_sha256": source["host_validation_sha256"],
        "reference_proof_sha256": REFERENCE_SHA, "reference_run_sha256": source["reference_run_sha256"],
        "accepted_routed_guide_sha256": source["accepted_routed_guide_sha256"],
        "driver_guide_kind": "actual same-new-binary baseline predicted placed timing report",
        "driver_guide_sha256": baseline[str(PHASES["baseline"] / "timing.json")] if baseline is not None else None,
        "helper_sha256": source["helper_sha256"],
        "command": expected_command(parent, phase), "diagnostic_environment": parent["diagnostic_environment"],
        "cwd": parent["cwd"], "execution": execution, "input_sha256": inputs,
        "baseline_artifact_sha256": baseline, "driver_candidate": -1 if phase == "list-driver" else None,
        "same_new_binary_baseline_required": True, "fresh_driver_ordinals_required": True,
        "driver_stage_is_last": True, "routed_proof_or_timing_gain_claimed": False,
        "completed": False, "hardware_tested": False}


def authenticate_phase(run, source, identity_sha, baseline=None):
    require(run["phase"] in PHASES, "unsupported phase")
    expected = record_template(source, identity_sha, run["phase"], run["execution"], baseline)
    mutable = {"completed", "elapsed_seconds", "exit_code", "output_sha256", "compiler_read_audit_passed",
               "failure", "exit_code_is_adapter_sentinel"}
    require({key: value for key, value in run.items() if key not in mutable} ==
            {key: value for key, value in expected.items() if key not in mutable}, "actual phase metadata differs")
    require(run["execution"] == expected_runtime(read(REFERENCE / "run.json"), source),
            "actual runtime differs beyond new compiler/PATH")
    require(type(run["completed"]) is bool and "failure" not in run and "exit_code_is_adapter_sentinel" not in run,
            "phase has failed/sentinel execution")
    if run["completed"]:
        folder = PHASES[run["phase"]]
        require(type(run["exit_code"]) is int and run["exit_code"] == 0 and
                type(run["elapsed_seconds"]) in (float, int) and math.isfinite(run["elapsed_seconds"]) and run["elapsed_seconds"] >= 0 and
                run["compiler_read_audit_passed"] is True and
                set(run["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")},
                "completed phase lacks audited normal exit/output closure")


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def snapshot(repo, label, archives, repositories, expected=None):
    commit = git(repo, "rev-parse", "HEAD").decode().strip()
    require(expected is None or commit == expected, "source commit differs: " + label)
    require(not git(repo, "status", "--porcelain=v1", "--untracked-files=no").strip(), "source/submodule dirty: " + label)
    payload = git(repo, "archive", "--format=tar", commit)
    member = "archives/" + label + ".tar"
    archives[member] = payload
    links = {}
    for entry in git(repo, "ls-tree", "-r", "-z", commit).split(b"\0"):
        if not entry:
            continue
        header, name = entry.split(b"\t", 1)
        mode, _, object_id = header.decode().split()
        if mode == "160000":
            name = name.decode()
            initialized = (repo / name / ".git").exists()
            links[name] = {"commit": object_id, "archived": initialized}
            if initialized:
                snapshot(repo / name, label + "/" + name, archives, repositories, object_id)
    repositories[label] = {"path": str(repo), "commit": commit,
        "tree": git(repo, "rev-parse", commit + "^{tree}").decode().strip(),
        "archive_member": member, "archive_sha256": hashlib.sha256(payload).hexdigest(), "gitlinks": links}


def check_library(repositories, inputs):
    identity = REFERENCE.parent / "source-identity.json"
    require(str(identity) in inputs, "accepted source identity is outside the cached proof")
    accepted = read(identity)["repositories"]
    select = lambda rows: {name: row for name, row in rows.items() if name == "mistral" or name.startswith("mistral/")}
    require(select(repositories) == select(accepted) and "mistral" in repositories,
            "Mistral model/library revision, tree, archive or gitlinks changed from accepted integration")


def host_sources(validation):
    result = {}
    for path, expected in validation["source_sha256"].items():
        path = Path(path)
        require(".." not in path.parts and digest(expected), "invalid host source pathname/hash")
        if path.is_absolute():
            require(path.is_relative_to(SOURCE), "host source escaped the selected checkout")
            path = path.relative_to(SOURCE)
        require(str(path) not in result, "duplicate host source member")
        result[str(path)] = expected
    return result


def check_validation(validation, commit, binary):
    require(validation["result_commit"] == commit and validation["delta_base_commit"] == BASE and
            validation["clean_committed_checkout"] is True and validation["build_passed"] is True and
            validation["binary_sha256"] == binary, "host validation/compiler identity differs")
    require({"driver_backend", "driver_cli"} <= set(validation["checks"]) and
            all(row["passed"] is True and type(row["exit_code"]) is int and row["exit_code"] == 0
                for row in validation["checks"].values()), "host checks are incomplete or failed")
    require(validation["artifact_sha256"] and
            {"mistral/lut_driver_copy.cc", "mistral/tests/lut_driver_copy.cc"} <= set(host_sources(validation)),
            "host manifest omits actual logs/source byte hashes")


def authenticate_freeze(identity_sha):
    inputs = {}
    bind(inputs, IDENTITY, identity_sha)
    source = read(IDENTITY)
    require(source["schema"] == 1 and digest(source["result_commit"], 40) and source["delta_base_commit"] == BASE and
            source["reference_proof_sha256"] == REFERENCE_SHA and source["clean_committed_checkout_at_freeze"] is True and
            source["listing_only_package"] is True and source["full_or_selected_phase_available"] is False,
            "frozen activation identity differs")
    for path, expected in source["input_sha256"].items():
        require(Path(path).is_absolute(), "input map contains nonabsolute pathname")
        bind(inputs, path, expected)
    parent, _ = reference(inputs)  # Already-hashed entries are memoized, no generator replay.
    require(source["helper_sha256"] == {name: inputs.get(str(HERE / name)) for name in HELPERS} and
            source["reference_run_sha256"] == inputs[str(REFERENCE / "run.json")] and
            source["accepted_routed_guide_sha256"] == inputs[str(REFERENCE / "timing.json")] and
            inputs[str(HERE / "nextpnr-mistral")] == source["binary_sha256"] and
            inputs[str(HERE / "source.tar.gz")] == source["source_archive_sha256"] and
            inputs[source["host_validation_path"]] == source["host_validation_sha256"], "frozen aliases differ")
    validation = read(source["host_validation_path"])
    check_validation(validation, source["result_commit"], source["binary_sha256"])
    check_library(source["repositories"], inputs)
    require(source["commands"] == {phase: expected_command(parent, phase) for phase in PHASES} and
            source["diagnostic_environment"] == parent["diagnostic_environment"], "sealed phase profile differs")
    with tarfile.open(HERE / "source.tar.gz", "r:gz") as outer:
        rows = source["repositories"]
        expected = {row["archive_member"]: row["archive_sha256"] for row in rows.values()}
        members = outer.getmembers()
        require(len(members) == len(expected) and all(member.isfile() for member in members) and
                {member.name for member in members} == set(expected), "archive member set differs")
        payloads = {}
        for member in members:
            payload = outer.extractfile(member).read()
            require(hashlib.sha256(payload).hexdigest() == expected[member.name], "archive payload differs")
            payloads[member.name] = payload
        require(rows["nextpnr"]["path"] == str(SOURCE) and rows["nextpnr"]["commit"] == source["result_commit"] and
                rows["mistral"]["path"] == str(MISTRAL), "archive repositories differ")
        with tarfile.open(fileobj=io.BytesIO(payloads[rows["nextpnr"]["archive_member"]]), mode="r:") as archive:
            for name, expected in host_sources(validation).items():
                member = archive.getmember(name)
                require(member.isfile() and hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected,
                        "host-tested source bytes differ from committed archive: " + name)
    return source, inputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--binary-sha256", required=True)
    parser.add_argument("--host-validation", type=Path, required=True)
    parser.add_argument("--host-validation-sha256", required=True)
    for name in HELPERS:
        parser.add_argument("--" + name.replace(".", "-").replace("_", "-") + "-sha256", required=True)
    args = parser.parse_args()
    require(args.source.resolve() == SOURCE.resolve() and digest(args.commit, 40) and digest(args.binary_sha256),
            "explicit source/commit/binary pins are unset or differ")
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json", "build-config.txt")),
            "freeze output already exists")
    inputs = {}
    parent, _ = reference(inputs)
    for name in HELPERS:
        expected = getattr(args, name.replace(".", "_").replace("-", "_") + "_sha256")
        bind(inputs, HERE / name, expected)
    bind(inputs, args.host_validation, args.host_validation_sha256)
    validation = read(args.host_validation)
    check_validation(validation, args.commit, args.binary_sha256)
    for path, expected in validation["artifact_sha256"].items():
        bind(inputs, path if Path(path).is_absolute() else ROOT / path, expected)
    build = args.build.resolve()
    require(build.is_relative_to(TOOLCHAIN / "build") and sha(build / "nextpnr-mistral") == args.binary_sha256,
            "explicit validated producer binary differs")
    cache = (build / "CMakeCache.txt").read_text()
    require("CMAKE_HOME_DIRECTORY:INTERNAL=" + str(SOURCE) + "\n" in cache and
            re.search(r"^MISTRAL_ROOT:(?:STRING|PATH)=" + re.escape(str(MISTRAL)) + r"$", cache, re.M),
            "build source/library roots differ")
    cache_sha = sha(build / "CMakeCache.txt")
    archives, repositories = {}, {}
    snapshot(SOURCE, "nextpnr", archives, repositories, args.commit)
    subprocess.run(["git", "-C", str(SOURCE), "merge-base", "--is-ancestor", BASE, args.commit], check=True)
    snapshot(MISTRAL, "mistral", archives, repositories)
    check_library(repositories, inputs)
    # Commit payload must contain every root-declared tested source byte.
    with tarfile.open(fileobj=io.BytesIO(archives["archives/nextpnr.tar"]), mode="r:") as archive:
        for name, expected in host_sources(validation).items():
            member = archive.getmember(name)
            require(member.isfile() and hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected,
                    "tested source differs from clean committed bytes: " + name)
    # Validate both commands before publishing any output.
    commands = {phase: expected_command(parent, phase) for phase in PHASES}
    finish(inputs)
    with (HERE / "nextpnr-mistral").open("xb") as output, (build / "nextpnr-mistral").open("rb") as producer:
        shutil.copyfileobj(producer, output)
    (HERE / "nextpnr-mistral").chmod(0o555)
    bind(inputs, HERE / "nextpnr-mistral", args.binary_sha256)
    require(sha(build / "CMakeCache.txt") == cache_sha, "producer cache changed during freeze")
    with (HERE / "build-config.txt").open("x") as output:
        output.write(cache)
    bind(inputs, HERE / "build-config.txt", cache_sha)
    with (HERE / "source.tar.gz").open("xb") as output:
        with tarfile.open(fileobj=output, mode="w:gz") as archive:
            for name, payload in sorted(archives.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(payload), 0o444, 0
                archive.addfile(member, io.BytesIO(payload))
    bind(inputs, HERE / "source.tar.gz", sha(HERE / "source.tar.gz"))
    source = {"schema": 1, "result_commit": args.commit, "delta_base_commit": BASE,
        "reference_proof_sha256": REFERENCE_SHA, "reference_run_sha256": inputs[str(REFERENCE / "run.json")],
        "accepted_routed_guide_sha256": inputs[str(REFERENCE / "timing.json")], "repositories": repositories,
        "binary_sha256": args.binary_sha256, "source_archive_sha256": inputs[str(HERE / "source.tar.gz")],
        "host_validation_path": str(args.host_validation.absolute()), "host_validation_sha256": args.host_validation_sha256,
        "helper_sha256": {name: inputs[str(HERE / name)] for name in HELPERS},
        "commands": commands, "diagnostic_environment": parent["diagnostic_environment"],
        "clean_committed_checkout_at_freeze": True, "listing_only_package": True,
        "full_or_selected_phase_available": False, "input_sha256": inputs, "hardware_tested": False}
    finish(inputs)
    with IDENTITY.open("x") as output:
        output.write(json.dumps(source, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"source_identity_sha256": sha(IDENTITY), "compiler_commit": args.commit,
                      "binary_sha256": args.binary_sha256, "inputs": len(inputs)}, indent=2))


if __name__ == "__main__":
    main()
