"""Partial driver-copy listing proof; no routed physical/timing acceptance."""
import argparse
import importlib.util
import json
import math
from pathlib import Path
import re

import freeze


def native_helper(inputs):
    freeze.bind(inputs, freeze.PURE, freeze.PURE_SHA)
    spec = importlib.util.spec_from_file_location("driver_copy_frozen_native_parser", freeze.PURE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_predicted_report(report):
    parent = freeze.read(freeze.REFERENCE / "timing.json")
    freeze.require(type(report.get("critical_paths")) is list and report["critical_paths"] and
                   set(report.get("fmax", {})) == set(parent["fmax"]) and
                   all(report["fmax"][clock]["constraint"] == parent["fmax"][clock]["constraint"] and
                       type(report["fmax"][clock]["achieved"]) in (int, float) and
                       math.isfinite(report["fmax"][clock]["achieved"]) and report["fmax"][clock]["achieved"] > 0
                       for clock in parent["fmax"]), "actual predicted report is empty/nonfinite or clock constraints differ")


def validate_guide(document, report):
    """Validate all violated ENA/DATAIN path graph records, without STA claims.

    This deliberately mirrors the report's relevant-path selection only. It
    checks raw current cells/ports/locations/edges, never collapses late BUFs.
    Clock/timing-class and legal-arc checks remain the compiled stage's guards.
    """
    require = freeze.require
    check_predicted_report(report)
    top = document["modules"]["top"]
    cells, names = top["cells"], top["netnames"]
    require(type(report["critical_paths"]) is list, "guide lacks critical_paths")
    relevant, edges = [], set()
    def endpoint(value):
        require(type(value) is dict and type(value.get("cell")) is str and type(value.get("port")) is str and
                type(value.get("loc")) is list and len(value["loc"]) == 2, "guide endpoint schema differs")
        name, port = value["cell"], value["port"]
        require(name in cells and port in cells[name]["connections"] and port in cells[name]["port_directions"],
                "guide references a missing pre-route cell/port: " + name + "." + port)
        bel = cells[name]["attributes"].get("NEXTPNR_BEL")
        require(type(bel) is str, "guide cell lacks current BEL")
        match = re.fullmatch(r"MISTRAL_[A-Z0-9_]+\.(\d+)\.(\d+)\.(\d+)", bel)
        require(match is not None and value["loc"] == [int(match[1]), int(match[2])],
                "guide cell placement is stale: " + name)
        return name, port
    for index, path in enumerate(report["critical_paths"]):
        segments = path.get("path", [])
        require(type(segments) is list, "guide path is not an array")
        if not segments:
            continue
        last = segments[-1]
        if last.get("type") != "setup" or last.get("to", {}).get("port") not in ("ENA", "DATAIN"):
            continue
        window = path.get("max_delay")
        require(type(window) in (int, float) and math.isfinite(window) and window > 0,
                "guide timing window is invalid")
        delays = [segment.get("delay") for segment in segments]
        require(all(type(value) in (int, float) and math.isfinite(value) for value in delays), "guide delay is nonfinite")
        total = sum(delays)
        require(math.isfinite(total), "guide total is nonfinite")
        if total <= window:
            continue
        relevant.append(index)
        previous, routing, setup, skew = None, [], False, False
        for segment in segments:
            source, sink = endpoint(segment["from"]), endpoint(segment["to"])
            kind = segment["type"]
            if kind == "clk-skew":
                require(previous is None and not skew and not setup, "guide skew is duplicated/misordered")
                skew = True
                continue
            require(not setup and (previous is None or source == previous), "guide data path is disconnected")
            if kind == "routing":
                a, b = cells[source[0]], cells[sink[0]]
                require(a["port_directions"][source[1]] == "output" and b["port_directions"][sink[1]] == "input" and
                        len(a["connections"][source[1]]) == 1 and a["connections"][source[1]] == b["connections"][sink[1]],
                        "guide routing edge is stale")
                net = segment.get("net")
                require(net in names and names[net]["bits"] == a["connections"][source[1]], "guide net alias/edge differs")
                routing.append((source, sink))
                if (a["type"] in {"MISTRAL_ALUT%d" % width for width in range(2, 7)} and source[1] == "Q" and
                        b["type"] == "MISTRAL_ALUT_ARITH" and sink[1] in ("A", "B", "C", "D0", "D1")):
                    edges.add((source[0], sink[0], sink[1]))
            elif kind == "logic":
                require(source[0] == sink[0] and cells[source[0]]["port_directions"][source[1]] == "input" and
                        cells[sink[0]]["port_directions"][sink[1]] == "output", "guide logic topology differs")
            elif kind == "clk-to-q":
                require(previous is None and source == sink and cells[source[0]]["port_directions"][source[1]] == "output",
                        "guide launch topology differs")
            elif kind == "setup":
                require(source == sink and routing and routing[-1][1] == sink and cells[sink[0]]["type"] == "MISTRAL_FF",
                        "guide does not terminate at its actual FF input")
                setup = True
            else:
                require(False, "unsupported guide path segment")
            previous = sink
        require(setup, "guide path lacks terminal setup")
    return {"relevant_violated_guide_path_indices": relevant,
            "reported_lut_to_arithmetic_data_edges": sorted(edges),
            "all_relevant_path_cells_ports_locations_and_native_edges_present": True,
            "guide_path_projection_or_buffer_collapse_used": False}


def qualification(log, guide, top):
    require = freeze.require
    discovery = re.compile(r"^Info: LUT driver copy discovery: (\d+) bounded data edges\.$")
    start = re.compile(r"^Info: LUT driver copy discovery source=(.+) sink=(.+)\.(A|B|C|D0|D1) users=(\d+) rows=(\d+)$")
    trial = re.compile(r"^Info: LUT driver copy trial source=(.+) sink=(.+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])$")
    candidate = re.compile(r"^Info: LUT driver copy candidate (\d+): source=(.+) sink=(.+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps\.$")
    probes = re.compile(r"^Info: LUT driver copy probes: source=(.+) sink=(.+)\.(A|B|C|D0|D1) timed=(\d+)$")
    summary = re.compile(r"^Info: LUT driver copy: (\d+) qualified candidates; no candidate applied\.$")
    reported_edges = {tuple(row) for row in guide["reported_lut_to_arithmetic_data_edges"]}
    bounded, current, last, total, rows, ordinals, summaries = None, None, None, 0, [], [], 0
    cells = top["cells"]
    for line in log.splitlines():
        if not line.startswith("Info: LUT driver copy"):
            continue
        if match := discovery.fullmatch(line):
            require(bounded is None and not rows, "duplicate/misordered discovery count")
            bounded = int(match[1]); require(bounded == min(16, len(reported_edges)), "bounded report-edge count differs")
        elif match := start.fullmatch(line):
            require(bounded is not None and current is None and summaries == 0, "discovery block is misordered")
            edge = tuple(match.group(i) for i in (1, 2, 3))
            require(edge in reported_edges, "discovered edge is absent from the unchanged guide")
            source = cells[edge[0]]
            width = int(source["type"].removeprefix("MISTRAL_ALUT"))
            require(2 <= width <= 6 and int(match[5]) == 1 << width, "discovery truth-row count/type differs")
            bits = source["connections"]["Q"]
            users = sum(direction == "input" and connection == bits for cell in cells.values()
                        for port, direction in cell["port_directions"].items()
                        for connection in (cell["connections"][port],))
            require(users == int(match[4]), "native original Q consumer count differs")
            require(not any(row["edge"] == list(edge) for row in rows), "discovery repeats an edge")
            rows.append({"edge": list(edge), "raw_truth_rows_reported": int(match[5]), "original_q_users": users, "trials": []})
            current, total, last = edge, 0, None
        elif match := trial.fullmatch(line):
            edge = tuple(match.group(i) for i in (1, 2, 3))
            require(edge == current and total < 16 and summaries == 0, "trial identity/order/budget differs")
            total += 1
            gain = int(match[5]); flags = [int(match[i]) for i in range(6, 10)]
            require(not flags[0] or gain >= 250, "positive improvement flag misses the reported250ps guard")
            last = {"edge": list(edge), "bel": match[4], "gain_ps": gain,
                    "improve": flags[0], "endpoints": flags[1], "clocks": flags[2], "hold": flags[3]}
            rows[-1]["trials"].append(last)
        elif match := candidate.fullmatch(line):
            edge = tuple(match.group(i) for i in (2, 3, 4))
            require(last is not None and int(match[1]) == len(ordinals) and edge == current and
                    last["bel"] == match[5] and last["gain_ps"] == int(match[6]) and
                    all(last[key] == 1 for key in ("improve", "endpoints", "clocks", "hold")) and
                    "ordinal" not in last, "qualified candidate lacks its exact preceding guarded trial")
            last["ordinal"] = int(match[1]); ordinals.append(int(match[1]))
        elif match := probes.fullmatch(line):
            require(tuple(match.group(i) for i in (1, 2, 3)) == current and int(match[4]) == total,
                    "probe summary differs from actual trial rows")
            for row in rows[-1]["trials"]:
                require(("ordinal" in row) == all(row[key] == 1 for key in ("improve", "endpoints", "clocks", "hold")),
                        "a qualifying trial lacks its fresh ordinal")
            current, last = None, None
        elif match := summary.fullmatch(line):
            require(current is None and bounded is not None and int(match[1]) == len(ordinals) and summaries == 0,
                    "final qualified summary differs")
            summaries += 1
        else:
            require(False, "unknown/applied driver-copy diagnostic: " + line)
    require(bounded is not None and summaries == 1 and current is None and len(rows) <= bounded,
            "listing lacks a complete bounded driver stage")
    return {"bounded_reported_edges": bounded, "eligible_probed_edges": rows,
            "qualified_driver_ordinals": ordinals, "no_candidate_applied": True,
            "minimum_modeled_gain_ps": 250, "guards_are_current_compiler_reported_not_independent_STA": True}


def completed(inputs, source, identity_sha, phase, baseline=None):
    folder = freeze.PHASES[phase]
    freeze.bind(inputs, folder / "run.json", freeze.sha(folder / "run.json"))
    run = freeze.read(folder / "run.json")
    freeze.authenticate_phase(run, source, identity_sha, baseline)
    freeze.require(run["completed"] is True, "actual phase did not complete")
    for path, expected in run["input_sha256"].items():
        freeze.bind(inputs, path, expected)
    for path, expected in run["execution"]["files"].items():
        freeze.bind(inputs, path, expected)
    for path, expected in run["output_sha256"].items():
        freeze.require(Path(path).stat().st_size > 0, "actual output is empty")
        freeze.bind(inputs, path, expected)
    freeze.require(not any((folder / name).exists() for name in ("core.rbf", "routed.json")), "listing has routed outputs")
    log = (folder / "phase.log").read_text()
    freeze.require("Info: Program finished normally." in log and
                   not any(line.startswith("ERROR:") for line in log.splitlines()) and
                   not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...")),
                   "actual phase is not a normally completed no-route invocation")
    freeze.require(log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1,
                   "actual predicted-report refresh provenance differs")
    check_predicted_report(freeze.read(folder / "timing.json"))
    return run, log


def comparison(identity_sha):
    source, inputs = freeze.authenticate_freeze(identity_sha)
    native = native_helper(inputs)
    baseline, oldlog = completed(inputs, source, identity_sha, "baseline")
    binding = {str(freeze.PHASES["baseline"] / "run.json"): inputs[str(freeze.PHASES["baseline"] / "run.json")], **baseline["output_sha256"]}
    actual, log = completed(inputs, source, identity_sha, "list-driver", binding)
    before = native.read_netlist(freeze.PHASES["baseline"] / "placed.json")
    after = native.read_netlist(freeze.PHASES["list-driver"] / "placed.json")
    freeze.require(before["creator"] == after["creator"], "same-binary creator metadata changed")
    old, new = before["modules"]["top"], after["modules"]["top"]
    freeze.require(native.canonical(old) == native.canonical(new), "listing changed the native module; no normalization permitted")
    freeze.require(native.canonical(old["cells"].pll_ports) == native.canonical(new["cells"].pll_ports), "ordered PLL duplicate records changed")
    for dictionary in ("cells", "netnames"):
        freeze.require(list(old[dictionary]) == list(new[dictionary]), "native cell/net export order changed")
    freeze.require("LUT driver copy" not in oldlog, "disabled baseline ran the copy stage")
    freeze.require(native.diagnostics(oldlog) == native.diagnostics(log), "retained upstream transform/qualification messages changed")
    metrics = native.PLACEMENT_METRICS.findall(oldlog)
    freeze.require(len(metrics) == 71 and metrics == native.PLACEMENT_METRICS.findall(log), "71 placement metrics differ")
    baseline_report = freeze.read(freeze.PHASES["baseline"] / "timing.json")
    listing_report = freeze.read(freeze.PHASES["list-driver"] / "timing.json")
    freeze.require(native.canonical(baseline_report) == native.canonical(listing_report), "same-phase predicted timing report differs after rollback")
    guide = validate_guide(before, baseline_report)
    candidates = qualification(log, guide, new)
    freeze.finish(inputs)
    artifacts = {str(Path(path).relative_to(freeze.ROOT)): value for path, value in inputs.items() if Path(path).is_relative_to(freeze.ROOT)}
    execution = {path: value for path, value in inputs.items() if not Path(path).is_relative_to(freeze.ROOT)}
    for run in (baseline, actual):
        execution.update(run["execution"]["files"])
    return {"schema": 1, "phase": "driver-copy-listing", "compiler_commit": source["result_commit"],
        "source_identity_sha256": identity_sha, "generator_sha256": source["helper_sha256"]["compare_listing.py"],
        "frozen_native_parser_sha256": freeze.PURE_SHA, "reference_integrated_proof_sha256": freeze.REFERENCE_SHA,
        "driver_guide_sha256": actual["driver_guide_sha256"],
        "driver_guide_kind": actual["driver_guide_kind"],
        "accepted_routed_timing_is_input_provenance_only": True,
        "candidate_completed": True, "elapsed_seconds": actual["elapsed_seconds"],
        "same_new_binary_baseline_elapsed_seconds": baseline["elapsed_seconds"],
        "serialized_same_phase_graph_rollback_proved": True, "cell_count": len(new["cells"]), "named_net_count": len(new["netnames"]),
        "complete_typed_module_and_creator_exact": True, "numeric_bits_and_serialized_native_consumers_exact": True,
        "serialized_bels_params_attrs_ports_and_available_pin_fields_exact": True,
        "cell_and_net_export_order_exact": True, "lossless_ordered_pll_occurrences_exact": True,
        "matched_ordinary_placement_metrics": 71, "retained_current_qualification_messages_exact": True,
        "current_predicted_timing_report_exact_after_listing_rollback": True,
        "guide_evidence": guide, **candidates, "fresh_listing_qualification_claimed": True,
        "independent_boolean_equivalence_proved": False, "physical_pin_preservation_proved": False,
        "in_memory_cache_or_indexed_store_identity_proved": False, "gpu_net_ids_proved": False,
        "routed_graph_proof_available": False, "passes_practical_timing_gate": None,
        "candidate_accepted_under_confirmed_target_clock_rule": False, "hardware_tested": False,
        "old_comparators_or_authenticators_replayed": False,
        "proof_limitations": ["Pre-route JSON does not provide complete FES_PINMAP_V1, combInfo caches, indexed-store/free-list/bucket/pointer identities or GPU net IDs.",
                              "Zero-delta proof compares complete actual serialized modules with no BUF collapse, topology alignment, settings allowance or pin normalization.",
                              "Fresh ordinals and gain/endpoint/clock/hold guards are the current frozen compiler's modeled listing diagnostics, not independent routed STA or gain acceptance.",
                              "Original integrated physical proof is cached input provenance only; this new no-route artifact inherits no routed physical, RBF, hold or hardware acceptance."],
        "artifact_sha256": dict(sorted(artifacts.items())), "execution_file_sha256": dict(sorted(execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    output = freeze.PHASES["list-driver"] / "comparison.json"
    freeze.require(not output.exists(), "listing comparison output already exists")
    result = comparison(args.source_identity_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("compiler_commit", "serialized_same_phase_graph_rollback_proved",
                      "qualified_driver_ordinals", "elapsed_seconds", "routed_graph_proof_available")}, indent=2))


if __name__ == "__main__":
    main()
