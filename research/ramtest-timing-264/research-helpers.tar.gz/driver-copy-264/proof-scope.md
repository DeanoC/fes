# Driver-copy listing preparation

This package provides only a same-binary baseline and a final driver-copy
listing. Root alone freezes and executes it. No helper, build, test, route or
hardware operation was executed by its authors. Prior evidence stays immutable.

`freeze.py` requires explicit source path/commit, build path/binary SHA, host
validation path/SHA and the four reviewed helper SHAs. All pins must be actual
non-placeholder hashes. The source must be clean and committed, descend from
integrated `0c59d78a`, and match the root-tested source file map in its Git archive.
The host manifest must identify `result_commit`, `delta_base_commit`, clean
checkout, passed build, `binary_sha256`, passing `checks.driver_backend` and
`checks.driver_cli` with exit 0, actual `source_sha256` and log/artifact hashes.
Those checks are root evidence, not executed again by these helpers.
The Mistral library/model commit, tree, archive hashes and initialized gitlinks
must equal the accepted integrated source identity exactly.

Activation hashes the accepted integrated proof `01886d65…`, its 339 artifacts
and 281 runtime paths flat, including every original supplied pathname. No old
proof generator/authenticator is replayed. New source/archive/binary/helper and
host evidence joins that closure; every original pathname is rehashed at exit.
The frozen `32fd10…` integrated helper supplies only its native JSON parser,
typed canonical serializer and diagnostic/placement regex constants.

Root invokes the following phases with the frozen source identity SHA:

1. `run.py baseline --source-identity-sha256 SHA` executes the exact integrated
   upstream stack with the new binary, without driver copy. It removes RBF and
   compression outputs, adds exactly one `--no-route`, and keeps an explicit
   `--report baseline/timing.json` for current predicted placed STA.
2. `run.py list-driver --source-identity-sha256 SHA` binds the actual completed
   baseline and adds only that baseline's actual predicted timing report plus driver
   candidate `-1`. Driver copy is last, after all three local stages, legacy
   comb, capture, selected 11/12 reductions and selected AC. GPU1 selectors stay
   exact but the GPU router does not execute under `--no-route`. It also emits
   its own predicted report; the comparator requires that report to reproduce
   the baseline report exactly after listing rollback.
3. `compare_listing.py --source-identity-sha256 SHA` writes a new exclusive
   `list-driver/comparison.json`. It authenticates both actual command/env/runtime
   records and outputs, then compares full serialized native modules with their
   original numeric bits, settings, attributes, parameters, connections, consumer
   relations, BELs, available pin fields, cell/net export order and ordered
   duplicate PLL records. Same-binary creator metadata must also be identical.

The accepted integrated report is provenance only: its memory path contains a
late `cmd_end$ROUTETHRU` absent before routing. The driver guide is instead the
complete actual report emitted by the own same-binary baseline. The new source
must explicitly refresh current STA for `--report` plus `--no-route`; both logs
must contain exactly one predicted placed timing label. Reports need populated
critical paths, finite positive modeled Fmax and the exact inherited constraints;
none of these modeled values establish a routed gain. Before the driver listing
launches, every relevant violated ENA/DATAIN guide path must name actual baseline
cells/ports/BEL coordinates and scalar native edges. No report path is projected,
no late BUF collapsed and no absent cell ignored. Clock/timing-class and legal-arc
checks are also performed by the current compiler.

The listing proof checks 71 unchanged placement metrics and exact retained
transform/qualification messages. It binds discovery rows, native original-Q
consumer counts, at most 16 discovered edges, at most 16 timed probes per edge,
current 250ps gain guard and all endpoint/clock/hold flags. Qualified ordinals must
be fresh contiguous rows tied to their exact preceding guarded trial. Zero
qualified candidates is a valid completed listing outcome, with no selected run.

Pre-route JSON omits complete physical FES_PINMAP_V1 and combInfo caches. Its
cell/net export order does not prove hidden dictionary storage or GPU IDs.
The result therefore claims only exact serialized rollback and current modeled
qualification, without independent Boolean/physical/cache/RBF/final-hold proof.
There are no settings, BUF, pin or consumer preservation waivers.

A selected no-route phase and full route need separate new immutable helpers and
before-run activation after an actual qualified ordinal. Their allowed graph
change is exactly one ordinary ALUT/private Q net and one ARITH data operand
redirect, with exact original-Q removal and clone-input load multiplicity. They
must independently prove at most 64 rows with actual aliases/constants/inversion
and routed physical pins; original cells/FFs/BELs/pins/BUF/PLL/users remain strict.
Sink and immediate CO-to-CI successor caches must be independently derived and
bound to backend regression evidence. Full signoff must meet the published target
gain and non-target clock/window/hold rule; this listing supplies none of that
acceptance and cannot authorize a full run.
