# Saved Quartus hints for the eleven-input reduction experiment

Read-only research, 2026-09-30. No Quartus queries, recompilation, or source edits.
Use this evidence as a locality/register-control hint only.

Paths below are relative to `/home/deano/kepler/worktrees/fes-fes-ramtest-compiler-gains-264-17a49c0d`, except the explicitly identified older-fit paths.

## Observed hints

- Current-RTL saved fit: `out/ramtest-compiler-gains/quartus-current-matched/project/output_files/top.fit.rpt:286`–`297` lists twelve DDR0 error-register duplicates, including bits 22, 23, 24, and 31, inserted during routing for routability optimization. The retained `out/ramtest-fixed-input-264/quartus-error-cone/error-registers.txt:1`–`44` inventory contains 32 original error registers plus these twelve duplicates.
- `out/ramtest-fixed-input-264/quartus-error-cone/error15-to-fault4.rpt:26` reports `errors[15]~DUPLICATE` to `fault_addr[4]`: 4.025 ns data delay and +3.432 ns setup slack with a 7.692 ns relationship. Its three LUT levels stay compact: FF (29,47), LUT (28,47), LUT (29,46), LUT (28,49), FF (28,49). The final LUT has fanout 31 (`:159`), and the sink is ENA (`:166`). Fanout around 32 therefore does not by itself explain the OSS path's much longer routing.
- `out/ramtest-compiler-gains/quartus-current-matched/project/output_files/top.map.rpt:1531` records restructuring the registered 3:1, 32-bit errors mux, with a reported saving of 64 LEs. This identifies register-control mapping as another comparison target; it does not decode the resulting saturation-enable function.
- Older-fit placement only: `/home/deano/kepler/worktrees/fes-fes-ramtest-oss-lane-timing-264-17a49c0d/out/ramtest-quartus-control-cones/nodes.tsv:1826`–`1859` places all DDR0 errors[20:31] at X28/Y46. Its named errors[16]~0 through ~7 combinational cells occupy X27–29/Y46–48 (`:10371`–`10378`). The saved selected connectivity omits these functions; their names are not proof of an eleven-input AND decomposition.

## Comparison limits

There is **no saved errors-to-errors timing path or complete fitted connectivity for the saturation-enable cone** in this evidence. The exact path above controls first-error address capture, not the new OSS errors[21:31] to errors-ENA critical path. Do not claim Quartus's exact eleven-input reduction, LUT depth, or distribution of the 32 saturation-enable consumers.

The newer Quartus fit uses BUILD_ID `52991ce22369904849b68bdd900f9ae1` (`out/ramtest-compiler-gains/quartus-current-matched/project/top.qsf:15`); the frozen accepted OSS input uses `7168b508ab424b70f1c0f87b2035d821` (`out/ramtest-wide-reduction-264/route-slots-final/run.json:2`). The older placement dump belongs to a different fit with BUILD_ID `cd3e4c315005fde83065dff7483ae0d7` (older-fit `project/top.qsf:15`). Do not combine those fits into one claimed physical implementation.

Quartus also omits RAM_OSS_HIGH_SPEED and uses native PLL/SDC and timing models; see `sources/misteross/docs/validation/2026-09-29-ramtest-fixed-input.md:88`–`100`. Neither whole-design elaboration equivalence nor an equivalent physical-route timing calibration is established.

## Verified source SHA256

Each digest below was recomputed from the file and verified against this note after writing it.

| Source | SHA256 |
| --- | --- |
| `out/ramtest-compiler-gains/quartus-current-matched/project/output_files/top.fit.rpt` | `8db149dbb9e2d5afeca75cc81f29abe2ed0e113dcced4e16f58a8ccea4f4d75b` |
| `out/ramtest-compiler-gains/quartus-current-matched/project/output_files/top.map.rpt` | `50d4825785611f27e9e6bca52f695a02ef3e6d0832d04a783188dc89ef5d13d7` |
| `out/ramtest-compiler-gains/quartus-current-matched/project/top.qsf` | `db71b993984823bbfc4a9bfcc530a037280ea36a1ded8c9d7bc4acab7caff46d` |
| `out/ramtest-fixed-input-264/quartus-error-cone/error15-to-fault4.rpt` | `02e439a64b6eb04a8f80f52cf513e0552d123ccd29349046387062f8283c3d52` |
| `out/ramtest-fixed-input-264/quartus-error-cone/error-registers.txt` | `2972991fbb8c89053c6a2741cd548e6a74ed2abba5c823e5c5c04dee07ec064e` |
| `sources/misteross/docs/validation/2026-09-29-ramtest-fixed-input.md` | `4f39ee21b6c6528a3655fd1666a275ae4e44f0899604c06bbd4d9bb546d26984` |
| `out/ramtest-wide-reduction-264/route-slots-final/run.json` | `7706cd9268be473f1955ffab7b1bcd2b80b2835c36252b81f5edf10e52bae144` |
| `/home/deano/kepler/worktrees/fes-fes-ramtest-oss-lane-timing-264-17a49c0d/out/ramtest-quartus-control-cones/nodes.tsv` | `c26bc777db47bdad9b6f0920cec4318ba83514da3291a179e9f5d0662031d655` |
| `/home/deano/kepler/worktrees/fes-fes-ramtest-oss-lane-timing-264-17a49c0d/out/ramtest-quartus-control-cones/project/top.qsf` | `7dac9740dacdf217062ad3bf84b6b3c9080b19bb12ca148dc0e2fb68371e0f43` |
