"""Route a disposable balanced netlist with the frozen merged compiler/input."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
MODULE=ROOT/'sources/misteross'
RAW=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation
from scripts.search_placer_qor import _score_report,has_failed_route_arc
from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS

sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((ROOT/'out/ramtest-merged-remap/measured-diagnostic/run-inputs.json').read_text())
binary=RAW/'eleven-reduction/nextpnr-mistral'
identity='base_commit=1e4ff5cbe7245fad9ad5fcea164ddba081214a5a; experimental_source_sha256='+sha(RAW/'eleven-reduction/source.tar.gz')+'; sha256='+sha(binary)
source=ROOT/'out/ramtest-merged-remap/measured-diagnostic/synth.json'
qsf=MODULE/'cores/fes-ramtest/constraints.qsf'
sdc=MODULE/'boards/de10nano/clocks.sdc'
assert sha(qsf)==original['sources'][str(qsf.relative_to(MODULE))]
assert sha(sdc)==original['sources'][str(sdc.relative_to(MODULE))]
output=RAW/'eleven-reduction/route-pair';output.mkdir(exist_ok=False)
invocation=FunctionalInvocation({'nextpnr-mistral':board.AuthenticatedTool(binary,identity)},1)
cmd=[str(binary),'--json',str(source),'--device','5CSEBA6U23I7','--qsf',str(qsf),'--sdc',str(sdc),
     '--freq','74.25','--seed','2','--placer-heap-timingweight','10','--placer-heap-critexp','2',
     '--router','gpu','--replicate-enables','4','--timing-allow-fail','--detailed-timing-report',
     '--balance-reduction-root','ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT6_F_E_MISTRAL_ALUT5_Q_1',
     '--balance-reduction-root','ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT4_Q',
     '--write',str(output/'routed.json'),'--report',str(output/'timing.json'),
     '--rbf',str(output/'core.rbf'),'--compress-rbf','--gpu-device','1']
record={'kind':'scratch route; no compiler or package selection','command':cmd,'cwd':str(MODULE),
        'tool_identity':identity,'build_id':original['build_id'],'input_sha256':{str(p):sha(p) for p in (binary,source,qsf,sdc)},
        'execution':invocation.inputs,'completed':False}
manifest=output/'run.json';manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
env=dict(invocation.env)
record['base_compiler_commit']='1e4ff5cbe7245fad9ad5fcea164ddba081214a5a'
record['experimental_eleven_reduction']=True
record['source_archive_sha256']=sha(RAW/'eleven-reduction/source.tar.gz')
start=time.monotonic()
try:
 with (output/'route.log').open('w') as log:
  result=audited_run(cmd,source_root=MODULE,cwd=MODULE,env=env,stdout=log,
                     stderr=subprocess.STDOUT,check=False,timeout=2400)
 record['exit_code']=result.returncode
 record['elapsed_seconds']=time.monotonic()-start
 invocation.verify()
 for name,digest in record['input_sha256'].items():assert sha(Path(name))==digest
 log=(output/'route.log').read_text()
 assert result.returncode==0 and 'Info: Program finished normally.' in log and not has_failed_route_arc(log)
 board._require_gpu_backend(log)
 assert (output/'core.rbf').stat().st_size>0 and 'Running signoff timing analysis...' in log
 record['final_reported_hold_violations']='Hold/min time violation' in log.rsplit('Running signoff timing analysis...',1)[1]
 report=json.loads((output/'timing.json').read_text())
 _score_report(report,REQUIRED_CLOCKS)
 assert set(report['fmax'])=={name for name,_ in REQUIRED_CLOCKS}
 record['fmax']=report['fmax'];record['completed']=True
 print(json.dumps({'elapsed_seconds':record['elapsed_seconds'],'fmax':record['fmax'],
                   'final_reported_hold_violations':record['final_reported_hold_violations']},indent=2),flush=True)
except BaseException as exc:
 record['failure']=repr(exc)
 raise
finally:
 manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
 invocation.close()
