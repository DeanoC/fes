"""Check frozen route inputs and record both reduction experiments without selection."""
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = RAW.parents[2]
CONTROL = RAW.parent / "route-slots-final"


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


folder = RAW / (sys.argv[1] if len(sys.argv) > 1 else "route-pair")
record = read(folder / "run.json")
assert record["completed"] and record["exit_code"] == 0
control_record = read(CONTROL / "run.json")
assert record["build_id"] == control_record["build_id"]
for path, digest in record["input_sha256"].items():
    assert sha(Path(path)) == digest, path
    if Path(path).name != "nextpnr-mistral":
        assert digest == control_record["input_sha256"][path], path
assert sha(RAW / "source.tar.gz") == record["source_archive_sha256"]
identity = read(RAW / "source-identity.json")
assert sha(RAW / "nextpnr-mistral") == identity["binary_sha256"]
with tarfile.open(RAW / "source.tar.gz") as archive:
    for path, digest in identity["source_sha256"].items():
        assert hashlib.sha256(archive.extractfile(path).read()).hexdigest() == digest, path
reference = CONTROL
if record.get("experimental_capture_locality"):
    reference = RAW / "route-pair"
    assert sha(reference / "timing.json") == record["capture_report_sha256"]
baseline = read(CONTROL / "timing.json")
candidate = read(folder / "timing.json")
assert set(candidate["fmax"]) == set(baseline["fmax"])
clocks = {}
for clock, current in candidate["fmax"].items():
    old = baseline["fmax"][clock]
    assert current["constraint"] == old["constraint"]
    clocks[clock] = {"control_mhz": old["achieved"], "candidate_mhz": current["achieved"],
                     "constraint_mhz": current["constraint"],
                     "gain_mhz": current["achieved"] - old["achieved"]}
old_cells = read(reference / "routed.json")["modules"]["top"]["cells"]
new_cells = read(folder / "routed.json")["modules"]["top"]["cells"]
common = set(old_cells) & set(new_cells)
changed = [name for name in sorted(common) if old_cells[name]["attributes"].get("NEXTPNR_BEL") !=
           new_cells[name]["attributes"].get("NEXTPNR_BEL")]
pattern = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
old_metrics = pattern.findall((reference / "route.log").read_text())
new_metrics = pattern.findall((folder / "route.log").read_text())
if reference != CONTROL:
    assert new_metrics == old_metrics and new_metrics
critical = next(p for p in candidate["critical_paths"]
                if p["from"] == p["to"] == "posedge ram_clock.clocks[0]")
summary = {
    "status": "experimental, unselected", "build_id": record["build_id"], "fmax": clocks,
    "passes_all_clock_nonregression": all(x["gain_mhz"] >= 0 for x in clocks.values()),
    "nonmemory_required_clocks_close": all(x["candidate_mhz"] >= x["constraint_mhz"]
                                           for k, x in clocks.items() if k != "ram_clock.clocks[0]"),
    "final_reported_hold_violations": record["final_reported_hold_violations"],
    "elapsed_seconds": record["elapsed_seconds"],
    "placement_metrics_identical": old_metrics == new_metrics,
    "placement_metric_count": len(new_metrics), "bel_reference": str(reference.relative_to(ROOT)),
    "common_cells": len(common), "changed_common_bels": changed,
    "added_cells": sorted(set(new_cells) - set(old_cells)),
    "removed_cells": sorted(set(old_cells) - set(new_cells)),
    "critical_memory_path": critical,
    "artifact_sha256": {str(p.relative_to(ROOT)): sha(p) for p in
                        (folder / "run.json", folder / "timing.json", folder / "core.rbf", RAW / "source.tar.gz")},
    "default_recipe_selected": False, "hardware_tested": False,
}
(folder / "comparison.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k not in
                  ("critical_memory_path", "artifact_sha256", "changed_common_bels", "added_cells", "removed_cells")}, indent=2))
