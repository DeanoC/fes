Latest fixed-input OSS result: **116.279068 MHz memory**, with the generic compiler stack now open for review in https://github.com/DeanoC/nextpnr/pull/97.

| Clock | Retained control MHz | New profile MHz | Required MHz |
| --- | ---: | ---: | ---: |
| Memory | 116.171005 | 116.279068 | 130.005203 |
| Pixel | 93.668045 | 93.896713 | 74.250069 |
| Phase-shifted capture | 378.582397 | 307.631805 | 130.005203 |

The full GPU route completed with no final reported hold violations. The target-memory gain is 0.108063 MHz; both other clocks meet their constraints. Capture-to-memory setup headroom decreases from 3.283 ns to **2.887 ns in a 5 ns window**. This remains passing internal timing, rather than an external SDRAM sampling-window measurement.

The agreed acceptance rule is target-memory improvement plus passing non-target clock constraints, holds and full graph/pin/buffer checks. Reduced positive non-target headroom is disclosed and does not automatically reject a gain. The earlier conservative all-clock-Fmax nonregression flag remains false in the preserved evidence; a separate acceptance record applies the revised rule without changing that evidence.

This is a combined profile: local groups8/1/1, retained internal-cut/capture/placed11 passes, and exact seven-input decomposition. The gain is not isolated to one pass. The actual generated ready copy and its declared ENA/BEL changes are independently proved; synthesis-original physical pins/BELs and buffers outside declared changes are preserved, with all 128 decomposition truth rows verified. The broader optional experiments in the branch have no separate performance claim.

Measured compiler: `6ad210a60991f93a607ac4490d6282b1267ec64a`; publication head `91f3ad1bd8bbebd09e5a7ffb92e5026c5558e771` adds documentation only. Synthesis input/BUILD_ID/constraints/seed/GPU are unchanged from the paired control. Final focused backend tests passed 25 cases; earlier cumulative runs passed 15 decomposition CLI and 45 existing backend cases. Full proof SHA256 `3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e`; publication acceptance SHA256 `c70363931e903723bff55522f2fca2eb62dac375f7387c58f26ab7619e903483` binds 162 artifacts.

[Profile, option order and measurement](https://github.com/DeanoC/nextpnr/blob/91f3ad1bd8bbebd09e5a7ffb92e5026c5558e771/docs/mistral-control-remapping.md). The wider GPU repair-band trial recovered capture margin but regressed memory to 112.536575 MHz and remains rejected.

**130 MHz remains unresolved.** This is host-only routed timing evidence, with no hardware acceptance or default FES compiler/recipe selection. Integration with current compiler main and the FES diagnostic is the next step after review.
