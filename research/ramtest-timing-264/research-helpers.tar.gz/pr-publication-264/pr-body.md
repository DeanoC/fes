Control paths can retain several LUT levels after ordinary mapping. This change adds explicit, bounded Mistral experiments for local enable composition, internal-cut cloning, pure-cube balancing and exact seven-input control decomposition. They run only when requested and qualify placed candidates with legality, setup, clock and hold checks before routing.

The cumulative implementation includes staged local and internal-cut plans, optional local pin ordering and fixed FF placement, hard-IP capture locality, eleven/16/24-literal cube recognition, guarded placed eleven/24-literal probes, and four-LUT seven-input decomposition. Plans validate their schemas and reports before placement, then validate relevant continuous edges against each current graph. Selected failures stop before routing even with `--force`. Decomposition preserves original owners and indexed consumers on rollback; acceptance keeps original cell/net iterator prefixes, appends clones and isolates new clone ALMs from original occupants. The documentation consolidates the current interfaces and records rejected experiments alongside the measured profile.

A complete frozen RAM-test route improves memory from **116.171005 to 116.279068 MHz (+0.108063 MHz, 0.0930%)** against the retained parent116 profile. The same fixed-input earlier reduction-balanced control reported 108.944328 MHz memory timing. Pixel improves from 93.668045 to 93.896713 MHz. Capture achieved Fmax decreases from 378.582397 to 307.631805 MHz, still above its 130.005203 MHz requirement; the reported 5 ns transfer-window setup headroom decreases from 3.283 to 2.887 ns. Routing completes with no final reported hold violations. The 130 MHz memory target remains unmet.

This result is accepted under the rule of target-memory improvement, passing non-target constraints and holds, and a successful full routed graph/pin/buffer proof. The earlier all-clock achieved-Fmax nonregression flag remains **false** in the sealed comparison. This is a small memory gain with reduced positive capture headroom. Hardware acceptance and default recipe selection remain separate integration steps.

The measured profile retains the existing unplaced root, uses three local stages with group budgets 8/1/1 (candidate 0, pin optimization off, original FF placement fixed), internal-cut candidate 0, 60 retained capture moves, placed eleven-literal candidate 0 and control-decomposition candidate 0. The full proof closes the actual generated ready-copy and declared enable/BEL changes, preserves synthesis-original physical pins/BELs and buffers outside declared changes, and proves all 128 rows of the actual seven-input decomposition. The 24-literal placed rewrite and optional local pin ordering are included capabilities but were not selected in this routed result. The gain belongs to the complete profile.

Validation:

- Built `nextpnr-mistral` and its backend test binary; the final source6ad focused backend run passed all 25 cases, including positive acceptance, exact original iterator prefixes, original physical-pin/ALM isolation, all 128 truth rows and rejection/listing rollback.
- Earlier cumulative validation passed 15 new decomposition CLI cases and 45 existing backend cases. These earlier runs are distinct from the final source6ad focused test run.
- Authenticated disabled controls, fresh listing and full-route evidence; the separate publication record binds 162 retained artifacts and leaves the original strict diagnostic result unchanged.
- No hardware test, RTL/constraint change, compiler-lock update or default recipe adoption.

Measured compiler: `6ad210a60991f93a607ac4490d6282b1267ec64a`.
Binary SHA256: `ba39ad814af51c4a6af3ca1854fcd1dd992af350bb09741d5b6becfa2d7d4b18`.
Publication acceptance SHA256: `c70363931e903723bff55522f2fca2eb62dac375f7387c58f26ab7619e903483`.
Full graph-proof SHA256: `3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e`.
RBF SHA256: `2eca0c165601511c391d7072d3a7386369bbdd2530bb13eab288d005c0806421`.

The measured source predates main's locked-LAB legalization change (`655f3833`, #96); combined integration has not been tested. A documentation-only publication commit does not alter the benchmark identity.


[Measurement, option order and acceptance rule](https://github.com/DeanoC/nextpnr/blob/91f3ad1bd8bbebd09e5a7ffb92e5026c5558e771/docs/mistral-control-remapping.md).

Related: https://github.com/DeanoC/fes/issues/264 (130 MHz remains unresolved).
