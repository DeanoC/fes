"""Publish an explicit target-clock acceptance without changing frozen proofs."""
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
CANDIDATE = RAW / "ready-g8-decomposition-264/route-c0"
PARENT = RAW / "remap-plan-264/route-c0-g1-third-c0-g1"
PROOF = CANDIDATE / "comparison.json"
PROOF_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
MEMORY = "ram_clock.clocks[0]"
CAPTURE = "ram_clock.clocks[1]"
PIXEL = "display.pixel_clk"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    return json.loads(path.read_text(), object_pairs_hook=pairs)


def headroom(report):
    paths = [path for path in report["critical_paths"] if path["from"] == "posedge " + CAPTURE]
    require(len(paths) == 1 and paths[0]["to"] == "negedge " + MEMORY, "unexpected capture transfer")
    path = paths[0]
    delay = sum(segment["delay"] for segment in path["path"])
    require(math.isfinite(delay) and path["max_delay"] == 5, "unexpected capture timing window")
    return {"window_ns": path["max_delay"], "reported_delay_ns": delay,
            "setup_headroom_ns": path["max_delay"] - delay}


require(sha(PROOF) == PROOF_SHA, "frozen routed graph proof changed")
proof = read(PROOF)
for filename, digest in proof["artifact_sha256"].items():
    artifact = (ROOT / filename).resolve()
    require(artifact.is_relative_to(ROOT) and sha(artifact) == digest,
            "proof artifact changed: " + filename)
require(proof["final_metadata_stable_during_comparison"] and proof["candidate_completed"] and
        proof["graph_proof_available"] and proof.get("structural_rejection") is None and
        proof["actual_local_and_ac_selected_prefix_match_fresh_listing"], "full graph proof unavailable")
require(proof["candidate_route"]["successful_full_route"] and
        not proof["candidate_route"]["final_reported_hold_violations"], "route/hold checks failed")
candidate = read(CANDIDATE / "timing.json")
parent = read(PARENT / "timing.json")
run = read(CANDIDATE / "run.json")
parent_run = read(PARENT / "run.json")
require(run["completed"] and run["exit_code"] == 0 and not run["list_only"] and
        run["build_id"] == parent_run["build_id"] and run["compiler_commit"] ==
        "6ad210a60991f93a607ac4490d6282b1267ec64a", "run/source/input identity changed")
require(set(candidate["fmax"]) == set(parent["fmax"]) == {MEMORY, CAPTURE, PIXEL}, "clock set changed")
clocks = {}
for clock, after in candidate["fmax"].items():
    before = parent["fmax"][clock]
    require(all(math.isfinite(value) and value > 0 for value in
                (before["achieved"], before["constraint"], after["achieved"], after["constraint"])) and
            after["constraint"] == before["constraint"], "clock constraint changed")
    clocks[clock] = {"before_mhz": before["achieved"], "after_mhz": after["achieved"],
                     "gain_mhz": after["achieved"] - before["achieved"],
                     "constraint_mhz": after["constraint"],
                     "constraint_passed": after["achieved"] >= after["constraint"]}
require(clocks[MEMORY]["gain_mhz"] > 0 and clocks[PIXEL]["gain_mhz"] >= 0 and
        all(row["constraint_passed"] for clock, row in clocks.items() if clock != MEMORY),
        "target gain or required non-target timing failed")
margins = {"parent": headroom(parent), "candidate": headroom(candidate)}
require(margins["candidate"]["setup_headroom_ns"] > 0, "capture transfer setup failed")
require(sha(PROOF) == PROOF_SHA and all(sha((ROOT / filename).resolve()) == digest
        for filename, digest in proof["artifact_sha256"].items()), "evidence changed during acceptance")
result = {
    "status": "accepted target-clock gain with disclosed capture-headroom tradeoff",
    "rule": "Target memory timing improves; non-target clock constraints and final holds pass; full graph/pin/buffer proof passes. Lower positive non-target headroom is disclosed, not an automatic rejection.",
    "rule_explicitly_confirmed_by_user": True,
    "compiler_commit": run["compiler_commit"], "build_id": run["build_id"],
    "full_routed_graph_proof_sha256": PROOF_SHA,
    "frozen_proof_artifacts_reauthenticated": len(proof["artifact_sha256"]),
    "cached_proof_reexecuted": False, "existing_strict_proof_unchanged": True,
    "existing_all_clock_fmax_nonregression_gate_passed": proof["passes_strict_diagnostic_gate_vs_116"],
    "accepted_under_target_clock_rule": True, "clocks": clocks, "capture_transfer": margins,
    "memory_130mhz_closed": clocks[MEMORY]["constraint_passed"],
    "default_recipe_selected": False, "hardware_tested": False,
    "acceptance_script_sha256": sha(Path(__file__).resolve()),
    "artifact_sha256": {**proof["artifact_sha256"], str(PROOF.relative_to(ROOT)): PROOF_SHA},
}
(HERE / "publication-acceptance.json").open("x").write(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: result[key] for key in ("status", "compiler_commit", "clocks", "capture_transfer",
                 "existing_all_clock_fmax_nonregression_gate_passed", "memory_130mhz_closed")}, indent=2))
