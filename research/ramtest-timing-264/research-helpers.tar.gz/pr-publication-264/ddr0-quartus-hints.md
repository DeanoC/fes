# DDR0 error-enable: retained Quartus evidence and exact-query proposal

Read-only saved-file review, 2026-09-30. No Quartus invocation, refit, compiler/helper execution, route, tracked edit or prior-output mutation by this agent. The proposed query is optional evidence and must not delay the fourth-local-stage listing.

## Concrete evidence currently retained

The saved `quartus-current-matched` fit has BUILD_ID `52991ce22369904849b68bdd900f9ae1`, rather than the measured OSS `7168b508ab424b70f1c0f87b2035d821`. Its QSF selects Quartus 17.0.2 Lite, device 5CSEBA6U23I7 and fit seed 1. The OSS routes use seed 2. Quartus-native PLL/SDC and pin models differ, and `RAM_OSS_HIGH_SPEED` is absent. The dated fixed-input validation documents matching DDR0 source, but explicitly rejects whole-design elaboration equivalence or equivalent timing calibration. No current source-hash audit was rerun here.

Saved current-fit `worst-paths.rpt` and `project/output_files/top.sta.rpt` contain no `ddr0_test`/`group_bad`/errors-ENA timing path. The already extracted exact current-fit atom cone is DDR1 address[10].ENA, not DDR0. Therefore these outputs establish **no exact current DDR0 group_bad[11] -> errors[18].ENA fitted LUT depth, location sequence, mask or fanout**.

Two narrower DDR0 observations remain useful:

- `project/output_files/top.map.rpt:1531` records a registered 3:1, 32-bit errors mux restructure with a reported 64-LE saving. This suggests inspecting the fitted control/data mux structure, but does not decode its saturation enable or prove that it matches a particular OSS two-LUT cut.
- `project/output_files/top.fit.rpt:286` onward records twelve original errors-register routing duplicates, for bits 1, 9, 13, 15, 16, 17, 19, 20, 22, 23, 24 and 31. Bit 18 is not listed among those duplicates. A new endpoint inventory must still verify the actual fitted names rather than infer them from this optimization table.

The retained separate `quartus-error-cone/error15-to-fault4.rpt` reports a real **first-error fault-address ENA** path from errors[15]~DUPLICATE: three LUT levels, 4.025 ns data delay, 2.918 ns routing and +3.432 ns setup slack at a 7.692 ns relationship. Its FF/LUT coordinates are (29,47) -> (28,47) -> (29,46) -> (28,49) -> (28,49), with final LUT fanout 31. This is a compact-locality precedent at comparable fanout, but it is a different logical endpoint from the current saturation-enable bottleneck. Do not present it as the exact group_bad -> errors path.

The much older whole-node inventory uses BUILD_ID `cd3e4c315005fde83065dff7483ae0d7`. It contains DDR0 group_bad[11], errors[18] and nearby errors combinational names, but selected input/output tables omit the relevant complete control cone. Those names and coordinates cannot supply current-fit edge or Boolean proof.

## Existing OSS fourth-stage hypothesis

The actual six-signal terminal cut is already eligible in principle for the existing generic local-remap composer. With all logical pins SIG, its ALUT2 mask `0xd` means `~a | R`; the outer ALUT5 mask `0x7fff0000` means `E & ~(x0 & x1 & x2 & x3)`. The composition is

```text
F(a,R,x0,x1,x2,x3) = (~a | R) & ~(x0 & x1 & x2 & x3)
```

Using that exact input order, the 64-row LSB-first OSS mask is `0x0ddddddddddddddd`. All six external inputs are essential. The upstream R cone has 17 essential external inputs and includes group_valid gating, so absorbing the whole path is neither the supported 11/16/24-literal pure-cube case nor a <=6-raw internal cut. A terminal clone can remove a LUT level while preserving R and its other users; its physical benefit still requires a fresh guide, current placement qualification and a full route. The fourth local stage runs before the existing internal cut, capture locality, placed11 and AC stages, so those later selected stages must independently qualify against the changed graph.

## Saved database is available; root-only query proposal

The untouched current retained project contains these nonempty inputs:

| File | Bytes |
| --- | ---: |
| `db/top.cmp.hdb` | 337883 |
| `db/top.routing.rdb` | 103235 |
| `db/top.sta_cmp.7_slow_1100mv_100c.tdb` | 2806268 |

Root can hash-authenticate and copy the complete retained project into a **new private DDR0 query project**, then use the already successful APIs without refitting. Do not run against the retained original or reuse/overwrite earlier DDR1 query outputs. These are proposed script names, not files written or executed by this agent:

```sh
quartus_sta -t query-ddr0-exact-pins.tcl /absolute/new-private-project/top.qpf /absolute/new-timing-output
quartus_cdb -t dump-ddr0-atoms.tcl /absolute/new-private-project/top.qpf /absolute/new-atoms-output
```

Derive `query-ddr0-exact-pins.tcl` from the successful retained `comb-plan-264/quartus-ddr1-query/query-ddr1-exact-pins.tcl`, retaining identity/count dumps, exclusive output creation, all input-file/BUILD_ID guards and this model setup:

```tcl
project_open top
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist
set registers [get_registers {*ddr0_test*}]
set pins [get_pins -compatibility_mode {*ddr0_test*}]
# Enumerate names first; only these anchored exact roles are accepted:
# {ddr0_test\|group_bad\[11\]$}
# {ddr0_test\|errors\[18\]$}
# {ddr0_test\|errors\[18\]\|ena$}
set launch [get_registers {*ddr0_test*group_bad?11?}]
set capture [get_pins -compatibility_mode {*ddr0_test*errors?18?|ena}]
# Require both queried collections and the enumerated exact roles to have count 1.
report_timing -setup -from $launch -to $capture -npaths 8 -detail full_path -show_routing -file groupbad11-errors18-ena.rpt
project_close
```

The commented requirements must be implemented as the existing script's fail-closed checks, not omitted. `-compatibility_mode` is important: the earlier hierarchical pin form failed because its wildcard did not match absolute hierarchy. If no exact ENA path exists, retain the inventory and report that result; do not substitute DATAIN and call it ENA. A separate register-to-register query may reveal that Quartus realizes the control through DATAIN, but its actual reported endpoint must be named explicitly.

Derive `dump-ddr0-atoms.tcl` from the successful `dump-ddr1-atoms.tcl`: enumerate every DDR0 group_bad/errors FF including duplicates; require unique anchored original group_bad[11] and errors[18]; dump **all** errors[18] input ports before selecting TYPE exactly `ENA`; require one nonconstant producer. Read `read_atom_netlist -type cmp`, expand only `LCELL_COMB` fanin from that producer, stop at FF/hard leaves, and abort rather than truncate if the 128-atom bound is exceeded. Retain each node's type/location, each input's inversion/constant/source port, and each COMBOUT's raw `lutmask` plus full fanout. Dumping DATAIN alongside ENA at the endpoint makes a fitted control-mux difference visible without conflating the queried cones.

Decode the retained Quartus textual 64-bit mask with its previously verified physical convention: `value(row) = (int(mask,16) >> (63-row)) & 1`, with DATAA as row-index bit 0 through DATAF bit 5. Include constants, input inversions and alias/duplicate identity when composing; do not reuse OSS LSB-first mask decoding or use reachable-state assumptions. Record endpoint producer fanout and which consumers are ENA, then compare the exact terminal cut's raw and essential support before proposing a generic factoring change.

Root should retain pre/post project manifests. Earlier no-refit TimeQuest queries changed the private `db/top.taw.rdb` cache, while critical fit inputs stayed unchanged; that is why the untouched fit needs a new authenticated copy.

## Hash checks performed in this review

These current files match the previously recorded hashes:

| File | SHA256 |
| --- | --- |
| Current project `top.qsf` | `db71b993984823bbfc4a9bfcc530a037280ea36a1ded8c9d7bc4acab7caff46d` |
| Current `top.fit.rpt` | `8db149dbb9e2d5afeca75cc81f29abe2ed0e113dcced4e16f58a8ccea4f4d75b` |
| Current `top.map.rpt` | `50d4825785611f27e9e6bca52f695a02ef3e6d0832d04a783188dc89ef5d13d7` |
| Retained error15-to-fault4 report | `02e439a64b6eb04a8f80f52cf513e0552d123ccd29349046387062f8283c3d52` |

No precise Quartus current-control-cone result is inferred from these hashes. They authenticate the observed saved reports and the absence limitation above.
