# Publication review for the cumulative Mistral branch

Prepared by read-only source/report inspection on 2026-09-30. This note is a proposal, not a tracked documentation change, PR, test run or performance acceptance.

## Exact review scope

- Repository: nested `sources/misteross/build/toolchain-ramtest-timing/src/nextpnr`; origin is `DeanoC/nextpnr`.
- Target reference read locally: `origin/main` at `24f9a1db0737559977a13abb2d05cceafa5e6142`.
- Reviewed branch: `experiment/mistral-wide-cube-264`, clean at `6ad210a60991f93a607ac4490d6282b1267ec64a`.
- Cumulative difference: 14 commits, 40 files, 9,202 insertions and 14 deletions. This is not a decomposition-only PR.
- Benchmark compiler remains source `6ad210a6`, binary SHA256 `ba39ad814af51c4a6af3ca1854fcd1dd992af350bb09741d5b6becfa2d7d4b18`, source archive SHA256 `af9b2c05bc7e4fe513f7f879d06c51c94fb696d2bde23469400fc7d041eff209`.
- No compiler source, tests, CMake, FES tracked file, frozen helper or earlier artifact was changed by this review. Only this new ignored note was written.

The fork guide states that feature PRs target `DeanoC/nextpnr:main`. An upstream YosysHQ PR would require a separate, focused branch; do not submit this accumulated fork branch there. Updating the misteross compiler lock, FES selected recipe or hardware image is a separate integration change.

## Cumulative implementation that the PR must describe

| Capability | Changed production files | Scope and status |
| --- | --- | --- |
| Unplaced conjunction balancing | `mistral/reduction_balance.cc`, `reduction_balance_plan.h`, `reduction_balance_policy.h` | Explicit roots; exact 3-LUT/11-, 4-LUT/16-, and 7-LUT/24-distinct-literal classes. Symbolic per-LUT proof and indexed consumer-slot preservation. No automatic design selection. |
| Placed balancing | `mistral/placed_reduction.cc`, `placed_reduction_policy.h` | Fixed public root and outside cells; 11- or 24-literal probes, exact transactional retirement/rollback, bounded geometry diversity and root-aware ranking. The 24-literal experiments did not qualify a candidate; they are supported diagnostics, not a claimed routed gain. |
| Capture locality | `mistral/capture_locality.cc` | Explicit environment diagnostic, registered hard-IP source, fixed logical connectivity, bounded FF movement. The current benchmark stack retains an existing 60-move result. This PR does not enable it in a default recipe. |
| Local LUT composition and staged plans | `mistral/local_remap.cc`, `local_remap_pin_policy.h`, `remap_plan.cc` | Existing two-LUT enable composition gains optional pin-order selection, fixed-FF trials and exact 1..8-step plans. Whole compatible LAB groups are selected; later steps see earlier accepted changes. |
| Internal-cut cloning and staged plans | `mistral/comb_remap.cc`, `local_remap_cut_policy.h`, `comb_plan.cc`, `remap_report.h` | Generic two/three-LUT cuts with at most six raw inputs, cloning to one LUT input while retaining originals. Plans preload all guides, validate current continuous paths and stop selected failures before routing, even with `--force`. |
| Exact seven-input decomposition | `mistral/decomposition_policy.h`, `decomposition_remap.cc` | Four-LUT cuts, seven essential inputs, full 128-row recomposition, one/two encoders and a root. New clone ALMs exclude original occupants; accepted originals form the exact cell/net iteration prefix and clones follow. Physical qualification remains bounded and heuristic. |
| Hooks and arrival ranking | `mistral/main.cc`, `arch.cc`, `arch.h`, `CMakeLists.txt`, `common/kernel/timing.h` | Explicit CLI/environment hooks and build/test registration. Read-only maximum data arrival includes clock-to-Q once and is used for ranking; full timing gates decide qualification. No default routing policy or serialized opt-in state is added. |

Tests cover pure Boolean policies, backend application/rejection/rollback and CLI/order guards. The cumulative PR includes new tests for older local/internal/staged/reduction behavior as well as decomposition; do not characterize all tests as tests of decomposition alone.

The complete cumulative commit chain is:

```
b95ac420 wide reduction balancing
1e4ff5cb hard-IP capture locality diagnostic
0533e9ff eleven-literal balancing
f2a8373d fixed-register placed balancing
2019b389 local LUT input ordering
664599e3 report-guided internal-cut cloning
b8f32140 staged local remapping with fixed FF placement
301fcee8 staged internal cuts
cb7c8176 private 24-literal cubes and guarded placed probes
c74c38a5 four-leaf geometry diversity
ec3fc015 root-pin logic in four-leaf ranking
2d521858 exact seven-input control decomposition
fddbdac2 accepted owner order and original ALM isolation
6ad210a6 original iteration prefix through accepted decomposition
```

## Documentation findings and concrete consolidation

`docs/mistral-reduction-balance.md` still describes only 11/16 literals and says all cells remain. `mistral/reduction_balance.md` describes the current 24-literal rewrite, including two retirements. These are competing capability references. The old file also ends with a historical suggestion to try preserved placement, which has already been implemented on this branch.

`docs/local-path-remap.md` is otherwise useful, but it omits `--remap-optimize-pins`, `--remap-preserve-ffs` and the staged-plan entry point. Its default movement description needs the fixed-FF switch beside it. The newer CLI guides are in `mistral/` and are not linked from the main README or fork guide, making the current interfaces hard to discover.

The plan guides correctly describe exact schemas, duplicate-key rejection, current graph validation and selected-failure handling. `mistral/comb_plan.md` first calls candidate indices zero through INT_MAX and describes final `-1` listing later; presenting both cases together would remove that small ambiguity. `mistral/control_decomposition.md` correctly distinguishes placement-model qualification from final routing. Capture/reduction historical results must be clearly dated and separated from current capability references.

Suggested docs-only edit set after a verified gain:

| File to edit | Concrete change |
| --- | --- |
| NEW `docs/mistral-timing-experiments.md` | A short current entry point with an option/default/bounds table, links to each canonical guide, exact pass order, provenance requirements and the distinction between listing, modeled qualification, full routed gain and hardware acceptance. |
| `README.md` | Add one link to that entry point beside the Cyclone V experimental support/getting-started paragraph. No build instructions or general architecture prose need changes. |
| `docs/mistral-fork.md` | Add the same entry-point link; retain immutable lock selection and separate integration policy. |
| `mistral/reduction_balance.md` | Keep this as the canonical current reduction guide. Add repeatable unplaced-root syntax, numeric bus ordering, the 6+5 and 6+6+4 forms, and distinguish 11/16 retaining all cells from 24 retiring exactly two private cells/nets. Keep current placed search bounds, rollback and route limits. |
| `docs/mistral-reduction-balance.md` | Replace the duplicated capability prose with a link to the canonical guide. Retain the old route section only as a explicitly historical rejected experiment at compiler `0533e9ff`, with its original measured numbers and rejected status. Remove its obsolete 'next experiment' recommendation from current guidance. |
| `docs/local-path-remap.md` | Document the pin-order and fixed-FF flags with their default-off behavior; link to `../mistral/remap_plan.md`. Preserve the existing legacy CLI's actual semantics and guards. |
| `mistral/remap_plan.md` | Link to the common entry point and specify the complete later order: internal cuts, capture locality, placed reductions, then decomposition. Add the integer bound and final `-1` exception together. |
| `mistral/comb_plan.md` | Link to the common entry point and state `candidate=0..2147483647`, with `-1` permitted only for final listing under `--no-route` and no `--rbf`. Mention decomposition follows capture/placed diagnostics. |
| `mistral/control_decomposition.md` | Link to the common entry point and name the exact earlier stage order. Keep the existing original-ALM/prefix/queue-size caveats and full-route evidence requirements. |
| `docs/mistral-capture-locality.md` | Link to the entry point, label the `b95ac420` route record historical and retain its unselected all-clock tradeoff. Specify that capture runs after local/internal cuts and before placed reduction/decomposition. |

No production code or help-string edit is necessary for this consolidation: the CLI help already exposes the new options and all three reduction classes. Do not modify `mistral/main.cc`, engine/policy sources, CMake or tests for publication cleanup while source6ad is the measured compiler.

The entry point should state the actual sequence, without implying every feature is enabled:

```
explicit unplaced root balancing during packing
→ ordinary HeAP placement / existing post-placement enable work
→ legacy local remap OR local plan
→ legacy internal-cut remap OR comb plan
→ capture locality environment diagnostic
→ placed reduction environment diagnostic
→ control decomposition
→ normal routing and signoff
```

Plan/decomposition listing requires `--no-route`, no RBF and a final listing stage. Do not retroactively claim the legacy single-remap interfaces or standalone environment diagnostics enforce all of those CLI restrictions; recommend a no-route/no-RBF enumeration command for them and distinguish their current implementation guards. Plans/decomposition require fresh packing and placement; document legacy guards separately rather than applying new-plan restrictions to old flags by inference.

Do not duplicate test histories in each capability guide. Keep rejected historical experiments visibly historical; place the eventual accepted route summary in one short results section or the PR validation paragraph. Link to durable evidence rather than publishing private `/home/deano/...` paths as the reproducibility interface.

If only docs change after6ad, identify the PR HEAD separately from benchmark source6ad. Check that `git diff 6ad210a6..HEAD --name-only` contains only the intended docs. This does not require rebuilding the compiler; do not relabel a6ad binary/route as a later source commit.

## Publication gate and present limits

The next qualifying result must be a successful complete route with current graph/128-row/local/comb/placed equivalence, full original FF/LUT physical pins and routing-created BUF/user preservation, declared ready-stage exceptions independently proved, no final reported hold violations, and all required clocks nonregressing against actual parent116. Listing gains and unqualified candidates do not satisfy this gate.

The actual parent116 comparison baseline is:

| Clock | Parent116 MHz | Condition for the publication trigger |
| --- | ---: | --- |
| `ram_clock.clocks[0]` | 116.17100524902344 | Strictly greater |
| `display.pixel_clk` | 93.66804504394531 | At least this value |
| `ram_clock.clocks[1]` | 378.5823974609375 | At least this value |

Current finalized groups8+decomposition source6ad route is structurally proved and hold-clean, with memory116.27906799316406 / pixel93.89671325683594 / capture307.6318054199219 MHz. It improves memory/pixel slightly but regresses capture by70.95059204101562 MHz and therefore fails parent116 acceptance. It must not be cited as the requested verified gain. The repairBand3000 trial is a fresh one-option routing experiment; no result from that active trial is assumed by this note.

The memory constraint remains130.0052032470703 MHz. A verified improvement below that value is progress, not130MHz timing closure. No hardware acceptance, default compiler-lock update, selected FES recipe or new ABI/shared contract is established by host routing evidence.

The 24-literal placed class and pin-order options remain available but unused/rejected in the measured successful stack unless the final authenticated command explicitly enables them. Do not assign a measured gain to those options. `--gpu-opt repairBand=3000`, if it wins, is an existing generic router option; this branch does not implement a new repair-band router algorithm.

## Proposed PR wording after the gate passes

Suggested title:

> mistral: add opt-in staged control remapping and exact decomposition

Suggested description (replace the bracketed evidence sentence with the finalized qualified result; do not publish with placeholders):

> Mistral can now apply bounded, report-guided control remaps in an explicit sequence while retaining original logic and register placement where requested. Local enable compositions can be staged across whole compatible LAB groups; internal cuts clone two/three LUTs, and exact seven-input control functions can be decomposed into one/two encoders and a root. Selected failures stop before routing, stale guides are rejected against the live graph, and rejected probes restore owner dictionaries, indexed consumers, connections, pin states and placements.
>
> This cumulative change also adds opt-in11/16/24-literal conjunction balancing, fixed-root placed reduction probes and a hard-IP capture locality diagnostic. All features remain explicit experiments. Decomposition isolates new LUTs from original ALM occupants and retains originals as the accepted cell/net iteration prefix; source arrivals and bounded placement scores rank proposals, while full setup/hold, clock, boundary and legality checks decide qualification.
>
> Validation includes exact Boolean policy tests, backend acceptance and rollback regressions, and CLI/stage-order checks. [Insert the root-verified latest test names/counts and qualified full-route comparison: source6ad and binary digest, identical RTL/synthesis/constraints/BUILD_ID/seed/device, selected profile, parent116 and candidate MHz for all three clocks, graph/physical pin/BUF preservation and final hold result, and durable closed evidence link.] The route remains below130MHz if applicable; no hardware acceptance or default recipe selection is claimed. The unused24-literal diagnostic is not credited with this routed result.

The latest6ad host-validation record establishes25 focused tests passed in40.766s with compiler and backend test targets built. Earlier2d records establish15 CLI tests passed in136.162s and45 legacy backend tests passed in127.934s; identify these as earlier cumulative validation, not fresh6ad executions. The earlier CLI/backend results remain relevant because6ad changed only selected qualified acceptance finalization and its regression, but they do not become a new all-suite run by implication. Root should supply the exact final log hashes and any subsequent checks rather than claiming that all40 files received a single current full-suite run.

Benchmark profiles, query scripts and private raw comparators are ignored FES evidence, not part of the compiler diff. The PR should use the public bounded synthetic regression fixtures in `mistral/tests/` as its code-level reproduction and attach/link only the retained route evidence the root elects to publish. Describe the measured profile separately from default behavior.

## Handoff

This review proposes only docs changes and wording. Root owns any tracked edits, final gate verification, push and explicitly authorized PR publication. The reviewed compiler remains clean source6ad; no additional approval is requested by this note.
