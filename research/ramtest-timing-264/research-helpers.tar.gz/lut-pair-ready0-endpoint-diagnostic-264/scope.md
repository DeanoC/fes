# Fresh endpoint-diagnostic ready0 listing

ROOT filled the seven actual ELF/archive/host/test/check/helper/scope pins
after all47 native and45 CLI diagnostic-source host checks passed. ROOT reviewed
the whole draft and AST; an independent whole-file peer was CLEAN. Final literal
pin filling is separately reviewed before ROOT prepares and invokes this helper. Source
commit e137ca5b is the new isolated one-file diagnostic change on frozen5a4a28eb.
Neither old sources/binaries/builds nor old helpers, guides or evidence change.
Activation requires actual self/scope/ELF/archive/host hashes; execution requires
the exclusive prepared profile's hash. Only new source-identity.json and the
exclusive diagnostic folder/output records are written here.

The exact completed5a disabled-ten control9498 and exact ready0 listing
reproduction94627 are prerequisites. Actual listing profile53f82/run15e5,
recorder6a053/scopefb6, comparator558d/scoped33, the positive dual-reference
control and their flat artifact/runtime closures are bound at their original
paths without old operational/authentication or comparison entrypoint replay.
The old candidate count is observed; no candidate existence or acceptance is
assumed. The new host must independently bind current source/archive/object
dependencies, unchanged selected submodules/model, cache and all47 native/45 CLI
cases. These are new compiler host checks, not inherited build acceptance.

The original ready0-guide.json9bdad541 is used unchanged, including the exact
critical_paths-only current path object. No guide/report or native graph is
regenerated. Fresh pack/ordinary HeAP placement uses the old listing argv's
literal ten-stage plan00bf, original descriptor order, source JSON/device/QSF/
SDC/seed/options and diagnostic environment. The only command changes are the
new diagnostic ELF and new write/report paths. Pair candidate remains-1;
no-route remains present; no post-plan, driver, replay or RBF is introduced.

The runtime snapshot must equal the old listing except for its one ELF pathname/
hash and controlled PATH directory. All other execution fields, selected GPU1,
libraries/platform/tracer/device and environment are exact. FunctionalInvocation
and compiler-read audit independently bind the actual run. All current and
historical source/dependency/runtime/profile/report input hashes and loaded five
project-module paths/hashes are checked before and after execution. Failed or
partial output records remain incomplete, with actual available output hashes
and a separate final input/runtime stability result.

Only pinned old listing/control definition loaders and pure qualification parsers
are called. Their complete eight-module chain is bound. The fresh ten guarded
models and every original pair discovery/domain/trial/candidate/final-listing
line must exactly equal the old actual listing. The parser explicitly excludes
only the new endpoint-rejection detail, summary and count forms, which it parses
separately and retains as literal lines. No old prepare/execute/main/host validator
or high-level native/physical/timing evaluator is activated.

Each of the actual single-cone16 trial rows must have exactly one diagnostic
summary before its original trial, with at most four earlier detail
rows followed by sorted unique reason counts. Trial index, both moved owners and
both chosen BELs must bind that following trial. Native/reference reason counts,
shown and omitted detail totals must agree with each other and the unchanged
endpoint-guard result. Full original raw field strings are retained, including
missing coverage/shape, clock identities/edges, row bounds, optional presence,
setup/hold windows/margins, max/min delays/deltas and hold floor. Unknown guard
failure is retained as an explicit diagnostic reason, not recast as setup or
hold evidence. No extra STA run or guard relaxation is performed.

Normal completion must remain a final listing that applies no candidate and
performs only predicted timing analysis. The full report must contain15,290
paths at cap16,384; fresh Fmax, all71 placement metric rows and full report
equality are recorded as comparison diagnostics. Independent native/physical
reproduction and complete seven-pair topology require a later separate fresh
comparison. No source graph, physical/cache proof, routed gain, calibration,
bitstream decode or hardware acceptance is inherited. The accepted fifth
117.771759MHz routed result remains separate from this diagnostic search.
