# Fresh endpoint-diagnostic listing reproduction

ROOT supplied the actual completed diagnostic profile/run and final recorder/
scope hashes after fresh execution closed with exit0 and stable audited inputs.
ROOT whole-file review and AST passed; independent whole-file draft peer was
CLEAN. The four literal fills are separately reviewed before ROOT executes this
comparator with explicit self/scope/profile/run/recorder/scope hashes. It writes only exclusive diagnostic/comparison-diagnostic.json.
Neither previous helpers nor source/build/evidence files change.

The new isolated compiler e137ca5b on frozen5a4a28eb, ELF ac6a481b, archive
8b498afd and host84f487 are independently bound with current47 native/45 CLI
checks, testdf7b and check-results689248. Every absolute source, submodule,
external-model, object dependency, original input/output and runtime path is
bound before comparison and rehashed after it. Archive member names remain
relative member evidence. No old host validator or operational entrypoint runs.

Both historical prerequisites must be positive: disabled-TEN control9498 and
ready0 listing reproduction94627. Their exact profile/run/helper/scope and flat
artifact/runtime ledgers are bound. The disabled control itself proved strict
TEN-model/native/71-metric/full-report parity with both original d7e and b3d
disabled-post controls; those retained closures are adopted without replay.
This comparison independently reads the actual 5a control and actual 5a listing
images, reports and logs as two direct references.

The actual new record must be completed with exit0/readAudit and stable hashes,
match every prepared profile field, have the exact profile-plus-own-profile
input union and the exact three output hashes. Its command equals the old
listing except for the diagnostic ELF and write/report aliases. Its execution
snapshot equals that listing except for one ELF file and controlled PATH.
Source JSON/device/QSF/SDC/seed, literal TEN plan00bf, descriptor order/options,
selected GPU1, libraries/device/tracer/environment, unchanged one-path guide
9bdad541, fixed original FFs and ten copy cohorts remain exact. Candidate-1 and
no-route remain; post-plan, driver, replay, RBF and routing are absent.

Only pinned lower definitions are called:32fd lossless native JSON/Audit and
placement metrics;72131 native tables/report topology with its exact8601
dependency in a module-local import namespace; the new recorder's pure
command/runtime/definition loader/qualification parser; and old listing/control
pure parsers with their full eight-module chain. Every called path/hash and the
five project modules loaded by the actual compiler invocation must belong to
the frozen current input closure. No prepare, execute, clean-source, old
comparison, authenticator, generator or high-level physical/timing evaluator
is called.

All14,907 cells/16,645 netnames and the complete native module must equal BOTH
references. All8,221 original FF records/BELs, types, LUT tables, ports, raw IDs,
connections, aliases, pin snapshots, controls, nested metadata, owner/port/list
order, reconstructed complete driver/user occurrence slots and lossless paired
PLL entries are strict. Only the document creator string may differ as compiler
provenance; all actual strings and whether they differ are disclosed. There is
no private-frame alignment, buffer collapse, native module exemption, numerical
relabeling or inherited physical/cache proof.

The full TEN guarded model dictionaries, all71 placement metrics and the ENTIRE
predicted report must equal both direct references. All three complete native
images undergo independent15,290-path/seven-clock-pair topology checks against
the disabled control's endpoint/window sets, with finite terms and cap16,384.
Model/diagnostic rejection, native rejection, metric/report mismatch and topology
rejection are separate. Structural rejection still records report/topology
diagnostics and completes the original-path rehash.

The new pure parser explicitly separates only production endpoint detail,
summary and reason-count lines; all original discovery/domain/trial/candidate
and final-listing lines must equal the old listing. The actual one cone and16
trials, both owners/BELs, diagnostic trial indices, native/reference failure
totals, at most four detail rows, omitted totals, row/presence/value fields and
each raw line are parsed again and must equal the actual recorded objects.
Unknown or missing coverage reasons remain diagnostics. Candidate existence or
a particular failing endpoint/reason is never assumed.

Only all exact gates permit fresh_lut_pair_endpoint_diagnostic_reproduction_proved.
This proves diagnostic listing reproduction, with no selected candidate,
independent physical/numerical STA, routed timing gain, calibration, unexported
cache state, bitstream decode or hardware acceptance. Accepted routed five-stage
117.771759MHz remains a separate numerical reference.
