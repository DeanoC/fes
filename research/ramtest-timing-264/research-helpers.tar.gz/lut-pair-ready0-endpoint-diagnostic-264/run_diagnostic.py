"""Record a fresh ready0 listing with bounded endpoint-rejection diagnostics."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-endpoint-diagnostics-264"
COMPILER, OLD, CONTROL = (RAW / name for name in
    ("lut-pair-endpoint-diagnostics-264", "lut-pair-ready0-listing-264", "lut-pair-ten-control-264"))
COMMIT, BASE = "e137ca5bda7c5e68e6da65f37b5830d12f58727a", "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc"
BINARY, ARCHIVE, HOST = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz", COMPILER / "validation/host-validation.json"
BINARY_SHA, ARCHIVE_SHA, HOST_SHA = "ac6a481b0f8d57a2f8da7dee22a7be00e9003aa4bc941d504093c6285bb42a08", "8b498afdf738a43a5a36731a1b1a09a624c3490009b5f30ec63671f3caea33df", "84f487077a00752ae590afd546b13fdd08879531c33d7b8ac572f8e3ed682a05"
TEST_SHA, CHECKS_SHA = "df7b3a568485dc9b986f5f7a414e2a78436bf419e548d4fc47e417b4734224de", "689248c35a50b41259e13b0d70084a2f637f42e6f7f1f3e687adb069a087bc82"
HOST_HELPER_SHA, HOST_SCOPE_SHA = "572ffed1c2b0133bce6108e20ced55c3c04f8de428419770bf60b89217cfb098", "db5b40c6d231045407be0b297eeaf9ef9ae7a052ebaa3a82078e1dc67e642bcd"
OLD_PROFILE, OLD_RUN, OLD_PROOF = OLD / "source-identity.json", OLD / "listing/run.json", OLD / "listing/comparison-listing.json"
OLD_PROFILE_SHA = "53f82bb5adc3bcac143097cade72eefbbb076344cb4243c31f109cd8993b9103"
OLD_RUN_SHA = "15e5a0c3e188811d870201e204b0cb0b9dcfadca545d0b051d2580f62e5f2fe4"
OLD_PROOF_SHA = "94627ac9a7ce2d8df01549d673233e914326fed48e9dd538042e5a37597f50d5"
OLD_HELPER_SHA, OLD_SCOPE_SHA = "6a053c8b28d5fa20ede4ba5ffdfe72f45bba48128931242407e380ac874b4964", "fb6d6ab4ce4ac93ac5d7293da2773b6756d898b1831531b7eff02b64d9a15c19"
OLD_COMPARER_SHA, OLD_COMPARISON_SCOPE_SHA = "558d267935a07370971aa54748662131fd8473a35738ddb7442bbb67060de205", "d33bc3f0ee3f4dd9bf831b3fafefe4ea5c243b913739064e771655429c261e2e"
OLD_BINARY = RAW / "lut-pair-placement-264/nextpnr-mistral"
OLD_BINARY_SHA = "1b4e45ac1adc5adf9be8edcfa67b922d7626504dc0bbc73f24ffb69b263f4b1f"
CONTROL_PROFILE_SHA = "d8c15d6b1ec82481f4dd3131136a8e7a913488a9f2961ec5da2f9e9a19f16413"
CONTROL_RUN_SHA = "581f3dd629fc00c7887bca7b6d8415fec214ce1cbe042c754e9eff776dbe3caa"
CONTROL_PROOF_SHA = "9498fb62edd6a9a25a3d8db137f1b7c32cc03dccd3be5a81233be639c81a196e"
CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA = "f72f98877a989f2457800989a69de7ef24d449cac4f6af759abc34a8ca447b13", "90494f8f0085b28b1d3a762508b09dff66396fab5c29994a869a319c3eaee903"
CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA = "1350e1ae0913ded6504c44bf3b75174c5121a06995e8c2924162d9a59864da2e", "a9a8951997616e288371ca9532bb573b136704f2f880b0a69e9ba9453f1cf1b2"
GUIDE, GUIDE_SHA = OLD / "ready0-guide.json", "9bdad54100c802d4a4aa366203afcaaffcfd4f69456d0ec2b0f6ac58ac786d41"
PLAN, PLAN_SHA = RAW / "local-plan16-ready1-command-stage-264/local-plan.json", "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "diagnostic"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}
DIAG_PREFIX = "Info: LUT pair placement endpoint rejection "
TRIAL = re.compile(r"^Info: LUT pair placement trial inner=(\S+) outer=(\S+) sink=(\S+) inner_bel=(\S+) outer_bel=(\S+) gain=(-?\d+)ps improve=(\d+) endpoints=(\d+) clocks=(\d+) hold=(\d+) fixed=(\d+)$", re.M)
REASONS = {"endpoint-coverage-unavailable", "baseline-rows-empty", "row-count-changed", "launch-clock-or-edge-changed",
    "capture-clock-or-edge-changed", "setup-timed-class-changed", "hold-related-class-changed", "setup-window-changed",
    "setup-margin-presence-changed", "hold-margin-presence-changed", "unrelated-max-path-delay-increased",
    "unrelated-min-path-delay-decreased", "timed-setup-window-unavailable", "timed-setup-margin-unavailable",
    "timed-max-path-delay-increased", "timed-setup-margin-decreased", "related-hold-margin-unavailable",
    "related-hold-margin-below-floor", "guard-failure-unclassified"}
COMMON = {"trial", "inner", "outer", "inner_bel", "outer_bel"}
SUMMARY = COMMON | {"native_failures", "reference_failures", "detail_rows", "omitted_detail_rows"}
COUNT = COMMON | {"frame", "reason", "endpoint_failures"}
DETAIL = COMMON | {"frame", "endpoint", "endpoint_bel", "reason", "covered", "row", "before_rows", "after_rows",
    "before_launch", "before_launch_edge", "after_launch", "after_launch_edge", "before_capture", "before_capture_edge", "after_capture", "after_capture_edge",
    "before_setup_timed", "after_setup_timed", "before_hold_related", "after_hold_related", "hold_floor_present", "hold_floor_ps"}
for side in ("before", "after"):
    DETAIL |= {side + "_" + name for name in ("setup_window_present", "setup_window_ps", "setup_margin_present", "setup_margin_ps",
        "hold_margin_present", "hold_margin_ps", "max_path_ps", "min_path_ps")}
DETAIL |= {name + "_delta_ps" for name in ("setup_margin", "hold_margin", "max_path", "min_path")}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch("[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original pathname hash")
    if path not in inputs:
        require(sha(path) == expected, "original input differs: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat runtime entry is not absolute"); bind(inputs, name, expected)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def listing_definitions():
    listing = load(OLD / "run_listing.py", OLD_HELPER_SHA, "ready0_diagnostic_listing_pure")
    control, definitions = listing.control_definitions()
    return listing, control, definitions


def command(old):
    result = list(old["command"])
    require(result[0] == str(OLD_BINARY) and result.count("--no-route") == result.count("--remap-plan") ==
        result.count("--remap-lut-pair-critical") == result.count("--remap-lut-pair-candidate") == 1 and
        result[result.index("--remap-plan") + 1] == str(PLAN) and result[result.index("--remap-lut-pair-critical") + 1] == str(GUIDE) and
        result[result.index("--remap-lut-pair-candidate") + 1] == "-1" and not any(flag in result for flag in
        ("--no-pack", "--no-place", "--rbf", "--remap-post-plan", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")),
        "proved old listing command role differs")
    result[0] = str(BINARY)
    for flag, name in (("--write", "placed.json"), ("--report", "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector"); result[result.index(flag) + 1] = str(FOLDER / name)
    return result


def expected_execution(old):
    result = copy.deepcopy(old["execution"])
    require(result["files"].pop(str(OLD_BINARY)) == OLD_BINARY_SHA and str(BINARY) not in result["files"] and
        result["environment"]["PATH"] == str(OLD_BINARY.parent) + ":/usr/bin:/bin", "old listing compiler/PATH differs")
    result["files"][str(BINARY)] = BINARY_SHA; result["files"] = dict(sorted(result["files"].items()))
    result["environment"]["PATH"] = str(BINARY.parent) + ":/usr/bin:/bin"
    return result


def closed_record(record, profile, path, expected, execution_key):
    require(record["completed"] is True and record["exit_code"] == 0 and
        record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
        record["source_identity_sha256"] == expected and record["execution"] == profile[execution_key] and
        record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(canonical(record[key]) == canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "prerequisite profile/run is not closed")


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and git(SOURCE, "diff", "--name-only", BASE, COMMIT) == "mistral/lut_pair_placement.cc",
        "new diagnostic source is not the clean reviewed one-file commit")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
        [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "current model/submodule identity changed")


def qualification(log, listing, control, definitions):
    # Only the three explicitly parsed diagnostic forms are removed. Every
    # original discovery/domain/trial/candidate/summary line remains binding.
    filtered = "".join(line for line in log.splitlines(keepends=True) if not line.startswith(DIAG_PREFIX))
    models, pair = listing.qualification(filtered, control, definitions)
    trials = list(TRIAL.finditer(log))
    require(pair["discovered_bounded_pairs"] == 1 and len(trials) == pair["actual_trial_count"] == 16,
        "diagnostic listing is not the actual single-cone sixteen-trial experiment")
    rows, raw_lines = {i: [] for i in range(len(trials))}, []
    for match in re.finditer(r"^Info: LUT pair placement endpoint rejection (.+)$", log, re.M):
        raw, body = match[0], match[1]
        kind = "summary" if body.startswith("summary ") else "count" if body.startswith("count ") else "detail"
        if kind != "detail": body = body[len(kind) + 1:]
        fields = {}
        for token in body.split():
            key, separator, value = token.partition("=")
            require(separator and key not in fields and value, "malformed/duplicate endpoint diagnostic field"); fields[key] = value
        require(set(fields) == {"summary": SUMMARY, "count": COUNT, "detail": DETAIL}[kind] and
            re.fullmatch(r"\d+", fields["trial"]), "endpoint diagnostic schema/trial differs")
        index = int(fields["trial"]); require(index in rows, "diagnostic trial is outside actual trials")
        trial = trials[index]
        require((fields["inner"], fields["outer"], fields["inner_bel"], fields["outer_bel"]) ==
            (trial[1], trial[2], trial[4], trial[5]) and match.end() < trial.start() and
            (index == 0 or match.start() > trials[index - 1].end()), "diagnostic does not bind its following actual trial/site")
        if kind == "summary":
            require(all(re.fullmatch(r"\d+", fields[key]) for key in SUMMARY - COMMON), "noninteger diagnostic summary")
        else:
            require(fields["frame"] in ("native", "reference") and fields["reason"] in REASONS, "unknown diagnostic frame/reason")
            if kind == "count":
                require(re.fullmatch(r"[1-9]\d*", fields["endpoint_failures"]), "empty/noninteger reason count")
            else:
                require(all(fields[key] in ("0", "1") for key in DETAIL if key.endswith("_present") or key in
                    ("covered", "before_setup_timed", "after_setup_timed", "before_hold_related", "after_hold_related")) and
                    re.fullmatch(r"-?\d+", fields["row"]) and int(fields["row"]) >= -1 and
                    all(re.fullmatch(r"\d+", fields[key]) for key in ("before_rows", "after_rows")) and
                    all(re.fullmatch(r"-?\d+", fields[key]) for key in DETAIL if key.endswith("_ps") and not key.endswith("_delta_ps")) and
                    all(math.isfinite(float(fields[key])) for key in DETAIL if key.endswith("_delta_ps")), "invalid diagnostic presence/index/delay fields")
                require(all(fields[key] in ("rising", "falling", "unknown", "unavailable") for key in DETAIL if key.endswith("_edge")), "invalid diagnostic clock edge")
                if int(fields["row"]) >= 0:
                    require(int(fields["row"]) < min(int(fields["before_rows"]), int(fields["after_rows"])), "diagnostic row out of bounds")
        rows[index].append({"kind": kind, "fields": fields, "raw_line": raw}); raw_lines.append(raw)
    records = []
    for index, entries in rows.items():
        detail = [row for row in entries if row["kind"] == "detail"]
        summaries = [row for row in entries if row["kind"] == "summary"]
        counts = [row for row in entries if row["kind"] == "count"]
        require(len(summaries) == 1 and len(detail) <= 4 and [row["kind"] for row in entries] ==
            ["detail"] * len(detail) + ["summary"] + ["count"] * len(counts), "bounded detail/summary/count ordering differs")
        summary = summaries[0]["fields"]
        keys = [(row["fields"]["frame"], row["fields"]["reason"]) for row in counts]
        require(keys == sorted(set(keys)), "duplicate/unsorted reason counts")
        total = {frame: sum(int(row["fields"]["endpoint_failures"]) for row in counts if row["fields"]["frame"] == frame)
            for frame in ("native", "reference")}
        failures = sum(total.values())
        require(total["native"] == int(summary["native_failures"]) and total["reference"] == int(summary["reference_failures"]) and
            len(detail) == int(summary["detail_rows"]) == min(4, failures) and
            failures - len(detail) == int(summary["omitted_detail_rows"]) and (trials[index][8] == "1") == (failures == 0),
            "diagnostic counts disagree with actual endpoint guard result")
        for key in keys:
            require(sum((row["fields"]["frame"], row["fields"]["reason"]) == key for row in detail) <=
                int(counts[keys.index(key)]["fields"]["endpoint_failures"]), "detail rows exceed their reason count")
        require(all((row["fields"]["frame"], row["fields"]["reason"]) in keys for row in detail), "detail lacks a corresponding reason count")
        records.append({"trial_index": index, "actual_trial_row": list(trials[index].groups()), "summary": summary,
            "detail_rows": [row["fields"] for row in detail], "reason_counts": [row["fields"] for row in counts],
            "raw_lines": [row["raw_line"] for row in entries]})
    return models, pair, {"trial_records": records, "all_endpoint_diagnostic_lines": raw_lines,
        "maximum_detail_rows_per_trial": 4, "native_or_physical_reproduction_proved": False, "routed_gain_accepted": False}


def prepare(self_sha, scope_sha, binary_sha, archive_sha, host_sha):
    pins = (BINARY_SHA, ARCHIVE_SHA, HOST_SHA, TEST_SHA, CHECKS_SHA, HOST_HELPER_SHA, HOST_SCOPE_SHA)
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in (self_sha, scope_sha, *pins)), "actual new diagnostic compiler/host pins remain UNFROZEN")
    require((binary_sha, archive_sha, host_sha) == (BINARY_SHA, ARCHIVE_SHA, HOST_SHA) and not PROFILE.exists() and not FOLDER.exists(),
        "actual activation pins and exclusive diagnostic outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (OLD_PROFILE, OLD_PROFILE_SHA),
        (OLD_RUN, OLD_RUN_SHA), (OLD_PROOF, OLD_PROOF_SHA), (OLD / "run_listing.py", OLD_HELPER_SHA), (OLD / "scope.md", OLD_SCOPE_SHA),
        (OLD / "compare_listing.py", OLD_COMPARER_SHA), (OLD / "comparison-scope.md", OLD_COMPARISON_SCOPE_SHA),
        (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA), (CONTROL / "baseline/run.json", CONTROL_RUN_SHA),
        (CONTROL / "baseline/comparison-control.json", CONTROL_PROOF_SHA), (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA),
        (CONTROL / "scope.md", CONTROL_SCOPE_SHA), (CONTROL / "compare_control.py", CONTROL_COMPARER_SHA),
        (CONTROL / "comparison-scope.md", CONTROL_COMPARISON_SCOPE_SHA), (HOST, host_sha),
        (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (BINARY, binary_sha), (ARCHIVE, archive_sha), (GUIDE, GUIDE_SHA), (PLAN, PLAN_SHA)):
        bind(inputs, path, expected)
    old_profile, old, proof, control_profile, control_record, control_proof, host = (read(path) for path in
        (OLD_PROFILE, OLD_RUN, OLD_PROOF, CONTROL / "source-identity.json", CONTROL / "baseline/run.json", CONTROL / "baseline/comparison-control.json", HOST))
    closed_record(old, old_profile, OLD_PROFILE, OLD_PROFILE_SHA, "listing_execution")
    closed_record(control_record, control_profile, CONTROL / "source-identity.json", CONTROL_PROFILE_SHA, "baseline_execution")
    require(proof["schema"] == 1 and proof["phase"] == "lut-pair-ready0-listing-native-reproduction" and
        proof["source_identity_sha256"] == OLD_PROFILE_SHA and proof["current_listing_run_sha256"] == OLD_RUN_SHA and
        proof["generator_sha256"] == OLD_COMPARER_SHA and proof["scope_sha256"] == OLD_COMPARISON_SCOPE_SHA and
        proof["recorder_sha256"] == OLD_HELPER_SHA and proof["recorder_scope_sha256"] == OLD_SCOPE_SHA and
        proof["compiler_commit"] == BASE and proof["control_proof_sha256"] == CONTROL_PROOF_SHA and
        proof["control_profile_sha256"] == CONTROL_PROFILE_SHA and proof["control_run_sha256"] == CONTROL_RUN_SHA and
        proof["current_actual_execution"] == old["execution"] and
        proof["structural_rejection"] is proof["model_or_listing_rejection"] is proof["native_path_topology_rejection"] is None and
        all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
            "all_71_placement_metrics_exact", "complete_predicted_report_exact", "recorded_reproduction_diagnostics_exact",
            "fresh_lut_pair_listing_reproduction_proved", "final_original_path_metadata_and_runtime_hashes_stable")), "prior5a exact listing reproduction prerequisite differs")
    require(control_proof["phase"] == "lut-pair-disabled-ten-stage-native-control" and control_proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and
        control_proof["current_baseline_run_sha256"] == CONTROL_RUN_SHA and control_proof["generator_sha256"] == CONTROL_COMPARER_SHA and
        control_proof["scope_sha256"] == CONTROL_COMPARISON_SCOPE_SHA and control_proof["compiler_commit"] == BASE and
        control_proof["current_actual_execution"] == control_record["execution"] and control_proof["structural_rejection"] is control_proof["native_path_topology_rejection"] is None and
        all(control_proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
            "all_71_placement_metrics_exact", "complete_predicted_report_exact", "fresh_lut_pair_control_prerequisite_proved",
            "final_original_path_metadata_and_runtime_hashes_stable")) and all(control_proof[key] == {"d7e_original_ten": True, "b3d_disabled_post_ten": True}
            for key in ("ten_model_equality_by_reference", "placement_metric_equality_by_reference", "complete_report_equality_by_reference")), "prior5a dual-reference control prerequisite differs")
    counts = {"pair_backend": 12, "native_plan": 25, "driver_backend": 10, "pair_cli": 11, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and
        host["check_results_sha256"] == CHECKS_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and set(host["changed_source_files"]) == {"mistral/lut_pair_placement.cc"} and
        set(host["checks"]) == set(counts) and all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
        all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"], "new independent diagnostic host/source/check qualification differs")
    for entry in (proof, control_proof): adopt(inputs, entry)
    for entry in (old, control_record):
        folder = Path(entry["command"][entry["command"].index("--write") + 1]).parent
        require(set(entry["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")}, "prerequisite output triplet differs")
    for ledger in (old["input_sha256"], old["output_sha256"], control_record["input_sha256"], control_record["output_sha256"], old["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original closure path is not absolute"); bind(inputs, path, expected)
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    listing, control, definitions = listing_definitions()
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    models, pair = listing.qualification((OLD_RUN.parent / "phase.log").read_text(), control, definitions)
    require(canonical(models) == canonical(old["actual_selected_local_qualification"]) == canonical(proof["fresh_local_models"]) and len(models) == 10 and
        canonical(pair) == canonical(old["actual_pair_listing"]) == canonical(proof["actual_pair_listing"]) and
        pair["discovered_bounded_pairs"] == 1 and pair["actual_trial_count"] == 16 and pair["candidate_applied"] is False and
        old["compiler_commit"] == BASE and old["binary_sha256"] == OLD_BINARY_SHA and old["execution"] == control_record["execution"] and
        read(GUIDE) == {"critical_paths": [old["exact_current_path_object"]]} and old["guide_sha256"] == GUIDE_SHA and
        read(PLAN)["steps"] == old["local_plan_steps"] and len(old["local_plan_steps"]) == 10 and len(old["all_original_ff_bel_manifest"]) == 8221,
        "old actual listing models/guide/plan/record provenance differs")
    profile = {"schema": 1, "phase": "lut-pair-ready0-endpoint-diagnostic-predicted-listing", "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "previous_listing_profile_sha256": OLD_PROFILE_SHA, "previous_listing_run_sha256": OLD_RUN_SHA, "previous_listing_proof_sha256": OLD_PROOF_SHA,
        "previous_listing_recorder_sha256": OLD_HELPER_SHA, "previous_listing_recorder_scope_sha256": OLD_SCOPE_SHA,
        "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": CONTROL_RUN_SHA, "control_proof_sha256": CONTROL_PROOF_SHA,
        "guide_path": str(GUIDE), "guide_sha256": GUIDE_SHA, "exact_current_path_object": old["exact_current_path_object"],
        "original_plan_path": str(PLAN), "original_plan_sha256": PLAN_SHA, "local_plan_steps": old["local_plan_steps"],
        "retained_local_models": models, "retained_pair_listing": pair, "retained_copy_cohorts": old["retained_copy_cohorts"],
        "all_original_ff_bel_manifest": old["all_original_ff_bel_manifest"], "pair_candidate_selection": -1, "command": command(old),
        "cwd": old["cwd"], "diagnostic_environment": old["diagnostic_environment"], "diagnostic_execution": expected_execution(old),
        "authorized_runtime_delta": {"old_compiler_path": str(OLD_BINARY), "old_compiler_sha256": OLD_BINARY_SHA, "new_compiler_path": str(BINARY),
            "new_compiler_sha256": BINARY_SHA, "controlled_path_directory_replaced": True, "all_other_execution_fields_and_files_exact": True},
        "post_plan_requested": False, "driver_pass_executed": False, "native_or_physical_reproduction_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False, "input_sha256": dict(sorted(inputs.items()))}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "diagnostic_listing_only": True}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, old, host = read(PROFILE), read(OLD_RUN), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    require(not FOLDER.exists() and profile["phase"] == "lut-pair-ready0-endpoint-diagnostic-predicted-listing" and
        profile["command"] == command(old) and profile["diagnostic_execution"] == expected_execution(old) and profile["cwd"] == old["cwd"] == str(MODULE) and
        profile["diagnostic_environment"] == old["diagnostic_environment"] and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
        all(inputs[str(path)] == profile[key] == expected for path, key, expected in
            ((OLD_PROFILE, "previous_listing_profile_sha256", OLD_PROFILE_SHA), (OLD_RUN, "previous_listing_run_sha256", OLD_RUN_SHA),
             (OLD_PROOF, "previous_listing_proof_sha256", OLD_PROOF_SHA), (HOST, "host_validation_sha256", HOST_SHA),
             (BINARY, "binary_sha256", BINARY_SHA), (ARCHIVE, "source_archive_sha256", ARCHIVE_SHA), (GUIDE, "guide_sha256", GUIDE_SHA))) and
        inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
        read(GUIDE) == {"critical_paths": [profile["exact_current_path_object"]]}, "frozen diagnostic profile/guide/command/runtime differs")
    listing, control, definitions = listing_definitions(); clean_source(host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["diagnostic_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual diagnostic runtime differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "fresh diagnostic listing did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step")) and
            not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "diagnostic is not a final predicted-only listing")
        models, pair, diagnostics = qualification(log, listing, control, definitions)
        record["actual_selected_local_qualification"], record["actual_pair_listing"], record["actual_endpoint_diagnostics"] = models, pair, diagnostics
        record["all_ten_complete_trial_models_exact"] = canonical(models) == canonical(profile["retained_local_models"])
        record["all_original_pair_discovery_domain_trial_candidate_lines_exact"] = canonical(pair) == canonical(profile["retained_pair_listing"])
        require(record["all_ten_complete_trial_models_exact"] and record["all_original_pair_discovery_domain_trial_candidate_lines_exact"], "new diagnostic compiler changed original model/trial outcomes")
        metric = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
        rows, old_rows = metric.findall(log), metric.findall((OLD_RUN.parent / "phase.log").read_text())
        record["all_71_placement_metrics_exact"] = len(rows) == len(old_rows) == 71 and rows == old_rows
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "complete predicted report count/cap/Fmax differs")
        record["actual_predicted_fmax"] = report["fmax"]
        record["complete_predicted_report_exact_diagnostic"] = canonical(report) == canonical(read(OLD_RUN.parent / "timing.json"))
        record["output_sha256"] = {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "actual diagnostic output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "trial_records": len(diagnostics["trial_records"]), "native_or_physical_reproduction_inherited": False, "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                    try:
                        finish({**inputs, **record["output_sha256"]}); invocation.verify(); clean_source(host)
                        record["final_original_input_output_runtime_hashes_stable"] = True
                    except BaseException as final_error:
                        record["final_original_input_output_runtime_hashes_stable"] = False
                        record["final_hash_or_runtime_failure"] = repr(final_error)
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "binary-sha256", "archive-sha256", "host-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.binary_sha256, args.archive_sha256, args.host_sha256)
        require(all(values), "actual preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
