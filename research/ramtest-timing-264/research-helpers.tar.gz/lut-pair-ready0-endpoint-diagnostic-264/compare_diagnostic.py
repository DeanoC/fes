"""Compare a fresh endpoint-diagnostic listing with both immutable 5a controls."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE, RUN, RUNNER = HERE / "source-identity.json", HERE / "diagnostic/run.json", HERE / "run_diagnostic.py"
OLD, CONTROL, COMPILER = (RAW / name for name in
    ("lut-pair-ready0-listing-264", "lut-pair-ten-control-264", "lut-pair-endpoint-diagnostics-264"))
COMMIT, BASE = "e137ca5bda7c5e68e6da65f37b5830d12f58727a", "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc"
BINARY_SHA = "ac6a481b0f8d57a2f8da7dee22a7be00e9003aa4bc941d504093c6285bb42a08"
ARCHIVE_SHA = "8b498afdf738a43a5a36731a1b1a09a624c3490009b5f30ec63671f3caea33df"
HOST_SHA = "84f487077a00752ae590afd546b13fdd08879531c33d7b8ac572f8e3ed682a05"
TEST_SHA = "df7b3a568485dc9b986f5f7a414e2a78436bf419e548d4fc47e417b4734224de"
CHECKS_SHA = "689248c35a50b41259e13b0d70084a2f637f42e6f7f1f3e687adb069a087bc82"
HOST_HELPER_SHA = "572ffed1c2b0133bce6108e20ced55c3c04f8de428419770bf60b89217cfb098"
HOST_SCOPE_SHA = "db5b40c6d231045407be0b297eeaf9ef9ae7a052ebaa3a82078e1dc67e642bcd"
PROFILE_SHA, RUN_SHA = "b894dd50f695a788060509567f9d930e7277b63f5e2038af3909f33e43a985b6", "f08067560d5fe7c753b403666b89583ee8d5eba03b66a6432cf16f564b69824f"
RUNNER_SHA, RUNNER_SCOPE_SHA = "3ea527220aa116a50d3930802fcec56a92572d2b91f685e5fb0e11e0d80f76d6", "a7bd7c1b16d169a96a55dac3747ddbb5e91b1d8c0f35ddf005c557124bfd3d8c"
OLD_PROFILE_SHA = "53f82bb5adc3bcac143097cade72eefbbb076344cb4243c31f109cd8993b9103"
OLD_RUN_SHA = "15e5a0c3e188811d870201e204b0cb0b9dcfadca545d0b051d2580f62e5f2fe4"
OLD_PROOF_SHA = "94627ac9a7ce2d8df01549d673233e914326fed48e9dd538042e5a37597f50d5"
OLD_HELPER_SHA, OLD_SCOPE_SHA = "6a053c8b28d5fa20ede4ba5ffdfe72f45bba48128931242407e380ac874b4964", "fb6d6ab4ce4ac93ac5d7293da2773b6756d898b1831531b7eff02b64d9a15c19"
OLD_COMPARER_SHA, OLD_COMPARISON_SCOPE_SHA = "558d267935a07370971aa54748662131fd8473a35738ddb7442bbb67060de205", "d33bc3f0ee3f4dd9bf831b3fafefe4ea5c243b913739064e771655429c261e2e"
CONTROL_PROFILE_SHA = "d8c15d6b1ec82481f4dd3131136a8e7a913488a9f2961ec5da2f9e9a19f16413"
CONTROL_RUN_SHA = "581f3dd629fc00c7887bca7b6d8415fec214ce1cbe042c754e9eff776dbe3caa"
CONTROL_PROOF_SHA = "9498fb62edd6a9a25a3d8db137f1b7c32cc03dccd3be5a81233be639c81a196e"
CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA = "f72f98877a989f2457800989a69de7ef24d449cac4f6af759abc34a8ca447b13", "90494f8f0085b28b1d3a762508b09dff66396fab5c29994a869a319c3eaee903"
CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA = "1350e1ae0913ded6504c44bf3b75174c5121a06995e8c2924162d9a59864da2e", "a9a8951997616e288371ca9532bb573b136704f2f880b0a69e9ba9453f1cf1b2"
GUIDE, GUIDE_SHA = OLD / "ready0-guide.json", "9bdad54100c802d4a4aa366203afcaaffcfd4f69456d0ec2b0f6ac58ac786d41"
PLAN, PLAN_SHA = RAW / "local-plan16-ready1-command-stage-264/local-plan.json", "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
HOST = COMPILER / "validation/host-validation.json"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def bind_absolute(audit, ledger, runtime=False):
    for name, expected in ledger.items():
        path = Path(name); require(path.is_absolute(), "flat original pathname is not absolute")
        audit.bind(path, expected, execution=runtime or not path.resolve().is_relative_to(ROOT))


def bind_proof(audit, proof):
    for name, expected in proof["artifact_sha256"].items():
        path = Path(name); require(not path.is_absolute() and ".." not in path.parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    bind_absolute(audit, proof["execution_file_sha256"], True)


def closed_record(native, record, profile, path, expected, execution_key):
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
        record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == expected and
        record["execution"] == profile[execution_key] and record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "record is not its closed exact profile/input-union/runtime")


def order_frame(value):
    if isinstance(value, dict): return [(key, order_frame(item)) for key, item in value.items()]
    if isinstance(value, list): return [order_frame(item) for item in value]
    return None


def prove_module(native, selected, before, after, manifest):
    require(set(before) == set(after) == {"creator", "modules"} and set(before["modules"]) == set(after["modules"]) == {"top"} and
        type(before["creator"]) is type(after["creator"]) is str, "complete document shape or creator type differs")
    a, b = before["modules"]["top"], after["modules"]["top"]
    require(len(a["cells"]) == len(b["cells"]) == 14907 and len(a["netnames"]) == len(b["netnames"]) == 16645 and
        native.canonical(before["modules"]) == native.canonical(after["modules"]), "complete native module/metadata/cells/nets/raw IDs differ")
    require(order_frame(before) == order_frame(after) and native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
        "document/module/owner/port/nested metadata order or paired PLL entries differ")
    require(selected.native_tables(a) == selected.native_tables(b), "complete raw driver/user slot tables differ")
    ffs = [{name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"} for top in (a, b)]
    require(len(manifest) == 8221 and ffs[0] == ffs[1] == manifest, "all8221 original FF names/BELs differ")
    return {"complete_native_module_exact": True, "complete_native_document_order_exact": True, "lossless_paired_pll_entries_exact": True,
        "native_driver_and_user_slot_tables_exact": True, "all_original_ff_records_and_bels_exact": True, "original_ff_count": 8221,
        "cells": 14907, "netnames": 16645, "creator_strings_exact": before["creator"] == after["creator"],
        "only_creator_provenance_difference_permitted": True, "native_field_waiver_or_raw_id_alignment_used": False,
        "unexported_physical_state_proved": False}


def diagnostic(error):
    return {"exception_type": type(error).__name__, "reason": str(error)}


def compare(self_sha, scope_sha, profile_sha, run_sha, runner_sha, runner_scope_sha):
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in
        (PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA, self_sha, scope_sha)) and
        (profile_sha, run_sha, runner_sha, runner_scope_sha) == (PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA), "actual completed diagnostic pins remain UNFROZEN or differ")
    native = load(NATIVE, NATIVE_SHA, "pair_diagnostic_native_pure"); audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha), (PROFILE, profile_sha), (RUN, run_sha),
        (RUNNER, runner_sha), (HERE / "scope.md", runner_scope_sha), (OLD / "source-identity.json", OLD_PROFILE_SHA),
        (OLD / "listing/run.json", OLD_RUN_SHA), (OLD / "listing/comparison-listing.json", OLD_PROOF_SHA), (OLD / "run_listing.py", OLD_HELPER_SHA),
        (OLD / "scope.md", OLD_SCOPE_SHA), (OLD / "compare_listing.py", OLD_COMPARER_SHA), (OLD / "comparison-scope.md", OLD_COMPARISON_SCOPE_SHA),
        (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA), (CONTROL / "baseline/run.json", CONTROL_RUN_SHA),
        (CONTROL / "baseline/comparison-control.json", CONTROL_PROOF_SHA), (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA),
        (CONTROL / "scope.md", CONTROL_SCOPE_SHA), (CONTROL / "compare_control.py", CONTROL_COMPARER_SHA), (CONTROL / "comparison-scope.md", CONTROL_COMPARISON_SCOPE_SHA),
        (HOST, HOST_SHA), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (COMPILER / "nextpnr-mistral", BINARY_SHA), (COMPILER / "source.tar.gz", ARCHIVE_SHA), (GUIDE, GUIDE_SHA), (PLAN, PLAN_SHA),
        (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    runner = load(RUNNER, runner_sha, "pair_diagnostic_recorder_pure")
    profile, record, old_profile, old, old_proof, control_profile, control_record, control_proof, host = (native.read(path) for path in
        (PROFILE, RUN, OLD / "source-identity.json", OLD / "listing/run.json", OLD / "listing/comparison-listing.json",
         CONTROL / "source-identity.json", CONTROL / "baseline/run.json", CONTROL / "baseline/comparison-control.json", HOST))
    for entry, prepared, path, expected, key in ((record, profile, PROFILE, profile_sha, "diagnostic_execution"),
        (old, old_profile, OLD / "source-identity.json", OLD_PROFILE_SHA, "listing_execution"),
        (control_record, control_profile, CONTROL / "source-identity.json", CONTROL_PROFILE_SHA, "baseline_execution")):
        closed_record(native, entry, prepared, path, expected, key)
    require((runner.COMMIT, runner.BASE, runner.BINARY_SHA, runner.ARCHIVE_SHA, runner.HOST_SHA, runner.TEST_SHA, runner.CHECKS_SHA,
        runner.HOST_HELPER_SHA, runner.HOST_SCOPE_SHA) == (COMMIT, BASE, BINARY_SHA, ARCHIVE_SHA, HOST_SHA, TEST_SHA, CHECKS_SHA, HOST_HELPER_SHA, HOST_SCOPE_SHA) and
        (runner.OLD_PROFILE_SHA, runner.OLD_RUN_SHA, runner.OLD_PROOF_SHA, runner.OLD_HELPER_SHA, runner.OLD_SCOPE_SHA,
         runner.CONTROL_PROFILE_SHA, runner.CONTROL_RUN_SHA, runner.CONTROL_PROOF_SHA, runner.CONTROL_HELPER_SHA, runner.CONTROL_SCOPE_SHA) ==
        (OLD_PROFILE_SHA, OLD_RUN_SHA, OLD_PROOF_SHA, OLD_HELPER_SHA, OLD_SCOPE_SHA, CONTROL_PROFILE_SHA, CONTROL_RUN_SHA, CONTROL_PROOF_SHA, CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA),
        "called diagnostic recorder compiler/prerequisite identities differ")
    require(old_proof["schema"] == control_proof["schema"] == 1 and old_proof["phase"] == "lut-pair-ready0-listing-native-reproduction" and
        old_proof["source_identity_sha256"] == OLD_PROFILE_SHA and old_proof["current_listing_run_sha256"] == OLD_RUN_SHA and
        old_proof["generator_sha256"] == OLD_COMPARER_SHA and old_proof["scope_sha256"] == OLD_COMPARISON_SCOPE_SHA and
        old_proof["recorder_sha256"] == OLD_HELPER_SHA and old_proof["recorder_scope_sha256"] == OLD_SCOPE_SHA and
        old_proof["compiler_commit"] == BASE and old_proof["control_proof_sha256"] == CONTROL_PROOF_SHA and
        old_proof["control_profile_sha256"] == CONTROL_PROFILE_SHA and old_proof["control_run_sha256"] == CONTROL_RUN_SHA and
        old_proof["current_actual_execution"] == old["execution"] and old_proof["structural_rejection"] is old_proof["model_or_listing_rejection"] is old_proof["native_path_topology_rejection"] is None and
        all(old_proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
            "all_71_placement_metrics_exact", "complete_predicted_report_exact", "recorded_reproduction_diagnostics_exact", "fresh_lut_pair_listing_reproduction_proved",
            "final_original_path_metadata_and_runtime_hashes_stable")), "old5a listing prerequisite is not positive")
    require(control_proof["phase"] == "lut-pair-disabled-ten-stage-native-control" and control_proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and
        control_proof["current_baseline_run_sha256"] == CONTROL_RUN_SHA and control_proof["generator_sha256"] == CONTROL_COMPARER_SHA and
        control_proof["scope_sha256"] == CONTROL_COMPARISON_SCOPE_SHA and control_proof["recorder_sha256"] == CONTROL_HELPER_SHA and control_proof["recorder_scope_sha256"] == CONTROL_SCOPE_SHA and
        control_proof["compiler_commit"] == BASE and control_proof["current_actual_execution"] == control_record["execution"] and
        control_proof["structural_rejection"] is control_proof["native_path_topology_rejection"] is None and
        all(control_proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact",
            "complete_predicted_report_exact", "fresh_lut_pair_control_prerequisite_proved", "final_original_path_metadata_and_runtime_hashes_stable")) and
        all(control_proof[key] == {"d7e_original_ten": True, "b3d_disabled_post_ten": True} for key in
            ("ten_model_equality_by_reference", "placement_metric_equality_by_reference", "complete_report_equality_by_reference")), "old5a dual-reference control prerequisite differs")
    counts = {"pair_backend": 12, "native_plan": 25, "driver_backend": 10, "pair_cli": 11, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and host["check_results_sha256"] == CHECKS_SHA and
        host["clean_committed_checkout"] is host["build_passed"] is True and host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and
        set(host["changed_source_files"]) == {"mistral/lut_pair_placement.cc"} and set(host["checks"]) == set(counts) and
        all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and all(host[key] for key in HOST_MAPS) and
        host["committed_archive_manifest_sha256"] and all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in host["committed_archive_manifest_sha256"]),
        "new independent diagnostic source/archive/dependency/47-native45-CLI qualification differs")
    for proof in (old_proof, control_proof): bind_proof(audit, proof)
    for entry in (profile, old_profile, control_profile, record, old, control_record): bind_absolute(audit, entry["input_sha256"])
    for entry, folder in ((record, RUN.parent), (old, OLD / "listing"), (control_record, CONTROL / "baseline")):
        require(set(entry["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")}, "closed output triplet differs")
        bind_absolute(audit, entry["output_sha256"]); bind_absolute(audit, entry["execution"]["files"], True)
    for key in HOST_MAPS: bind_absolute(audit, host[key])
    require(profile["schema"] == 1 and profile["phase"] == "lut-pair-ready0-endpoint-diagnostic-predicted-listing" and
        profile["command"] == runner.command(old) and profile["diagnostic_execution"] == record["execution"] == runner.expected_execution(old) and
        profile["cwd"] == old["cwd"] == control_record["cwd"] == str(ROOT / "sources/misteross") and
        profile["diagnostic_environment"] == old["diagnostic_environment"] == control_record["diagnostic_environment"] and
        all(profile[key] == expected for key, expected in (("compiler_commit", COMMIT), ("delta_base_commit", BASE), ("binary_sha256", BINARY_SHA),
            ("source_archive_sha256", ARCHIVE_SHA), ("host_validation_sha256", HOST_SHA), ("helper_sha256", runner_sha), ("scope_sha256", runner_scope_sha),
            ("previous_listing_profile_sha256", OLD_PROFILE_SHA), ("previous_listing_run_sha256", OLD_RUN_SHA), ("previous_listing_proof_sha256", OLD_PROOF_SHA),
            ("previous_listing_recorder_sha256", OLD_HELPER_SHA), ("previous_listing_recorder_scope_sha256", OLD_SCOPE_SHA),
            ("control_profile_sha256", CONTROL_PROFILE_SHA), ("control_run_sha256", CONTROL_RUN_SHA), ("control_proof_sha256", CONTROL_PROOF_SHA))) and
        old["compiler_commit"] == control_record["compiler_commit"] == BASE and old["execution"] == control_record["execution"] and
        profile["pair_candidate_selection"] == -1 and all(profile[key] is False for key in
            ("post_plan_requested", "driver_pass_executed", "native_or_physical_reproduction_inherited", "routed_gain_accepted", "hardware_tested")),
        "actual diagnostic command/profile/source/runtime roles differ")
    listing, control, definitions = runner.listing_definitions()
    require(listing.COMMIT == control.COMMIT == BASE and listing.CONTROL_PROFILE_SHA == CONTROL_PROFILE_SHA and listing.CONTROL_RUN_SHA == CONTROL_RUN_SHA and
        listing.CONTROL_PROOF_SHA == CONTROL_PROOF_SHA and listing.CONTROL_HELPER_SHA == CONTROL_HELPER_SHA, "called old pure parser identity differs")
    pure = ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (RUNNER, runner_sha),
        (OLD / "run_listing.py", OLD_HELPER_SHA), (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA), *control.PARSERS)
    for path, expected in pure:
        audit.bind(path, expected)
        if path not in (NATIVE, SELECTED, FREEZE): require(profile["input_sha256"].get(str(path)) == expected, "called parser lies outside diagnostic input closure")
    for name, expected in runner.SCRIPTS.items():
        path = ROOT / "sources/misteross/scripts" / name; audit.bind(path, expected)
        require(profile["input_sha256"].get(str(path)) == expected, "executed project module lies outside frozen input closure")
    require(all(audit.paths.get(Path(path)) == expected for path, expected in profile["input_sha256"].items()) and
        audit.paths.get(runner.BINARY) == BINARY_SHA and audit.paths.get(runner.ARCHIVE) == ARCHIVE_SHA, "current source/runtime/artifact closure incomplete")
    plan, guide = native.read(PLAN), native.read(GUIDE)
    require(profile["original_plan_path"] == old["original_plan_path"] == control_record["original_plan_path"] == str(PLAN) and
        profile["original_plan_sha256"] == old["original_plan_sha256"] == control_record["original_plan_sha256"] == PLAN_SHA and set(plan) == {"steps"} and
        plan["steps"] == profile["local_plan_steps"] == old["local_plan_steps"] == control_record["local_plan_steps"] and len(plan["steps"]) == 10 and
        [step["groups"] for step in plan["steps"]] == [8] + [1] * 9 and all(set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and
            step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True and Path(step["report"]) in audit.paths for step in plan["steps"]) and
        profile["retained_copy_cohorts"] == old["retained_copy_cohorts"] == control_record["retained_copy_cohorts"] and
        profile["all_original_ff_bel_manifest"] == old["all_original_ff_bel_manifest"] == control_record["all_original_ff_bel_manifest"] and
        profile["guide_path"] == old["guide_path"] == str(GUIDE) and profile["guide_sha256"] == old["guide_sha256"] == GUIDE_SHA and
        native.canonical(guide) == native.canonical({"critical_paths": [profile["exact_current_path_object"]]}) and
        native.canonical(profile["exact_current_path_object"]) == native.canonical(old["exact_current_path_object"]), "literal plan/cohorts/FFs or unchanged current guide differs")
    logs = {"old_listing": (OLD / "listing/phase.log").read_text(), "disabled_control": (CONTROL / "baseline/phase.log").read_text()}
    log = (RUN.parent / "phase.log").read_text()
    old_models, old_pair = listing.qualification(logs["old_listing"], control, definitions)
    control_models = control.qualification(logs["disabled_control"], definitions)
    require(native.canonical(old_models) == native.canonical(old["actual_selected_local_qualification"]) == native.canonical(old_proof["fresh_local_models"]) ==
        native.canonical(control_models) == native.canonical(control_record["actual_selected_local_qualification"]) == native.canonical(control_proof["fresh_local_models"]) ==
        native.canonical(profile["retained_local_models"]) and len(old_models) == 10 and
        native.canonical(old_pair) == native.canonical(old["actual_pair_listing"]) == native.canonical(old_proof["actual_pair_listing"]) == native.canonical(profile["retained_pair_listing"]) and
        old_pair["discovered_bounded_pairs"] == 1 and old_pair["actual_trial_count"] == 16 and old_pair["candidate_applied"] is False, "closed reference models/one-cone16-trial core differ")
    models, pair, diagnostics, model_rejection = None, None, None, None
    try:
        models, pair, diagnostics = runner.qualification(log, listing, control, definitions)
        require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and native.canonical(pair) == native.canonical(record["actual_pair_listing"]) and
            native.canonical(diagnostics) == native.canonical(record["actual_endpoint_diagnostics"]), "fresh recorded models/pair/endpoint diagnostic bindings differ")
    except (ValueError, TypeError, KeyError, IndexError) as error: model_rejection = diagnostic(error)
    models_by_reference = {name: model_rejection is None and native.canonical(models) == native.canonical(reference)
        for name, reference in (("old_listing", old_models), ("disabled_control", control_models))}
    pair_exact = model_rejection is None and native.canonical(pair) == native.canonical(old_pair)
    metrics = native.PLACEMENT_METRICS.findall(log); reference_metrics = {name: native.PLACEMENT_METRICS.findall(text) for name, text in logs.items()}
    metrics_by_reference = {name: len(metrics) == len(rows) == 71 and metrics == rows for name, rows in reference_metrics.items()}
    report = native.read(RUN.parent / "timing.json")
    reports = {"old_listing": native.read(OLD / "listing/timing.json"), "disabled_control": native.read(CONTROL / "baseline/timing.json")}
    reports_by_reference = {name: native.canonical(report) == native.canonical(data) for name, data in reports.items()}
    models_exact, metrics_exact, report_exact = all(models_by_reference.values()), all(metrics_by_reference.values()), all(reports_by_reference.values())
    recorded_exact = (record["all_ten_complete_trial_models_exact"] is models_by_reference["old_listing"] and
        record["all_original_pair_discovery_domain_trial_candidate_lines_exact"] is pair_exact and
        record["all_71_placement_metrics_exact"] is metrics_by_reference["old_listing"] and
        record["complete_predicted_report_exact_diagnostic"] is reports_by_reference["old_listing"])
    frozen = load(FREEZE, FREEZE_SHA, "pair_diagnostic_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "pair_diagnostic_selected_pure", frozen)
    document = native.read_netlist(RUN.parent / "placed.json")
    documents = {"old_listing": native.read_netlist(OLD / "listing/placed.json"), "disabled_control": native.read_netlist(CONTROL / "baseline/placed.json")}
    evidence, rejections, topology, topology_rejections = {}, {}, {}, {}
    for name, before in documents.items():
        try: evidence[name] = prove_module(native, selected, before, document, profile["all_original_ff_bel_manifest"])
        except (ValueError, TypeError, KeyError, IndexError) as error: rejections[name] = diagnostic(error)
    for name, doc, data in [(key, documents[key], reports[key]) for key in documents] + [("fresh_endpoint_diagnostic", document, report)]:
        try:
            topology[name] = selected.report_topology(doc, data, reports["disabled_control"])
            require(topology[name]["current_report_paths"] == 15290 and len(topology[name]["domain_pair_endpoint_counts"]) == 7, "complete native path count/clock-pair set differs")
        except (ValueError, TypeError, KeyError, IndexError) as error: topology_rejections[name] = diagnostic(error)
    require(report["timing_report_paths"] == reports["old_listing"]["timing_report_paths"] == reports["disabled_control"]["timing_report_paths"] == 16384 and
        len(report["critical_paths"]) == 15290 and record["actual_predicted_fmax"] == report["fmax"] and "Info: Program finished normally." in log and
        not any(line.startswith("ERROR:") for line in log.splitlines()) and log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
        not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step", "LUT pair placement applied candidate")) and
        not any((RUN.parent / name).exists() for name in ("core.rbf", "routed.json")), "actual diagnostic listing is not final predicted-only completion")
    audit.finish()
    positive = not rejections and model_rejection is None and not topology_rejections and models_exact and pair_exact and metrics_exact and report_exact and recorded_exact and pair["candidate_applied"] is False
    return {"schema": 1, "phase": "lut-pair-ready0-endpoint-diagnostic-native-reproduction", "source_identity_sha256": profile_sha,
        "current_diagnostic_run_sha256": run_sha, "previous_listing_profile_sha256": OLD_PROFILE_SHA, "previous_listing_run_sha256": OLD_RUN_SHA,
        "previous_listing_proof_sha256": OLD_PROOF_SHA, "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": CONTROL_RUN_SHA, "control_proof_sha256": CONTROL_PROOF_SHA,
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "generator_sha256": self_sha, "scope_sha256": scope_sha, "recorder_sha256": runner_sha,
        "recorder_scope_sha256": runner_scope_sha, "host_validation_sha256": HOST_SHA, "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "current_actual_execution": record["execution"], "creator_strings": {**{key: doc["creator"] for key, doc in documents.items()}, "fresh_endpoint_diagnostic": document["creator"]},
        "only_creator_provenance_difference_permitted": True, "creator_difference_observed": any(doc["creator"] != document["creator"] for doc in documents.values()),
        "reference_local_models": {"old_listing": old_models, "disabled_control": control_models}, "fresh_local_models": models, "actual_pair_listing": pair,
        "actual_endpoint_diagnostics": diagnostics, "model_or_diagnostic_rejection": model_rejection, "original_pair_listing_core_exact": pair_exact,
        "all_ten_complete_trial_models_exact": models_exact, "ten_model_equality_by_reference": models_by_reference,
        "all_71_placement_metrics_exact": metrics_exact, "placement_metric_equality_by_reference": metrics_by_reference,
        "placement_metric_rows": metrics, "reference_placement_metric_rows": reference_metrics, "recorded_reproduction_diagnostics_exact": recorded_exact,
        "structural_rejection": rejections or None, "native_graph_proof_available": not rejections, "native_graph_evidence": evidence,
        "current_predicted_native_paths": topology, "native_path_topology_rejection": topology_rejections or None,
        "complete_predicted_report_exact": report_exact, "complete_report_equality_by_reference": reports_by_reference, "actual_predicted_fmax": report["fmax"],
        "fresh_lut_pair_endpoint_diagnostic_reproduction_proved": positive, "raw_id_alignment_or_native_module_field_waiver_used": False,
        "selected_candidate_accepted": False, "independent_physical_equivalence_proved": False, "independent_numerical_sta_proved": False,
        "routed_gain_accepted": False, "hardware_tested": False, "pure_function_helper_sha256": {str(path): expected for path, expected in pure},
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())), "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "run-sha256", "runner-sha256", "runner-scope-sha256"): parser.add_argument("--" + name, required=True)
    args = parser.parse_args(); require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual SHA activation pins required")
    output = HERE / "diagnostic/comparison-diagnostic.json"; require(not output.exists(), "immutable diagnostic comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.profile_sha256, args.run_sha256, args.runner_sha256, args.runner_scope_sha256)
    with output.open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "fresh_lut_pair_endpoint_diagnostic_reproduction_proved": result["fresh_lut_pair_endpoint_diagnostic_reproduction_proved"]}, indent=2))


if __name__ == "__main__": main()
