# Disabled post-plan ten-stage compiler control

ROOT alone activates this comparison after whole-file, hash, AST and independent
peer review. Actual self/scope, prepared profile, closed run and reviewed recorder
and recorder-scope SHA arguments are mandatory. It exclusively writes
baseline/comparison-control.json. It does not invoke compilers, tests, routing,
source-clean Git queries, previous validators, authenticators or old entrypoints.

The new source b3d03654 is based on d7e5c61f and is independently bound to current
host3751b2eb, production ELF0c880559 and archive338f71f6. Current host qualification
does not inherit the previous compiler's checks. Historical external dependencies
remain byte evidence, without authenticating a loaded historical build toolchain.
The new actual invocation must equal the reviewed command/runtime definitions:
only production ELF/path, controlled PATH directory and fresh output aliases
change. The literal ten-stage plan00bf and all reports, seed, constraints,
diagnostic environment, device/model and every other runtime input stay exact.
The optional post plan is absent from this control and from its phase log.

The closed previous ten-stage run3d69/profile77fd/positive logical prefixbf9d is
the structural reference. Its flat closure, all current host/dependency/source
maps, profile/input union, outputs and actual runtime paths are rehashed without
replaying parent proofs. The previous owner-alignment proof is provenance only:
this comparison permits no private-output alignment between the two images.
Current ten-stage full timing116.809 is a rejected experiment and contributes no
gain acceptance. The accepted fifth6dc/117.771759 MHz reference remains separate.

Only pinned32fd lossless parsing/Audit/canonical,72131 native tables/report
topology,8601's local import hook, and the new recorder's reviewed pure command,
runtime, host-shape and log-qualification definitions are called. Pinned prior
qualification definitions may be loaded through its allowlisted loader; their
prepare/execute/authentication/comparison/main functions are never called.

All ten complete guarded local models and all71 placement metric rows must match.
The full14907-cell/16645-net native top module must match, including every raw
alias, connection, parameter, attribute, exported pin/LAB state, public port and
setting. Original owner and port ordering, both lossless ordered PLL occurrences,
complete rebuilt raw driver/user tables, and all8221 original FF names/BELs stay
exact. Document creator strings are recorded separately as compiler diagnostics;
no field of the top module is waived. There is no numeric normalization, buffer
collapse, Boolean substitution, pin exception or placement tolerance. Hidden
pin/LAB caches and absent physical snapshots are not independently proved.

The full current15290-path/seven-pair predicted report is validated against its
own lossless native image and the previous predicted endpoint/window set. The
entire JSON report must also match the previous report, including all segments,
clock terms, actual max-delay windows, Fmax and detailed net timing rows. The
explicit cap remains16384. Structural and topology rejections are saved separately,
with actual report diagnostics and final original-path hashes. The single
fresh_post_plan_control_prerequisite_proved flag requires native/model/metric,
topology and complete-report equality together; a completed compiler run alone
does not qualify a late remap.

This proves reproduction of exported predicted data under the current compiler.
It does not independently recompute numerical STA, prove physical equivalence,
qualify a future candidate, prove routed gain or authorize hardware acceptance.
