"""Prove a closed disabled-post-plan ten-stage control reproduces the prior image."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE, RUN, RUNNER = HERE / "source-identity.json", HERE / "baseline/run.json", HERE / "run_baseline.py"
OLD_FOLDER = RAW / "local-plan16-ready1-command-stage-264"
OLD, OLD_PROFILE, OLD_PREFIX = OLD_FOLDER / "baseline/run.json", OLD_FOLDER / "source-identity.json", OLD_FOLDER / "baseline/comparison-prefix-v2.json"
OLD_SHA = "3d69a28a7fb1741349f1b4e77be6f13bbdae21dfeb4bacd77ef5f5862059ad11"
OLD_PROFILE_SHA = "77fd5636a7947d349605147bc164ba7cf562dc5885aa09072a1cc2945931e546"
OLD_PREFIX_SHA = "bf9d312c140f349f75244c087be5a90f59c6fb6a87d28437051936f178884fe3"
OLD_PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
COMMIT, BASE = "b3d036549c29a333e67c61bd1b23e705bce75d41", "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
HOST = RAW / "post-remap-plan-264/validation/host-validation.json"
HOST_SHA = "3751b2ebc0c0f802ac2b4251150a693764487939c0b08e42fe100c2047eb6fe0"
BINARY_SHA = "0c8805598c4e59ad77683956cdc1739b8d2ed183c73eab51c85c9b7a52ea18ad"
ARCHIVE_SHA = "338f71f67188fa29dbb9f6fa616f6d33f4bc926b3acd00bfb5122ef543a8c2fb"
OLD_BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
OLD_ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
             "build_dependency_manifest_sha256", "build_dependency_file_sha256")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def prove_module(native, selected, before, after, manifest):
    require(set(before) == set(after) == {"creator", "modules"} and set(before["modules"]) == set(after["modules"]) == {"top"},
            "complete native document shape differs")
    a, b = before["modules"]["top"], after["modules"]["top"]
    require(len(a["cells"]) == len(b["cells"]) == 14907 and len(a["netnames"]) == len(b["netnames"]) == 16645 and
            native.canonical(a) == native.canonical(b), "complete native module metadata/cells/nets/raw IDs differ")
    require(list(a) == list(b) and list(a["cells"]) == list(b["cells"]) and list(a["netnames"]) == list(b["netnames"]) and
            list(a["ports"]) == list(b["ports"]) and native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "native module/owner/public-port order or lossless paired PLL entries differ")
    for name, cell in a["cells"].items():
        other = b["cells"][name]
        require(list(cell["connections"]) == list(other["connections"]) and list(cell["port_directions"]) == list(other["port_directions"]),
                "original cell port/direction order differs: " + name)
    require(selected.native_tables(a) == selected.native_tables(b), "complete raw driver/user slot tables differ")
    old_ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_FF"}
    new_ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in b["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(manifest) == 8221 and old_ffs == new_ffs == manifest, "all8221 original FF names/BELs differ")
    return {"complete_native_module_exact": True, "original_owner_and_port_order_exact": True,
            "lossless_paired_pll_entries_exact": True, "native_driver_and_user_slot_tables_exact": True,
            "all_original_ff_bels_exact": True, "original_ff_count": 8221, "cells": 14907, "netnames": 16645,
            "raw_id_translation_or_native_field_waiver_used": False, "unexported_pins_lab_caches_or_physical_state_proved": False}


def compare(self_sha, scope_sha, profile_sha, run_sha, runner_sha, runner_scope_sha):
    native = load(NATIVE, NATIVE_SHA, "post_plan_ten_native_pure")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha), (PROFILE, profile_sha),
            (RUN, run_sha), (RUNNER, runner_sha), (HERE / "scope.md", runner_scope_sha), (HOST, HOST_SHA),
            (OLD, OLD_SHA), (OLD_PROFILE, OLD_PROFILE_SHA), (OLD_PREFIX, OLD_PREFIX_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    runner = load(RUNNER, runner_sha, "post_plan_ten_runner_pure")
    for path, expected in runner.PARSERS:
        audit.bind(path, expected)
    profile, record, old, old_profile, prefix, host = (native.read(path) for path in (PROFILE, RUN, OLD, OLD_PROFILE, OLD_PREFIX, HOST))
    runner.validate_host(host)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == profile_sha and
            all(record[key] == value for key, value in profile.items() if key != "input_sha256") and
            record["input_sha256"] == {**profile["input_sha256"], str(PROFILE): profile_sha} and
            not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel", "partial_outputs_only")),
            "current baseline is not its closed exact profile/input-union record")
    require(profile["phase"] == "post-remap-plan-disabled-ten-stage-predicted-control" and profile["command"] == runner.command(old) and
            record["execution"] == profile["baseline_execution"] == runner.expected_execution(old) and
            profile["diagnostic_environment"] == old["diagnostic_environment"] and profile["cwd"] == old["cwd"] == str(ROOT / "sources/misteross") and
            profile["compiler_commit"] == host["compiler_commit"] == COMMIT and profile["delta_base_commit"] == host["delta_base_commit"] == BASE and
            profile["binary_sha256"] == host["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == host["source_archive_sha256"] == ARCHIVE_SHA and
            profile["helper_sha256"] == runner_sha and profile["scope_sha256"] == runner_scope_sha and profile["host_validation_sha256"] == HOST_SHA and
            profile["committed_archive_member_sha256"] == host["committed_archive_manifest_sha256"] and
            "--remap-post-plan" not in profile["command"], "new compiler/host/archive/runtime/disabled-post role differs")
    for ledger in (profile["input_sha256"], old["input_sha256"], old["output_sha256"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "host/control flat entry is not absolute")
            audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    for runtime in (old["execution"], record["execution"]):
        for path, expected in runtime["files"].items():
            audit.bind(Path(path), expected, execution=True)
    for path, expected in prefix["artifact_sha256"].items():
        require(not Path(path).is_absolute() and ".." not in Path(path).parts, "old flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    for path, expected in prefix["execution_file_sha256"].items():
        audit.bind(Path(path), expected, execution=True)
    require(old["completed"] is True and old["exit_code"] == 0 and old["compiler_read_audit_passed"] is True and
            old["final_original_input_output_runtime_hashes_stable"] is True and old["source_identity_sha256"] == OLD_PROFILE_SHA and
            old["compiler_commit"] == BASE and old["binary_sha256"] == OLD_BINARY_SHA and old["source_archive_sha256"] == OLD_ARCHIVE_SHA and
            prefix["candidate_completed"] is True and prefix["native_graph_proof_available"] is True and prefix["structural_rejection"] is None and
            prefix["native_path_topology_rejection"] is None and prefix["final_original_path_metadata_and_runtime_hashes_stable"] is True and
            prefix["current_baseline_run_sha256"] == OLD_SHA and prefix["source_identity_sha256"] == OLD_PROFILE_SHA and
            profile["previous_source_identity_sha256"] == OLD_PROFILE_SHA and profile["previous_baseline_run_sha256"] == OLD_SHA and
            profile["previous_prefix_proof_sha256"] == OLD_PREFIX_SHA and
            profile["current_host_case_counts"] == {key: row["cases"] for key, row in host["checks"].items()},
            "closed previous ten-stage construction or current host role differs")
    plan_path = OLD_FOLDER / "local-plan.json"
    require(profile["original_plan_path"] == str(plan_path) and audit.paths.get(plan_path) == profile["original_plan_sha256"] == OLD_PLAN_SHA and
            native.read(plan_path)["steps"] == profile["local_plan_steps"] == old_profile["local_plan_steps"] and len(profile["local_plan_steps"]) == 10 and
            [step["groups"] for step in profile["local_plan_steps"]] == [8] + [1] * 9 and
            all(step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True for step in profile["local_plan_steps"]),
            "literal original ten-stage plan changed")
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")}, "predicted output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "empty current predicted output")
        audit.bind(Path(path), expected)
    definitions = runner.definitions()
    old_log, log = (OLD.parent / "phase.log").read_text(), (HERE / "baseline/phase.log").read_text()
    old_models, models = runner.qualification(old_log, definitions), runner.qualification(log, definitions)
    require(native.canonical(old_models) == native.canonical(old["actual_selected_local_qualification"]) == native.canonical(profile["retained_local_models"]) and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]), "actual complete trial bindings differ")
    models_exact = native.canonical(models) == native.canonical(old_models)
    require(record["all_ten_complete_trial_models_exact"] is models_exact, "recorded complete-model diagnostic differs")
    metrics = len(native.PLACEMENT_METRICS.findall(log)) == 71 and native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(old_log)
    frozen = load(FREEZE, FREEZE_SHA, "post_plan_ten_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "post_plan_ten_selected_pure", frozen)
    before, after = native.read_netlist(OLD.parent / "placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    evidence, rejection = None, None
    try:
        require(models_exact and metrics, "ten complete trial models or71 placement metrics differ")
        require(profile["all_original_ff_bel_manifest"] == old["all_original_ff_bel_manifest"], "original FF manifest changed")
        evidence = prove_module(native, selected, before, after, profile["all_original_ff_bel_manifest"])
    except (ValueError, TypeError, KeyError, IndexError) as error:
        rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(OLD.parent / "timing.json")
    topology, topology_rejection = None, None
    try:
        topology = selected.report_topology(after, report, old_report)
        require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7, "predicted native topology count/pairs differ")
    except (ValueError, TypeError, KeyError, IndexError) as error:
        topology_rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    report_exact = native.canonical(report) == native.canonical(old_report)
    require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and record["actual_predicted_fmax"] == report["fmax"] and
            "Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step")),
            "predicted report or disabled-post phase role differs")
    audit.finish()
    prerequisite = rejection is None and topology_rejection is None and report_exact
    return {"schema": 1, "phase": "post-remap-plan-disabled-ten-stage-native-control", "source_identity_sha256": profile_sha,
        "current_baseline_run_sha256": run_sha, "previous_source_identity_sha256": OLD_PROFILE_SHA, "previous_baseline_run_sha256": OLD_SHA,
        "previous_prefix_proof_sha256": OLD_PREFIX_SHA, "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "generator_sha256": self_sha, "scope_sha256": scope_sha, "recorder_sha256": runner_sha, "recorder_scope_sha256": runner_scope_sha,
        "host_validation_sha256": HOST_SHA, "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "current_actual_execution": record["execution"], "authorized_runtime_delta": profile["authorized_runtime_delta"],
        "creator_strings": {"before": before["creator"], "after": after["creator"]}, "creator_strings_equal": before["creator"] == after["creator"],
        "old_local_models": old_models, "fresh_local_models": models, "all_ten_complete_trial_models_exact": models_exact,
        "all_71_placement_metrics_exact": metrics, "structural_rejection": rejection, "native_graph_proof_available": rejection is None,
        "native_graph_evidence": evidence, "current_predicted_native_paths": topology, "native_path_topology_rejection": topology_rejection,
        "complete_predicted_report_exact": report_exact, "actual_predicted_fmax": report["fmax"], "fresh_post_plan_control_prerequisite_proved": prerequisite,
        "raw_id_alignment_or_native_module_field_waiver_used": False, "independent_physical_equivalence_proved": False,
        "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "pure_function_helper_sha256": {str(path): expected for path, expected in ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (RUNNER, runner_sha), *runner.PARSERS)},
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "run-sha256", "runner-sha256", "runner-scope-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual SHA activation pins required")
    output = HERE / "baseline/comparison-control.json"
    require(not output.exists(), "immutable control comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.profile_sha256, args.run_sha256, args.runner_sha256, args.runner_scope_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "complete_predicted_report_exact": result["complete_predicted_report_exact"],
        "fresh_post_plan_control_prerequisite_proved": result["fresh_post_plan_control_prerequisite_proved"]}, indent=2))


if __name__ == "__main__":
    main()
