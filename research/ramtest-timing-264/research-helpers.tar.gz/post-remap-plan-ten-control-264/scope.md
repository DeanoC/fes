# Disabled-post ten-stage predicted control

ROOT alone reviews, prepares and executes this new recorder. The selected
compiler is committed b3d036549c29a333e67c61bd1b23e705bce75d41, based on d7e5,
with ELF 0c880559, source archive 338f71f6 and closed host 3751b2eb. Its current
25 local-plan native, 10 driver native, 24 plan CLI and 10 driver CLI cases
passed. Source, model, submodules and full build-dependency maps are bound;
no old compiler host qualification substitutes for the new host record.

The reference is the closed tenth predicted profile 77fd5636/run 3d69a28a and
positive bounded prefix bf9d312c. The exact original local-plan.json pathname
and bytes 00bf9b8c, all ten descriptors and every report pathname stay unchanged.
There is no --remap-post-plan option, post descriptor, driver-copy pass, route
or RBF. The requested command changes only the compiler executable and the
two write/report destinations. All fixed input/device/constraint/seed/placer
and diagnostic reduction/decomposition options remain literal reference values.

The reference profile, completed record, outputs, flat cached prefix artifact
and execution maps, and all new host maps are rehashed directly. Flat closure
preserves old numerical references and failed attempts as history; it does not
execute an old generator, authenticator, validator or state-check entrypoint.
No historical partial or rejected stage is selected by this command.

Eight pinned old modules are loaded for definitions only: tenth and ninth
qualification, the eight-stage control qualification, then the five lower
qualification parsers. Only their pure log qualification chain is called.
Old prepare/run/host_valid/clean-source/main functions are never called.
The five current FES runtime/read-audit project modules are independently bound
before import and their actual loaded paths/hashes checked afterwards.

Current FunctionalInvocation must reproduce the old runtime frame exactly
except the actual production ELF pathname/hash and its controlled PATH directory.
All other execution fields/files, selected GPU1 identity, libraries, tracer,
KFD/platform evidence and invocation environment remain unchanged. The old
compiler and source evidence remain in the historical input ledger. The new
compiler executes under the current committed FES read-audit mechanism, with
the exact inherited diagnostic environment and no ambient diagnostic overrides.
This predicted-only run does not invoke GPU routing or claim fresh GPU state.

Preparation uses explicit self/scope/ELF/archive/host SHA arguments and creates
only an exclusive new source-identity.json. It retains ten actual complete
trial dictionaries, the ten named copy cohorts and all 8,221 original FF BELs
as comparison inputs. It copies no old physical or Boolean acceptance into
the new compiler result. Runtime/profile/input hashes are rechecked before
and after preparation and before/after execution.

Execution requires the actual prepared profile hash and exclusive baseline
directory. Fresh normal completion, ten guarded qualifications, report cap
16,384/count 15,290, finite Fmax and all three outputs are recorded. Exact
ten-model equality is a separate diagnostic flag. A later independent control
comparator must prove complete typed graph/raw-ID/order/paired-PLL equality,
all placement metrics and the complete predicted report before this control
can qualify a post-plan experiment. Neither predicted Fmax nor completion is
new routed timing, independent STA, physical truth, RBF or hardware acceptance.
The accepted five-stage 117.771759 MHz route remains a separate gain reference.

Failures preserve the actual exit (or labelled adapter sentinel), elapsed
time, partial output hashes and completed=false in the exclusive new record.
No old output is overwritten. Future post-plan selection, clone identity/site,
truth, physical banks and routed timing require new actual evidence.
