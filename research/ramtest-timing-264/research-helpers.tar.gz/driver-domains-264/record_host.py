"""Record root-executed current domain checks; predecessor focused checks are not rerun."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TOOLCHAIN = ROOT / "sources/misteross/build/toolchain-ramtest-timing"
SOURCE = TOOLCHAIN / "src/nextpnr-driver-domains-264"
BUILD = TOOLCHAIN / "build/nextpnr-driver-domains-264"
BASE = "9dc3633aa0c5395df9a81be8437d1a746ba54b5d"
OLD_SOURCE = TOOLCHAIN / "src/nextpnr-driver-rejections-264"
PREDECESSOR = HERE.parent / "driver-rejections-264/validation/host-validation.json"
PREDECESSOR_SHA = "78c2fd212f6081f7dcd5cc0bda15df4da8d13b2f28b13333cf62928019f21d51"
FOCUSED = HERE.parent / "timing-paths-264/validation/host-validation.json"
FOCUSED_SHA = "d68ff437d71d0c74447d391a4b543ce22d3cad6686b7fe8d6ca15bf330594d64"
CHANGED = {"common/kernel/timing.h", "common/kernel/timing.cc", "mistral/lut_driver_copy.cc",
           "mistral/tests/lut_driver_copy.cc", "mistral/tests/timing_report_paths.cc"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args])


def names(text):
    return [fixture + "." + name for fixture, name in
            re.findall(r"(?m)^\s*TEST_F\s*\(\s*([A-Za-z_]\w*)\s*,\s*([A-Za-z_]\w*)\s*\)", text)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--generic-build", type=Path)
    parser.add_argument("--generic-configure-log", type=Path)
    parser.add_argument("--generic-build-log", type=Path)
    parser.add_argument("--generic-commit")
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.commit) and git("rev-parse", "HEAD").decode().strip() == args.commit and
            not git("status", "--porcelain").strip(), "current checkout is not the supplied clean commit")
    require(git("merge-base", BASE, args.commit).decode().strip() == BASE and
            set(git("diff", "--name-only", BASE, args.commit).decode().splitlines()) == CHANGED,
            "current source is not the reviewed five-file base delta")
    require(sha(PREDECESSOR) == PREDECESSOR_SHA and sha(FOCUSED) == FOCUSED_SHA, "closed host records changed")
    previous, focused = json.loads(PREDECESSOR.read_text()), json.loads(FOCUSED.read_text())
    require(previous["result_commit"] == BASE and previous["clean_committed_checkout"] is True and
            previous["build_passed"] is True and previous["hardware_tested"] is False,
            "predecessor host is not complete")
    closed = focused["checks"]["focused_backend"]
    require(focused["result_commit"] == "1cdef559c0e22a96bb0712f3ec348468b348f156" and
            closed["passed"] is True and closed["exit_code"] == 0 and closed["cases"] == 37,
            "older focused check is not the completed closed37 evidence")
    bound = {str(PREDECESSOR): PREDECESSOR_SHA, str(FOCUSED): FOCUSED_SHA}
    for document in (previous, focused):
        for path, expected in document["artifact_sha256"].items():
            require(sha(path) == expected, "closed predecessor artifact changed: " + path)
            bound[path] = expected
    sources, inherited = {}, {}
    for path, expected in previous["source_sha256"].items():
        old_path = Path(path)
        require(sha(old_path) == expected, "original predecessor source path changed")
        relative = str(old_path.relative_to(OLD_SOURCE))
        require(hashlib.sha256(git("show", BASE + ":" + relative)).hexdigest() == expected, "actual Git base bytes differ")
        now = SOURCE / relative
        sources[str(now)] = sha(now)
        require(hashlib.sha256(git("show", args.commit + ":" + relative)).hexdigest() == sources[str(now)],
                "live current source differs from supplied clean commit")
        if relative not in CHANGED:
            require(sources[str(now)] == expected, "unrelated inherited source changed")
            inherited[relative] = expected
        bound[str(old_path)] = expected
    require(len(sources) == 16 and len(inherited) == 11, "source manifest shape differs")
    validation = HERE / "validation"
    checks, case_names = {}, {}
    for key, source_name, log_name, minimum in (
            ("driver_backend", "lut_driver_copy.cc", "driver-backend.log", 8),
            ("timing_paths_backend", "timing_report_paths.cc", "timing-backend.log", 4)):
        declarations = names(git("show", args.commit + ":mistral/tests/" + source_name).decode())
        require(len(declarations) >= minimum and len(set(declarations)) == len(declarations), "native new backend coverage is absent")
        log = (validation / log_name).read_text()
        count = len(declarations)
        ran = re.findall(r"\[\s*RUN\s*\]\s+(\S+)", log)
        require(len(ran) == count and set(ran) == set(declarations) and
                "[  PASSED  ] %d tests." % count in log and "[  FAILED  ]" not in log and "[  SKIPPED ]" not in log,
                "actual backend log does not pass all committed native TEST_F cases")
        match = re.search(r"\[==========\] %d tests from .* ran\. \((\d+) ms total\)" % count, log)
        require(match is not None, "backend elapsed summary is absent")
        checks[key] = {"passed": True, "exit_code": 0, "cases": count, "elapsed_seconds": int(match[1]) / 1000}
        case_names[key] = declarations
    for key, log_name, count in (("driver_cli", "driver-cli.log", 10), ("timing_paths_cli", "timing-cli.log", 4)):
        log = (validation / log_name).read_text()
        match = re.search(r"Ran %d tests in ([\d.]+)s\s+OK\s*$" % count, log)
        require(match is not None and not re.search(r"FAIL|ERROR", log), "actual current CLI checks failed or count differs")
        checks[key] = {"passed": True, "exit_code": 0, "cases": count, "elapsed_seconds": float(match[1])}
    build = (validation / "build.log").read_text()
    require("Built target nextpnr-mistral" in build and "Built target nextpnr-mistral-test" in build and
            "error:" not in build and "fatal error:" not in build, "actual current build did not complete")
    cold_build = (validation / "build-cold.log").read_text()
    require("Built target nextpnr-mistral" in cold_build and "Built target nextpnr-mistral-test" in cold_build and
            "error:" not in cold_build and "fatal error:" not in cold_build, "preserved cold build did not complete")
    initial_driver = (validation / "driver-backend-initial.log").read_text()
    require("[  FAILED  ]" in initial_driver, "preserved initial fixture failure evidence is absent")
    pre_fixture = {}
    for line in (validation / "pre-fixture-rebuild-binaries.sha256").read_text().splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})\s+(/\S+)", line)
        require(match is not None and match[2] not in pre_fixture, "invalid preserved pre-fixture binary identity")
        pre_fixture[match[2]] = match[1]
    require(set(pre_fixture) == {str(BUILD / "nextpnr-mistral"), str(BUILD / "nextpnr-mistral-test")} and
            pre_fixture[str(BUILD / "nextpnr-mistral")] == sha(BUILD / "nextpnr-mistral") and
            pre_fixture[str(BUILD / "nextpnr-mistral-test")] != sha(BUILD / "nextpnr-mistral-test"),
            "test-only fixture rebuild changed CLI bytes or did not rebuild test bytes")
    artifacts = [validation / name for name in ("dependency-setup.log", "configure.log", "build-cold.log", "build.log",
                 "driver-backend-initial.log", "timing-backend-initial.log", "pre-fixture-rebuild-binaries.sha256",
                 "driver-backend.log", "timing-backend.log", "driver-cli.log", "timing-cli.log")]
    artifacts += [BUILD / "nextpnr-mistral", BUILD / "nextpnr-mistral-test", BUILD / "CMakeCache.txt", Path(__file__).resolve()]
    generic_args = (args.generic_build, args.generic_configure_log, args.generic_build_log, args.generic_commit)
    generic = None
    if any(path is not None for path in generic_args):
        require(all(value is not None for value in generic_args), "generic compile evidence requires all three actual paths and compiled commit")
        require(re.fullmatch(r"[0-9a-f]{40}", args.generic_commit) and
                git("merge-base", args.generic_commit, args.commit).decode().strip() == args.generic_commit,
                "generic compiled commit is not an actual ancestor of current source")
        production = {str(Path(path).relative_to(SOURCE)): expected for path, expected in sources.items()
                      if not str(Path(path).relative_to(SOURCE)).startswith("mistral/tests/") and
                      str(Path(path).relative_to(SOURCE)) != "mistral/CMakeLists.txt"}
        require(len(production) == 11 and all(hashlib.sha256(git("show", args.generic_commit + ":" + name)).hexdigest() == expected
                for name, expected in production.items()), "generic compiled production source differs from current result")
        generic_build = args.generic_build.absolute()
        require(generic_build.is_relative_to(TOOLCHAIN / "build"), "generic build escaped toolchain")
        generic_cache = generic_build / "CMakeCache.txt"
        cache_text = generic_cache.read_text()
        require("CMAKE_HOME_DIRECTORY:INTERNAL=" + str(SOURCE) + "\n" in cache_text and
                re.search(r"^ARCH:STRING=generic$", cache_text, re.M), "generic build source/ARCH differs")
        generic_log = args.generic_build_log.read_text()
        require("Built target nextpnr-generic" in generic_log and "error:" not in generic_log and
                "fatal error:" not in generic_log and "Configuring done" in args.generic_configure_log.read_text(),
                "actual generic ARCH configure/build did not pass")
        generic_binary = generic_build / "nextpnr-generic"
        require(generic_binary.is_file() and generic_binary.stat().st_size > 0, "actual generic compile binary is absent")
        artifacts += [generic_binary, generic_cache, args.generic_configure_log.absolute(), args.generic_build_log.absolute()]
        generic = {"compiled": True, "runtime_sta_tested": False, "source_commit": args.generic_commit,
            "current_result_commit": args.commit, "production_source_unchanged": True,
            "unchanged_production_source_sha256": production,
            "binary_path": str(generic_binary), "binary_sha256": sha(generic_binary),
            "cache_path": str(generic_cache), "cache_sha256": sha(generic_cache),
            "configure_log_path": str(args.generic_configure_log.absolute()),
            "configure_log_sha256": sha(args.generic_configure_log),
            "build_log_path": str(args.generic_build_log.absolute()), "build_log_sha256": sha(args.generic_build_log)}
    record = {"schema": 1, "result_commit": args.commit, "delta_base_commit": BASE,
        "clean_committed_checkout": True, "build_passed": True, "diagnostic_only": True,
        "hardware_tested": False, "new_timing_gain_claimed": False,
        "binary_sha256": sha(BUILD / "nextpnr-mistral"), "test_binary_sha256": sha(BUILD / "nextpnr-mistral-test"),
        "source_sha256": sources, "artifact_sha256": {str(path): sha(path) for path in artifacts}, "checks": checks,
        "native_backend_case_names": case_names,
        "predecessor_host_validation_path": str(PREDECESSOR), "predecessor_host_validation_sha256": PREDECESSOR_SHA,
        "focused_host_validation_path": str(FOCUSED), "focused_host_validation_sha256": FOCUSED_SHA,
        "focused_check_not_rerun": closed, "unchanged_inherited_source_sha256": inherited,
        "pre_fixture_rebuild_binary_sha256": pre_fixture, "cli_binary_unchanged_after_fixture_rebuild": True,
        "test_binary_changed_after_fixture_rebuild": True,
        "generic_arch_compile": generic,
        "cold_build_warning_count": cold_build.count("warning:")}
    require(git("rev-parse", "HEAD").decode().strip() == args.commit and not git("status", "--porcelain").strip(),
            "source changed while recording")
    for path, expected in {**bound, **sources, **record["artifact_sha256"]}.items():
        require(sha(path) == expected, "original host input path changed while recording: " + path)
    with (validation / "host-validation.json").open("x") as output:
        output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"compiler_commit": args.commit, "binary_sha256": record["binary_sha256"],
                      "host_validation_sha256": sha(validation / "host-validation.json"), "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
