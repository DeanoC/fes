# Clock-domain guarded driver-copy baseline and listing

Root alone records host validation, activates and executes this package.
Authors do not execute helpers, compilers, builds, tests, routes or hardware.
All previous source, binaries, helpers and proofs remain immutable.

The source base is `9dc3633aa0c5395df9a81be8437d1a746ba54b5d`. The reviewed
new delta is exactly five files: `common/kernel/timing.h`, `timing.cc`,
`mistral/lut_driver_copy.cc`, and its two backend test files. Activation
requires explicit actual clean source/commit/build/binary/host/helper pins
plus the actual driver and timing backend case counts. Counts must match all
committed native TEST_F declarations and actual passed log names; the minimum
new coverage is driver 8 and timing 4. Both CLI suites are current runs with
exactly 10 and 4 cases. Source, logs, host producer, binaries and cache are
bound. Eleven of the same sixteen source files must remain byte-identical to
the finalized predecessor host `78c2fd21…`. Focused37 remains separately
closed at `d68ff437…` and explicitly not rerun; current timing/driver checks
are not mislabeled as inherited checks. Optional generic ARCH evidence is
compile-only, binds its own source/binary/cache/logs and claims no runtime STA.
Its actual compiled commit is disclosed separately from the later test-only
result commit; all eleven production Git blobs must be identical. Both the
preserved cold build and final incremental build, plus the initial fixture
failure log, remain bound. Warning count refers to the cold build alone.

The completed rejection proof `e28ac9a1…` supplies its flat 453-artifact,
281-runtime closure, including exact previous full native placement and
15,290-path report plus all preceding accepted/diagnostic proofs. No old
generator, comparison or authenticator is replayed. Only pinned `32fd10…`
pure lossless native parsing, typed canonical serialization and diagnostic
regex constants are imported. All supplied original pathnames, including
symlinks, are retained and rehashed at completion. The Mistral model/library,
tree, archives and initialized gitlinks must match the frozen predecessor.

Root first runs a new disabled-driver baseline from the exact complete
previous invocation, removing only the two driver selectors and replacing
the executable/write/report paths. It retains cap16,384, fixed inputs, seed,
GPU1 selectors, constraints, upstream guarded selections and diagnostic
environment. The actual baseline module must match the predecessor typed
module, native bits/consumers/settings/attributes/parameters/ports/BELs,
available pin fields, export order and lossless duplicate PLL records. Only
creator metadata may differ across binaries, and both values are disclosed.
All71 placement metrics and retained qualification messages stay exact.
The whole actual predicted report must match, including all15,290 paths,
six legacy prefix paths, actual windows/delays/Fmax/constraints. Additional
current native topology, scalar/vector bit edges, pair/endpoint uniqueness,
finite segments/windows, cap and same-clock order remain checked without
pruning, BUF collapse or imported routed delays. Cross-clock ordering and
unseen phase state remain getter provenance, not independently recomputed STA.

That baseline's independent completed comparison is mandatory before the
driver listing. The listing uses only its actual same-new-binary baseline
report, candidate -1 and an otherwise identical complete prefix invocation.
Controlled FunctionalInvocation runtime and compiler-read audit are
mandatory. GPU routing, analogue signoff, RBF output and forced selection do
not execute; outputs are exclusive new files. Ambient diagnostics are rejected.

Listing must restore the whole own baseline native module, same-binary
creator, order, PLL occurrences, metrics, prior qualifications and expanded
report exactly. Actual bounded reported edges may be rejected before trials
or probed. Every eligible edge must emit its real domain-coverage summary;
qualified ordinals must be fresh, contiguous, and attached to the exact
preceding trial with improvement >=250ps and all improvement, endpoint,
clock and hold flags true. Limits remain16 reported edges and16 timed trials
per edge. Ordinary Q consumer multiplicity and reported truth-row width are
checked from actual native topology; the compiler's strict guide guards remain.

Domain summaries distinguish timed setup pairs from unrelated transfers and
native hold-related pairs. When unrelated pairs exist, the summary must show
the separate reference-free frame. The frozen accessor and driver check
finite extrema, exact pair-key/class/window coverage, timed margins and
unrelated max nonincrease/min nondecrease in native and reference-free frames.
Unrelated pairs have no fabricated setup window or margin. Logs serialize
counts and guard flags, not individual before/after extrema; those numerical
bounds remain explicitly compiled, root-tested guard evidence, not an
independent per-pair numerical proof.

Pre-route JSON does not prove full FES_PINMAP_V1, physical pin placement,
combInfo caches, indexed stores/free lists/buckets/pointers, dictionary
storage or GPU IDs. Current listing qualifies modeled candidates; it proves
no exported selected clone, independent Boolean copy, routed gain, RBF,
final hold or hardware acceptance. A selected/full package requires a real
fresh ordinal and separately declared actual function, physical and routed
timing proof. No site, clone, ordinal or gain is assumed here.

Root execution API:

1. `record_host.py --commit COMMIT`, after all current root checks close;
   optional actual generic build/configure/build-log paths and
   `--generic-commit COMPILED_COMMIT` must be supplied together.
2. `freeze.py` with source/commit/build/binary/host and four helper pins plus
   `--driver-backend-cases N --timing-backend-cases N` actual exact counts.
3. `run.py baseline --source-identity-sha256 SHA`.
4. `compare_listing.py baseline --source-identity-sha256 SHA`.
5. Only after that proof passes, `run.py list-driver --source-identity-sha256 SHA`.
6. `compare_listing.py list-driver --source-identity-sha256 SHA`.
