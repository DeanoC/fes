"""Root-only fresh disabled baseline and final clock-domain guarded listing."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

import freeze


def pure_listing(source):
    path = freeze.HERE / "compare_listing.py"
    freeze.require(freeze.sha(path) == source["helper_sha256"][path.name], "current comparator changed")
    spec = importlib.util.spec_from_file_location("driver_rejection_replay_check", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=freeze.PHASES)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    source, inputs = freeze.authenticate_freeze(args.source_identity_sha256)
    folder = freeze.PHASES[args.phase]
    freeze.require(not folder.exists(), "replay output already exists")
    baseline = None
    if args.phase == "list-driver":
        baseline = freeze.baseline_binding(inputs, args.source_identity_sha256)
        parent = freeze.read(freeze.PHASES["baseline"] / "run.json")
        freeze.authenticate_phase(parent, source, args.source_identity_sha256)
        for path, expected in parent["execution"]["files"].items():
            freeze.bind(inputs, path, expected)
        helper = pure_listing(source)
        native = helper.native_helper(inputs)
        document = native.read_netlist(freeze.PHASES["baseline"] / "placed.json")
        report = freeze.read(freeze.PHASES["baseline"] / "timing.json")
        helper.expanded_paths(document, report)
        helper.validate_guide(document, report)
    sys.path.insert(0, str(freeze.MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    tool_identity = (f"base_commit={freeze.BASE}; experimental_source_sha256={source['source_archive_sha256']}; "
                     f"sha256={source['binary_sha256']}")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(freeze.HERE / "nextpnr-mistral", tool_identity)}, 1)
    try:
        freeze.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                       "ambient compiler diagnostics are forbidden")
        record = freeze.record_template(source, args.source_identity_sha256, args.phase, invocation.inputs, baseline)
        freeze.authenticate_phase(record, source, args.source_identity_sha256, baseline)
        for path, expected in record["execution"]["files"].items():
            freeze.bind(inputs, path, expected)
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        try:
            with (folder / "phase.log").open("x") as log:
                result = audited_run(record["command"], source_root=freeze.MODULE, cwd=record["cwd"],
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log,
                    stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            record["compiler_read_audit_passed"] = True
            invocation.verify()
            freeze.require(result.returncode == 0 and all((folder / name).is_file() and (folder / name).stat().st_size > 0
                           for name in ("phase.log", "placed.json", "timing.json")), "replay did not complete with actual outputs")
            helper = pure_listing(source)
            log = (folder / "phase.log").read_text()
            freeze.require("Info: Program finished normally." in log and
                           not any(line.startswith("ERROR:") for line in log.splitlines()) and
                           not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...")) and
                           log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                           not any((folder / name).exists() for name in ("core.rbf", "routed.json")),
                           "actual phase is not the completed current predicted no-route invocation")
            helper.expanded_paths(helper.native_helper(inputs).read_netlist(folder / "placed.json"), freeze.read(folder / "timing.json"))
            helper.check_path_count_log(log, freeze.read(folder / "timing.json"))
            if args.phase == "baseline":
                freeze.require("LUT driver copy" not in log, "disabled baseline executed the driver stage")
            else:
                freeze.require("LUT driver copy discovery:" in log and "LUT driver copy applied" not in log,
                               "fresh driver listing did not finish without applying a copy")
            record["output_sha256"] = {str(folder / name): freeze.sha(folder / name)
                                      for name in ("phase.log", "placed.json", "timing.json")}
            record["completed"] = True
            freeze.authenticate_phase(record, source, args.source_identity_sha256, baseline)
            freeze.finish({**inputs, **record["output_sha256"]})
            print(json.dumps({key: record[key] for key in ("phase", "compiler_commit", "completed", "exit_code", "elapsed_seconds")}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
