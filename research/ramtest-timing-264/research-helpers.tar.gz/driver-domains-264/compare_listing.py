"""Partial actual multi-endpoint report/listing proof; no routed acceptance."""
import argparse
import importlib.util
import io
import json
import math
from pathlib import Path
import re
import tarfile

import freeze


def native_helper(inputs):
    freeze.bind(inputs, freeze.PURE, freeze.PURE_SHA)
    spec = importlib.util.spec_from_file_location("timing_paths_frozen_native_parser", freeze.PURE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_predicted_report(report):
    parent = freeze.read(freeze.OLD / "list-driver/timing.json")
    freeze.require(type(report.get("critical_paths")) is list and report["critical_paths"] and
                   set(report.get("fmax", {})) == set(parent["fmax"]) and
                   all(report["fmax"][clock]["constraint"] == parent["fmax"][clock]["constraint"] and
                       type(report["fmax"][clock]["achieved"]) in (int, float) and
                       math.isfinite(report["fmax"][clock]["achieved"]) and report["fmax"][clock]["achieved"] > 0
                       for clock in parent["fmax"]), "actual predicted report is empty/nonfinite or clock constraints differ")


def validate_guide(document, report):
    """Validate all violated ENA/DATAIN path graph records, without STA claims.

    This deliberately mirrors the report's relevant-path selection only. It
    checks raw current cells/ports/locations/edges, never collapses late BUFs.
    Clock/timing-class and legal-arc checks remain the compiled stage's guards.
    """
    require = freeze.require
    check_predicted_report(report)
    top = document["modules"]["top"]
    cells, names = top["cells"], top["netnames"]
    require(type(report["critical_paths"]) is list, "guide lacks critical_paths")
    relevant, edges = [], set()
    def endpoint(value):
        return native_endpoint(top, value)
    for index, path in enumerate(report["critical_paths"]):
        segments = path.get("path", [])
        require(type(segments) is list, "guide path is not an array")
        if not segments:
            continue
        last = segments[-1]
        if last.get("type") != "setup" or last.get("to", {}).get("port") not in ("ENA", "DATAIN"):
            continue
        window = path.get("max_delay")
        require(type(window) in (int, float) and math.isfinite(window) and window > 0,
                "guide timing window is invalid")
        delays = [segment.get("delay") for segment in segments]
        require(all(type(value) in (int, float) and math.isfinite(value) for value in delays), "guide delay is nonfinite")
        total = sum(delays)
        require(math.isfinite(total), "guide total is nonfinite")
        if total <= window:
            continue
        relevant.append(index)
        previous, routing, setup, skew = None, [], False, False
        for segment in segments:
            source, sink = endpoint(segment["from"]), endpoint(segment["to"])
            kind = segment["type"]
            if kind == "clk-skew":
                require(previous is None and not skew and not setup, "guide skew is duplicated/misordered")
                skew = True
                continue
            require(not setup and (previous is None or source == previous), "guide data path is disconnected")
            if kind == "routing":
                a, b = cells[source[0]], cells[sink[0]]
                source_bits, source_dir = port_data(cells, *source)
                sink_bits, sink_dir = port_data(cells, *sink)
                require(source_dir == "output" and sink_dir == "input" and source_bits == sink_bits,
                        "guide routing edge is stale")
                net = segment.get("net")
                require(net in names and names[net]["bits"] == source_bits, "guide net alias/edge differs")
                routing.append((source, sink))
                if (a["type"] in {"MISTRAL_ALUT%d" % width for width in range(2, 7)} and source[1] == "Q" and
                        b["type"] == "MISTRAL_ALUT_ARITH" and sink[1] in ("A", "B", "C", "D0", "D1")):
                    edges.add((source[0], sink[0], sink[1]))
            elif kind == "logic":
                require(source[0] == sink[0] and port_data(cells, *source)[1] == "input" and
                        port_data(cells, *sink)[1] == "output", "guide logic topology differs")
            elif kind == "clk-to-q":
                require(previous is None and source == sink and port_data(cells, *source)[1] == "output",
                        "guide launch topology differs")
            elif kind == "setup":
                require(source == sink and routing and routing[-1][1] == sink and cells[sink[0]]["type"] == "MISTRAL_FF",
                        "guide does not terminate at its actual FF input")
                setup = True
            else:
                require(False, "unsupported guide path segment")
            previous = sink
        require(setup, "guide path lacks terminal setup")
    return {"relevant_violated_guide_path_indices": relevant,
            "reported_lut_to_arithmetic_data_edges": sorted(edges),
            "all_relevant_path_cells_ports_locations_and_native_edges_present": True,
            "guide_path_projection_or_buffer_collapse_used": False}


def reason_tokens(source):
    with tarfile.open(freeze.HERE / "source.tar.gz", "r:gz") as outer:
        payload = outer.extractfile(source["repositories"]["nextpnr"]["archive_member"]).read()
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:") as archive:
        text = archive.extractfile("mistral/lut_driver_copy.cc").read().decode()
    return set(re.findall(r'"([a-z]+(?:-[a-z]+)+)"', text))


def qualification(log, guide, top, source):
    require = freeze.require
    discovery = re.compile(r"^Info: LUT driver copy discovery: (\d+) bounded data edges\.$")
    start = re.compile(r"^Info: LUT driver copy discovery source=(.+) sink=(.+)\.(A|B|C|D0|D1) users=(\d+) rows=(\d+)$")
    trial = re.compile(r"^Info: LUT driver copy trial source=(.+) sink=(.+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])$")
    candidate = re.compile(r"^Info: LUT driver copy candidate (\d+): source=(.+) sink=(.+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps\.$")
    probes = re.compile(r"^Info: LUT driver copy probes: source=(.+) sink=(.+)\.(A|B|C|D0|D1) timed=(\d+)$")
    summary = re.compile(r"^Info: LUT driver copy: (\d+) qualified candidates; no candidate applied\.$")
    domains = re.compile(r"^Info: LUT driver copy domains source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) endpoints=(\d+) timed_pairs=(\d+) unrelated_pairs=(\d+) hold_pairs=(\d+) reference_free=([01])$")
    rejection = re.compile(r"^Info: LUT driver copy rejection source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) reason=([a-z]+(?:-[a-z]+)+)(.*)$")
    reported_edges = {tuple(row) for row in guide["reported_lut_to_arithmetic_data_edges"]}
    bounded, current, last, total, rows, ordinals, summaries = None, None, None, 0, [], [], 0
    rejected, handled, reasons = [], set(), reason_tokens(source)
    cells = top["cells"]
    for line in log.splitlines():
        if not line.startswith("Info: LUT driver copy"):
            continue
        if match := discovery.fullmatch(line):
            require(bounded is None and not rows, "duplicate/misordered discovery count")
            bounded = int(match[1]); require(bounded == min(16, len(reported_edges)), "bounded report-edge count differs")
        elif match := start.fullmatch(line):
            require(bounded is not None and current is None and summaries == 0, "discovery block is misordered")
            edge = tuple(match.group(i) for i in (1, 2, 3))
            require(edge in reported_edges and edge not in handled, "discovered edge is absent/repeated in the unchanged guide")
            handled.add(edge)
            source_cell = cells[edge[0]]
            width = int(source_cell["type"].removeprefix("MISTRAL_ALUT"))
            require(2 <= width <= 6 and int(match[5]) == 1 << width, "discovery truth-row count/type differs")
            bits = source_cell["connections"]["Q"]
            require(len(bits) == 1 and type(bits[0]) is int, "source Q is not a native signal")
            users = sum(connection.count(bits[0]) for cell in cells.values()
                        for port, direction in cell["port_directions"].items() if direction == "input"
                        for connection in (cell["connections"][port],))
            require(users == int(match[4]), "native original Q consumer count differs")
            require(not any(row["edge"] == list(edge) for row in rows), "discovery repeats an edge")
            rows.append({"edge": list(edge), "raw_truth_rows_reported": int(match[5]), "original_q_users": users, "trials": []})
            current, total, last = edge, 0, None
        elif match := domains.fullmatch(line):
            edge = tuple(match.group(i) for i in (1, 2, 3))
            endpoints, timed, unrelated, hold, reference_free = [int(match[i]) for i in range(4, 9)]
            require(edge == current and total == 0 and "domains" not in rows[-1] and summaries == 0 and
                    endpoints > 0 and timed + unrelated >= endpoints and hold <= timed + unrelated and
                    reference_free == int(unrelated > 0), "domain coverage/classification summary differs")
            rows[-1]["domains"] = {"endpoints": endpoints, "timed_pairs": timed, "unrelated_pairs": unrelated,
                "hold_pairs": hold, "reference_free": bool(reference_free),
                "unrelated_pairs_guarded_as_finite_transfer_bounds_with_no_setup_window": True,
                "numeric_before_after_pair_extrema_independently_proved": False}
        elif match := rejection.fullmatch(line):
            edge = tuple(match.group(i) for i in (1, 2, 3))
            require(bounded is not None and current is None and summaries == 0 and edge in reported_edges and
                    edge not in handled and match[4] in reasons, "pretrial rejection edge/reason/order is invalid")
            handled.add(edge)
            metadata = {}
            for item in match[5].split():
                key, separator, value = item.partition("=")
                require(separator and value and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", key) and key not in metadata,
                        "rejection detail key/value schema differs")
                metadata[key] = value
            require(len(metadata) <= 64, "pretrial rejection detail is not bounded")
            if "cell" in metadata:
                require(metadata["cell"] in cells and metadata.get("type") == cells[metadata["cell"]]["type"],
                        "pretrial rejection cell/type is stale")
                if "port" in metadata:
                    bits, _ = port_data(cells, metadata["cell"], metadata["port"])
                    if "net" in metadata:
                        require(metadata["net"] in top["netnames"] and top["netnames"][metadata["net"]]["bits"] == bits,
                                "pretrial rejection detail native net/port differs")
            if "net" in metadata:
                require(metadata["net"] in top["netnames"], "pretrial rejection native net is absent")
            rejected.append({"edge": list(edge), "reason": match[4], "details": metadata,
                             "guard_state_is_current_compiler_diagnostic_not_independent_STA": True})
        elif match := trial.fullmatch(line):
            edge = tuple(match.group(i) for i in (1, 2, 3))
            require(edge == current and total < 16 and summaries == 0 and "domains" in rows[-1],
                    "trial identity/order/budget/domain coverage differs")
            total += 1
            gain = int(match[5]); flags = [int(match[i]) for i in range(6, 10)]
            require(not flags[0] or gain >= 250, "positive improvement flag misses the reported250ps guard")
            last = {"edge": list(edge), "bel": match[4], "gain_ps": gain,
                    "improve": flags[0], "endpoints": flags[1], "clocks": flags[2], "hold": flags[3]}
            rows[-1]["trials"].append(last)
        elif match := candidate.fullmatch(line):
            edge = tuple(match.group(i) for i in (2, 3, 4))
            require(last is not None and int(match[1]) == len(ordinals) and edge == current and
                    last["bel"] == match[5] and last["gain_ps"] == int(match[6]) and
                    all(last[key] == 1 for key in ("improve", "endpoints", "clocks", "hold")) and
                    "ordinal" not in last, "qualified candidate lacks its exact preceding guarded trial")
            last["ordinal"] = int(match[1]); ordinals.append(int(match[1]))
        elif match := probes.fullmatch(line):
            require(tuple(match.group(i) for i in (1, 2, 3)) == current and int(match[4]) == total,
                    "probe summary differs from actual trial rows")
            require("domains" in rows[-1], "eligible edge lacks its actual current domain summary")
            for row in rows[-1]["trials"]:
                require(("ordinal" in row) == all(row[key] == 1 for key in ("improve", "endpoints", "clocks", "hold")),
                        "a qualifying trial lacks its fresh ordinal")
            current, last = None, None
        elif match := summary.fullmatch(line):
            require(current is None and bounded is not None and int(match[1]) == len(ordinals) and summaries == 0,
                    "final qualified summary differs")
            summaries += 1
        else:
            require(False, "unknown/applied driver-copy diagnostic: " + line)
    require(bounded is not None and summaries == 1 and current is None and len(handled) == bounded,
            "listing lacks a complete bounded driver stage")
    return {"bounded_reported_edges": bounded, "eligible_probed_edges": rows,
            "qualified_driver_ordinals": ordinals, "no_candidate_applied": True,
            "pretrial_rejections": rejected,
            "domain_classification_and_transfer_bound_guards_are_compiler_reported": True,
            "numeric_before_after_pair_extrema_independently_proved": False,
            "minimum_modeled_gain_ps": 250, "guards_are_current_compiler_reported_not_independent_STA": True}


def completed(inputs, source, identity_sha, phase, baseline=None):
    folder = freeze.PHASES[phase]
    freeze.bind(inputs, folder / "run.json", freeze.sha(folder / "run.json"))
    run = freeze.read(folder / "run.json")
    freeze.authenticate_phase(run, source, identity_sha, baseline)
    freeze.require(run["completed"] is True, "actual phase did not complete")
    for path, expected in run["input_sha256"].items():
        freeze.bind(inputs, path, expected)
    for path, expected in run["execution"]["files"].items():
        freeze.bind(inputs, path, expected)
    for path, expected in run["output_sha256"].items():
        freeze.require(Path(path).stat().st_size > 0, "actual output is empty")
        freeze.bind(inputs, path, expected)
    freeze.require(not any((folder / name).exists() for name in ("core.rbf", "routed.json")), "listing has routed outputs")
    log = (folder / "phase.log").read_text()
    freeze.require("Info: Program finished normally." in log and
                   not any(line.startswith("ERROR:") for line in log.splitlines()) and
                   not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...")),
                   "actual phase is not a normally completed no-route invocation")
    freeze.require(log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1,
                   "actual predicted-report refresh provenance differs")
    check_predicted_report(freeze.read(folder / "timing.json"))
    return run, log



def port_data(cells, name, port):
    """Resolve one native scalar bit; exported vector groupings are lossless."""
    freeze.require(name in cells, "path cell is absent: " + name)
    cell = cells[name]
    connections, directions = cell["connections"], cell["port_directions"]
    if port in connections:
        bits = connections[port]
        freeze.require(port in directions and type(bits) is list and len(bits) == 1,
                       "path terminal is not a scalar native port: " + name + "." + port)
        return bits, directions[port]
    match = re.fullmatch(r"(.+)\[(\d+)\]", port)
    freeze.require(match is not None and match[1] in connections and match[1] in directions,
                   "path terminal is absent from native ports: " + name + "." + port)
    bits = connections[match[1]]
    index = int(match[2])
    freeze.require(type(bits) is list and index < len(bits),
                   "path vector bit is outside actual native connection width")
    return [bits[index]], directions[match[1]]


def native_endpoint(top, value):
    freeze.require(type(value) is dict and set(value) == {"cell", "port", "loc"} and
                   type(value["cell"]) is str and type(value["port"]) is str and
                   type(value["loc"]) is list and len(value["loc"]) == 2 and
                   all(type(item) is int for item in value["loc"]), "path endpoint schema differs")
    name, port = value["cell"], value["port"]
    port_data(top["cells"], name, port)
    bel = top["cells"][name]["attributes"].get("NEXTPNR_BEL")
    match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", bel or "")
    freeze.require(match is not None and value["loc"] == [int(match[1]), int(match[2])],
                   "path endpoint BEL/coordinates are stale")
    return name, port


def clock_event(value, top):
    if value == "<async>":
        return None
    match = re.fullmatch(r"(posedge|negedge) (.+)", value or "")
    freeze.require(match is not None and match[2] in top["netnames"] and
                   len(top["netnames"][match[2]]["bits"]) == 1 and
                   type(top["netnames"][match[2]]["bits"][0]) is int,
                   "path event is not an actual scalar clock net")
    return match[1], match[2], top["netnames"][match[2]]["bits"]


def register_clock(cells, terminal):
    name, port = terminal
    cell = cells[name]
    if cell["type"] == "MISTRAL_FF":
        clock = "CLK"
    elif cell["type"] == "cyclonev_hps_interface_fpga2sdram":
        match = re.fullmatch(r"(cmd_data|cmd_valid|wrack_ready|cmd_ready|wrack_data|wrack_valid|wr_data|wr_valid|wr_ready|rd_ready|rd_data|rd_valid)_(\d+)(?:\[\d+\])?", port)
        freeze.require(match is not None, "HPS registered path port is unsupported by the native clock audit")
        prefix = "cmd_port_clk" if match[1].startswith(("cmd_", "wrack_")) else "wr_clk" if match[1].startswith("wr_") else "rd_clk"
        clock = prefix + "_" + match[2]
    elif cell["type"].startswith("MISTRAL_MUL"):
        clock = "CLK"
    elif cell["type"] == "MISTRAL_MLAB":
        clock = "CLK1"
    else:
        freeze.require(False, "registered path clock audit lacks this actual primitive: " + cell["type"])
    bits, direction = port_data(cells, name, clock)
    freeze.require(direction == "input" and type(bits[0]) is int, "registered clock is not a native signal input")
    return bits


def expanded_paths(document, report):
    """Prove actual exported topology; unseen pin/phase/STA state stays unclaimed."""
    require = freeze.require
    check_predicted_report(report)
    require(report.get("timing_report_paths") == freeze.PATH_LIMIT, "actual report diagnostic limit differs")
    old_report = freeze.read(freeze.LEGACY_REPORT)
    old_paths = old_report["critical_paths"]
    require(len(old_paths) == 6 and report["critical_paths"][:6] == old_paths,
            "old six legacy paths are not the exact unchanged report prefix")
    require(report["fmax"] == old_report["fmax"], "diagnostic changed modeled Fmax/constraints")
    old_windows = {(path["from"], path["to"]): path["max_delay"] for path in old_paths}
    require(len(old_windows) == len(old_paths), "legacy pair windows are ambiguous")
    top, counts, seen, extra_order, new_windows = document["modules"]["top"], {}, set(), {}, {}
    cells = top["cells"]
    for index, path in enumerate(report["critical_paths"]):
        require(type(path) is dict and set(path) == {"from", "to", "max_delay", "path"} and
                type(path["path"]) is list and path["path"], "expanded path schema is incomplete")
        pair = path["from"], path["to"]
        launch, capture = clock_event(pair[0], top), clock_event(pair[1], top)
        window = path["max_delay"]
        require(type(window) in (int, float) and math.isfinite(window) and window > 0,
                "expanded path window is nonfinite/nonpositive")
        if pair in old_windows:
            require(window == old_windows[pair], "expanded path changed its preserved actual domain-pair window")
        else:
            require(pair not in new_windows or new_windows[pair] == window, "new domain pair has inconsistent actual windows")
            new_windows[pair] = window
        endpoint = native_endpoint(top, path["path"][-1]["to"])
        identity = pair + endpoint
        require(identity not in seen, "report repeats a domain-pair/native endpoint")
        seen.add(identity)
        counts[pair] = counts.get(pair, 0) + 1
        require(counts[pair] <= freeze.PATH_LIMIT, "actual domain pair exceeds requested endpoint budget")
        previous, first, setup, clock_prefix, delays_ps = None, None, False, set(), []
        for segment in path["path"]:
            require(type(segment) is dict and {"type", "delay", "from", "to"} <= set(segment),
                    "expanded path segment schema differs")
            source = native_endpoint(top, segment["from"])
            sink = native_endpoint(top, segment["to"])
            delay, kind = segment["delay"], segment["type"]
            require(type(delay) in (int, float) and math.isfinite(delay), "expanded path delay is nonfinite")
            delays_ps.append(round(delay * 1000))
            if kind in ("clk-skew", "clk-to-clk"):
                require(previous is None and first is None and kind not in clock_prefix and not setup and
                        launch is not None and capture is not None,
                        "clock prefix is duplicated/misordered or has async clock attribution")
                require(port_data(cells, *source)[0] == launch[2] and port_data(cells, *sink)[0] == capture[2],
                        "clock prefix does not name the actual launch/capture clock connections")
                clock_prefix.add(kind)
                continue
            require(not setup and (previous is None or source == previous), "expanded native data chain is disconnected")
            source_bits, source_dir = port_data(cells, *source)
            sink_bits, sink_dir = port_data(cells, *sink)
            if kind in ("clk-to-q", "source"):
                require(first is None and previous is None and source == sink and source_dir == "output" and delay >= 0,
                        "expanded launch does not name its actual native output")
                first = source
                if kind == "clk-to-q":
                    require(launch is not None and register_clock(cells, source) == launch[2],
                            "registered launch clock net differs from actual report event")
                else:
                    require(launch is None, "asynchronous source has a registered launch event")
            elif kind == "routing":
                require(first is not None and source_dir == "output" and sink_dir == "input" and
                        source_bits == sink_bits and type(source_bits[0]) is int and delay >= 0,
                        "expanded routing segment is not an actual current signal edge")
                net = segment.get("net")
                require(net in top["netnames"] and top["netnames"][net]["bits"] == source_bits and
                        type(segment.get("sources")) is list,
                        "expanded routing segment net alias/source schema is stale")
            elif kind == "logic":
                require(first is not None and source[0] == sink[0] and source_dir == "input" and
                        sink_dir == "output" and delay >= 0,
                        "expanded logic segment is not a native input/output arc")
            elif kind == "setup":
                require(first is not None and source == sink == endpoint and sink_dir == "input" and
                        capture is not None and register_clock(cells, sink) == capture[2] and
                        segment is path["path"][-1],
                        "expanded path lacks its actual registered terminal/clock")
                setup = True
            else:
                require(False, "unsupported expanded setup path segment: " + str(kind))
            previous = sink
        require(setup and first is not None and math.isfinite(sum(segment["delay"] for segment in path["path"])),
                "expanded native path lacks finite complete registered setup provenance")
        if index >= len(old_paths) and launch is not None and capture is not None and launch[2] == capture[2]:
            extra_order.setdefault(pair, []).append((-sum(delays_ps), endpoint[0], endpoint[1]))
    require(all(rows == sorted(rows) for rows in extra_order.values()),
            "same-clock extra endpoints are not ordered by modeled delay/native name/port")
    return {"expanded_paths_current_native_topology_validated": True,
            "legacy_report_prefix_and_fmax_exact": True,
            "legacy_report_path_count": len(old_paths),
            "additional_reported_setup_path_count": len(report["critical_paths"]) - len(old_paths),
            "domain_pair_endpoint_counts": [{"from": pair[0], "to": pair[1], "count": count}
                                          for pair, count in sorted(counts.items())],
            "new_actual_domain_pair_windows": [{"from": pair[0], "to": pair[1], "max_delay": window}
                                              for pair, window in sorted(new_windows.items())],
            "pair_and_endpoint_uniqueness_proved": True,
            "reported_windows_and_signed_segments_finite": True,
            "preserved_pair_windows_exact": True,
            "same_clock_extra_path_sum_and_name_order_checked": True,
            "async_and_cross_clock_endpoint_order_independently_recomputed": False,
            "new_pair_windows_independently_recomputed": False,
            "native_edges_checked_without_buffer_projection": True}


def check_path_count_log(log, report):
    rows = re.findall(r"^Info: Timing report includes (\d+) additional registered setup endpoint paths \(limit (\d+) per domain pair\)\.$",
                      log, re.M)
    freeze.require(rows == [(str(len(report["critical_paths"]) - 6), str(freeze.PATH_LIMIT))],
                   "actual final expanded-report count/limit diagnostic differs")


def same_module(native, before, after, creator):
    freeze.require((before["creator"] == after["creator"]) if creator else
                   type(before["creator"]) is str and type(after["creator"]) is str,
                   "same-binary creator metadata changed")
    old, new = before["modules"]["top"], after["modules"]["top"]
    freeze.require(native.canonical(old) == native.canonical(new),
                   "actual native module changed; no settings/pins/BUF/topology normalization permitted")
    freeze.require(native.canonical(old["cells"].pll_ports) == native.canonical(new["cells"].pll_ports),
                   "lossless ordered PLL duplicate records changed")
    for dictionary in ("cells", "netnames"):
        freeze.require(list(old[dictionary]) == list(new[dictionary]), "native export owner order changed")


def baseline_evidence(native, document, log, report):
    old_document = native.read_netlist(freeze.OLD / "list-driver/placed.json")
    same_module(native, old_document, document, False)
    oldlog = (freeze.OLD / "list-driver/phase.log").read_text()
    freeze.require("LUT driver copy" not in log and native.diagnostics(oldlog) == native.diagnostics(log),
                   "old upstream transform/qualification messages changed")
    metrics = native.PLACEMENT_METRICS.findall(oldlog)
    freeze.require(len(metrics) == 71 and metrics == native.PLACEMENT_METRICS.findall(log),
                   "old 71 placement metrics differ")
    evidence = expanded_paths(document, report)
    check_path_count_log(log, report)
    freeze.require(native.canonical(report) == native.canonical(freeze.read(freeze.OLD / "list-driver/timing.json")),
                   "own new-binary baseline changed the complete authenticated predicted report")
    return {"baseline_native_graph_matches_predecessor": True, "only_creator_metadata_may_differ_from_old": True,
            "complete_predicted_report_exact": True,
            "old_creator": old_document["creator"], "new_creator": document["creator"],
            "matched_ordinary_placement_metrics": 71, "retained_current_qualification_messages_exact": True,
            **evidence}


def comparison(identity_sha, phase):
    source, inputs = freeze.authenticate_freeze(identity_sha)
    native = native_helper(inputs)
    baseline, oldlog = completed(inputs, source, identity_sha, "baseline")
    before = native.read_netlist(freeze.PHASES["baseline"] / "placed.json")
    baseline_report = freeze.read(freeze.PHASES["baseline"] / "timing.json")
    evidence = baseline_evidence(native, before, oldlog, baseline_report)
    actual, candidates, guide = baseline, None, None
    if phase == "list-driver":
        binding = freeze.baseline_binding(inputs, identity_sha)
        actual, log = completed(inputs, source, identity_sha, "list-driver", binding)
        after = native.read_netlist(freeze.PHASES["list-driver"] / "placed.json")
        same_module(native, before, after, True)
        freeze.require(native.diagnostics(oldlog) == native.diagnostics(log) and
                       native.PLACEMENT_METRICS.findall(oldlog) == native.PLACEMENT_METRICS.findall(log),
                       "same-new-binary upstream diagnostics/71 placement metrics differ")
        listing_report = freeze.read(freeze.PHASES["list-driver"] / "timing.json")
        freeze.require(native.canonical(baseline_report) == native.canonical(listing_report),
                       "actual expanded predicted timing report changed after listing rollback")
        check_path_count_log(log, listing_report)
        guide = validate_guide(before, baseline_report)
        candidates = qualification(log, guide, after["modules"]["top"], source)
    else:
        freeze.require(phase == "baseline", "only diagnostic baseline/list-driver proofs are implemented")
    freeze.finish(inputs)
    artifacts = {str(Path(path).relative_to(freeze.ROOT)): value for path, value in inputs.items()
                 if Path(path).is_relative_to(freeze.ROOT)}
    execution = {path: value for path, value in inputs.items() if not Path(path).is_relative_to(freeze.ROOT)}
    for run in (baseline, actual):
        execution.update(run["execution"]["files"])
    top = before["modules"]["top"]
    return {"schema": 1, "phase": freeze.PROOF_PREFIX + phase, "compiler_commit": source["result_commit"],
        "delta_base_commit": freeze.BASE,
        "source_identity_sha256": identity_sha, "generator_sha256": source["helper_sha256"]["compare_listing.py"],
        "frozen_native_parser_sha256": freeze.PURE_SHA,
        "cached_rejection_proof_sha256": freeze.OLD_PROOF_SHA,
        "predecessor_host_validation_path": str(freeze.PREDECESSOR_HOST),
        "predecessor_host_validation_sha256": freeze.PREDECESSOR_HOST_SHA,
        "current_host_case_counts": source["current_host_case_counts"],
        "focused_checks_reexecuted_for_this_binary": False,
        "timing_report_paths": freeze.PATH_LIMIT,
        "candidate_completed": True, "elapsed_seconds": actual["elapsed_seconds"],
        "same_new_binary_baseline_elapsed_seconds": baseline["elapsed_seconds"],
        "same_new_binary_listing_rollback_proved": True if phase == "list-driver" else None,
        "current_predicted_timing_report_exact_after_listing_rollback": True if phase == "list-driver" else None,
        "driver_guide_kind": actual["driver_guide_kind"], "driver_guide_sha256": actual["driver_guide_sha256"],
        "guide_evidence": guide, "fresh_driver_qualification": candidates,
        "qualified_driver_ordinals": candidates["qualified_driver_ordinals"] if candidates is not None else None,
        "cell_count": len(top["cells"]), "named_net_count": len(top["netnames"]),
        "typed_native_module_bits_consumers_bels_attrs_params_ports_exact": True,
        "cell_and_net_export_order_exact": True, "lossless_ordered_pll_occurrences_exact": True,
        **evidence,
        "independent_boolean_equivalence_proved": False, "physical_pin_preservation_proved": False,
        "in_memory_cache_or_indexed_store_identity_proved": False, "gpu_net_ids_proved": False,
        "routed_graph_proof_available": False, "passes_practical_timing_gate": None,
        "candidate_accepted_under_confirmed_target_clock_rule": False, "hardware_tested": False,
        "old_comparators_or_authenticators_replayed": False,
        "proof_limitations": [
            "This is predicted placed timing; no routing, RBF, analogue signoff, routed gain, final hold or hardware acceptance.",
            "Complete actual serialized native modules are compared without BUF collapse, settings/pin/topology normalization or imported routed delays.",
            "Pre-route JSON omits complete FES_PINMAP_V1, combInfo/clock-phase state, indexed-store/free-list/bucket/pointer identities and GPU IDs.",
            "Additional paths use the frozen getter's actual domain/backpointer/window/delay records; unseen physical inversion/phase and numeric STA are not independently recomputed.",
            "Same-clock extra order is checked from represented signed path sums; async/cross-clock order remains actual frozen-getter provenance because setup slack may contain unexported clock-route terms.",
            "Existing six actual pair windows are exact; any newly exposed pair's finite consistent window remains explicitly current compiler-emitted diagnostic evidence.",
            "Current domain counts bind timed setup/hold and unrelated transfer-bound classification; unrelated pairs have no manufactured setup window. Numeric before/after per-pair extrema are not serialized and are not independently proved.",
            "Fresh copy ordinals and endpoint/clock/hold guards are current compiler-modeled trial diagnostics, not routed physical or timing qualification."],
        "artifact_sha256": dict(sorted(artifacts.items())), "execution_file_sha256": dict(sorted(execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=freeze.PHASES)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    output = freeze.PHASES[args.phase] / "comparison.json"
    freeze.require(not output.exists(), "comparison output already exists")
    result = comparison(args.source_identity_sha256, args.phase)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in (
        "phase", "compiler_commit", "baseline_native_graph_matches_predecessor", "legacy_report_prefix_and_fmax_exact",
        "additional_reported_setup_path_count", "qualified_driver_ordinals", "routed_graph_proof_available")}, indent=2))


if __name__ == "__main__":
    main()
