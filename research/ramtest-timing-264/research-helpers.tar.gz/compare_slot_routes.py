"""Compare the frozen controls with the completed slot-preserving compiler route."""
import hashlib
import json
from pathlib import Path
import re
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = RAW.parents[1]
BASELINE = ROOT / "out/ramtest-merged-remap/measured-diagnostic/qor-search/s2-w10-c2"
PRELOAD = RAW / "route-new-binary-scratch"
OLD_COMPILER = RAW / "route-compiler"
FINAL = RAW / "route-slots-final"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


record = read(FINAL / "run.json")
assert record["completed"] and record["exit_code"] == 0
assert record["final_reported_hold_violations"] is False
for filename, digest in record["input_sha256"].items():
    path = Path(filename)
    if path.name == "nextpnr-mistral":
        path = RAW / "validated-nextpnr-mistral"
    assert sha(path) == digest, filename
source_hashes = read(RAW / "slot-fixed-source-hashes.json")
repo = ROOT / "sources/misteross/build/toolchain-ramtest-timing/src/nextpnr"
with tarfile.open(RAW / "nextpnr-slots-fixed-source.tar.gz") as archive:
    for filename, digest in source_hashes.items():
        assert hashlib.sha256(archive.extractfile(filename).read()).hexdigest() == digest, filename

reports = {name: read(folder / "timing.json") for name, folder in
           (("baseline", BASELINE), ("preload", PRELOAD), ("old_compiler", OLD_COMPILER), ("final", FINAL))}
clocks = reports["baseline"]["fmax"]
assert set(clocks) == set(reports["final"]["fmax"])
changes = {}
for name in clocks:
    values = {run: report["fmax"][name]["achieved"] for run, report in reports.items()}
    assert values["final"] >= values["baseline"], name
    changes[name] = {**values, "gain_mhz": values["final"] - values["baseline"],
                     "gain_percent": 100 * (values["final"] / values["baseline"] - 1)}

pattern = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
preload_metrics = pattern.findall((PRELOAD / "route.log").read_text())
final_metrics = pattern.findall((FINAL / "route.log").read_text())
assert final_metrics == preload_metrics

preload_cells = read(PRELOAD / "routed.json")["modules"]["top"]["cells"]
final_cells = read(FINAL / "routed.json")["modules"]["top"]["cells"]
common = set(preload_cells) & set(final_cells)
bel_differences = [name for name in sorted(common)
                   if preload_cells[name]["attributes"].get("NEXTPNR_BEL") !=
                   final_cells[name]["attributes"].get("NEXTPNR_BEL")]
critical = next(p for p in reports["final"]["critical_paths"]
                if p["from"] == p["to"] == "posedge ram_clock.clocks[0]")
summary = {
    "build_id": record["build_id"], "fmax_mhz": changes,
    "matched_placement_metrics": len(final_metrics), "common_cells": len(common),
    "changed_common_bels": bel_differences,
    "rbf_identical_to_preload": sha(FINAL / "core.rbf") == sha(PRELOAD / "core.rbf"),
    "critical_memory_path": critical,
    "source_sha256": source_hashes,
    "artifact_sha256": {str(p.relative_to(ROOT)): sha(p) for p in
                        (FINAL / "run.json", FINAL / "timing.json", FINAL / "core.rbf",
                         RAW / "nextpnr-slots-fixed-source.tar.gz", RAW / "slot-final-ctest.log")},
    "default_recipe_selected": False, "hardware_tested": False,
}
(RAW / "slot-route-comparison.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k not in
                  ("critical_memory_path", "source_sha256", "artifact_sha256")}, indent=2))
