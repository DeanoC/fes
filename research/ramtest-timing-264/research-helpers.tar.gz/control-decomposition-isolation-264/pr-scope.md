# Compiler PR preparation

Assessment uses local `origin/main` `24f9a1db0737559977a13abb2d05cceafa5e6142`
and frozen HEAD `fddbdac2d966ff3c2455e8b93ee221c71156fad7`: 13 unmerged
commits, 40 files, +9,156/-14 lines. No fetch, build, test or route was run
for this assessment. No new production addition selects a rewrite using
baked RTL names, state encodings or coordinates. The design-specific
`retained_enable.cc` is unchanged from this local base.

## Ready-to-open choice

At the next strictly accepted full routed gain, open one PR from the already
committed, pushed and measured compiler stack, with a title such as **Add
opt-in report-guided Mistral control remapping**. Keep the logical commits
visible and describe the measured option profile precisely. Do not imply
that every included option improves timing, that the default compiler changes
mapping, or that the memory target/hardware acceptance is complete.

This is the least-delay choice: deleting unused options now changes source
and binary identity and requires fresh disabled-control and routed evidence.
The cumulative PR is large; mark the additional experiments explicitly and
offer the narrower boundaries below for review. Opening this PR does not
establish performance acceptance for its unused options.

## Measured profile and unused options

The retained parent reaches memory 116.171005 MHz, pixel 93.668045 MHz and
phase 378.582397 MHz, with strict full-route preservation and no final
reported holds. The new isolation/order compiler has no accepted routed gain
yet. Its intended profile retains:

| Included dependency | Role in the measured profile |
| --- | --- |
| Slot-preserving pre-place 16-literal balancing | Retained ordinary placement input |
| Capture-locality diagnostic | Explicit environment-selected profile; 60 retained FF moves |
| Guarded placed11 balancing | Fixed outside FF/LUT placement; retained branch rewrite |
| Fixed-FF local remapping and three-step local plan | Whole compatible LAB-group ENA rewires, original shared users retained |
| Single two/three-LUT internal cut | Retained original cone; redirects one ordinary LUT input |
| Seven-essential-input decomposition | New candidate; exact four-node composition, exhaustive 128-row proof, isolated clone ALMs and original iteration-order preservation |

Current runners use the legacy single internal-cut option, not a multi-cut
comb plan. Other unmerged functionality must be labelled separately:

- Unplaced11 balancing is functionally tested; its independent route was
  rejected. The retained profile uses placed11 instead.
- Local pin optimization was tested but its measured trial regressed.
- Multiple staged internal cuts have parser/backend proof, but measured
  candidates were rejected for timing or original BUF/pin preservation.
- Placed24, geometry diversity and root-aware ranking are tested, but produced
  no qualified candidate. They are not prerequisites of the current profile.
- Capture alone improved memory while reducing other clock margins; it is an
  unselected standalone tradeoff. Its explicit experimental use in the
  qualified combined profile does not make it a general production policy.

## Curating choices and dependencies

If a narrower PR is required, split into (1) cube recognition/rewriting and
guarded placed11, (2) strict current-path/clock report validation, fixed-FF
local plans and single internal-cut cloning, and (3) seven-input decomposition
plus its data-arrival accessor and isolation/order fixes. Capture must remain
an explicit prerequisite or separate prerequisite PR for this measured
profile. Each split carries its matching policy, backend, CLI and documentation
tests. The decomposition reuses the pure cut/pin policies and report validator;
reusing those headers does not require exposing the unused pin-optimization
or multi-comb-plan CLI options. Defer the 24-literal extension and unused
options to separate experimental submissions if reviewers want a smaller API.

Do not transfer frozen route claims to a newly curated binary. A reassembled
branch needs its own build, disabled-control equivalence and complete route.
Consolidate the reduction documentation before publication:
`docs/mistral-reduction-balance.md` describes only 11/16, while
`mistral/reduction_balance.md` describes current 11/16/24 behavior.

## Required evidence before a gain claim

Root reports the frozen compiler's 25 focused tests and disabled-control
equivalence pass. Functional evidence covers truth, inversions, shared users,
indexed-slot rollback, plan schemas, stale paths and clock attribution; the
latest backend fixture also asserts original iteration order and ALM isolation.
These prove bounded transformation behavior, not routed improvement.

Bind the next result to source archive/commit, compiler hash, fixed inputs,
all guide/plan bytes and constraints. Require exhaustive actual routed clone
truth, exact original FF/LUT/BEL/parameter/logical-pin/physical-pin and BUF
preservation, unchanged unselected users and retained transforms, all-clock
nonregression, final hold checks, successful route/RBF provenance and elapsed
time. Listing proves candidate/probe behavior only. Earlier original-pin/BUF
failures and clock regressions show why modeled local slack cannot substitute
for these gates. Publish the qualified experiment and its limits; no hardware
acceptance or 130 MHz closure is established by this compiler PR.
