"""Root-operated real JSON-loader check with both remap-plan options disabled."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
RAW = HERE.parent
PARENT = RAW / "control-decomposition-264"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sys.path.insert(0, str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation

old = json.loads((PARENT / "disabled-control/comparison.json").read_text())
accepted = PARENT / "disabled-control/candidate.json"
assert old["completed"]
expected = json.loads(accepted.read_text())["modules"]
modules_sha = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
assert modules_sha == old["modules_sha256"]
for filename, digest in old["input_sha256"].items():
    assert sha(Path(filename)) == digest
freeze = json.loads((HERE / "source-identity.json").read_text())
assert freeze["base_commit"] == "ec3fc0156a60a3d3193142def03d992a875aaab0"
binary, archive = HERE / "nextpnr-mistral", HERE / "source.tar.gz"
assert sha(binary) == freeze["binary_sha256"] and sha(archive) == freeze["source_archive_sha256"]
source = Path(old["command"][old["command"].index("--json") + 1])
root = old["command"][old["command"].index("--balance-reduction-root") + 1]
output = HERE / "disabled-control"
output.mkdir(exist_ok=False)
identity = f"base_commit={freeze['base_commit']}; experimental_source_sha256={sha(archive)}; sha256={sha(binary)}"
invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, identity)}, 1)
command = [str(binary), "--json", str(source), "--device", "5CSEBA6U23I7", "--no-pack", "--no-place",
           "--no-route", "--balance-reduction-root", root, "--write", str(output / "candidate.json")]
inputs = (binary, archive, source, accepted, PARENT / "disabled-control/comparison.json")
record = {"command": command, "cwd": str(MODULE), "tool_identity": identity,
          "base_compiler_commit": freeze["base_commit"],
          "compiler_commit": freeze.get("result_commit", freeze["base_commit"] + "+wide-cube-experiment"),
          "execution": invocation.inputs, "completed": False,
          "source_archive_sha256": sha(archive), "input_sha256": {str(path): sha(path) for path in inputs},
          "kind": "host-only disabled-plan-options JSON-loader control"}
start = time.monotonic()
try:
    assert not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env)
    with (output / "loader.log").open("w") as log:
        result = audited_run(command, source_root=MODULE, cwd=MODULE, env=invocation.env, stdout=log,
                             stderr=subprocess.STDOUT, check=False, timeout=300)
    record["exit_code"] = result.returncode
    record["elapsed_seconds"] = time.monotonic() - start
    assert result.returncode == 0
    invocation.verify()
    actual = json.loads((output / "candidate.json").read_text())["modules"]
    assert actual == expected
    record["modules_sha256"] = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    assert record["modules_sha256"] == modules_sha
    for filename, digest in record["input_sha256"].items():
        assert sha(Path(filename)) == digest
    record["candidate_sha256"] = sha(output / "candidate.json")
    record["reference_sha256"] = sha(accepted)
    record["completed"] = True
    print(json.dumps({key: record[key] for key in ("completed", "modules_sha256", "candidate_sha256")}), flush=True)
except BaseException as exc:
    record["failure"] = repr(exc)
    record["elapsed_seconds"] = time.monotonic() - start
    if "exit_code" not in record:
        record["exit_code"] = 124 if isinstance(exc, subprocess.TimeoutExpired) else 1
        record["exit_code_is_adapter_sentinel"] = True
    raise
finally:
    (output / "comparison.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    invocation.close()
