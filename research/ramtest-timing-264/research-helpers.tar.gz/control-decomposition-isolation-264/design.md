# Accepted decomposition isolation correction

Cumulative source base ec3fc0156a60a3d3193142def03d992a875aaab0;
implementation delta over 2d521858a686d68dc12c40cacf4e76459f07297b.

Preserve original cell/net relative iteration on acceptance by reinserting
parked owners in reverse iterator order. net_aliases copy keeps original order.
Rejected trials still swap the original owner dictionaries back.

New encoder/root LUTs may share an ALM with each other, but not with any original
COMB/MCOMB/FF occupant (including route buffers). Use actual LAB/ALM metadata.
Keep the original truth, all-clock, endpoint, hard-block-boundary and hold gates.

The positive acceptance test must fail on 2d and pass on the correction for
original iteration and ALM isolation, preserving all 128 truth rows and physical
pins. Full timing measurement uses identical fixed-input parent116 profile.
A memory-only gain with pixel/phase regression does not qualify for the PR.
Host-only experiment; no RTL, default recipe, ABI or hardware change.
