# Isolated exact decomposition: preservation passes, timing rejects

Compiler fddbdac2d966ff3c2455e8b93ee221c71156fad7 over2d521858, cumulativeec3 base. Fresh fixed-input GPU1 candidate0 route completed exit0 in752.171640s, no final reported hold violations.

| Route | Memory MHz | Pixel MHz | Phase MHz |
| --- | ---: | ---: | ---: |
| Retained parent116 | 116.171005 | 93.668045 | 378.582397 |
| Isolated candidate0 | 113.507370 | 93.650490 | 307.631805 |

Reject timing: every strict comparison gate is false. Full actual export proof passes exhaustive128 rows, seven essential inputs, the retained local/comb transformations, all original pins/BELs/parameters/unselected connections/consumers and BUF names. New clones occupy ALMs without original COMB/MCOMB/FF/BUF occupants. Both duplicate PLL outputs are losslessly audited. Original pre-route relative export order passes; this does not claim bucket/slot history or stable GPU IDs.

Full comparison SHA256:31c13cb34588624065edd590a65bb5b79333127a35e627e09266ce13b0f4cc8e.
Listing comparison SHA256:c156ed718c9cff4d8d28f076302210600ef07eaca376d04a7f868b0dd0edf756.
Frozen evidence helper SHA256:d4b16db834f7b06d4f8aefb480f5f6ea74dc4af3ba6e77c22e26e50086165142.

The accepted dictionaries still enumerate three new owners before originals, shifting all original GPU net IDs. Follow-up6ad210a6 changes successful selected acceptance only to put originals first, with all allocations/lookups preceding ownership transfer and exact exception rollback. Synthetic prefix test failsfdd and all25 focused tests pass on6ad. Separate control-decomposition-prefix-264 full route tests indexing; added loads/queue length still differ and timing recovery is not assumed.

Host-only/unselected. No RTL, recipe, ABI or hardware change. No PR milestone reached and130MHz remains unresolved.
