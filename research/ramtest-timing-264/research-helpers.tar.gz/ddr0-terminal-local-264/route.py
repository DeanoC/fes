"""Root-only fresh local qualification, fresh final AC listing, or full HIP route."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
from seal_profile import (HERE, FULL, PROFILE, PHASES, authenticate_phase, expected_command, load_profile,
                          make_plan, phase_folder, require, sealed_input_map, sha)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=PHASES, required=True)
    parser.add_argument("--local-candidate", type=int)
    parser.add_argument("--ac-candidate", type=int)
    args = parser.parse_args()
    if args.phase == "list-local":
        require(args.local_candidate is None and args.ac_candidate is None, "initial listing takes no selected ordinal")
        local, ac = -1, None
    elif args.phase == "list-ac":
        require(args.local_candidate is not None and args.ac_candidate is None, "AC listing needs only freshly selected local ordinal")
        local, ac = args.local_candidate, -1
    else:
        require(args.local_candidate is not None and args.ac_candidate is not None, "full route requires both fresh ordinals")
        local, ac = args.local_candidate, args.ac_candidate
    folder = phase_folder(args.phase, local, ac)
    require(not folder.exists(), "phase output already exists")
    profile, g8, base, _, _ = load_profile()
    module = Path(base["cwd"])
    sys.path.insert(0, str(module))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    from scripts.search_placer_qor import _score_report, has_failed_route_arc
    from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS
    binary = Path(base["command"][0])
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, base["tool_identity"])}, 1)
    env = dict(invocation.env)
    for name in ("NEXTPNR_MISTRAL_CAPTURE_LOCALITY", "NEXTPNR_MISTRAL_PLACED_REDUCTION"):
        env.pop(name, None)
    if args.phase != "list-local":
        env["NEXTPNR_MISTRAL_CAPTURE_LOCALITY"] = base["experimental_capture_locality"]
        env["NEXTPNR_MISTRAL_PLACED_REDUCTION"] = base["experimental_placed_reduction"]
    folder.mkdir()
    plan, plan_file = make_plan(base, args.phase, local), folder / "plan.json"
    with plan_file.open("x") as output:
        output.write(json.dumps(plan, indent=2, sort_keys=True) + "\n")
    record = {**base, "kind": "scratch fourth-local qualification/full route; unselected", "phase": args.phase,
              "local_candidate": local, "decomposition_selection": ac, "remap_plan": plan,
              "remap_plan_sha256": sha(plan_file), "command": expected_command(base, args.phase, local, ac),
              "runner_sha256": sha(HERE / "route.py"), "profile_sha256": sha(PROFILE),
              "reference_run_sha256": sha(FULL / "run.json"), "fourth_local_report_sha256": sha(FULL / "timing.json"),
              "list_only": args.phase != "route", "fresh_listing": args.phase != "route", "execution": invocation.inputs,
              "input_sha256": sealed_input_map(profile, args.phase, local, ac), "completed": False,
              "listing_lineage": {} if args.phase == "list-local" else {"local_listing": str(HERE / "list-local")}}
    if args.phase == "route":
        record["listing_lineage"]["ac_listing"] = str(HERE / f"list-ac-c{local}")
    if args.phase == "list-local":
        for key in ("experimental_capture_locality", "experimental_placed_reduction", "retained_comb_report_sha256",
                    "decomposition_report_sha256"):
            record[key] = None
    for key in ("exit_code", "elapsed_seconds", "fmax", "final_reported_hold_violations"):
        record.pop(key, None)
    g8.ready.authenticate_execution(record, base)
    authenticate_phase(record)
    manifest, started = folder / "run.json", time.monotonic()
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    try:
        with (folder / "route.log").open("x") as log:
            result = audited_run(record["command"], source_root=module, cwd=module, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, check=False, timeout=2400)
        record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
        invocation.verify()
        for filename, digest in record["input_sha256"].items():
            require(sha(Path(filename)) == digest, "phase input changed: " + filename)
        log = (folder / "route.log").read_text()
        require(result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log),
                "phase did not complete normally")
        if args.phase != "route":
            require((folder / "placed.json").exists() and "Running the GPU router" not in log and
                    not (folder / "core.rbf").exists() and not (folder / "routed.json").exists(), "listing started a route")
        else:
            board._require_gpu_backend(log)
            require((folder / "core.rbf").stat().st_size > 0 and "Running signoff timing analysis..." in log,
                    "full RBF/signoff is absent")
            record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
            report = g8.read(folder / "timing.json")
            _score_report(report, REQUIRED_CLOCKS)
            require(set(report["fmax"]) == {name for name, _ in REQUIRED_CLOCKS}, "required clock set changed")
            record["fmax"] = report["fmax"]
        record["completed"] = True
        print(json.dumps({key: record[key] for key in ("phase", "elapsed_seconds", "completed", "fmax",
                          "final_reported_hold_violations") if key in record}, indent=2))
    except BaseException as error:
        record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
        invocation.close()


if __name__ == "__main__":
    main()
