"""Root-operated partial evidence for the completed fourth-local listing.

Cached measured references are hash-bound, never re-executed. The observed
listing has no qualified fourth candidate, so no later listing/full route is
accepted by this helper. No final pins, BUF population, timing or hold proof
is inferred from this pre-route export.
"""
import argparse
import json
import math
from pathlib import Path

import seal_profile as seal

HERE, ROOT = seal.HERE, seal.ROOT
require, sha, read = seal.require, seal.sha, seal.read
FULL_PROOF_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
LIST_PROOF_SHA = "20b7f1dc20c5ef5d2bbb1fb789e2bb00d2d77b08afaff3c7b0d07a7c06d9976d"


def relative(path):
    return str(Path(path).resolve().relative_to(ROOT))


def serial(value):
    return json.loads(json.dumps(value))


def top(g8, folder, filename):
    modules = g8.read_netlist(folder / filename)["modules"]
    require(set(modules) == {"top"}, "unexpected netlist module set")
    return modules["top"]


def netlist(g8, module):
    return g8.Netlist(module["cells"], module["netnames"])


def terminal_cut(g8, old, guide, named_nets):
    """Recover the actual violated terminal ENA pair, including logical pins."""
    found = []
    for index, path in enumerate(guide["critical_paths"]):
        segments = path.get("path", [])
        if not segments or segments[-1]["type"] != "setup" or segments[-1]["to"]["port"] != "ENA":
            continue
        require(math.isfinite(path["max_delay"]) and path["max_delay"] > 0 and
                all(math.isfinite(row["delay"]) for row in segments), "invalid terminal guidance")
        total = sum(row["delay"] for row in segments)
        require(math.isfinite(total), "nonfinite terminal guide total")
        edges = []
        for row in segments:
            for endpoint in (row["from"], row["to"]):
                name, port = endpoint["cell"], endpoint["port"]
                require(name in old.cells and port in old.cells[name]["port_directions"] and
                        tuple(endpoint["loc"]) == g8.comb.cell_lab(old.cells[name]), "stale terminal guide endpoint")
            if row["type"] != "routing":
                continue
            source, target = row["from"], row["to"]
            cell = old.cells[source["cell"]]
            require(cell["port_directions"][source["port"]] == "output" and
                    old.cells[target["cell"]]["port_directions"][target["port"]] == "input" and
                    len(cell["connections"][source["port"]]) == 1, "guide edge is not scalar output to input")
            token = old.token(cell["connections"][source["port"]][0])
            require(old.inputs(target["cell"])[target["port"]] == [token] and row["net"] in named_nets and
                    [old.token(bit) for bit in named_nets[row["net"]]["bits"]] == [token],
                    "stale terminal guide driver/consumer/net")
            edges.append((source, target))
        if total <= path["max_delay"]:
            continue
        require(len(edges) >= 2, "terminal guide lacks two edges")
        inner, outer = edges[-2][0]["cell"], edges[-1][0]["cell"]
        sink = edges[-1][1]["cell"]
        require(edges[-2][0]["port"] == edges[-1][0]["port"] == "Q" and
                edges[-2][1]["cell"] == outer and edges[-1][1]["port"] == "ENA" and
                g8.ready.is_lut(old.cells[inner]) and g8.ready.is_lut(old.cells[outer]) and
                old.cells[sink]["type"] == "MISTRAL_FF", "guide does not end in a two-LUT ENA pair")
        found.append((index, inner, outer, sink, edges[-2][1]["port"], total-path["max_delay"]))
    require(len(found) == 1, "expected one relevant violated terminal ENA guide")
    index, inner, outer, sink, link, excess = found[0]
    require(old.cells[inner]["type"] == "MISTRAL_ALUT2" and old.cells[outer]["type"] == "MISTRAL_ALUT5" and
            int(old.cells[inner]["parameters"]["LUT"], 2) == 0xd and
            int(old.cells[outer]["parameters"]["LUT"], 2) == 0x7fff0000 and link == "E",
            "observed terminal Boolean shape differs from the intended bounded cut")
    for name in (inner, outer):
        g8.lut_shape(old, name)
        require(all(state == 0 for state in old.pin_states(name).values()), "terminal cut has an unexpected polarity")
    boundary = [*old.lut_inputs(inner), *old.lut_inputs(outer)[:4]]
    require(len(boundary) == len(set(boundary)) == 6, "terminal cut does not have six distinct inputs")
    visited = set()
    tree = old.expression((outer, "Q", 0), set(boundary), visited)
    require(visited == {inner, outer}, "terminal function includes an undeclared node")
    rows = []
    for row in range(64):
        values = {token: (row >> bit) & 1 for bit, token in enumerate(boundary)}
        expected = ((not bool(row & 1)) or bool(row & 2)) and not all(row & (1 << bit) for bit in range(2, 6))
        actual = g8.previous.evaluate(tree, values)
        require(actual == int(expected), "terminal mask/polarity algebra differs")
        rows.append(actual)
    require(g8.essential(rows, 6) == set(range(6)) and sum(rows) == 45, "terminal support/true-row count changed")
    root, lab = (outer, "Q", 0), g8.comb.cell_lab(old.cells[sink])
    users = g8.comb.consumers(old, root, set(old.cells))
    group = sorted(name for name, port, bit in users if g8.comb.cell_lab(old.cells[name]) == lab)
    require(group and len(group) == len(set(group)) and all(old.cells[name]["type"] == "MISTRAL_FF" and
            port == "ENA" and bit == 0 and old.inputs(name)["CLK"] == old.inputs(sink)["CLK"] and
            old.pin_states(name).get("CLK") == old.pin_states(sink).get("CLK") and old.pin_states(name).get("ENA") == 0
            for name, port, bit in users if g8.comb.cell_lab(old.cells[name]) == lab), "terminal LAB is incompatible")
    return {"inner": inner, "outer": outer, "primary_ff": sink, "primary_lab": list(lab), "selected_ffs": group,
            "guide_path_index": index, "reported_path_excess_ns": excess, "canonical_boundary_order": boundary,
            "canonical_mask_hex": "0x0ddddddddddddddd", "essential_inputs": 6, "assignments_checked": 64,
            "true_rows": 45, "formula": "(!a OR R) AND !(x0*x1*x2*x3)", "truth_values": rows,
            "algebra_reference": "Authenticated accepted g8 full graph; these are expected composition rows, not an applied fourth-clone proof."}


def nonconnection_fields(cell):
    result = {key: value for key, value in cell.items() if key != "connections"}
    return {**result, "attributes": {key: value for key, value in result["attributes"].items() if key != "FES_PINMAP_V1"}}


def initial_listing_proof(g8, baseline, current, listing_reference, steps, models):
    """Lossless PLL-aware named topology check before later transforms."""
    old, new = netlist(g8, baseline), netlist(g8, current)
    originals = {name for name, cell in old.cells.items() if cell["type"] != "MISTRAL_BUF"}
    added = set(new.cells)-set(old.cells)
    require(originals <= set(new.cells) and set(new.cells) == originals | added and len(added) == 3 and
            all(g8.ready.is_lut(new.cells[name]) for name in added) and
            all(cell["type"] != "MISTRAL_BUF" and not cell["attributes"].get("FES_PINMAP_V1") for cell in new.cells.values()),
            "initial listing changed the original non-BUF population or retained trial owners/pins")
    changes = {}
    for name in originals:
        require(nonconnection_fields(old.cells[name]) == nonconnection_fields(new.cells[name]),
                "initial listing changed original metadata: " + name)
        before, after = g8.connections(old, name), g8.connections(new, name)
        require(set(before) == set(after), "initial listing changed original port dictionary")
        for pin in before:
            if before[pin] != after[pin]:
                require(old.cells[name]["type"] == "MISTRAL_FF" and pin == "ENA" and len(after[pin]) == 1 and
                        after[pin][0][0] in added and after[pin][0][1:] == ("Q", 0),
                        "initial listing changed a connection outside the three declared ENA groups")
                changes.setdefault(after[pin][0][0], []).append(name)
    proofs = []
    for step, model in zip(steps, models):
        clone, selected = g8.discover_local_users(old, new, model)
        require(clone in added and sorted(row["ff"] for row in selected) == sorted(changes.get(clone, [])),
                "initial listing accepted local clone/ENA set differs")
        proofs.append(g8.partial_local_proof(old, new, clone, selected, step, model))
    require({proof["clone"]["cell"] for proof in proofs} == added and
            [proof["assignments_checked"] for proof in proofs] == [32, 16, 16], "initial retained local proof shapes changed")
    missing = set(baseline["netnames"])-set(current["netnames"])
    require(all(net["bits"] and all(bit in old.drivers and old.cells[old.drivers[bit][0]]["type"] == "MISTRAL_BUF"
                for bit in net["bits"]) for name, net in baseline["netnames"].items() if name in missing),
            "initial listing removed a non-BUF named net")
    stripped = {**baseline, "netnames": {name: net for name, net in baseline["netnames"].items() if name not in missing}}
    new_nets = set(current["netnames"])-set(baseline["netnames"])
    require(len(new_nets) == 3 and all(len(current["netnames"][name]["bits"]) == 1 for name in new_nets) and
            {new.token(current["netnames"][name]["bits"][0]) for name in new_nets} == {(name, "Q", 0) for name in added},
            "initial listing has undeclared new named nets")
    g8.compare_named_nets(stripped, current, old, new, new_nets, routed=True)
    g8.ranking.top_ports(baseline, current, old, new)
    require(current["settings"] == listing_reference["settings"] and current["attributes"] == listing_reference["attributes"],
            "listing settings/attributes differ from the sealed same-source no-route listing")
    phase_attributes = {"step", "FES_LABSTATE_V1"}
    require(baseline["attributes"]["step"] == "route" and current["attributes"]["step"] == "place" and
            "FES_LABSTATE_V1" not in current["attributes"] and
            {key: value for key, value in baseline["attributes"].items() if key not in phase_attributes} ==
            {key: value for key, value in current["attributes"].items() if key not in phase_attributes},
            "original top attributes changed outside the explicit phase/routed snapshot fields")
    def route_setting(key):
        return key in {"router", "compress_rbf"} or key.startswith(("gpurouter/", "router1/", "router/"))
    require(baseline["settings"]["router"] == "gpu" and current["settings"]["router"] == "router2" and
            "compress_rbf" not in current["settings"] and
            {key: value for key, value in baseline["settings"].items() if not route_setting(key)} ==
            {key: value for key, value in current["settings"].items() if not route_setting(key)},
            "original non-route settings changed")
    require({key: value for key, value in baseline.items() if key not in {"cells", "netnames", "ports", "settings", "attributes"}} ==
            {key: value for key, value in current.items() if key not in {"cells", "netnames", "ports", "settings", "attributes"}},
            "initial listing changed another module field")
    return {"local_clone_compositions_under_pin_assumptions": proofs, "original_nonbuffer_named_topology_preserved": True,
            "declared_local_clone_count": 3, "selected_ena_count": sum(proof["selected_ff_count"] for proof in proofs),
            "fourth_trial_owners_absent_after_rollback": True, "route_buffer_output_aliases_absent_in_listing": sorted(missing),
            "pin_state_export_available": False, "original_full_pin_preservation_proved": False,
            "top_metadata_phase_audit": {"current_settings_attributes_exactly_match_sealed_g8_listing": True,
                "listing_reference": relative(seal.LIST / "placed.json"), "original_non_route_settings_preserved": True,
                "original_attributes_preserved_except_phase_and_routed_snapshot": True,
                "phase_attribute_fields": sorted(phase_attributes), "routed_only_setting_keys":
                    sorted(set(baseline["settings"])-set(current["settings"])), "all_other_module_fields_identical": True},
            "listing_limitations": ["Physical pin states and route-created BUF population/users are absent and unproved.",
                                   "Current clone pins are assumed plain signals for the partial Boolean checks."]}


def current_terminal_guide(g8, measured, current, guide, cut, named_nets):
    """Check the exact relevant path's cells/ports/BELs/nets still exist now."""
    path = guide["critical_paths"][cut["guide_path_index"]]
    for row in path["path"]:
        for endpoint in (row["from"], row["to"]):
            name, pin = endpoint["cell"], endpoint["port"]
            require(name in current.cells and pin in current.cells[name]["port_directions"] and
                    g8.comb.cell_lab(current.cells[name]) == tuple(endpoint["loc"]) and
                    measured.cells[name]["type"] == current.cells[name]["type"] and
                    measured.cells[name]["parameters"] == current.cells[name]["parameters"],
                    "current fourth guide cell/port/LAB/type/parameters differ")
        if row["type"] == "routing":
            source, target = row["from"], row["to"]
            bits = current.cells[source["cell"]]["connections"][source["port"]]
            require(len(bits) == 1 and row["net"] in named_nets and
                    current.inputs(target["cell"])[target["port"]] == [current.token(bits[0])] and
                    [current.token(bit) for bit in named_nets[row["net"]]["bits"]] == [current.token(bits[0])],
                    "current fourth guide routing edge/net differs")
    for name in (cut["inner"], cut["outer"]):
        require(g8.connections(measured, name) == g8.connections(current, name), "current terminal LUT boundary identities changed")
    return {"current_reported_path_cell_ports_labs_types_params_and_routing_edges_match": True,
            "current_terminal_boundary_identities_match_measured_reference": True,
            "current_physical_pin_states_are_not_exported": True}


def comparison(folder):
    _, g8, base, base_proof, _ = seal.load_profile()
    require(sha(seal.FULL / "comparison.json") == FULL_PROOF_SHA and sha(seal.LIST / "comparison.json") == LIST_PROOF_SHA,
            "accepted measured cache changed")
    record = read(folder / "run.json")
    phase = seal.authenticate_phase(record)
    require(phase["phase"] == "list-local" and folder.resolve() == phase["folder"].resolve(),
            "this finalized empty-qualified experiment accepts only its initial listing")
    require(record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and record["elapsed_seconds"] >= 0,
            "listing is not complete")
    mutable = {"command", "remap_plan", "remap_plan_sha256", "decomposition_selection", "experimental_capture_locality",
               "experimental_placed_reduction", "retained_comb_report_sha256", "decomposition_report_sha256", "list_only",
               "fresh_listing", "execution", "input_sha256", "completed", "elapsed_seconds", "exit_code", "fmax",
               "final_reported_hold_violations", "kind", "runner_sha256"}
    require(all(record.get(key) == value for key, value in base.items() if key not in mutable), "undeclared inherited metadata change")
    g8.previous.authenticate_inputs(record)
    g8.ready.authenticate_execution(record, base)
    digests = {Path(filename): digest for filename, digest in record["input_sha256"].items()}
    digests.update({folder / name: sha(folder / name) for name in ("run.json", "route.log", "placed.json")})
    digests[Path(__file__).resolve()] = sha(Path(__file__).resolve())
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log and not any(row.startswith("ERROR:") for row in log.splitlines()),
            "listing lacks normal completion")
    require(not any(marker in log for marker in ("Info: Comb remap", "Info: Capture locality", "Info: Placed reduction",
            "Info: Balanced three-LUT reduction", "Info: Decomposition", "Running the GPU router", "Running signoff timing analysis")) and
            not any((folder / name).exists() for name in ("core.rbf", "routed.json", "timing.json")),
            "initial final-local listing executed a later transform/route/report")
    metrics = g8.previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and metrics == g8.previous.PLACEMENT_METRICS.findall((seal.FULL / "route.log").read_text()),
            "ordinary placement metrics changed")
    steps = phase["local_steps"]
    blocks = g8.staged.plan_blocks(log, steps)
    models = [g8.staged.selected_local(block, step) for block, step in zip(blocks[:3], steps[:3])]
    expected = [proof["selected_stage_log"] for proof in base_proof["retained_local_clone_equivalences"]]
    require(len(expected) == 3 and serial(models) == expected, "the preceding three local selections changed")
    final = blocks[3]
    require(final.count("Info: Local remap: 0 qualified candidates; no candidate applied.") == 1 and
            not any(marker in final for marker in ("Local remap trial", "Local remap candidate", "Local remap applied candidate")),
            "observed fourth listing is not the finalized empty/no-trial selection")
    measured_top, current_top = top(g8, seal.FULL, "routed.json"), top(g8, folder, "placed.json")
    require(all(cell["attributes"].get("NEXTPNR_BEL") for cell in current_top["cells"].values()), "unplaced listing cell")
    measured, current = netlist(g8, measured_top), netlist(g8, current_top)
    guide = g8.read(seal.FULL / "timing.json")
    cut = terminal_cut(g8, measured, guide, measured_top["netnames"])
    baseline = top(g8, g8.ready.BASE, "routed.json")
    partial = initial_listing_proof(g8, baseline, current_top, top(g8, seal.LIST, "placed.json"), steps[:3], models)
    guide_match = current_terminal_guide(g8, measured, current, guide, cut, current_top["netnames"])
    audit = g8.pll_port_audit(netlist(g8, baseline), current)
    require(all(sha(path) == digest for path, digest in digests.items()), "artifacts changed during comparison")
    return {"status": "completed fourth-local listing: zero qualified candidates; no later AC listing or full route",
            "phase": "list-local", "compiler_commit": base["compiler_commit"], "build_id": base["build_id"],
            "candidate_completed": True, "list_only": True, "elapsed_seconds": record["elapsed_seconds"], "exit_code": 0,
            "cached_full_graph_proof_sha256": FULL_PROOF_SHA, "cached_listing_proof_sha256": LIST_PROOF_SHA,
            "cached_reference_artifacts_reauthenticated": True, "cached_comparison_helpers_reexecuted": False,
            "matched_placement_metrics": 71, "placement_metrics_identical": True, "terminal_cut": cut,
            "current_terminal_guide": guide_match, "initial_original_nonbuffer_reference": relative(g8.ready.BASE / "routed.json"),
            "initial_partial_equivalence": partial, "lossless_pll_port_audit": audit,
            "qualified_target_local_ordinals": [], "fourth_qualified_candidate_count": 0, "fourth_logged_sta_trial_count": 0,
            "absence_of_trials_assessment": "No fourth-stage STA trial is logged. Guards before trial logging and site/global legality may skip silently; this log does not identify a unique reason or prove a modeled timing rejection.",
            "graph_proof_available": False, "partial_graph_evidence_available": True,
            "fourth_local_rollback_named_topology_proved": True, "full_physical_graph_preservation_proved": False,
            "route_started": False, "candidate_route": None, "candidate_accepted": False,
            "performance_acceptance_evaluated": False, "default_recipe_selected": False, "hardware_tested": False,
            "comparator_binding": "Final helper bytes bound at comparison time; initial compiler execution did not consume this helper.",
            "proof_limitations": ["No fourth clone was applied, so the 64 rows describe the expected terminal composition only.",
                                  "Listing lacks final physical pins, route-created BUFs, routed timing, holds and RBF evidence.",
                                  "Named topology/BEL/mask rollback is observed; JSON does not export owner buckets or indexed-store slots/free lists."],
            "artifact_sha256": {relative(path): digest for path, digest in digests.items()},
            "final_metadata_stable_during_comparison": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    folder = args.folder.resolve()
    result = comparison(folder)
    with (folder / "comparison.json").open("x") as output:
        output.write(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps({key: result[key] for key in ("phase", "graph_proof_available", "candidate_completed",
                                                "qualified_target_local_ordinals")}, indent=2))


if __name__ == "__main__":
    main()
