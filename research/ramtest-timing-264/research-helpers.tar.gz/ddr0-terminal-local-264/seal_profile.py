"""Root-only profile sealing and shared support for the fourth-local experiment."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
G8 = RAW / "ready-g8-decomposition-264"
FULL, LIST = G8 / "route-c0", G8 / "list"
PROFILE, HELPER = HERE / "profile.json", G8 / "compare_control_decomposition.py"
HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
PHASES = ("list-local", "list-ac", "route")
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata value: " + value)
    return json.loads(path.read_text(), object_pairs_hook=pairs, parse_constant=nonfinite)


def load_helper():
    require(sha(HELPER) == HELPER_SHA, "frozen groups8 helper changed")
    spec = importlib.util.spec_from_file_location("frozen_ddr0_terminal_reference", HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def authenticate_cached(folder, required=()):
    """Bind an already root-validated proof; never rerun its comparison helper."""
    proof, record = read(folder / "comparison.json"), read(folder / "run.json")
    require(proof["final_metadata_stable_during_comparison"] and proof["candidate_completed"] and
            record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0,
            "cached proof/run is not finalized")
    for filename, digest in proof["artifact_sha256"].items():
        path = (ROOT / filename).resolve()
        require(path.is_relative_to(ROOT) and sha(path) == digest, "cached artifact changed: " + filename)
    for path in (folder / "run.json", folder / "route.log", *required,
                 *(Path(path) for path in record["input_sha256"])):
        require(proof["artifact_sha256"].get(str(path.relative_to(ROOT))) == sha(path),
                "cached proof omits a required artifact/input")
    return record, proof


def authenticate_references(g8):
    base, full = authenticate_cached(FULL, [FULL / name for name in ("routed.json", "timing.json", "core.rbf")])
    listed, listing = authenticate_cached(LIST, [LIST / "placed.json"])
    require(base["compiler_commit"] == listed["compiler_commit"] == g8.RESULT_COMMIT and
            base["list_only"] is False and listed["list_only"] is True and not base["final_reported_hold_violations"] and
            full["graph_proof_available"] and full["actual_local_and_ac_selected_prefix_match_fresh_listing"] and
            full["local_clone_count"] == 3 and full["comb_clone_count"] == 1,
            "retained groups8+AC source/full proof changed")
    require(listing["partial_graph_evidence_available"] and not listing["graph_proof_available"] and
            listing["decomposition_selection"]["none_applied"] and
            listing["decomposition_selection"]["qualified_candidates"] > base["decomposition_selection"],
            "retained fresh listing does not qualify the measured AC")
    require(sha(G8 / "route.py") == g8.SEALED_RUNNER and
            full["artifact_sha256"].get(str(HELPER.relative_to(ROOT))) == HELPER_SHA, "retained helper/runner binding changed")
    plan = read(Path(base["command"][base["command"].index("--remap-plan") + 1]))
    require(plan == base["remap_plan"] and len(plan["steps"]) == 3 and
            [step["groups"] for step in plan["steps"]] == [8, 1, 1] and
            all(step["candidate"] == 0 and step["preserve_ff_placement"] is True and step["optimize_pins"] is False
                for step in plan["steps"]), "retained three-stage plan changed")
    return base, full, listing


def load_profile():
    profile = read(PROFILE)
    require(set(profile) == {"schema", "helper_sha256", "reference_full", "reference_listing", "base_plan",
                            "terminal_guide", "input_sha256"} and profile["schema"] == 1 and
            profile["helper_sha256"] == HELPER_SHA and profile["reference_full"] == str(FULL) and
            profile["reference_listing"] == str(LIST) and profile["terminal_guide"] == str(FULL / "timing.json"),
            "sealed fourth-stage profile changed")
    for filename, digest in profile["input_sha256"].items():
        require(sha(Path(filename)) == digest, "sealed input changed: " + filename)
    g8 = load_helper()
    base, full, listing = authenticate_references(g8)
    require(profile["base_plan"] == base["remap_plan"], "sealed base plan changed")
    return profile, g8, base, full, listing


def phase_folder(phase, localordinal, acordinal):
    require(phase in PHASES, "unknown phase")
    if phase == "list-local":
        require(localordinal == -1 and acordinal is None, "initial listing must select final local -1 only")
        return HERE / "list-local"
    require(type(localordinal) is int and 0 <= localordinal <= 2147483647, "invalid local candidate ordinal")
    if phase == "list-ac":
        require(acordinal == -1, "final fresh AC listing must select -1")
        return HERE / f"list-ac-c{localordinal}"
    require(type(acordinal) is int and 0 <= acordinal <= 2147483647, "invalid fresh AC candidate ordinal")
    return HERE / f"route-local{localordinal}-ac{acordinal}"


def make_plan(base, phase, localordinal):
    plan = copy.deepcopy(base["remap_plan"])
    require(len(plan["steps"]) == 3 and [step["groups"] for step in plan["steps"]] == [8, 1, 1], "base plan changed")
    plan["steps"].append({"report": str(FULL / "timing.json"), "candidate": -1 if phase == "list-local" else localordinal,
                          "groups": 1, "optimize_pins": False, "preserve_ff_placement": True})
    return plan


def expected_command(base, phase, localordinal, acordinal):
    folder = phase_folder(phase, localordinal, acordinal)
    old, command, index = base["command"], [base["command"][0]], 1
    require("--gpu-opt" not in old and "--no-route" not in old, "measured profile has unexpected route override")
    removed = {"--write", "--report", "--rbf", "--remap-decompose-critical", "--remap-decompose-candidate"}
    if phase != "route":
        removed |= {"--router", "--gpu-device"}
    if phase == "list-local":
        removed |= {"--remap-comb-critical", "--remap-comb-candidate"}
    while index < len(old):
        option = old[index]
        if option in removed:
            require(index + 1 < len(old), "missing base command value")
            index += 2
        elif option == "--compress-rbf" and phase != "route":
            index += 1
        elif option == "--remap-plan":
            command += [option, str(folder / "plan.json")]
            index += 2
        else:
            command.append(option)
            index += 1
    command += ["--write", str(folder / ("routed.json" if phase == "route" else "placed.json"))]
    if phase != "route":
        command += ["--no-route"]
    else:
        command += ["--report", str(folder / "timing.json"), "--rbf", str(folder / "core.rbf")]
    if phase != "list-local":
        guide = old[old.index("--remap-decompose-critical") + 1]
        command += ["--remap-decompose-critical", guide, "--remap-decompose-candidate", str(acordinal)]
    return command


def sealed_input_map(profile, phase, localordinal, acordinal):
    folder = phase_folder(phase, localordinal, acordinal)
    inputs = {**profile["input_sha256"], str(PROFILE): sha(PROFILE), str(folder / "plan.json"): sha(folder / "plan.json")}
    dependencies = [] if phase == "list-local" else [HERE / "list-local"]
    if phase == "route":
        dependencies.append(HERE / f"list-ac-c{localordinal}")
    for previous in dependencies:
        record, proof = authenticate_cached(previous, [previous / "placed.json"])
        require(record["profile_sha256"] == sha(PROFILE) and record["list_only"] is True and
                proof["partial_graph_evidence_available"] and not proof["graph_proof_available"], "listing prerequisite is not bound")
        if previous.name == "list-local":
            require(record["phase"] == "list-local" and localordinal in proof["qualified_target_local_ordinals"],
                    "requested local ordinal is not a freshly qualified target")
        else:
            require(record["phase"] == "list-ac" and record["local_candidate"] == localordinal and
                    acordinal in proof["qualified_ac_ordinals"], "requested AC ordinal is not freshly qualified")
        extra = {str(ROOT / path): digest for path, digest in proof["artifact_sha256"].items()}
        extra[str(previous / "comparison.json")] = sha(previous / "comparison.json")
        require(all(path not in inputs or inputs[path] == digest for path, digest in extra.items()), "listing input digest collision")
        inputs.update(extra)
    return inputs


def authenticate_phase(record):
    profile, g8, base, _, _ = load_profile()
    phase, local, ac = record["phase"], record["local_candidate"], record["decomposition_selection"]
    folder = phase_folder(phase, local, ac)
    plan_path = folder / "plan.json"
    require(record["command"] == expected_command(base, phase, local, ac) and record["remap_plan"] ==
            read(plan_path) == make_plan(base, phase, local) and record["remap_plan_sha256"] == sha(plan_path) and
            record["input_sha256"] == sealed_input_map(profile, phase, local, ac), "phase command/plan/input profile changed")
    require(record["list_only"] is (phase != "route") and record["fresh_listing"] is (phase != "route") and
            record["profile_sha256"] == sha(PROFILE) and record["reference_run_sha256"] == sha(FULL / "run.json") and
            record["runner_sha256"] == sha(HERE / "route.py") and record["fourth_local_report_sha256"] == sha(FULL / "timing.json"),
            "phase metadata aliases disagree")
    for key in ("experimental_capture_locality", "experimental_placed_reduction", "retained_comb_report_sha256",
                "decomposition_report_sha256"):
        require(record[key] == (None if phase == "list-local" else base[key]), "phase retained-transform metadata changed")
    steps = [{**step, "index": index, "report_path": Path(step["report"]), "report_json": g8.read(Path(step["report"])),
              "report_sha256": sha(Path(step["report"]))} for index, step in enumerate(record["remap_plan"]["steps"])]
    return {"phase": phase, "folder": folder, "local_plan_path": plan_path, "local_steps": steps,
            "local_selection": local, "ac_selection": ac}


def seal():
    require(not PROFILE.exists(), "profile already sealed")
    g8 = load_helper()
    base, full, listing = authenticate_references(g8)
    paths = {Path(path) for path in base["input_sha256"]}
    paths |= {ROOT / path for proof in (full, listing) for path in proof["artifact_sha256"]}
    paths |= {folder / "comparison.json" for folder in (FULL, LIST)}
    # The initial local listing can precede completion of the independent
    # comparator. Its final bytes are bound when that listing is compared,
    # then enter later executions through the listing proof artifact closure.
    paths |= {HERE / name for name in ("seal_profile.py", "route.py")}
    digests = {str(path): sha(path) for path in sorted(paths)}
    require(all(digests[path] == digest for path, digest in base["input_sha256"].items()), "retained inputs changed")
    profile = {"schema": 1, "helper_sha256": HELPER_SHA, "reference_full": str(FULL), "reference_listing": str(LIST),
               "base_plan": base["remap_plan"], "terminal_guide": str(FULL / "timing.json"), "input_sha256": digests}
    require(all(sha(Path(path)) == digest for path, digest in digests.items()), "inputs changed during sealing")
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"profile": str(PROFILE), "sha256": sha(PROFILE), "inputs": len(digests)}, indent=2))


if __name__ == "__main__":
    seal()
