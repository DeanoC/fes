# DDR0 terminal local-remap listing

The frozen `6ad210a60991f93a607ac4490d6282b1267ec64a` compiler completed the initial fourth-local listing in 525.293 seconds, exit 0. The fourth step produced **zero STA trials and zero qualified candidates**. No fourth clone was applied, and no final AC listing, full route, timing report or RBF was produced. The accepted g8 route remains the retained result.

The profile retains the first three local steps with group budgets 8/1/1, then requests a fourth final listing with candidate -1, groups 1, pin optimization disabled and original FF placement fixed. This initial listing intentionally omits the later comb, capture, placed-reduction and AC stages. The earlier local copies retain 21/2/10 selected ENAs; all 71 ordinary placement metrics match the authenticated g8 listing.

The completed [comparison](list-local/comparison.json) proves named original non-BUF topology, parameters, BELs, declared prior local rewires, lossless paired PLL-output evidence, and absence of fourth-trial owners after rollback. Its 32/16/16 prior-local truth checks explicitly assume the unserialized clone pins are plain signals. It reports `partial_graph_evidence_available=true`, `graph_proof_available=false`, no accepted candidate and no performance evaluation. Final physical pin states, route-created BUF population/users, routed timing, final holds and hardware behavior are unproved. JSON does not expose owner buckets or indexed-store slots/free lists.

The static exclusion is the protected carry LAB `(2,5)`: the target `ddr0_errors_MISTRAL_FF_Q_18` and `_Q_15` ENAs share it with four CI/CO-linked `MISTRAL_ALUT_ARITH` cells at COMB z=0/1/6/7. Packing assigns nonempty carry clusters (`mistral/pack.cc:1309,1317`). The frozen local-remap policy makes clustered cells immovable and protects their entire LAB (`mistral/local_remap.cc:58–64`); `safe_cell` and the FF-group check reject these target FFs before input collection or STA (`:88,151`). Zero trials therefore provide no modeled-gain, physical-timing rejection or ALUT6-capacity result.

The measured guide's terminal pair nevertheless has six raw and essential inputs. With boundary order `[a,R,x0,x1,x2,x3]`, its exact function is `(!a | R) & !(x0*x1*x2*x3)`, mask `0x0ddddddddddddddd`, with 45 true rows of 64. This is a proof of the retained function, not an applied fourth-stage rewrite or qualification.

Comparison retries are preserved: the first failed on a nonexistent placement-metric API in root execution history; [attempt 2](comparison-attempt-2.log) failed on nonexistent `Netlist.netnames`; [attempt 3](comparison-attempt-3.log) failed on the legitimate routed/listing metadata difference; [attempt 4](comparison-attempt-4.log) used unsupported `--phase`. Each failed before producing comparison evidence. [Attempt 5](comparison-attempt-5.log) completed after explicit API and phase-metadata corrections; the benchmark inputs and compiler were unchanged.

Bound SHA-256 identities:

| Artifact | SHA-256 |
| --- | --- |
| `list-local/comparison.json` | `b3cd35db5da7394c3d39795c37c14fd9b4edbfac44e8947e4d5dfc254b795760` |
| `compare.py` | `da51a76eaf0d6ed89cbdcb939f4efea1712690ee642e31c84b9653c252103aba` |
| `list-local/run.json` | `f26a5cb92429d96db82a022534c8f2fc02155dcd0702ac8c8d7e38dacc621ef5` |
| `list-local/route.log` | `4bf67c3524a6bbf31ec2184b05a9aa080646de7050f440bd4ce5a79ac76ed206` |
| `list-local/placed.json` | `6f742d7c4ad52b8baeedb6e32d658f0044969da006f01c33af62785f5ead6ec7` |

Only this ignored result note was written for this handoff. No source, frozen helper, existing proof, publication, default recipe or hardware state changed.
