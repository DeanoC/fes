# Retained-fit scalar DDR0 cmd_end data/control producer cones, including carry.
# Root runs this only against its authenticated private copy; no map/fit.
# Usage: quartus_cdb -t dump-ddr0-command-atoms.tcl project/top.qpf new/atoms
if {[llength $quartus(args)] != 2} {
    error "Usage: dump-ddr0-command-atoms.tcl project.qpf new-output-directory"
}
load_package atoms
set project [file normalize [lindex $quartus(args) 0]]
set output [file normalize [lindex $quartus(args) 1]]
if {[file exists $output]} {error "Refusing existing output directory: $output"}
file mkdir $output
set expected_build_id 52991ce22369904849b68bdd900f9ae1
set oss_build_id 7168b508ab424b70f1c0f87b2035d821
set qsf [file rootname $project].qsf
set qsf_file [open $qsf r]
set qsf_text [read $qsf_file]
close $qsf_file
set observed_build_id MISSING
regexp {RAMTEST_BUILD_ID=128'h([0-9a-fA-F]{32})} $qsf_text ignored observed_build_id
set observed_build_id [string tolower $observed_build_id]
set identity [open [file join $output identity.txt] {WRONLY CREAT EXCL}]
puts $identity "script [file normalize [info script]]"
puts $identity "project $project"
puts $identity "project_manifest [file join [file dirname [file dirname $project]] project-inputs.json]"
puts $identity "expected_quartus_build_id $expected_build_id"
puts $identity "observed_quartus_build_id $observed_build_id"
puts $identity "frozen_oss_build_id $oss_build_id"
puts $identity "classification retained-fit named-path/mapping hints only; different BUILD_ID/native PLL/SDC/timing models; no OSS calibration or hardware acceptance"
puts $identity "phase_encoding unknown; phase names do not establish original RTL bit equivalence after Quartus recoding"
puts $identity "atom_netlist_type cmp; all cmd_end FF inputs inventoried; CLK is not traversed; every other actual input producer seeds traversal; LCELL_COMB fanins expanded, all other types recorded leaves; max_cone_nodes=256"
puts $identity "property_states available, empty_or_unavailable, unavailable_error; empty values are never interpreted as zero"
if {[info exists quartus(version)]} {puts $identity "quartus_version $quartus(version)"}
set missing {}
foreach relative {top.qpf top.qsf db/top.cmp.hdb db/top.routing.rdb} {
    set path [file join [file dirname $project] $relative]
    if {![file isfile $path] || [file size $path] == 0} {
        lappend missing $relative
        puts $identity "input $relative MISSING_OR_EMPTY"
    } else {
        puts $identity "input $relative bytes=[file size $path] mtime=[file mtime $path]"
    }
}
close $identity
if {[llength $missing]} {error "Retained fitted inputs missing or empty: $missing"}
if {$observed_build_id != $expected_build_id} {error "Unexpected retained Quartus BUILD_ID: $observed_build_id"}

proc tsv {values} {
    set escaped {}
    foreach value $values {
        lappend escaped [string map [list "\\" "\\\\" "\t" "\\t" "\n" "\\n" "\r" "\\r"] $value]
    }
    return [join $escaped \t]
}
proc property {command} {
    if {[catch {uplevel #0 $command} value]} {return [list unavailable_error $value]}
    if {$value == ""} {return [list empty_or_unavailable {}]}
    return [list available $value]
}
proc required_node {node key} {
    set result [property [list get_atom_node_info -node $node -key $key]]
    if {[lindex $result 0] != "available"} {error "Required node property unavailable: node=$node key=$key result=$result"}
    return [lindex $result 1]
}
proc required_port_type {node port direction} {
    set result [property [list get_atom_port_info -node $node -port_id $port -type $direction -key type]]
    if {[lindex $result 0] != "available"} {error "Required port type unavailable: node=$node port=$port direction=$direction result=$result"}
    return [lindex $result 1]
}
proc port_fanin {node port} {
    set result [property [list get_atom_port_info -node $node -port_id $port -type iport -key fanin]]
    if {[lindex $result 0] == "unavailable_error"} {error "Cannot traverse missing fanin API: node=$node port=$port result=$result"}
    set source [lindex $result 1]
    if {[llength $source] != 0 && [llength $source] != 2} {error "Malformed native fanin: node=$node port=$port result=$result"}
    return $result
}
proc dump_port_properties {file node port direction} {
    if {$direction == "iport"} {
        set keys {type fanin delay literal_index is_inverted is_global get_global is_row_global is_logical_vcc is_logical_gnd IS_ENCRYPTED}
    } else {
        set keys {type name name_id fanout literal_index timing_node is_registered is_inverted is_global is_row_global is_auto_global is_observable lutmask IS_ENCRYPTED}
    }
    foreach key $keys {
        set result [property [list get_atom_port_info -node $node -port_id $port -type $direction -key $key]]
        puts $file [tsv [list $node $direction $port $key {*}$result]]
    }
}
proc dump_node_properties {file node} {
    # The installed Quartus 17.0 help explicitly supports node-specific legal
    # keys. Discover actual arithmetic/mode/LUT fields rather than guessing names.
    foreach key {NAME TYPE LOCATION} {
        set result [property [list get_atom_node_info -node $node -key $key]]
        puts $file [tsv [list $node $key {} {*}$result]]
    }
    set legal [property [list get_legal_info_keys -node $node -type ALL]]
    puts $file [tsv [list $node __LEGAL_KEYS__ {} {*}$legal]]
    if {[lindex $legal 0] != "available"} {return}
    foreach key [lsort -unique [lindex $legal 1]] {
        if {[regexp -nocase {^object} $key]} {
            set features [property [list get_legal_object_features -key $key -node $node -type ALL]]
            puts $file [tsv [list $node $key __LEGAL_FEATURES__ {*}$features]]
            if {[lindex $features 0] != "available"} {continue}
            foreach feature [lsort -unique [lindex $features 1]] {
                set result [property [list get_atom_node_info -node $node -key $key -feature $feature]]
                puts $file [tsv [list $node $key $feature {*}$result]]
            }
        } else {
            set result [property [list get_atom_node_info -node $node -key $key]]
            puts $file [tsv [list $node $key {} {*}$result]]
        }
    }
}

cd [file dirname $project]
project_open [file rootname [file tail $project]]
read_atom_netlist -type cmp
set inventory [open [file join $output endpoint-atoms.tsv] {WRONLY CREAT EXCL}]
puts $inventory "id\ttype\tname\tlocation_state\tlocation\trole\tnamed_phase_index\tcopy_suffix"
set captures {}
set phases {}
set named_phase2_originals {}
set original_command_count 0
set atom_count 0
foreach_in_collection node [get_atom_nodes] {
    incr atom_count
    set name [required_node $node NAME]
    if {![regexp {ddr0_test\|(phase\[|cmd_end(?:~|$)|cmd_addr\[|cmd_following|burst(?:\[|_|count))} $name]} {continue}
    set type [required_node $node TYPE]
    set role related_named_atom_not_a_selected_endpoint
    set bit {}
    set suffix {}
    if {$type == "FF" && [regexp {ddr0_test\|phase\[([0-9]+)\](~[^|]+)?$} $name ignored bit suffix]} {
        set role named_phase_original
        if {$suffix != ""} {set role named_phase_copy}
        lappend phases $node
        if {$bit == "2" && $suffix == ""} {lappend named_phase2_originals $node}
    }
    if {$type == "FF" && [regexp {ddr0_test\|cmd_end(~[^|]+)?$} $name ignored suffix]} {
        set role scalar_cmd_end_original
        if {$suffix != ""} {set role scalar_cmd_end_copy} else {incr original_command_count}
        lappend captures $node
    }
    set location [property [list get_atom_node_info -node $node -key LOCATION]]
    puts $inventory [tsv [list $node $type $name {*}$location $role $bit $suffix]]
}
close $inventory
if {![llength $phases] || $original_command_count != 1 ||
    [llength $phases] > 64 || [llength $captures] > 16 || [llength $named_phase2_originals] > 1} {
    project_close
    error "Named phase/scalar cmd_end FFs missing, ambiguous or beyond bounds; inspect endpoint-atoms.tsv"
}

# Inventory every capture input before selecting roots. The saved successful
# current-fit API spells the FF data port D, not DATAIN; no data-port name is
# assumed here. CLK is recorded but never traversed. ENA/SCLR/SDATA and any other
# actual nonclock FF input keep their own recorded source and type.
set endpoints [open [file join $output endpoint-inputs.tsv] {WRONLY CREAT EXCL}]
set port_properties [open [file join $output port-properties.tsv] {WRONLY CREAT EXCL}]
puts $endpoints "node\tport\ttype\ttraversal_role\tfanin_state\tfanin\tsource_name_state\tsource_name"
puts $port_properties "node\tdirection\tport\tkey\tstate\tvalue"
set seeds {}
set root_count 0
foreach node $captures {
    foreach port [get_atom_iports -node $node] {
        set type [required_port_type $node $port iport]
        set fanin [port_fanin $node $port]
        set source [lindex $fanin 1]
        set source_name [list empty_or_unavailable {}]
        if {[llength $source] == 2} {
            set source_name [property [list get_atom_node_info -node [lindex $source 0] -key NAME]]
        }
        set role no_native_source_recorded
        if {$type == "CLK"} {
            set role clock_recorded_not_traversed
        } elseif {[llength $source] == 2} {
            set role data_or_control_producer_seed
            lappend seeds [lindex $source 0]
            incr root_count
        }
        puts $endpoints [tsv [list $node $port $type $role {*}$fanin {*}$source_name]]
        dump_port_properties $port_properties $node $port iport
    }
}
close $endpoints
if {![llength $seeds]} {close $port_properties; project_close; error "No actual cmd_end nonclock producer roots"}
set queue $seeds
set seen [dict create]
while {[llength $queue]} {
    set node [lindex $queue 0]
    set queue [lrange $queue 1 end]
    if {[dict exists $seen $node]} {continue}
    dict set seen $node 1
    if {[dict size $seen] > 256} {
        close $port_properties; project_close
        error "cmd_end producer cone exceeded 256 atoms; no completion or truncated-cone claim is published"
    }
    if {[required_node $node TYPE] != "LCELL_COMB"} {continue}
    # Expand ALL real combinational input ports, so carry predecessors are not
    # dropped by a DATAA..DATAF-only or COMBOUT-only assumption.
    foreach port [get_atom_iports -node $node] {
        set fanin [port_fanin $node $port]
        set source [lindex $fanin 1]
        if {[llength $source] == 2} {lappend queue [lindex $source 0]}
    }
}

set nodes [open [file join $output cone-nodes.tsv] {WRONLY CREAT EXCL}]
set inputs [open [file join $output cone-inputs.tsv] {WRONLY CREAT EXCL}]
set outputs [open [file join $output cone-outputs.tsv] {WRONLY CREAT EXCL}]
set node_properties [open [file join $output node-properties.tsv] {WRONLY CREAT EXCL}]
puts $nodes "id\ttype\tname\tlocation_state\tlocation\ttraversal_role\tin_producer_cone\tphase_role"
puts $inputs "node\tport\ttype\tfanin_state\tfanin\tsource_name_state\tsource_name\texpanded_fanin"
puts $outputs "node\tport\ttype\tname_state\tname\tlutmask_state\tlutmask\tfanout_state\tfanout_count\tfanout"
puts $node_properties "node\tkey\tfeature\tstate\tvalue"
set comb_count 0
set leaf_count 0
set named_phase_in_cone {}
# Endpoint FFs and all named phase FFs are also dumped for placement/properties;
# their input connectivity is metadata only and is never expanded across FFs.
set selected [lsort -integer -unique [concat [dict keys $seen] $captures $phases]]
foreach node $selected {
    set type [required_node $node TYPE]
    set name [required_node $node NAME]
    set location [property [list get_atom_node_info -node $node -key LOCATION]]
    set in_cone [dict exists $seen $node]
    set role endpoint_or_named_phase_inventory_only
    if {$in_cone} {
        if {$type == "LCELL_COMB"} {set role expanded; incr comb_count} else {set role boundary_leaf; incr leaf_count}
    }
    set phase_role {}
    if {[lsearch -exact $phases $node] >= 0} {
        set phase_role actual_named_phase_FF
        if {$in_cone} {lappend named_phase_in_cone $node}
    }
    puts $nodes [tsv [list $node $type $name {*}$location $role $in_cone $phase_role]]
    dump_node_properties $node_properties $node
    foreach port [get_atom_iports -node $node] {
        set port_type [required_port_type $node $port iport]
        set fanin [port_fanin $node $port]
        set source [lindex $fanin 1]
        set source_name [list empty_or_unavailable {}]
        if {[llength $source] == 2} {
            set source_name [property [list get_atom_node_info -node [lindex $source 0] -key NAME]]
        }
        set expanded 0
        if {$in_cone && $type == "LCELL_COMB" && [llength $source] == 2} {set expanded 1}
        puts $inputs [tsv [list $node $port $port_type {*}$fanin {*}$source_name $expanded]]
        # Capture inputs already have full property rows above.
        if {[lsearch -exact $captures $node] < 0} {dump_port_properties $port_properties $node $port iport}
    }
    foreach port [get_atom_oports -node $node] {
        set port_type [required_port_type $node $port oport]
        set port_name [property [list get_atom_port_info -node $node -port_id $port -type oport -key name]]
        set mask [property [list get_atom_port_info -node $node -port_id $port -type oport -key lutmask]]
        set fanout [property [list get_atom_port_info -node $node -port_id $port -type oport -key fanout]]
        set fanout_count {}
        if {[lindex $fanout 0] == "available"} {set fanout_count [llength [lindex $fanout 1]]}
        puts $outputs [tsv [list $node $port $port_type {*}$port_name {*}$mask [lindex $fanout 0] $fanout_count [lindex $fanout 1]]]
        dump_port_properties $port_properties $node $port oport
    }
}
close $nodes
close $inputs
close $outputs
close $node_properties
close $port_properties
set summary [open [file join $output cone-summary.txt] {WRONLY CREAT EXCL}]
puts $summary "all_atoms $atom_count"
puts $summary "original_scalar_cmd_end_FFs $original_command_count"
puts $summary "cmd_end_FFs_including_copies [llength $captures]"
puts $summary "actual_named_phase_FFs [llength $phases]"
puts $summary "original_named_phase2_FFs [llength $named_phase2_originals]"
puts $summary "nonclock_input_producer_roots $root_count"
puts $summary "node_bound 256"
puts $summary "actual_producer_cone_nodes [dict size $seen]"
puts $summary "expanded_LCELL_COMB_nodes $comb_count"
puts $summary "boundary_leaf_nodes $leaf_count"
puts $summary "dumped_nodes_including_endpoint_and_phase_inventory [llength $selected]"
puts $summary "named_phase_FFs_in_actual_cone $named_phase_in_cone"
puts $summary "status completed bounded native-connectivity traversal; non-LCELL_COMB nodes are recorded unexpanded boundaries"
puts $summary "node_property_availability recorded individually; native empty values remain empty_or_unavailable, never zero"
puts $summary "no path sensitization or phase-encoding equivalence proved; separate TimeQuest reports required for timing; different Quartus/OSS BUILD_ID and native frames"
close $summary
project_close
