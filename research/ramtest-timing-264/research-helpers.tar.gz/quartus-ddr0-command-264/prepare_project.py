"""Copy the retained fit without refitting; root runs the actual queries."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
FES = HERE.parents[2]
OLD = HERE.parent / "quartus-ddr0-query-264"
MANIFEST = OLD / "project-inputs.json"
MANIFEST_SHA = "fdc653e9de0568fad1b749a25e01e03d987298e26b53ed9c51c5754cbb7e5575"

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def tree(root):
    paths = list(root.rglob("*"))
    if any(p.is_symlink() for p in paths):
        raise ValueError("fit tree contains a symlink")
    return {str(p.relative_to(root)): sha(p) for p in sorted(paths) if p.is_file()}

def main():
    if sha(MANIFEST) != MANIFEST_SHA:
        raise ValueError("closed prior fit input manifest changed")
    old = json.loads(MANIFEST.read_text())
    source = FES / "out/ramtest-compiler-gains/quartus-current-matched/project"
    expected = old["input_sha256"]
    if old["source"] != str(source) or len(expected) != 176 or tree(source) != expected:
        raise ValueError("retained fitted source differs from its closed manifest")
    target = HERE / "project"
    if target.exists():
        raise ValueError("new private project already exists")
    shutil.copytree(source, target)
    if tree(target) != expected or tree(source) != expected:
        raise ValueError("private fit copy or original fit changed")
    record = {"source": str(source), "private_copy": str(target),
        "input_sha256": expected, "source_manifest_path": str(MANIFEST),
        "source_manifest_sha256": MANIFEST_SHA, "root_preparer_sha256": sha(__file__),
        "classification": "Retained-fit command-cone hint only. Quartus BUILD_ID52991 differs from OSS7168; no refit, OSS timing calibration or hardware operation."}
    with (HERE / "project-inputs.json").open("x") as stream:
        stream.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"copied_files":len(expected),"manifest_sha256":sha(HERE/"project-inputs.json")},indent=2))

if __name__ == "__main__":
    main()
