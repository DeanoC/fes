"""Root executes retained-fit read queries; no mapping, fitting or hardware."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import prepare_project as prep

HERE = Path(__file__).resolve().parent
QUARTUS = Path("/home/deano/intelFPGA_lite/17.0/quartus/bin")
def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def main():
    manifest_path=HERE/"project-inputs.json"
    manifest=json.loads(manifest_path.read_text())
    source,target=Path(manifest["source"]),Path(manifest["private_copy"])
    expected=manifest["input_sha256"]
    if prep.tree(source)!=expected or prep.tree(target)!=expected:
        raise ValueError("original/private fitted inputs differ before read queries")
    record_path=HERE/"query-record.json"
    if record_path.exists():
        raise ValueError("query record already exists")
    scripts=[("timing","quartus_sta","query-ddr0-command-pins.tcl"),("atoms","quartus_cdb","dump-ddr0-command-atoms.tcl")]
    inputs={str(manifest_path):sha(manifest_path),str(Path(__file__).resolve()):sha(__file__),
        str(HERE/"prepare_project.py"):sha(HERE/"prepare_project.py")}
    for _,tool,script in scripts:
        inputs[str(HERE/script)]=sha(HERE/script)
        inputs[str(QUARTUS/tool)]=sha(QUARTUS/tool)
    inputs[str(HERE/"query-scope.md")]=sha(HERE/"query-scope.md")
    environment={"PATH":str(QUARTUS)+":/usr/bin:/bin", "LANG":"C", "LC_ALL":"C", "LC_CTYPE":"C",
        "QUARTUS_ROOTDIR_OVERRIDE":str(QUARTUS.parent)}
    if "HOME" in os.environ:
        environment["HOME"]=os.environ["HOME"]
    native_dir=QUARTUS.parent/"linux64"
    runtime_files=list(native_dir.glob("*.so*"))
    runtime_files += [QUARTUS.parent/"adm/qenv.sh",QUARTUS.parent/"adm/qtb.sh"]
    loader_environment={**environment,"LD_LIBRARY_PATH":str(native_dir)}
    for _,tool,_ in scripts:
        payload=native_dir/tool
        runtime_files.append(payload)
        dependencies=subprocess.check_output(["/usr/bin/ldd",str(payload)],env=loader_environment,text=True)
        dependency_log=HERE/(tool+"-ldd.txt")
        with dependency_log.open("x") as stream:
            stream.write(dependencies)
        inputs[str(dependency_log)]=sha(dependency_log)
        if "not found" in dependencies:
            raise ValueError("native Quartus dependency unresolved: "+tool)
        runtime_files += [Path(name) for name in re.findall(r"(?:=>\s+)?(/[^\s()]+)",dependencies)]
    for path in runtime_files:
        if path.is_file(): inputs[str(path)]=sha(path)
    def after_trees():
        rows={}
        for label,root in (("original",source),("private",target)):
            try:
                rows[label]={"file_sha256":prep.tree(root)}
            except BaseException as error:
                rows[label]={"error":repr(error)}
        return rows
    queries=[]
    try:
        for kind,tool,script in scripts:
            output=HERE/kind
            if output.exists():
                raise ValueError("query output already exists: "+str(output))
            command=[str(QUARTUS/tool),"-t",str(HERE/script),str(target/"top.qpf"),str(output)]
            started=time.monotonic()
            with (HERE/(kind+"-driver.log")).open("x") as log:
                result=subprocess.run(command,cwd=target,env=environment,stdout=log,stderr=subprocess.STDOUT,
                    check=False,timeout=300)
            queries.append({"kind":kind,"command":command,"exit_code":result.returncode,
                "elapsed_seconds":time.monotonic()-started})
            if result.returncode!=0:
                raise ValueError("actual retained-fit query failed: "+kind)
        original=prep.tree(source)
        private=prep.tree(target)
        changed=[name for name,expected_sha in expected.items() if private.get(name)!=expected_sha]
        critical=["top.qpf","top.qsf","clocks.sdc","db/top.cmp.hdb","db/top.cmp.cdb",
            "db/top.routing.rdb","db/top.sta_cmp.7_slow_1100mv_100c.tdb",
            "output_files/top.fit.rpt","output_files/top.map.rpt","output_files/top.rbf"]
        if original!=expected or any(name not in expected or private.get(name)!=expected[name] for name in critical):
            raise ValueError("original retained fit or critical private fitted bytes changed")
        for name,expected_sha in inputs.items():
            if sha(name)!=expected_sha:
                raise ValueError("query producer/tool input changed: "+name)
        outputs={str(p):sha(p) for kind,_,_ in scripts for p in (HERE/kind).rglob("*") if p.is_file()}
        outputs.update({str(HERE/(kind+"-driver.log")):sha(HERE/(kind+"-driver.log")) for kind,_,_ in scripts})
        record={"completed":True,"queries":queries,"input_sha256":inputs,"artifact_sha256":outputs,
            "operator_environment":environment,"project_trees_after":after_trees(),
            "runtime_scope":"Installed native payload/library files and ldd dependencies hashed; no loaded-library execution trace claimed.",
            "private_changed_input_files":changed,"private_additional_files":sorted(set(private)-set(expected)),
            "private_critical_fit_inputs_unchanged":True,"retained_source_inputs_unchanged":True,
            "refit_performed":False,"hardware_tested":False,
            "classification":manifest["classification"]}
        with record_path.open("x") as stream:
            stream.write(json.dumps(record,indent=2,sort_keys=True)+"\n")
        print(json.dumps({"completed":True,"queries":queries,"query_record_sha256":sha(record_path)},indent=2))
    except BaseException as error:
        failure={"completed":False,"queries":queries,"failure":repr(error),"input_sha256":inputs,
            "operator_environment":environment,"project_trees_after":after_trees()}
        with (HERE/"failed-query-record.json").open("x") as stream:
            stream.write(json.dumps(failure,indent=2,sort_keys=True)+"\n")
        raise

if __name__=="__main__":
    main()
