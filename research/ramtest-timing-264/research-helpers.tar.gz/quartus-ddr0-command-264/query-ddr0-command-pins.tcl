# Retained-fit named DDR0 phase registers -> scalar cmd_end input pins.
# Root runs this only against its authenticated private copy; no map/fit.
# Usage: quartus_sta -t query-ddr0-command-pins.tcl project/top.qpf new/timing
if {[llength $quartus(args)] != 2} {
    error "Usage: query-ddr0-command-pins.tcl project.qpf new-output-directory"
}
set project [file normalize [lindex $quartus(args) 0]]
set output [file normalize [lindex $quartus(args) 1]]
if {[file exists $output]} {error "Refusing existing output directory: $output"}
file mkdir $output
set expected_build_id 52991ce22369904849b68bdd900f9ae1
set oss_build_id 7168b508ab424b70f1c0f87b2035d821
set qsf [file rootname $project].qsf
set qsf_file [open $qsf r]
set qsf_text [read $qsf_file]
close $qsf_file
set observed_build_id MISSING
regexp {RAMTEST_BUILD_ID=128'h([0-9a-fA-F]{32})} $qsf_text ignored observed_build_id
set observed_build_id [string tolower $observed_build_id]
set identity [open [file join $output identity.txt] {WRONLY CREAT EXCL}]
puts $identity "script [file normalize [info script]]"
puts $identity "project $project"
puts $identity "project_manifest [file join [file dirname [file dirname $project]] project-inputs.json]"
puts $identity "expected_quartus_build_id $expected_build_id"
puts $identity "observed_quartus_build_id $observed_build_id"
puts $identity "frozen_oss_build_id $oss_build_id"
puts $identity "classification retained-fit named-path/mapping hints only; different BUILD_ID/native PLL/SDC/timing models; no OSS calibration or hardware acceptance"
puts $identity "phase_encoding unknown; phase names do not establish original RTL bit equivalence after Quartus recoding"
puts $identity "model slow temperature_C=100 voltage_mV=1100; npaths_per_query=8; setup_and_hold only, not asynchronous recovery/removal signoff"
if {[info exists quartus(version)]} {puts $identity "quartus_version $quartus(version)"}
set missing {}
foreach relative {top.qpf top.qsf clocks.sdc db/top.cmp.hdb db/top.routing.rdb db/top.sta_cmp.7_slow_1100mv_100c.tdb} {
    set path [file join [file dirname $project] $relative]
    if {![file isfile $path] || [file size $path] == 0} {
        lappend missing $relative
        puts $identity "input $relative MISSING_OR_EMPTY"
    } else {
        puts $identity "input $relative bytes=[file size $path] mtime=[file mtime $path]"
    }
}
close $identity
if {[llength $missing]} {error "Retained fitted inputs missing or empty: $missing"}
if {$observed_build_id != $expected_build_id} {error "Unexpected retained Quartus BUILD_ID: $observed_build_id"}

proc tsv {values} {
    set escaped {}
    foreach value $values {
        lappend escaped [string map [list "\\" "\\\\" "\t" "\\t" "\n" "\\n" "\r" "\\r"] $value]
    }
    return [join $escaped \t]
}
proc pin_property {pin option} {
    if {[catch {get_pin_info $option $pin} value]} {return [list unavailable_error $value]}
    if {$value == ""} {return [list empty_or_unavailable {}]}
    return [list available $value]
}
proc exact_pin_collection {name} {
    # cmd_end is scalar. Re-resolve and compare the actual name so a glob cannot
    # silently select another node if the implementation adds special characters.
    set pins [get_pins -compatibility_mode [list $name]]
    if {[get_collection_size $pins] != 1} {error "Pin did not re-resolve uniquely: $name"}
    foreach_in_collection pin $pins {
        if {[get_pin_info -name $pin] != $name} {error "Pin name mismatch while re-resolving: $name"}
    }
    return $pins
}

cd [file dirname $project]
project_open [file rootname [file tail $project]]
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist

# Inventory every actual named phase register, including fitter copies and
# additional bit indices produced by possible state recoding. No bit count or
# same-RTL encoding is inferred from the source's original [2:0] declaration.
set registers [get_registers {*ddr0_test*}]
set register_file [open [file join $output registers.tsv] {WRONLY CREAT EXCL}]
puts $register_file "id\tname\trole\tnamed_phase_index\tcopy_suffix"
set phase_bits [dict create]
set phase_names {}
set command_names {}
set original_command_count 0
set original_phase2_count 0
foreach_in_collection register $registers {
    set name [get_register_info -name $register]
    set bit {}
    set suffix {}
    if {[regexp {ddr0_test\|phase\[([0-9]+)\](~[^|]+)?$} $name ignored bit suffix]} {
        set role named_phase_original
        if {$suffix != ""} {set role named_phase_copy}
        lappend phase_names $name
        dict lappend phase_bits $bit $name
        if {$bit == "2" && $suffix == ""} {incr original_phase2_count}
    } elseif {[regexp {ddr0_test\|cmd_end(~[^|]+)?$} $name ignored suffix]} {
        set role scalar_cmd_end_original
        if {$suffix != ""} {set role scalar_cmd_end_copy} else {incr original_command_count}
        lappend command_names $name
    } else {continue}
    puts $register_file [tsv [list $register $name $role $bit $suffix]]
}
close $register_file
if {![llength $phase_names] || $original_command_count != 1 ||
    [llength $phase_names] > 64 || [llength $command_names] > 16 || $original_phase2_count > 1} {
    project_close
    error "Named phase/scalar cmd_end inventory missing, ambiguous or beyond bounds; inspect registers.tsv"
}

# Build query collections from retained names and check all selected members.
# '?' matches a literal bus bracket, as in the pinned successful DDR0 query.
set groups {}
set all_phase [get_registers {*ddr0_test|phase?*}]
set actual_names {}
foreach_in_collection register $all_phase {lappend actual_names [get_register_info -name $register]}
if {[lsort $actual_names] != [lsort $phase_names]} {
    project_close
    error "All-phase query differs from the enumerated actual phase register set"
}
lappend groups [list all_actual_phase_registers $all_phase $actual_names]
foreach bit [lsort -integer [dict keys $phase_bits]] {
    set selected [get_registers [list "*ddr0_test|phase?$bit?*"]]
    set actual_names {}
    foreach_in_collection register $selected {lappend actual_names [get_register_info -name $register]}
    if {[lsort $actual_names] != [lsort [dict get $phase_bits $bit]]} {
        project_close
        error "Phase-index query differs from the enumerated register set: $bit"
    }
    lappend groups [list "named_phase${bit}_original_and_copies" $selected $actual_names]
}
if {$original_phase2_count == 1} {
    set phase2 [get_registers {*ddr0_test|phase?2?}]
    if {[get_collection_size $phase2] != 1} {project_close; error "Original named phase2 did not resolve uniquely"}
    foreach_in_collection register $phase2 {
        set phase2_name [get_register_info -name $register]
        if {![regexp {ddr0_test\|phase\[2\]$} $phase2_name]} {project_close; error "Original phase2 query name mismatch"}
    }
    lappend groups [list named_phase2_original_only $phase2 [list $phase2_name]]
}

set pins [get_pins -compatibility_mode {*ddr0_test*}]
set pin_file [open [file join $output pins.tsv] {WRONLY CREAT EXCL}]
set properties [open [file join $output pin-properties.tsv] {WRONLY CREAT EXCL}]
puts $pin_file "id\tname\towner\trole\tsuffix\tinput_state\tinput_value\tclock_state\tclock_value"
puts $properties "id\tname\toption\tstate\tvalue"
set capture_pins {}
set command_pin_count 0
foreach_in_collection pin $pins {
    set name [get_pin_info -name $pin]
    if {![regexp {(.*ddr0_test\|cmd_end(?:~[^|]+)?)\|([^|]+)$} $name ignored owner suffix]} {continue}
    # Comb nodes with a cmd_end-derived name are not capture FFs. Keep only
    # the owners already enumerated as actual scalar command registers.
    set matched_owner 0
    foreach register_name $command_names {
        if {[string match "*$owner" $register_name]} {set matched_owner 1; break}
    }
    if {!$matched_owner} {continue}
    incr command_pin_count
    foreach option {-type -suffix -parent_cell -is_in_pin -is_out_pin -is_clock_pin} {
        set property [pin_property $pin $option]
        puts $properties [tsv [list $pin $name $option [lindex $property 0] [lindex $property 1]]]
        if {$option == "-is_in_pin"} {set input_property $property}
        if {$option == "-is_clock_pin"} {set clock_property $property}
    }
    if {[lindex $input_property 0] != "available" || [lindex $clock_property 0] != "available"} {
        close $pin_file; close $properties; project_close
        error "Cannot classify actual cmd_end pin: $name; see pin-properties.tsv"
    }
    set role output_or_other_pin
    if {[lindex $clock_property 1]} {
        set role clock_pin_not_queried
    } elseif {[lindex $input_property 1]} {
        set role actual_data_or_control_input
        lappend capture_pins [list $name [exact_pin_collection $name]]
    }
    puts $pin_file [tsv [list $pin $name $owner $role $suffix {*}$input_property {*}$clock_property]]
}
close $pin_file
close $properties
if {![llength $capture_pins] || $command_pin_count > 64} {
    project_close
    error "No actual cmd_end input pins or pin inventory beyond bound; inspect pins.tsv"
}
set counts [open [file join $output counts.txt] {WRONLY CREAT EXCL}]
puts $counts "all_ddr0_registers [get_collection_size $registers]"
puts $counts "actual_named_phase_registers [llength $phase_names]"
puts $counts "actual_named_phase_indices [lsort -integer [dict keys $phase_bits]]"
puts $counts "original_named_phase2_registers $original_phase2_count"
puts $counts "scalar_cmd_end_original_registers $original_command_count"
puts $counts "scalar_cmd_end_registers_including_copies [llength $command_names]"
puts $counts "actual_cmd_end_pins $command_pin_count"
puts $counts "queried_nonclock_input_pins [llength $capture_pins]"
puts $counts "source_groups [llength $groups]"
puts $counts "classification named-fit paths only; zero native path count is not a timing pass or semantic equivalence proof"
close $counts

set reports [open [file join $output reports.tsv] {WRONLY CREAT EXCL}]
puts $reports "ordinal\tsource_group\tsource_names\tcapture_pin\tcheck\tfile\tnative_result\tstatus"
set ordinal 0
foreach group $groups {
    lassign $group group_name sources source_names
    foreach capture $capture_pins {
        lassign $capture pin_name destinations
        foreach check {setup hold} {
            incr ordinal
            set filename [format "path-%03d-%s.rpt" $ordinal $check]
            set report [file join $output $filename]
            if {[file exists $report]} {close $reports; project_close; error "Refusing existing report: $report"}
            set result [report_timing -$check -from $sources -to $destinations -npaths 8 -detail full_path -show_routing -file $report]
            set status native_result_retained
            if {[lindex $result 0] == "0"} {set status native_no_path_not_a_pass}
            puts $reports [tsv [list $ordinal $group_name $source_names $pin_name $check $filename $result $status]]
        }
    }
}
close $reports
set completion [open [file join $output completion.txt] {WRONLY CREAT EXCL}]
puts $completion "status completed named-path queries"
puts $completion "reports $ordinal; native per-query path cap 8; not an exhaustive path proof"
puts $completion "phase_encoding not proved; different Quartus/OSS BUILD_ID and native timing frames"
close $completion
project_close
