# Retained Quartus DDR0 command-cone query

These new scripts query an existing fitted Quartus 17.0.2 Lite project. They
do not invoke analysis/synthesis, placement, routing, assembly, or hardware.
Root is the only operator. They have not been executed by their author.

The retained fit is
`out/ramtest-compiler-gains/quartus-current-matched/project/top.qpf` in the
compiler-gains FES worktree. Its QSF BUILD_ID must be
`52991ce22369904849b68bdd900f9ae1`. The frozen OSS comparison uses
`7168b508ab424b70f1c0f87b2035d821`, so the results are mapping and locality
hints, not a same-input numerical timing calibration. Native PLLs, SDCs,
timing models and routing/placement frames also differ.

Current RTL connects `ddr0_status[297:295]` to `ddr0_test.phase[2:0]` and loads
the scalar `cmd_end` from `burst_bytes == BYTES` or
`cmd_following == BASE + BYTES`. This identifies useful named endpoints; it
does not prove equivalence of fitted phase bits after Quartus state recoding.
The scripts retain every actual named phase FF/index/copy rather than assuming
there are exactly three fitted phase FFs. A missing named `phase[2]` is
recorded; an absent or ambiguous original scalar `cmd_end` aborts.

Root prerequisites:

1. Prepare a new private copy of the retained fitted project and authenticate
   every copied regular file against the original retained-fit manifest.
   Preserve the original project and all prior query outputs. The scripts
   do not copy projects or authenticate file contents themselves.
2. Record the exact script bytes, Quartus executable/launcher/library bytes,
   input-project manifest, environment and command before execution. Use the
   already installed `/home/deano/intelFPGA_lite/17.0/quartus/bin` tools.
3. Use distinct nonexistent output directories. Each script rejects an
   existing output directory and creates result files exclusively. Retain
   complete stdout/stderr and actual exit status, including API warnings.
4. Compare original and private project manifests afterward. STA can update
   private timing caches even though it does not refit. Do not claim the
   original fit was untouched without the actual before/after comparison.

Root-only invocations, using absolute paths to the authenticated new copy:

```sh
/home/deano/intelFPGA_lite/17.0/quartus/bin/quartus_sta -t \
  /absolute/quartus-ddr0-command-264/query-ddr0-command-pins.tcl \
  /absolute/quartus-ddr0-command-264/project/top.qpf \
  /absolute/quartus-ddr0-command-264/timing

/home/deano/intelFPGA_lite/17.0/quartus/bin/quartus_cdb -t \
  /absolute/quartus-ddr0-command-264/dump-ddr0-command-atoms.tcl \
  /absolute/quartus-ddr0-command-264/project/top.qpf \
  /absolute/quartus-ddr0-command-264/atoms
```

`query-ddr0-command-pins.tcl` uses the successful retained query's
`get_registers`, `get_pins -compatibility_mode`, bus-bracket `?` matching,
`create_timing_netlist -model slow -temperature 100 -voltage 1100`, `read_sdc`,
and `update_timing_netlist` APIs. It checks query collections against actual
enumerated names. It inventories all real scalar `cmd_end` FF pins, including
copies, and reports setup and hold from all named phase FFs, each actual
phase-index group including copies, and original named `phase[2]` if present,
to every nonclock input. Clock and output pins remain in the inventory.
Each report keeps up to eight native paths with full clock/path and routing
detail. Native zero-path results are explicitly not timing passes. These are
bounded named-path queries, not exhaustive path enumeration or asynchronous
recovery/removal signoff. Native constraints and model remain unchanged.

`dump-ddr0-command-atoms.tcl` uses `read_atom_netlist -type cmp`. It inventories
all actual command FF inputs before traversing producer cones from every
nonclock input. CLK is recorded but not traversed. All actual LCELL_COMB
fanin ports are expanded, including carry predecessors; every other atom type
is a recorded boundary. The union of producer cones is bounded to 256 atoms;
an overflow aborts without publishing a completion summary. Endpoint and
named phase FF placement/property inventories are additional marked rows,
never traversed across FF boundaries.

All actual input/output port properties documented by the installed 17.0
`atoms.cmds.advanced.hlp` are retained, including inversion, constants,
fanins/fanouts, output masks where available, and routing-delay metadata.
Node properties are discovered with `get_legal_info_keys -node ... -type ALL`
and object features with `get_legal_object_features`. No arithmetic mode-key
name is guessed. Fields record `available`, `empty_or_unavailable`, or
`unavailable_error`; errors retain their messages. An empty native value or
unavailable mask/property is never converted to zero. Missing required node
names/types or traversal fanin API errors abort. Native API warnings remain
in the operator logs. Atom values and combinational connectivity do not by
themselves prove path sensitization, arithmetic equivalence, or encoding.

The templates are the immutable prior
`quartus-ddr0-query-264/query-ddr0-exact-pins.tcl`
(SHA256 `b344566b0165017fe96f25948c08e8937f774590a71850c89b214f1119166725`)
and `dump-ddr0-atoms.tcl`
(`5891bc3ed662ebe6b423f871f09b9e6e4b13f68f947785e9a22a507a1edba2ff`).
Those outputs concern `group_bad[11] -> errors[18].ENA`, not the command cone.
The retained fitter's burst-enable fanouts of six/seven must not be equated
with the OSS burst decoder's 49 users. No source changes, OSS route, new
timing gain, compiler qualification or hardware acceptance are claimed here.
