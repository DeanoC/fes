# Disabled joint-LUT placement control

This new run_baseline.py records one fresh ten-stage predicted control with
the optional joint-LUT pass disabled. ROOT will freeze its UNFROZEN identity
constants to the actual selected compiler commit, production ELF, Git archive,
host validation, test ELF and check-results bytes after successful current
native and CLI checks. It must remain inactive until then and until whole-file
review of those final bytes is complete.

Preparation binds this helper and scope, the selected current host/source
closure, all original ten-stage input/descriptor bytes, the old closed d7e5
ten-stage run and exact native prefix proof, original runtime files, and pinned
pure qualification parser definitions. It preserves the literal ten-step plan
and saved argv. The only executable/PATH change is the new compiler. Only write
and report outputs point at this new exclusive baseline directory. The same
device, seed, complete source netlist, QSF/SDC, diagnostic environment, cwd and
read-audit/project helpers remain selected. There is no post-plan, pair, driver,
placement replay, RBF output or routing in the command.

Preparation writes only a new source-identity.json. Execution accepts its
explicit SHA and requires fresh outputs, the exact command/profile/helper/host
pins, clean selected current source/model/submodules, the exact loaded project
helper bytes and actual FunctionalInvocation runtime before audited_run. It
records actual return code, elapsed time, read audit, all ten complete local
qualification models, the complete predicted report and output hashes. All
original input and loaded-runtime bytes are rechecked before and after the run.
Failure preserves actual available outputs and distinguishes adapter sentinel
codes. Existing frozen controls, archives and logs are unchanged.

Old qualification modules are loaded only for their pinned pure parsing
definitions. Their old main, preparation, execution, host/source authorization
and generator entrypoints are never invoked. This is a newly reviewed helper
with its own entrypoints; it does not reuse old control authorization.

This run establishes closed execution only. A separate new comparator must
prove exact native module/owner/port ordering, raw IDs and complete slots,
paired PLL entries, all original FF placements, ten qualification models,
placement metrics and complete predicted report against the closed b3d control
as well as the older d7e5 control. Only the creator version string differs as
compiler provenance. No structural waiver or raw-ID normalization is allowed.
Neither closed execution nor predicted parity proves physical equivalence,
independent numerical STA, a routed gain or hardware acceptance. Any enabled
pair listing/selection and routed timing qualification are separate fresh runs.
