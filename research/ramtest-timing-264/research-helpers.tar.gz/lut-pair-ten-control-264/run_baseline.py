"""Record the unchanged ten-stage predicted control with joint LUT placement disabled."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-placement-264"
COMPILER = RAW / "lut-pair-placement-264"
COMMIT, BASE = "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc", "b3d036549c29a333e67c61bd1b23e705bce75d41"
OLD_COMMIT = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA = "1b4e45ac1adc5adf9be8edcfa67b922d7626504dc0bbc73f24ffb69b263f4b1f"
ARCHIVE_SHA = "2c8c190cab4556232cf0230213a83122fc22af6af19b76590392732eb6df6c8c"
HOST, HOST_SHA = COMPILER / "validation/host-validation.json", "c77030ec24ef18fc1dc64f85ad05b3e0841866cb9d03ecf46c7cc75586f415d6"
HOST_HELPER_SHA, HOST_SCOPE_SHA = "80af57eefb926577426c7043e46a438b938c282b5bb57d87301e88a9a7467d1c", "a32cf00ffef05c9260c2b1ffea9668bd83db231bc35a89e10fb6741b5eb98c98"
OLD_FOLDER = RAW / "local-plan16-ready1-command-stage-264"
OLD, OLD_SHA = OLD_FOLDER / "baseline/run.json", "3d69a28a7fb1741349f1b4e77be6f13bbdae21dfeb4bacd77ef5f5862059ad11"
OLD_PROFILE_SHA = "77fd5636a7947d349605147bc164ba7cf562dc5885aa09072a1cc2945931e546"
OLD_PREFIX, OLD_PREFIX_SHA = OLD_FOLDER / "baseline/comparison-prefix-v2.json", "bf9d312c140f349f75244c087be5a90f59c6fb6a87d28437051936f178884fe3"
OLD_PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
OLD_BINARY = RAW / "remap-plan16-264/nextpnr-mistral"
OLD_BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
OLD_ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "baseline"
PARSERS = (
    (OLD_FOLDER / "run_baseline.py", "7a00db6a5bb6f045bfdac8805f234e16b9d67d75cbe13e52db912b7361a595e5"),
    (RAW / "local-plan16-ready1-skid-byte-stage-264/run_baseline.py", "51ff54f38b122f9d6bef47b2feb9a64916855b3523215df8b06e0c3cc99dd487"),
    (RAW / "local-plan16-eight-control-264/run_baseline.py", "b5e0f6ad4b09c3d051174e9dd4409f9f02c030a0db9b6626741dec7c715a5749"),
    (RAW / "local-multicopy-port0-skid-address-stage-264/run_baseline.py", "a7ef2ec62622491626357ff5ddf8fc6bb689a7f26a0d773f125b055c7a24ecff"),
    (RAW / "local-multicopy-ready1-byteenable-stage-264/run_baseline.py", "abd9832d33e9705a75deb404b7349282921ff5321216b4ec8d526391e90040bd"),
    (RAW / "local-multicopy-port0-burst-stage-264/run_baseline.py", "57ec4a9c788d3fbf59f1a5123ee1f197bb967f4390fb4daf9642345aee6b0362"),
    (RAW / "local-multicopy-ready1-address-stage-264/run_baseline.py", "a2d626253826a6b187713f42904720ecdb1d06754ab2776c1fa9d7b39437e2f4"),
    (RAW / "local-multicopy-ready1-264/run_baseline.py", "440013e34d68841d103ca0bea4e3d927a9fd9f50917e10800ad604caa1aec36a"))
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}
CHANGED = {"mistral/CMakeLists.txt", "mistral/arch.h", "mistral/arch.cc", "mistral/lut_driver_copy.cc",
    "mistral/main.cc", "mistral/lut_pair_placement.cc", "mistral/lut_pair_placement.h", "mistral/remap_clock_guard.h",
    "mistral/tests/lut_pair_placement.cc", "mistral/tests/lut_pair_placement_cli.py", "mistral/lut_pair_placement.md"}
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
COHORT_COUNTS = [21, 2, 10, 1, 6, 1, 1, 3, 2, 8]


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original path hash")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution entry is not absolute"); bind(inputs, name, expected)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def definitions():
    modules = tuple(load(path, expected, "pair_ten_control_parser_" + str(i)) for i, (path, expected) in enumerate(PARSERS))
    return modules[0], modules[1], modules[2], modules[3:]


def qualification(log, definitions):
    tenth, ninth, control, parsers = definitions
    return tenth.qualification(log, ninth, control, parsers)


def validate_host(host):
    counts = {"pair_backend": 12, "native_plan": 25, "driver_backend": 10, "pair_cli": 11, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and
        host["test_binary_sha256"] == "5221d767e061623bb48699370b548cb2d5fa76291d318f3af20da64a1c0ae41f" and
        host["check_results_sha256"] == "ca75e70399796e6937e9925d6470ff84916630abab741faae2b54177f687ae2d" and
        host["clean_committed_checkout"] is host["build_passed"] is True and host["generator_sha256"] == HOST_HELPER_SHA and
        host["scope_sha256"] == HOST_SCOPE_SHA and set(host["changed_source_files"]) == CHANGED and set(host["checks"]) == set(counts) and
        all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()), "new host identity/checks differ")
    require(host["build_dependency_manifest_sha256"] and host["build_dependency_file_sha256"] and host["committed_archive_manifest_sha256"] and
        all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in host["committed_archive_manifest_sha256"]), "current dependency/archive closure absent")


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == CHANGED,
        "current source is not its exact clean committed host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
        [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def command(old):
    result = list(old["command"])
    require(result[0] == str(OLD_BINARY) and result.count("--no-route") == result.count("--remap-plan") == 1 and
        result[result.index("--remap-plan") + 1] == str(OLD_FOLDER / "local-plan.json") and not any(flag in result for flag in
        ("--remap-post-plan", "--rbf", "--remap-lut-pair-critical", "--remap-lut-pair-candidate", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "old command role differs")
    result[0] = str(BINARY)
    for flag, path in (("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector"); result[result.index(flag) + 1] = str(path)
    return result


def expected_execution(old):
    result = copy.deepcopy(old["execution"])
    require(result["files"].pop(str(OLD_BINARY)) == OLD_BINARY_SHA and str(BINARY) not in result["files"] and
        result["environment"]["PATH"] == str(OLD_BINARY.parent) + ":/usr/bin:/bin" and result["gpu_device"] == 1, "old compiler/PATH/device differs")
    result["files"][str(BINARY)] = BINARY_SHA; result["files"] = dict(sorted(result["files"].items()))
    result["environment"]["PATH"] = str(BINARY.parent) + ":/usr/bin:/bin"
    return result


def prepare(self_sha, scope_sha, binary_sha, archive_sha, host_sha):
    require(binary_sha == BINARY_SHA and archive_sha == ARCHIVE_SHA and host_sha == HOST_SHA and
        not PROFILE.exists() and not FOLDER.exists(), "actual compiler/host pins and exclusive outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (OLD, OLD_SHA),
        (OLD_FOLDER / "source-identity.json", OLD_PROFILE_SHA), (OLD_PREFIX, OLD_PREFIX_SHA),
        (HOST, host_sha), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (BINARY, binary_sha), (ARCHIVE, archive_sha), *PARSERS): bind(inputs, path, expected)
    original, old, prefix, host = (read(path) for path in (OLD_FOLDER / "source-identity.json", OLD, OLD_PREFIX, HOST))
    validate_host(host); adopt(inputs, prefix)
    require(old["completed"] is True and old["exit_code"] == 0 and old["compiler_read_audit_passed"] is old["final_original_input_output_runtime_hashes_stable"] is True and
        old["source_identity_sha256"] == OLD_PROFILE_SHA and old["compiler_commit"] == OLD_COMMIT and old["binary_sha256"] == OLD_BINARY_SHA and
        old["source_archive_sha256"] == OLD_ARCHIVE_SHA and old["cwd"] == str(MODULE) and old["execution"] == original["baseline_execution"] and
        old["input_sha256"] == {**original["input_sha256"], str(OLD_FOLDER / "source-identity.json"): OLD_PROFILE_SHA} and
        all(canonical(old[key]) == canonical(value) for key, value in original.items() if key != "input_sha256") and
        not any(key in old for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "old ten-stage profile/run is not closed")
    require(prefix["phase"] == "local-plan16-ready1-command-tenth-stage-explicit-private-owner-native-prefix" and
        prefix["compiler_commit"] == OLD_COMMIT and prefix["source_identity_sha256"] == OLD_PROFILE_SHA and prefix["current_baseline_run_sha256"] == OLD_SHA and
        prefix["generator_sha256"] == "adcf038706860a70fa8d11d54d2d37eeb09a35c426ed84ac6776f7bf22c3d130" and
        prefix["scope_sha256"] == "e2059c34f1f0a9228f4d51d02dffb1c55c3e004661d571f8bd661b983f6692d0" and
        prefix["structural_rejection"] is prefix["native_path_topology_rejection"] is None and all(prefix[key] is True for key in
        ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
         "all_nine_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "final_original_path_metadata_and_runtime_hashes_stable")), "closed old native prefix differs")
    for ledger in (old["input_sha256"], old["output_sha256"], old["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original host/control pathname is not absolute"); bind(inputs, path, expected)
    plan_path = OLD_FOLDER / "local-plan.json"; bind(inputs, plan_path, OLD_PLAN_SHA); plan = read(plan_path)
    require(set(plan) == {"steps"} and plan["steps"] == old["local_plan_steps"] == original["local_plan_steps"] and len(plan["steps"]) == 10 and
        [step["groups"] for step in plan["steps"]] == [8] + [1] * 9 and all(set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and
        step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True and step["report"] in inputs for step in plan["steps"]), "literal old ten descriptors differ")
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    runtime = expected_execution(old)
    for path, expected in runtime["files"].items(): bind(inputs, path, expected)
    modules = definitions(); models = qualification((OLD.parent / "phase.log").read_text(), modules)
    require(canonical(models) == canonical(old["actual_selected_local_qualification"]) == canonical(prefix["fresh_local_models"]) and len(models) == 10, "old complete ten models differ")
    graph = prefix["native_graph_evidence"]; copies = copy.deepcopy(graph["retained_copy_cohorts"])
    new_slots = [[row["cell"], row["port"], row["vector_index"], row["occurrence"]] for row in graph["declared_ena_redirects"]]
    copies.append({"cell": graph["new_clone"], "record": graph["actual_new_clone_record"], "consumer_slots": new_slots})
    require(len(copies) == 10 and [len(row["consumer_slots"]) for row in copies] == COHORT_COUNTS and
        all(row["record"]["attributes"]["NEXTPNR_BEL"] == model["bel"] for row, model in zip(copies, models)) and
        len(old["all_original_ff_bel_manifest"]) == 8221, "ten retained copy cohorts/all FF manifest differ")
    profile = {"schema": 1, "phase": "lut-pair-disabled-ten-stage-predicted-control", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": binary_sha, "source_archive_sha256": archive_sha,
        "host_validation_path": str(HOST), "host_validation_sha256": host_sha, "current_host_case_counts": {key: row["cases"] for key, row in host["checks"].items()},
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "previous_source_identity_sha256": OLD_PROFILE_SHA,
        "previous_baseline_run_sha256": OLD_SHA, "previous_prefix_proof_sha256": OLD_PREFIX_SHA,
        "original_plan_path": str(plan_path), "original_plan_sha256": OLD_PLAN_SHA, "local_plan_steps": plan["steps"],
        "retained_local_models": models, "retained_copy_cohorts": copies, "all_original_ff_bel_manifest": old["all_original_ff_bel_manifest"],
        "command": command(old), "cwd": old["cwd"], "diagnostic_environment": old["diagnostic_environment"], "baseline_execution": runtime,
        "authorized_runtime_delta": {"old_compiler_path": str(OLD_BINARY), "new_compiler_path": str(BINARY), "old_compiler_sha256": OLD_BINARY_SHA,
            "new_compiler_sha256": binary_sha, "controlled_path_directory_replaced": True, "all_other_execution_fields_and_files_exact": True},
        "committed_archive_member_sha256": host["committed_archive_manifest_sha256"], "input_sha256": dict(sorted(inputs.items())),
        "post_plan_requested": False, "lut_pair_requested": False, "driver_pass_executed": False, "native_graph_or_physical_equivalence_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "original_plan_path": str(plan_path)}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, old, host = read(PROFILE), read(OLD), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    validate_host(host)
    require(not FOLDER.exists() and profile["command"] == command(old) and profile["baseline_execution"] == expected_execution(old) and
        profile["diagnostic_environment"] == old["diagnostic_environment"] and profile["cwd"] == old["cwd"] == str(MODULE) and
        profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and profile["post_plan_requested"] is profile["lut_pair_requested"] is False and
        inputs[str(OLD)] == profile["previous_baseline_run_sha256"] == OLD_SHA and inputs[str(OLD_PREFIX)] == profile["previous_prefix_proof_sha256"] == OLD_PREFIX_SHA and
        inputs[str(HOST)] == profile["host_validation_sha256"] == HOST_SHA and inputs[str(BINARY)] == profile["binary_sha256"] == BINARY_SHA and
        inputs[str(ARCHIVE)] == profile["source_archive_sha256"] == ARCHIVE_SHA and inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and
        inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and inputs[profile["original_plan_path"]] == OLD_PLAN_SHA and
        read(profile["original_plan_path"])["steps"] == profile["local_plan_steps"] and len(profile["local_plan_steps"]) == 10, "frozen control helper/profile/command/host/runtime differs")
    modules = definitions(); clean_source(host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "loaded runtime differs beyond compiler/PATH")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "disabled-pair ten-stage control did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(label in log for label in ("Local-remap post-plan step", "Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "LUT pair placement")) and
            not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual control is not predicted-only with post/pair/driver disabled")
        models = qualification(log, modules); record["actual_selected_local_qualification"] = models
        record["all_ten_complete_trial_models_exact"] = canonical(models) == canonical(profile["retained_local_models"])
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "predicted cap/count/Fmax invalid")
        record["actual_predicted_fmax"], record["output_sha256"] = report["fmax"], {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "predicted output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "all_ten_complete_trial_models_exact": record["all_ten_complete_trial_models_exact"], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "binary-sha256", "archive-sha256", "host-sha256", "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.binary_sha256, args.archive_sha256, args.host_sha256)
        require(all(values), "actual preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
