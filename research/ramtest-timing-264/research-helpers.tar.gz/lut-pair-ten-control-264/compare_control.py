"""Compare a disabled joint-placement ten-stage control with both closed controls."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE, RUN, RUNNER = HERE / "source-identity.json", HERE / "baseline/run.json", HERE / "run_baseline.py"
COMPILER = RAW / "lut-pair-placement-264"
COMMIT, BASE = "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc", "b3d036549c29a333e67c61bd1b23e705bce75d41"
BINARY_SHA, ARCHIVE_SHA, HOST_SHA = "1b4e45ac1adc5adf9be8edcfa67b922d7626504dc0bbc73f24ffb69b263f4b1f", "2c8c190cab4556232cf0230213a83122fc22af6af19b76590392732eb6df6c8c", "c77030ec24ef18fc1dc64f85ad05b3e0841866cb9d03ecf46c7cc75586f415d6"
TEST_SHA, CHECKS_SHA = "5221d767e061623bb48699370b548cb2d5fa76291d318f3af20da64a1c0ae41f", "ca75e70399796e6937e9925d6470ff84916630abab741faae2b54177f687ae2d"
HOST = COMPILER / "validation/host-validation.json"
HOST_HELPER_SHA = "80af57eefb926577426c7043e46a438b938c282b5bb57d87301e88a9a7467d1c"
HOST_SCOPE_SHA = "a32cf00ffef05c9260c2b1ffea9668bd83db231bc35a89e10fb6741b5eb98c98"
OLD_FOLDER = RAW / "local-plan16-ready1-command-stage-264"
OLD, OLD_PROFILE, OLD_PREFIX = OLD_FOLDER / "baseline/run.json", OLD_FOLDER / "source-identity.json", OLD_FOLDER / "baseline/comparison-prefix-v2.json"
OLD_SHA = "3d69a28a7fb1741349f1b4e77be6f13bbdae21dfeb4bacd77ef5f5862059ad11"
OLD_PROFILE_SHA = "77fd5636a7947d349605147bc164ba7cf562dc5885aa09072a1cc2945931e546"
OLD_PREFIX_SHA = "bf9d312c140f349f75244c087be5a90f59c6fb6a87d28437051936f178884fe3"
OLD_PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
OLD_COMMIT = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
OLD_BINARY = RAW / "remap-plan16-264/nextpnr-mistral"
OLD_BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
OLD_ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
POST_FOLDER = RAW / "post-remap-plan-ten-control-264"
POST, POST_PROFILE, POST_PROOF = POST_FOLDER / "baseline/run.json", POST_FOLDER / "source-identity.json", POST_FOLDER / "baseline/comparison-control.json"
POST_SHA = "3eb274cc9d2d2a40ba348e35b0055b14f0d39edc035ac8c49b8dc7da13b27dee"
POST_PROFILE_SHA = "2294abbbadb2d74df4657344f841a2dcbaaf57854e33d7484a5e3e7841f9ab06"
POST_PROOF_SHA = "323846d51ef9c76047ba243f55d7505395fcb793dab4b32dd963f56c72b0a746"
POST_GENERATOR_SHA = "a03142215d8b205931d877af26dce1af5ed54854bfd8fc388553340dadad4c85"
POST_SCOPE_SHA = "bdd231b06c1a8b6e74d729194a2058e1d70f23dac38b84072ef5197bab571e6b"
POST_BINARY = RAW / "post-remap-plan-264/nextpnr-mistral"
POST_BINARY_SHA = "0c8805598c4e59ad77683956cdc1739b8d2ed183c73eab51c85c9b7a52ea18ad"
POST_ARCHIVE_SHA = "338f71f67188fa29dbb9f6fa616f6d33f4bc926b3acd00bfb5122ef543a8c2fb"
POST_HOST_SHA = "3751b2ebc0c0f802ac2b4251150a693764487939c0b08e42fe100c2047eb6fe0"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
             "build_dependency_manifest_sha256", "build_dependency_file_sha256")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def bind_absolute(audit, ledger, runtime=False):
    for name, expected in ledger.items():
        path = Path(name)
        require(path.is_absolute(), "flat original pathname is not absolute")
        audit.bind(path, expected, execution=runtime or not path.resolve().is_relative_to(ROOT))


def bind_proof(audit, proof):
    for name, expected in proof["artifact_sha256"].items():
        path = Path(name)
        require(not path.is_absolute() and ".." not in path.parts, "flat proof artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    bind_absolute(audit, proof["execution_file_sha256"], True)


def closed_record(native, record, profile, profile_path, profile_sha):
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == profile_sha and
            record["execution"] == profile["baseline_execution"] and
            record["input_sha256"] == {**profile["input_sha256"], str(profile_path): profile_sha} and
            all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
            not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel", "partial_outputs_only")),
            "control is not its closed exact profile/input-union/runtime record")


def order_frame(value):
    if isinstance(value, dict):
        return [(key, order_frame(item)) for key, item in value.items()]
    if isinstance(value, list):
        return [order_frame(item) for item in value]
    return None


def prove_module(native, selected, before, after, manifest):
    require(set(before) == set(after) == {"creator", "modules"} and set(before["modules"]) == set(after["modules"]) == {"top"} and
            type(before["creator"]) is type(after["creator"]) is str, "complete native document shape differs")
    a, b = before["modules"]["top"], after["modules"]["top"]
    require(len(a["cells"]) == len(b["cells"]) == 14907 and len(a["netnames"]) == len(b["netnames"]) == 16645 and
            native.canonical(a) == native.canonical(b), "complete native module metadata/cells/nets/raw IDs differ")
    require(order_frame(a) == order_frame(b) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "native module/owner/port/metadata order or lossless paired PLL entries differ")
    require(selected.native_tables(a) == selected.native_tables(b), "complete raw driver/user slot tables differ")
    ffs = [{name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"}
           for top in (a, b)]
    require(len(manifest) == 8221 and ffs[0] == ffs[1] == manifest, "all8221 original FF names/BELs differ")
    return {"complete_native_module_exact": True, "all_native_metadata_and_owner_port_order_exact": True,
            "lossless_paired_pll_entries_exact": True, "native_driver_and_user_slot_tables_exact": True,
            "all_original_ff_bels_exact": True, "original_ff_count": 8221, "cells": 14907, "netnames": 16645,
            "raw_id_translation_or_native_field_waiver_used": False, "unexported_pins_lab_caches_or_physical_state_proved": False}


def post_command(old):
    result = list(old["command"])
    require(result[0] == str(OLD_BINARY), "original compiler pathname differs")
    result[0] = str(POST_BINARY)
    for flag, name in (("--write", "placed.json"), ("--report", "timing.json")):
        require(result.count(flag) == 1, "ambiguous reference output selector")
        result[result.index(flag) + 1] = str(POST_FOLDER / "baseline" / name)
    return result


def post_execution(old):
    result = copy.deepcopy(old["execution"])
    require(result["files"].pop(str(OLD_BINARY)) == OLD_BINARY_SHA and str(POST_BINARY) not in result["files"] and
            result["environment"]["PATH"] == str(OLD_BINARY.parent) + ":/usr/bin:/bin", "original reference compiler/PATH differs")
    result["files"][str(POST_BINARY)] = POST_BINARY_SHA
    result["files"] = dict(sorted(result["files"].items()))
    result["environment"]["PATH"] = str(POST_BINARY.parent) + ":/usr/bin:/bin"
    return result


def compare(self_sha, scope_sha, profile_sha, run_sha, runner_sha, runner_scope_sha):
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64
            for value in (BINARY_SHA, ARCHIVE_SHA, HOST_SHA, TEST_SHA, CHECKS_SHA)), "current compiler/host pins are UNFROZEN")
    native = load(NATIVE, NATIVE_SHA, "pair_ten_native_pure")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha), (PROFILE, profile_sha),
            (RUN, run_sha), (RUNNER, runner_sha), (HERE / "scope.md", runner_scope_sha), (HOST, HOST_SHA),
            (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
            (OLD, OLD_SHA), (OLD_PROFILE, OLD_PROFILE_SHA), (OLD_PREFIX, OLD_PREFIX_SHA),
            (POST, POST_SHA), (POST_PROFILE, POST_PROFILE_SHA), (POST_PROOF, POST_PROOF_SHA),
            (POST_FOLDER / "compare_control.py", POST_GENERATOR_SHA), (POST_FOLDER / "comparison-scope.md", POST_SCOPE_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    runner = load(RUNNER, runner_sha, "pair_ten_runner_pure")
    for path, expected in runner.PARSERS:
        audit.bind(path, expected)
    profile, record, old, old_profile, prefix, post, post_profile, post_proof, host = (
        native.read(path) for path in (PROFILE, RUN, OLD, OLD_PROFILE, OLD_PREFIX, POST, POST_PROFILE, POST_PROOF, HOST))
    closed_record(native, record, profile, PROFILE, profile_sha)
    closed_record(native, old, old_profile, OLD_PROFILE, OLD_PROFILE_SHA)
    closed_record(native, post, post_profile, POST_PROFILE, POST_PROFILE_SHA)
    counts = {"pair_backend": 12, "native_plan": 25, "driver_backend": 10, "pair_cli": 11, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == runner.COMMIT == COMMIT and
            host["delta_base_commit"] == runner.BASE == BASE and host["binary_sha256"] == runner.BINARY_SHA == BINARY_SHA and
            host["source_archive_sha256"] == runner.ARCHIVE_SHA == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and
            host["check_results_sha256"] == CHECKS_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
            host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and
            set(host["changed_source_files"]) == runner.CHANGED and set(host["checks"]) == set(counts) and
            all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
            all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"] and
            all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in host["committed_archive_manifest_sha256"]),
            "current independent host/source/archive/dependency/check qualification differs")
    require(profile["phase"] == "lut-pair-disabled-ten-stage-predicted-control" and profile["command"] == runner.command(old) and
            record["execution"] == runner.expected_execution(old) and profile["diagnostic_environment"] == old["diagnostic_environment"] == post["diagnostic_environment"] and
            profile["cwd"] == old["cwd"] == post["cwd"] == str(ROOT / "sources/misteross") and profile["compiler_commit"] == COMMIT and
            profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and
            profile["helper_sha256"] == runner_sha and profile["scope_sha256"] == runner_scope_sha and profile["host_validation_sha256"] == runner.HOST_SHA == HOST_SHA and
            profile["host_validation_path"] == str(HOST) and profile["current_host_case_counts"] == counts and
            profile["committed_archive_member_sha256"] == host["committed_archive_manifest_sha256"] and
            all(profile[key] is False for key in ("post_plan_requested", "lut_pair_requested", "driver_pass_executed", "native_graph_or_physical_equivalence_inherited", "routed_gain_accepted", "hardware_tested")),
            "current disabled-control profile/compiler/host/runtime roles differ")
    require(old["compiler_commit"] == OLD_COMMIT and old["binary_sha256"] == OLD_BINARY_SHA and old["source_archive_sha256"] == OLD_ARCHIVE_SHA and
            prefix["phase"] == "local-plan16-ready1-command-tenth-stage-explicit-private-owner-native-prefix" and
            prefix["source_identity_sha256"] == OLD_PROFILE_SHA and prefix["current_baseline_run_sha256"] == OLD_SHA and
            prefix["compiler_commit"] == OLD_COMMIT and prefix["structural_rejection"] is prefix["native_path_topology_rejection"] is None and
            all(prefix[key] is True for key in ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof", "final_original_path_metadata_and_runtime_hashes_stable")) and
            profile["previous_source_identity_sha256"] == OLD_PROFILE_SHA and profile["previous_baseline_run_sha256"] == OLD_SHA and
            profile["previous_prefix_proof_sha256"] == OLD_PREFIX_SHA, "closed original d7e ten-stage prerequisite differs")
    require(post["phase"] == "post-remap-plan-disabled-ten-stage-predicted-control" and post["compiler_commit"] == BASE and
            post["binary_sha256"] == POST_BINARY_SHA and post["source_archive_sha256"] == POST_ARCHIVE_SHA and
            post["command"] == post_command(old) and post["execution"] == post_execution(old) and
            post_proof["schema"] == 1 and post_proof["phase"] == "post-remap-plan-disabled-ten-stage-native-control" and
            post_proof["compiler_commit"] == BASE and post_proof["delta_base_commit"] == OLD_COMMIT and
            post_proof["source_identity_sha256"] == POST_PROFILE_SHA and post_proof["current_baseline_run_sha256"] == POST_SHA and
            post_proof["previous_source_identity_sha256"] == OLD_PROFILE_SHA and post_proof["previous_baseline_run_sha256"] == OLD_SHA and
            post_proof["previous_prefix_proof_sha256"] == OLD_PREFIX_SHA and post_proof["generator_sha256"] == POST_GENERATOR_SHA and
            post_proof["scope_sha256"] == POST_SCOPE_SHA and post_proof["host_validation_sha256"] == POST_HOST_SHA and
            post_proof["current_actual_execution"] == post["execution"] and post_proof["structural_rejection"] is post_proof["native_path_topology_rejection"] is None and
            all(post_proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact", "complete_predicted_report_exact", "fresh_post_plan_control_prerequisite_proved", "final_original_path_metadata_and_runtime_hashes_stable")),
            "closed positive b3d disabled-post ten-stage control differs")
    for entry in (prefix, post_proof):
        bind_proof(audit, entry)
    for entry in (profile, old_profile, post_profile):
        bind_absolute(audit, entry["input_sha256"])
    for entry in (record, old, post):
        expected_outputs = {str(Path(entry["command"][entry["command"].index("--write") + 1]).parent / name) for name in ("phase.log", "placed.json", "timing.json")}
        require(set(entry["output_sha256"]) == expected_outputs, "control output set differs")
        bind_absolute(audit, entry["input_sha256"])
        bind_absolute(audit, entry["output_sha256"])
        bind_absolute(audit, entry["execution"]["files"], True)
    for key in HOST_MAPS:
        bind_absolute(audit, host[key])
    require(all(audit.paths.get(Path(path)) == expected for path, expected in profile["input_sha256"].items()) and
            audit.paths.get(runner.BINARY) == BINARY_SHA and audit.paths.get(runner.ARCHIVE) == ARCHIVE_SHA,
            "current source/artifact/runtime flat closure is incomplete")
    plan_path = OLD_FOLDER / "local-plan.json"
    plan = native.read(plan_path)
    require(profile["original_plan_path"] == post["original_plan_path"] == str(plan_path) and
            audit.paths.get(plan_path) == profile["original_plan_sha256"] == post["original_plan_sha256"] == OLD_PLAN_SHA and
            set(plan) == {"steps"} and plan["steps"] == profile["local_plan_steps"] == old["local_plan_steps"] == post["local_plan_steps"] and
            len(plan["steps"]) == 10 and [step["groups"] for step in plan["steps"]] == [8] + [1] * 9 and
            all(set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and step["candidate"] == 0 and
                step["optimize_pins"] is False and step["preserve_ff_placement"] is True and Path(step["report"]) in audit.paths for step in plan["steps"]),
            "literal original ten-stage plan/report paths differ")
    definitions = runner.definitions()
    logs = {"d7e_original_ten": (OLD.parent / "phase.log").read_text(), "b3d_disabled_post_ten": (POST.parent / "phase.log").read_text(), "current": (HERE / "baseline/phase.log").read_text()}
    models = {key: runner.qualification(log, definitions) for key, log in logs.items()}
    for key, entry in (("d7e_original_ten", old), ("b3d_disabled_post_ten", post), ("current", record)):
        require(native.canonical(models[key]) == native.canonical(entry["actual_selected_local_qualification"]), "actual complete trial binding differs: " + key)
    require(native.canonical(models["d7e_original_ten"]) == native.canonical(profile["retained_local_models"]) == native.canonical(prefix["fresh_local_models"]) and
            native.canonical(models["b3d_disabled_post_ten"]) == native.canonical(post_proof["fresh_local_models"]), "retained/cached actual model provenance differs")
    references = ("d7e_original_ten", "b3d_disabled_post_ten")
    models_exact = {key: native.canonical(models["current"]) == native.canonical(models[key]) for key in references}
    require(record["all_ten_complete_trial_models_exact"] is models_exact["d7e_original_ten"], "recorded model diagnostic differs")
    metric_rows = {key: native.PLACEMENT_METRICS.findall(log) for key, log in logs.items()}
    metrics_exact = {key: len(metric_rows["current"]) == len(metric_rows[key]) == 71 and metric_rows["current"] == metric_rows[key] for key in references}
    frozen = load(FREEZE, FREEZE_SHA, "pair_ten_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "pair_ten_selected_pure", frozen)
    documents = {"d7e_original_ten": native.read_netlist(OLD.parent / "placed.json"), "b3d_disabled_post_ten": native.read_netlist(POST.parent / "placed.json"), "current": native.read_netlist(HERE / "baseline/placed.json")}
    reports = {"d7e_original_ten": native.read(OLD.parent / "timing.json"), "b3d_disabled_post_ten": native.read(POST.parent / "timing.json"), "current": native.read(HERE / "baseline/timing.json")}
    evidence, rejections, topology, topology_rejections = {}, {}, {}, {}
    for key, entry in (("d7e_original_ten", old), ("b3d_disabled_post_ten", post)):
        try:
            require(models_exact[key] and metrics_exact[key], "ten complete trial models or71 placement metrics differ")
            require(profile["all_original_ff_bel_manifest"] == entry["all_original_ff_bel_manifest"], "original FF manifest differs")
            evidence[key] = prove_module(native, selected, documents[key], documents["current"], profile["all_original_ff_bel_manifest"])
        except (ValueError, TypeError, KeyError, IndexError) as error:
            rejections[key] = {"exception_type": type(error).__name__, "reason": str(error)}
        try:
            topology[key] = selected.report_topology(documents["current"], reports["current"], reports[key])
            require(topology[key]["current_report_paths"] == 15290 and len(topology[key]["domain_pair_endpoint_counts"]) == 7, "native path count/pair set differs")
        except (ValueError, TypeError, KeyError, IndexError) as error:
            topology_rejections[key] = {"exception_type": type(error).__name__, "reason": str(error)}
    report_exact = {key: native.canonical(reports["current"]) == native.canonical(reports[key]) for key in references}
    report, log = reports["current"], logs["current"]
    require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and record["actual_predicted_fmax"] == report["fmax"] and
            "Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step", "LUT pair placement")),
            "current predicted-only report or disabled pass phase differs")
    audit.finish()
    prerequisite = not rejections and not topology_rejections and all(report_exact.values())
    return {"schema": 1, "phase": "lut-pair-disabled-ten-stage-native-control", "source_identity_sha256": profile_sha,
        "current_baseline_run_sha256": run_sha, "previous_source_identity_sha256": OLD_PROFILE_SHA, "previous_baseline_run_sha256": OLD_SHA,
        "previous_prefix_proof_sha256": OLD_PREFIX_SHA, "b3d_control_profile_sha256": POST_PROFILE_SHA, "b3d_control_run_sha256": POST_SHA,
        "b3d_control_proof_sha256": POST_PROOF_SHA, "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "generator_sha256": self_sha, "scope_sha256": scope_sha, "recorder_sha256": runner_sha, "recorder_scope_sha256": runner_scope_sha,
        "host_validation_sha256": HOST_SHA, "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "current_actual_execution": record["execution"], "authorized_runtime_delta": profile["authorized_runtime_delta"],
        "creator_strings": {key: document["creator"] for key, document in documents.items()},
        "creator_provenance_only_difference_permitted": True, "reference_local_models": {key: models[key] for key in references}, "fresh_local_models": models["current"],
        "all_ten_complete_trial_models_exact": all(models_exact.values()), "ten_model_equality_by_reference": models_exact,
        "all_71_placement_metrics_exact": all(metrics_exact.values()), "placement_metric_equality_by_reference": metrics_exact,
        "structural_rejection": rejections or None, "native_graph_proof_available": not rejections, "native_graph_evidence": evidence,
        "current_predicted_native_paths": topology, "native_path_topology_rejection": topology_rejections or None,
        "complete_predicted_report_exact": all(report_exact.values()), "complete_report_equality_by_reference": report_exact,
        "actual_predicted_fmax": report["fmax"], "fresh_lut_pair_control_prerequisite_proved": prerequisite,
        "raw_id_alignment_or_native_module_field_waiver_used": False, "independent_physical_equivalence_proved": False,
        "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "pure_function_helper_sha256": {str(path): expected for path, expected in ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (RUNNER, runner_sha), *runner.PARSERS)},
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "run-sha256", "runner-sha256", "runner-scope-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual SHA activation pins required")
    output = HERE / "baseline/comparison-control.json"
    require(not output.exists(), "immutable control comparison already exists")
    result = compare(args.self_sha256, args.scope_sha256, args.profile_sha256, args.run_sha256, args.runner_sha256, args.runner_scope_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "complete_predicted_report_exact": result["complete_predicted_report_exact"],
        "fresh_lut_pair_control_prerequisite_proved": result["fresh_lut_pair_control_prerequisite_proved"]}, indent=2))


if __name__ == "__main__":
    main()
