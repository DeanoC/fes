# Disabled joint-LUT-placement ten-stage control

ROOT alone activates this new comparator after whole-file, hash, AST and
independent peer review. It requires actual self/scope, prepared profile, closed
run, recorder and recorder-scope SHA arguments. Current commit, production ELF,
source archive, test ELF, check-results and host constants remain UNFROZEN and
fail closed until ROOT has completed the current checks and frozen their bytes.
The exclusive output is baseline/comparison-control.json. No compiler, test,
routing, Git query, old authentication, generator or comparison entrypoint runs.

This control requests neither joint LUT placement nor a post plan or driver
copy. It retains the literal original d7e5 ten-stage plan00bf, including original
report paths, 8/1/1/1/1/1/1/1/1/1 group budgets, candidate0, plain pins and fixed
FF placement. The new b3d-based compiler changes only the executable pathname
and hash, its controlled PATH directory, and fresh predicted output aliases.
Every other option, diagnostic environment, device/model, seed, clock setting,
runtime file and execution field must equal the closed original invocation.

Two independently bound closed controls are compared directly: the original
d7e5 run3d69/profile77fd/logical prefixbf9d and the disabled-post b3d control
run3eb274cc/profile2294abbb/positive proof323846d5. The latter must retain its
exact successful native/model/metric/topology/full-report gates and original
reference anchors. Its command and runtime are checked against the original
invocation with only its historical compiler/PATH/output changes. Both complete
profile/input-union records and actual output/runtime maps are rehashed, as are
both flat proof closures. Neither old comparison is replayed. Historic compiler
host acceptance is provenance and does not qualify the current compiler.

Current independent host evidence binds the clean committed source, production
and test ELF, committed archive and member manifest, dependency manifests and
resolved files, model/submodule/source maps and all six current native/CLI case
groups. Their required counts are 12/25/10 native and 11/24/10 CLI; all must have
passed with exit0. Relative archive member names remain member evidence, not
filesystem paths. Original artifact paths and external historical/runtime paths
retain separate flat ledgers and are checked again before the result is written.

Only pinned32fd read/read_netlist/Audit/canonical,72131 native_tables and
report_topology,8601 require via the exact local import, and the current
recorder's reviewed command/expected_execution/definitions/qualification are
called. All eight called log-parser modules are explicitly pinned. Old prepare,
execute, clean_source, validators, authenticator, generator and main functions
remain inactive. The comparator independently checks current host shape rather
than calling a historical host validator.

Every complete guarded ten-stage trial model and all71 placement metric rows
must equal both reference records. Both comparisons independently require the
whole14907-cell/16645-net module, all original raw IDs, aliases, drivers and
consumer slots, parameters, attributes, exported pins/LAB state, public ports,
settings, nested metadata/owner/port order, lossless ordered paired PLL entries,
and all8221 original FF owners/BELs to be exact. Only the document's string
creator provenance may differ and all three strings are disclosed. No private
frame alignment, numeric translation, buffer collapse, native field exclusion,
Boolean substitution, placement tolerance or physical pin waiver is allowed.

The current complete15290-path/seven-pair predicted report is checked against
its own lossless native image and both retained endpoint/window sets. The whole
JSON report must equal both references, including every segment, clock term,
window, net timing row and Fmax. The explicit report cap remains16384. Each
reference has separate structural, topology and full-report diagnostics. Native
or topology rejection still preserves current report evidence and completes the
original-path hash closure. fresh_lut_pair_control_prerequisite_proved requires
both strict graph/model/metric gates, both topologies and both full-report
equalities; compiler completion alone cannot activate a selected pair move.

This proves reproduction of exported predicted data with the optional pass
disabled. It does not prove unexported pin/LAB caches, independent physical
equivalence or numerical STA, qualify a future pair candidate, accept routed
gain, decode an RBF or claim hardware testing. The accepted fifth117.771759 MHz
measurement remains separate from these predicted construction controls.
