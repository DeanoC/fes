"""Root-only seal of a full route from an independently proved selected snapshot."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
SELECTED = HERE.parent / "driver-copy-selected-264"
SELECTED_ID = SELECTED / "source-identity.json"
SELECTED_ID_SHA = "488b187412a3fecf94e534a32219d197548e3adb3bb03ee3346693ed5a6e16c9"
SELECTED_FOLDER = SELECTED / "selected-c0"
SELECTED_PROOF = SELECTED_FOLDER / "comparison.json"
SELECTED_GENERATOR_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
LISTING_PROOF_SHA = "2af219908f88cc0dc42d6fea29740868e9b9ab40f6379f855d1b54cbe441fa96"
COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"
BASE = "9dc3633aa0c5395df9a81be8437d1a746ba54b5d"
BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
PURE = HERE.parent / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
IDENTITY = HERE / "source-identity.json"
FOLDER = HERE / "route-c0"
HELPERS = ("freeze.py", "route.py", "scope.md")


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(value, width=64):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{%d}" % width, value) is not None and len(set(value)) > 1


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata: " + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(digest(expected), "unset/invalid artifact hash: " + path)
    if path in inputs:
        require(inputs[path] == expected, "conflicting artifact identity: " + path)
    else:
        require(sha(path) == expected, "original artifact path changed: " + path)
        inputs[path] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "original input path changed during operation: " + path)


def native_helper(inputs):
    bind(inputs, PURE, PURE_SHA)
    spec = importlib.util.spec_from_file_location("driver_full_frozen_native_parser", PURE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def location(cell):
    bel = cell["attributes"].get("NEXTPNR_BEL", "")
    match = re.fullmatch(r"MISTRAL_(M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)", bel)
    if match is None:
        return None
    kind, x, y, z = match[1], int(match[2]), int(match[3]), int(match[4])
    require(0 <= z < 60 and (z % 6 >= 2 if kind == "FF" else z % 6 < 2), "invalid native ALM BEL")
    return kind, x, y, z


def declared_scope(document, graph):
    """Declare actual selected cells/ALMs; this grants no physical-change waiver."""
    top, cells = document["modules"]["top"], document["modules"]["top"]["cells"]
    source, clone, sink, port = graph["source"], graph["clone"], graph["sink"], graph["sink_port"]
    require(port in {"A", "B", "C", "D0", "D1"} and cells[sink]["type"] == "MISTRAL_ALUT_ARITH" and
            cells[source]["type"] == cells[clone]["type"] == "MISTRAL_ALUT3" and
            cells[clone]["connections"]["Q"] == cells[sink]["connections"][port] and
            cells[source]["connections"]["Q"] != cells[clone]["connections"]["Q"], "selected scope graph edge differs")
    cell_names = {source, clone, sink}
    carry_rows = []
    if cells[sink]["connections"].get("CO"):
        output = cells[sink]["connections"]["CO"]
        require(len(output) == 1 and type(output[0]) is int, "selected carry output is not scalar")
        owners, users = [], []
        for name, cell in cells.items():
            for pin, direction in cell["port_directions"].items():
                for index, bit in enumerate(cell["connections"][pin]):
                    if bit == output[0]:
                        (owners if direction == "output" else users).append((name, pin, index, direction))
        require(owners == [(sink, "CO", 0, "output")] and len(users) <= 1 and all(
                row[1:] == ("CI", 0, "input") and cells[row[0]]["type"] == "MISTRAL_ALUT_ARITH" for row in users),
                "selected carry output has unexpected owners/users")
        for successor, _, _, _ in users:
            cell_names.add(successor)
            require(location(cells[successor]) is not None, "immediate carry successor is not placed")
            carry_rows.append({"source": sink, "source_port": "CO", "native_bit": output[0],
                               "sink": successor, "sink_port": "CI", "vector_index": 0})
    alms = set()
    roles = []
    for name in sorted(cell_names):
        where = location(cells[name])
        require(where is not None and where[0] != "FF", "selected declared combinational cell lacks its actual ALM BEL")
        key = where[1], where[2], where[3] // 6
        alms.add(key)
        roles.append({"cell": name, "type": cells[name]["type"], "bel": cells[name]["attributes"]["NEXTPNR_BEL"],
                      "alm": list(key), "half": where[3] % 6,
                      "role": "clone" if name == clone else "source" if name == source else
                              "arithmetic_sink" if name == sink else "immediate_carry_successor"})
    occupants = []
    for name, cell in cells.items():
        where = location(cell)
        if where is not None and (where[1], where[2], where[3] // 6) in alms:
            occupants.append({"cell": name, "type": cell["type"], "bel": cell["attributes"]["NEXTPNR_BEL"],
                "alm": [where[1], where[2], where[3] // 6], "slot": where[3] % 6,
                "serialized_attributes": cell["attributes"], "serialized_parameters": cell["parameters"],
                "serialized_port_directions": cell["port_directions"], "serialized_connections": cell["connections"]})
    clone_where = location(cells[clone])
    clone_alm = clone_where[1], clone_where[2], clone_where[3] // 6
    require([row["cell"] for row in occupants if tuple(row["alm"]) == clone_alm] == [clone],
            "selected clone ALM has an undeclared original COMB/MCOMB/FF occupant")
    require(top["attributes"].get("step") == "place", "selected scope is not an actual pre-route placement")
    return {"schema": 1, "selected_native_source_cell": source, "selected_native_clone_cell": clone,
        "selected_native_sink_cell": sink, "selected_native_sink_port": port,
        "selected_native_private_q_net": graph["private_net"], "selected_actual_clone_bel": graph["selected_clone_bel"],
        "declared_alm_keys": [list(key) for key in sorted(alms)], "declared_cells": roles,
        "actual_selected_alm_occupants": sorted(occupants, key=lambda row: (row["alm"], row["slot"], row["cell"])),
        "native_immediate_carry_edges": carry_rows,
        "copy_input_load_ledger": graph["declared_copy_input_loads"],
        "original_cell_pin_bel_movement_authorized": False, "buffer_changes_authorized": False,
        "serialized_ff_controls_and_all_original_metadata_remain_strict": True,
        "physical_lab_control_state_or_pin_image_proved": False,
        "physical_evaluator_and_routed_acceptance_available": False}


def reference(inputs, proof_sha):
    require(digest(proof_sha), "actual selected proof pin is unset")
    bind(inputs, SELECTED_PROOF, proof_sha)
    proof = read(SELECTED_PROOF)
    require(proof["schema"] == 1 and proof["phase"] == "driver-copy-selected-no-route" and
            proof["compiler_commit"] == COMMIT and proof["source_identity_sha256"] == SELECTED_ID_SHA and
            proof["listing_proof_sha256"] == LISTING_PROOF_SHA and proof["generator_sha256"] == SELECTED_GENERATOR_SHA and
            proof["frozen_native_parser_sha256"] == PURE_SHA and all(proof[key] is True for key in (
                "candidate_completed", "selected_serialized_native_graph_proved", "partial_graph_evidence_available",
                "final_original_path_metadata_and_runtime_hashes_stable")) and
            proof["routed_graph_proof_available"] is False and proof["complete_physical_pin_preservation_proved"] is False,
            "selected source is not its completed independent partial proof")
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "selected artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "selected runtime pathname is not absolute")
        bind(inputs, name, expected)
    require(inputs.get(str(SELECTED_ID)) == SELECTED_ID_SHA and
            inputs.get(str(SELECTED / "compare_selected.py")) == SELECTED_GENERATOR_SHA,
            "selected closure omits actual source/generator")
    selected, run = read(SELECTED_ID), read(SELECTED_FOLDER / "run.json")
    require(selected["result_commit"] == COMMIT and selected["delta_base_commit"] == BASE and
            selected["binary_sha256"] == BINARY_SHA and selected["source_archive_sha256"] == ARCHIVE_SHA and
            selected["selected_candidate"] == 0 and selected["listing_proof_sha256"] == LISTING_PROOF_SHA,
            "selected copied compiler/source identity differs")
    require(run["phase"] == "selected-c0" and run["completed"] is True and run["exit_code"] == 0 and
            run["compiler_read_audit_passed"] is True and run["source_identity_sha256"] == SELECTED_ID_SHA and
            run["selected_candidate"] == 0 and run["selected_trial"] == selected["selected_trial"] and
            run["command"] == selected["command"] and run["diagnostic_environment"] == selected["diagnostic_environment"] and
            set(run["output_sha256"]) == {str(SELECTED_FOLDER / name) for name in ("phase.log", "placed.json", "timing.json")} and
            "failure" not in run, "actual selected execution is not completed and bound")
    require(all(inputs.get(path) == expected for path, expected in
                {**selected["input_sha256"], **run["input_sha256"], **run["output_sha256"], **run["execution"]["files"]}.items()),
            "selected actual inputs/runtime/outputs are outside finalized flat proof")
    graph, qualification = proof["graph_evidence"], proof["qualification_evidence"]
    require(graph["source_q_users_before"] == 49 and graph["source_q_users_after"] == 48 and
            len(graph["clone_q_users"]) == 1 and graph["selected_clone_bel"] == selected["selected_trial"]["bel"] and
            graph["conditional_function"]["raw_truth_row_count"] == 8 and
            graph["conditional_function"]["conditional_raw_table_equivalence_proved"] is True and
            qualification["actual_selected_candidate"] == 0 and qualification["fresh_selected_trial"] == selected["selected_trial"] and
            qualification["selected_qualified_log_prefix_exact"] is True and
            qualification["retained_upstream_qualification_messages_and_71_metrics_exact"] is True and all(graph[key] is True for key in (
                "complete_original_native_cells_except_one_operand_exact", "all_original_named_nets_bits_aliases_and_metadata_exact",
                "all_original_serialized_ff_buf_lut_bels_params_attrs_and_available_pins_exact",
                "original_cell_net_export_prefix_and_private_suffix_exact", "lossless_ordered_pll_occurrences_exact",
                "all_actual_native_drivers_and_input_consumer_slots_closed", "clone_alm_no_original_serialized_occupants")),
            "selected proof does not close actual one-copy scope/current guarded selection")
    native = native_helper(inputs)
    scope = declared_scope(native.read_netlist(SELECTED_FOLDER / "placed.json"), graph)
    return {"selected": selected, "run": run, "proof": proof, "scope": scope, "proof_sha256": proof_sha}


def expected_command(ctx):
    command = list(ctx["run"]["command"])
    require(command.count("--no-route") == 1 and command.count("--remap-lut-driver-candidate") == 1 and
            command[command.index("--remap-lut-driver-candidate") + 1] == "0" and
            command.count("--timing-report-paths") == 1 and
            command[command.index("--timing-report-paths") + 1] == "16384" and
            command.count("--remap-lut-driver-critical") == 1 and
            "--rbf" not in command and "--compress-rbf" not in command,
            "selected source command is not its sole guarded no-route candidate0")
    command.remove("--no-route")
    for option, name in (("--write", "routed.json"), ("--report", "timing.json")):
        require(command.count(option) == 1, "source output selector is ambiguous")
        command[command.index(option) + 1] = str(FOLDER / name)
    command[0] = str(HERE / "nextpnr-mistral")
    command += ["--rbf", str(FOLDER / "core.rbf")]
    require(command.count("--router") == 1 and command[command.index("--router") + 1] == "gpu" and
            command.count("--gpu-device") == 1 and command[command.index("--gpu-device") + 1] == "1" and
            not any(flag in command for flag in ("--no-place", "--no-pack", "--no-route")),
            "full command changed the exact source placement/GPU profile")
    return command


def expected_runtime(ctx, profile):
    runtime = json.loads(json.dumps(ctx["run"]["execution"]))
    require(runtime["files"].pop(ctx["run"]["command"][0]) == BINARY_SHA, "selected source runtime binary differs")
    runtime["files"][str(HERE / "nextpnr-mistral")] = profile["binary_sha256"]
    runtime["environment"]["PATH"] = str(HERE) + ":/usr/bin:/bin"
    return runtime


def record_template(profile, identity_sha, execution, ctx):
    return {"schema": 1, "phase": "route-c0", "kind": "full routing recorder from proved selected one-copy snapshot",
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "source_identity_sha256": identity_sha,
        "selected_source_identity_sha256": SELECTED_ID_SHA, "selected_proof_sha256": ctx["proof_sha256"],
        "source_archive_sha256": ARCHIVE_SHA, "binary_sha256": BINARY_SHA,
        "selected_candidate": 0, "selected_trial": ctx["run"]["selected_trial"],
        "driver_guide_sha256": ctx["run"]["driver_guide_sha256"], "timing_report_paths": 16384,
        "helper_sha256": profile["helper_sha256"], "before_run_native_scope": ctx["scope"],
        "command": expected_command(ctx), "diagnostic_environment": ctx["run"]["diagnostic_environment"],
        "cwd": ctx["run"]["cwd"], "execution": execution,
        "input_sha256": {**profile["input_sha256"], str(IDENTITY): identity_sha},
        "same_compiled_binary_as_selected_snapshot": True, "runner_is_acceptance_proof": False,
        "routed_graph_and_physical_equivalence_proved": False, "timing_gain_accepted": False,
        "completed": False, "hardware_tested": False}


def authenticate_phase(run, profile, identity_sha, ctx):
    expected = record_template(profile, identity_sha, run["execution"], ctx)
    mutable = {"completed", "elapsed_seconds", "exit_code", "output_sha256", "compiler_read_audit_passed",
               "failure", "exit_code_is_adapter_sentinel", "actual_timing_report_summary", "actual_last_signoff"}
    require({key: value for key, value in run.items() if key not in mutable} ==
            {key: value for key, value in expected.items() if key not in mutable} and
            run["execution"] == expected_runtime(ctx, profile), "actual full command/env/runtime/profile differs")
    require(type(run["completed"]) is bool and "failure" not in run and "exit_code_is_adapter_sentinel" not in run,
            "full route has failed/sentinel execution")
    if run["completed"]:
        require(type(run["exit_code"]) is int and run["exit_code"] == 0 and run["compiler_read_audit_passed"] is True and
                type(run["elapsed_seconds"]) in (int, float) and math.isfinite(run["elapsed_seconds"]) and
                run["elapsed_seconds"] >= 0 and set(run["output_sha256"]) ==
                {str(FOLDER / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")},
                "completed full run lacks actual audited outputs")


def authenticate_freeze(identity_sha):
    inputs = {}
    bind(inputs, IDENTITY, identity_sha)
    profile = read(IDENTITY)
    require(profile["schema"] == 1 and profile["result_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            profile["selected_source_identity_sha256"] == SELECTED_ID_SHA and digest(profile["selected_proof_sha256"]) and
            profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and
            profile["runner_is_acceptance_proof"] is False and profile["before_run_scope_derived_from_actual_selected"] is True,
            "full frozen recorder identity differs")
    for path, expected in profile["input_sha256"].items():
        require(Path(path).is_absolute(), "full frozen input is not an original absolute pathname")
        bind(inputs, path, expected)
    ctx = reference(inputs, profile["selected_proof_sha256"])
    require(profile["helper_sha256"] == {name: inputs.get(str(HERE / name)) for name in HELPERS} and
            profile["before_run_native_scope"] == ctx["scope"] and profile["command"] == expected_command(ctx) and
            profile["diagnostic_environment"] == ctx["run"]["diagnostic_environment"] and
            profile["repositories"] == ctx["selected"]["repositories"] and
            inputs.get(str(HERE / "nextpnr-mistral")) == BINARY_SHA and
            inputs.get(str(HERE / "source.tar.gz")) == ARCHIVE_SHA, "full copied source/scope aliases differ")
    return profile, inputs, ctx


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selected-proof-sha256", required=True)
    for name in HELPERS:
        parser.add_argument("--" + name.replace(".", "-").replace("_", "-") + "-sha256", required=True)
    args = parser.parse_args()
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "build-config.txt",
                                                      "source-identity.json", "route-c0")), "full freeze outputs already exist")
    inputs = {}
    ctx = reference(inputs, args.selected_proof_sha256)
    for name in HELPERS:
        bind(inputs, HERE / name, getattr(args, name.replace(".", "_").replace("-", "_") + "_sha256"))
    command = expected_command(ctx)
    finish(inputs)
    for name in ("nextpnr-mistral", "source.tar.gz", "build-config.txt"):
        origin, target = SELECTED / name, HERE / name
        expected = inputs.get(str(origin))
        require(digest(expected), "selected compiler closure omitted copied artifact: " + name)
        with target.open("xb") as output, origin.open("rb") as source:
            shutil.copyfileobj(source, output)
        target.chmod(0o555 if name == "nextpnr-mistral" else 0o444)
        bind(inputs, target, expected)
    profile = {"schema": 1, "result_commit": COMMIT, "delta_base_commit": BASE,
        "selected_source_identity_sha256": SELECTED_ID_SHA, "selected_proof_sha256": args.selected_proof_sha256,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA,
        "repositories": ctx["selected"]["repositories"], "helper_sha256": {name: inputs[str(HERE / name)] for name in HELPERS},
        "before_run_native_scope": ctx["scope"], "before_run_scope_derived_from_actual_selected": True,
        "command": command, "diagnostic_environment": ctx["run"]["diagnostic_environment"],
        "same_compiled_binary_as_selected_snapshot": True, "runner_is_acceptance_proof": False,
        "input_sha256": inputs, "hardware_tested": False}
    finish(inputs)
    with IDENTITY.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"source_identity_sha256": sha(IDENTITY), "selected_proof_sha256": args.selected_proof_sha256,
                      "before_run_native_scope": ctx["scope"], "inputs": len(inputs)}, indent=2))


if __name__ == "__main__":
    main()
