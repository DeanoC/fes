"""Root-only full route recorder; completion is not optimization acceptance."""
import argparse
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

import freeze


def report_summary(report):
    fmax = report.get("fmax")
    freeze.require(type(fmax) is dict and fmax and all(type(row) is dict and
                   type(row.get("achieved")) in (int, float) and math.isfinite(row["achieved"]) and row["achieved"] > 0 and
                   type(row.get("constraint")) in (int, float) and math.isfinite(row["constraint"]) and row["constraint"] > 0
                   for row in fmax.values()), "actual full report has missing/nonfinite clock results")
    paths = report.get("critical_paths")
    freeze.require(type(paths) is list and paths and report.get("timing_report_paths") == 16384,
                   "actual full expanded report is absent")
    pairs = {}
    for path in paths:
        freeze.require(type(path) is dict and type(path.get("max_delay")) in (int, float) and
                       math.isfinite(path["max_delay"]) and path["max_delay"] > 0 and
                       type(path.get("path")) is list and path["path"], "actual path/window summary is invalid")
        delays = [segment.get("delay") for segment in path["path"]]
        freeze.require(all(type(value) in (int, float) and math.isfinite(value) for value in delays),
                       "actual full report contains nonfinite segment delays")
        total, key = sum(delays), (path["from"], path["to"])
        freeze.require(math.isfinite(total), "actual full path sum is nonfinite")
        if key not in pairs:
            pairs[key] = {"max_delay": path["max_delay"], "worst_segment_sum_ns": total,
                          "minimum_headroom_ns": path["max_delay"] - total, "reported_paths": 1}
        else:
            freeze.require(pairs[key]["max_delay"] == path["max_delay"], "actual pair has inconsistent windows")
            pairs[key]["worst_segment_sum_ns"] = max(pairs[key]["worst_segment_sum_ns"], total)
            pairs[key]["minimum_headroom_ns"] = min(pairs[key]["minimum_headroom_ns"], path["max_delay"] - total)
            pairs[key]["reported_paths"] += 1
    return {"fmax": fmax, "reported_paths": len(paths), "actual_clock_pair_window_summaries":
            [{"from": key[0], "to": key[1], **value} for key, value in sorted(pairs.items())],
            "native_topology_or_physical_equivalence_independently_proved": False,
            "timing_gain_or_acceptance_evaluated": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    profile, inputs, ctx = freeze.authenticate_freeze(args.source_identity_sha256)
    freeze.require(not freeze.FOLDER.exists(), "full route output folder already exists")
    sys.path.insert(0, str(freeze.MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    tool_identity = (f"base_commit={freeze.BASE}; experimental_source_sha256={profile['source_archive_sha256']}; "
                     f"sha256={profile['binary_sha256']}")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(freeze.HERE / "nextpnr-mistral", tool_identity)}, 1)
    try:
        freeze.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                       "ambient compiler diagnostics are forbidden")
        record = freeze.record_template(profile, args.source_identity_sha256, invocation.inputs, ctx)
        freeze.authenticate_phase(record, profile, args.source_identity_sha256, ctx)
        for path, expected in record["execution"]["files"].items():
            freeze.bind(inputs, path, expected)
        freeze.FOLDER.mkdir()
        manifest, started = freeze.FOLDER / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        try:
            with (freeze.FOLDER / "route.log").open("x") as log:
                result = audited_run(record["command"], source_root=freeze.MODULE, cwd=record["cwd"],
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log,
                    stderr=subprocess.STDOUT, check=False, timeout=3600)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            record["compiler_read_audit_passed"] = True
            invocation.verify()
            freeze.require(result.returncode == 0 and all((freeze.FOLDER / name).is_file() and
                           (freeze.FOLDER / name).stat().st_size > 0 for name in ("route.log", "routed.json", "timing.json", "core.rbf")),
                           "full routing did not complete with actual outputs")
            log = (freeze.FOLDER / "route.log").read_text()
            freeze.require("Info: Program finished normally." in log and
                           not any(line.startswith("ERROR:") for line in log.splitlines()) and
                           log.count("Info: LUT driver copy applied candidate 0; full routing and signoff still required.") == 1 and
                           "Running the GPU router" in log and "Running signoff timing analysis..." in log and
                           "Running predicted placed timing analysis for --report (no routing or analogue signoff)." not in log,
                           "actual execution lacks current selected/GPU/final signoff provenance")
            last = log.rsplit("Running signoff timing analysis...", 1)[1]
            record["actual_last_signoff"] = {"reported_hold_warning_lines":
                [line for line in last.splitlines() if re.search(r"hold", line, re.I) and
                 (re.search(r"warning|violation|negative", line, re.I) or line.startswith("Warning:"))],
                "independent_hold_acceptance_proved": False}
            record["actual_timing_report_summary"] = report_summary(freeze.read(freeze.FOLDER / "timing.json"))
            record["output_sha256"] = {str(freeze.FOLDER / name): freeze.sha(freeze.FOLDER / name)
                                      for name in ("route.log", "routed.json", "timing.json", "core.rbf")}
            record["completed"] = True
            freeze.authenticate_phase(record, profile, args.source_identity_sha256, ctx)
            freeze.finish({**inputs, **record["output_sha256"]})
            print(json.dumps({"phase": record["phase"], "completed": True, "elapsed_seconds": record["elapsed_seconds"],
                              "actual_fmax": record["actual_timing_report_summary"]["fmax"],
                              "runner_is_acceptance_proof": False}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
