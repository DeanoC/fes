# Driver-copy full-route recorder

These three files are drafts until root reviews and seals them against an
actual completed selected proof. Root alone freezes/runs the compiler; authors
execute no helpers, builds, tests, routes, queries or hardware operations.
All previous files remain immutable. This recorder makes no acceptance claim.

Activation requires `--selected-proof-sha256` for the actual finalized proof
from selected generator `72131acf…`, identity `488b1874…`, plus three exact
helper hashes. A missing or failed selected proof cannot activate this phase.
The independent selected proof supplies its flat artifact/runtime closure,
including fresh listing, disabled same-binary baseline and upstream evidence.
No old generator or authenticator is replayed. Only pinned `32fd10…` pure
lossless native parsing is imported. Original absolute pathnames are rehashed.

The exact same frozen binary/archive/config are copied from the selected
package: compiler result `5dd69a8d…`, binary `2ebe29ca…`, archive `840e7a44…`.
The command is the actual selected command with one --no-route removed, write
and report paths replaced, a new RBF output added and executable alias replaced.
Guide, report cap16,384, input files, stage order, candidate0, seed, constraints,
GPU1 selectors and complete diagnostic environment remain unchanged. Runtime
changes only the executable/PATH alias. FunctionalInvocation/audited_run
bind current execution and compiler accesses. Outputs are exclusive new files.

Before launch, the actual selected graph declares source, copy, arithmetic
sink and each immediate CO-to-CI successor, with their actual ALMs, paired
COMB/MCOMB halves and fixed neighboring FF occupants. Serialized parameters,
ports and attributes of those occupants are retained in the declaration;
actual copy input loads and the dedicated carry edges remain explicit. The
clone ALM must contain no selected original COMB/MCOMB/FF occupant. This
declaration grants no original pin/BEL movement, buffer change or LAB control
normalization. It is not an independent physical/carry-cache/FF-control proof.

The runner records real exit status, elapsed time, audited runtime, routed
native JSON, whole expanded timing report, last-signoff hold warning lines
and RBF hashes. It summarizes finite actual clock-pair windows and all segment
sums, without accepting any result. Failed source selection, execution,
incomplete output or nonfinite report fails closed with failure metadata.
Completed routing can still be rejected by the subsequent independent proof.

A separate proof must validate current physical LUT2..5/MCOMB and arithmetic
truth, actual constants/inversions, both shared halves, dedicated carry wires,
all original FF/BEL/pin/PLL/BUF/user preservation and the one-edge manifest.
Derived masks do not decode the RBF; unexported caches/GPU/internal owner-store
identity cannot be claimed from native JSON. Any buffer change requires an
explicit separate identity/endpoint proof; there is no blanket collapse.

Timing acceptance is also separate: memory strictly above 116.64527893066406
MHz, exact actual constraints and required other clocks, positive actual
non-target setup windows (capture phase included), and no final reported hold
violations. Target130 may remain unmet and must be disclosed. There is no
inheritance of routed gain or hardware acceptance from selected modeled guards.
