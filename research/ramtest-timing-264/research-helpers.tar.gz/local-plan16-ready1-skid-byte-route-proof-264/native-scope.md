# Ninth routed native scope

This pure module reads no files, imports no helpers and mutates no input graph.
The authenticated structural before is old-eight3ef0/f74c, independently of the
accepted-five timing reference. Creator metadata is disclosed across compiler
versions; all module metadata/settings/public ports/order/paired PLL records and
full pin/LAB attributes remain exact. The current caller binds same-binary full
versus predicted creator. One ready1 outer3$local_remap$3 ALUT4 and sole alias are
added:20138→20139 cells/21876→21877 aliases.

Actual masks inner0xb/outer0x32/retained0x4440/new0x4440 and four unchanged native
leaf drivers are checked with16 logical rows. Exactly FF3/7 ENA at27.21.52/.40
move from original root to the new Q; original root102→100. Eight prior copies,
literal Qs and complete cohorts21/2/10/1/6/1/1/3 remain strict. Their original
two-user ready1 copy is retained. Source burst ALUT3 mask0x20 retains48 users;
its same-named requalified copy has one operand consumer and both image functions
are checked. CO has only the same immediate successor CI. Actual driver BEL and
pin snapshot may differ only for that one requalified owner and require the
independent physical proof.

All four generated private outputs, driver Q and5232 existing buffer Qs get
separate complete per-image owner/alias/driver/consumer frames. Each private Q
has one driver, its sole literal private alias, no public boundary and complete
unchanged named consumers. Buffers retain exact native A and its original driver,
unique named FF DATAIN, metadata and pins. Frames must be injective within each
image; all old keys are removed before new ones are added so overlapping raw
numbers cannot conflate owners. The new ready Q must be outside every surviving
driver and every new frame. No global offset, buffer collapse or numeric graph
rewrite exists. All original driver/user tables and per-cell slots are rebuilt
and compared, allowing only declared frame slots and the two ENAs/four loads.

All remaining alias metadata/raw slots and original cell metadata, LUT tables,
full pins, BELs and port order are strict; net ROUTING attributes may differ
because actual routing is fresh. All8221 original FF owners remain present.
Logical rows are conditional plain-SIG evidence only; the separate physical
module proves actual pin states/banks/FF controls. This module claims no STA,
route-pip legality, RBF decoding, caches or hardware acceptance.
