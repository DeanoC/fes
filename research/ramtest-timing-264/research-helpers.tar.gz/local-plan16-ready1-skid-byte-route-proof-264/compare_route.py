"""Authenticate and independently inspect the ninth ready1-copy full route."""
import argparse
import builtins
import hashlib
import importlib.util
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
ROUTE = RAW / "local-plan16-ready1-skid-byte-route-264"
PREFIX = RAW / "local-plan16-ready1-skid-byte-stage-264"
PARENT = RAW / "local-multicopy-ready1-address-route-264/route-c0"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
PARENT_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
BEFORE = RAW / "local-multicopy-port0-skid-address-route-264/route-c0"
CONSTRUCTION = RAW / "local-multicopy-port0-skid-address-route-proof-264/comparison.json"
CONSTRUCTION_SHA = "f74c76d8ee455ccc499e86a99256c771537953615b0136762dae1ed85a33a4e3"
CONSTRUCTION_RUN_SHA = "3ef0c0b68f5bcb5d9fc0c7667663c88b1cdc086869973929c2c8e3b4450b7497"
CONSTRUCTION_PROFILE_SHA = "539376c79a565e3f114c20349a1a764059443217c68b088c2892bc66de1960c0"
PROFILE_SHA = "788f16d21d128edbf0ffce4fb32b63db6e47135cf9faa5686d084d6fd4aa780d"
RUNNER_SHA = "1381258caa20e3e4925e5c817c6ff36092270bd348f4816f325b86360e3a89bd"
RUNNER_SCOPE_SHA = "355863f20df2280dad3a46d3316baa72e229fe8eaf767d60a35686e5e8fd62c6"
PREFIX_SHA = "d1ee70008e30c5079473af11d0789a430a79b80bce75edf2477e8ef056c0230b"
PREFIX_PROFILE_SHA = "aceefeba07c0b3f3d7e98d09d336742b10a31aac734dccfe9c6df6dd71971d51"
PREFIX_RUN_SHA = "899a21d86764d2904aeab4632724b68e7db8e23cccd5ddc6a84be932dd4de4a6"
PREFIX_GENERATOR_SHA = "35ec079e3e9144468757a5714b4651424517d175b8f07d823d540941a40af7ec"
PREFIX_SCOPE_SHA = "df76ca3feb53ebce6415d13b1a830ecd3243217df0435ff12e82fcf4915e65da"
STRICT_SHA = "0a121998881b8ac94e0b816c315579d0789e7a714fb875356b5c758d239ea60c"
CONTROL_SHA = "1cff85d6656ba2afe90c89ee5a7e37a68bfa72f9592c273e4396a672520f268f"
HOST_SHA = "0f3c11a523ca7981b5d3e373c10d67d0ade5bf5cac9212e02e0186d6368b438c"
COMMIT, BASE = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f", "ec0a8d0cc56f0915e985ca7d1528daab1450c00d"
OLD_COMMIT = "81243a1300304d7e598156c692be2fcbf2c16268"
BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PHYSICAL_CORE = RAW / "local-multicopy-ready1-address-route-proof-264/physical.py"
PHYSICAL_CORE_SHA = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"
PHYSICAL_CORE_SCOPE_SHA = "976c13d6111f7bda5c7cfdc49df5089e23af4969b3294c12dee2a392dc46790a"
TIMING_CORE = RAW / "driver-copy-ready-groups8-proof-264/timing.py"
TIMING_CORE_SHA = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
TIMING_CORE_SCOPE_SHA = "5088a952653ccd349edb109bd68e038cace200c911ec7707cef1d958897d8032"


def require(value, message):
    if not value: raise ValueError(message)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def adopt(audit, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        audit.bind(Path(name), expected, execution=True)


def comparison(args):
    require(args.prefix_sha256 == PREFIX_SHA and args.profile_sha256 == PROFILE_SHA and
            re.fullmatch(r"[0-9a-f]{64}", args.run_sha256) and args.run_sha256 != "0" * 64 and not (HERE / "comparison.json").exists(),
            "actual positive prefix/prepared profile/closed full run and exclusive output required")
    native = load(PURE, PURE_SHA, "ninth_full_native_parser")
    audit = native.Audit()
    pins = ((PURE, PURE_SHA), (Path(__file__).resolve(), args.self_sha256), (HERE / "scope.md", args.scope_sha256),
        (HERE / "native_scope.py", args.native_sha256), (HERE / "native-scope.md", args.native_scope_sha256),
        (HERE / "physical.py", args.physical_sha256), (HERE / "physical-scope.md", args.physical_scope_sha256),
        (HERE / "timing.py", args.timing_sha256), (HERE / "timing-scope.md", args.timing_scope_sha256),
        (ROUTE / "source-identity.json", args.profile_sha256), (ROUTE / "run_route.py", RUNNER_SHA), (ROUTE / "scope.md", RUNNER_SCOPE_SHA),
        (ROUTE / "route-c0/run.json", args.run_sha256), (PREFIX / "baseline/comparison-prefix-v2.json", args.prefix_sha256),
        (PREFIX / "compare_prefix_v2.py", PREFIX_GENERATOR_SHA), (PREFIX / "prefix-v2-scope.md", PREFIX_SCOPE_SHA),
        (PREFIX / "baseline/comparison-prefix.json", STRICT_SHA), (PREFIX / "source-identity.json", PREFIX_PROFILE_SHA),
        (PREFIX / "baseline/run.json", PREFIX_RUN_SHA), (ACCEPTED, ACCEPTED_SHA), (PARENT / "run.json", PARENT_RUN_SHA),
        (CONSTRUCTION, CONSTRUCTION_SHA), (BEFORE / "run.json", CONSTRUCTION_RUN_SHA),
        (BEFORE.parent / "source-identity.json", CONSTRUCTION_PROFILE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA),
        (PHYSICAL_CORE, PHYSICAL_CORE_SHA), (PHYSICAL_CORE.parent / "physical-scope.md", PHYSICAL_CORE_SCOPE_SHA),
        (TIMING_CORE, TIMING_CORE_SHA), (TIMING_CORE.parent / "timing-scope.md", TIMING_CORE_SCOPE_SHA))
    for path, expected in pins: audit.bind(path, expected)
    profile, record = native.read(ROUTE / "source-identity.json"), native.read(ROUTE / "route-c0/run.json")
    prefix, parent, construction = (native.read(path) for path in (PREFIX / "baseline/comparison-prefix-v2.json", ACCEPTED, CONSTRUCTION))
    for manifest in (prefix, parent, construction): adopt(audit, manifest)
    require(prefix["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-explicit-private-owner-native-prefix" and
            prefix["generator_sha256"] == PREFIX_GENERATOR_SHA and prefix["scope_sha256"] == PREFIX_SCOPE_SHA and
            prefix["source_identity_sha256"] == PREFIX_PROFILE_SHA and prefix["current_baseline_run_sha256"] == PREFIX_RUN_SHA and
            prefix["compiler_commit"] == COMMIT and prefix["immutable_strict_prefix_rejection_sha256"] == STRICT_SHA and
            prefix["structural_rejection"] is prefix["native_path_topology_rejection"] is None and
            all(prefix[key] is True for key in ("native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
                "all_eight_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "private_output_frame_alignment_used",
                "final_original_path_metadata_and_runtime_hashes_stable")), "actual V2 prefix prerequisite differs")
    require(parent["structural_rejection"] is None and parent["native_graph_proof_available"] is parent["physical_scope_proved"] is
            parent["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and parent["current_full_run_sha256"] == PARENT_RUN_SHA and
            construction["structural_rejection"] is None and construction["native_graph_proof_available"] is construction["physical_scope_proved"] is True and
            construction["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and construction["current_full_run_sha256"] == CONSTRUCTION_RUN_SHA and
            construction["source_identity_sha256"] == CONSTRUCTION_PROFILE_SHA and construction["accepted_full_proof_sha256"] == ACCEPTED_SHA,
            "old eighth structural construction versus accepted fifth timing roles differ")
    require(profile["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-fresh-driver-full-route" and
            profile["prefix_proof_sha256"] == PREFIX_SHA and profile["prefix_baseline_run_sha256"] == PREFIX_RUN_SHA and
            profile["prefix_source_identity_sha256"] == PREFIX_PROFILE_SHA and profile["prefix_generator_sha256"] == PREFIX_GENERATOR_SHA and
            profile["prefix_scope_sha256"] == PREFIX_SCOPE_SHA and profile["immutable_strict_prefix_rejection_sha256"] == STRICT_SHA and
            profile["control_proof_sha256"] == CONTROL_SHA and profile["host_validation_sha256"] == HOST_SHA and
            profile["accepted_full_proof_sha256"] == ACCEPTED_SHA and profile["accepted_full_run_sha256"] == PARENT_RUN_SHA and
            profile["experimental_eighth_full_proof_sha256"] == CONSTRUCTION_SHA and profile["experimental_eighth_full_run_sha256"] == CONSTRUCTION_RUN_SHA and
            profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and
            profile["source_archive_sha256"] == ARCHIVE_SHA and profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            profile["minimum_accepted_memory_mhz"] == 117.77175903320312 and len(profile["prefix_fresh_local_models"]) == 9,
            "prepared ninth profile/compiler/source/proof roles differ")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    for key, value in profile.items():
        if key != "input_sha256": require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["source_identity_sha256"] == args.profile_sha256 and record["completed"] is True and record["exit_code"] == 0 and
            record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): args.profile_sha256} and
            record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip", "actual completed run/profile/runtime differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is outside frozen input closure")
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(ROUTE / "route-c0" / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")},
            "complete actual output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output empty")
        audit.bind(Path(name), expected)
    runner = load(ROUTE / "run_route.py", RUNNER_SHA, "ninth_full_record_definitions")
    ninth, control, local, driver_defs = runner.definitions()
    for path, expected in ((PREFIX / "run_baseline.py", runner.NINTH_SHA), (PREFIX / "scope.md", runner.NINTH_SCOPE_SHA),
            (runner.OLD, runner.OLD_SHA), (runner.OLD.parent / "scope.md", runner.OLD_SCOPE_SHA), *control.PARSERS):
        require(audit.paths.get(path) == expected, "executed pure parser is outside closure")
    for name, expected in control.SCRIPTS.items(): audit.bind(ROOT / "sources/misteross/scripts" / name, expected)
    require(audit.paths.get(ninth.HOST) == HOST_SHA and audit.paths.get(ninth.BINARY) == BINARY_SHA and
            audit.paths.get(ninth.ARCHIVE) == ARCHIVE_SHA, "current host/binary/archive outside flat closure")
    control.host_valid(native.read(ninth.HOST), HOST_SHA)
    baseline, template, accepted_run = (native.read(path) for path in (PREFIX / "baseline/run.json", BEFORE / "run.json", PARENT / "run.json"))
    require(baseline["completed"] is template["completed"] is accepted_run["completed"] is True and
            baseline["compiler_commit"] == COMMIT and template["compiler_commit"] == accepted_run["compiler_commit"] == OLD_COMMIT and
            record["command"] == runner.command(baseline, template, ninth, control) and
            baseline["execution"] == record["execution"] == control.expected_execution(template) and
            record["cwd"] == baseline["cwd"] == template["cwd"] == accepted_run["cwd"] and record["diagnostic_environment"] ==
            baseline["diagnostic_environment"] == template["diagnostic_environment"] == accepted_run["diagnostic_environment"],
            "actual old/new compiler command/runtime/environment frame differs")
    log = (ROUTE / "route-c0/route.log").read_text()
    trial, models = driver_defs.qualification(log), ninth.qualification(log, control, local)
    require(native.canonical(trial) == native.canonical(record["actual_fresh_driver_qualification"]) and trial["domain_summary"] == ["334", "331", "3", "331", "1"] and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) == native.canonical(profile["prefix_fresh_local_models"]) ==
            native.canonical(prefix["fresh_local_models"]) and native.canonical(models[:8]) == native.canonical(template["actual_selected_local_qualification"]),
            "actual guarded ninth/eight-retained/fresh-driver qualification differs")
    metrics = native.PLACEMENT_METRICS.findall(log)
    placement_exact = len(metrics) == 71 and metrics == native.PLACEMENT_METRICS.findall((PREFIX / "baseline/phase.log").read_text())
    before, after = native.read_netlist(BEFORE / "routed.json"), native.read_netlist(ROUTE / "route-c0/routed.json")
    predicted = native.read_netlist(PREFIX / "baseline/placed.json")
    report, parent_report, predicted_report = (native.read(path) for path in (ROUTE / "route-c0/timing.json", PARENT / "timing.json", PREFIX / "baseline/timing.json"))
    timing_core = load(TIMING_CORE, TIMING_CORE_SHA, "ninth_full_timing_lower_definitions")
    timing = load(HERE / "timing.py", args.timing_sha256, "ninth_full_current_timing_gate")
    timing_result = timing.evaluate(timing_core, after, report, parent_report, predicted_report, log, record)
    for name, expected in timing_result["evidence"]["pinned_pure_module_sha256"].items():
        require(audit.paths.get(Path(name)) == expected, "timing imported dependency is unauthenticated")
    frozen = load(FREEZE, FREEZE_SHA, "ninth_full_freeze_definitions")
    selected = load(SELECTED, SELECTED_SHA, "ninth_full_native_tables", frozen)
    proof = load(HERE / "native_scope.py", args.native_sha256, "ninth_full_named_slot_proof")
    physical_core = load(PHYSICAL_CORE, PHYSICAL_CORE_SHA, "ninth_full_physical_lower_definitions")
    physical = load(HERE / "physical.py", args.physical_sha256, "ninth_full_current_physical_proof")
    graph, physical_evidence, rejection = None, None, None
    try:
        require(after["creator"] == predicted["creator"] and placement_exact, "current compiler creator/original placement sequence differs")
        graph = proof.prove(native, selected, before, after, prefix["native_graph_evidence"], profile, trial)
        ledger = {key: graph[key] for key in ("ready", "driver", "buffer_rows", "private_output_rows")}
        physical_evidence = physical.evaluate(physical_core, before, after, ledger, profile, trial)
        require(physical_evidence["physical_scope_proved"] is True, "independent physical scope did not pass")
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        rejection = str(error)
    audit.finish()
    passed = rejection is None and timing_result["passes_practical_timing_gate"]
    return {"schema": 1, "phase": "local-plan16-ready1-skid-byte-ninth-stage-full-route-inspection", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "source_identity_sha256": args.profile_sha256, "current_full_run_sha256": args.run_sha256,
        "prefix_proof_sha256": args.prefix_sha256, "accepted_full_proof_sha256": ACCEPTED_SHA,
        "structural_before_full_proof_sha256": CONSTRUCTION_SHA, "structural_before_full_run_sha256": CONSTRUCTION_RUN_SHA,
        "structural_before_timing_gain_accepted": False, "immutable_strict_prefix_rejection_sha256": STRICT_SHA,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256, "native_helper_sha256": args.native_sha256,
        "native_scope_sha256": args.native_scope_sha256, "physical_helper_sha256": args.physical_sha256,
        "physical_scope_sha256": args.physical_scope_sha256, "timing_helper_sha256": args.timing_sha256, "timing_scope_sha256": args.timing_scope_sha256,
        "candidate_completed": True, "structural_rejection": rejection, "native_graph_proof_available": graph is not None,
        "physical_scope_proved": physical_evidence is not None and rejection is None, "native_graph_evidence": graph,
        "physical_evidence": physical_evidence, "timing": timing_result, "routed_gain_accepted_under_confirmed_target_clock_rule": passed,
        "all_71_placement_metrics_exact": placement_exact, "actual_fresh_driver_qualification": trial, "fresh_local_models": models,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True, "independent_numerical_sta_proved": False,
        "rbf_decoded_or_hardware_tested": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "native-sha256", "native-scope-sha256", "physical-sha256", "physical-scope-sha256",
            "timing-sha256", "timing-scope-sha256", "prefix-sha256", "run-sha256", "profile-sha256"):
        parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    import json
    with (HERE / "comparison.json").open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_graph_proof_available",
        "physical_scope_proved", "routed_gain_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__": main()
