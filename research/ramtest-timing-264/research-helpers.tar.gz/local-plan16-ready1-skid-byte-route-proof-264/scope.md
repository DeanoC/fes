# Ninth full-route comparison

ROOT alone executes this new exclusive comparison after whole-byte/hash/AST and
independent peer review. Actual full run SHA is mandatory and is never predicted.
The prepared full profile788f16d2, recorder1381258c/scope355863f2 and positive
ninth prefixd1ee7000/profileaceefeba/run899a21d8 are fixed. The strict rejection
0a121998 remains separately bound through the V2 flat closure. Current source
d7e5c61f/baseec0a8d0c/ELF41c2afe1/archive4fbebd5e/host0f3c11a5 and fresh-eight
control1cff85d6 qualify this compiler; old compiler checks do not qualify it.

Structural before is actual old-eight full3ef0c0b6 with native/physical-positive
but timing-rejected prooff74c76d8. Numerical acceptance uses the separate actual
accepted-five full5ed3c077/proof6dcf8c4b at117.77175903320312MHz. The ninth route
must strictly exceed that value. The source-version creator strings may differ
between old and current compilers and are disclosed; current full creator must
equal its own same-binary predicted creator. Every other native top field is
strict. No old-eight Fmax, delay, candidate or physical proof is inherited.

The flat prefix/accepted/construction artifact and runtime closures are rehashed
once alongside every current profile input, record/profile union, actual runtime,
four actual outputs and these eight new files. Current command must equal the
literal ninth recorder's independent dual construction. Runtime must equal the
current ninth baseline and old-eight frame after only current ELF/PATH changes;
cwd and diagnostic environment stay exact. Current host/source/dependency maps,
all nine complete local trial dictionaries, fresh driver0/domain guards and
all71 placement metrics are independently bound. No old prepare/route/main,
source-clean query, recursive authenticator or proof generator is called.

Pinned32fd supplies lossless paired-PLL parsing/Audit/canonical. Current recorder
definitions supply only pure command/log/host checks. Pinned72131/8601 supply
native tables/topology;60ca4442 supplies only lower physical definitions, and
e6ce77b7 only lower timing loading/path functions. Executed project imports and
their direct dependencies are pinned before use and checked in final closure.

Native proof permits one absent-before ready1 ALUT4$local_remap$3/private net,
two FF3/7 ENA redirects at LAB27.21 and four added actual boundary load slots.
All eight prior copies and cohorts21/2/10/1/6/1/1/3 stay literal. Per-image named
frames separately prove four generated private outputs, the requalified driver
copy Q and all5232 existing late buffers, with unique owners/aliases/consumers.
All other raw slots, metadata, public ports, original owner order, paired PLLs,
FF placements and complete pin/LAB snapshots are strict. ROUTING net attributes
are the only ordinary route fields omitted from semantic equality; actual route
files/RBF remain bound, with no byte-equivalence or decoded-pip claim.

Pure physical proof checks actual pin-state/inversion/constant functions and
16-row ready composition, both current/reference driver eight-row functions,
immediate arithmetic carry and whole old/current dynamic driver/copy LABs.
All original FF controls, shared occupied ALM banks and explicit5232 buffer
banks are independently reconstructed. Missing or different exported state
fails closed. Unexported caches/GPU IDs, numerical STA, RBF decode and hardware
remain unproved.

Current timing is computed before structural checks so a graph rejection retains
actual timing evidence. The complete current15290 endpoints/seven actual domain
pairs must match own predicted and accepted-five endpoint/window coverage.
All six non-target headrooms must be positive; pixel/capture constraints and
zero LAST signoff holds are required. The130MHz memory miss is visible separately,
and all-clock Fmax/headroom changes are disclosed as diagnostics. Only combined
native, physical and current timing success accepts gain. Every original path
is rehashed at the end, including on serialized structural rejection.
