# Ninth current-window timing gate

evaluate(core,complete_document,report,accepted_fifth_report,own_predicted_report,
log,record) returns current timing evidence and a timing-only decision. It never
calls the old timing evaluate. Pinned e6ce77b7 contributes only lower _load/_paths;
72131/8601 independently check current native report topology. The complete
lossless document, not its top module alone, is required.

Accepted five is exactly117.77175903320312/93.6504898071289/259.49139404296875MHz.
The old-eight rejected report is never the timing parent. Current memory must
strictly exceed117.77175903320312; pixel and capture must meet their actual
constraints. All three constraints are exact. Current15290 unique endpoints,
seven domain pairs and actual windows must match accepted-five and own ninth
prediction. Every finite emitted path term is summed with math.fsum. Capture's
actual5ns phase window and memory half-cycle3.8459999561309814ns stay exact.

All six non-target worst headrooms must be positive. Target130MHz closure is
reported separately and may remain open under the confirmed target-gain rule.
Each relation distinguishes reported_window_met from acceptance-window policy.
All-clock Fmax nonregression and each headroom change remain visible diagnostics;
lower positive margins may be accepted but are disclosed.

The actual LAST RBF signoff must have neither literal hold violation nor broader
hold/min warning/negative lines. Exact recorder Fmax/hold fields are crosschecked.
Pinned board _require_gpu_backend and HIP completion/normal exit reject fallback.
Board source_repository29ab5ad5/lockfile742d5b39 bytes and loaded module paths
are checked and returned in evidence for the caller's original-path closure.

No independent numerical STA, unreported extrema, analogue calibration, physical
function, decoded RBF or hardware acceptance is claimed. Graph/physical proof and
caller authentication/final rehash remain separately mandatory for gain.
