# Ninth exported physical scope

evaluate(core,before_doc,after_doc,ledger,profile,trial) is pure. The caller must
bind the separately pinned60ca4442 lower core and all documents; only lower
PhysicalView/evaluate_alm/evaluate_lut/_shape/_boundary/_read_shape/_driver_proof/
_ff_pair/_buffer_proof definitions are called. Old evaluate/_ready_proof and any
validator or generator are never called. Ledger keys are exactly ready, driver,
buffer_rows and private_output_rows from the new native proof.

Actual before old-eight and current ninth pin snapshots, typed native driver
tokens and physical ALUT masks prove innerALUT2/outerALUT3/retainedALUT4/newALUT4
composition on four distinct effective boundary tokens. All16 rows use actual
SIG/INV/constants, both real32-row halves, active-low storage and final MCOMB
logic permutation where applicable. The eight retained copies/cohorts remain
exact, root102→100 and only two declared FF3/7 ENAs become the equivalent new Q.
Original FF CLK/pins/BEL remain exact; conditional logical metadata is not a
substitute for these actual evaluated physical functions.

Both old/current requalified driver copy images are independently evaluated for
the original source eight-row function and single arithmetic operand. Arithmetic
LUT0/1, q0+!q1+CI, dedicated CO→immediate CI and physical sharing remain in the
pinned lower proof. Actual old and current driver/copy LABs are derived from both
images and added to the predeclared whole-LAB scope. Every original FF member in
that complete union retains controls apart from the two equivalent ENAs.

Whole original LAB selectors/modes/snapshot records are exact. Every occupied
original ALM bank/function/shared input token is exact except the actual new
ready copy and independently proved requalified driver site. Four original
private-owner physical functions and all5232 named existing buffers/unique FFs
are independently reconstructed without numerical ID translation or collapse.
Missing snapshots, unexpected MLAB occupancy or sharing changes reject scope.

Evidence is exported-state truth, not independently decoded CRAM/RBF bits,
route muxes/pips, hidden comb caches/GPU IDs, numerical STA or hardware. The helper
does not accept routed gain; the independent current timing gate remains required.
