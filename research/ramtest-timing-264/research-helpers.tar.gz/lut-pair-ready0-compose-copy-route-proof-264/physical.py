"""Pure exported physical checks against this candidate's own selected graph."""

CORE_SHA256 = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"
CORE_PATH_SUFFIX = "local-multicopy-ready1-address-route-proof-264/physical.py"


def require(value, message):
    if not value:
        raise ValueError("composed-copy physical proof: " + message)


def _signal(native, name, port, direction, connected=True):
    cell = native.cells[name]
    bits = cell["connections"].get(port)
    require(cell["port_directions"].get(port) == direction and type(bits) is list and
            (len(bits) == 1 if connected else len(bits) <= 1) and
            all(type(bit) is int and bit >= 0 for bit in bits), "native scalar slot differs: " + name + "." + port)
    if not bits:
        return None
    token = native.token(bits[0])
    require(token[0] not in ("constant", "undriven"), "unresolved native scalar driver")
    return token


def _alm(core, cell):
    _, x, y, z = core._location(cell)
    return x, y, z // 6


def _alias(native, name, port="Q"):
    bit = native.cells[name]["connections"][port][0]
    aliases = native.aliases.get(bit, [])
    require(len(aliases) == 1 and aliases[0][1] == 0 and
            native.top["netnames"][aliases[0][0]]["bits"] == [bit] and
            not native.top_users.get(bit), "private output is not one nonpublic scalar alias")
    return bit, aliases[0][0]


def _buffers(core, selected, routed, rows):
    require(type(rows) is list and
            len({row["buffer"] for row in rows}) == len({row["ff"] for row in rows}) == len(rows) and
            {row["buffer"] for row in rows} == {name for name, cell in routed.cells.items() if cell["type"] == "MISTRAL_BUF"} and
            not any(cell["type"] == "MISTRAL_BUF" for cell in selected.cells.values()),
            "complete fresh late-BUF/FF population differs")
    evidence, transfers = [], {}
    for row in rows:
        name, ff = row["buffer"], row["ff"]
        require(name not in selected.cells and ff in selected.cells and
                selected.cells[ff]["type"] == routed.cells[ff]["type"] == "MISTRAL_FF", "late BUF/FF owner differs")
        shape = core._shape(routed, name)
        original = _signal(selected, ff, "DATAIN", "input")
        copied = shape["outputs"]["Q"]
        require(shape["type"] == "MISTRAL_BUF" and shape["tables"] == [2] and
                shape["inputs"][0]["state"] == 0 and shape["inputs"][0].get("driver") == original and
                _signal(routed.native, ff, "DATAIN", "input") == copied and
                routed.native.users.get(copied) == [(ff, "DATAIN", 0)] and
                core._truth(shape)["rows"] == [{"row": 0, "Q": 0}, {"row": 1, "Q": 1}],
                "late BUF does not independently forward the exact original unique FF DATAIN")
        q, alias = _alias(routed.native, name)
        require(alias not in selected.top["netnames"], "new BUF alias already exists in selected graph")
        transfers[ff] = {"buffer": name, "original": original, "copied": copied}
        evidence.append({"buffer": name, "ff": ff, "actual_q_raw_bit": q, "actual_private_alias": alias,
                         "original_input_driver": list(original), "unique_ff_consumer": [ff, "DATAIN", 0],
                         "actual_forwarding_rows": core._truth(shape), "actual_physical_bank": core.evaluate_lut(routed, name)})
    return evidence, transfers


def _private_rows(selected, routed, rows):
    require(type(rows) is list and len({row["owner"] for row in rows}) == len({row["alias"] for row in rows}) == len(rows),
            "private output owner/alias ledger has duplicates")
    names = set(selected.top["netnames"])
    require(names <= set(routed.top["netnames"]), "an original selected alias disappeared")
    changed = {name for name in names if selected.top["netnames"][name]["bits"] != routed.top["netnames"][name]["bits"]}
    require(changed == {row["alias"] for row in rows}, "original raw alias changes are outside the explicit owner ledger")
    result = []
    for row in rows:
        name, alias = row["owner"], row["alias"]
        old_q, old_alias = _alias(selected, name)
        new_q, new_alias = _alias(routed.native, name)
        require(old_alias == new_alias == alias and old_q == row["old_raw_bit"] and new_q == row["new_raw_bit"] and
                old_q != new_q and selected.token(old_q) == routed.native.token(new_q) == ("cell", name, "Q", 0),
                "declared private output frame does not have its exact typed unique Q driver")
        result.append({"owner": name, "alias": alias, "old_raw_bit": old_q, "new_raw_bit": new_q,
                       "actual_native_driver": ["cell", name, "Q", 0]})
    return result


def _native_frame(selected, routed, transfers):
    buffers = {row["buffer"] for row in transfers.values()}
    require(set(routed.cells) == set(selected.cells) | buffers and len(selected.cells) == 14908 and
            selected.pll_ports == routed.native.pll_ports,
            "routed original owners or lossless paired PLL records differ")
    expected_users = {token: list(slots) for token, slots in selected.users.items()}
    for ff, row in transfers.items():
        slot = (ff, "DATAIN", 0)
        require(slot in expected_users.get(row["original"], []), "original FF DATAIN slot is absent")
        expected_users[row["original"]].remove(slot)
        expected_users[row["original"]].append((row["buffer"], "A", 0))
        expected_users[row["copied"]] = [slot]
    require(routed.native.users == {token: sorted(slots) for token, slots in expected_users.items()},
            "complete native consumers differ outside named late-BUF forwarding")
    for name, old in selected.cells.items():
        new = routed.cells[name]
        require(old["type"] == new["type"] and old["parameters"] == new["parameters"] and
                old["port_directions"] == new["port_directions"] and
                old["attributes"].get("NEXTPNR_BEL") == new["attributes"].get("NEXTPNR_BEL"),
                "original intended table/type/BEL/ports differ: " + name)
        intended = {port: list(tokens) for port, tokens in selected.connections[name].items()}
        if name in transfers:
            intended["DATAIN"] = [transfers[name]["copied"]]
        require(intended == routed.native.connections[name], "original native driver slots differ: " + name)
    return {"all_original_intended_tables_types_ports_and_bels_exact": True,
            "all_original_native_driver_and_reverse_consumer_slots_exact_except_explicit_buffer_forwarding": True,
            "global_buffer_collapse_or_raw_id_translation_used": False}


def _read(core, shape, assignment):
    require(not shape["arithmetic"] and len(shape["tables"]) == 1, "control cone is not an ordinary single-output LUT")
    address = sum(core._value(entry, assignment) << index for index, entry in enumerate(shape["inputs"]))
    return (shape["tables"][0] >> address) & 1


def _copy(core, selected, routed, ready, profile, transfers):
    candidate = profile["expected_candidate"]
    inner, outer, clone = candidate["inner"], candidate["outer"], ready["new_clone"]
    require(clone == profile["new_local_clone"] == profile["prefix_native_graph_evidence"]["new_clone"] and
            set(profile["prefix_native_graph_evidence"]["original_pair"]) == {inner, outer} and
            selected.cells[clone]["type"] == routed.cells[clone]["type"] and
            selected.cells[clone]["parameters"] == routed.cells[clone]["parameters"] and
            selected.cells[clone]["attributes"]["NEXTPNR_BEL"] == routed.cells[clone]["attributes"]["NEXTPNR_BEL"] == candidate["clone_bel"],
            "actual full clone/pair/site differs from independently selected identity")
    a, b, c = (core._shape(routed, name) for name in (inner, outer, clone))
    require(all(not shape["arithmetic"] and shape["outputs"].keys() == {"Q"} for shape in (a, b, c)),
            "actual physical cone is not three ordinary LUTs")
    mid, root, copied = a["outputs"]["Q"], b["outputs"]["Q"], c["outputs"]["Q"]
    require(mid != root and any(entry.get("driver") == mid for entry in b["inputs"]), "actual inner→outer physical boundary differs")
    external = {entry["driver"] for shape in (a, b) for entry in shape["inputs"] if "driver" in entry and entry["driver"] != mid}
    require(mid not in {entry.get("driver") for entry in a["inputs"]} and root not in external and
            0 < len(external) <= 6 and external == {entry["driver"] for entry in c["inputs"] if "driver" in entry},
            "actual composed physical cut has feedback, missing or introduced inputs")
    boundary, truth = sorted(external), []
    for row in range(1 << len(boundary)):
        assignment = {token: (row >> index) & 1 for index, token in enumerate(boundary)}
        assignment[mid] = _read(core, a, assignment)
        old, new = _read(core, b, assignment), _read(core, c, assignment)
        require(old == new, "actual routed constants/inversions/composed truth differ")
        truth.append({"row": row, "inner": assignment[mid], "original_outer": old, "clone": new})
    sink = candidate["sink"]
    require(sink.endswith(".ENA"), "selected endpoint is not ENA")
    ff = sink[:-4]; target = _alm(core, selected.cells[ff])[:2]
    before_token = _signal(selected, clone, "Q", "output")
    cohort = selected.users.get(before_token, [])
    require(cohort == routed.native.users.get(copied) and len(cohort) == candidate["cohort"] and
            (ff, "ENA", 0) in cohort and all(selected.cells[name]["type"] == "MISTRAL_FF" and port == "ENA" and index == 0 and
                _alm(core, selected.cells[name])[:2] == target and
                _signal(selected, name, "CLK", "input") == _signal(selected, ff, "CLK", "input") for name, port, index in cohort),
            "actual private clone is not the exact whole same-clock selected ENA cohort")
    for name, port, index in cohort:
        require(routed.pins(name)["ENA"] == [0, "ENA"] and _signal(routed.native, name, "ENA", "input") == copied,
                "selected FF ENA does not directly receive the independently equivalent Boolean output")
    original_root_users = selected.users.get(_signal(selected, outer, "Q", "output"), [])
    expected_root_users = [(transfers[name]["buffer"], "A", 0) if name in transfers and port == "DATAIN" else (name, port, index)
                           for name, port, index in original_root_users]
    require(routed.native.users.get(root) == sorted(expected_root_users), "original root side consumers differ outside explicit BUF forwarding")
    clone_q, alias = _alias(routed.native, clone)
    require(alias == clone + "$Q", "actual clone private alias differs")
    key = _alm(core, routed.cells[clone])
    require(routed.occupants.get(key) == [(clone, core._location(routed.cells[clone])[0], core._location(routed.cells[clone])[3] % 6)] and
            not any(name != clone and core.BEL.fullmatch(cell.get("attributes", {}).get("NEXTPNR_BEL", "")) and
                    _alm(core, cell) == key for name, cell in selected.cells.items()),
            "actual clone ALM is not isolated from every original selected neighbor")
    return {"inner": inner, "outer": outer, "clone": clone, "actual_clone_q": clone_q, "actual_private_alias": alias,
            "native_input_boundary": [list(token) for token in boundary], "assignments_checked": len(truth), "actual_effective_truth_rows": truth,
            "actual_pin_constants_and_inversions_used": True, "exact_same_clock_ena_cohort": [list(slot) for slot in cohort],
            "retained_original_root_consumers": [list(slot) for slot in original_root_users],
            "actual_root_consumers_after_explicit_buffer_forwarding": [list(slot) for slot in sorted(expected_root_users)],
            "original_inner": core.evaluate_lut(routed, inner), "original_outer": core.evaluate_lut(routed, outer),
            "actual_clone": core.evaluate_lut(routed, clone)}, {inner, outer, clone, *(name for name, _, _ in cohort)}


def _ff_rows(core, selected, routed, names):
    rows, selectors, aclr = [], {}, {}
    for name in sorted(names):
        require(name in selected.cells and selected.cells[name]["type"] == routed.cells[name]["type"] == "MISTRAL_FF" and
                selected.cells[name]["parameters"] == routed.cells[name]["parameters"] and
                selected.cells[name]["attributes"]["NEXTPNR_BEL"] == routed.cells[name]["attributes"]["NEXTPNR_BEL"],
                "original FF table/BEL differs")
        key = _alm(core, routed.cells[name]); state = routed.labs[key[:2]][3][2 + 6 * key[2]:8 + 6 * key[2]]
        record = core._ff(routed, name, state)
        for port, control in record["controls"].items():
            token = _signal(selected, name, port, "input", False)
            require(control["driver"] == (list(token) if token else None) and control["pins"] == routed.pins(name)[port] and
                    len(control["pins"]) == 2 and control["pins"][1] == port and
                    control["pins"][0] in ((0, 3) if token else (1, 2)), "original FF control driver or actual Boolean state differs")
        group = (key[:2], record["clk_ena_selector"])
        pair = tuple((record["controls"][port]["pins"][0], tuple(record["controls"][port]["driver"] or ())) for port in ("CLK", "ENA"))
        require(group not in selectors or selectors[group] == pair, "one saved LAB CLK/ENA selector has different actual control signals")
        selectors[group] = pair
        reset = record["controls"]["ACLR"]
        if reset["driver"] is not None:
            group = (key[:2], record["aclr_selector"]); signal = (reset["pins"][0], tuple(reset["driver"]))
            require(group not in aclr or aclr[group] == signal, "one saved LAB ACLR selector has different actual control signals")
            aclr[group] = signal
        rows.append(record)
    return {"actual_original_ff_control_rows": rows, "ff_count": len(rows),
            "actual_whole_lab_clk_ena_and_aclr_selector_groups_consistent": True,
            "original_unexported_pre_route_pin_and_controller_cache_equality_proved": False}


def evaluate(core, selected_doc, routed_doc, logical_ledger, profile):
    """No file access, imports, authentication, mutation, STA or RBF decoding."""
    require(set(logical_ledger) == {"ready", "buffer_rows", "private_output_rows"} and
            profile["driver_pass_executed"] is profile["post_plan_requested"] is False,
            "fresh no-driver physical ledger contract differs")
    selected = core.Native(selected_doc["modules"]["top"])
    routed = core.PhysicalView(routed_doc["modules"]["top"])
    command = profile["command"]
    require(command.count("--device") == 1 and routed.device == command[command.index("--device") + 1], "exported physical device differs")
    for name, cell in routed.cells.items():
        if "FES_PINMAP_V1" in cell.get("attributes", {}):
            routed.pins(name)
    buffers, transfers = _buffers(core, selected, routed, logical_ledger["buffer_rows"])
    private = _private_rows(selected, routed, logical_ledger["private_output_rows"])
    native_frame = _native_frame(selected, routed, transfers)
    copy, names = _copy(core, selected, routed, logical_ledger["ready"], profile, transfers)
    names.update(row["owner"] for row in private)
    names.update(row["cell"] for row in profile["retained_copy_cohorts"])
    labs = set(map(tuple, profile["affected_whole_labs"]))
    for name in names:
        labs.add(_alm(core, routed.cells[name])[:2])
    for token in copy["native_input_boundary"]:
        if token[0] == "cell" and core.BEL.fullmatch(routed.cells[token[1]].get("attributes", {}).get("NEXTPNR_BEL", "")):
            labs.add(_alm(core, routed.cells[token[1]])[:2])
    require(labs and all(key in routed.labs for key in labs), "whole affected LAB is outside actual snapshot")
    original_ffs = {name for name, cell in selected.cells.items() if cell["type"] == "MISTRAL_FF" and _alm(core, cell)[:2] in labs}
    require(original_ffs == {name for name, cell in routed.cells.items() if cell["type"] == "MISTRAL_FF" and _alm(core, cell)[:2] in labs} and
            profile["all_original_ff_members_in_affected_labs"] == [{"cell": name, "record": cell} for name, cell in selected.cells.items()
                if cell["type"] == "MISTRAL_FF" and _alm(core, cell)[:2] in set(map(tuple, profile["affected_whole_labs"]))],
            "complete original whole-LAB FF manifest differs")
    ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in routed.cells.items() if cell["type"] == "MISTRAL_FF"}
    require(len(ffs) == 8221 and ffs == profile["all_original_ff_bel_manifest"], "all original FF BELs differ")
    controls = _ff_rows(core, selected, routed, original_ffs | set(transfers))
    alms = [core.evaluate_alm(routed, (*lab, index)) for lab in sorted(labs) for index in range(10)]
    original_banks = [bank for alm in alms for bank in alm["occupied_banks"] if bank["cell"] in selected.cells]
    require(all(routed.cells[bank["cell"]]["type"] == selected.cells[bank["cell"]]["type"] and
                routed.cells[bank["cell"]]["parameters"] == selected.cells[bank["cell"]]["parameters"] for bank in original_banks),
            "actual original physical banks use different intended selected tables")
    return {"schema": 1, "physical_scope_proved": True, "inherited_pure_core_sha256": CORE_SHA256,
            "actual_routed_composed_clone_function_and_ena_equivalence_proved": True, "composed_copy": copy,
            "fresh_selected_native_to_routed_frame": native_frame, "actual_late_buffer_count": len(buffers), "explicit_late_buffer_rows": buffers,
            "explicit_private_output_owner_frames": private, "whole_affected_labs": [list(key) for key in sorted(labs)],
            "whole_actual_lab_alm_and_shared_bank_rows": alms, "original_intended_bank_count": len(original_banks),
            "whole_original_ff_controls": controls, "all_original_ff_bels_exact": True,
            "actual_original_tables_interpreted_using_current_exported_pin_states": True,
            "historical_routed_physical_frame_or_unexported_selected_pin_state_inherited": False,
            "original_unexported_pre_route_pin_and_controller_cache_equality_proved": False,
            "complete_route_or_device_legality_independently_proved": False,
            "unexported_comb_cache_gpu_ids_or_indexed_user_store_holes_proved": False,
            "route_muxes_pips_rbf_or_cram_independently_decoded": False,
            "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
