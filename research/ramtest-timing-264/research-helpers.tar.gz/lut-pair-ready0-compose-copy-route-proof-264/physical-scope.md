# Fresh composed-copy exported physical scope

This new pure helper owns only physical.py and this scope. Its five-argument API
is evaluate(core, selected_doc, routed_doc, logical_ledger, profile). The caller
authenticates every actual selected proof/profile/run and fresh routed output,
this helper/scope and the lower core before invoking it. Future route identities
are not guessed or embedded. ROOT alone imports, AST-checks or executes helpers.

The lower core is local-multicopy-ready1-address-route-proof-264/physical.py at
60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41.
Only Native/PhysicalView, _location/_shape/_value/_truth/_ff and evaluate_lut/
evaluate_alm are called. They parse actual exported FES_PINMAP_V1 and
FES_LABSTATE_V1, derive native driver identities and full ordinary/arithmetic
ALM banks, shared physical inputs, carry boundaries, FF controls, masks and
MCOMB permutations. No old evaluate, ready/driver/buffer proof, authenticator,
generator, main, file access, graph mutation or timing evaluator is called.

The logical ledger has exactly ready, buffer_rows and private_output_rows.
ready.new_clone must match the current positive selected graph and the actual
explicit candidate. buffer_rows contains every actual late buffer/FF pair as
{buffer,ff}; private_output_rows contains only independently audited original
raw alias changes as {owner,alias,old_raw_bit,new_raw_bit}. Each private frame is
reconstructed with a typed unique Q driver, sole alias and no public consumers.
All changed original aliases must be those exact rows. No global raw translation
or buffer collapse is used. ROOT's separate native comparator proves complete
ordered original metadata/raw slot closure and authorizes only actual deltas.

The structural reference is this candidate's own freshly selected graph, not a
historical routed image. The complete NEW late BUF population is independently
derived from actual routed types and the exact native/FF occurrence ledger; no
historical count is imposed. Every owner must independently forward its original
FF DATAIN driver, use SIG identity truth, have one private
Q alias and feed only that FF DATAIN. All original table/type/BEL/port and native
driver/reverse-consumer identities remain exact outside those explicit forwarding
slots. Every8,221 original FF BEL remains exact. There is no driver-copy pass.

The physical cone is reconstructed from the actual routed original inner/outer
LUTs and clone. Actual SIG/INV/constant states, aliases and deduplicated native
drivers define its external boundary, limited to six signals. Every2^N assignment
independently evaluates both original tables and the clone, with no reliance on
compiler truth/mask logs. The actual clone ALM must contain only that clone and
no original selected neighbor. Its sole Q alias and exact whole same-clock
target FF.ENA cohort are reconstructed; those ENAs must directly receive the
independently equivalent Boolean output. Original root side consumers are exact
after only the independently proved named DATAIN buffer forwarding.

Whole source/outer/target/clone, retained-copy, literal leaf-driver and declared
LAB neighborhoods include every original FF and all ten ALMs, including protected
carry neighbors and shared-bank mates. Core evaluation validates actual l6/carry
modes against occupants, dedicated carry edges, complete physical input sharing,
ordinary/arithmetic bank masks, MCOMB permutation and all FF selector snapshots.
Every late-BUF bank is also evaluated with its actual whole ALM. All original
affected-LAB and buffer-fed FF CLK/ENA/reset/load drivers, actual polarity/constant
states and saved selectors are recorded. FFs sharing a LAB CLK/ENA or connected
ACLR selector must agree on their actual control signals. Original table/type/
parameters in every evaluated bank match the proved selected intended graph.

Selected placed JSON does not export pre-route PIN0/PIN1/PIN_INV, complete LAB
controller caches, GPU identifiers or indexed-store holes. This helper never
invents that missing before frame: original banks are interpreted using their
actual CURRENT exported states, and preservation of unexported selected pin/cache
states is explicitly FALSE/unproved. Unchanged compiler behavior or backend tests
are not relabeled as that independent evidence. The newly composed function and
target ENA equivalence are independently proved from the current exported frame.
An unsupported actual shape/control/bank or any observed unproved graph delta
rejects with its exact reason; no blanket historical pin/mate/LAB waiver applies.

The wrapper computes current timing/topology and retains hashes even on physical
rejection. This helper does not decide timing acceptance: the accepted FIVE
117.77175903320312MHz reference, all15,290 paths/seven clock-pair windows, positive
six non-target headrooms and LAST holds0 belong to the separate fresh timing proof.
It proves no complete routing legality, route mux/PIP equivalence, RBF/CRAM
decoding, independent numerical STA, calibration, hardware result or gain.
