"""Prove this selected composed copy's fresh routed native, physical and timing scope."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
ROUTE, SELECTED = RAW / "lut-pair-ready0-compose-copy-route-264", RAW / "lut-pair-ready0-compose-copy-selected-264"
PROFILE, RUN = ROUTE / "source-identity.json", ROUTE / "route/run.json"
PROFILE_SHA, RUN_SHA = "79e71f1ed628b0bb0f4f97432fd8bca62ccf18e1066403c613c056215096a27b", "b76ff6967705654e9cb1a9d8756d3302f4a7db035f3fb4c4f6490c3f376a8f22"
RUNNER_SHA, RUNNER_SCOPE_SHA = "89fcae457034e0cef94d5c3b14be940e815abc5eb8dff6448065314f3eee0afc", "51246f72e01c7484a605dd6decf108ef4b0cb85c39eab47328850392c4a80526"
SELECTED_PROFILE_SHA, SELECTED_RUN_SHA = "f429189ff69ab9c2d9c3bf9f7a59815e530cf416a3abe9f75600dc808629ab59", "84252668b4943038526a41ee6e6694a905582bcc450cf97b9874e05b27f8438f"
SELECTED_PROOF_SHA = "9034eda835a0b54238c50a1ab83f358b89c64f417c27c17b1575360ef965b2c2"
SELECTED_HELPER_SHA, SELECTED_SCOPE_SHA = "fec8c4b4f31827c10ec834351bae7a28ae148368c73ad9a556359a0481396d9e", "936673ca3dedb50a23f8e5a774078c4628d36d7650b3128b766210ed2c8a2556"
SELECTED_COMPARER_SHA, SELECTED_COMPARISON_SCOPE_SHA = "6fdfdce1841119ede82d91d36af5e65c2f57bfe871459876cc745787d02deab9", "aef919889f2aacffc40c2cb5fff17777857194b624d2d417641822b92b8989dd"
COMPILER = RAW / "lut-pair-compose-copy-264"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-compose-copy-264"
COMMIT, BASE = "cae5eb9a326507b688414ba934421286f648a43b", "e137ca5bda7c5e68e6da65f37b5830d12f58727a"
BINARY_SHA = "a2b5da93a9a91cd95d411fb5773e86136ff62e1fce7896d371c97c756004885e"
ARCHIVE_SHA, HOST_SHA = "c64eb65c4e1ac01a277322bddc90172be836fddd60f2d3a0baf66bad62522dd2", "84416288f9a9b4f85c956ad32dc264efc14d007d2d3278c3abc952a006cc6a1e"
TEST_SHA, CHECKS_SHA = "b0e912b15ebd4ce11cb56cec7a356809ce4bf84ef347851fbcccfbf978a20484", "f0b694224d40ae6eb8c081d13fd0cc1fc75c1e337bd7093168a7a3759a3b6721"
HOST_HELPER_SHA, HOST_SCOPE_SHA = "e5cf3243801bcf13f4aed5086ad4914502ed1765bbff15eedf7cf4d589157439", "071a7d054e6dafd79d92962ad0f9466d5987da9aa793a38de2b1c41f019b95a3"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
TABLES, TABLES_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = TABLES.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
CORE, CORE_SHA = RAW / "local-multicopy-ready1-address-route-proof-264/physical.py", "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"
TIMING, TIMING_SHA = RAW / "driver-copy-ready-groups8-proof-264/timing.py", "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
PHYSICAL_SHA, PHYSICAL_SCOPE_SHA = "3a3d97b269290cce13f12b1a7af4067a716eddfc05e4364ae07fcbee8416f313", "601f88a05986c56cffba03e399878baa44512d57ad2bb9b821d65f9343445fe9"
ACCEPTED, ACCEPTED_SHA = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json", "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
ACCEPTED_RUN, ACCEPTED_RUN_SHA = RAW / "local-multicopy-ready1-address-route-264/route-c0/run.json", "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
PARENT_MHZ = {MEMORY: 117.77175903320312, PIXEL: 93.6504898071289, CAPTURE: 259.49139404296875}
CONSTRAINTS = {MEMORY: 130.0052032470703, PIXEL: 74.25006866455078, CAPTURE: 130.0052032470703}
COMB = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMP = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C"
KNOWN_PRIVATE = (COMB, DECOMP + "$code0", DECOMP + "$code1", DECOMP + "$root")
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256", "build_dependency_manifest_sha256", "build_dependency_file_sha256")


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def bind_absolute(audit, ledger, runtime=False):
    for name, expected in ledger.items():
        path = Path(name); require(path.is_absolute(), "flat original pathname is not absolute")
        audit.bind(path, expected, execution=runtime or not path.resolve().is_relative_to(ROOT))


def adopt(audit, proof):
    for name, expected in proof["artifact_sha256"].items():
        path = Path(name); require(not path.is_absolute() and ".." not in path.parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    bind_absolute(audit, proof["execution_file_sha256"], True)


def order(value):
    if isinstance(value, dict): return [(key, order(item)) for key, item in value.items()]
    if isinstance(value, list): return [order(item) for item in value]
    return None


def scalar(cell, port):
    bits = cell["connections"][port]
    require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0, "literal scalar required: " + port)
    return bits[0]


def net_shape(row):
    value = copy.deepcopy(row); value.get("attributes", {}).pop("ROUTING", None); return value


def routing_defaults(audit, host, before, after):
    require(set(before) <= set(after) and {key: after[key] for key in before} == before and
        [key for key in after if key in before] == list(before), "existing settings/value order changed")
    added = {key: after[key] for key in after if key not in before}
    files = ("common/route/gpurouter.cc", "common/route/router1.cc", "mistral/analogue.cc", "mistral/bitstream.cc")
    encoding_sources = []
    for relative, first, last in (("common/kernel/context.h", 117, 127), ("common/kernel/property.cc", 35, 61)):
        path = SOURCE / relative; expected = host["source_sha256"][str(path)]; audit.bind(path, expected)
        encoding_sources.append({"source": str(path), "source_sha256": expected, "lines": [first, last]})
    pattern = re.compile(r'->setting<(bool|int|float)>\(\s*"([^"\n]+)"\s*,\s*(true|false|[-+]?\d+(?:\.\d+)?f?|[a-zA-Z_]\w*)\s*\)')
    references = {"gpurouter/repairEstimateWeight": ("estimate_weight", "gpurouter/estimateWeight"),
                  "gpurouter/candidateExpandK": ("expand_k", "gpurouter/expandK")}
    definitions = {}
    for relative in files:
        path = SOURCE / relative; expected = host["source_sha256"][str(path)]; audit.bind(path, expected)
        for number, line in enumerate(path.read_text().splitlines(), 1):
            for match in pattern.finditer(line):
                kind, key, literal = match.groups(); inherited = None
                if re.fullmatch(r"[a-zA-Z_]\w*", literal) and literal not in ("true", "false"):
                    require(key in references and literal == references[key][0], "unsupported current-source default expression")
                    variable, prior_key = references[key]; prior = definitions.get(prior_key, [])
                    require(len(prior) == 1 and prior[0]["source"] == str(path) and prior[0]["line"] == number - 1 and prior[0]["type"] == kind and
                        re.match(r"\s*" + re.escape(variable) + r"\s*=\s*ctx->setting<", path.read_text().splitlines()[number - 2]) and
                        after.get(prior_key) == prior[0]["encoded"], "inherited default does not follow its exact typed current-source value")
                    encoded, inherited = prior[0]["encoded"], prior[0]
                else:
                    if kind == "bool": require(literal in ("true", "false"), "Boolean default literal malformed"); text = "1" if literal == "true" else "0"
                    elif kind == "int": require(re.fullmatch(r"[-+]?\d+", literal), "integer default literal malformed"); text = str(int(literal))
                    else: text = format(float(literal.removesuffix("f")), ".6f")
                    encoded = text + " " if re.fullmatch(r"[01xz]* *", text) else text
                definitions.setdefault(key, []).append({"source": str(path), "source_sha256": expected, "line": number, "type": kind, "literal": literal, "encoded": encoded,
                    "inherited_typed_default": inherited})
    result = {}
    for key, value in added.items():
        require((key.startswith(("gpurouter/", "router1/")) or key in ("router/tmg_ripup", "compress_rbf")) and
            key in definitions and all(row["encoded"] == value for row in definitions[key]), "added setting is not its unique typed current-source default: " + key)
        result[key] = {"actual_value": value, "current_source_definitions": definitions[key], "property_encoding_sources": encoding_sources}
    return result


def prove_native(native, tables, before_doc, after_doc, selected_graph, profile, routing_settings):
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    require(list(before_doc) == list(after_doc) == ["creator", "modules"] and before_doc["creator"] == after_doc["creator"] and
        list(before_doc["modules"]) == list(after_doc["modules"]) == ["top"] and list(a) == list(b) and
        set(a) == {"settings", "attributes", "ports", "cells", "netnames"}, "same-compiler complete document frame differs")
    attrs = copy.deepcopy(a["attributes"]); require(attrs.get("step") == "place", "selected stage is not place"); attrs["step"] = "route"
    require("FES_LABSTATE_V1" not in attrs and "FES_LABSTATE_V1" in b["attributes"] and
        {key: value for key, value in b["attributes"].items() if key != "FES_LABSTATE_V1"} == attrs and
        [key for key in b["attributes"] if key != "FES_LABSTATE_V1"] == list(attrs) and a["ports"] == b["ports"] and order(a["ports"]) == order(b["ports"]),
        "top attributes/interface differ outside exact route step and fresh LAB snapshot")
    cells, nets = a["cells"], a["netnames"]; new_cells = set(b["cells"]) - set(cells); new_nets = set(b["netnames"]) - set(nets)
    require(len(cells) == 14908 and len(nets) == 16646 and set(cells) <= set(b["cells"]) and set(nets) <= set(b["netnames"]) and
        all(b["cells"][name]["type"] == "MISTRAL_BUF" for name in new_cells) and len(new_nets) == len(new_cells) and
        not any(cell["type"] == "MISTRAL_BUF" for cell in cells.values()) and
        [name for name in b["cells"] if name not in new_cells] == list(cells) and [name for name in b["netnames"] if name not in new_nets] == list(nets) and
        native.canonical(cells.pll_ports) == native.canonical(b["cells"].pll_ports), "original ordered owners/aliases/PLL or actual added BUF population differs")
    old_drivers, old_users = tables.native_tables(a); new_drivers, new_users = tables.native_tables(b)
    def alias_index(top):
        result = {}
        for name, row in top["netnames"].items():
            for bit in set(row["bits"]): result.setdefault(bit, []).append(name)
        return result
    old_aliases, new_aliases = alias_index(a), alias_index(b)
    changed_aliases = [name for name in nets if nets[name]["bits"] != b["netnames"][name]["bits"]]
    allowed_owners = (*KNOWN_PRIVATE, selected_graph["new_clone"])
    require(all(name in cells and re.fullmatch(r"MISTRAL_ALUT[2-6]", cells[name]["type"]) for name in allowed_owners), "own selected generated-owner allowlist unavailable")
    frames, changes = [], {}
    for owner in allowed_owners:
        alias = owner + "$Q"; require(alias in nets, "declared generated owner private alias missing")
        old, new = scalar(cells[owner], "Q"), scalar(b["cells"][owner], "Q")
        if old == new: continue
        require(old_drivers.get(old) == new_drivers.get(new) == [(owner, "Q", 0, 0)] and
            old_aliases.get(old) == new_aliases.get(new) == [alias] and nets[alias]["bits"] == [old] and b["netnames"][alias]["bits"] == [new] and
            all(old not in row["bits"] for row in a["ports"].values()) and all(new not in row["bits"] for row in b["ports"].values()) and old_users.get(old),
            "private output is not its unique isolated typed original owner/alias")
        slots = [(owner, "Q", 0, 0), *old_users[old]]
        for slot in slots:
            require(slot[3] == 0 and slot not in changes, "private occurrence frames overlap")
            changes[slot] = (old, new)
        frames.append({"owner": owner, "alias": alias, "old_raw_bit": old, "new_raw_bit": new,
            "before_driver": [owner, "Q", 0, 0], "after_driver": [owner, "Q", 0, 0], "before_named_consumer_slots": [list(slot) for slot in old_users[old]],
            "before_alias_record": nets[alias], "after_alias_record": b["netnames"][alias]})
    require(set(changed_aliases) == {row["alias"] for row in frames} and len({row["old_raw_bit"] for row in frames}) == len({row["new_raw_bit"] for row in frames}) == len(frames),
        "raw alias changes outside own declared private-owner partition")
    expected_cells = copy.deepcopy(dict(cells))
    for (name, port, index, occurrence), (old, new) in changes.items():
        require(expected_cells[name]["connections"][port][index] == old, "private original raw occurrence differs"); expected_cells[name]["connections"][port][index] = new
    buffers, used_ffs = [], set()
    for name in sorted(new_cells):
        cell = b["cells"][name]; alias = name + "$conn$Q"
        require(cell["type"] == "MISTRAL_BUF" and cell["parameters"] == {} and cell["port_directions"] == {"A": "input", "Q": "output"} and
            set(cell["connections"]) == {"A", "Q"} and alias in new_nets, "actual late BUF/alias schema differs")
        bit, q = scalar(cell, "A"), scalar(cell, "Q"); consumers = new_users.get(q)
        require(new_drivers.get(q) == [(name, "Q", 0, 0)] and new_aliases.get(q) == [alias] and b["netnames"][alias]["bits"] == [q] and
            consumers and len(consumers) == 1 and consumers[0][1:] == ("DATAIN", 0, 0), "late BUF Q is not one private original FF DATAIN")
        ff = consumers[0][0]
        require(ff in cells and cells[ff]["type"] == "MISTRAL_FF" and ff not in used_ffs and name == ff + "$ROUTETHRU" and
            expected_cells[ff]["connections"]["DATAIN"] == [bit] and len(new_drivers.get(bit, [])) == 1 and
            not any(q in row["bits"] for row in b["ports"].values()), "late BUF is not its exact original FF data forwarding")
        used_ffs.add(ff); expected_cells[ff]["connections"]["DATAIN"] = [q]
        buffers.append({"buffer": name, "ff": ff, "input_raw_bit": bit, "output_raw_bit": q, "alias": alias,
            "input_native_driver": list(new_drivers[bit][0]), "sole_named_consumer_slot": list(consumers[0])})
    require(new_nets == {row["alias"] for row in buffers}, "new routing aliases exceed exact BUF outputs")
    expected_drivers = copy.deepcopy(old_drivers)
    for row in frames: del expected_drivers[row["old_raw_bit"]]
    for row in frames:
        require(row["new_raw_bit"] not in expected_drivers, "private after-frame collides with surviving driver")
        expected_drivers[row["new_raw_bit"]] = [(row["owner"], "Q", 0, 0)]
    for row in buffers:
        require(row["output_raw_bit"] not in expected_drivers, "BUF output collides with surviving driver")
        expected_drivers[row["output_raw_bit"]] = [(row["buffer"], "Q", 0, 0)]
    expected_users = {}
    buffer_by_ff = {row["ff"]: row for row in buffers}
    for bit, slots in old_users.items():
        for slot in slots:
            actual_bit = changes[slot][1] if slot in changes else bit
            if slot[0] in buffer_by_ff and slot[1:] == ("DATAIN", 0, 0):
                row = buffer_by_ff[slot[0]]; require(actual_bit == row["input_raw_bit"], "BUF input differs after explicit private frame")
                expected_users.setdefault(actual_bit, []).append((row["buffer"], "A", 0, 0)); actual_bit = row["output_raw_bit"]
            expected_users.setdefault(actual_bit, []).append(slot)
    require(new_drivers == expected_drivers and new_users == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete raw drivers/users differ beyond explicit owner/BUF occurrences")
    for row in frames: row["after_named_consumer_slots"] = [list(slot) for slot in new_users[row["new_raw_bit"]]]
    for name, expected in expected_cells.items():
        actual = copy.deepcopy(b["cells"][name])
        require("FES_PINMAP_V1" not in expected["attributes"] and type(actual["attributes"].get("FES_PINMAP_V1")) is str, "fresh original pin snapshot missing or preexisting")
        actual["attributes"].pop("FES_PINMAP_V1")
        require(native.canonical(actual) == native.canonical(expected) and order(actual) == order(expected), "original metadata/table/BEL/order/raw slots differ outside exact frames: " + name)
    frame_by_alias = {row["alias"]: row for row in frames}
    for name, original in nets.items():
        expected, actual = net_shape(original), net_shape(b["netnames"][name])
        if name in frame_by_alias: expected["bits"] = [frame_by_alias[name]["new_raw_bit"]]
        require(native.canonical(expected) == native.canonical(actual) and order(expected) == order(actual), "original alias metadata/order/raw bits differ: " + name)
    ffs = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in cells.items() if cell["type"] == "MISTRAL_FF"}
    require(len(ffs) == 8221 and ffs == profile["all_original_ff_bel_manifest"], "own selected original FF manifest differs")
    ready = copy.deepcopy(selected_graph); clone = selected_graph["new_clone"]
    ready.update({"actual_clone_q": scalar(b["cells"][clone], "Q"), "actual_new_clone_record": b["cells"][clone],
        "routed_original_pair": {name: b["cells"][name] for name in selected_graph["original_pair"]}})
    ready["routed_ena_redirects"] = [{"cell": row["cell"], "record": b["cells"][row["cell"]], "raw_bit": scalar(b["cells"][row["cell"]], "ENA")} for row in selected_graph["declared_ena_redirects"]]
    return {"ready": ready, "buffer_rows": buffers, "private_output_rows": frames,
        "serialized_native_scope_proved": True, "all_original_ff_bels_exact": True, "all_original_order_and_paired_pll_exact": True,
        "actual_late_buffer_count": len(buffers), "actual_private_output_frame_count": len(frames), "private_owner_allowlist_from_selected": list(allowed_owners),
        "raw_driver_user_tables_reconstructed_exactly": True, "global_numeric_renaming_or_buffer_collapse_used": False,
        "route_metadata_scope": {"step": ["place", "route"], "added_module_attribute": "FES_LABSTATE_V1", "added_cell_attribute": "FES_PINMAP_V1",
            "net_routing_metadata_recorded_not_logically_compared": True, "added_typed_current_source_routing_defaults": routing_settings}}


def timing(paths, report, predicted, accepted, log, record):
    windows, endpoints, worst = paths._paths(report); pw, pe, _ = paths._paths(predicted); aw, ae, old = paths._paths(accepted)
    require(windows == pw == aw and endpoints == pe == ae and set(report["fmax"]) == set(predicted["fmax"]) == set(accepted["fmax"]) == set(CONSTRAINTS), "fresh/own/accepted actual pair-window endpoint or clock coverage differs")
    clocks = {}
    for name, constraint in CONSTRAINTS.items():
        actual, before, pre = report["fmax"][name], accepted["fmax"][name], predicted["fmax"][name]
        require(set(actual) == set(before) == set(pre) == {"achieved", "constraint"} and actual["constraint"] == before["constraint"] == pre["constraint"] == constraint and
            before["achieved"] == PARENT_MHZ[name] and all(type(value) in (int, float) and math.isfinite(value) and value > 0 for value in (actual["achieved"], before["achieved"], pre["achieved"])), "current Fmax/reference/constraint differs")
        clocks[name] = {"before_mhz": before["achieved"], "after_mhz": actual["achieved"], "gain_mhz": actual["achieved"] - before["achieved"], "constraint_mhz": constraint, "constraint_passed": actual["achieved"] >= constraint}
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    require(windows[("posedge " + CAPTURE, "negedge " + MEMORY)] == 5 and windows[("negedge " + MEMORY, "posedge " + MEMORY)] == 3.8459999561309814, "actual capture/half-cycle windows differ")
    relations = [{"from": pair[0], "to": pair[1], "window_ns": windows[pair], **worst[pair], "before_headroom_ns": old[pair]["headroom_ns"],
        "headroom_change_ns": worst[pair]["headroom_ns"] - old[pair]["headroom_ns"], "positive_headroom_required": pair != target} for pair in sorted(windows)]
    require("Running signoff timing analysis..." in log, "LAST RBF signoff missing"); last = log.rsplit("Running signoff timing analysis...", 1)[1]
    literal_hold = "Hold/min time violation" in last
    hold_lines = [line for line in last.splitlines() if re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
    printed = re.findall(r"Max frequency for clock\s+'([^']+)': ([0-9.]+) MHz", last)
    require(len(printed) == 3 and {name for name, value in printed} == set(CONSTRAINTS) and all(abs(float(value) - report["fmax"][name]["achieved"]) < .011 for name, value in printed) and
        record["fmax"] == report["fmax"] and record["final_reported_hold_violations"] is literal_hold and record["last_signoff_hold_warning_lines"] == hold_lines and
        record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log), "actual LAST CLI/report/hold/backend binding differs")
    gain = report["fmax"][MEMORY]["achieved"] > PARENT_MHZ[MEMORY]
    passed = gain and all(clocks[name]["constraint_passed"] for name in (PIXEL, CAPTURE)) and all(row["headroom_ns"] > 0 for row in relations if row["positive_headroom_required"]) and not literal_hold and not hold_lines
    return {"passes_practical_timing_gate": passed, "actual_timing_thresholds_passed": passed,
        "raw_timing": {"memory_strict_gain_vs_current_accepted_fifth": gain, "memory_gain_threshold_mhz": PARENT_MHZ[MEMORY], "memory_130mhz_closed": clocks[MEMORY]["constraint_passed"],
            "clocks": clocks, "all_actual_required_non_target_windows": relations, "complete_current_path_count": len(endpoints), "actual_domain_pair_count": len(windows),
            "final_reported_hold_violations": literal_hold or bool(hold_lines), "last_signoff_hold_warning_lines": hold_lines}, "old_sta_or_physical_frame_inherited": False}


def closed(native, record, profile, path, expected, runtime):
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
        record["source_identity_sha256"] == expected and record["execution"] == profile[runtime] and record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "actual record is not its closed profile/input/runtime union")


def failure(error):
    return {"exception_type": type(error).__name__, "reason": str(error)}


def compare(self_sha, scope_sha, run_sha, physical_sha, physical_scope_sha):
    require((run_sha, physical_sha, physical_scope_sha) == (RUN_SHA, PHYSICAL_SHA, PHYSICAL_SCOPE_SHA) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in (RUN_SHA, PHYSICAL_SHA, PHYSICAL_SCOPE_SHA)), "actual route/physical identities remain UNFROZEN or differ")
    native = load(NATIVE, NATIVE_SHA, "copy_route_native_pure"); audit = native.Audit()
    selected_profile, selected_run = SELECTED / "source-identity.json", SELECTED / "selected/run.json"
    selected_proof = SELECTED / "selected/comparison-selected-copy.json"; host_path = COMPILER / "validation/host-validation.json"
    fixed = ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (PROFILE, PROFILE_SHA), (RUN, run_sha), (ROUTE / "run_route.py", RUNNER_SHA), (ROUTE / "scope.md", RUNNER_SCOPE_SHA),
        (selected_profile, SELECTED_PROFILE_SHA), (selected_run, SELECTED_RUN_SHA), (selected_proof, SELECTED_PROOF_SHA), (SELECTED / "run_selected.py", SELECTED_HELPER_SHA), (SELECTED / "scope.md", SELECTED_SCOPE_SHA),
        (SELECTED / "compare_selected_copy.py", SELECTED_COMPARER_SHA), (SELECTED / "comparison-scope.md", SELECTED_COMPARISON_SCOPE_SHA), (COMPILER / "nextpnr-mistral", BINARY_SHA), (COMPILER / "source.tar.gz", ARCHIVE_SHA),
        (host_path, HOST_SHA), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA), (HERE / "physical.py", physical_sha), (HERE / "physical-scope.md", physical_scope_sha),
        (NATIVE, NATIVE_SHA), (TABLES, TABLES_SHA), (FREEZE, FREEZE_SHA), (CORE, CORE_SHA), (TIMING, TIMING_SHA), (ACCEPTED, ACCEPTED_SHA), (ACCEPTED_RUN, ACCEPTED_RUN_SHA))
    for path, expected in fixed: audit.bind(path, expected)
    profile, record, previous_profile, previous, proof, host, accepted_proof, accepted_record = (native.read(path) for path in (PROFILE, RUN, selected_profile, selected_run, selected_proof, host_path, ACCEPTED, ACCEPTED_RUN))
    closed(native, previous, previous_profile, selected_profile, SELECTED_PROFILE_SHA, "selected_execution"); closed(native, record, profile, PROFILE, PROFILE_SHA, "route_execution")
    require(proof["phase"] == "lut-pair-ready0-selected-composed-copy-conditional-native-proof" and proof["source_identity_sha256"] == SELECTED_PROFILE_SHA and proof["current_selected_run_sha256"] == SELECTED_RUN_SHA and
        proof["generator_sha256"] == SELECTED_COMPARER_SHA and proof["scope_sha256"] == SELECTED_COMPARISON_SCOPE_SHA and proof["recorder_sha256"] == SELECTED_HELPER_SHA and proof["recorder_scope_sha256"] == SELECTED_SCOPE_SHA and
        proof["structural_rejection"] is proof["model_or_selected_prefix_rejection"] is proof["native_path_topology_rejection"] is None and all(proof[key] is True for key in
        ("candidate_completed", "native_graph_proof_available", "selected_native_graph_and_conditional_function_proved", "fresh_full_route_prerequisite_under_plain_sig_condition", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact", "all_original_ff_bels_exact", "final_original_path_metadata_and_runtime_hashes_stable")), "own independent selected native prerequisite is not positive")
    require(accepted_proof["candidate_completed"] is accepted_proof["native_graph_proof_available"] is accepted_proof["physical_scope_proved"] is True and accepted_proof["structural_rejection"] is None and
        accepted_proof["current_full_run_sha256"] == ACCEPTED_RUN_SHA and accepted_proof["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and accepted_record["completed"] is True and accepted_record["exit_code"] == 0,
        "accepted fifth numerical reference is not closed/positive")
    adopt(audit, proof); adopt(audit, accepted_proof)
    counts = {"pair_backend": 12, "copy_backend": 11, "native_plan": 25, "driver_backend": 10, "pair_cli": 17, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and
        host["check_results_sha256"] == CHECKS_SHA and host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        set(host["checks"]) == set(counts) and all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()), "actual current host/build/cases differ")
    for key in HOST_MAPS: bind_absolute(audit, host[key])
    for entry, folder, names in ((previous, selected_run.parent, ("phase.log", "placed.json", "timing.json")), (record, RUN.parent, ("route.log", "routed.json", "timing.json", "core.rbf"))):
        require(set(entry["output_sha256"]) == {str(folder / name) for name in names} and all((folder / name).stat().st_size > 0 for name in names), "closed full output set differs")
        bind_absolute(audit, entry["input_sha256"]); bind_absolute(audit, entry["output_sha256"]); bind_absolute(audit, entry["execution"]["files"], True)
    runner = load(ROUTE / "run_route.py", RUNNER_SHA, "copy_route_recorder_pure"); modules = runner.definitions()
    for path, expected in profile["pure_function_helper_sha256"].items(): audit.bind(Path(path), expected)
    called = {str(ROUTE / "run_route.py"): RUNNER_SHA, str(NATIVE): NATIVE_SHA, str(TABLES): TABLES_SHA, str(FREEZE): FREEZE_SHA, str(CORE): CORE_SHA, str(TIMING): TIMING_SHA, str(HERE / "physical.py"): physical_sha}
    called.update(profile["pure_function_helper_sha256"])
    for name, expected in runner.SCRIPTS.items(): audit.bind(MODULE / "scripts" / name, expected)
    require(profile["phase"] == "lut-pair-ready0-compose-copy-fresh-selected-full-route" and profile["compiler_commit"] == previous["compiler_commit"] == COMMIT and profile["delta_base_commit"] == previous["delta_base_commit"] == BASE and
        profile["command"] == runner.command(previous) and record["execution"] == previous["execution"] == runner.expected_execution(previous) and profile["cwd"] == previous["cwd"] == str(MODULE) and
        profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["driver_pass_executed"] is profile["post_plan_requested"] is False and profile["rbf_generation_requested"] is True and
        proof["current_actual_execution"] == previous["execution"] and profile["selected_profile_sha256"] == SELECTED_PROFILE_SHA and profile["selected_run_sha256"] == SELECTED_RUN_SHA and profile["selected_proof_sha256"] == SELECTED_PROOF_SHA and
        native.canonical(profile["prefix_native_graph_evidence"]) == native.canonical(proof["native_graph_evidence"]) and profile["local_plan_steps"] == previous["local_plan_steps"] and
        profile["pair_candidate_selection"] == proof["actual_candidate_selection"] == previous["pair_candidate_selection"] and profile["expected_candidate"] == proof["actual_chosen_candidate"] == previous["expected_candidate"], "fresh routed command/selected scope/current runtime differs")
    def source_state():
        def git(path, *args): return subprocess.check_output(["git", "-C", str(path), *args], text=True).strip()
        require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and git(SOURCE, "merge-base", BASE, COMMIT) == BASE and
            set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == set(host["changed_source_files"]), "live current source state differs")
        for path, commit in [(Path(host["external_model_path"]), host["external_model_commit"]), *((SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items())]:
            require(git(path, "rev-parse", "HEAD") == commit and not git(path, "status", "--porcelain"), "live source/model dependency differs")
    source_state()
    log = (RUN.parent / "route.log").read_text(); before_log = (selected_run.parent / "phase.log").read_text()
    models, applied = runner.qualification(log, modules, previous)
    require(native.canonical(models) == native.canonical(previous["actual_selected_local_qualification"]) == native.canonical(record["actual_selected_local_qualification"]) == native.canonical(proof["fresh_local_models"]) and
        native.canonical(applied) == native.canonical(previous["actual_selected_pair_copy_qualification"]) == native.canonical(record["actual_selected_pair_copy_qualification"]) and len(models) == 10 and
        native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(before_log) and len(native.PLACEMENT_METRICS.findall(log)) == 71,
        "fresh full TEN/copy prefix/initial placement rows differ")
    applied_line = f"Info: LUT pair copy applied candidate {profile['pair_candidate_selection']}; full routing and signoff still required."
    require(log.count(applied_line) == 1 and log.index(applied_line) < log.index("Running the GPU router") < log.rindex("Running signoff timing analysis...") < log.index("Info: Program finished normally.") and
        not any(line.startswith("ERROR:") for line in log.splitlines()) and not any(label in log for label in ("LUT driver copy", "Local-remap post-plan step", "Running predicted placed timing analysis", "Running final routed timing analysis for --report")), "actual copy/GPU/RBF signoff order or requested role differs")
    before_doc, after_doc = native.read_netlist(selected_run.parent / "placed.json"), native.read_netlist(RUN.parent / "routed.json")
    report, predicted, accepted_report = native.read(RUN.parent / "timing.json"), native.read(selected_run.parent / "timing.json"), native.read(ACCEPTED_RUN.parent / "timing.json")
    frozen = load(FREEZE, FREEZE_SHA, "copy_route_freeze_pure"); tables = load(TABLES, TABLES_SHA, "copy_route_tables_pure", frozen)
    paths = load(TIMING, TIMING_SHA, "copy_route_paths_pure")
    measured = timing(paths, report, predicted, accepted_report, log, record)
    native_evidence, physical_evidence, rejection = None, None, None
    try:
        defaults = routing_defaults(audit, host, before_doc["modules"]["top"]["settings"], after_doc["modules"]["top"]["settings"])
        native_evidence = prove_native(native, tables, before_doc, after_doc, proof["native_graph_evidence"], profile, defaults)
        core = load(CORE, CORE_SHA, "copy_route_physical_core_pure"); physical = load(HERE / "physical.py", physical_sha, "copy_route_actual_physical_pure")
        physical_evidence = physical.evaluate(core, before_doc, after_doc, {key: native_evidence[key] for key in ("ready", "buffer_rows", "private_output_rows")}, profile)
        require(physical_evidence["physical_scope_proved"] is True, "actual exported physical scope not proved")
    except (ValueError, TypeError, KeyError, IndexError) as error: rejection = failure(error)
    topologies, topology_rejections = {}, {}
    for name, document, data in (("selected", before_doc, predicted), ("routed", after_doc, report)):
        try: topologies[name] = tables.report_topology(document, data, predicted)
        except (ValueError, TypeError, KeyError, IndexError) as error: topology_rejections[name] = failure(error)
    audit.finish(); source_state()
    native_ok = native_evidence is not None; physical_ok = physical_evidence is not None and physical_evidence["physical_scope_proved"] is True
    gain = rejection is None and not topology_rejections and native_ok and physical_ok and measured["passes_practical_timing_gate"]
    return {"schema": 1, "phase": "lut-pair-ready0-compose-copy-fresh-routed-native-physical-timing-proof", "source_identity_sha256": PROFILE_SHA, "current_full_run_sha256": run_sha,
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "host_validation_sha256": HOST_SHA, "generator_sha256": self_sha, "scope_sha256": scope_sha,
        "recorder_sha256": RUNNER_SHA, "recorder_scope_sha256": RUNNER_SCOPE_SHA, "physical_helper_sha256": physical_sha, "physical_scope_sha256": physical_scope_sha,
        "selected_proof_sha256": SELECTED_PROOF_SHA, "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": ACCEPTED_RUN_SHA,
        "candidate_completed": True, "compiler_read_audit_passed": True, "fresh_local_models": models, "actual_selected_pair_copy_qualification": applied,
        "native_graph_proof_available": native_ok, "native_graph_evidence": native_evidence, "physical_scope_proved": physical_ok, "physical_evidence": physical_evidence,
        "structural_rejection": rejection, "native_path_topology_rejection": topology_rejections or None, "current_predicted_native_paths": topologies, "timing": measured,
        "routed_gain_accepted_under_confirmed_target_clock_rule": gain, "independent_numerical_sta_proved": False, "rbf_decoded_or_hardware_tested": False,
        "pure_function_helper_sha256": called, "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "run-sha256", "physical-sha256", "physical-scope-sha256"): parser.add_argument("--" + name, required=True)
    args = parser.parse_args(); require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual SHA activation pins required")
    output = HERE / "comparison-copy-route.json"; require(not output.exists(), "immutable full composed-copy proof exists")
    result = compare(args.self_sha256, args.scope_sha256, args.run_sha256, args.physical_sha256, args.physical_scope_sha256)
    with output.open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"], "physical_scope_proved": result["physical_scope_proved"],
        "structural_rejection": result["structural_rejection"], "routed_gain_accepted_under_confirmed_target_clock_rule": result["routed_gain_accepted_under_confirmed_target_clock_rule"]}, indent=2))


if __name__ == "__main__": main()
