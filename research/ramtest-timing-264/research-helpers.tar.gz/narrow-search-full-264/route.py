"""Root-operated sealed full selected11/12/AC route; no helper runs automatically."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

import seal_profile as seal


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", required=True, choices=seal.PHASES)
    args = parser.parse_args()
    context = seal.load_profile()
    profile, _, base, source, _, prior = context
    folder = seal.phase_folder(args.phase)
    seal.require(not folder.exists(), "full output already exists")
    module = Path(base["cwd"])
    sys.path.insert(0, str(module))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    from scripts.search_placer_qor import _score_report, has_failed_route_arc
    from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS
    identity = seal.tool_identity(prior["fast"].BASE_COMMIT, source)
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(seal.INITIAL / "nextpnr-mistral", identity)}, 1)
    try:
        seal.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                     "ambient compiler diagnostic environment")
        record = seal.record_template(profile, base, source, prior, invocation.inputs, args.phase)
        seal.authenticate_phase(record, context)
        prior["audit"].finish()
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        try:
            with (folder / "route.log").open("x") as log:
                result = audited_run(record["command"], source_root=module, cwd=module,
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log,
                    stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            invocation.verify()
            log = (folder / "route.log").read_text()
            seal.require(result.returncode == 0 and "Info: Program finished normally." in log and
                not has_failed_route_arc(log) and not any(line.startswith("ERROR:") for line in log.splitlines()),
                "full route did not finish normally")
            board._require_gpu_backend(log)
            seal.require(all((folder / name).is_file() and (folder / name).stat().st_size > 0
                for name in ("routed.json", "timing.json", "core.rbf")) and "Running signoff timing analysis..." in log,
                "full route lacks final output/signoff")
            seal.require([line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line] ==
                [seal.MINIMUM_LOG], "full route lacks exactly one minimum200 log")
            record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
            report = seal.read(folder / "timing.json")
            _score_report(report, REQUIRED_CLOCKS)
            seal.require(set(report["fmax"]) == {name for name, _ in REQUIRED_CLOCKS}, "full route changed clock set")
            record["fmax"], record["minimum_log_verified"], record["completed"] = report["fmax"], True, True
            seal.authenticate_phase(record, context)
            prior["audit"].finish()
            print(json.dumps({key: record[key] for key in
                ("phase", "eleven_selection", "twelve_selection", "decomposition_selection", "completed", "exit_code",
                 "elapsed_seconds", "fmax", "final_reported_hold_violations")}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
