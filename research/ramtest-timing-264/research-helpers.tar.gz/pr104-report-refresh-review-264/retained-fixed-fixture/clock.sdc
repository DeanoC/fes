create_clock -period 10 [get_nets clock]
