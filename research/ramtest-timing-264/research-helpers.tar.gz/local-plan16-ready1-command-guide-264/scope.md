# Exact current ready1 command search guide

ROOT alone executes this new derivation after whole-byte/hash/AST and independent
peer review. Explicit self/scope/full-proof/run hashes are mandatory. Actual
ninth full proof5966273b/runEA8e5bed/profile788f16d2 has positive native and
exported physical scope, zero LAST signoff holds and timing gain false at
112.981582MHz. Current d7e5c61f/baseec0a8d0c/ELF41c2afe1/archive4fbebd5e/host0f3c11a5,
positive ninth V2d1ee7000 and new compiler control1cff85d6 are distinct from
accepted-five6dcf8c4b at117.77175903320312MHz. No gain or candidate is inherited.

The derivation authenticates flat full-proof/accepted artifact and runtime maps,
the actual profile/record union, every current input/runtime file and all four
closed outputs. Pinned32fd supplies lossless paired-PLL parsing/Audit/canonical;
72131/8601 supply only native tables/current report topology. No old proof,
derivation, authenticator, prepare/run/main or source query is executed.
Every original path is rehashed before guide publication and after binding it.
Outputs command-guide.json and derivation.json are exclusive and immutable.

The guide keeps exactly actual critical_paths[1], the ready1→innerALUT2.A→
outerALUT4.C→m1_writedataFF61.ENA path. All original path fields, sources, clocks,
locations, windows, skew and delays remain unchanged, as does every other report
field. The other seven exact worst ties at source indices2975..2981 are preserved
in original source order in the derivation, without invented endpoints. All eight
target paths are the complete current worst memory ties at8.850999876856804ns.
The filtered guide is a search input, not a replacement full timing report.

The full current15290/seven-pair report is checked against its own lossless graph
and ninth predicted endpoint/window coverage. The current root Q101074 has87
original scalar FF ENA consumers on common CLK3549. Exactly eight whole-LAB25.16
consumers are target cohort: m1_address15/19/22/4/6, scalar m1_burstcount and
m1_writedata20/61. Existing root consumers and both ALUT5 copies remain complete:
base Q120708 retains21 ENAs and copy$1 Q120720 retains its one ENA. Neither is
replaced or requalified by this guide.

Actual innerALUT2 mask0xb/outerALUT4 mask0xf0e0.C and both existing ALUT5 functions
0xbbbbbbb0 use exact literal leaf order[98308,98312,35614,23880,107546]. Thirty-two
conditional plain-SIG rows prove the existing two-LUT function equals both
existing copies. Each boundary net has one ordinary actual native driver.
This existing-function enumeration does not prove any new copy or site.

All nine prior copies retain complete actual records, literal Qs120708..120724
and disjoint cohorts21/2/10/1/6/1/1/3/2. Actual copy BELs and complete modeled
trial dictionaries agree with the bound ninth run/proof. Full native pin snapshots
for the cone/copies/targets, aliases, input/output driver/user slots, whole FF LAB
records and all8221 original FF BELs are recorded. The expected next owner
outerALUT4_C$local_remap$2 and its $Q alias must be free in both namespaces.
No future chosen BEL, Q, qualification or physical mask is guessed.

Pin snapshots preserve the complete typed SIG/constant/inversion states. The
enumerated inner/outer/two-copy cone is explicitly plain SIG, as are target
CLK/ENA pins; other actual FF control states are retained without alteration.

Actual CLKBUF Q3549←A112726 is checked with full SIG A/Q pins. Its driver is the
second serialized outclk occurrence of the paired lossless PLL records112724/
112726; complete original entries are retained. Serialized occurrence is not a
logical-channel or frequency assertion. No clock buffer collapse is performed.

The guide changes no graph, constraints, compiler policy, plan descriptor, RTL,
pin, phase or route. A future tenth stage requires fresh guarded qualification,
independent prefix proof and full routed physical/window/hold acceptance. Hidden
caches/GPU IDs, independent numerical STA/calibration, decoded RBF or hardware
are not proved here. Accepted117.771759MHz remains unchanged.
