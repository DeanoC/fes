"""Derive the exact current ready1 command path and whole eight-FF LAB cohort."""
import argparse
import builtins
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
ROUTE = RAW / "local-plan16-ready1-skid-byte-route-264"
PREFIX = RAW / "local-plan16-ready1-skid-byte-stage-264"
PROOF = RAW / "local-plan16-ready1-skid-byte-route-proof-264/comparison.json"
PROOF_SHA = "5966273babe8b4405ce23571d30cc9b7e342fbdd062272ac4b575df54596b95a"
PROFILE_SHA = "788f16d21d128edbf0ffce4fb32b63db6e47135cf9faa5686d084d6fd4aa780d"
RUN_SHA = "ea8e5bed840dc8ec53c077b669fc2cc2cc3a8081afd27476695be1bd675f9ba5"
PREFIX_SHA = "d1ee70008e30c5079473af11d0789a430a79b80bce75edf2477e8ef056c0230b"
CONTROL_SHA = "1cff85d6656ba2afe90c89ee5a7e37a68bfa72f9592c273e4396a672520f268f"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
COMMIT = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
BASE = "ec0a8d0cc56f0915e985ca7d1528daab1450c00d"
BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
HOST_SHA = "0f3c11a523ca7981b5d3e373c10d67d0ade5bf5cac9212e02e0186d6368b438c"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
INNER, OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port1.slot_free_MISTRAL_ALUT4_C"
RETAINED, SECOND = OUTER + "$local_remap", OUTER + "$local_remap$1"
TARGET = "hps_ddr.m1_writedata_MISTRAL_FF_Q_61"
TARGETS = tuple("hps_ddr.m1_address_MISTRAL_FF_Q_" + str(i) for i in (15, 19, 22, 4, 6)) + (
    "hps_ddr.m1_burstcount_MISTRAL_FF_Q", "hps_ddr.m1_writedata_MISTRAL_FF_Q_20", TARGET)
OUTER3, PORT0 = "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B", "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B"
COPY_NAMES = (RETAINED, OUTER3 + "$local_remap", PORT0 + "$local_remap", OUTER3 + "$local_remap$1",
    OUTER3 + "$local_remap$2", PORT0 + "$local_remap$1", SECOND, PORT0 + "$local_remap$2", OUTER3 + "$local_remap$3")
HPS, PAIR = "hps_ddr.f2sdram", ("posedge ram_clock.clocks[0]", "posedge ram_clock.clocks[0]")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure helper identity differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure helper pathname differs")
    return module


def derive(self_sha, scope_sha, proof_sha, run_sha):
    guide, output = HERE / "command-guide.json", HERE / "derivation.json"
    require(proof_sha == PROOF_SHA and run_sha == RUN_SHA and not guide.exists() and not output.exists(), "actual completed proof/run pins and exclusive guide required")
    native = load(NATIVE, NATIVE_SHA, "ready1_command_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (PROOF, proof_sha),
            (ROUTE / "source-identity.json", PROFILE_SHA), (ROUTE / "route-c0/run.json", run_sha), (ACCEPTED, ACCEPTED_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    proof, accepted, profile, record = (native.read(path) for path in
        (PROOF, ACCEPTED, ROUTE / "source-identity.json", ROUTE / "route-c0/run.json"))
    for manifest in (proof, accepted):
        for path, expected in manifest["artifact_sha256"].items():
            require(not Path(path).is_absolute() and ".." not in Path(path).parts, "flat artifact escapes ROOT")
            audit.bind(ROOT / path, expected)
        for path, expected in manifest["execution_file_sha256"].items():
            require(Path(path).is_absolute(), "flat execution pathname is not absolute")
            audit.bind(Path(path), expected, execution=True)
    for path, expected in profile["input_sha256"].items():
        require(Path(path).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    require(proof["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-full-route-inspection" and
            proof["structural_rejection"] is None and all(proof[key] is True for key in
                ("candidate_completed", "native_graph_proof_available", "physical_scope_proved", "final_original_path_metadata_and_runtime_hashes_stable")) and
            proof["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and proof["timing"]["passes_practical_timing_gate"] is False and
            proof["source_identity_sha256"] == PROFILE_SHA and proof["current_full_run_sha256"] == RUN_SHA and
            proof["prefix_proof_sha256"] == PREFIX_SHA and proof["accepted_full_proof_sha256"] == ACCEPTED_SHA and
            accepted["structural_rejection"] is None and accepted["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and
            proof["timing"]["raw_timing"]["memory_gain_threshold_mhz"] == profile["minimum_accepted_memory_mhz"] == 117.77175903320312 and
            proof["compiler_commit"] == profile["compiler_commit"] == record["compiler_commit"] == COMMIT and
            profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and
            profile["host_validation_sha256"] == HOST_SHA and profile["control_proof_sha256"] == CONTROL_SHA and
            record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in record for key in ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")) and
            record["source_identity_sha256"] == PROFILE_SHA and
            all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
            record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): PROFILE_SHA} and
            record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip" and
            record["final_reported_hold_violations"] is False and not record["last_signoff_hold_warning_lines"],
            "physically proved timing-rejected ninth/current accepted-reference/closed compiler roles differ")
    for path, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(path) == expected, "actual runtime outside frozen profile")
        audit.bind(Path(path), expected, execution=True)
    require(set(record["output_sha256"]) == {str(ROUTE / "route-c0" / name) for name in
        ("route.log", "routed.json", "timing.json", "core.rbf")}, "actual complete output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "actual output empty")
        audit.bind(Path(path), expected)
    document = native.read_netlist(ROUTE / "route-c0/routed.json")
    top, report = document["modules"]["top"], native.read(ROUTE / "route-c0/timing.json")
    frozen = load(FREEZE, FREEZE_SHA, "ready1_command_freeze")
    selected = load(SELECTED, SELECTED_SHA, "ready1_command_topology", frozen)
    topology = selected.report_topology(document, report, native.read(PREFIX / "baseline/timing.json"))
    require(report["fmax"] == record["fmax"] and report["timing_report_paths"] == 16384 and topology["current_report_paths"] == 15290 and
            len(topology["domain_pair_endpoint_counts"]) == 7, "current complete report coverage differs")
    drivers, users = selected.native_tables(top)
    def scalar(name, port):
        bits = top["cells"][name]["connections"][port]
        require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0, "native scalar differs")
        return bits[0]
    def q(name):
        bit = scalar(name, "Q")
        require(drivers.get(bit) == [(name, "Q", 0, 0)], "Q driver is not unique")
        return bit
    def lab(name):
        match = re.fullmatch(r"MISTRAL_(?:M?COMB|FF)\.(\d+)\.(\d+)\.\d+", top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "actual fabric owner lacks a placed BEL")
        return tuple(map(int, match.groups()))
    root_q, inner_q, retained_q, second_q = q(OUTER), q(INNER), q(RETAINED), q(SECOND)
    require((top["cells"][INNER]["type"], top["cells"][OUTER]["type"], top["cells"][RETAINED]["type"]) ==
            ("MISTRAL_ALUT2", "MISTRAL_ALUT4", "MISTRAL_ALUT5") and
            [int(top["cells"][name]["parameters"]["LUT"], 2) for name in (INNER, OUTER, RETAINED)] == [0xb, 0xf0e0, 0xbbbbbbb0] and
            scalar(OUTER, "C") == inner_q and (root_q, inner_q, retained_q, second_q) == (101074, 97422, 120708, 120720) and
            (len(users[root_q]), len(users[retained_q]), len(users[second_q])) == (87, 21, 1) and
            top["cells"][TARGET]["type"] == "MISTRAL_FF" and scalar(TARGET, "ENA") == root_q and
            lab(TARGET) == (25, 16), "actual ready1 command cone/two retained copies/target differs")
    masks, input_rows = [], []
    for name, width in ((INNER, 2), (OUTER, 4), (RETAINED, 5), (SECOND, 5)):
        text, cell = top["cells"][name]["parameters"]["LUT"], top["cells"][name]
        pins = "ABCDE"[:width]
        require(set(cell["parameters"]) == {"LUT"} and type(text) is str and len(text) == 1 << width and set(text) <= {"0", "1"} and
                cell["port_directions"] == {**{pin: "input" for pin in pins}, "Q": "output"} and set(cell["connections"]) == set(pins) | {"Q"}, "existing LUT schema differs")
        masks.append(int(text, 2)); input_rows.append([scalar(name, pin) for pin in pins])
    ai, ao, ac, second_inputs = input_rows
    require(masks == [0xb, 0xf0e0, 0xbbbbbbb0, 0xbbbbbbb0] and ac == second_inputs == [98308, 98312, 35614, 23880, 107546] and
            ao.count(inner_q) == 1 and len(set(ac)) == 5 and set(ac) == set(ai + [bit for bit in ao if bit != inner_q]) and
            not {root_q, inner_q, retained_q, second_q} & set(ac), "existing five-input conditional boundary differs")
    boundary = []
    for pin, bit in zip("ABCDE", ac):
        require(len(drivers.get(bit, [])) == 1 and top["cells"][drivers[bit][0][0]]["type"] != "MISTRAL_CONST", "existing boundary is not a unique ordinary driver")
        boundary.append({"pin": pin, "raw_bit": bit, "native_driver": list(drivers[bit][0])})
    truth = []
    for assignment in range(32):
        values = {bit: (assignment >> i) & 1 for i, bit in enumerate(ac)}
        iv = (masks[0] >> sum(values[bit] << i for i, bit in enumerate(ai))) & 1
        original = (masks[1] >> sum((iv if bit == inner_q else values[bit]) << i for i, bit in enumerate(ao))) & 1
        retained = (masks[2] >> assignment) & 1
        second_value = (masks[3] >> assignment) & 1
        require(original == retained == second_value, "existing plain-SIG composition differs")
        truth.append({"assignment": assignment, "original": original, "retained": retained, "second_retained": second_value})
    for slot in users[root_q] + users[retained_q] + users[second_q]:
        require(slot[1:] == ("ENA", 0, 0) and top["cells"][slot[0]]["type"] == "MISTRAL_FF" and scalar(slot[0], "CLK") == 3549,
                "complete root/copy scalar ENA cohort/common clock differs")
    target_group = [slot for slot in users[root_q] if lab(slot[0]) == (25, 16)]
    require(target_group == sorted((name, "ENA", 0, 0) for name in TARGETS), "whole target LAB does not have exactly the eight original-root ENAs")
    expected_clone = OUTER + "$local_remap$2"
    require(all(name not in top["cells"] and name not in top["netnames"] for name in (expected_clone, expected_clone + "$Q")), "expected next copy pair is occupied")
    paths, indices, memory, tied = [], [], [], []
    for index, path in enumerate(report["critical_paths"]):
        end, total = path["path"][-1]["to"], math.fsum(segment["delay"] for segment in path["path"])
        require(math.isfinite(total), "complete path sum is not finite")
        if (path["from"], path["to"]) == PAIR: memory.append((index, total))
        if end["cell"] not in TARGETS or end["port"] != "ENA": continue
        require((path["from"], path["to"]) == PAIR and path["path"][-1]["type"] == "setup" and total > path["max_delay"], "target is not the current memory ENA violation")
        routes = [segment for segment in path["path"] if segment["type"] == "routing"]
        require([(s["from"]["cell"], s["from"]["port"], s["to"]["cell"], s["to"]["port"]) for s in routes] ==
                [(HPS, "cmd_ready_1", INNER, "A"), (INNER, "Q", OUTER, "C"), (OUTER, "Q", end["cell"], "ENA")], "actual routing sequence differs")
        tied.append({"source_index": index, "path": path, "total_ns": total})
        if end["cell"] == TARGET: paths.append(path); indices.append(index)
    require(memory and indices == [1] and len(paths) == 1 and [row["source_index"] for row in tied] == [1, *range(2975, 2982)] and
            {row["path"]["path"][-1]["to"]["cell"] for row in tied} == set(TARGETS) and
            len({row["total_ns"] for row in tied}) == 1 and [(i, total) for i, total in memory if total == max(x[1] for x in memory)] ==
            [(row["source_index"], row["total_ns"]) for row in tied], "eight whole-LAB paths are not the exact current worst ties")
    models = profile["prefix_fresh_local_models"]
    require(len(models) == 9 and native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) ==
            native.canonical(proof["fresh_local_models"]), "actual nine retained complete models differ")
    cohorts, copy_outputs, occupied = [], [], set()
    for index, (name, model) in enumerate(zip(COPY_NAMES, models)):
        bit, cell = q(name), top["cells"][name]
        slots = users.get(bit, [])
        require(bit == 120708 + 2 * index and name.startswith(model["outer"] + "$local_remap") and
                cell["attributes"]["NEXTPNR_BEL"] == model["bel"] and len(slots) == model["ena_users"] == [21, 2, 10, 1, 6, 1, 1, 3, 2][index] and
                not occupied & set(slots) and all(slot[1:] == ("ENA", 0, 0) and top["cells"][slot[0]]["type"] == "MISTRAL_FF" and
                    scalar(slot[0], "CLK") == 3549 for slot in slots) and
                [alias for alias, net in top["netnames"].items() if bit in net["bits"]] == [name + "$Q"] and
                all(bit not in port["bits"] for port in top["ports"].values()), "actual retained copy owner/Q/all consumers differ: " + name)
        occupied.update(slots)
        cohorts.append({"cell": name, "raw_q": bit, "record": cell, "consumer_slots": [list(slot) for slot in slots]})
        copy_outputs.append({"cell": name, "before_raw_bit": bit, "after_raw_bit": bit, "consumer_slots": [list(slot) for slot in slots]})
    require(not set(target_group) & occupied, "target original-root cohort overlaps a retained copy")
    clock = "ram_clock.clocks_MISTRAL_CLKBUF_Q_1"
    require(top["cells"][clock]["type"] == "MISTRAL_CLKBUF" and top["cells"][clock]["parameters"] == {} and
            scalar(clock, "Q") == 3549 and scalar(clock, "A") == 112726 and drivers.get(3549) == [(clock, "Q", 0, 0)] and
            len(drivers.get(112726, [])) == 1, "common native clock buffer frame differs")
    pll_slot = drivers[112726][0]
    require(pll_slot[1:] == ("outclk", 0, 1) and top["cells"][pll_slot[0]]["type"] == "altera_pll" and
            [bits for port, bits in top["cells"].pll_ports[pll_slot[0]]["connections"] if port == "outclk"] == [[112724], [112726]],
            "actual ordered duplicate PLL outputs differ")
    names = (INNER, OUTER, *COPY_NAMES, *TARGETS)
    snapshots = {}
    for name in names:
        pins = json.loads(bytes.fromhex(top["cells"][name]["attributes"]["FES_PINMAP_V1"]).decode(),
            object_pairs_hook=native.unique_object, parse_constant=native.nonfinite)
        require(set(pins) == {"count", "pins"} and type(pins["count"]) is int and pins["count"] == len(pins["pins"]) and
                set(pins["pins"]) == set(top["cells"][name]["connections"]) and all(type(row) is list and len(row) == 2 and
                    type(row[0]) is int and row[0] in (0, 1, 2, 3) and type(row[1]) is str and row[1] for row in pins["pins"].values()), "full typed pin snapshot incomplete")
        if name in (INNER, OUTER, RETAINED, SECOND):
            require(all(row[0] == 0 for row in pins["pins"].values()), "existing conditional cone is not plain SIG")
        if name in TARGETS:
            require(pins["pins"]["CLK"][0] == pins["pins"]["ENA"][0] == 0, "target native clock/ENA pin state differs")
        snapshots[name] = {"record": top["cells"][name], "decoded_pin_snapshot": pins}
    clock_pins = json.loads(bytes.fromhex(top["cells"][clock]["attributes"]["FES_PINMAP_V1"]).decode(),
        object_pairs_hook=native.unique_object, parse_constant=native.nonfinite)
    require(clock_pins == {"count": 2, "pins": {"A": [0, "A"], "Q": [0, "Q"]}}, "actual clock buffer SIG snapshot differs")
    relevant = {root_q, inner_q, retained_q, second_q, 3549, 112724, 112726} | {bit for name in names for bits in top["cells"][name]["connections"].values() for bit in bits}
    alias_rows = [{"name": name, "record": net} for name, net in top["netnames"].items() if any(bit in relevant for bit in net["bits"])]
    labs = {lab(name) for name in names}
    ff_rows = [{"cell": name, "record": cell} for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF" and lab(name) in labs]
    ff_bels = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ff_bels) == 8221, "complete original FF BEL population differs")
    result = {**report, "critical_paths": paths}
    require(native.canonical({key: value for key, value in result.items() if key != "critical_paths"}) ==
            native.canonical({key: value for key, value in report.items() if key != "critical_paths"}), "other report metadata changed")
    audit.finish()
    with guide.open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    audit.bind(guide, sha(guide)); audit.finish()
    derived = {"schema": 1, "phase": "local-plan16-ready1-command-exact-current-path-guide", "generator_sha256": self_sha,
        "scope_sha256": scope_sha, "experimental_full_proof_sha256": proof_sha, "accepted_reference_full_proof_sha256": ACCEPTED_SHA,
        "route_profile_sha256": PROFILE_SHA, "current_full_run_sha256": RUN_SHA, "prefix_proof_sha256": PREFIX_SHA, "compiler_commit": COMMIT,
        "guide_path": str(guide), "guide_sha256": sha(guide), "selected_path_source_indices": indices, "selected_paths": len(paths),
        "selected_endpoint": TARGET, "selected_lab": [25, 16], "declared_target_lab_ena_slots": [list(slot) for slot in target_group],
        "all_exact_worst_tied_paths_in_source_order": tied,
        "expected_next_copy_name": expected_clone, "actual_selected_total_ns": math.fsum(s["delay"] for s in paths[0]["path"]),
        "actual_selected_window_ns": paths[0]["max_delay"], "full_current_report_topology": topology, "native_owner_snapshots": snapshots,
        "native_alias_records": alias_rows, "root_q": root_q, "inner_q": inner_q, "retained_copy_q": retained_q,
        "second_retained_copy_q": second_q, "second_retained_copy_consumer_slots": [list(slot) for slot in users[second_q]],
        "retained_copy_cohorts": cohorts, "actual_retained_copy_output_rows": copy_outputs, "retained_local_models": models,
        "root_consumer_slots": [list(slot) for slot in users[root_q]], "retained_copy_consumer_slots": [list(slot) for slot in users[retained_q]],
        "inner_consumer_slots": [list(slot) for slot in users[inner_q]], "predeclared_whole_labs": sorted(map(list, labs)),
        "existing_conditional_boundary": boundary, "existing_plain_sig_truth_rows": truth, "existing_function_assignments_checked": 32,
        "original_ffs_in_predeclared_labs": ff_rows, "all_original_ff_bel_manifest": ff_bels,
        "native_clock_chain": {"buffer": clock, "buffer_record": top["cells"][clock], "buffer_pin_snapshot": clock_pins,
            "pll_driver_slot": list(pll_slot), "pll_record": top["cells"][pll_slot[0]], "ordered_pll_ports": top["cells"].pll_ports[pll_slot[0]],
            "serialized_occurrence_is_not_a_logical_channel_claim": True},
        "source_fmax": report["fmax"], "source_ninth_experiment_timing_gain_accepted": False,
        "accepted_memory_reference_mhz": 117.77175903320312, "exact_path_objects_and_original_source_order_preserved": True,
        "all_original_report_metadata_except_filtered_critical_paths_exact": True, "clock_terms_locations_sources_windows_or_segment_delays_modified": False,
        "search_guide_only_not_a_new_full_timing_report": True, "new_candidate_qualified": False, "new_native_or_physical_equivalence_proved": False,
        "routed_gain_accepted": False, "hardware_tested": False, "artifact_sha256": dict(sorted(audit.artifacts.items())),
        "execution_file_sha256": dict(sorted(audit.execution.items())), "final_original_path_metadata_and_runtime_hashes_stable": True}
    with output.open("x") as stream: stream.write(json.dumps(derived, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"guide_sha256": sha(guide), "derivation_sha256": sha(output), "paths": len(paths)}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "proof-sha256", "run-sha256"): parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    derive(args.self_sha256, args.scope_sha256, args.proof_sha256, args.run_sha256)


if __name__ == "__main__":
    main()
