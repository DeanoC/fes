"""Tenth ready1 command copy with four explicit private output owner frames."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PREVIOUS = RAW / "local-plan16-ready1-skid-byte-stage-264"
PREVIOUS_PROFILE_SHA = "aceefeba07c0b3f3d7e98d09d336742b10a31aac734dccfe9c6df6dd71971d51"
PREVIOUS_RUN_SHA = "899a21d86764d2904aeab4632724b68e7db8e23cccd5ddc6a84be932dd4de4a6"
PREVIOUS_PROOF_SHA = "d1ee70008e30c5079473af11d0789a430a79b80bce75edf2477e8ef056c0230b"
PREVIOUS_PLAN_SHA = "9acacb2358c2e41aba147c445ec626f9c25f0ae29e2f557b416160860720f9bd"
PREVIOUS_HELPER_SHA = "51ff54f38b122f9d6bef47b2feb9a64916855b3523215df8b06e0c3cc99dd487"
RUNNER_SHA = "7a00db6a5bb6f045bfdac8805f234e16b9d67d75cbe13e52db912b7361a595e5"
RUNNER_SCOPE_SHA = "0ee7db618025c004c861d9ab73148e33c0ad2ecdf4e11361b81e5e02db2dfd92"
COMMIT, BASE = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f", "ec0a8d0cc56f0915e985ca7d1528daab1450c00d"
BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
HOST_SHA = "0f3c11a523ca7981b5d3e373c10d67d0ade5bf5cac9212e02e0186d6368b438c"
CONTROL_SHA = "1cff85d6656ba2afe90c89ee5a7e37a68bfa72f9592c273e4396a672520f268f"
EXPERIMENT_SHA = "5966273babe8b4405ce23571d30cc9b7e342fbdd062272ac4b575df54596b95a"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
GUIDE_FOLDER = RAW / "local-plan16-ready1-command-guide-264"
GUIDE_SHA = "ee82097b60d255e7a1ef9cc1e3eab33cb2f33d22d33269dff29e7cec3bda850f"
DERIVATION_SHA = "53151cafd46efd4626bde52f9488805b7d3aec82367b6a204171a75086ca4719"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
LAWS = RAW / "local-multicopy-ready1-264/compare_prefix.py"
LAWS_SHA = "0a52299ec2c2547dd24407bbad78caa904093ee0514c0c28ea6eda04e1e44744"
INNER, OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port1.slot_free_MISTRAL_ALUT4_C"
CLONE = OUTER + "$local_remap$2"
LEAVES = [98308, 98312, 35614, 23880, 107546]
COUNTS = [21, 2, 10, 1, 6, 1, 1, 3, 2]
PROFILE_SHA = "77fd5636a7947d349605147bc164ba7cf562dc5885aa09072a1cc2945931e546"
RUN_SHA = "3d69a28a7fb1741349f1b4e77be6f13bbdae21dfeb4bacd77ef5f5862059ad11"
PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
STRICT_HELPER_SHA = "e4124425f593d5d8cfb6de13ccf8a54ab4430b6a83e5c7156e59baacaa466ec0"
STRICT_SCOPE_SHA = "d2a7faa74e7c7f4dd42449e2483cdc9eeab52c14b3bee372510d43e8647b8e0b"
STRICT_PROOF_SHA = "f71d52283200fdee82b4176bda3c0bcc134174bb9b28e7007e5bda6f7864a5af"
COMB_OWNER = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMP = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C"
PRIVATE_FRAMES = ((COMB_OWNER, 120726, 120728, "ddr1_test.pass_end_MISTRAL_ALUT5_D", "E"),
    (DECOMP + "$code0", 120728, 120730, DECOMP + "$root", "C"),
    (DECOMP + "$code1", 120730, 120732, DECOMP + "$root", "D"),
    (DECOMP + "$root", 120732, 120734, "ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B", "C"))


def require(value, message):
    if not value: raise ValueError(message)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def adopt(audit, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); audit.bind(ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution entry is not absolute"); audit.bind(Path(name), expected, execution=True)


def copy_pin_snapshot(native, cell):
    encoded = cell["attributes"].get("FES_PINMAP_V1")
    if encoded is None: return {"present": False, "complete_exported_pin_snapshot_proved": False, "physical_truth_proved": False}
    require(type(encoded) is str and re.fullmatch(r"(?:[0-9a-fA-F]{2})+", encoded), "new copy pin snapshot is not complete hex")
    snapshot = json.loads(bytes.fromhex(encoded).decode(), object_pairs_hook=native.unique_object, parse_constant=native.nonfinite)
    require(type(snapshot) is dict and set(snapshot) == {"count", "pins"} and type(snapshot["count"]) is int and snapshot["count"] == 6 and
            type(snapshot["pins"]) is dict and set(snapshot["pins"]) == set(cell["connections"]) == set("ABCDEQ") and cell["type"] == "MISTRAL_ALUT5", "new ALUT5 pin snapshot does not cover exactly six native ports")
    match = re.fullmatch(r"MISTRAL_(?:MCOMB|COMB)\.(\d+)\.(\d+)\.(\d+)", cell["attributes"]["NEXTPNR_BEL"])
    require(match is not None and 0 <= int(match[3]) < 60 and int(match[3]) % 6 in (0, 1), "new copy lacks a real combinational half BEL")
    half = int(match[3]) % 6
    available = {"A", "B", "D" if half else "C", "E1" if half else "E0", "F1" if half else "F0"}
    pins = snapshot["pins"]
    require(all(type(row) is list and len(row) == 2 and type(row[0]) is int and row[0] == 0 and type(row[1]) is str for row in pins.values()) and
            pins["Q"] == [0, "COMBOUT"] and {pins[pin][1] for pin in "ABCDE"} == available, "new copy plain-SIG output/five distinct actual half inputs differ")
    return {"present": True, "encoded": encoded, "decoded": snapshot, "actual_bel": cell["attributes"]["NEXTPNR_BEL"],
        "actual_half": half, "complete_exported_pin_snapshot_proved": True, "bel_half_input_membership_checked": True,
        "paired_half_shared_bank_allocation_or_physical_truth_proved": False, "physical_truth_proved": False}


def private_frames(native, laws, a, b, od, ou, nd, nu):
    rows, changes = [], {}
    for owner, old_bit, new_bit, consumer, consumer_port in PRIVATE_FRAMES:
        alias, driver, slots = owner + "$Q", (owner, "Q", 0, 0), [(consumer, consumer_port, 0, 0)]
        require(laws.scalar(a["cells"][owner], "Q") == old_bit and laws.scalar(b["cells"][owner], "Q") == new_bit and
                od.get(old_bit) == nd.get(new_bit) == [driver] and a["netnames"][alias]["bits"] == [old_bit] and
                b["netnames"][alias]["bits"] == [new_bit] and ou.get(old_bit) == nu.get(new_bit) == slots,
                "explicit private owner/Q/unique driver/sole named consumer differs: " + owner)
        laws.lut(a["cells"][owner]); laws.lut(b["cells"][owner])
        for top, bit in ((a, old_bit), (b, new_bit)):
            require([name for name, net in top["netnames"].items() if bit in net["bits"]] == [alias] and
                    all(bit not in port["bits"] for port in top["ports"].values()), "private owner has another alias/public slot: " + owner)
        left, right = copy.deepcopy(a["netnames"][alias]), copy.deepcopy(b["netnames"][alias])
        left.pop("bits"); right.pop("bits")
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + alias)
        for slot in [driver, *slots]:
            cell, port, index, occurrence = slot
            require(occurrence == 0 and cell not in a["cells"].pll_ports and cell not in b["cells"].pll_ports and
                    a["cells"][cell]["connections"][port][index] == old_bit and b["cells"][cell]["connections"][port][index] == new_bit and
                    slot not in changes, "private owner frame slot is not unique/exact in both images: " + str(slot))
            changes[slot] = (old_bit, new_bit)
        rows.append({"owner": owner, "alias": alias, "before_raw_bit": old_bit, "after_raw_bit": new_bit,
            "before_driver": list(driver), "after_driver": list(driver), "named_consumer_slots": [list(slot) for slot in slots],
            "before_alias_record": a["netnames"][alias], "after_alias_record": b["netnames"][alias]})
    require(len({row[1] for row in PRIVATE_FRAMES}) == len({row[2] for row in PRIVATE_FRAMES}) == 4 and len(changes) == 8,
            "private owner frame is not bijective within each image/eight named slots")
    return rows, changes


def prove(native, selected, laws, before_doc, after_doc, profile, models):
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "same-compiler document/creator differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    alias, model = CLONE + "$Q", models[9]
    require((model["inner"], model["outer"]) == (INNER, OUTER) and profile["expected_additional_copy_name"] == CLONE and
            all(name not in a["cells"] and name not in a["netnames"] for name in (CLONE, alias)), "tenth cone/free paired namespace differs")
    require(set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and list(a) == list(b) and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (14906, 14907, 16644, 16645) and
            set(b["cells"]) == set(a["cells"]) | {CLONE} and set(b["netnames"]) == set(a["netnames"]) | {alias} and
            [name for name in b["cells"] if name != CLONE] == list(a["cells"]) and [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports), "complete module/order/PLL/one-copy population differs")
    od, ou = selected.native_tables(a); nd, nu = selected.native_tables(b)
    frames, slot_changes = private_frames(native, laws, a, b, od, ou, nd, nu)
    frame_aliases = {row["alias"]: row for row in frames}
    old_private, new_private = {row["before_raw_bit"] for row in frames}, {row["after_raw_bit"] for row in frames}
    for name, net in a["netnames"].items():
        expected = copy.deepcopy(net)
        if name in frame_aliases: expected["bits"] = [frame_aliases[name]["after_raw_bit"]]
        require(native.canonical(expected) == native.canonical(b["netnames"][name]), "undeclared original alias/raw bits/metadata differs: " + name)
    wi, mi, ai, qi = laws.lut(a["cells"][INNER]); wo, mo, ao, qo = laws.lut(a["cells"][OUTER])
    wp, mp, ap, qp = laws.lut(a["cells"][OUTER + "$local_remap"]); wc, mc, ac, qc = laws.lut(b["cells"][CLONE])
    require((wi, wo, wp, wc, mi, mo, mp, mc) == (2, 4, 5, 5, 0xb, 0xf0e0, 0xbbbbbbb0, 0xbbbbbbb0) and
            qi == 97422 and qo == 101074 and ao.count(qi) == 1 and ao[2] == qi and ac == ap == LEAVES and len(set(ac)) == 5 and
            set(ac) == set(ai + [bit for bit in ao if bit != qi]) and not ({qi, qo, qp, qc} & set(ac)) and len({qi, qo, qp, qc}) == 4 and
            not old_private & set(ac) and not new_private & set(ac) and qc == 120726 and
            qc not in (set(od) - old_private) and qc not in new_private and not new_private & (set(od) - old_private) and
            nd.get(qc) == [(CLONE, "Q", 0, 0)] and b["netnames"][alias]["bits"] == [qc] and
            [name for name, net in b["netnames"].items() if qc in net["bits"]] == [alias] and all(qc not in port["bits"] for port in b["ports"].values()) and
            b["cells"][CLONE]["attributes"]["NEXTPNR_BEL"] == model["bel"], "actual new private Q/site/five-input composition differs")
    snapshot = copy_pin_snapshot(native, b["cells"][CLONE])
    left, right = copy.deepcopy(a["cells"][OUTER + "$local_remap"]), copy.deepcopy(b["cells"][CLONE])
    for cell in (left, right):
        cell["attributes"].pop("NEXTPNR_BEL"); cell["attributes"].pop("FES_PINMAP_V1", None); cell["connections"].pop("Q")
    require(native.canonical(left) == native.canonical(right) and
            list(a["cells"][OUTER + "$local_remap"]["connections"]) == list(b["cells"][CLONE]["connections"]) and
            list(a["cells"][OUTER + "$local_remap"]["port_directions"]) == list(b["cells"][CLONE]["port_directions"]), "NEW copy metadata/input order differs beyond its BEL/Q/site pin snapshot")
    left, right = dict(a["netnames"][OUTER + "$local_remap$Q"]), dict(b["netnames"][alias]); left.pop("bits"); right.pop("bits")
    require(native.canonical(left) == native.canonical(right), "new private alias metadata differs")
    rows, slots, outputs, names, seen = profile["retained_copy_cohorts"], set(), [], [], {}
    for earlier in models[:9]:
        outer = earlier["outer"]; ordinal = seen.get(outer, 0); seen[outer] = ordinal + 1
        names.append(outer + "$local_remap" + ("$" + str(ordinal) if ordinal else ""))
    require([row["cell"] for row in rows] == names and [len(row["consumer_slots"]) for row in rows] == COUNTS, "nine retained owner/cohort declarations differ")
    for row, earlier in zip(rows, models[:9]):
        name, users = row["cell"], sorted(tuple(slot) for slot in row["consumer_slots"]); bit = laws.scalar(a["cells"][name], "Q")
        require(native.canonical(a["cells"][name]) == native.canonical(row["record"]) == native.canonical(b["cells"][name]) and
                bit == laws.scalar(b["cells"][name], "Q") and od.get(bit) == nd.get(bit) == [(name, "Q", 0, 0)] and ou.get(bit) == nu.get(bit) == users and
                len(users) == earlier["ena_users"] and a["cells"][name]["attributes"]["NEXTPNR_BEL"] == earlier["bel"] and not slots & set(users), "retained copy literal record/Q/complete users differs: " + name)
        slots.update(users); outputs.append({"cell": name, "before_raw_bit": bit, "after_raw_bit": bit, "consumer_slots": [list(slot) for slot in users]})
    declared = sorted((row["cell"], row["port"], row["vector_index"], row["occurrence"]) for row in profile["declared_ena_cohort"])
    chosen = sorted(slot for slot in ou.get(qo, []) if laws.lab(a["cells"][slot[0]]) == [25, 16])
    require(len(chosen) == len(set(chosen)) == 8 and all(slot[1:] == ("ENA", 0, 0) for slot in chosen) and model["primary_lab"] == [25, 16] and
            model["selected_groups"] == 1 and model["ena_users"] == 8 and len(ou.get(qo, [])) == 87 and len(nu.get(qo, [])) == 79 and
            nu.get(qc) == chosen == declared and [slot for slot in ou[qo] if slot not in chosen] == nu[qo] and not set(chosen) & slots, "root87-to79/new8/wholeLAB25.16/retained9 partition differs")
    for slot in ou[qo] + sorted(slots):
        cell = a["cells"][slot[0]]
        require(slot[1:] == ("ENA", 0, 0) and cell["type"] == "MISTRAL_FF" and laws.scalar(cell, "CLK") == 3549, "ready union is not common-clock scalar FF ENA")
    redirects = []
    for name, port, index, occurrence in chosen:
        row = next(row for row in profile["declared_ena_cohort"] if row["cell"] == name)
        require(native.canonical(a["cells"][name]) == native.canonical(row["before_record"]) and row["old_raw_bit"] == qo and row["clock_raw_bit"] == 3549 and
                row["bel"] == a["cells"][name]["attributes"]["NEXTPNR_BEL"] and laws.scalar(b["cells"][name], "ENA") == qc, "predeclared target record/clock/BEL/ENA differs")
        redirects.append({"cell": name, "port": port, "vector_index": index, "occurrence": occurrence, "old_raw_bit": qo, "new_raw_bit": qc, "bel": row["bel"]})
    boundary, truth = [], []
    for pin, bit in zip("ABCDE", ac):
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit) and a["cells"][od[bit][0][0]]["type"] != "MISTRAL_CONST", "boundary lacks unique unchanged ordinary driver")
        boundary.append({"port": pin, "raw_bit": bit, "native_driver": list(od[bit][0])})
    prior_names = (OUTER + "$local_remap", OUTER + "$local_remap$1")
    require(all(laws.lut(a["cells"][name])[:3] == (5, 0xbbbbbbb0, ac) for name in prior_names), "two retained fused functions/input order differ")
    for assignment in range(32):
        values = {bit: (assignment >> i) & 1 for i, bit in enumerate(ac)}
        iv = (mi >> sum(values[bit] << i for i, bit in enumerate(ai))) & 1
        original = (mo >> sum((iv if bit == qi else values[bit]) << i for i, bit in enumerate(ao))) & 1
        prior = [(laws.lut(a["cells"][name])[1] >> assignment) & 1 for name in prior_names]; additional = (mc >> assignment) & 1
        require(prior == [original] * 2 and additional == original, "conditional original/two retained/new32-row function differs")
        truth.append({"assignment": assignment, "original": original, "retained_copies": prior, "additional": additional})
    # Remove the entire old private partition before adding the independently
    # proved new frames and clone. Sequential numeric replacement is unsafe:
    # each image has different named owners at the overlapping raw IDs.
    expected_drivers = {bit: slots for bit, slots in od.items() if bit not in old_private}
    expected_drivers.update({row["after_raw_bit"]: [tuple(row["after_driver"])] for row in frames})
    expected_drivers[qc] = [(CLONE, "Q", 0, 0)]
    require(nd == expected_drivers, "complete native drivers differ beyond four named frames/new private Q")
    expected_users = {bit: copy.deepcopy(slots) for bit, slots in ou.items() if bit not in old_private}
    expected_users.update({row["after_raw_bit"]: [tuple(slot) for slot in row["named_consumer_slots"]] for row in frames})
    for slot in chosen: expected_users[qo].remove(slot)
    expected_users[qc] = chosen
    for pin, bit in zip("ABCDE", ac): expected_users.setdefault(bit, []).append((CLONE, pin, 0, 0))
    require(nu == {bit: sorted(users) for bit, users in expected_users.items()}, "complete users differ beyond8ENA/5actual input loads")
    for name, cell in a["cells"].items():
        expected = copy.deepcopy(cell)
        for (owner, port, index, occurrence), (old_bit, new_bit) in slot_changes.items():
            if name == owner:
                require(occurrence == 0 and expected["connections"][port][index] == old_bit, "explicit old private slot differs")
                expected["connections"][port][index] = new_bit
        if (name, "ENA", 0, 0) in chosen: expected["connections"]["ENA"] = [qc]
        require(native.canonical(expected) == native.canonical(b["cells"][name]) and list(cell["connections"]) == list(b["cells"][name]["connections"]) and
                list(cell["port_directions"]) == list(b["cells"][name]["port_directions"]), "original metadata/BEL/fullpins/order/undeclared slot differs: " + name)
    ff_bels = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ff_bels) == 8221 and ff_bels == profile["all_original_ff_bel_manifest"], "complete8221 FF BEL declaration differs")
    members = lambda labs: sorted(({"cell": name, "record": cell} for name, cell in a["cells"].items()
        if cell["type"] == "MISTRAL_FF" and tuple(laws.lab(cell)) in labs), key=lambda row: row["cell"])
    require(native.canonical(members({tuple(lab) for lab in profile["declared_whole_labs"]})) == native.canonical(profile["original_ffs_in_declared_labs"]), "predeclared wholeLAB FF records differ")
    selected_lab = laws.lab(b["cells"][CLONE])
    selected_members = [{"cell": row["cell"], "before_record": row["record"], "after_record": b["cells"][row["cell"]],
        "before_available_pin_snapshot": row["record"]["attributes"].get("FES_PINMAP_V1"),
        "after_available_pin_snapshot": b["cells"][row["cell"]]["attributes"].get("FES_PINMAP_V1")} for row in members({tuple(selected_lab)})]
    return {"serialized_native_scope_proved": True, "inner": INNER, "outer": OUTER, "new_clone": CLONE, "new_private_alias": alias,
        "actual_clone_q": qc, "original_root_q": qo, "actual_clone_bel": model["bel"], "actual_new_clone_record": b["cells"][CLONE],
        "actual_new_clone_pin_snapshot": snapshot, "new_owner_site_pin_snapshot_only_metadata_exception": True,
        "actual_original_cone_records": {name: a["cells"][name] for name in (INNER, OUTER, *prior_names)},
        "declared_ena_redirects": redirects, "declared_ena_redirect_count": 8, "retained_copy_cohorts": rows, "actual_retained_copy_output_rows": outputs,
        "original_root_users_before": 87, "original_root_users_after": 79, "whole_selected_lab": selected_lab, "original_ffs_in_selected_lab": selected_members,
        "whole_selected_lab_native_ff_count": len(selected_members), "predeclared_whole_labs": profile["declared_whole_labs"],
        "conditional_boundary": boundary, "assignments_checked": 32, "conditional_plain_sig_truth_rows": truth,
        "all_original_ff_placements_and_controls_exact": True, "all_original_nonprivate_raw_slots_exact": True,
        "all_original_aliases_and_raw_ids_exact": False, "all_original_alias_metadata_except_four_declared_bits_exact": True,
        "explicit_private_output_owners": frames, "private_output_owner_count": 4, "declared_private_raw_slot_count": len(slot_changes),
        "complete_native_driver_and_user_tables_proved": True, "original_export_order_and_paired_pll_records_exact": True,
        "private_output_frame_alignment_used": True, "global_numeric_normalization_or_buffer_collapse_used": False,
        "physical_pins_lab_cache_gpu_or_independent_sta_proved": False}


def comparison(args):
    require(not (HERE / "baseline/comparison-prefix-v2.json").exists(), "exclusive tenth V2 prefix output already exists")
    require(args.runner_sha256 == RUNNER_SHA and args.runner_scope_sha256 == RUNNER_SCOPE_SHA and
            args.guide_sha256 == GUIDE_SHA and args.derivation_sha256 == DERIVATION_SHA and args.profile_sha256 == PROFILE_SHA and args.run_sha256 == RUN_SHA and
            all(re.fullmatch(r"[0-9a-f]{64}", value) and value != "0" * 64 for value in
                (args.profile_sha256, args.run_sha256, args.guide_sha256, args.derivation_sha256)), "actual recorder/profile/closedrun/guide pins required")
    native = load(PURE, PURE_SHA, "command_tenth_v2_prefix_native"); audit = native.Audit()
    for path, expected in ((PURE, PURE_SHA), (Path(__file__).resolve(), args.self_sha256), (HERE / "prefix-v2-scope.md", args.scope_sha256),
            (HERE / "compare_prefix.py", STRICT_HELPER_SHA), (HERE / "prefix-scope.md", STRICT_SCOPE_SHA),
            (HERE / "baseline/comparison-prefix.json", STRICT_PROOF_SHA), (HERE / "local-plan.json", PLAN_SHA),
            (HERE / "run_baseline.py", args.runner_sha256), (HERE / "scope.md", args.runner_scope_sha256), (HERE / "source-identity.json", args.profile_sha256),
            (HERE / "baseline/run.json", args.run_sha256), (PREVIOUS / "source-identity.json", PREVIOUS_PROFILE_SHA), (PREVIOUS / "baseline/run.json", PREVIOUS_RUN_SHA),
            (PREVIOUS / "baseline/comparison-prefix-v2.json", PREVIOUS_PROOF_SHA), (PREVIOUS / "run_baseline.py", PREVIOUS_HELPER_SHA),
            (PREVIOUS / "local-plan.json", PREVIOUS_PLAN_SHA), (GUIDE_FOLDER / "command-guide.json", args.guide_sha256),
            (GUIDE_FOLDER / "derivation.json", args.derivation_sha256), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (LAWS, LAWS_SHA)): audit.bind(path, expected)
    runner = load(HERE / "run_baseline.py", args.runner_sha256, "command_tenth_v2_prefix_runner_definitions")
    profile, record, original, previous, proof, derived = (native.read(path) for path in
        (HERE / "source-identity.json", HERE / "baseline/run.json", PREVIOUS / "source-identity.json", PREVIOUS / "baseline/run.json",
         PREVIOUS / "baseline/comparison-prefix-v2.json", GUIDE_FOLDER / "derivation.json"))
    for manifest in (proof, derived): adopt(audit, manifest)
    strict = native.read(HERE / "baseline/comparison-prefix.json"); adopt(audit, strict)
    require(strict["phase"] == "local-plan16-ready1-command-tenth-stage-bounded-native-prefix" and
            strict["generator_sha256"] == STRICT_HELPER_SHA and strict["scope_sha256"] == STRICT_SCOPE_SHA and
            strict["source_identity_sha256"] == PROFILE_SHA and strict["current_baseline_run_sha256"] == RUN_SHA and
            strict["candidate_completed"] is True and strict["native_graph_proof_available"] is False and
            strict["native_path_topology_rejection"] is None and strict["structural_rejection"] == {"exception_type": "ValueError",
                "reason": "original alias/raw bits/metadata differs: " + COMB_OWNER + "$Q"} and strict["routed_gain_accepted"] is False and
            strict["final_original_path_metadata_and_runtime_hashes_stable"] is True,
            "immutable strict rejection is not the exact observed first private-alias difference")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input is not absolute"); audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    require(proof["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-explicit-private-owner-native-prefix" and proof["compiler_commit"] == COMMIT and
            proof["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and proof["current_baseline_run_sha256"] == PREVIOUS_RUN_SHA and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and all(proof[key] is True for key in
                ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
                 "all_eight_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "final_original_path_metadata_and_runtime_hashes_stable")), "ninth prefix prerequisite is not positive")
    require(previous["completed"] is True and previous["exit_code"] == 0 and previous["compiler_read_audit_passed"] is previous["final_original_input_output_runtime_hashes_stable"] is True and
            previous["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and all(native.canonical(previous[key]) == native.canonical(value) for key, value in original.items() if key != "input_sha256") and
            previous["input_sha256"] == {**original["input_sha256"], str(PREVIOUS / "source-identity.json"): PREVIOUS_PROFILE_SHA}, "closed ninth record/profile differs")
    require(profile["phase"] == "local-plan16-ready1-command-tenth-stage-predicted-baseline" and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and profile["host_validation_sha256"] == HOST_SHA and profile["control_proof_sha256"] == CONTROL_SHA and
            profile["helper_sha256"] == args.runner_sha256 and profile["scope_sha256"] == args.runner_scope_sha256 and profile["previous_source_identity_sha256"] == PREVIOUS_PROFILE_SHA and
            profile["previous_baseline_run_sha256"] == PREVIOUS_RUN_SHA and profile["previous_prefix_proof_sha256"] == PREVIOUS_PROOF_SHA and
            profile["experimental_current_full_proof_sha256"] == EXPERIMENT_SHA and profile["accepted_current_full_proof_sha256"] == ACCEPTED_SHA and profile["minimum_accepted_memory_mhz"] == 117.77175903320312 and
            profile["guide_sha256"] == args.guide_sha256 and profile["guide_derivation_sha256"] == args.derivation_sha256 and
            derived["experimental_full_proof_sha256"] == EXPERIMENT_SHA and derived["prefix_proof_sha256"] == PREVIOUS_PROOF_SHA and derived["accepted_reference_full_proof_sha256"] == ACCEPTED_SHA and
            derived["source_ninth_experiment_timing_gain_accepted"] is False and derived["guide_sha256"] == args.guide_sha256, "current compiler/guide construction/accepted reference roles differ")
    for key, value in profile.items():
        if key != "input_sha256": require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
            record["source_identity_sha256"] == args.profile_sha256 and not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): args.profile_sha256} and record["command"] == runner.command(previous) and
            record["execution"] == profile["baseline_execution"] == previous["execution"] and record["cwd"] == previous["cwd"] and
            record["diagnostic_environment"] == previous["diagnostic_environment"] and record["original_nine_complete_trial_models_exact"] is True, "completed tenth record/runtime/input union differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime outside frozen closure"); audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")}, "complete predicted output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual predicted output empty"); audit.bind(Path(name), expected)
    require(audit.paths.get(HERE / "local-plan.json") == profile["local_plan_sha256"] and native.read(HERE / "local-plan.json")["steps"] == profile["local_plan_steps"] and
            len(profile["local_plan_steps"]) == 10 <= 16 and profile["local_plan_steps"][:9] == original["local_plan_steps"] and profile["original_nine_plan_sha256"] == PREVIOUS_PLAN_SHA and
            profile["local_plan_steps"][9] == {"report": str(GUIDE_FOLDER / "command-guide.json"), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True}, "exact nine descriptors plus sole tenth differ")
    ninth, control, definitions = runner.local_definitions()
    for path, expected in ((PREVIOUS / "run_baseline.py", PREVIOUS_HELPER_SHA), (control.HOST, HOST_SHA), (control.BINARY, BINARY_SHA), (control.ARCHIVE, ARCHIVE_SHA), *control.PARSERS):
        require(audit.paths.get(path) == expected, "pure log/compiler dependency outside frozen closure")
    control.host_valid(native.read(control.HOST), HOST_SHA)
    log, previous_log = (HERE / "baseline/phase.log").read_text(), (PREVIOUS / "baseline/phase.log").read_text()
    models, old_models = runner.qualification(log, ninth, control, definitions), ninth.qualification(previous_log, control, definitions)
    require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and native.canonical(models[:9]) == native.canonical(old_models) ==
            native.canonical(profile["retained_local_models"]) == native.canonical(proof["fresh_local_models"]), "fresh ten/retained nine complete models differ")
    frozen = load(FREEZE, FREEZE_SHA, "command_tenth_v2_prefix_freeze_definitions")
    selected = load(SELECTED, SELECTED_SHA, "command_tenth_v2_prefix_tables_topology", frozen)
    laws = load(LAWS, LAWS_SHA, "command_tenth_v2_prefix_scalar_lut_lab_definitions")
    before, after = native.read_netlist(PREVIOUS / "baseline/placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(PREVIOUS / "baseline/timing.json")
    metrics = len(native.PLACEMENT_METRICS.findall(log)) == 71 and native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(previous_log)
    evidence, rejection, topology, topology_rejection = None, None, None, None
    try:
        require(metrics, "all71 original placement metrics are not exact"); evidence = prove(native, selected, laws, before, after, profile, models)
    except (ValueError, TypeError, KeyError, IndexError, AttributeError, StopIteration) as error: rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    try:
        topology = selected.report_topology(after, report, old_report)
        require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and report["timing_report_paths"] == 16384 and
                report["fmax"] == record["actual_predicted_fmax"], "current native report count/pairs/cap/Fmax differs")
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error: topology_rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and not any(text in log for text in
                ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy")), "actual tenth phase is not predicted-only")
    audit.finish(); positive = rejection is None and topology_rejection is None
    return {"schema": 1, "phase": "local-plan16-ready1-command-tenth-stage-explicit-private-owner-native-prefix", "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "source_identity_sha256": args.profile_sha256, "current_baseline_run_sha256": args.run_sha256, "previous_prefix_proof_sha256": PREVIOUS_PROOF_SHA,
        "previous_baseline_run_sha256": PREVIOUS_RUN_SHA, "control_proof_sha256": CONTROL_SHA, "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256,
        "runner_sha256": args.runner_sha256, "runner_scope_sha256": args.runner_scope_sha256, "guide_sha256": args.guide_sha256, "guide_derivation_sha256": args.derivation_sha256,
        "candidate_completed": True, "structural_rejection": rejection, "native_path_topology_rejection": topology_rejection,
        "native_graph_proof_available": rejection is None, "fresh_driver_guide_available_after_conditional_prefix_proof": positive, "native_graph_evidence": evidence,
        "fresh_local_models": models, "previous_local_models": old_models, "all_nine_retained_complete_trial_models_exact": True, "all_71_placement_metrics_exact": metrics,
        "current_complete_native_report_topology": topology, "actual_predicted_fmax": report["fmax"], "complete_predicted_report_exact": native.canonical(report) == native.canonical(old_report),
        "complete_predicted_report_exact_required": False, "experimental_current_full_proof_sha256": EXPERIMENT_SHA, "accepted_current_full_proof_sha256": ACCEPTED_SHA,
        "minimum_accepted_memory_mhz": 117.77175903320312, "conditional_plain_sig_equivalence_only": True,
        "immutable_strict_prefix_rejection_sha256": STRICT_PROOF_SHA, "immutable_strict_prefix_generator_sha256": STRICT_HELPER_SHA,
        "immutable_strict_prefix_scope_sha256": STRICT_SCOPE_SHA, "immutable_strict_prefix_structural_rejection": strict["structural_rejection"],
        "original_private_output_raw_ids_equal": False, "private_output_frame_alignment_used": True, "private_output_owner_count": 4,
        "global_numeric_normalization_or_buffer_collapse_used": False,
        "physical_pin_lab_cache_gpu_or_sta_acceptance_inherited": False, "routed_gain_accepted": False, "hardware_tested": False,
        "pure_function_helper_sha256": {str(path): expected for path, expected in ((PURE, PURE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (LAWS, LAWS_SHA),
            (PREVIOUS / "run_baseline.py", PREVIOUS_HELPER_SHA), *control.PARSERS)}, "artifact_sha256": dict(sorted(audit.artifacts.items())),
        "execution_file_sha256": dict(sorted(audit.execution.items())), "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "runner-sha256", "runner-scope-sha256", "profile-sha256", "run-sha256", "guide-sha256", "derivation-sha256"):
        parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    with (HERE / "baseline/comparison-prefix-v2.json").open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_path_topology_rejection", "native_graph_proof_available")}, indent=2))


if __name__ == "__main__": main()
