# Strict initial tenth-stage prefix

ROOT alone activates this new exclusive comparator after final whole-byte/hash/
AST and independent peer review. Actual future prepared profile and closed tenth
run SHA arguments are mandatory; no unknown hash is guessed. Actual completed
guideee82097b/derivation53151caf are literal pins and required CLI arguments.
The runner7a00db6a/scope0ee7db61 are pinned. Positive ninth V2 d1ee7000, actual
run899a21d8/profileaceefeba and literal nine-plan9acacb23 are structural inputs.
Their existing named-owner proof is bound as provenance, never rerun or applied
to this new graph. Current compiler d7e5c61f/ELF41c2afe1/archive4fbebd5e/host0f3
and fresh-eight1cff prerequisite remain distinct from older compiler evidence.

The complete current record/profile/input union, three actual outputs, actual
runtime, flat previous proof/guide source/dependency closures and pure modules
are bound and rehashed on their original paths. Runtime/command/diagnostics must
equal the ninth invocation apart from the one tenth-plan selector and new write/
report paths. Nine descriptors and all nine fresh complete trial models remain
exact. The tenth actual candidate0/group1 guards must pass with eight ENAs, zero
FF shift and gain at least250ps. All71 placement metrics remain exact.

Full ninth5966/ea8e is native/physical-positive construction with rejected gain;
accepted fifth6dc at117.771759MHz remains a separate numerical reference. Guide
truth and failed ninth delays qualify neither the new copy nor any timing gain.
No old generator, authenticator, prepare/run/main or comparison is invoked.
Pinned32fd supplies lossless paired-PLL/native/Audit;72131/8601 supply complete
native tables/report topology;0a522 supplies only scalar/lut/lab definitions.
The new recorder supplies pure command/local parser/host checks only.

Initial graph policy is strict:14906→14907 cells/16644→16645 nets, only one new
outerALUT4_C$local_remap$2 ALUT5 and sole private Q alias. All original aliases,
raw bits, module metadata/settings/public ports/order/paired PLLs, original
cell masks/pins/BELs/port order and nine retained copy records/users remain exact.
Any shift of four generated private outputs is an explicit saved rejection.
There is no private-frame alignment, numeric renaming or buffer collapse.

Actual masks are inner0xb/outer0xf0e0/two retained fused0xbbbbbbb0/new0xbbbbbbb0;
five distinct boundary bits98308/98312/35614/23880/107546 must retain their unique
ordinary drivers. All32 new plain-SIG conditional rows independently prove the
original, two retained functions and additional table agree. Root101074 users
87→79; exactly all eight scalar FF ENAs in LAB25.16 move to the new Q, remaining
on CLK3549. Nine cohorts21/2/10/1/6/1/1/3/2 and all complete native driver/user
tables remain exact except these eight slots and five added input loads.

Only the NEW owner template may have a different optional FES_PINMAP snapshot.
When exported, it must be complete hex/strict JSON, count6/exactABCDEQ, all plain
SIG, COMBOUT Q and five distinct actual COMB/MCOMB half-bank input pins. This is
snapshot-shape evidence; shared A/B allocation and physical truth are unproved.
Absence is explicitly unproved. Every original pin attribute remains exact.

All8221 original FF BELs and predeclared entire FF neighborhoods must match;
the actual new clone site adds its whole original FF neighborhood dynamically.
Its site/Q come only from the closed fresh model/image. Current complete15290
paths/seven pairs/cap16384 and native endpoint/clock/window topology are checked
separately against the ninth predicted report even if graph comparison rejects.
Actual predicted Fmax is recorded, with no report equality requirement or gain.
Final original path hashes remain checked on serialized structural/topology
rejection. Hidden pin/LAB caches, GPU IDs, numerical STA, routed physical function,
decoded RBF and hardware acceptance are not claimed.
