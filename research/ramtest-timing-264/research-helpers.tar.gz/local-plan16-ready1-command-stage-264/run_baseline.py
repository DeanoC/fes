"""Record an additive tenth ready1 remap after the closed ninth prefix."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
PREVIOUS = RAW / "local-plan16-ready1-skid-byte-stage-264"
PREVIOUS_PROFILE_SHA = "aceefeba07c0b3f3d7e98d09d336742b10a31aac734dccfe9c6df6dd71971d51"
PREVIOUS_RUN_SHA = "899a21d86764d2904aeab4632724b68e7db8e23cccd5ddc6a84be932dd4de4a6"
PREVIOUS_PROOF_SHA = "d1ee70008e30c5079473af11d0789a430a79b80bce75edf2477e8ef056c0230b"
PREVIOUS_HELPER_SHA = "51ff54f38b122f9d6bef47b2feb9a64916855b3523215df8b06e0c3cc99dd487"
PREVIOUS_SCOPE_SHA = "1533f18f01efebf3b3dc3010d054d91b3ad1a565206f4b0b9205a988615d8702"
PREVIOUS_COMPARE_SHA = "35ec079e3e9144468757a5714b4651424517d175b8f07d823d540941a40af7ec"
PREVIOUS_COMPARE_SCOPE_SHA = "df76ca3feb53ebce6415d13b1a830ecd3243217df0435ff12e82fcf4915e65da"
PREVIOUS_PLAN_SHA = "9acacb2358c2e41aba147c445ec626f9c25f0ae29e2f557b416160860720f9bd"
FULL = RAW / "local-plan16-ready1-skid-byte-route-264"
FULL_PROOF = RAW / "local-plan16-ready1-skid-byte-route-proof-264/comparison.json"
FULL_PROOF_SHA = "5966273babe8b4405ce23571d30cc9b7e342fbdd062272ac4b575df54596b95a"
FULL_PROFILE_SHA = "788f16d21d128edbf0ffce4fb32b63db6e47135cf9faa5686d084d6fd4aa780d"
FULL_RUN_SHA = "ea8e5bed840dc8ec53c077b669fc2cc2cc3a8081afd27476695be1bd675f9ba5"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
GUIDE_FOLDER = RAW / "local-plan16-ready1-command-guide-264"
GUIDE, DERIVATION = GUIDE_FOLDER / "command-guide.json", GUIDE_FOLDER / "derivation.json"
COMPILER = RAW / "remap-plan16-264"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-remap-plan16-264"
COMMIT, BASE = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f", "ec0a8d0cc56f0915e985ca7d1528daab1450c00d"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
HOST, HOST_SHA = COMPILER / "validation/host-validation.json", "0f3c11a523ca7981b5d3e373c10d67d0ade5bf5cac9212e02e0186d6368b438c"
CONTROL_PROOF_SHA = "1cff85d6656ba2afe90c89ee5a7e37a68bfa72f9592c273e4396a672520f268f"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PROFILE, PLAN, FOLDER = HERE / "source-identity.json", HERE / "local-plan.json", HERE / "baseline"
INNER, OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port1.slot_free_MISTRAL_ALUT4_C"
TARGET = "hps_ddr.m1_writedata_MISTRAL_FF_Q_61"
COHORT_COUNTS = [21, 2, 10, 1, 6, 1, 1, 3, 2]


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected) and
            (path not in inputs or inputs[path] == expected), "invalid/conflicting original path hash")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute"); bind(inputs, name, expected)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def local_definitions():
    ninth = load(PREVIOUS / "run_baseline.py", PREVIOUS_HELPER_SHA, "command_tenth_ninth_pure")
    control, definitions = ninth.local_definitions()
    return ninth, control, definitions


def qualification(log, ninth, control, definitions):
    headers = list(re.finditer(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, row.groups())) for row in headers] == [(i, 0, g, 0, 1) for i, g in enumerate((8,) + (1,) * 9)], "fresh ten-stage headers differ")
    models = ninth.qualification(log[:headers[9].start()], control, definitions)
    block = log[headers[9].end():]
    trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
    choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
    applied = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
    require(trials and len(choices) == len(applied) == 1 and choices[0][1] == applied[0][1] == "0" and
            trials[-1].end() < choices[0].start() < applied[0].start(), "tenth candidate0/application lacks final guarded trial")
    row = trials[-1].groups()
    require((row[0], row[1], row[4], row[12], row[7]) == choices[0].groups()[1:] and row[:2] == (INNER, OUTER) and
            row[2:4] == ("25", "16") and row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and
            row[11:13] == ("1", "8") and int(row[7]) >= 250, "fresh eight-ENA fixed-FF/clock/hold/boundary/minimum-gain guards differ")
    models.append({"index": 9, "candidate": 0, "groups_budget": 1, "selected_groups": 1, "inner": INNER, "outer": OUTER,
        "primary_lab": [25, 16], "bel": row[4], "ena_users": 8, "gain_ps": int(row[7]), "actual_trial_count": len(trials),
        "prior_trial_rows": [trial.groups() for trial in trials[:-1]], "ff_shift": [0, 0],
        "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False})
    return models


def command(previous):
    result = list(previous["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == 1 and not any(flag in result for flag in
        ("--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "current ninth command role differs")
    for flag, path in (("--remap-plan", PLAN), ("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous plan/output selector"); result[result.index(flag) + 1] = str(path)
    return result


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
            git(SOURCE, "merge-base", BASE, COMMIT) == BASE and
            set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == set(host["changed_source_files"]), "current compiler source differs from clean host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
            [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def prepare(self_sha, scope_sha, guide_sha, derivation_sha):
    require(all(type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) and value != "0" * 64 for value in
            (self_sha, scope_sha, guide_sha, derivation_sha)) and not any(path.exists() for path in (PROFILE, PLAN, FOLDER)), "actual pins and exclusive tenth outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (GUIDE, guide_sha), (DERIVATION, derivation_sha),
            (PREVIOUS / "source-identity.json", PREVIOUS_PROFILE_SHA), (PREVIOUS / "baseline/run.json", PREVIOUS_RUN_SHA),
            (PREVIOUS / "baseline/comparison-prefix-v2.json", PREVIOUS_PROOF_SHA), (PREVIOUS / "run_baseline.py", PREVIOUS_HELPER_SHA),
            (PREVIOUS / "scope.md", PREVIOUS_SCOPE_SHA), (PREVIOUS / "compare_prefix_v2.py", PREVIOUS_COMPARE_SHA),
            (PREVIOUS / "prefix-v2-scope.md", PREVIOUS_COMPARE_SCOPE_SHA), (PREVIOUS / "local-plan.json", PREVIOUS_PLAN_SHA),
            (FULL_PROOF, FULL_PROOF_SHA), (FULL / "source-identity.json", FULL_PROFILE_SHA), (FULL / "route-c0/run.json", FULL_RUN_SHA),
            (ACCEPTED, ACCEPTED_SHA), (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA), (HOST, HOST_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)): bind(inputs, path, expected)
    ninth, control, definitions = local_definitions()
    original, previous, proof, derived, experiment, accepted, host = (read(path) for path in
        (PREVIOUS / "source-identity.json", PREVIOUS / "baseline/run.json", PREVIOUS / "baseline/comparison-prefix-v2.json", DERIVATION, FULL_PROOF, ACCEPTED, HOST))
    control.host_valid(host, HOST_SHA)
    for manifest in (proof, derived, experiment, accepted): adopt(inputs, manifest)
    require(proof["phase"] == "local-plan16-ready1-skid-byte-ninth-stage-explicit-private-owner-native-prefix" and
            proof["compiler_commit"] == COMMIT and proof["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and proof["current_baseline_run_sha256"] == PREVIOUS_RUN_SHA and
            proof["generator_sha256"] == PREVIOUS_COMPARE_SHA and proof["scope_sha256"] == PREVIOUS_COMPARE_SCOPE_SHA and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and all(proof[key] is True for key in
                ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
                 "all_eight_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "final_original_path_metadata_and_runtime_hashes_stable")), "ninth prefix prerequisite is not positive")
    require(previous["completed"] is True and previous["exit_code"] == 0 and previous["compiler_read_audit_passed"] is previous["final_original_input_output_runtime_hashes_stable"] is True and
            previous["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and previous["compiler_commit"] == COMMIT and previous["control_proof_sha256"] == CONTROL_PROOF_SHA and
            all(canonical(previous[key]) == canonical(value) for key, value in original.items() if key != "input_sha256") and
            previous["input_sha256"] == {**original["input_sha256"], str(PREVIOUS / "source-identity.json"): PREVIOUS_PROFILE_SHA} and
            previous["execution"] == original["baseline_execution"] and not any(key in previous for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "closed ninth profile/run/runtime differs")
    for ledger in (previous["input_sha256"], previous["output_sha256"], previous["execution"]["files"], *(host[key] for key in control.HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "original input/runtime pathname is not absolute"); bind(inputs, path, expected)
    require(experiment["structural_rejection"] is None and experiment["native_graph_proof_available"] is experiment["physical_scope_proved"] is True and
            experiment["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and experiment["current_full_run_sha256"] == FULL_RUN_SHA and
            experiment["source_identity_sha256"] == FULL_PROFILE_SHA and experiment["prefix_proof_sha256"] == PREVIOUS_PROOF_SHA and
            experiment["accepted_full_proof_sha256"] == ACCEPTED_SHA and accepted["structural_rejection"] is None and
            accepted["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and derived["phase"] == "local-plan16-ready1-command-exact-current-path-guide" and
            derived["experimental_full_proof_sha256"] == FULL_PROOF_SHA and derived["current_full_run_sha256"] == FULL_RUN_SHA and
            derived["route_profile_sha256"] == FULL_PROFILE_SHA and derived["prefix_proof_sha256"] == PREVIOUS_PROOF_SHA and
            derived["accepted_reference_full_proof_sha256"] == ACCEPTED_SHA and derived["accepted_memory_reference_mhz"] == 117.77175903320312 and
            derived["source_ninth_experiment_timing_gain_accepted"] is derived["new_candidate_qualified"] is False and
            derived["guide_sha256"] == guide_sha and derived["guide_path"] == str(GUIDE) and derived["selected_lab"] == [25, 16] and
            derived["selected_endpoint"] == TARGET and derived["selected_path_source_indices"] == [1] and derived["selected_paths"] == 1 and
            derived["expected_next_copy_name"] == OUTER + "$local_remap$2" and derived["existing_function_assignments_checked"] == 32 and
            derived["exact_path_objects_and_original_source_order_preserved"] is True and derived["all_original_report_metadata_except_filtered_critical_paths_exact"] is True and
            derived["clock_terms_locations_sources_windows_or_segment_delays_modified"] is False, "guide construction and accepted-reference roles differ")
    bind(inputs, GUIDE_FOLDER / "derive_guide.py", derived["generator_sha256"]); bind(inputs, GUIDE_FOLDER / "scope.md", derived["scope_sha256"])
    native = load(NATIVE, NATIVE_SHA, "tenth_command_native_pure")
    frozen = load(FREEZE, FREEZE_SHA, "tenth_command_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "tenth_command_selected_pure", frozen)
    before_doc, full_doc = native.read_netlist(PREVIOUS / "baseline/placed.json"), native.read_netlist(FULL / "route-c0/routed.json")
    before, routed = before_doc["modules"]["top"], full_doc["modules"]["top"]
    guide, report = read(GUIDE), read(FULL / "route-c0/timing.json")
    paths = [report["critical_paths"][index] for index in derived["selected_path_source_indices"]]
    require(canonical(guide) == canonical({**report, "critical_paths": paths}) and paths[0]["path"][-1]["to"]["cell"] == TARGET and
            paths[0]["path"][-1]["to"]["port"] == "ENA", "actual guide object/full metadata differs")
    for segment in paths[0]["path"]:
        for endpoint in (segment["from"], segment["to"]):
            name, port = endpoint["cell"], endpoint["port"]; a, b = before["cells"][name], routed["cells"][name]
            require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and a["attributes"]["NEXTPNR_BEL"] == b["attributes"]["NEXTPNR_BEL"] and
                    a["port_directions"][port] == b["port_directions"][port] and a["connections"][port] == b["connections"][port], "guide endpoint differs in ninth predicted image")
    drivers, users = selected.native_tables(before)
    q = before["cells"][OUTER]["connections"]["Q"][0]
    cohort = [slot for slot in users[q] if before["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"].startswith("MISTRAL_FF.25.16.")]
    require(len(users[q]) == 87 and len(cohort) == 8 and all(slot[1:] == ("ENA", 0, 0) for slot in cohort) and
            derived["declared_target_lab_ena_slots"] == [list(slot) for slot in cohort] and (TARGET, "ENA", 0, 0) in cohort, "tenth group is not all eight original-root LAB25.16 ENAs")
    target_rows = []
    for name, port, index, occurrence in cohort:
        cell = before["cells"][name]
        require(cell["type"] == "MISTRAL_FF" and cell["connections"]["CLK"] == [3549], "target FF clock differs")
        target_rows.append({"cell": name, "port": port, "vector_index": index, "occurrence": occurrence, "old_raw_bit": q,
            "clock_raw_bit": 3549, "bel": cell["attributes"]["NEXTPNR_BEL"], "before_record": cell})
    models = ninth.qualification((PREVIOUS / "baseline/phase.log").read_text(), control, definitions)
    require(canonical(models) == canonical(previous["actual_selected_local_qualification"]) == canonical(proof["fresh_local_models"]) and len(models) == 9, "closed nine fresh models differ")
    copies, seen, labs, owners = [], {}, {(25, 16)}, {INNER, OUTER}
    for index, model in enumerate(models):
        outer = model["outer"]; ordinal = seen.get(outer, 0); seen[outer] = ordinal + 1
        name = outer + "$local_remap" + ("$" + str(ordinal) if ordinal else "")
        cell = before["cells"][name]; bit = cell["connections"]["Q"][0]; recorded = derived["retained_copy_cohorts"][index]
        require(recorded["cell"] == name and recorded["raw_q"] == bit and recorded["consumer_slots"] == [list(slot) for slot in users[bit]] and
                cell["type"] == recorded["record"]["type"] and cell["parameters"] == recorded["record"]["parameters"] and
                cell["connections"] == recorded["record"]["connections"] and cell["port_directions"] == recorded["record"]["port_directions"] and
                cell["attributes"]["NEXTPNR_BEL"] == recorded["record"]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
                len(users[bit]) == model["ena_users"] and not set(users[bit]) & set(cohort) and all(slot[1:] == ("ENA", 0, 0) and
                    before["cells"][slot[0]]["type"] == "MISTRAL_FF" and before["cells"][slot[0]]["connections"]["CLK"] == [3549] for slot in users[bit]), "retained nine-copy logical record/cohort/site differs")
        copies.append({"cell": name, "record": cell, "consumer_slots": [list(slot) for slot in users[bit]]})
        owners.update((model["inner"], outer, name)); owners.update(slot[0] for slot in users[bit]); labs.add(tuple(model["primary_lab"]))
    require([len(row["consumer_slots"]) for row in copies] == COHORT_COUNTS, "all nine retained cohorts differ")
    expected_name = OUTER + "$local_remap$2"
    require(all(name not in before["cells"] and name not in before["netnames"] for name in (expected_name, expected_name + "$Q")), "expected unused suffix pair is occupied")
    for name in owners:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", before["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "original cone/copy/cohort lacks placed BEL"); labs.add(tuple(map(int, match.groups())))
    ff_bels, neighborhoods = {}, []
    for name, cell in before["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        bel = cell["attributes"].get("NEXTPNR_BEL", ""); match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", bel)
        require(match is not None, "original FF lacks placed BEL"); ff_bels[name] = bel
        if tuple(map(int, match.groups())) in labs: neighborhoods.append({"cell": name, "record": cell})
    require(len(ff_bels) == 8221 and ff_bels == original["all_original_ff_bel_manifest"], "all original FF owner/BELs differ")
    old_plan = read(PREVIOUS / "local-plan.json")
    require(old_plan["steps"] == original["local_plan_steps"] and len(old_plan["steps"]) == 9, "literal nine descriptors differ")
    plan = copy.deepcopy(old_plan); plan["steps"].append({"report": str(GUIDE), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True})
    require(len(plan["steps"]) == 10 <= 16 and plan["steps"][:9] == old_plan["steps"], "ten-step plan/exact nine descriptors differ")
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    for name, expected in control.SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    finish(inputs); clean_source(host)
    with PLAN.open("x") as stream: stream.write(json.dumps(plan, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, PLAN, sha(PLAN))
    profile = {"schema": 1, "phase": "local-plan16-ready1-command-tenth-stage-predicted-baseline", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA,
        "control_proof_sha256": CONTROL_PROOF_SHA, "previous_source_identity_sha256": PREVIOUS_PROFILE_SHA, "previous_baseline_run_sha256": PREVIOUS_RUN_SHA,
        "previous_prefix_proof_sha256": PREVIOUS_PROOF_SHA, "experimental_current_full_proof_sha256": FULL_PROOF_SHA, "accepted_current_full_proof_sha256": ACCEPTED_SHA,
        "minimum_accepted_memory_mhz": 117.77175903320312, "guide_sha256": guide_sha, "guide_derivation_sha256": derivation_sha,
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "original_nine_plan_path": str(PREVIOUS / "local-plan.json"), "original_nine_plan_sha256": PREVIOUS_PLAN_SHA,
        "local_plan_sha256": inputs[str(PLAN)], "local_plan_steps": plan["steps"], "retained_local_models": models,
        "authorized_plan_delta": {"append_index": 9, "step": plan["steps"][9], "first_nine_descriptors_exact": True},
        "expected_additional_copy_name": expected_name, "declared_ena_cohort": target_rows, "retained_copy_cohorts": copies,
        "declared_whole_labs": sorted(map(list, labs)), "original_ffs_in_declared_labs": sorted(neighborhoods, key=lambda row: row["cell"]),
        "all_original_ff_bel_manifest": dict(sorted(ff_bels.items())), "actual_tenth_site_neighborhood_requires_later_prefix_proof": True,
        "command": command(previous), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"], "baseline_execution": previous["execution"],
        "input_sha256": dict(sorted(inputs.items())), "driver_pass_executed": False, "native_graph_or_physical_equivalence_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "plan_sha256": sha(PLAN), "inputs": len(inputs), "target_ena_count": len(target_rows)}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile = read(PROFILE)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    previous, host = read(PREVIOUS / "baseline/run.json"), read(HOST)
    require(not FOLDER.exists() and profile["command"] == command(previous) and profile["baseline_execution"] == previous["execution"] and
            profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["cwd"] == previous["cwd"] == str(MODULE) and
            inputs[str(PREVIOUS / "baseline/run.json")] == profile["previous_baseline_run_sha256"] and inputs[str(PREVIOUS / "baseline/comparison-prefix-v2.json")] == profile["previous_prefix_proof_sha256"] and
            inputs[str(HOST)] == profile["host_validation_sha256"] == HOST_SHA and inputs[str(BINARY)] == profile["binary_sha256"] == BINARY_SHA and
            inputs[str(ARCHIVE)] == profile["source_archive_sha256"] == ARCHIVE_SHA and inputs[str(PLAN)] == profile["local_plan_sha256"] and
            read(PLAN)["steps"] == profile["local_plan_steps"] and len(profile["local_plan_steps"]) == 10 and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"], "frozen tenth profile/command/runtime/plan differs")
    ninth, control, definitions = local_definitions(); control.host_valid(host, HOST_SHA); clean_source(host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in control.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module path/bytes differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual current compiler/runtime differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "tenth predicted qualification did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy")) and
                not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual tenth phase is not predicted-only")
        models = qualification(log, ninth, control, definitions); record["actual_selected_local_qualification"] = models
        record["original_nine_complete_trial_models_exact"] = canonical(models[:9]) == canonical(profile["retained_local_models"])
        require(record["original_nine_complete_trial_models_exact"], "freshly retained nine guarded models changed")
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "predicted report cap/count/Fmax invalid")
        record["actual_predicted_fmax"] = report["fmax"]; record["output_sha256"] = {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "actual predicted output missing"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "original_nine_complete_trial_models_exact": True, "actual_tenth_qualification": models[9], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "guide-sha256", "derivation-sha256", "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.guide_sha256, args.derivation_sha256)
        require(all(values), "actual guide/self/scope preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
