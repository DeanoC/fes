# Tenth-stage explicit private output frames

ROOT alone executes this NEW exclusive comparator after final whole-byte/hash/
AST and independent peer review. Self/scope, runner/scope, actual profile77fd5636,
closed tenth run3d69a28a, guideee82097b and derivation53151caf hashes are mandatory
CLI pins. Plan00bf9b8c retains all nine original descriptors and adds only stage9.
Current d7e5c61f/ELF41c2afe1/archive4fbebd5e/host0f3 and control1cff are unchanged.

The strict e4124425/d2a7faa7 comparator and its immutable f71d5228 output remain
unchanged. That actual inspection completed, rejected the original comb output
alias/raw-bit difference, passed current15290/seven-pair topology and rehashed
all inputs. This comparator binds its complete flat closure without replaying
that generator, any old authenticator, prepare/run/main or source query. Output
baseline/comparison-prefix-v2.json is separate and exclusive. The strict false
native/gain result is retained explicitly.

The only new allowance is four separately reconstructed named private Q frames:

| Owner | Before Q | After Q | Sole consumer |
| --- | ---: | ---: | --- |
| comb_remap pass_end.E owner |120726|120728|pass_end ALUT5.E|
| decomposition code0 |120728|120730|same decomposition root.C|
| decomposition code1 |120730|120732|same decomposition root.D|
| decomposition root |120732|120734|cmd_end ALUT3.C|

Full literal owner names and consumer slots are pinned in the helper. Each image
must have its typed LUT owner, unique Q driver, sole owner+$Q alias, no public
port use, exact alias metadata, exactly the declared single named consumer and
both literal driver/consumer raw slots. All owner/cell tables, params, attributes,
BELs, full original pin snapshots and port order remain exact. Eight private
slots are the entire original-record allowance; there is no global offset,
numeric normalization, frame mutation or buffer collapse.

New outerALUT4_C$local_remap$2 Q120726 legitimately reuses the old comb private
ID. It must avoid all original nonprivate drivers and the four new private IDs;
every surviving nonprivate alias/slot stays literal. Complete driver/user tables
remove ALL four old private keys before adding ALL four proved new frames and
the new copy, avoiding collisions between distinct named nets. All other users
remain exact except eight declared ENAs and five actual additional LUT inputs.

The new ALUT5 has mask0xbbbbbbb0 and exact five distinct leaves
98308/98312/35614/23880/107546. Thirty-two conditional plain-SIG assignments prove
the original inner0xb/outer0xf0e0, both retained fused functions and new table
agree. Root101074 users87→79; exactly the eight original-root FF ENAs in LAB25.16
move to the new Q on CLK3549. All nine previous literal Qs/cohorts
21/2/10/1/6/1/1/3/2, every other original cell/net/raw slot, export owner order,
paired lossless PLL records, all8221 FF BELs and71 placement metrics remain exact.

The NEW owner's optional site-specific FES snapshot is the sole template-only
metadata exception. If present it must cover ABCDEQ, all SIG, COMBOUT and the
five distinct inputs of its actual BEL half. The actual new snapshot is absent,
so exported physical pin truth is explicitly unproved. Original snapshots and
complete whole-LAB FF records remain strict; the actual MCOMB25.16.7 site adds
its complete original FF neighborhood from the before image.

Current complete15290/seven-pair native endpoint, clock, window and finite-term
checks run separately even on structural rejection; report equality and timing
gain are not required or inherited. Full ninth5966/ea8e is construction-positive
but timing-rejected; accepted fifth6dc at117.771759MHz remains distinct. Every
actual profile/input/runtime/three-output/helper path is bound and rehashed on
success or serialized rejection. Hidden physical caches/GPU IDs, independent
numerical STA, routed physical equivalence, decoded RBF and hardware are unproved.
