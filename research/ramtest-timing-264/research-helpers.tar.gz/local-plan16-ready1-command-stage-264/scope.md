# Tenth-stage predicted qualification

Only ROOT activates this new recorder after complete final-byte/hash/AST and
independent peer review. Prepare requires actual self/scope and completed new
command-guide/derivation SHA arguments; execute requires the resulting exclusive
profile SHA. No future guide, model, placement site, Q bit or gain is guessed.

Structural input is the closed ninth predicted run899a21d8/profileaceefeba and
positive explicit-private-owner prefixd1ee7000. Its strict earlier rejection is
retained in that flat closure. Actual full ninth ea8e5bed/profile788f16d2 and
comparison5966273b prove exported native/physical construction but have rejected
timing. Accepted fifth6dcf8c4b remains the separate117.771759MHz gain reference.
The new guide must preserve the exact full source-index1 FF61.ENA path and all
other report metadata; endpoint cell/port parameters, BELs and raw connections
must also match the actual ninth predicted graph. Guide existing-function truth
does not qualify the prospective tenth copy.

The source stays clean d7e5c61f/baseec0a8d0c with ELF41c2afe1/archive4fbebd5e,
host0f3c11a5 and fresh-eight control1cff85d6. Complete flat proof/input/output,
host dependency and actual runtime paths are bound and rehashed. Runtime equals
the closed ninth invocation literally. The command changes only the remap-plan
selector and two output aliases. RTL/BUILD_ID, options, seed, environment, device,
headers, platform and libraries remain exact. No route, RBF or driver is allowed.

Literal plan9acacb23 retains all nine descriptor values/order/report paths and
appends only the authenticated command-guide at index9: candidate0/groups1,
optimize_pinsfalse/preserveFFtrue. Exactly10 stages remain within cap16. All nine
fresh complete trial records must match the closed ninth records, including
previous rejected trials. The tenth candidate0/application binds its final
actual trial: innerALUT2/outerALUT4_C, primaryLAB25.16, eight ENA users, one group,
zero FF shift, clock/hold/boundary guards1 and gain at least250ps. Site and gain
are recorded only after that fresh qualification.

Preparation derives all eight remaining original-root ENA slots in LAB25.16,
including m1_writedataFF61, with CLK3549 and original root87 users. Nine retained
copy cohorts21/2/10/1/6/1/1/3/2 stay disjoint from the target cohort; their actual
logical records, masks, input/output bits, sites and complete named users match
the current guide inventory. The unused outer4_C$local_remap$2/$Q pair is checked
in all cell/net namespaces. All8221 original FF owners/BELs remain exact. Whole
original FF neighborhoods cover all current cones, copies, cohort primary LABs
and known targetLAB25.16. The fresh tenth site's complete neighborhood awaits
the separately authored actual prefix proof; no pin/LAB state is inherited.

Only pinned ninth51ff54f3 and its current-control/older parsers' pure definitions
are reused for qualification. Lossless32fd and72131/8601 supply native parsing
and tables. No preceding prepare/execute/main/auth/comparison entrypoint is
called. The recorder's own clean-source queries and compiler activation are
ROOT-only. Project FunctionalInvocation and compiler-read audit bind actual
loaded runtime/project scripts; all original inputs and actual three output
files are rehashed on completion. Failure preserves separate partial hashed
outputs and never claims success.

The actual predicted report must retain cap16384/count15290, finite positive
Fmax and one explicit placed-report refresh, with no routing/signoff/driver/RBF
log. A later independent prefix proof must establish the new clone, eight ENAs,
five input load slots,32 conditional rows, retained graph/order/PLL/FF placement
and actual site neighborhood. This recorder proves no native or physical
equivalence, numerical STA, routed timing gain, decoded RBF or hardware result.
