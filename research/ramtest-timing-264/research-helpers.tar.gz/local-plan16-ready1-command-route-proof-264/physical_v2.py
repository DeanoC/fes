"""Pure tenth V2 physical proof with one exact shared-ALM mate pin reassignment."""

CORE_SHA256 = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"
MATE = "hps_ddr.port1.skid_MISTRAL_ALUT3_C_Q_MISTRAL_ALUT3_Q_12"
MATE_BEL = "MISTRAL_MCOMB.25.16.6"
SHARED_ALM = (25, 16, 1)
PHYSICAL_ADDRESS_BIT = {"A": 0, "B": 1, "C": 2, "D": 2, "E0": 3, "E1": 3, "F0": 4, "F1": 4}


def require(value, message):
    if not value:
        raise ValueError(message)


def _ready(core, before, after, ready, profile):
    models = profile["prefix_fresh_local_models"]
    require(len(models) == 10 and ready["inner"] == models[9]["inner"] and ready["outer"] == models[9]["outer"], "tenth physical model differs")
    inner, outer = ready["inner"], ready["outer"]
    retained, second, clone = outer + "$local_remap", outer + "$local_remap$1", ready["new_clone"]
    require(clone == outer + "$local_remap$2" and clone not in before.cells and clone in after.cells and
            after.cells[clone]["attributes"]["NEXTPNR_BEL"] == models[9]["bel"], "additional owner/fresh site differs")
    frames = [(core._shape(view, inner), core._shape(view, outer), core._shape(view, retained), core._shape(view, second))
        for view in (before, after)]
    added = core._shape(after, clone)
    require(all((i["type"], o["type"], r["type"], s["type"], i["tables"], o["tables"], r["tables"], s["tables"]) ==
                ("MISTRAL_ALUT2", "MISTRAL_ALUT4", "MISTRAL_ALUT5", "MISTRAL_ALUT5", [0xb], [0xf0e0], [0xbbbbbbb0], [0xbbbbbbb0])
                for i, o, r, s in frames) and added["type"] == "MISTRAL_ALUT5" and added["tables"] == [0xbbbbbbb0],
            "actual ready1 command original/two retained/new LUT function differs")
    require(all(before.cells[name] == after.cells[name] and before.pins(name) == after.pins(name)
                for name in (inner, outer, retained, second)), "original ready1 command physical state changed")
    boundary = None
    for i, o, r, s in frames:
        token = i["outputs"]["Q"]
        require(sum(entry.get("driver") == token for entry in o["inputs"]) == 1, "outer does not consume exactly one actual inner Q")
        signals = (core._boundary(i) | core._boundary(o)) - {token}
        require(len(signals) == 5 and core._boundary(r) == core._boundary(s) == signals and (boundary is None or signals == boundary), "actual native boundary differs")
        boundary = signals
    require(core._boundary(added) == boundary, "new copy effective native boundary differs")
    boundary, rows = sorted(boundary), []
    for assignment in range(32):
        values = {token: (assignment >> index) & 1 for index, token in enumerate(boundary)}
        outputs = []
        for i, o, r, s in frames:
            with_inner = {**values, i["outputs"]["Q"]: core._read_shape(i, values)}
            outputs.extend((core._read_shape(o, with_inner), core._read_shape(r, values), core._read_shape(s, values)))
        outputs.append(core._read_shape(added, values))
        require(len(set(outputs)) == 1, "actual pin-state/inversion/constant composition differs")
        rows.append({"assignment": assignment, "original_before": outputs[0], "retained_before": outputs[1],
            "second_retained_before": outputs[2], "original_after": outputs[3], "retained_after": outputs[4],
            "second_retained_after": outputs[5], "additional_after": outputs[6]})
    old_root, new_root = frames[0][1]["outputs"]["Q"], frames[1][1]["outputs"]["Q"]
    old_copy, new_copy = frames[0][2]["outputs"]["Q"], frames[1][2]["outputs"]["Q"]
    old_second, new_second = frames[0][3]["outputs"]["Q"], frames[1][3]["outputs"]["Q"]
    output = added["outputs"]["Q"]
    require(old_root == new_root and old_copy == new_copy and old_second == new_second and
            len({old_root, old_copy, old_second, output}) == 4, "original output identities differ")
    declared = ready["declared_ena_redirects"]
    require(type(declared) is list and len(declared) == ready["declared_ena_redirect_count"] == models[9]["ena_users"] == 8 and
            all(row["occurrence"] == row["vector_index"] == 0 and row["port"] == "ENA" for row in declared),
            "eight declared enable schema differs")
    chosen = sorted((row["cell"], "ENA", 0) for row in declared)
    target_bels = {"hps_ddr.m1_address_MISTRAL_FF_Q_15": "MISTRAL_FF.25.16.26",
        "hps_ddr.m1_address_MISTRAL_FF_Q_19": "MISTRAL_FF.25.16.16",
        "hps_ddr.m1_address_MISTRAL_FF_Q_22": "MISTRAL_FF.25.16.52",
        "hps_ddr.m1_address_MISTRAL_FF_Q_4": "MISTRAL_FF.25.16.4",
        "hps_ddr.m1_address_MISTRAL_FF_Q_6": "MISTRAL_FF.25.16.14",
        "hps_ddr.m1_burstcount_MISTRAL_FF_Q": "MISTRAL_FF.25.16.50",
        "hps_ddr.m1_writedata_MISTRAL_FF_Q_20": "MISTRAL_FF.25.16.8",
        "hps_ddr.m1_writedata_MISTRAL_FF_Q_61": "MISTRAL_FF.25.16.46"}
    old_users = before.native.users.get(old_root, [])
    require(len(set(chosen)) == len(chosen) == 8 and {slot[0] for slot in chosen} == set(target_bels) and
            len(old_users) == 87 and all(slot in old_users for slot in chosen) and after.native.users.get(output) == chosen and
            after.native.users.get(new_root) == [slot for slot in old_users if slot not in chosen] and
            len(after.native.users[new_root]) == 79 and len(before.native.users.get(old_copy, [])) == 21 and
            before.native.users[old_copy] == after.native.users.get(new_copy) and len(before.native.users.get(old_second, [])) == 1 and
            before.native.users[old_second] == after.native.users.get(new_second), "root87-to79/retained21+1/new8 partition differs")
    retained_rows = ready["retained_copy_cohorts"]
    require(len(retained_rows) == 9 and len({row["cell"] for row in retained_rows}) == 9 and
            [len(row["consumer_slots"]) for row in retained_rows] == [21, 2, 10, 1, 6, 1, 1, 3, 2], "retained nine-copy inventory differs")
    for row, model in zip(retained_rows, models[:9]):
        name = row["cell"]
        require(all(type(slot) is list and len(slot) == 4 and slot[1:] == ["ENA", 0, 0] for slot in row["consumer_slots"]), "retained scalar ENA slot schema differs")
        slots = [tuple(slot[:3]) for slot in row["consumer_slots"]]
        token = before.scalar(name, "Q", "output")
        require(before.cells[name] == after.cells[name] and before.pins(name) == after.pins(name) and
                before.cells[name]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
                token == after.scalar(name, "Q", "output") and before.native.users.get(token) == after.native.users.get(token) == slots and
                len(slots) == model["ena_users"], "retained copy actual physical/user state differs")
        for ff, port, index in slots:
            require(port == "ENA" and index == 0 and before.cells[ff]["type"] == after.cells[ff]["type"] == "MISTRAL_FF" and
                    before.cells[ff]["connections"]["CLK"] == after.cells[ff]["connections"]["CLK"] == [3549], "retained common-clock cohort differs")
    for ff, port, index in old_users:
        require(port == "ENA" and index == 0 and before.cells[ff]["type"] == after.cells[ff]["type"] == "MISTRAL_FF" and
                before.cells[ff]["connections"]["CLK"] == after.cells[ff]["connections"]["CLK"] == [3549], "original common-clock cohort differs")
    enables = {}
    for ff, port, index in chosen:
        require(before.scalar(ff, "ENA", "input") == old_root and after.scalar(ff, "ENA", "input") == output and
                before.pins(ff) == after.pins(ff) and before.cells[ff]["attributes"]["NEXTPNR_BEL"] ==
                after.cells[ff]["attributes"]["NEXTPNR_BEL"] == target_bels[ff], "actual chosen FF enable/pins/BEL differs")
        enables[ff] = (old_root, output)
    return {"inner": inner, "outer": outer, "retained_copy": retained, "second_retained_copy": second, "new_clone": clone,
        "retained_copies": [row["cell"] for row in retained_rows], "actual_external_native_boundary": [list(token) for token in boundary],
        "actual_truth_rows": rows, "assignments_checked": 32, "physical_pin_states_inversions_constants_and_aliases_evaluated": True,
        "declared_additional_ena_slots": [list(slot) for slot in chosen],
        "original_root_users_before": 87, "original_root_users_after": 79}, enables


def _mate(core, before, after, ready):
    clone = ready["new_clone"]
    require(core._alm_key(before, MATE) == core._alm_key(after, MATE) == core._alm_key(after, clone) == SHARED_ALM and
            before.cells[MATE]["attributes"]["NEXTPNR_BEL"] == after.cells[MATE]["attributes"]["NEXTPNR_BEL"] == MATE_BEL,
            "exact mate/new copy shared ALM differs")
    shapes, banks = [], []
    for view, physical_c in ((before, "F0"), (after, "A")):
        cell = view.cells[MATE]
        require(cell["type"] == "MISTRAL_ALUT3" and cell["parameters"] == {"LUT": "11001010"} and
                cell["connections"] == {"Q": [101789], "C": [35614], "B": [108960], "A": [36027]} and
                view.pins(MATE) == {"A": [0, "C"], "B": [0, "E0"], "C": [0, physical_c], "Q": [0, "COMBOUT"]},
                "mate has other native/function/pin changes")
        shape, bank = core._shape(view, MATE), core.evaluate_lut(view, MATE)
        require(shape["type"] == "MISTRAL_ALUT3" and shape["tables"] == [0xca] and shape["half"] == 0 and
                all("driver" in entry and entry["state"] == 0 for entry in shape["inputs"]) and
                bank["alm"]["alm"] == list(SHARED_ALM) and bank["alm"]["is_mlab_capable_logic"] is True and
                bank["lut"]["physical_bank"]["physical_rows_derived"] == bank["lut"]["physical_bank"]["alias_consistent_rows_checked"] == 32,
                "actual ordinary mate bank/MLAB state differs")
        shapes.append(shape); banks.append(bank)
    boundary = sorted(core._boundary(shapes[0]))
    require(len(boundary) == 3 and core._boundary(shapes[1]) == set(boundary) and
            shapes[0]["outputs"]["Q"] == shapes[1]["outputs"]["Q"] and
            before.native.users.get(shapes[0]["outputs"]["Q"]) == after.native.users.get(shapes[1]["outputs"]["Q"]),
            "mate's distinct native inputs/output/user identity differs")
    require(len(core.MLAB_PERMUTE) == 64 and set(core.MLAB_PERMUTE) == set(range(64)), "MLAB logic permutation is not bijective")
    rows = []
    for assignment in range(8):
        values = {token: (assignment >> index) & 1 for index, token in enumerate(boundary)}
        actual_values, physical_rows = [], []
        for shape, bank in zip(shapes, banks):
            image = int(bank["lut"]["physical_bank"]["active_low_mask_hex"], 16)
            pre = int(bank["alm"]["derived_active_low_64_mask_before_mlab_permutation_hex"], 16)
            post = int(bank["alm"]["derived_active_low_64_mask_after_mlab_permutation_hex"], 16)
            require(0 <= image < (1 << 32) and 0 <= pre < (1 << 64) and 0 <= post < (1 << 64), "actual mate storage masks overflow")
            matches, outputs = [], set()
            for address in range(32):
                if not all((1 ^ ((address >> PHYSICAL_ADDRESS_BIT[entry["physical"][0]]) & 1)) == values[entry["driver"]]
                        for entry in shape["inputs"]): continue
                expected = core._read_shape(shape, values)
                stored = (image >> address) & 1
                require(stored == ((pre >> address) & 1) == ((post >> core.MLAB_PERMUTE[address]) & 1),
                        "mate occupied bank differs from whole MCOMB image/permutation")
                value = 1 ^ stored
                require(value == expected, "mate actual physical row differs from its native pin-state function")
                matches.append(address); outputs.add(value)
            require(len(matches) == 4 and len(outputs) == 1, "mate assignment lacks all four physical rows for unused input bits")
            actual_values.append(next(iter(outputs))); physical_rows.append(matches)
        require(actual_values[0] == actual_values[1], "mate function changed under exact F0-to-A reassignment")
        rows.append({"assignment": assignment, "value": actual_values[0],
            "before_matching_physical_rows": physical_rows[0], "after_matching_physical_rows": physical_rows[1]})
    old_alm, new_alm = banks[0]["alm"], banks[1]["alm"]
    require({row["cell"] for row in old_alm["occupied_banks"]} == {MATE} and
            {row["cell"] for row in new_alm["occupied_banks"]} == {MATE, clone} and
            after.pins(clone).get("C") == [0, "A"] and
            after.scalar(MATE, "C", "input") == after.scalar(clone, "C", "input") and
            new_alm["physical_input_native_drivers"].get("A") == list(after.scalar(MATE, "C", "input")),
            "actual shared A does not bind the same mate/new-copy native driver")
    return {"cell": MATE, "bel": MATE_BEL, "shared_alm": list(SHARED_ALM), "assignments_checked": 8,
        "actual_external_native_boundary": [list(token) for token in boundary], "actual_truth_rows": rows,
        "before": banks[0], "after": banks[1], "only_reassigned_logical_pin": "C", "before_physical_pin": "F0", "after_physical_pin": "A",
        "actual_bank_active_low_and_mlab_permutation_checked": True, "whole_shared_alm_input_driver_legality_evaluated": True,
        "shared_a_native_driver": list(after.scalar(MATE, "C", "input")), "other_original_metadata_or_pin_exception_allowed": False}


def evaluate(core, before_doc, after_doc, logical_ledger, profile, driver_trial):
    """Caller authenticates core bytes and all inputs; no file/import/STA operations."""
    require(set(logical_ledger) == {"ready", "driver", "buffer_rows", "private_output_rows"}, "physical ledger contract differs")
    before, after = core.PhysicalView(before_doc["modules"]["top"]), core.PhysicalView(after_doc["modules"]["top"])
    require(before.device == after.device and before.labs == after.labs, "whole original LAB geometry/modes/selectors snapshot differs")
    ready, enables = _ready(core, before, after, logical_ledger["ready"], profile)
    mate = _mate(core, before, after, ready)
    driver = core._driver_proof(before, after, logical_ledger["driver"], driver_trial)
    private_names = [row["owner"] for row in logical_ledger["private_output_rows"]]
    require(len(private_names) == len(set(private_names)) == 4, "four private physical owner identities differ")
    private = []
    for name in private_names:
        a, b = core.evaluate_lut(before, name), core.evaluate_lut(after, name)
        require(a["lut"] == b["lut"], "original private owner physical bank/function/pins differs")
        private.append({"owner": name, "before": a, "after": b})
    names = {ready["inner"], ready["outer"], ready["retained_copy"], ready["second_retained_copy"], ready["new_clone"], *ready["retained_copies"],
        driver["source"], driver["clone"], driver["sink"], driver["successor"], MATE, *private_names}
    labs = {tuple(key) for key in profile["affected_whole_labs"]}
    for view in (before, after): labs.update(core._alm_key(view, name)[:2] for name in names if name in view.cells)
    require(all(key in before.labs and key in after.labs for key in labs), "declared physical LAB absent")
    original_ffs = sorted(name for name, cell in before.cells.items() if cell["type"] == "MISTRAL_FF" and core._alm_key(before, name)[:2] in labs)
    require(set(original_ffs) == {name for name, cell in after.cells.items() if cell["type"] == "MISTRAL_FF" and core._alm_key(after, name)[:2] in labs} and
            {row["cell"] for row in profile["all_original_ff_members_in_affected_labs"]} <= set(original_ffs), "whole-LAB original FF closure differs")
    ff_rows = [core._ff_pair(before, after, name, enables) for name in original_ffs]
    banks, alms = 0, []
    for lab in sorted(labs):
        for index in range(10):
            key = (*lab, index)
            a, b = core.evaluate_alm(before, key), core.evaluate_alm(after, key)
            old = {row["cell"]: row for row in a["occupied_banks"] if row["cell"] not in {driver["clone"], MATE}}
            new = {row["cell"]: row for row in b["occupied_banks"] if row["cell"] not in {driver["clone"], ready["new_clone"], MATE}}
            require(old == new, "original occupied ALM bank/function/shared pins changed")
            banks += len(old)
            alms.append({"alm": list(key), "before": a, "after": b})
    buffers = core._buffer_proof(before, after, logical_ledger["buffer_rows"], enables)
    return {"schema": 1, "physical_scope_proved": True, "pinned_pure_core_sha256": CORE_SHA256,
        "actual_exported_physical_function_scope_proved": True, "additional_ready1_command_copy": ready,
        "per_frame_lut_driver_copy_and_immediate_carry": driver, "private_output_owner_banks": private,
        "independently_proved_shared_alm_mate": mate,
        "whole_labs_including_actual_old_and_new_driver_sites": [list(key) for key in sorted(labs)],
        "whole_lab_ff_control_rows": ff_rows, "whole_lab_alm_rows": alms, "unchanged_original_occupied_banks_checked": banks, "independently_proved_mate_occupied_banks": 1,
        "original_occupied_banks_proved": banks + 1,
        "complete_lab_snapshot_exact": True, "explicit_existing_buffer_scope": buffers,
        "unexported_comb_cache_and_gpu_ids_proved": False, "physical_route_muxes_or_pips_independently_decoded": False,
        "cram_bytes_or_rbf_independently_decoded": False, "independent_numerical_sta_proved": False,
        "routed_gain_accepted": False, "hardware_tested": False}


