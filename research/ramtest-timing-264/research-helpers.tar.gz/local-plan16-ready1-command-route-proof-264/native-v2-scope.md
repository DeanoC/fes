# Exact shared-ALM mate pin reassignment

This NEW pure native proof preserves strict native_scope.py and rejected output
fffb82ee. Caller binds actual tenth full1a6d4f7b/profileea033985/prefixbf9d312c,
the strict output/bytes, and this new helper/scope. No old prove/evaluate,
authenticator, generator, main or source query is executed.

The sole added allowance is exactly
hps_ddr.port1.skid_MISTRAL_ALUT3_C_Q_MISTRAL_ALUT3_Q_12 at MCOMB25.16.6: ALUT3
mask0xca, Q101789/A36027/B108960/C35614 and complete native record unchanged
except the observed FES_PINMAP hex payload. Both exact payloads are pinned and
decoded with duplicate/nonfinite rejection. Both count4 snapshots require
plain-SIG A→C, B→E0 and Q→COMBOUT. Only logical C changes from SIG F0 to SIG A.
Every other mate attribute, type, mask, connection, BEL and port order stays exact.
This typed exception alone claims no physical equivalence; physical_v2 must
independently prove all eight native-driver assignments and shared ALM legality.

All strict policies remain: same-compiler creator and complete LAB snapshot,
settings/public ports/order/paired PLL, nine retained literal copies/cohorts,
8221 original FFs, one new ALUT5/eight ENAs/five loads/root87→79/32 logical rows,
four private output frames, requalified driver frame and5232 named BUF frames.
No other original FES pin attribute may differ. All old frame keys are removed
together before independently derived new keys; complete raw drivers/users and
every undeclared native slot remain exact. Only ordinary ROUTING net attributes
are omitted from semantic equality; route/RBF bytes remain authenticated.

prove keeps the strict signature and returns the same four-key physical ledger.
mate_pin_change_row plus evidence.exact_mate_pin_assignment_exception records
the one actual pair; it adds no generic tolerance or alternate graph model.
Timing remains separate and identical to the rejected strict inspection.
Unexported caches, numerical STA, pip/CRAM/RBF decoding and hardware are unproved.
