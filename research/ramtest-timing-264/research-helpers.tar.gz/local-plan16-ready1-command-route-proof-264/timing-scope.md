# Tenth-stage current-window timing gate

evaluate(core, complete_document, report, accepted_fifth_report,
own_tenth_predicted_report, log, record) returns actual reported timing and a
timing-only decision. The complete lossless document with modules.top is required.
Pinned e6ce77b7 contributes only lower _load/_paths; its old evaluate is never
called. Pinned 72131/8601 check every current report arc and registered clock
against that native document and the current tenth predicted report.

The accepted timing reference is exactly the positive fifth full route 6dcf/5ed3:
117.77175903320312/93.6504898071289/259.49139404296875 MHz. Ninth 5966/ea8e is
construction provenance and cannot supply a timing threshold or borrowed delays.
Memory must strictly exceed 117.77175903320312 MHz. Pixel and capture must meet
their exact constraints, and all three reported constraints remain exactly
130.0052032470703/74.25006866455078/130.0052032470703 MHz.

The current routed report, accepted fifth report and own tenth predicted report
must have cap 16384, exactly 15290 unique domain-pair endpoints, seven actual
domain pairs and identical positive finite windows. Each finite emitted term is
summed with math.fsum. Capture's actual 5 ns window and the memory half-cycle
3.8459999561309814 ns window stay exact. All six non-target worst headrooms must
be strictly positive. Target 130 MHz closure is reported separately from the
confirmed gain rule: reported_window_met never treats its negative margin as
closed. All-clock nonregression and every before/after headroom remain explicit
diagnostics; lower positive headroom is allowed and disclosed.

Only the LAST RBF signoff block supplies hold status. Literal hold violation and
broader hold/min warning/negative lines both reject timing acceptance. The actual
recorder's Fmax, literal hold flag and warning lines must match exactly. Pinned
board _require_gpu_backend, HIP completion and normal exit reject fallback; the
recorder's actual_live_gpu_backend must also be exactly hip. Board's direct
source_repository 29ab5ad5 and lockfile 742d5b39 bytes and loaded paths are checked
before/after import and returned in the dependency evidence.

The caller must bind this pair, every lower module/dependency, complete reports,
native document, log, actual completed record and runtime to its own flat closure,
then rehash original paths even if structural proof rejects. This pure timing
helper has no CLI, does not authenticate or execute a parent generator, and makes
no graph/physical acceptance claim. Independent numerical STA, unseen phase or
extrema reconstruction, analogue calibration, decoded RBF, cache/GPU identity
and hardware acceptance remain unproved. Native and physical proofs remain
separately mandatory before overall candidate acceptance.
