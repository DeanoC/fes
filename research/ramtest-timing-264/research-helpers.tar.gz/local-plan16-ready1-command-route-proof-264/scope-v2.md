# Explicit paired-half pin inspection

This NEW wrapper writes only exclusive comparison-v2.json. Strict compare_route.py
53169c51, scope f1c997a8, its six companion files and comparison.json fffb82ee
remain unchanged. The strict record rejected the named original mate
hps_ddr.port1.skid_MISTRAL_ALUT3_C_Q_MISTRAL_ALUT3_Q_12 and proved neither native
nor physical scope. Those false results and its exact rejection are preserved as
explicit provenance; no earlier acceptance is substituted.

Activation requires actual self/scope/native-v2/physical-v2 file hashes, immutable
timing 859052ff/5bbb3d7c, strict fffb82ee and actual completed full run
1a6d4f7b/profile ea033985/positive prefix bf9d312c. Every strict artifact/runtime
entry is adopted as a flat hash ledger, without invoking its generator or any
older authentication/acceptance entrypoint. All current profile/runtime/output
checks and final original-path rehash remain unchanged, including on serialized
structural failure. The original strict output is never overwritten.

Only the separately reviewed new native/physical helpers may admit the actual
one-field mate snapshot change at MCOMB25.16.6: C[0,F0] becomes C[0,A], beside
the new odd-half copy at25.16.7. A[0,C], B[0,E0], Q[0,COMBOUT], the ALUT3 table,
connections, BEL and all other original attributes/pins remain exact. The native
helper must expose this precise image-local pin record. The physical helper
independently evaluates all eight actual mate input assignments in both frames,
its shared ALM with the new copy, and every other occupied bank/FF/control in the
affected whole LAB closure. There is no blanket pin or LAB waiver.

The prior explicit four private owners, driver frame and5232 named buffer frames
are independently reconstructed from these same actual images. Nine retained
copy cohorts, eight equivalent ENA redirects, five new input loads, paired PLLs,
all8221 FFs, raw slots outside named ledgers, owner order and71 placement metrics
remain strict. New pin functions, inversions/constants, active-low banks and
sharing are proved from exported snapshots rather than inherited prefix truth.

The existing current timing.evaluate is intentionally called again on unchanged
current inputs, then compared canonically with the strict record's timing
diagnostic. Its old e6ce acceptance evaluate is never called. All15290 endpoints,
seven pairs and exact windows/constraints use accepted five6dcf/5ed3 as timing
reference, requiring memory strictly above117.77175903320312 MHz and all six
non-target headrooms positive, pixel/capture constraints and zero LAST holds.
Ninth5966/ea8e remains native/physical construction provenance only. Target130MHz,
all-clock nonregression and headroom changes stay separate diagnostics. Current
116.808784 MHz is not an accepted gain.

ROOT alone performs whole-file/hash/AST review and execution after independent
cross-peer review. The wrapper does not run a compiler, route, test or parent
generator. Exported-state proof does not establish hidden cache/GPU identity,
decoded routing/CRAM/RBF, independent numerical STA, analogue calibration or
hardware acceptance. Only current joint native/physical/timing success could
accept a candidate; this narrower structural scope cannot relax timing.
