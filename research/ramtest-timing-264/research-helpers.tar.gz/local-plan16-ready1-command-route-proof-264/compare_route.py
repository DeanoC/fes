"""Authenticate and independently inspect the tenth ready1 command full route."""
import argparse
import builtins
import hashlib
import importlib.util
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
ROUTE = RAW / "local-plan16-ready1-command-route-264"
PREFIX = RAW / "local-plan16-ready1-command-stage-264"
PARENT = RAW / "local-multicopy-ready1-address-route-264/route-c0"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
PARENT_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
BEFORE = RAW / "local-plan16-ready1-skid-byte-route-264/route-c0"
CONSTRUCTION = RAW / "local-plan16-ready1-skid-byte-route-proof-264/comparison.json"
CONSTRUCTION_SHA = "5966273babe8b4405ce23571d30cc9b7e342fbdd062272ac4b575df54596b95a"
CONSTRUCTION_RUN_SHA = "ea8e5bed840dc8ec53c077b669fc2cc2cc3a8081afd27476695be1bd675f9ba5"
CONSTRUCTION_PROFILE_SHA = "788f16d21d128edbf0ffce4fb32b63db6e47135cf9faa5686d084d6fd4aa780d"
PROFILE_SHA = "ea03398546c1a1c8f9f099d0ed6ce4b156661d3276e0ec2057c7f09e563fe305"
RUNNER_SHA = "3aa1a8cf7b5ef636d4900f1ddc0b7cc9883fd67828a394812542b8c00288648e"
RUNNER_SCOPE_SHA = "b0f52c6163e16dae1e8095df7fe407baf0b1bf054956b66ed04eb8546ece21f2"
PREFIX_SHA = "bf9d312c140f349f75244c087be5a90f59c6fb6a87d28437051936f178884fe3"
PREFIX_PROFILE_SHA = "77fd5636a7947d349605147bc164ba7cf562dc5885aa09072a1cc2945931e546"
PREFIX_RUN_SHA = "3d69a28a7fb1741349f1b4e77be6f13bbdae21dfeb4bacd77ef5f5862059ad11"
PREFIX_GENERATOR_SHA = "adcf038706860a70fa8d11d54d2d37eeb09a35c426ed84ac6776f7bf22c3d130"
PREFIX_SCOPE_SHA = "e2059c34f1f0a9228f4d51d02dffb1c55c3e004661d571f8bd661b983f6692d0"
STRICT_SHA = "f71d52283200fdee82b4176bda3c0bcc134174bb9b28e7007e5bda6f7864a5af"
CONTROL_SHA = "1cff85d6656ba2afe90c89ee5a7e37a68bfa72f9592c273e4396a672520f268f"
HOST_SHA = "0f3c11a523ca7981b5d3e373c10d67d0ade5bf5cac9212e02e0186d6368b438c"
COMMIT, BASE = "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f", "ec0a8d0cc56f0915e985ca7d1528daab1450c00d"
BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
ARCHIVE_SHA = "4fbebd5e7ddd47738f5218fae88824292d904841e89fa11375866c7f50fafedb"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PHYSICAL_CORE = RAW / "local-multicopy-ready1-address-route-proof-264/physical.py"
PHYSICAL_CORE_SHA = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"
PHYSICAL_CORE_SCOPE_SHA = "976c13d6111f7bda5c7cfdc49df5089e23af4969b3294c12dee2a392dc46790a"
TIMING_CORE = RAW / "driver-copy-ready-groups8-proof-264/timing.py"
TIMING_CORE_SHA = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
TIMING_CORE_SCOPE_SHA = "5088a952653ccd349edb109bd68e038cace200c911ec7707cef1d958897d8032"


def require(value, message):
    if not value: raise ValueError(message)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def adopt(audit, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        audit.bind(Path(name), expected, execution=True)


def comparison(args):
    require(args.prefix_sha256 == PREFIX_SHA and args.profile_sha256 == PROFILE_SHA and
            re.fullmatch(r"[0-9a-f]{64}", args.run_sha256) and args.run_sha256 != "0" * 64 and not (HERE / "comparison.json").exists(),
            "actual positive prefix/prepared profile/closed full run and exclusive output required")
    native = load(PURE, PURE_SHA, "tenth_command_full_native_parser")
    audit = native.Audit()
    pins = ((PURE, PURE_SHA), (Path(__file__).resolve(), args.self_sha256), (HERE / "scope.md", args.scope_sha256),
        (HERE / "native_scope.py", args.native_sha256), (HERE / "native-scope.md", args.native_scope_sha256),
        (HERE / "physical.py", args.physical_sha256), (HERE / "physical-scope.md", args.physical_scope_sha256),
        (HERE / "timing.py", args.timing_sha256), (HERE / "timing-scope.md", args.timing_scope_sha256),
        (ROUTE / "source-identity.json", args.profile_sha256), (ROUTE / "run_route.py", RUNNER_SHA), (ROUTE / "scope.md", RUNNER_SCOPE_SHA),
        (ROUTE / "route-c0/run.json", args.run_sha256), (PREFIX / "baseline/comparison-prefix-v2.json", args.prefix_sha256),
        (PREFIX / "compare_prefix_v2.py", PREFIX_GENERATOR_SHA), (PREFIX / "prefix-v2-scope.md", PREFIX_SCOPE_SHA),
        (PREFIX / "baseline/comparison-prefix.json", STRICT_SHA), (PREFIX / "source-identity.json", PREFIX_PROFILE_SHA),
        (PREFIX / "baseline/run.json", PREFIX_RUN_SHA), (ACCEPTED, ACCEPTED_SHA), (PARENT / "run.json", PARENT_RUN_SHA),
        (CONSTRUCTION, CONSTRUCTION_SHA), (BEFORE / "run.json", CONSTRUCTION_RUN_SHA),
        (BEFORE.parent / "source-identity.json", CONSTRUCTION_PROFILE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA),
        (PHYSICAL_CORE, PHYSICAL_CORE_SHA), (PHYSICAL_CORE.parent / "physical-scope.md", PHYSICAL_CORE_SCOPE_SHA),
        (TIMING_CORE, TIMING_CORE_SHA), (TIMING_CORE.parent / "timing-scope.md", TIMING_CORE_SCOPE_SHA))
    for path, expected in pins: audit.bind(path, expected)
    profile, record = native.read(ROUTE / "source-identity.json"), native.read(ROUTE / "route-c0/run.json")
    prefix, parent, construction = (native.read(path) for path in (PREFIX / "baseline/comparison-prefix-v2.json", ACCEPTED, CONSTRUCTION))
    for manifest in (prefix, parent, construction): adopt(audit, manifest)
    require(prefix["phase"] == "local-plan16-ready1-command-tenth-stage-explicit-private-owner-native-prefix" and
            prefix["generator_sha256"] == PREFIX_GENERATOR_SHA and prefix["scope_sha256"] == PREFIX_SCOPE_SHA and
            prefix["source_identity_sha256"] == PREFIX_PROFILE_SHA and prefix["current_baseline_run_sha256"] == PREFIX_RUN_SHA and
            prefix["compiler_commit"] == COMMIT and prefix["immutable_strict_prefix_rejection_sha256"] == STRICT_SHA and
            prefix["structural_rejection"] is prefix["native_path_topology_rejection"] is None and
            all(prefix[key] is True for key in ("native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
                "all_nine_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "private_output_frame_alignment_used",
                "final_original_path_metadata_and_runtime_hashes_stable")), "actual V2 prefix prerequisite differs")
    require(parent["structural_rejection"] is None and parent["native_graph_proof_available"] is parent["physical_scope_proved"] is
            parent["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and parent["current_full_run_sha256"] == PARENT_RUN_SHA and
            construction["structural_rejection"] is None and construction["native_graph_proof_available"] is construction["physical_scope_proved"] is True and
            construction["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and construction["current_full_run_sha256"] == CONSTRUCTION_RUN_SHA and
            construction["source_identity_sha256"] == CONSTRUCTION_PROFILE_SHA and construction["accepted_full_proof_sha256"] == ACCEPTED_SHA,
            "current ninth structural construction versus accepted fifth timing roles differ")
    require(profile["phase"] == "local-plan16-ready1-command-tenth-stage-fresh-driver-full-route" and
            profile["prefix_proof_sha256"] == PREFIX_SHA and profile["prefix_baseline_run_sha256"] == PREFIX_RUN_SHA and
            profile["prefix_source_identity_sha256"] == PREFIX_PROFILE_SHA and profile["prefix_generator_sha256"] == PREFIX_GENERATOR_SHA and
            profile["prefix_scope_sha256"] == PREFIX_SCOPE_SHA and profile["immutable_strict_prefix_rejection_sha256"] == STRICT_SHA and
            profile["control_proof_sha256"] == CONTROL_SHA and profile["host_validation_sha256"] == HOST_SHA and
            profile["accepted_full_proof_sha256"] == ACCEPTED_SHA and profile["accepted_full_run_sha256"] == PARENT_RUN_SHA and
            profile["experimental_ninth_full_proof_sha256"] == CONSTRUCTION_SHA and profile["experimental_ninth_full_run_sha256"] == CONSTRUCTION_RUN_SHA and
            profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and
            profile["source_archive_sha256"] == ARCHIVE_SHA and profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            profile["minimum_accepted_memory_mhz"] == 117.77175903320312 and len(profile["prefix_fresh_local_models"]) == 10,
            "prepared tenth profile/compiler/source/proof roles differ")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    for key, value in profile.items():
        if key != "input_sha256": require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["source_identity_sha256"] == args.profile_sha256 and record["completed"] is True and record["exit_code"] == 0 and
            record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): args.profile_sha256} and
            record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip", "actual completed run/profile/runtime differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is outside frozen input closure")
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(ROUTE / "route-c0" / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")},
            "complete actual output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output empty")
        audit.bind(Path(name), expected)
    runner = load(ROUTE / "run_route.py", RUNNER_SHA, "tenth_command_full_record_definitions")
    tenth, ninth, control, local, parent_defs, driver_defs = runner.definitions()
    for path, expected in ((PREFIX / "run_baseline.py", runner.TENTH_SHA), (PREFIX / "scope.md", runner.TENTH_SCOPE_SHA),
            (runner.PARENT_HELPER, runner.PARENT_HELPER_SHA), (runner.PARENT_HELPER.parent / "scope.md", runner.PARENT_SCOPE_SHA),
            (runner.DRIVER, runner.DRIVER_SHA), (runner.DRIVER.parent / "scope.md", runner.DRIVER_SCOPE_SHA), *control.PARSERS):
        require(audit.paths.get(path) == expected, "executed pure parser is outside closure")
    for name, expected in control.SCRIPTS.items(): audit.bind(ROOT / "sources/misteross/scripts" / name, expected)
    require(audit.paths.get(tenth.HOST) == HOST_SHA and audit.paths.get(tenth.BINARY) == BINARY_SHA and
            audit.paths.get(tenth.ARCHIVE) == ARCHIVE_SHA, "current host/binary/archive outside flat closure")
    control.host_valid(native.read(tenth.HOST), HOST_SHA)
    baseline, template, accepted_run = (native.read(path) for path in (PREFIX / "baseline/run.json", BEFORE / "run.json", PARENT / "run.json"))
    require(baseline["completed"] is template["completed"] is accepted_run["completed"] is True and
            baseline["compiler_commit"] == template["compiler_commit"] == COMMIT and
            record["command"] == runner.command(baseline, template, tenth) and
            baseline["execution"] == record["execution"] == template["execution"] == control.expected_execution(accepted_run) and
            record["cwd"] == baseline["cwd"] == template["cwd"] == accepted_run["cwd"] and record["diagnostic_environment"] ==
            baseline["diagnostic_environment"] == template["diagnostic_environment"] == accepted_run["diagnostic_environment"],
            "actual tenth/ninth runtime and accepted compiler/PATH frame differs")
    log = (ROUTE / "route-c0/route.log").read_text()
    trial, models = driver_defs.qualification(log), tenth.qualification(log, ninth, control, local)
    require(native.canonical(trial) == native.canonical(record["actual_fresh_driver_qualification"]) and trial["domain_summary"] == ["334", "331", "3", "331", "1"] and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) == native.canonical(profile["prefix_fresh_local_models"]) ==
            native.canonical(prefix["fresh_local_models"]) and native.canonical(models[:9]) == native.canonical(template["actual_selected_local_qualification"]),
            "actual guarded tenth/nine-retained/fresh-driver qualification differs")
    metrics = native.PLACEMENT_METRICS.findall(log)
    placement_exact = len(metrics) == 71 and metrics == native.PLACEMENT_METRICS.findall((PREFIX / "baseline/phase.log").read_text())
    before, after = native.read_netlist(BEFORE / "routed.json"), native.read_netlist(ROUTE / "route-c0/routed.json")
    predicted = native.read_netlist(PREFIX / "baseline/placed.json")
    report, parent_report, predicted_report = (native.read(path) for path in (ROUTE / "route-c0/timing.json", PARENT / "timing.json", PREFIX / "baseline/timing.json"))
    timing_core = load(TIMING_CORE, TIMING_CORE_SHA, "tenth_command_full_timing_lower_definitions")
    timing = load(HERE / "timing.py", args.timing_sha256, "tenth_command_full_current_timing_gate")
    timing_result = timing.evaluate(timing_core, after, report, parent_report, predicted_report, log, record)
    for name, expected in timing_result["evidence"]["pinned_pure_module_sha256"].items():
        require(audit.paths.get(Path(name)) == expected, "timing imported dependency is unauthenticated")
    frozen = load(FREEZE, FREEZE_SHA, "tenth_command_full_freeze_definitions")
    selected = load(SELECTED, SELECTED_SHA, "tenth_command_full_native_tables", frozen)
    proof = load(HERE / "native_scope.py", args.native_sha256, "tenth_command_full_named_slot_proof")
    physical_core = load(PHYSICAL_CORE, PHYSICAL_CORE_SHA, "tenth_command_full_physical_lower_definitions")
    physical = load(HERE / "physical.py", args.physical_sha256, "tenth_command_full_current_physical_proof")
    graph, physical_evidence, rejection = None, None, None
    try:
        require(after["creator"] == predicted["creator"] and placement_exact, "current compiler creator/original placement sequence differs")
        graph = proof.prove(native, selected, before, after, prefix["native_graph_evidence"], profile, trial)
        ledger = {key: graph[key] for key in ("ready", "driver", "buffer_rows", "private_output_rows")}
        physical_evidence = physical.evaluate(physical_core, before, after, ledger, profile, trial)
        require(physical_evidence["physical_scope_proved"] is True, "independent physical scope did not pass")
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        rejection = str(error)
    audit.finish()
    passed = rejection is None and timing_result["passes_practical_timing_gate"]
    return {"schema": 1, "phase": "local-plan16-ready1-command-tenth-stage-full-route-inspection", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "source_identity_sha256": args.profile_sha256, "current_full_run_sha256": args.run_sha256,
        "prefix_proof_sha256": args.prefix_sha256, "accepted_full_proof_sha256": ACCEPTED_SHA,
        "structural_before_full_proof_sha256": CONSTRUCTION_SHA, "structural_before_full_run_sha256": CONSTRUCTION_RUN_SHA,
        "structural_before_timing_gain_accepted": False, "immutable_strict_prefix_rejection_sha256": STRICT_SHA,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256, "native_helper_sha256": args.native_sha256,
        "native_scope_sha256": args.native_scope_sha256, "physical_helper_sha256": args.physical_sha256,
        "physical_scope_sha256": args.physical_scope_sha256, "timing_helper_sha256": args.timing_sha256, "timing_scope_sha256": args.timing_scope_sha256,
        "candidate_completed": True, "structural_rejection": rejection, "native_graph_proof_available": graph is not None,
        "physical_scope_proved": physical_evidence is not None and rejection is None, "native_graph_evidence": graph,
        "physical_evidence": physical_evidence, "timing": timing_result, "routed_gain_accepted_under_confirmed_target_clock_rule": passed,
        "all_71_placement_metrics_exact": placement_exact, "actual_fresh_driver_qualification": trial, "fresh_local_models": models,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True, "independent_numerical_sta_proved": False,
        "rbf_decoded_or_hardware_tested": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "native-sha256", "native-scope-sha256", "physical-sha256", "physical-scope-sha256",
            "timing-sha256", "timing-scope-sha256", "prefix-sha256", "run-sha256", "profile-sha256"):
        parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    import json
    with (HERE / "comparison.json").open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_graph_proof_available",
        "physical_scope_proved", "routed_gain_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__": main()
