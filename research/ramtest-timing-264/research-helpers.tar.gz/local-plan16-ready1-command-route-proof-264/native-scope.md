# Tenth routed native scope

prove(native,selected,before_doc,after_doc,ready,profile,trial) is pure: no reads,
imports, input mutation or source queries. Structural before is the actual ninth
full ea8e5bed with native/physical-positive but timing-rejected proof5966273b.
Both images use current d7e5c61f, so creator strings must match exactly. Module
settings, attributes including complete LAB snapshots, public ports, owner/net
order and lossless paired PLL records remain exact. One outerALUT4_C$local_remap$2
ALUT5 and sole private alias are added:20139→20140 cells/21877→21878 netnames.

Actual inner0xb/outer0xf0e0/two retained fused0xbbbbbbb0/new0xbbbbbbb0 tables use
the same five distinct native leaves98308/98312/35614/23880/107546. Thirty-two
conditional plain-SIG rows independently compare original, both retained and
new functions. Original root101074 users87→79; exactly eight bound FF ENAs in
LAB25.16 redirect. All nine prior literal Q/cohorts21/2/10/1/6/1/1/3/2 remain
exact, including the retained21-user and one-user fused copies. All8221 original
FF owners, placement, controls and original pin metadata remain exact apart
from the eight explicitly equivalent ENA inputs proved separately in physical.

Each image independently reconstructs four named generated private output Qs,
the freshly requalified driver Q and all5232 existing late-buffer Qs. Each frame
has its unique native driver, sole literal private alias, no public boundary and
complete unchanged named consumer slots. Buffers retain exact A/raw driver and
the same unique FF DATAIN. All old driver keys are removed together before all
new frame keys/new copy are added, preventing numeric overlap from conflating
different owners. No inherited raw pairs, global translation or BUF collapse is
used. Entire raw driver/user tables and per-cell slots are compared; only those
named frames, eight ENAs and five additional input loads may differ.

The original burst source retains48 consumers and its copy has the sole selected
arithmetic A operand. Both image ALUT3 functions/masks/inputs are checked over
eight rows. CO has only the same immediate CI successor. Only the requalified
driver's actual BEL and complete FES pin snapshot may change; the physical
helper must independently prove both sites and their whole original neighbors.
All original copy/BEL/LUT/pin/port metadata and aliases remain strict. Ordinary
net ROUTING is omitted only from semantic equality; actual output/RBF bytes stay
authenticated. This module claims no physical truth, pip decode, numerical STA,
cache/GPU-ID equality or hardware acceptance.
