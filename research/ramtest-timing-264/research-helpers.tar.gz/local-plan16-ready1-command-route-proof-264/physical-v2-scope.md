# Independent mate function and whole shared ALM

This NEW physical helper preserves strict physical.py and rejected strict output
fffb82ee. evaluate keeps the six-argument API and exact four-key native ledger.
Caller authenticates this pair and pinned60ca4442 lower definitions; no old
evaluate/_ready_proof, authenticator, validator or generator is called. Actual
structural before is ninth ea8e5bed; current is tenth1a6d4f7b, independently of
the accepted fifth timing reference.

The exact named ALUT3 mate at MCOMB25.16.6 must retain mask0xca and all native
Q/A/B/C connections. Actual before pins A→C/B→E0/C→F0 and actual after pins
A→C/B→E0/C→A are plain SIG with Q→COMBOUT. Both effective boundaries must be
the same three distinct native drivers and output/user identity unchanged.
All eight independent driver assignments are checked in both images.

For each assignment the helper reads every matching row of each derived32-row
active-low physical bank, covering the four combinations of unused physical
inputs. Outputs must be uniform and agree with the native pin-state function
and each other. The same stored bit must appear in the whole64-row occupied
MCOMB image before permutation and at its exact bijective final MLAB logic
permutation position. This proves the changed exported physical assignments
implement the same function, without claiming independently decoded CRAM bits.

The entire ALM25.16.1 is independently evaluated in both images. Before it must
contain only the mate combinational bank; after it contains exactly mate plus
new odd-half ALUT5$local_remap$2. The actual shared A must resolve to precisely
the same native driver for mate.C and new-copy.C. Lower evaluate_alm checks
storage/modes, both occupied halves, shared A/B identities, physical tables,
FF occupancy and controls. The new ALUT5 still independently passes all32 rows.

Only this one already proved mate is removed from old/new occupied-bank strict
fingerprint equality. All other original banks remain exact apart from the
independently proved driver site and new copy. Nine old copies/cohorts, four
private-owner functions, both driver functions/immediate carry,5232 BUF banks,
all original whole-LAB FF controls and complete LAB selectors remain under the
strict checks. No generic pin/ALM/control waiver or numeric normalization exists.

Evidence independently_proved_shared_alm_mate contains the exact owner/BEL,
eight assignment rows, both full LUT/ALM records and shared native driver. The
one independently proved mate bank is counted separately from strict unchanged
original banks. Missing or unsupported state fails closed. Hidden caches/GPU
IDs, physical pip/CRAM/RBF decode, independent numerical STA, gain and hardware
remain unproved; actual timing is separately required for acceptance.
