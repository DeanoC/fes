# Tenth full-route comparison

ROOT alone activates this NEW exclusive comparison after whole-byte/hash/AST
and independent peer review. Mandatory actual closed full-run SHA is never
predicted. Prepared full profileea033985, recorder3aa1a8cf/scopeb0f52c61 and
positive tenth V2 prefixbf9d312c/profile77fd5636/run3d69a28a are fixed. Actual
strict rejectionf71d5228 and its e4124425/d2a7faa7 bytes stay separately bound.
Current compilerd7e5c61f/ELF41c2afe1/archive4fbebd5e/host0f3 and fresh-eight
control1cff remain selected; old compiler tests do not qualify this compiler.

Structural before is actual ninth full ea8e5bed/profile788f16d2 with independent
native/physical-positive proof5966273b and rejected gain112.981582MHz. Both
images use the same current compiler and creator must match exactly. Numerical
acceptance uses actual accepted-fifth5ed3c077/proof6dcf8c4b at117.77175903320312MHz,
independently of the ninth construction. No rejected path timing or physical
function is inherited as a current result.

Flat prefix/accepted/construction closures, every current profile input, actual
record/profile union, loaded runtime, four outputs and these eight new files are
bound/rehashed. Command must equal the current tenth recorder's independent dual
construction. Current full runtime equals tenth prediction and actual ninth
literally; only the older accepted frame needs the proven current ELF/PATH
substitution. Cwd/environment/device/header/RTL/BUILD_ID/options stay exact.
Current host/source/dependency maps, all ten fresh local models, driver candidate0
with complete domain guards and all71 placement metrics are checked. No old
prepare/route/main/auth, source-clean query or recursive generator is invoked.

Pinned32fd supplies lossless parsing/Audit/canonical;72131/8601 supplies native
tables/topology. Current recorder definitions contribute only pure command/log/
host checks. Physical60ca4442 and timinge6ce77b7 contribute lower definitions,
never their historical evaluate/acceptance functions. Executed project imports
and direct dependencies must be in the actual flat closure before final rehash.

New native proof independently reconstructs per-image private and BUF frames,
one absent-before ALUT5/private net, eight FF ENA redirects and five added input
loads. It preserves nine literal copies/cohorts, original metadata/full pins/BELs,
public ports, owner order, paired PLLs and all8221 original FFs. New physical proof
independently evaluates32 actual pin-state rows, both driver images/carry, whole
original FF controls and occupied shared banks in old/new affected LABs, four
private-owner functions and all5232 existing buffers. Only explicit native slots
and independently evaluated new copy/driver sites are admitted; no BUF collapse,
blanket pin/LAB waiver or global numeric normalization is used.

Current timing is evaluated before structural checks, so a native/physical
rejection retains actual timing diagnostics. All15290 endpoints/seven domain
pairs/windows must match accepted-fifth and own tenth prediction. Capture's5ns
and memory half-cycle3.8459999561309814ns windows and all exact constraints stay
fixed. Gain must exceed117.771759MHz with all six non-target positive headrooms,
pixel/capture constraints and zero LAST holds. Target130MHz closure, all-clock
nonregression and headroom changes remain separate visible results. Only joint
native/physical/current-timing success accepts gain. Every original file is
rehashed even on serialized structural rejection; hidden caches/GPU IDs, decoded
RBF, independent numerical STA and hardware remain unproved.
