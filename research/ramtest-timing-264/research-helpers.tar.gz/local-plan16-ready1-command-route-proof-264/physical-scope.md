# Tenth exported physical scope

evaluate(core,before_doc,after_doc,ledger,profile,trial) is pure. Caller authenticates
the separately pinned60ca4442 lower core and all documents. Only its lower
PhysicalView/evaluate_alm/evaluate_lut/_shape/_boundary/_read_shape/_driver_proof/
_ff_pair/_buffer_proof definitions are used; old evaluate/_ready_proof, validators,
authenticators or generators are never called. Ledger keys are exactly ready,
driver, buffer_rows and private_output_rows from the new native proof.

The actual ninth and tenth exported pin snapshots/native driver tokens/physical
ALUT tables independently prove innerALUT2/outerALUT4/two retainedALUT5/newALUT5
composition on five distinct effective input drivers. All32 rows use actual
SIG/INV/constants, both occupied32-row halves, active-low storage and MCOMB logic
permutation where applicable. Logical prefix rows are not physical evidence.
The new prefix site's absent pin snapshot proves no hardware function; final
actual ABCDE/Q snapshots and actual bank placement are required here.

Root87→79 and only the eight declared LAB25.16 ENAs become the equivalent new Q;
all nine previous copy functions/pins/cohorts remain strict, including retained
21+1 enables. Original FF CLK/full pins/BELs remain exact. Whole original LAB
selectors/modes/snapshots must match; there is no generic control-bank waiver.
The complete original FF set in the union of predeclared and actual old/new
copy, driver, source, operand, carry and private-owner LABs is independently
checked, allowing only the eight already evaluated enable functions.

Both old/current driver copies are evaluated against the original source's
eight-row function and single arithmetic operand. Actual arithmetic LUT0/1,
q0+!q1+CI, dedicated CO-to-immediate-CI and shared-half resources stay in the
pinned lower proof. Every original occupied ALM bank/function/shared input token
in scope remains exact apart from the independently evaluated new ready copy
and requalified driver site. Four generated private owner functions and all5232
named buffers/unique FFs are reconstructed per image without raw-ID translation
or collapse. Missing snapshots, unsupported MLAB use or sharing changes reject.

Evidence covers exported-state functions and controls. Actual CRAM/RBF bytes,
physical pip/mux decoding, hidden caches/GPU IDs, independent numerical STA and
hardware remain unproved. This helper never accepts timing gain.
