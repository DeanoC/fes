# DDR0 next-stage target after the two-root ready plan

Read-only graph and policy assessment. No compiler/helper edits, builds, routes,
or hardware operations were performed. This ignored note is the only new file.
Root remains the build and route operator. FES base is
`7ce9926941a5f72cc3ca4b0ed61b7b06e76e5304`; the measured g8 route used frozen
nextpnr commit `664599e39086d89104a0eeeaa44f192038f88ae6` and binary SHA256
`7c60d4a5e4a763fec35ab4c3ed77f50e8fe7486a17b72843321cd9dfd3f19a52`.

## Recommendation

Measure the current two-root plan first. If its memory bottleneck moves to this
DDR0 address enable path, first list and qualify a **third existing local-remap
step**, composing the final ALUT3 and ALUT4 into a six-input LUT for the primary
address group. Use one group initially and `preserve_ff_placement: true`. No new
compiler mapping is needed for this experiment. A generic three-LUT internal
cut later in the same path is the next bounded implementation target if the
terminal fold fails qualification or leaves this chain critical. The proposed
private24 mapping applies to the comparator on this exact cone, but has a less
direct benefit for the actual critical source and requires more implementation.

## Authenticated measured path

Inputs are under `out/ramtest-wide-reduction-264/comb-remap-264/`:

| Artifact | SHA256 |
| --- | --- |
| `route-c0-ready-g8/routed.json` | `a6cebba2cb7752cb152808946243bcce415f9658ca35a6767820f7edec6f98cd` |
| `route-c0-ready-g8/timing.json` | `b50004ff986f16841cb50dfd18bc9c797324af6d1933ae0a0f3b6e12354271b3` |
| `route-c0-ready-g8/run.json` | `e617c9652af7a544a65a0bc9e3b7608521e5986404723257d4a1d79e77e39bd0` |
| frozen115 `placed-reduction-root-slack/route-local-r6-s0/routed.json` | `12b2b6e334d38ea113918d0c1800853cc77f1e6d6fbbf3a91d05b2d7b09b016e` |

The first three current hashes match g8 `comparison.json`'s artifact identities.
The completed full g8 route reports memory 114.0120849609375 MHz, pixel
92.74717712402344 MHz and phase 378.5823974609375 MHz. It was rejected against
115.380 MHz; it is diagnostic evidence, with no hardware acceptance.

The memory critical source is `ddr0_test.idle_MISTRAL_FF_Q_16.Q` at `(40,31)`.
Frozen synthesis netnames map this generated suffix to logical **idle[11]**.
The sink is `ddr0_address_MISTRAL_FF_Q_21.ENA` at `(36,30)`. The complete path is
8.770999925 ns against 7.691999912 ns: 0.014 ns skew, 0.731 ns clock-to-Q,
6.549 ns routing, 1.674 ns logic, and -0.196 ns setup.

The six logic arcs, in path order, are:

| Label | Cell | BEL | Mask | Critical pin / delay |
| --- | --- | --- | --- | --- |
| T1 | `ddr0_test.state_MISTRAL_FF_Q_4_DATAIN_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q_C_MISTRAL_ALUT5_Q_1` | `MISTRAL_COMB.40.31.37` | `0x100000` | A / 0.583 ns |
| T2 | `ddr0_test.state_MISTRAL_FF_Q_4_DATAIN_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_Q` | `MISTRAL_COMB.35.29.30` | `0x80` | B / 0.400 ns |
| T3 | `ddr0_test.write_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_C_Q_MISTRAL_ALUT4_Q_1_C_MISTRAL_ALUT3_C_1_Q_MISTRAL_ALUT2_Q` | `MISTRAL_COMB.35.29.31` | `0x8` | B / 0.097 ns |
| T4 | `ddr0_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT2_Q` | `MISTRAL_COMB.35.29.13` | `0xe` | A / 0.400 ns |
| T5 | `ddr0_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT3_C` | `MISTRAL_COMB.36.27.55` | `0x4` | C / 0.097 ns |
| T6 | `ddr0_test.cmd_end_MISTRAL_ALUT4_C` | `MISTRAL_MCOMB.34.27.12` | `0x5700` | D / 0.097 ns |

Incoming routes to T1..T6 are 1.201, 0.860, 1.290, 0.581, 0.775 and 0.438 ns;
the final T6.Q to address21.ENA route is 1.403 ns. The seven comparator LUTs and
T3..T6 retain the frozen115 types, tables, logical connections and BELs exactly.
This is an unchanged Boolean cone whose routed delay became limiting.

## Existing terminal two-LUT composition

Compose T5 then T6. T5 is `!A && B && !C`; T6 retains its exact `0x5700` table.
Enumerating all 64 assignments proves six structural inputs and six essential
inputs; no pruning or correlated-input assumption is needed. In **ascending g8
routed bit-ID order**, the resulting table is `0x0000030001000300`:

| Input index | Routed bit | Normalized driver |
| --- | --- | --- |
| 0 | 4223 | `ddr0_test.stop_MISTRAL_FF_Q.Q` |
| 1 | 4979 | T4.Q |
| 2 | 4990 | `ddr0_test.drain_MISTRAL_FF_Q_DATAIN_MISTRAL_ALUT_ARITH_SO_CO_MISTRAL_ALUT_ARITH_CI_SO_MISTRAL_NOT_A_Q_MISTRAL_FF_DATAIN_Q_MISTRAL_ALUT4_D_Q_MISTRAL_ALUT3_Q.Q` |
| 3 | 4991 | `ddr0_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_Q.Q` |
| 4 | 4995 | `ddr0_test.state_MISTRAL_FF_Q_2.Q` |
| 5 | 7187 | `ddr0_test.cmd_end_MISTRAL_FF_Q.Q` |

The compiler assigns external input IDs in collection order, so it should
derive its own table/order rather than copy this diagnostic mask. This is a
general six-input truth proof, including any actual reconvergence/correlation
among the source nets.

The actual reported final routing edges are T5.Q to T6.D and T6.Q to FF.ENA,
which meet the existing local-remap discovery shape. T6.Q has 28 direct ENA
users in seven LABs. Primary LAB `(36,30)` contains **only address_FF_Q_21** in
that family. Other group sizes are `(29,31):2`, `(30,27):4`, `(31,28):3`,
`(33,27):2`, `(34,27):11`, and `(37,27):5`. Group expansion should remain an
independently qualified later choice.

The local fold adds one ALUT6 clone and redirects the selected whole LAB group.
It preserves T5, its 32 status ENA side users, T6 and all unselected address
ENAs. With FF preservation, address and feedback FF BELs remain fixed. All six
source-net existing users, source-cell ports, clock connections and exact
indexed user slots must remain unchanged; only clone slots and selected ENA
slots are added/redirected. The current existing legality, per-clock setup,
hold and hard-boundary qualification gates remain necessary.

A listing step can use the current g8 timing report after the first two ready
steps, if DDR0 connectivity and these placements remain unchanged. This report
has six critical paths, but **only the DDR0 memory path ends at ENA**; the other
five end at DATAIN. Thus local-remap selection does not import a stale ready
ENA path from the earlier g8 group expansion. The graph validator must still
authenticate it in the actual fresh HeAP context; never load g8 routed JSON.
The existing DDR1 comb cut remains after the local plan hook.

Example **final listing step**, for a plan file in this directory:

```json
{
  "report": "../comb-remap-264/route-c0-ready-g8/timing.json",
  "candidate": -1,
  "groups": 1,
  "optimize_pins": false,
  "preserve_ff_placement": true
}
```

Listing must be the final step and use `--no-route` without `--rbf`. Use the
actual qualified index from the staged listing for a measured run; do not assume
that structural support guarantees qualification. Failure aborts before route.

## Next bounded internal cut if the final fold is insufficient

T3 -> T4 -> T5 is a three-LUT cut with **five structural and five essential
inputs**. T3 is `state && timeout`; T4 is `T3 || condition`; T5 is
`!drain_condition && other_condition && !T4`. Exhaustive 32-row evaluation gives
`0x01000300` in ascending routed-bit order
`[4123,4987,4990,4991,7193]`: state FF.Q, T4.B's existing condition driver,
the same T5.A/T5.B drivers above, and timeout comparator T2.Q.

The existing generic `local_remap_cut_policy` already supports this function.
Clone the three-node cut into **T6.D only**, preserving T3, T4 and T5 in place.
Their total original output consumers are 5, 2 and 33 respectively; T4 also
drives `ddr0_nack_MISTRAL_FF_Q.ENA`, and T5 retains the 32 status ENAs. An ALUT5
clone reduces these three levels to one on the address branch. Bound it near
the unchanged T6/selected consumers using actual full legality and full STA.
No in-place change to these shared roots is justified by this proof.

The T4 -> T5 two-node fallback has four essential inputs and table `0x0100` over
sorted routed bits `[4218,4987,4990,4991]`; it removes one level into T6.D.
T4 -> T5 -> T6 instead has seven structural **and seven essential** inputs and
is rejected by the six-input policy. No generic pruning makes that cut fit.

Current `remap_comb_critical` can discover the three-node T3/T4/T5 cut on this
report and rank it near the terminal edge, but the CLI/hook selects only one
comb cut. Retaining the accepted DDR1 cut and adding this DDR0 cut needs generic
multi-comb staging or another explicit bounded invocation in the same fresh
placement context. Reuse the existing pure policy and mutation/rollback path;
an optional generic staged comb extension is smaller than a new private24
rewriter. Every stage must validate its current graph, preserve earlier stages,
and abort on failure. A previous local T5/T6 clone changes the original address
ENA report edge, so do not blindly apply both transformations with stale g8
guidance; first list each proposed stage against its actual preceding graph.

## The private24 plan on this exact DDR0 comparator

T2 is indeed a pure 24-literal equality, with seven LUTs and three maximum
levels: three ALUT4 -> ALUT5 eight-literal branches, then ALUT3 `0x80`.
Unique-row recognition of each local table proves `idle == 24'd1000000`
(`0x0f4240`), with high logical bits 6,9,14,16,17,18,19. All other bits are low.
There are 24 distinct external FF-Q inputs; sixteen source FFs are in `(40,31)`,
four in `(39,31)` and four in `(39,30)`. No 2^24 enumeration was needed.

All six nonroot LUT outputs are private, with exactly one internal consumer.
The root Q is shared by six external ordinary LUT input slots: T3.B,
`ddr0_test.write_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT5_Q.E`,
`ddr0_test.write_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT3_C_Q_MISTRAL_ALUT4_Q_1_C_MISTRAL_ALUT2_Q.B`,
`ddr0_test.state_MISTRAL_FF_Q_4_DATAIN_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT2_A.A`,
`ddr0_test.state_MISTRAL_FF_Q_4_DATAIN_MISTRAL_ALUT5_Q.E`, and
`ddr0_read_MISTRAL_FF_Q_DATAIN_MISTRAL_ALUT6_Q_F_MISTRAL_ALUT2_Q.B`.
Preserve the original root cell/Q net/driver and all six exact consumer slots.
Preserve all external idle FF side users, including counter feedback.

The complete downstream closure contains 29 nets and 354 unique FF inputs:
349 ENA and 5 DATAIN. There is benign reconvergence at T4.Q. Use active/completed
DFS states; do not reject a second completed visit as a cycle. These bounds fit
the prior placed24 plan's proposed 64-net limit, subject to actual-context
revalidation after earlier clones.

The placement differences from the DDR1 target in `comb-remap-264/placed24-plan.md`
matter. T2's opposite ALM LUT is the critical T3 at `(35,29,31)`; it must stay
bound and intact while a fixed-site ALUT3->ALUT4 root is tested. Five original
private-child ALMs also contain post-route FF DATAIN route-through BUFs and
source FFs. These BUFs are post-route insertions, not proof of fresh-placement
occupancy or a reason to reuse their sites. Preserve original FF placements and
check live ALM/LAB/control/input-sharing legality; freeing six private LUTs does
not guarantee four legal ALUT6 sites.

The proposed four ALUT6 leaves -> ALUT4 root gives two comparator levels, five
active LUTs, and preserves all root consumers. But **logical idle[11] currently
traverses only T1 -> T2, two comparator levels already**. The proposed mapping
must gain from route geometry and pin arcs on this exact path; it does not
automatically remove a level there. Other comparator sources currently cross
three levels and may improve. Keep the root fixed, use bounded local placement
search and full-model per-clock/endpoint/hold/boundary gates from the prior plan.

Logical graph fingerprint, excluding BELs, physical maps and JSON bit IDs:
`4172069250175efc7c84c2c4dfe3aa798a10546c7a2123ea2bc433a55ea21f4e`.
Canonical serialization is sorted cone-node records with keys `cell`, `type`,
`mask` (hex string), and `pins`; each active alphabetical pin records
`[pin,[normalized_driver_cell,driver_port],"PIN_SIG"]`, encoded using
`json.dumps(records,sort_keys=True,separators=(",",":"))`. This fingerprint is
specific to DDR0 names; the cube semantics match the earlier DDR1 target.

## Saved Quartus comparison limits

The saved fit reports under the separate oss-lane worktree's
`out/ramtest-quartus-control-cones/reports/` include DDR1 idle[14] -> beats_left[2]
DATAIN and DDR2 idle[23] -> address[25] ENA, not this exact DDR0 endpoint. The
DDR2 report shows three logic levels, 4.287 ns data delay and 3.175 ns setup
slack; its first LUT is `Equal13~2`, followed by a selector/control chain. It is
evidence that equality/control factoring can produce a shallower overall path,
not a measured gain for DDR0 private24 rewriting. The saved DDR2 report SHA256
is `1e83022bc9f2d363735065778b05a3dc63bae1a661a2a60e36f4e748d0e8ae92`.
Quartus and OSS builds/model/PLL/constraint identities differ as documented in
the saved hints. No Fmax calibration or hardware claim follows from that fit.
