#!/usr/bin/env python3
"""Authenticate a frozen staged remap, its actual graph changes and truth tables.

This host-only helper writes comparison.json after run.json is final. It does
not compile, place, route, select an image or touch hardware. Failed runs and
host-only final-step listings are recorded without claiming route acceptance.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
COMB_HELPER = RAW / "comb-remap-264/compare_routes.py"
spec = importlib.util.spec_from_file_location("comb_remap_evidence", COMB_HELPER)
comb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(comb)
ready, previous = comb.ready, comb.previous
require, read, sha, relative = comb.require, comb.read, comb.sha, comb.relative
CONTROL, BASE = comb.CONTROL, comb.BASE
READY_CONTROL = comb.READY_CONTROL
COMB_G1 = comb.COMB_READY_G1
COMB_G4 = comb.HERE / "route-c0-ready-g4"
COMB_G8 = comb.HERE / "route-c0-ready-g8"
TWO_ROOT_CONTROL = HERE / "route-c0-g1"
SOURCE_BASE = "664599e39086d89104a0eeeaa44f192038f88ae6"
STEP_KEYS = {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"}
STEP_HEADER = previous.re.compile(
    r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=([01]) preserve_ffs=([01])\.$",
    previous.re.M)
LOCAL_CANDIDATE = previous.re.compile(
    r"^Info: Local remap candidate (\d+): (\S+) \+ (\S+) -> (\S+), (\d+) ENA users, predicted gain ([\d.]+)ps\.$",
    previous.re.M)


class Netlist(comb.Netlist):
    """Name external, driverless hard-block/pad nets across JSON renumbering."""
    def __init__(self, cells, netnames=None):
        names = {}
        for name, net in (netnames or {}).items():
            for index, bit in enumerate(net["bits"]):
                names.setdefault(bit, []).append((name, index))
        self.external_names = {bit: tuple(sorted(aliases)) for bit, aliases in names.items()}
        super().__init__(cells)

    def token(self, bit, stack=frozenset()):
        result = super().token(bit, stack)
        if result[0] == "undriven" and result[1] in self.external_names:
            return ("external_net", self.external_names[result[1]])
        return result


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON plan key: " + key)
        result[key] = value
    return result


def fixed_command(command):
    """Compare option values independent of the runner's argument ordering."""
    excluded = {"--write", "--report", "--rbf", "--remap-critical", "--remap-candidate", "--remap-groups",
                "--remap-comb-critical", "--remap-comb-candidate", "--remap-plan"}
    flags = {"--timing-allow-fail", "--detailed-timing-report", "--compress-rbf", "--no-route",
             "--remap-optimize-pins"}
    result, seen, index = [], set(), 1
    while index < len(command):
        option = command[index]
        require(option.startswith("--") and option not in seen, "unexpected/repeated command option: " + option)
        seen.add(option)
        if option in flags:
            if option not in {"--no-route", "--remap-optimize-pins"}:
                result.append((option, True))
            index += 1
        else:
            require(index + 1 < len(command) and not command[index + 1].startswith("--"),
                    "missing command value: " + option)
            if option not in excluded:
                result.append((option, command[index + 1]))
            index += 2
    return sorted(result)


def authenticated_digest(record, path, aliases=()):
    digest = sha(path)
    require(record["input_sha256"].get(str(path)) == digest, "unauthenticated input: " + str(path))
    for key in aliases:
        if key in record:
            require(record[key] == digest, "input alias disagrees with bytes: " + key)
    return digest


def validate_profile(steps, listing=False):
    """Preserve the two-stage profile, with one explicitly bound third guide."""
    require(len(steps) in (2, 3) and steps[0]["report_path"] == CONTROL / "timing.json" and
            steps[0]["groups"] == 4 and steps[1]["report_path"] == COMB_G4 / "timing.json",
            "first two stages differ from the established guidance/budget profile")
    require(all(step["preserve_ff_placement"] and not step["optimize_pins"] for step in steps),
            "this profile requires preserved FFs and unoptimized logical pins")
    if len(steps) == 3:
        third = steps[2]
        require(not listing and third["report_path"] in {COMB_G8 / "timing.json", TWO_ROOT_CONTROL / "timing.json"} and
                type(third["candidate"]) is int and third["candidate"] >= 0 and
                type(third["groups"]) is int and 1 <= third["groups"] <= 8,
                "optional third stage must select a bounded candidate from the frozen g8 or two-root report")


def authenticate_plan(record, listing=False):
    command = record["command"]
    require(not any(flag in command for flag in ("--remap-critical", "--remap-candidate", "--remap-groups",
                                                "--remap-optimize-pins")), "legacy local-remap flags accompany the plan")
    plan_file = Path(ready.argument(command, "--remap-plan"))
    digest = authenticated_digest(record, plan_file, ("remap_plan_sha256", "plan_sha256", "local_remap_plan_sha256"))
    plan = json.loads(plan_file.read_text(), object_pairs_hook=unique_object)
    require(type(plan) is dict and set(plan) == {"steps"} and type(plan["steps"]) is list and
            1 <= len(plan["steps"]) <= 8, "invalid plan schema or step count")
    steps = []
    for index, step in enumerate(plan["steps"]):
        require(type(step) is dict and set(step) == STEP_KEYS, "invalid plan step keys")
        require(type(step["report"]) is str and step["report"] and "\0" not in step["report"], "invalid report path")
        require(type(step["candidate"]) is int and 0 <= step["candidate"] <= 2147483647 or
                listing and index == len(plan["steps"]) - 1 and type(step["candidate"]) is int and step["candidate"] == -1,
                "invalid selected plan candidate")
        require(type(step["groups"]) is int and 1 <= step["groups"] <= 8 and
                type(step["optimize_pins"]) is bool and type(step["preserve_ff_placement"]) is bool,
                "invalid plan step options")
        require(step["preserve_ff_placement"], "this evidence profile requires unchanged FF placement")
        report_file = Path(step["report"])
        if not report_file.is_absolute():
            report_file = plan_file.parent / report_file
        report_file = report_file.resolve()
        report_sha = authenticated_digest(record, report_file)
        report = read(report_file)
        require(type(report.get("critical_paths")) is list, "plan guidance has no critical path array")
        steps.append({**step, "index": index, "report_path": report_file, "report_sha256": report_sha, "report_json": report})
    require(record.get("list_only", False) is listing and ((steps[-1]["candidate"] == -1) is listing),
            "plan/list record disagrees with selected final candidate")
    if "remap_plan" in record:
        require(record["remap_plan"] == plan, "recorded plan differs from authenticated plan bytes")
    # Candidate ordinals and group budgets come from the authenticated plan.
    # Only the optional third report lineage is added to the original profile.
    validate_profile(steps, listing)
    if "ddr0_next" in record:
        require(type(record["ddr0_next"]) is bool and record["ddr0_next"] is (len(steps) == 3),
                "optional DDR0-stage record disagrees with the authenticated plan")
    require(not listing or "--no-route" in command, "listing requested a route")
    return plan_file, digest, steps


def authenticate_compiler(record):
    require(Path(record["command"][0]) == HERE / "nextpnr-mistral", "candidate compiler is not the plan freeze")
    source = previous.source_identity(HERE, record)
    parent_record = read(COMB_G1 / "run.json")
    parent_source, _ = comb.authenticate_compiler(parent_record)
    require(source["base_commit"] == SOURCE_BASE == parent_source["result_commit"], "plan compiler parent differs from frozen664599")
    fields = dict(part.strip().split("=", 1) for part in record["tool_identity"].split(";") if "=" in part)
    require(fields.get("base_commit") == source["base_commit"] and
            fields.get("experimental_source_sha256") == source["archive_sha256"] and
            fields.get("sha256") == source["binary_sha256"], "compiler identity text differs from the freeze")
    authenticated_digest(record, HERE / "source.tar.gz", ("source_archive_sha256",))
    require(record.get("base_compiler_commit") == source["base_commit"], "recorded compiler parent changed")
    result = source.get("result_commit")
    committed = isinstance(result, str) and previous.re.fullmatch(r"[0-9a-f]{40}", result) is not None
    if committed:
        require(record.get("compiler_commit") == result, "recorded compiler result changed")
    return {**source, "freeze_path": relative(HERE), "result_commit_recorded": committed}, parent_source


def plan_blocks(log, steps, full=True):
    headers = list(STEP_HEADER.finditer(log))
    require(len(headers) == len(steps) if full else len(headers) <= len(steps), "plan stage count differs from the log")
    blocks = []
    for index, match in enumerate(headers):
        step = steps[index]
        actual = tuple(map(int, match.groups()))
        require(actual == (index, step["candidate"], step["groups"], int(step["optimize_pins"]),
                           int(step["preserve_ff_placement"])), "logged plan stage/options differ from the plan")
        end = headers[index + 1].start() if index + 1 < len(headers) else len(log)
        blocks.append(log[match.end():end])
    return blocks


def selected_local(block, step):
    found = [m for m in LOCAL_CANDIDATE.finditer(block) if int(m[1]) == step["candidate"]]
    require(len(found) == 1 and block.count(f"Local remap applied candidate {step['candidate']};") == 1,
            "selected local stage was not uniquely reported and applied")
    match = found[0]
    require(float(match[6]) >= 250, "selected local candidate lacks the modeled gain threshold")
    trial = previous.re.compile(r"^Info: Local remap trial inner=" + previous.re.escape(match[2]) +
        r" outer=" + previous.re.escape(match[3]) + r" lab=(\d+),(\d+) bel=" + previous.re.escape(match[4]) +
        r" shift=0,0 gain=" + previous.re.escape(match[6]) + r"ps clocks=1 hold=1 boundaries=1 groups=(\d+) sinks=(\d+)$",
        previous.re.M)
    trials = list(trial.finditer(block[:match.start()]))
    require(trials, "selected local candidate has no matching zero-movement trial with all guards")
    selected = trials[-1]
    require(int(selected[4]) == int(match[5]) and 1 <= int(selected[3]) <= step["groups"],
            "logged selected sink/group count exceeds the stage budget")
    return {"stage": step["index"], "candidate": step["candidate"], "inner": match[2], "outer": match[3],
            "bel": match[4], "primary_lab": tuple(map(int, (selected[1], selected[2]))),
            "selected_group_count": int(selected[3]), "selected_ff_count": int(match[5]),
            "requested_group_budget": step["groups"], "predicted_gain_ps": float(match[6]),
            "candidate_log": match[0], "qualified_trial_log": selected[0], "shift": [0, 0],
            "modeled_clocks_holds_boundaries_passed": True}


def recover_local_cut(old, selected, guide, modeled):
    """Use the report's last two routing edges, never cell-name assumptions."""
    root = tuple(selected[0]["control_driver"])
    require(root == (modeled["outer"], "Q", 0), "selected original root disagrees with the stage log")
    found = []
    for path in guide["critical_paths"]:
        segments = path.get("path", [])
        if not segments or segments[-1]["type"] != "setup" or segments[-1]["to"]["port"] != "ENA":
            continue
        require(math.isfinite(path["max_delay"]) and all(math.isfinite(s["delay"]) for s in segments), "nonfinite local guidance")
        total = sum(s["delay"] for s in segments)
        require(math.isfinite(total), "nonfinite local guidance total")
        if total <= path["max_delay"]:
            continue
        edges = [(s["from"], s["to"]) for s in segments if s["type"] == "routing"]
        if len(edges) < 2:
            continue
        a, b = edges[-2:]
        if (a[0]["cell"], b[0]["cell"]) != (modeled["inner"], modeled["outer"]):
            continue
        if a[0]["port"] != "Q" or b[0]["port"] != "Q" or a[1]["cell"] != b[0]["cell"] or b[1]["port"] != "ENA":
            continue
        primary = b[1]["cell"]
        require(primary in old.cells and old.cells[primary]["type"] == "MISTRAL_FF" and
                old.inputs(primary)["ENA"] == [root] and comb.cell_lab(old.cells[primary]) == modeled["primary_lab"],
                "reported primary ENA/BEL does not match the selected stage")
        require(old.inputs(modeled["outer"]).get(a[1]["port"]) == [(modeled["inner"], "Q", 0)],
                "reported local inner-to-outer edge is stale")
        for source, target in (a, b):
            require(tuple(source["loc"]) == comb.cell_lab(old.cells[source["cell"]]) and
                    tuple(target["loc"]) == comb.cell_lab(old.cells[target["cell"]]), "reported local cut placement is stale")
        found.append((primary, path))
    require(found, "the selected two-LUT local cut cannot be recovered from its authenticated report")
    return found[0][0], found[0][1]


def prove_local(old, new, clone, selected, step, modeled):
    require(selected and len(selected) == modeled["selected_ff_count"] and
            previous.bel(new.cells[clone]) == modeled["bel"], "local graph/BEL differs from the selected stage")
    primary, path = recover_local_cut(old, selected, step["report_json"], modeled)
    proof = ready.prove_clone(old, new, clone, selected)
    proof.pop("expected_ready_cone", None)
    proof.pop("expected_mask_0xbbbbbbb0", None)
    root = tuple(proof["control_root"])
    require(set(proof["retained_cone"]) == {modeled["inner"], modeled["outer"]} and
            proof["control_lut_depth"] == 2, "local clone is not the reported two-LUT composition")
    require(old.pin_states(root[0]).get("Q", 0) == 0 and
            all(new.pin_states(clone).get(pin, 0) == 0 for pin in "ABCDEF"[:len(new.lut_inputs(clone))] + "Q"),
            "local clone has unexpected logical pin polarity")
    names = {row["ff"] for row in selected}
    require(primary in names, "reported primary FF is absent from the selected ENAs")
    before = comb.consumers(old, root, set(old.cells))
    after = comb.consumers(new, root, set(old.cells))
    expected = [user for user in before if not (user[0] in names and user[1:] == ("ENA", 0))]
    require(after == expected, "unselected shared local-root consumers changed")
    clone_users = comb.consumers(new, (clone, "Q", 0), set(new.cells))
    require(clone_users == sorted((name, "ENA", 0) for name in names), "new local clone has an unexpected consumer")
    groups = {}
    clock, clock_state = old.inputs(primary)["CLK"], old.pin_states(primary).get("CLK", 0)
    for name in names:
        require(old.inputs(name)["ENA"] == [root] and new.inputs(name)["ENA"] == [(clone, "Q", 0)] and
                old.pin_states(name) == new.pin_states(name), "selected FF ENA function or polarity changed")
        groups.setdefault(comb.cell_lab(old.cells[name]), []).append(name)
    require(len(groups) == modeled["selected_group_count"] <= step["groups"], "actual selected LAB budget differs from the stage")
    for lab, members in groups.items():
        users = [u for u in before if comb.cell_lab(old.cells[u[0]]) == lab]
        require(all(old.cells[name]["type"] == "MISTRAL_FF" and port == "ENA" and index == 0 and
                    old.inputs(name)["CLK"] == clock and old.pin_states(name).get("CLK", 0) == clock_state
                    for name, port, index in users) and sorted(u[0] for u in users) == sorted(members),
                "local stage selected a partial or incompatible LAB group")
    return {**proof, "stage": step["index"], "requested_group_budget": step["groups"],
            "selected_group_count": len(groups), "selected_ff_count": len(names), "primary_ff": primary,
            "primary_lab": modeled["primary_lab"], "selected_report_path": path,
            "selected_lab_groups": [{"lab": lab, "ffs": sorted(members)} for lab, members in sorted(groups.items())],
            "original_root_consumers": before, "retained_original_root_consumers": after,
            "unselected_original_root_consumers_preserved": True, "clone_consumers": clone_users,
            "whole_compatible_lab_groups_proved": True, "selected_ena_polarities_preserved": True,
            "selected_stage_log": modeled}


def compare_netlists(old_cells, new_cells, steps, modeled, comb_guide=None, comb_model=None,
                     old_netnames=None, new_netnames=None):
    """Discover any number of accepted local clones plus the optional comb cut."""
    old, new = Netlist(old_cells, old_netnames), Netlist(new_cells, new_netnames)
    added, removed = set(new_cells) - set(old_cells), set(old_cells) - set(new_cells)
    require(not removed and all(ready.is_lut(new_cells[name]) for name in added), "original cells removed or non-LUT additions present")
    local_changes, internal_changes = {}, {}
    old_ffs = {n for n, c in old_cells.items() if c["type"] == "MISTRAL_FF"}
    old_luts = {n for n, c in old_cells.items() if c["type"].startswith("MISTRAL_ALUT")}
    require(old_ffs == {n for n, c in new_cells.items() if c["type"] == "MISTRAL_FF"}, "FF population changed")
    for name, a in old_cells.items():
        b = new_cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and previous.bel(a) == previous.bel(b),
                "original type/parameter/BEL changed: " + name)
        require(a["port_directions"] == b["port_directions"] and
                a["attributes"].get("FES_PINMAP_V1") == b["attributes"].get("FES_PINMAP_V1"),
                "original port/pin mapping changed: " + name)
        ai, bi = old.inputs(name), new.inputs(name)
        require(set(ai) == set(bi), "original input ports changed: " + name)
        if a["type"] == "MISTRAL_BUF":
            require(ai == bi and old.direct_users.get((name, "Q", 0), []) == new.direct_users.get((name, "Q", 0), []),
                    "original transparent buffer changed: " + name)
            continue
        for port in ai:
            if ai[port] == bi[port]:
                continue
            require(len(ai[port]) == len(bi[port]) == 1 and len(bi[port][0]) == 3 and
                    bi[port][0][0] in added and bi[port][0][1:] == ("Q", 0), "unexplained original input change: " + name + "." + port)
            clone = bi[port][0][0]
            if name in old_ffs and port == "ENA":
                local_changes.setdefault(clone, []).append({"ff": name, "bel": previous.bel(b),
                    "control_driver": ai[port][0], "candidate_driver": bi[port][0]})
            else:
                require(ready.is_lut(a) and port in "ABCDEF", "input changed outside FF ENA/internal Boolean LUT: " + name)
                internal_changes.setdefault(clone, []).append({"sink": name, "port": port, "bel": previous.bel(b),
                    "control_driver": ai[port][0], "candidate_driver": bi[port][0]})
    require(len(local_changes) == len(modeled) == len(steps), "accepted stage count differs from discovered local clones")
    require(set(local_changes).isdisjoint(internal_changes) and set(local_changes) | set(internal_changes) == added,
            "an added clone has no authorized selected consumer or serves both kinds")
    require(len(internal_changes) == int(comb_model is not None), "internal cut count differs from the selected command")
    proofs, used = [], set()
    for step, model in zip(steps, modeled):
        matches = [name for name, changes in local_changes.items() if
                   {tuple(row["control_driver"]) for row in changes} == {(model["outer"], "Q", 0)} and
                   previous.bel(new_cells[name]) == model["bel"]]
        require(len(matches) == 1 and matches[0] not in used, "stage cannot be matched to a unique new local clone")
        clone = matches[0]
        used.add(clone)
        proofs.append(prove_local(old, new, clone, local_changes[clone], step, model))
    comb_proof = None
    if comb_model:
        clone, selected = next(iter(internal_changes.items()))
        comb_proof = comb.prove_cut(old, new, clone, selected, comb_guide, comb_model)
        require(comb.consumers(new, (clone, "Q", 0), set(new.cells)) == [(selected[0]["sink"], selected[0]["port"], 0)],
                "new internal-cut clone has an unexpected consumer")
    return {"common_cells": len(old_cells), "common_ff_cells": len(old_ffs), "original_lut_cells": len(old_luts),
            "added_clone_count": len(added), "local_clone_count": len(proofs), "comb_clone_count": int(bool(comb_proof)),
            "added_cells": [ready.detail(name, new_cells[name]) for name in sorted(added)], "removed_cells": [],
            "added_buffer_count": 0, "removed_buffer_count": 0, "all_original_buffers_preserved": True,
            "ff_placements_identical": True, "original_lut_placements_identical": True,
            "original_type_parameters_preserved": True, "all_original_port_pin_mappings_preserved": True,
            "all_original_ff_connections_preserved_except_selected_enas": True,
            "all_unselected_original_logical_connections_preserved": True,
            "all_original_output_consumers_preserved_except_selected_enas_and_internal_edge": True,
            "local_clone_equivalences": proofs, "composed_cut_equivalence": comb_proof,
            "selected_ff_ena_count": sum(len(rows) for rows in local_changes.values()),
            "selected_internal_lut_inputs": [row for rows in internal_changes.values() for row in rows]}


def compare_listing(old_top, new_top, steps, modeled):
    """A pre-route export has neither route BUFs nor a logical pin snapshot."""
    old_cells, new_cells = old_top["cells"], new_top["cells"]
    old, new = Netlist(old_cells, old_top["netnames"]), Netlist(new_cells, new_top["netnames"])
    removed, added = set(old_cells) - set(new_cells), set(new_cells) - set(old_cells)
    require(all(old_cells[name]["type"] == "MISTRAL_BUF" for name in removed) and
            all(ready.is_lut(new_cells[name]) for name in added), "listing changed the original non-BUF population")
    require(not any(cell["type"] == "MISTRAL_BUF" for cell in new_cells.values()), "unexpected pre-route buffer export")
    changes = {}
    for name in set(old_cells) & set(new_cells):
        a, b = old_cells[name], new_cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and
                previous.bel(a) == previous.bel(b) and a["port_directions"] == b["port_directions"],
                "listing changed original type/parameter/BEL/ports: " + name)
        require(not b["attributes"].get("FES_PINMAP_V1"), "listing unexpectedly exports partial pin snapshots")
        ai, bi = old.inputs(name), new.inputs(name)
        require(set(ai) == set(bi), "listing changed original input-port set")
        for port in ai:
            if ai[port] == bi[port]:
                continue
            require(a["type"] == "MISTRAL_FF" and port == "ENA" and len(ai[port]) == len(bi[port]) == 1 and
                    len(bi[port][0]) == 3 and bi[port][0][0] in added and bi[port][0][1:] == ("Q", 0),
                    "listing changed an input outside selected FF ENAs: " + name + "." + port)
            changes.setdefault(bi[port][0][0], []).append({"ff": name, "bel": previous.bel(b),
                "control_driver": ai[port][0], "candidate_driver": bi[port][0]})
    require(set(changes) == added and len(changes) == len(steps) == len(modeled), "listing accepted clone count differs from the plan")
    proofs = []
    for step, model in zip(steps, modeled):
        matches = [name for name, selected in changes.items() if
                   {tuple(row["control_driver"]) for row in selected} == {(model["outer"], "Q", 0)} and
                   previous.bel(new_cells[name]) == model["bel"]]
        require(len(matches) == 1, "listing stage cannot be matched to its accepted clone")
        clone, selected = matches[0], changes[matches[0]]
        require(len(selected) == model["selected_ff_count"], "listing selected ENA count differs from its log")
        primary, path = recover_local_cut(old, selected, step["report_json"], model)
        proof = ready.prove_clone(old, new, clone, selected)
        proof.pop("expected_ready_cone", None)
        proof.pop("expected_mask_0xbbbbbbb0", None)
        proof.pop("equivalent", None)
        require(set(proof["retained_cone"]) == {model["inner"], model["outer"]}, "listing Boolean cut differs from the report")
        names = {row["ff"] for row in selected}
        before = comb.consumers(old, tuple(proof["control_root"]), set(old_cells))
        after = comb.consumers(new, tuple(proof["control_root"]), set(new_cells) - added)
        require(primary in names and after == [user for user in before if not
                (user[0] in names and user[1:] == ("ENA", 0))], "listing changed an unselected shared root consumer")
        require(comb.consumers(new, (clone, "Q", 0), set(new_cells)) == sorted((name, "ENA", 0) for name in names),
                "listing clone has an unexpected consumer")
        groups = {}
        for name in names:
            groups.setdefault(comb.cell_lab(old_cells[name]), []).append(name)
        require(len(groups) == model["selected_group_count"] <= step["groups"], "listing LAB budget differs from its log")
        for lab, members in groups.items():
            users = [user for user in before if comb.cell_lab(old_cells[user[0]]) == lab]
            require(all(old_cells[name]["type"] == "MISTRAL_FF" and port == "ENA" and index == 0 and
                        old.inputs(name)["CLK"] == old.inputs(primary)["CLK"] and
                        old.pin_states(name).get("CLK", 0) == old.pin_states(primary).get("CLK", 0)
                        for name, port, index in users) and sorted(user[0] for user in users) == sorted(members),
                    "listing selected a partial or incompatible original LAB group")
        proofs.append({**proof, "stage": step["index"], "requested_group_budget": step["groups"],
            "selected_group_count": len(groups), "selected_ff_count": len(names), "primary_ff": primary,
            "selected_report_path": path, "selected_stage_log": model,
            "selected_lab_groups": [{"lab": lab, "ffs": sorted(members)} for lab, members in sorted(groups.items())],
            "original_root_consumers": before, "retained_original_root_consumers": after,
            "unselected_original_root_consumers_preserved": True,
            "matches_control_composition_under_pin_assumptions": True,
            "clone_truth_proof_assumes_unserialized_clone_pins_are_plain_signals": True})
    return {"common_ff_cells": sum(c["type"] == "MISTRAL_FF" for c in old_cells.values()),
            "original_lut_cells": sum(c["type"].startswith("MISTRAL_ALUT") for c in old_cells.values()),
            "ff_placements_identical": True, "original_lut_placements_identical": True,
            "all_original_type_parameters_preserved": True,
            "all_unselected_original_exported_connections_preserved": True,
            "added_clone_count": len(added), "local_clone_count": len(proofs), "comb_clone_count": 0,
            "local_clone_compositions_under_pin_assumptions": proofs,
            "selected_ff_ena_count": sum(len(rows) for rows in changes.values()),
            "route_created_control_buffers_absent_before_route": len(removed),
            "pin_state_export_available": False, "original_pin_polarity_and_physical_mapping_proved": False,
            "listing_limitations": ["Pre-route JSON omits FES_PINMAP_V1; original pin polarity and physical mapping cannot be independently checked.",
                                    "Clone truth uses exported LUT parameters and connections with ordinary signal pins; those pin states are not serialized.",
                                    "The full control's transparent route buffers are absent before routing."]}


def selected_ena_arrivals(proofs, reports):
    endpoints = {(row["ff"], "ENA") for proof in proofs for row in proof["selected_ff_ena_users"]}
    values = {}
    for label, report in reports.items():
        current = {}
        for net in report["detailed_net_timings"]:
            for endpoint in net["endpoints"]:
                if (endpoint["cell"], endpoint["port"]) in endpoints:
                    key = (endpoint["cell"], endpoint["port"], net["event"], endpoint["event"])
                    require(key not in current, "duplicate selected FF arrival")
                    current[key] = endpoint["delay"]
        values[label] = current
    candidate = values.pop("candidate")
    require(candidate and all(set(rows) == set(candidate) for rows in values.values()), "selected FF arrival set changed")
    result = {}
    for label, previous_rows in values.items():
        rows = [{"cell": key[0], "port": key[1], "launch_event": key[2], "capture_event": key[3],
                 "control_arrival_ns": previous_rows[key], "candidate_arrival_ns": arrival,
                 "min_arrival_change_ns": arrival[0] - previous_rows[key][0],
                 "max_arrival_gain_ns": previous_rows[key][1] - arrival[1]} for key, arrival in sorted(candidate.items())]
        result[label] = {"rows": rows, "endpoint_count": len(rows),
                         "minimum_max_arrival_gain_ns": min(row["max_arrival_gain_ns"] for row in rows),
                         "maximum_max_arrival_gain_ns": max(row["max_arrival_gain_ns"] for row in rows),
                         "all_max_arrivals_nonregressing": all(row["max_arrival_gain_ns"] >= 0 for row in rows)}
    return result


def authenticate_guidance(record, guide):
    trust = read(guide / "comparison.json")["artifact_sha256"]
    require(all(trust.get(relative(guide / name)) == sha(guide / name) for name in ready.ARTIFACT_NAMES),
            "guidance route no longer matches its completed independent comparison")
    authenticated_digest(record, guide / "run.json")
    authenticated_digest(record, guide / "comparison.json")


def authenticate_comb_selection(record):
    guide = Path(ready.argument(record["command"], "--remap-comb-critical"))
    require(guide == comb.GUIDE_REPORT, "comb guidance report changed")
    authenticated_digest(record, guide, ("comb_report_sha256", "comb_remap_report_sha256", "remap_comb_report_sha256"))
    candidate = int(ready.argument(record["command"], "--remap-comb-candidate"))
    require(candidate >= 0, "full route did not select a comb candidate")
    for alias in ("comb_candidate", "comb_remap_candidate", "remap_comb_candidate"):
        if alias in record:
            require(type(record[alias]) is int and record[alias] == candidate, "comb candidate alias changed")
    return candidate


def reprove_two_root_guide(item, control, old_ready):
    """Prove the two-stage control directly, without a comparison() recursion."""
    record, log = item["record"], item["log"]
    _, _, steps = authenticate_plan(record)
    require(len(steps) == 2 and item["path"] == TWO_ROOT_CONTROL, "third guide must be the completed two-root control")
    authenticate_compiler(record)
    previous.authenticate_inputs(record)
    ready.authenticate_execution(record, control["record"])
    for guide in (COMB_G4, READY_CONTROL):
        authenticate_guidance(record, guide)
    require(fixed_command(record["command"]) == fixed_command(control["record"]["command"]) and
            record["experimental_capture_locality"] == control["record"]["experimental_capture_locality"] and
            record["experimental_placed_reduction"] == control["record"]["experimental_placed_reduction"],
            "two-root guidance route changed its fixed transform inputs")
    authenticated_digest(record, BASE / "timing.json", ("capture_report_sha256",))
    authenticated_digest(record, CONTROL / "run.json", ("control_run_sha256",))
    for option, filename in (("--write", "routed.json"), ("--report", "timing.json"), ("--rbf", "core.rbf")):
        require(ready.argument(record["command"], option) == str(TWO_ROOT_CONTROL / filename), "two-root guide output path changed")
    metrics = previous.PLACEMENT_METRICS.findall(log)
    require(metrics == previous.PLACEMENT_METRICS.findall(control["log"]) and len(metrics) == 71,
            "two-root guide ordinary placement metrics changed")
    models = [selected_local(block, step) for step, block in zip(steps, plan_blocks(log, steps))]
    comb_model = comb.selected_candidate(log, authenticate_comb_selection(record))
    proof = compare_netlists(control["cells"], item["cells"], steps, models, old_ready["report"], comb_model,
                             read(CONTROL / "routed.json")["modules"]["top"]["netnames"],
                             read(TWO_ROOT_CONTROL / "routed.json")["modules"]["top"]["netnames"])
    require(proof["local_clone_count"] == 2 and proof["comb_clone_count"] == 1 and proof["added_clone_count"] == 3,
            "two-root guide accepted graph differs from its two-stage profile")
    require(set(item["report"]["fmax"]) == set(ready.REQUIRED_CLOCKS) and
            all(item["report"]["fmax"][clock]["constraint"] >= nominal for clock, nominal in ready.REQUIRED_CLOCKS.items()),
            "two-root guide required clocks/nominal constraints changed")
    proof.update({"transform_stack": ready.transform_stack(log, control["log"]), "matched_placement_metrics": len(metrics),
                  "fmax_vs_control_115": previous.compare_clocks(control["report"], item["report"]),
                  "guide_reproved_without_recursive_comparison": True})
    return proof


def comparison(folder):
    record = read(folder / "run.json")
    listing = record.get("list_only", False)
    require(type(listing) is bool and type(record.get("exit_code")) is int and
            type(record.get("elapsed_seconds")) in (int, float) and math.isfinite(record["elapsed_seconds"]), "candidate metadata is not final")
    success = record.get("completed") is True and record["exit_code"] == 0
    require(success or record["exit_code"] != 0 and record.get("failure"), "unfinished candidate metadata")
    plan_file, plan_sha, steps = authenticate_plan(record, listing)
    control_paths = {"baseline_108": BASE, "control_115": CONTROL, "ready_control_113": READY_CONTROL,
                     "comb_ready_g1": COMB_G1, "comb_ready_g4": COMB_G4}
    guides = [COMB_G4, READY_CONTROL]
    if len(steps) == 3:
        third_guide = steps[2]["report_path"].parent
        third_label = "comb_ready_g8" if third_guide == COMB_G8 else "two_root_control"
        require(folder != third_guide, "third-stage route cannot supply its own guidance")
        control_paths[third_label] = third_guide
        guides.append(third_guide)
    artifacts = [p / name for p in control_paths.values() for name in ready.ARTIFACT_NAMES]
    artifacts += [p / name for p in (HERE, comb.HERE, ready.FROZEN, ready.PIN_ORDER)
                  for name in ("source-identity.json", "source.tar.gz", "nextpnr-mistral")]
    artifacts += [plan_file, folder / "run.json", folder / "route.log", Path(__file__).resolve(),
                  HERE / "route.py", HERE / "freeze.py", COMB_HELPER,
                  comb.READY_HELPER, ready.PREVIOUS_HELPER, RAW / "validated-nextpnr-mistral",
                  RAW / "nextpnr-slots-fixed-source.tar.gz", RAW / "slot-fixed-source-hashes.json"]
    artifacts += [guide / "comparison.json" for guide in guides]
    if "two_root_control" in control_paths:
        guide_record = read(TWO_ROOT_CONTROL / "run.json")
        artifacts.append(Path(ready.argument(guide_record["command"], "--remap-plan")))
    artifacts += [Path(path) for path in record["input_sha256"]]
    if success:
        artifacts += [folder / "placed.json"] if listing else [folder / n for n in ("timing.json", "routed.json", "core.rbf")]
    artifacts = list(dict.fromkeys(artifacts))
    digests = {p: sha(p) for p in artifacts}
    inputs = previous.authenticate_inputs(record)
    source, parent_source = authenticate_compiler(record)
    controls = {}
    for label, path in control_paths.items():
        r, t, c, l, e = previous.route_evidence(path)
        item = {"path": path, "record": r, "report": t, "cells": c, "log": l, "route": e}
        item["authenticated_inputs"] = previous.authenticate_inputs(r, RAW / "validated-nextpnr-mistral" if label == "baseline_108" else None)
        if label == "baseline_108":
            item["source"] = previous.verify_archive(RAW / "nextpnr-slots-fixed-source.tar.gz", read(RAW / "slot-fixed-source-hashes.json"))
        elif path.parent == comb.HERE:
            item["source"], _ = comb.authenticate_compiler(r)
        elif path.parent == HERE:
            item["source"], _ = authenticate_compiler(r)
        else:
            item["source"] = previous.source_identity(ready.FROZEN, r)
        require(r["build_id"] == record["build_id"], "fixed synthesis BUILD_ID changed")
        controls[label] = item
    for guide in guides:
        authenticate_guidance(record, guide)
    if "comb_ready_g8" in controls:
        # Repeat the pure legacy helper's full structural and Boolean checks;
        # the third guide is not trusted solely because comparison.json exists.
        g8_proof = comb.comparison(COMB_G8)
        require(g8_proof["ready_group_budget"] == 8 and g8_proof["added_clone_count"] == 1 and
                g8_proof["composed_cut_equivalence"]["equivalent"] and
                g8_proof["ready_group_extension"]["group1_clone_equivalence"]["equivalent"] and
                g8_proof["all_original_buffers_preserved"] and g8_proof["matched_placement_metrics"] == 71,
                "frozen g8 guide no longer passes its full independent graph/Boolean proof")
        controls["comb_ready_g8"]["structural_proof"] = {
            key: g8_proof[key] for key in ("common_ff_cells", "original_lut_cells", "added_clone_count",
                "ff_placements_identical", "original_lut_placements_identical", "all_original_buffers_preserved",
                "all_original_logical_pin_states_preserved", "all_unselected_original_logical_connections_preserved",
                "ready_group_extension", "composed_cut_equivalence", "matched_placement_metrics")}
    if "two_root_control" in controls:
        controls["two_root_control"]["structural_proof"] = reprove_two_root_guide(
            controls["two_root_control"], controls["control_115"], controls["ready_control_113"])
    control_record = controls["control_115"]["record"]
    expected_fixed = fixed_command(control_record["command"])
    current_fixed = fixed_command(record["command"])
    if listing:
        # Listing deliberately omits the GPU selector and compressed RBF flag.
        omitted = {"--router", "--gpu-device", "--compress-rbf"}
        expected_fixed = [pair for pair in expected_fixed if pair[0] not in omitted]
    require(current_fixed == expected_fixed and all(fixed_command(item["record"]["command"]) ==
            fixed_command(control_record["command"]) for item in controls.values()), "fixed route command changed")
    for option in ("--json", "--qsf", "--sdc"):
        path = ready.argument(record["command"], option)
        expected = record["input_sha256"].get(path)
        require(expected and all(ready.argument(item["record"]["command"], option) == path and
                                item["record"]["input_sha256"].get(path) == expected for item in controls.values()),
                "fixed synthesis/constraint input changed: " + option)
    require(record["experimental_capture_locality"] == control_record["experimental_capture_locality"] ==
            str(BASE / "timing.json") + " 64 24" and record["experimental_placed_reduction"] ==
            control_record["experimental_placed_reduction"] == previous.ROOT_CELL + " 6 0", "capture/placed-reduction options changed")
    capture_sha = authenticated_digest(record, BASE / "timing.json", ("capture_report_sha256",))
    require(record.get("control_run_sha256") == sha(CONTROL / "run.json"), "full115 control metadata changed")
    authenticated_digest(record, CONTROL / "run.json")
    ready.authenticate_execution(record, control_record)
    log = (folder / "route.log").read_text()
    metrics = previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and all(previous.PLACEMENT_METRICS.findall(item["log"]) == metrics for item in controls.values()),
            "the 71 ordinary HeAP placement metrics changed")
    blocks = plan_blocks(log, steps, success)
    common = {"status": "experimental staged remap; unselected", "build_id": record["build_id"],
              "compiler_commit": record.get("compiler_commit"), "base_compiler_commit": source["base_commit"],
              "elapsed_seconds": record["elapsed_seconds"], "candidate_completed": success,
              "exit_code": record["exit_code"], "list_only": listing,
              "plan_path": relative(plan_file), "plan_sha256": plan_sha,
              "local_plan_stage_count": len(steps), "optional_third_stage": len(steps) == 3,
              "optional_third_guide": relative(steps[2]["report_path"]) if len(steps) == 3 else None,
              "plan_steps": [{k: v for k, v in step.items() if k != "report_json" and k != "report_path"} |
                             {"report_path": relative(step["report_path"])} for step in steps],
              "source": source, "compiler_parent_664599": parent_source, "authenticated_inputs": inputs,
              "controls": {label: {"path": relative(item["path"]), "source": item["source"], "route": item["route"],
                                   "authenticated_inputs": item["authenticated_inputs"],
                                   **({"structural_proof": item["structural_proof"]} if "structural_proof" in item else {})}
                           for label, item in controls.items()},
              "capture_report_sha256": capture_sha, "placement_metrics_identical": True, "matched_placement_metrics": len(metrics),
              "placement_metrics_sha256": hashlib.sha256("\n".join(metrics).encode()).hexdigest(),
              "execution_inputs_authenticated": True, "remap_log": [line for line in log.splitlines() if "remap" in line.lower()],
              "default_recipe_selected": False, "hardware_tested": False}
    if not success:
        require("Running the GPU router" not in log and not (folder / "core.rbf").exists() and
                not (folder / "routed.json").exists(), "failed staged trial produced/started a route")
        common.update({"status": "staged trial failed before route; no route acceptance", "failure": record["failure"],
                       "route_started": False, "graph_proof_available": False,
                       "accepted_stage_logs": [selected_local(block, step) for step, block in zip(steps, blocks)
                           if f"Local remap applied candidate {step['candidate']};" in block],
                       "candidate_route": None})
    elif listing:
        require("Info: Program finished normally." in log and "Running the GPU router" not in log and
                not (folder / "core.rbf").exists(), "host-only listing route status changed")
        selected_steps = steps[:-1]
        models = [selected_local(block, step) for step, block in zip(selected_steps, blocks)]
        top = read(folder / "placed.json")["modules"]["top"]
        old_top = read(CONTROL / "routed.json")["modules"]["top"]
        placement = compare_listing(old_top, top, selected_steps, models)
        common.update({**placement, "status": "host-only final-step listing; partial graph evidence; no route acceptance",
                       "graph_proof_available": False, "partial_graph_evidence_available": True,
                       "route_started": False, "candidate_route": None})
    else:
        r, report, cells, routed_log, route = previous.route_evidence(folder)
        require(r == record and routed_log == log, "candidate metadata changed during load")
        for option, filename in (("--write", "routed.json"), ("--report", "timing.json"), ("--rbf", "core.rbf")):
            require(ready.argument(record["command"], option) == str(folder / filename), "output path mismatch: " + option)
        require(set(report["fmax"]) == set(ready.REQUIRED_CLOCKS) and all(report["fmax"][clock]["constraint"] >= nominal
            for clock, nominal in ready.REQUIRED_CLOCKS.items()), "required clock set/nominal constraint changed")
        comb_candidate = authenticate_comb_selection(record)
        comb_model = comb.selected_candidate(log, comb_candidate)
        models = [selected_local(block, step) for step, block in zip(steps, blocks)]
        placement = compare_netlists(controls["control_115"]["cells"], cells, steps, models,
                                    controls["ready_control_113"]["report"], comb_model,
                                    read(CONTROL / "routed.json")["modules"]["top"]["netnames"],
                                    read(folder / "routed.json")["modules"]["top"]["netnames"])
        stacked = ready.transform_stack(log, controls["control_115"]["log"])
        clocks = {label: previous.compare_clocks(item["report"], report) for label, item in controls.items()}
        arrivals = {"candidate": report, **{label: item["report"] for label, item in controls.items()}}
        selected = placement["selected_internal_lut_inputs"][0]
        common.update({**placement, "candidate_route": route, "graph_proof_available": True, "route_started": True,
                       "transform_stack": stacked, "selected_comb_candidate": comb_model, "fmax_comparisons": clocks,
                       "all_clock_nonregression": {label: all(row["gain_mhz"] >= 0 for row in rows.values()) for label, rows in clocks.items()},
                       "passes_all_clock_constraints": all(row["meets_constraint"] for row in clocks["control_115"].values()),
                       "memory_improved_vs_115": clocks["control_115"][ready.MEMORY_CLOCK]["gain_mhz"] > 0,
                       "passes_strict_diagnostic_gate_vs_115": all(row["gain_mhz"] >= 0 for row in clocks["control_115"].values()) and
                           clocks["control_115"][ready.MEMORY_CLOCK]["gain_mhz"] > 0 and not route["final_reported_hold_violations"],
                       "critical_path_comparisons": ready.critical_path_comparison(controls["control_115"]["report"], report),
                       "critical_memory_path": next(p for p in report["critical_paths"] if p["from"] == p["to"] == "posedge " + ready.MEMORY_CLOCK),
                       "selected_ena_arrival_comparisons": selected_ena_arrivals(placement["local_clone_equivalences"], arrivals),
                       "selected_comb_downstream_arrival_comparisons": comb.endpoint_arrival_comparison(cells, selected["sink"], arrivals)})
    require(all(sha(p) == digest for p, digest in digests.items()), "evidence changed during comparison")
    common.update({"artifact_sha256": {relative(p): digest for p, digest in digests.items()},
                   "final_metadata_stable_during_comparison": True})
    return common


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", nargs="?", default="route-c0-g1", help="finalized route/list directory under remap-plan-264")
    args = parser.parse_args()
    folder = (HERE / args.route).resolve()
    require(folder.parent == HERE, "candidate must be a direct directory under remap-plan-264")
    result = comparison(folder)
    (folder / "comparison.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    keys = ("status", "compiler_commit", "elapsed_seconds", "candidate_completed", "exit_code", "list_only",
            "local_plan_stage_count", "optional_third_stage", "optional_third_guide",
            "plan_path", "plan_sha256", "plan_steps", "candidate_route", "fmax_comparisons", "all_clock_nonregression",
            "passes_all_clock_constraints", "memory_improved_vs_115", "matched_placement_metrics", "common_ff_cells",
            "original_lut_cells", "ff_placements_identical", "original_lut_placements_identical", "added_clone_count",
            "local_clone_count", "comb_clone_count", "selected_ff_ena_count", "added_buffer_count", "removed_buffer_count",
            "graph_proof_available", "default_recipe_selected", "hardware_tested")
    print(json.dumps({key: result[key] for key in keys if key in result}, indent=2))


if __name__ == "__main__":
    main()
