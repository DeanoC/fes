"""Draft native-first proof of the separately activated narrow-search full route.

Every supplied graph remains unchanged. BUF outputs remain native drivers;
only explicitly proved reduction, AC and identity-buffer ledgers may differ.
The activation profile must bind a fresh staged-v2 proof and actual AC ordinal.
No benchmark/helper replay, chip query, compiler, test or route is invoked here.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

import seal_profile as seal

HERE, ROOT = seal.HERE, seal.ROOT
read, sha, require = seal.read, seal.sha, seal.require
PINS = "ABCDEF"
MARKER = "$decomposition$"
BUFFER_SHA = "220e0dc45b9948d746dc9372b6951bfe1566419ddc76a9ae4c2eda3b6ecef06c"
A_SHA = "0434ef77bf1b203cf6650de90f16e94c43a2807e7c5a79caad419479a17b574a"
PRIOR_VALIDATOR_SHA = "4d52fc7ca100bf94ff03003a0b02151b288c5f3d281789dfa6d642ab092492b1"
PRIOR_COMPARISON_SHA = "36b3f890ddfc02bdfbedd92078e05caff758fff37a1510fd76823cee9691e7b2"
PRIOR_REJECTION = "query-v3 validation: tuple list contains unsupported ordinary LAB coordinates/half"
PREVIOUS_SUPPLEMENTAL_VALIDATOR_SHA = "1bf733c782650ae172a15cbcb05bc6f9e04b847e7b29a70e4255c8d24ef232f6"
PREVIOUS_PIN_VALIDATOR_SHA = "0cbd075285bce58d9e4de98593dbae3f46f7286a989110f684ba203f7d174b12"
PREVIOUS_PIN_COMPARISON_SHA = "d0a8b72ed88a8aef84a98c504431c9bc5c0f393b6fb2682ec68c9b64dc05a18d"
PREVIOUS_PIN_REJECTION = "outside original full physical pin snapshot is incomplete: hps_ddr.f2sdram"
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
CONSTRAINTS = {MEMORY: 130.00520324707031, PIXEL: 74.25006866455078, CAPTURE: 130.00520324707031}
TARGET_MHZ = 116.27906799316406
BEL = re.compile(r"MISTRAL_(M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)")


def relative(path):
    target = Path(path).resolve()
    require(target.is_relative_to(ROOT), "artifact lies outside the active FES checkout")
    return str(target.relative_to(ROOT))


def serial(value):
    return json.loads(json.dumps(value))


def load_pinned(audit, identity, digest, name):
    require(type(digest) is str and re.fullmatch(r"[0-9a-f]{64}", digest), "proof module's reviewed digest is unset")
    if isinstance(identity, (str, Path)):
        identity = {"path": str(identity), "sha256": digest}
    require(type(identity) is dict and set(identity) == {"path", "sha256"} and identity["sha256"] == digest,
            "proof module lacks its exact reviewed identity")
    path = Path(identity["path"])
    audit.bind(path, digest)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def top(g8, path):
    document = g8.read_netlist(path)
    require(set(document["modules"]) == {"top"}, "unexpected routed module set")
    return document["modules"]["top"]


def triple(token):
    """Compatibility with pure Boolean helpers, never BUF transparency."""
    if token[0] == "cell":
        return tuple(token[1:])
    if token[0] == "constant" and token[1] in {"0", "1"}:
        return ("constant", int(token[1]))
    return tuple(token)


def native_token(token):
    require(len(token) == 3 and token[1:] == ("Q", 0), "unsupported scalar Boolean output")
    return ("cell", *token)


class NativeView:
    """Read-only Boolean adapter over independently built native tables.

    A MISTRAL_BUF.Q is always its own driver. expression() rejects buffers
    inside a selected Boolean cone instead of silently collapsing them.
    """
    def __init__(self, g8, buffers, native):
        self.g8, self.buffers, self.native = g8, buffers, native
        self.cells = native.cells
        self.drivers = {bit: triple(token) for bit, token in native.drivers.items()}
        self.direct_users = {triple(token): list(users) for token, users in native.users.items()}
        self.external_names, self.pll_ports = native.aliases, native.pll_ports

    def token(self, bit):
        return triple(self.native.token(bit))

    def inputs(self, name):
        result = {}
        for port, direction, bits, occurrence in self.native.entries[name]:
            if direction in {"input", "inout"}:
                key = (port, occurrence) if name in self.pll_ports else port
                result[key] = [self.token(bit) for bit in bits]
        return result

    def pin_states(self, name):
        return {pin: row[0] for pin, row in self.buffers._pins(self.g8, name, self.cells[name]).items()}

    def lut_inputs(self, name):
        cell, states = self.cells[name], self.pin_states(name)
        require(self.g8.ready.is_lut(cell), "Boolean cone includes a non-LUT native driver")
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        result = []
        for pin in PINS[:width]:
            state, bits = states.get(pin), cell["connections"].get(pin)
            if state in (1, 2):
                require(bits == [], "constant logical pin also has a native input")
                result.append(("constant", state - 1))
            else:
                require(state in (0, 3) and type(bits) is list and len(bits) == 1,
                        "selected LUT input lacks its actual scalar pin state")
                result.append(self.token(bits[0]))
        return result

    def expression(self, token, leaves, visited, stack=frozenset()):
        if token[0] == "constant":
            require(token[1] in (0, 1), "unknown Boolean constant")
            return token
        if token in leaves:
            return ("variable", token)
        require(len(token) == 3 and token[0] in self.cells and token[1:] == ("Q", 0) and token not in stack,
                "cyclic or unsupported native Boolean driver")
        name, states = token[0], self.pin_states(token[0])
        cell = self.cells[name]
        require(self.g8.ready.is_lut(cell) and states.get("Q") == 0,
                "selected Boolean cone has a BUF/non-LUT or inverted output")
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        value = cell["parameters"].get("LUT")
        require(2 <= width <= 6 and set(cell["parameters"]) == {"LUT"} and type(value) is str and
                len(value) == 1 << width and set(value) <= {"0", "1"}, "selected Boolean LUT mask is invalid")
        mask = int(value, 2)
        inverted = sum((states[pin] == 3) << bit for bit, pin in enumerate(PINS[:width]))
        effective = sum(((mask >> (row ^ inverted)) & 1) << row for row in range(1 << width))
        visited.add(name)
        return ("lut", effective, [self.expression(value, leaves, visited, stack | {token})
                                  for value in self.lut_inputs(name)])


def location(cell):
    match = BEL.fullmatch(cell.get("attributes", {}).get("NEXTPNR_BEL", ""))
    if match is None:
        return None
    kind, x, y, z = match.groups()
    x, y, z = int(x), int(y), int(z)
    require(0 <= z < 60 and (z % 6 >= 2 if kind == "FF" else z % 6 < 2), "invalid physical ALM position")
    return kind, x, y, z


def alm(cell):
    value = location(cell)
    require(value is not None, "declared cell lacks its actual ALM BEL")
    return value[1], value[2], value[3] // 6


def full_lut_shape(g8, buffers, view, name):
    cell = view.cells[name]
    require(g8.ready.is_lut(cell), "declared Boolean cell is not an ALUT2..6")
    width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
    ports = {**{pin: "input" for pin in PINS[:width]}, "Q": "output"}
    value = cell["parameters"].get("LUT")
    require(set(cell["parameters"]) == {"LUT"} and type(value) is str and len(value) == 1 << width and
            set(value) <= {"0", "1"} and cell["port_directions"] == ports and
            set(cell["connections"]) == set(ports), "actual scalar LUT schema changed")
    pins = buffers._pins(g8, name, cell)
    require(set(pins) == set(ports) and pins["Q"] == [0, "COMBOUT"],
            "actual LUT full pin/output snapshot is invalid")
    for pin in PINS[:width]:
        bits = cell["connections"][pin]
        require((pins[pin][0] in (0, 3) and len(pins[pin]) == 2 and type(bits) is list and len(bits) == 1) or
                (pins[pin][0] in (1, 2) and len(pins[pin]) == 1 and bits == []),
                "actual LUT pin state disagrees with its scalar/constant native connection")
    return width, pins


def physical_lut(g8, buffers, view, name):
    """Derive actual serialized pin mapping, including the LUT6 dual banks."""
    width, pins = full_lut_shape(g8, buffers, view, name)
    where = location(view.cells[name])
    require(where is not None and where[0] in {"COMB", "MCOMB"}, "actual selected LUT BEL is invalid")
    half = where[3] % 6
    physical = [pins[pin][1] for pin in PINS[:width] if pins[pin][0] in (0, 3)]
    require(len(physical) == len(set(physical)), "selected logical signal pins share a physical input")
    if width < 6:
        require(set(physical) <= {"A", "B", "D" if half else "C", f"E{half}", f"F{half}"},
                "actual selected LUT uses an invalid half-specific physical input")
        return {"cell": name, "width": width, "actual_pins": pins, "logical_rows_checked": 1 << width,
                "rbf_or_cram_bits_independently_decoded": False}
    require(all(pins[pin][0] in (0, 3) for pin in PINS) and
            physical == ["A", "B", "C", "D", f"E{half}", f"F{half}"],
            "six-input LUT differs from canonical all-connected dual-bank mapping")
    mask = int(view.cells[name]["parameters"]["LUT"], 2)
    addresses, native_rows, image = [], {}, 0
    for row in range(64):
        bits = {"A": 0, "B": 1, "C": 3 if row >= 32 else 2,
                "D": 2 if row >= 32 else 3, f"E{half}": 5, f"F{half}": 4}
        raw = {pin: (row >> bits[pin]) & 1 for pin in physical}
        native = sum((1 ^ raw[pin]) << bit for bit, pin in enumerate(physical))
        logical = sum((raw[pins[pin][1]] ^ (pins[pin][0] != 3)) << bit for bit, pin in enumerate(PINS))
        require(native not in native_rows, "dual-bank native permutation is not injective")
        native_rows[native] = row
        addresses.append(logical)
        image |= (1 ^ ((mask >> logical) & 1)) << row
    require(set(addresses) == set(native_rows) == set(range(64)), "dual-bank mapping loses a logical/native row")
    inverted = sum((pins[pin][0] == 3) << bit for bit, pin in enumerate(PINS))
    require(all(1 ^ ((image >> row) & 1) == (mask >> (native ^ inverted)) & 1
                for native, row in native_rows.items()), "derived physical image differs from actual pin-state truth")
    return {"cell": name, "width": 6, "actual_pins": pins, "logical_and_dual_bank_rows_checked": 64,
            "derived_active_low_half_pair_mask_hex": hex(image), "rbf_or_cram_bits_independently_decoded": False}


def changed_cell_schema(old, new, name):
    before, after = old.cells[name], new.cells[name]
    mutable = {"type", "parameters", "port_directions", "connections", "attributes"}
    require({key: value for key, value in before.items() if key not in mutable} ==
            {key: value for key, value in after.items() if key not in mutable}, "declared reduction changed unknown cell metadata")
    require(set(before["parameters"]) == set(after["parameters"]) == {"LUT"}, "declared reduction changed a non-LUT parameter")
    allowed = {"NEXTPNR_BEL", "FES_PINMAP_V1"}
    require({key: value for key, value in before["attributes"].items() if key not in allowed} ==
            {key: value for key, value in after["attributes"].items() if key not in allowed},
            "declared reduction changed source/strength/protection attributes")


def prove_reduction(g8, buffers, old, new, root, count, trial, cached_source):
    before_cone, before_literals, before_nodes = g8.ranking.cube(old, root)
    after_cone, after_literals, after_nodes = g8.ranking.cube(new, root)
    require(count in (11, 12) and len(before_cone) == len(after_cone) == 3 and
            len(before_literals) == len(after_literals) == count and before_cone == after_cone and
            before_literals == after_literals, "actual routed reduction source/function/support changed")
    boundary = sorted(before_literals)
    require(serial(boundary) == cached_source["external_boundary_order"] and
            [before_literals[token] for token in boundary] == cached_source["conditional_required_values"] and
            sorted(before_cone) == cached_source["source_cone"], "actual routed source differs from fresh conditional source identities")
    leaves = sorted(before_cone - {root})
    require(g8.previous.bel(old.cells[root]) == g8.previous.bel(new.cells[root]) and
            new.cells[root]["type"] == "MISTRAL_ALUT2" and int(new.cells[root]["parameters"]["LUT"], 2) == 8 and
            new.inputs(root) == {pin: [(name, "Q", 0)] for pin, name in zip("AB", leaves)},
            "shared reduction root moved or is not the fixed ordered two-leaf AND")
    require([g8.previous.bel(new.cells[name]) for name in leaves] == trial["leaf_bels"],
            "actual leaf BELs differ from fresh qualified selected placements")
    partitions = []
    for index, name in enumerate(leaves):
        width = (count + 1) // 2 if index == 0 else count // 2
        require(full_lut_shape(g8, buffers, new, name)[0] == width and
                new.direct_users.get((name, "Q", 0), []) == [(root, "AB"[index], 0)],
                "new leaf shape/private root user changed")
        tokens = new.lut_inputs(name)
        require(len(tokens) == len(set(tokens)) == width and set(tokens) <= set(boundary),
                "balanced leaf has a duplicated/new/non-signal input")
        partitions.append(set(tokens))
    require(partitions[0].isdisjoint(partitions[1]) and partitions[0] | partitions[1] == set(boundary),
            "two balanced leaves do not partition every original literal")
    for name in before_cone:
        changed_cell_schema(old, new, name)
    values_before, values_after = [], []
    visited_before, visited_after = set(), set()
    tree_before = old.expression((root, "Q", 0), set(boundary), visited_before)
    tree_after = new.expression((root, "Q", 0), set(boundary), visited_after)
    require(visited_before == visited_after == before_cone, "routed reduction contains an undeclared node")
    for row in range(1 << count):
        values = {token: (row >> bit) & 1 for bit, token in enumerate(boundary)}
        values_before.append(g8.previous.evaluate(tree_before, values))
        values_after.append(g8.previous.evaluate(tree_after, values))
    require(values_before == values_after and sum(values_before) == 1 and
            g8.essential(values_after, count) == set(range(count)), "actual routed full pin-state truth differs")
    return {"root": root, "reused_cells": sorted(before_cone), "boundary_order": boundary,
            "source_nodes": before_nodes, "actual_nodes": after_nodes,
            "assignments_checked": 1 << count, "true_rows": 1,
            "truth_sha256": hashlib.sha256(bytes(values_after)).hexdigest(), "fresh_selected_trial": trial,
            "actual_routed_pin_state_truth_proved": True,
            "physical_luts": [physical_lut(g8, buffers, new, name) for name in sorted(after_cone)]}, before_cone


def parent_ac(g8, old, proof):
    cached = proof["decomposition_equivalence_on_ready_aligned_original_graph"]
    require(cached["assignments_checked"] == 128 and cached["all_original_buffers_preserved"] is True,
            "accepted old AC lacks its artifact-bound exhaustive proof")
    details = [*cached["encoders"], cached["root"]]
    generated = {row["cell"] for row in details}
    require(len(generated) in (2, 3) and {name for name in old.cells if MARKER in name} == generated,
            "old generated AC owner set exceeds its cached declaration")
    for row in details:
        require(g8.ready.detail(row["cell"], old.cells[row["cell"]]) == row, "old generated AC actual detail changed")
    edge = cached["selected_internal_input"]
    root = tuple(edge["candidate_driver"])
    require(old.inputs(edge["sink"])[edge["port"]] == [root] and
            old.direct_users.get(root) == [(edge["sink"], edge["port"], 0)], "old AC selected redirect/private root changed")
    return cached, generated


def original_ac_edge(old, cached, sink, port):
    tokens = old.inputs(sink).get(port)
    require(type(tokens) is list and len(tokens) == 1, "fresh AC sink original input is nonscalar")
    prior = cached["selected_internal_input"]
    if (sink, port) == (prior["sink"], prior["port"]):
        require(tokens == [tuple(prior["candidate_driver"])], "old selected AC edge is stale")
        return tuple(prior["control_driver"])
    return tokens[0]


def prove_ac(g8, buffers, old, new, cached, trial, staged_top):
    added = {name for name in new.cells if MARKER in name}
    require(len(added) in (2, 3) and all(g8.ready.is_lut(new.cells[name]) for name in added),
            "fresh generated AC owner set is not exactly one/two encoders plus root")
    roots = []
    for name in added:
        users = new.direct_users.get((name, "Q", 0), [])
        outside = [row for row in users if row[0] not in added]
        if outside:
            require(len(users) == len(outside) == 1 and outside[0][2] == 0, "new AC root has an undeclared user")
            roots.append((name, *outside[0][:2]))
    require(len(roots) == 1, "fresh AC root/sink cannot be uniquely discovered from native connectivity")
    root, sink, port = roots[0]
    original = original_ac_edge(old, cached, sink, port)
    require(original == (trial["original_root"], "Q", 0) and (sink, port) == (trial["sink"], trial["port"]) and
            new.inputs(sink)[port] == [(root, "Q", 0)] and sink not in added,
            "actual fresh root/sink differs from fresh qualified guidance")
    encoders = sorted(added - {root})
    require(len(encoders) == trial["encoder_count"] and
            g8.previous.bel(new.cells[root]) == trial["root_bel"] and
            [g8.previous.bel(new.cells[name]) for name in encoders] == trial["code_bels"],
            "actual fresh AC geometry differs from qualified definition/trial")
    bound = set()
    for name in encoders:
        width, _ = full_lut_shape(g8, buffers, new, name)
        tokens = new.lut_inputs(name)
        require(2 <= width <= 4 and len(set(tokens)) == width and all(
            len(token) == 3 and token[0] in old.cells and token[1:] == ("Q", 0) for token in tokens),
            "encoder uses a duplicated/non-original bound input")
        bound.update(tokens)
    outputs = {(name, "Q", 0) for name in encoders}
    width, _ = full_lut_shape(g8, buffers, new, root)
    root_inputs = new.lut_inputs(root)
    free = set(root_inputs) - outputs
    require(width == 3 + len(encoders) and len(set(root_inputs)) == width and outputs <= set(root_inputs) and
            len(bound) == 4 and len(free) == 3 and not bound & free and all(
            len(token) == 3 and token[0] in old.cells and token[1:] == ("Q", 0) for token in free),
            "fresh actual bound-four/free-three partition is invalid")
    boundary = sorted(bound | free)
    for token in boundary:
        require(old.pin_states(token[0]).get("Q") == new.pin_states(token[0]).get("Q") == 0,
                "original boundary output has an unsupported/changed polarity")
    visited_before, visited_after = set(), set()
    # The fresh source is the retained four-LUT cone in the actual new native
    # graph, before following its separately declared generated sink edge.
    tree_before = new.expression(original, set(boundary), visited_before)
    tree_after = new.expression((root, "Q", 0), set(boundary), visited_after)
    require(len(visited_before) == 4 and original[0] in visited_before and sink not in visited_before and
            visited_after == added, "actual old/new AC cone is not four originals and only generated clones")
    for name in visited_before:
        full_lut_shape(g8, buffers, new, name)
    values, rows = [], []
    for row in range(128):
        assignment = {token: (row >> index) & 1 for index, token in enumerate(boundary)}
        before, after = g8.previous.evaluate(tree_before, assignment), g8.previous.evaluate(tree_after, assignment)
        require(before == after, "actual AC128 truth differs at row " + str(row))
        values.append(before)
        rows.append({"row": row, "original": before, "decomposed": after})
    require(g8.essential(values, 7) == set(range(7)), "fresh original AC support is not seven essential inputs")
    for name in sorted(added):
        tokens = new.lut_inputs(name)
        expression = new.expression((name, "Q", 0), set(tokens), set())
        table = [g8.previous.evaluate(expression, {token: (row >> index) & 1 for index, token in enumerate(tokens)})
                 for row in range(1 << len(tokens))]
        require(g8.essential(table, len(tokens)) == set(range(len(tokens))), "generated AC LUT has an unpruned input")
    bound, free = sorted(bound), sorted(free)
    encoder_trees = [new.expression(token, set(bound), set()) for token in sorted(outputs)]
    root_tree = new.expression((root, "Q", 0), set(free) | outputs, set())
    columns, codes = [], []
    for row in range(16):
        assignment = {token: (row >> index) & 1 for index, token in enumerate(bound)}
        codes.append(sum(g8.previous.evaluate(tree, assignment) << index for index, tree in enumerate(encoder_trees)))
        column = 0
        for free_row in range(8):
            current = {**assignment, **{token: (free_row >> index) & 1 for index, token in enumerate(free)}}
            column |= g8.previous.evaluate(tree_before, current) << free_row
        columns.append(column)
    require(2 <= len(set(columns)) <= 1 << len(encoders) and len(encoders) == (len(set(columns)) - 1).bit_length() and
            all((columns[a] == columns[b]) == (codes[a] == codes[b]) for a in range(16) for b in range(16)),
            "actual AC code assignment is not an injective encoding of cofactor classes")
    for code in set(range(1 << len(encoders))) - set(codes):
        for row in range(8):
            assignment = {token: (row >> index) & 1 for index, token in enumerate(free)}
            assignment.update({token: (code >> index) & 1 for index, token in enumerate(sorted(outputs))})
            require(g8.previous.evaluate(root_tree, assignment) == 0, "unused AC code is not zero-completed")
    for output in outputs:
        users = [(root, pin, 0) for pin, tokens in new.inputs(root).items() if tokens == [output]]
        require(len(users) == 1 and new.direct_users.get(output, []) == users, "encoder output is not private to one root pin")
    occupied = {}
    for name, cell in staged_top["cells"].items():
        where = location(cell)
        if where:
            occupied.setdefault((where[1], where[2], where[3] // 6), []).append(name)
    _, labs = buffers._lab_rows(new.native.top)
    occupants = buffers._occupants(new.native, set())
    geometry = []
    for name in sorted(added):
        key = alm(new.cells[name])
        require(not occupied.get(key) and labs[key[:2]][2] == 0 and
                labs[key[:2]][3][2 + 6 * key[2]:4 + 6 * key[2]] == [0, 0],
                "fresh AC clone shares an original pre-AC occupant or unsupported LAB mode")
        actual = occupants.get(key, [])
        require(all(owner in added and kind != "FF" for owner, kind, _ in actual),
                "fresh AC ALM acquired an undeclared original FF/BUF/LUT occupant")
        require(sum(int(new.cells[owner]["type"].removeprefix("MISTRAL_ALUT")) for owner, _, _ in actual) <= 8,
                "fresh AC occupied ALM exceeds dual-LUT input capacity")
        geometry.append({"cell": name, "alm": key, "pre_ac_original_occupants": [],
                         "actual_joint_alm_truth": buffers._alm_mask(g8, new.native, key, occupants)})
    return {"selected_internal_input": {"sink": sink, "port": port, "control_driver": original,
                                        "candidate_driver": (root, "Q", 0)},
            "original_cut_nodes": sorted(visited_before), "boundary_order": boundary,
            "bound_inputs": bound, "free_inputs": free, "root": g8.ready.detail(root, new.cells[root]),
            "encoders": [g8.ready.detail(name, new.cells[name]) for name in encoders],
            "assignments_checked": 128, "true_rows": sum(values), "truth_rows": rows,
            "cofactor_columns": columns, "encoder_codes": codes, "unused_codes_zero_completed": True,
            "actual_routed_logical_pin_truth_proved": True, "clone_alm_isolation": geometry,
            "physical_luts": [physical_lut(g8, buffers, new, name) for name in sorted(added)]}, added


def private_ac_nets(view, cells):
    result = set()
    for name in cells:
        bit = view.cells[name]["connections"]["Q"][0]
        aliases = view.native.aliases.get(bit, [])
        require(len(aliases) == 1 and aliases[0][1] == 0 and not view.native.top_users.get(bit),
                "AC Q does not have one independent private scalar named alias")
        alias = aliases[0][0]
        net = view.native.top["netnames"][alias]
        require(set(net) == {"hide_name", "bits", "attributes"} and type(net["hide_name"]) is int and
                net["hide_name"] in (0, 1) and len(net["bits"]) == 1 and set(net["attributes"]) == {"ROUTING"},
                "AC Q alias has extra semantic metadata or a non-scalar shape")
        result.add(alias)
    require(len(result) == len(cells), "generated AC cells share a named Q net")
    return result


def exact_scope(g8, old, new, staged_top, cones, old_ac, ac, prior, phase):
    declared = {tuple(row) for row in phase["allowed_alms"]}
    require(len(declared) == len(phase["allowed_alms"]), "predeclared ALM scope contains duplicates")
    new_sites = [ac["root"]["bel"], *[row["bel"] for row in ac["encoders"]]]
    expected = {alm(view.cells[name]) for view in (old, new) for cone in cones for name in cone}
    expected.update(alm(old.cells[name]) for name in old_ac)
    expected.update(alm(new.cells[row["cell"]]) for row in [ac["root"], *ac["encoders"]])
    require(declared == expected and serial(sorted(expected)) == prior["allowed_alms"],
            "actual selected old/new reduction/AC ALMs differ from the exact pre-run declaration")
    for cone in cones:
        require(all(staged_top["cells"][name]["attributes"]["NEXTPNR_BEL"] ==
                    new.cells[name]["attributes"]["NEXTPNR_BEL"] for name in cone),
                "actual reused-cell site differs from the authenticated fresh pre-AC placement")
    eligible = sorted(name for name, cell in old.cells.items() if cell["type"] == "MISTRAL_FF" and alm(cell) in expected)
    rows = prior["eligible_ffs"]
    require(type(rows) is list and eligible == sorted(row["cell"] for row in rows) and len(rows) == len(eligible),
            "predeclared eligible FF population differs from actual fixed FF ALMs")
    halves = set()
    for row in rows:
        cell = old.cells[row["cell"]]
        where = location(cell)
        digest_value = lambda value: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
        require(set(row) == {"cell", "bel", "alm", "ff_slot", "old_full_cell_sha256", "old_full_pinmap_sha256"} and
                row["bel"] == g8.previous.bel(cell) and row["alm"] == list(alm(cell)) and row["ff_slot"] == where[3] % 6 and
                row["old_full_cell_sha256"] == digest_value(cell) and
                row["old_full_pinmap_sha256"] == digest_value(cell["attributes"]["FES_PINMAP_V1"]),
                "predeclared eligible FF state/BEL/pin hash differs from the actual accepted full")
        halves.add((*alm(cell), (where[3] % 6 - 2) // 2))
    require(serial(sorted(halves)) == prior["eligible_halves"] == phase["scope"]["eligible_buffer_halves"],
            "predeclared eligible buffer halves differ from exact fixed FF pairing")
    return {"allowed_alms": sorted(expected), "eligible_ffs": eligible, "eligible_halves": sorted(halves),
            "eligible_original_ff_rows": rows, "actual_fresh_ac_bels": new_sites,
            "scope_fixed_before_route": True, "whole_lab_or_after_route_scope_broadening": False}


def ff_ena_declaration(old, new, ac):
    edge = ac["selected_internal_input"]
    sink, port = edge["sink"], edge["port"]
    if old.cells[sink]["type"] != "MISTRAL_FF":
        return []
    require(port == "ENA", "fresh AC selected FF input is not the bounded ENA class")
    if old.inputs(sink)[port] == new.inputs(sink)[port]:
        # A rerun may reuse the generated root's name. Its actual function is
        # separately proved, while this ledger declares only native edges.
        return []
    return [{"ff": sink, "port": "ENA", "index": 0,
             "before_native_driver": list(old.native.connections[sink][port][0]),
             "after_native_driver": list(new.native.connections[sink][port][0])}]


def boolean_consumer_scope(view):
    # Frozen consumers() indexes every supplied old name before skipping BUF.
    # Only its Boolean-cell scope is narrowed; actual Native tables, drivers,
    # ports and all BUF records remain independently checked and unchanged.
    scoped = copy.copy(view)
    scoped.cells = {name: cell for name, cell in view.cells.items() if cell["type"] != "MISTRAL_BUF"}
    return scoped


def retained_functions(g8, old_control, new, phase, log, accepted, comb_guide, audit):
    old_control, new = boolean_consumer_scope(old_control), boolean_consumer_scope(new)
    # The actual plan stays untouched. The pure helper API consumes decoded
    # reports and an observed zero-based stage index, as its frozen reader does.
    steps = []
    for index, step in enumerate(phase["local_steps"]):
        report_path = Path(step["report"])
        require(report_path.is_absolute(), "retained local report is not the authenticated absolute path")
        report_sha256 = accepted["artifact_sha256"][relative(report_path)]
        audit.bind(report_path, report_sha256)
        report_json = read(report_path)
        require(type(report_json.get("critical_paths")) is list, "retained local guide lacks critical paths")
        steps.append({**step, "index": index, "report_path": report_path,
                      "report_sha256": report_sha256, "report_json": report_json})
    models = g8.local_models(log, {"local_steps": steps})
    cached = accepted["retained_local_clone_equivalences"]
    require(len(models) == len(cached) == len(phase["local_steps"]) == 3, "retained local stage count changed")
    proofs = []
    for step, model, prior in zip(steps, models, cached):
        clone, users = g8.discover_local_users(old_control, new, model)
        require(clone == prior["clone"]["cell"] and serial(model) == prior["selected_stage_log"],
                "retained local clone identity/selected model changed")
        proofs.append(g8.staged.prove_local(old_control, new, clone, users, step, model))
    prior = accepted["retained_comb_equivalence"]
    composed = g8.comb.prove_cut(old_control, new, prior["clone"]["cell"], [prior["selected_internal_input"]],
                                comb_guide, g8.comb.selected_candidate(log, 0))
    require([row["assignments_checked"] for row in proofs] == [32, 16, 16] and composed["assignments_checked"] == 32,
            "retained local/comb full function proof row counts changed")
    return {"local_clones": proofs, "comb_clone": composed, "native_buffer_transparency_used": False,
            "boolean_consumer_scope": "actual non-BUF cells only; full native BUF/user ledger is proved separately",
            "native_graphs_or_driver_tokens_changed": False, "missing_buffer_cells_fabricated": False}


def selected_log_prefix(g8, log, staged_log, specs, selected_ac, trial):
    pattern = r"^Info: Decomposition discovery: \d+ bounded seven-input cuts\.$"
    starts, prior_starts = list(re.finditer(pattern, log, re.M)), list(re.finditer(pattern, staged_log, re.M))
    require(len(starts) == len(prior_starts) == 1, "actual/staged fresh AC discovery is absent or repeated")
    placed, prior_placed = log[:starts[0].start()], staged_log[:prior_starts[0].start()]
    headers = list(re.finditer(r"^Info: Placed reduction stage (\d+): root=(\S+) radius=(\d+) selection=(-?\d+)\.$", placed, re.M))
    require(len(headers) == len(specs) == 2 and all(match.groups() ==
            (str(index), spec["root"], str(spec["radius"]), str(spec["candidate"]))
            for index, (match, spec) in enumerate(zip(headers, specs))), "actual selected-stage headers differ from the sealed two stages")
    markers = ("Placed reduction", "Placed-reduction", "Balanced three-LUT reduction", "Balanced four-LUT reduction",
               "Enable replication", "Local-remap plan step ", "Local remap ", "Comb remap ", "Capture locality")
    messages = lambda value: [line for line in value.splitlines() if any(marker in line for marker in markers)]
    require(messages(placed) == messages(prior_placed) and
            not any(any(marker in line for marker in markers) for line in log[starts[0].start():].splitlines()),
            "retained and actual selected11/12 discovery/guard/BEL/candidate prefix differs from fresh staged-v2")
    actual_ac, prior_ac = log[starts[0].start():], staged_log[prior_starts[0].start():]
    actual_candidates, prior_candidates = list(g8.CANDIDATE.finditer(actual_ac)), list(g8.CANDIDATE.finditer(prior_ac))
    require(len(actual_candidates) == selected_ac + 1 and len(prior_candidates) > selected_ac and
            actual_candidates[-1].group(0) == trial["candidate_log"] == prior_candidates[selected_ac].group(0),
            "actual selected AC ordinal/candidate is not its fresh qualified listing row")
    decomp_messages = lambda value: [line for line in value.splitlines() if "Info: Decomposition" in line]
    require(decomp_messages(actual_ac[:actual_candidates[-1].end()]) ==
            decomp_messages(prior_ac[:prior_candidates[selected_ac].end()]) and
            trial["trial_log"] in actual_ac[:actual_candidates[-1].start()],
            "actual fresh AC definition/geometry/guards prefix differs from its complete staged-v2 listing")
    return actual_ac


def restored_ac_guide_reference(g8, buffers, new, ac):
    """Algebra-only copy after the native/function ledgers have passed.

    Restore just the independently proved fresh selected input and remove its
    private generated closure. No run record, timing or original graph changes.
    """
    edge = ac["selected_internal_input"]
    generated = {ac["root"]["cell"], *(row["cell"] for row in ac["encoders"])}
    private = private_ac_nets(new, generated)
    source = native_token(tuple(edge["control_driver"]))
    bits = [bit for bit, token in new.native.drivers.items() if token == source]
    require(len(bits) == 1, "fresh original root has no unique native output bit")
    reference = copy.deepcopy(new.native.top)
    reference["cells"][edge["sink"]]["connections"][edge["port"]] = bits
    for name in generated:
        del reference["cells"][name]
    for name in private:
        del reference["netnames"][name]
    return NativeView(g8, buffers, buffers.Native(reference)), {
        "restored_original_input": edge, "removed_generated_cells": sorted(generated), "removed_private_q_nets": sorted(private),
        "reference_is_algebraic_not_an_independent_route_or_timing_baseline": True,
        "actual_graph_or_record_mutated": False}


def require_exported_pin_coverage(g8, buffers, name, cell):
    """Cover raw pin names retained by save_fes_pin_maps after JSON grouping.

    Cell JSON groups zero-based indexed ports into vectors without exporting
    their offset. Missing indices and unsupported nonzero offsets fail closed.
    A disconnected scalar is exported as [] but still requires its raw pin.
    """
    pins = buffers._pins(g8, name, cell)
    for port, bits in cell["connections"].items():
        require(type(bits) is list, "outside original port vector is malformed: " + name + "." + port)
        if len(bits) <= 1:
            covered = port in pins or port + "[0]" in pins
        else:
            covered = all(port + "[" + str(index) + "]" in pins for index in range(len(bits)))
        require(covered, "outside original full physical pin snapshot is incomplete: " + name + "." + port)


def outside_native(g8, buffers, old, new, cones, old_ac, new_ac, cached_ac, ac, ledger, staged_top):
    changed = set().union(*cones)
    removed_buffers = {row["cell"] for row in ledger["removed_buffers"]}
    added_buffers = {row["cell"] for row in ledger["added_buffers"]}
    original = set(old.cells) - old_ac - removed_buffers
    require(set(new.cells) == original | new_ac | added_buffers,
            "actual cell owner changes exceed declared reused cells/old-new AC/private buffers")
    exceptions = {(row["ff"], "DATAIN"): (tuple(row["before_native_driver"]), tuple(row["after_native_driver"]))
                  for row in ledger["permitted_original_ff_datain_deltas"]}
    old_edge, new_edge = cached_ac["selected_internal_input"], ac["selected_internal_input"]
    for sink, port in {(old_edge["sink"], old_edge["port"]), (new_edge["sink"], new_edge["port"])}:
        before = old.native.connections[sink][port]
        after = new.native.connections[sink][port]
        require(len(before) == len(after) == 1 and (sink, port) not in exceptions,
                "AC restore/redirect overlaps a buffered DATAIN exception")
        expected = native_token(tuple(new_edge["candidate_driver"])) if (sink, port) == (new_edge["sink"], new_edge["port"]) \
            else native_token(tuple(old_edge["control_driver"]))
        require(after == [expected], "AC old restoration/fresh redirect is not exact")
        exceptions[(sink, port)] = (before[0], expected)
    altered_edges = []
    for name in sorted(original):
        a, b = old.cells[name], new.cells[name]
        if name in changed:
            continue
        require(buffers._metadata(a) == buffers._metadata(b), "outside original params/type/BEL/full pins/metadata changed: " + name)
        require_exported_pin_coverage(g8, buffers, name, a)
        require_exported_pin_coverage(g8, buffers, name, b)
        before, after = old.native.connections[name], new.native.connections[name]
        require(set(before) == set(after), "outside original named port set changed")
        for port in before:
            if before[port] == after[port]:
                continue
            declared = exceptions.get((name, port))
            require(declared is not None and before[port] == [declared[0]] and after[port] == [declared[1]],
                    "unproved outside native port change: " + name + "." + str(port))
            altered_edges.append({"cell": name, "port": port, "before": before[port], "after": after[port]})
    require(all(name not in changed and name in original for name, _ in exceptions),
            "a declared BUF/AC sink overlaps reused cells or lies outside originals")
    # Native.users is reconstructed independently from every actual input.
    # A complete port ledger, not a collapsed graph, closes every user triple.
    expected_users = {}
    for name in new.cells:
        if name in changed or name in new_ac or name in added_buffers:
            entries = new.native.entries[name]
            for port, direction, bits, _ in entries:
                if direction in {"input", "inout"}:
                    for index, bit in enumerate(bits):
                        expected_users.setdefault(new.native.token(bit), []).append((name, port, index))
            continue
        for port, direction, bits, _ in old.native.entries[name]:
            if direction in {"input", "inout"}:
                for index, bit in enumerate(bits):
                    replacement = exceptions.get((name, port))
                    token = replacement[1] if replacement else old.native.token(bit)
                    expected_users.setdefault(token, []).append((name, port, index))
    require({token: sorted(users) for token, users in expected_users.items()} == new.native.users,
            "actual native input user triples differ from the complete declared edge ledger")
    old_private = private_ac_nets(old, old_ac)
    new_private = private_ac_nets(new, new_ac)
    require(old_private == set(cached_ac["added_private_q_nets"]), "old generated AC alias closure changed")
    old_private.update(row["name"] for row in ledger["permitted_private_q_alias_deltas"] if row["operation"] == "remove")
    new_private.update(row["name"] for row in ledger["permitted_private_q_alias_deltas"] if row["operation"] == "add")
    before_nets, after_nets = old.native.top["netnames"], new.native.top["netnames"]
    require(set(before_nets) - old_private == set(after_nets) - new_private,
            "named net changes exceed independent AC Q and declared BUF private aliases")
    for name in set(before_nets) - old_private:
        a, b = before_nets[name], after_nets[name]
        require({key: value for key, value in a.items() if key not in {"bits", "attributes"}} ==
                {key: value for key, value in b.items() if key not in {"bits", "attributes"}} and
                {key: value for key, value in a["attributes"].items() if key != "ROUTING"} ==
                {key: value for key, value in b["attributes"].items() if key != "ROUTING"} and
                [old.native.token(bit) for bit in a["bits"]] == [new.native.token(bit) for bit in b["bits"]],
                "original net alias/native identity or semantic metadata changed: " + name)
    g8.ranking.top_ports(old.native.top, new.native.top, old, new)
    pll = g8.pll_port_audit(old, new)
    orders = {}
    for dictionary in ("cells", "netnames"):
        reference = list(staged_top[dictionary])
        observed = [name for name in new.native.top[dictionary] if name in staged_top[dictionary]]
        require(observed == reference, "pre-existing relative export owner order changed")
        additions = new_ac if dictionary == "cells" else private_ac_nets(new, new_ac)
        filtered = [name for name in new.native.top[dictionary] if name in staged_top[dictionary] or name in additions]
        require(filtered[:len(reference)] == reference and set(filtered[len(reference):]) == additions,
                "fresh AC owners precede the filtered pre-existing non-BUF owner prefix")
        orders[dictionary] = {"original_count": len(reference), "relative_order_and_filtered_prefix_exact": True,
                              "route_created_buf_owners_not_used_as_transaction_order_evidence": True}
    require({key: value for key, value in old.native.top.items() if key not in {"cells", "netnames", "ports", "attributes"}} ==
            {key: value for key, value in new.native.top.items() if key not in {"cells", "netnames", "ports", "attributes"}} and
            {key: value for key, value in old.native.top["attributes"].items() if key != "FES_LABSTATE_V1"} ==
            {key: value for key, value in new.native.top["attributes"].items() if key != "FES_LABSTATE_V1"},
            "unrelated full-route module metadata/settings changed")
    return {"outside_original_ff_lut_hardcell_params_bels_full_exported_pins_exact": True,
            "outside_connected_bit_and_empty_scalar_pin_coverage_checked_on_both_graphs": True,
            "only_independently_proved_native_port_deltas": altered_edges,
            "complete_native_consumer_triples_closed": True, "original_net_aliases_and_public_ports_preserved": True,
            "lossless_pll_port_audit": pll, "owner_export_order": orders,
            "indexed_user_slots_free_lists_owner_buckets_or_gpu_ids_proved": False,
            "unexported_duplicate_pll_pin_occurrences_not_inferred": True,
            "route_wires_or_pips_required_identical_to_parent": False}


def timing_gates(report, parent, log, record):
    require(set(report["fmax"]) == set(parent["fmax"]) == set(CONSTRAINTS), "required clock set changed")
    clocks = {}
    for clock, constraint in CONSTRAINTS.items():
        a, b = parent["fmax"][clock], report["fmax"][clock]
        require(set(a) == set(b) == {"achieved", "constraint"} and a["constraint"] == b["constraint"] == constraint and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in (a, b) for value in row.values()),
                "actual finite positive clocks/quantized constraints differ")
        clocks[clock] = {"before_mhz": a["achieved"], "after_mhz": b["achieved"], "constraint_mhz": constraint,
                         "gain_mhz": b["achieved"] - a["achieved"], "constraint_passed": b["achieved"] >= constraint}
    require(clocks[MEMORY]["before_mhz"] == TARGET_MHZ, "accepted target-memory baseline changed")
    def paths(document):
        result = {}
        for path in document["critical_paths"]:
            key = (path["from"], path["to"])
            require(key not in result and type(path["max_delay"]) in (int, float) and math.isfinite(path["max_delay"]),
                    "critical clock-pair window is duplicate/nonfinite")
            result[key] = path
        return result
    before, after = paths(parent), paths(report)
    require(len(before) == len(after) == 6 and set(before) == set(after), "required six clock-pair windows changed")
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    capture = ("posedge " + CAPTURE, "negedge " + MEMORY)
    require(before[capture]["max_delay"] == after[capture]["max_delay"] == 5, "capture phase window differs from accepted5ns")
    windows = []
    for key, path in after.items():
        require(path["max_delay"] == before[key]["max_delay"] and path["path"], "required actual clock-pair budget changed")
        segments = path["path"]
        require(segments[-1]["type"] == "setup" and sum(row["type"] == "setup" for row in segments) == 1 and
                sum(row["type"] == "clk-skew" for row in segments) <= 1 and all(
                row["type"] in {"clk-skew", "clk-to-q", "source", "routing", "logic", "setup"} and
                type(row["delay"]) in (int, float) and math.isfinite(row["delay"]) for row in segments),
                "actual path contains missing setup, duplicate skew or nonfinite/unknown terms")
        total = math.fsum(row["delay"] for row in segments)
        headroom = path["max_delay"] - total
        require(math.isfinite(total) and math.isfinite(headroom), "complete path sum is nonfinite")
        windows.append({"from": key[0], "to": key[1], "window_ns": path["max_delay"],
                        "complete_delay_ns": total, "setup_headroom_ns": headroom,
                        "positive_headroom_required": key != target, "passes_window": key == target or headroom > 0})
    require("Running signoff timing analysis..." in log, "actual final signoff block is absent")
    hold = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
    require(record["fmax"] == report["fmax"] and record["final_reported_hold_violations"] is hold,
            "final hold/Fmax run metadata disagrees with actual outputs")
    practical = clocks[MEMORY]["gain_mhz"] > 0 and all(clocks[clock]["constraint_passed"] for clock in (PIXEL, CAPTURE)) and \
        all(row["passes_window"] for row in windows) and not hold
    strict = all(row["gain_mhz"] >= 0 for row in clocks.values())
    return {"passes_practical_timing_gate": practical, "all_clock_fmax_nonregression_vs_accepted_g8": strict,
            "passes_all_required_clock_constraints": all(row["constraint_passed"] for row in clocks.values()),
            "target_memory_gain_mhz": clocks[MEMORY]["gain_mhz"], "memory_130mhz_closed": clocks[MEMORY]["constraint_passed"],
            "clocks": clocks, "required_related_windows": windows, "final_reported_hold_violations": hold,
            "non_target_fmax_nonregression_is_not_a_practical_requirement": True,
            "lower_positive_non_target_headroom_is_disclosed": True}


def comparison(folder, query_binding_path=None, query_binding_sha256=None):
    folder = folder.resolve()
    context = seal.load_profile()
    profile, g8, base, source, control, prior = context
    audit = prior["audit"]
    audit.bind(HERE / "compare_full.py", PRIOR_VALIDATOR_SHA)
    audit.bind(HERE / "compare_full_v2.py", PREVIOUS_SUPPLEMENTAL_VALIDATOR_SHA)
    audit.bind(HERE / "compare_full_v3.py", PREVIOUS_PIN_VALIDATOR_SHA)
    audit.bind(folder / "comparison.json", PRIOR_COMPARISON_SHA)
    audit.bind(folder / "comparison-v3.json", PREVIOUS_PIN_COMPARISON_SHA)
    prior_comparison = read(folder / "comparison.json")
    require(prior_comparison["graph_proof_available"] is False and
            prior_comparison["candidate_accepted_under_confirmed_target_clock_rule"] is False and
            prior_comparison["structural_rejection"] == PRIOR_REJECTION,
            "prior immutable validator type-rejection record changed")
    previous_pin_comparison = read(folder / "comparison-v3.json")
    require(previous_pin_comparison["graph_proof_available"] is False and
            previous_pin_comparison["candidate_accepted_under_confirmed_target_clock_rule"] is False and
            previous_pin_comparison["structural_rejection"] == PREVIOUS_PIN_REJECTION,
            "prior immutable validator grouped-pin rejection record changed")
    for path in (Path(__file__).resolve(), HERE / "seal_profile.py", HERE / "route.py", seal.PROFILE,
                 *(folder / name for name in ("run.json", "route.log", "routed.json", "timing.json", "core.rbf"))):
        audit.bind(path)
    record = read(folder / "run.json")
    phase = seal.authenticate_phase(record, context=context)
    require(phase["phase"] == "route" and phase["folder"].resolve() == folder and record["completed"] is True and
            type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0 and not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel")),
            "full phase is not a finalized normally completed authenticated route")
    require(type(phase["ac_selection"]) is int and phase["ac_selection"] >= 0 and
            record["decomposition_selection"] == phase["ac_selection"] and phase["ac_trial"] == prior["ac_trial"],
            "fresh AC qualification/selected ordinal is absent or changed")
    log = (folder / "route.log").read_text()
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            "Running the GPU router" in log and (folder / "core.rbf").stat().st_size > 0,
            "full route/compiler/GPU/RBF outputs did not complete normally")
    for filename, digest in record["input_sha256"].items():
        audit.bind(Path(filename), digest)
    for filename, digest in record["execution"]["files"].items():
        audit.bind(Path(filename), digest, execution=True)
    staged_record, staged_proof = prior["staged_record"], prior["staged_proof"]
    require(staged_record["compiler_commit"] == record["compiler_commit"] == source["result_commit"] and
            staged_proof["candidate_completed"] is True and staged_proof["partial_graph_evidence_available"] is True and
            staged_proof["graph_proof_available"] is False and phase["ac_selection"] in staged_proof["qualified_ac_ordinals"],
            "fresh actual staged-v2 AC qualification is not artifact-bound")
    staged_folder = Path(staged_record["command"][staged_record["command"].index("--write") + 1]).parent
    require(staged_folder.parent.name == "narrow-search-staged-v2-264", "full profile refers to superseded failed staged phase")
    for name in ("run.json", "route.log", "placed.json", "comparison.json"):
        audit.bind(staged_folder / name)
    staged_log = (staged_folder / "route.log").read_text()
    metrics = g8.previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and metrics == g8.previous.PLACEMENT_METRICS.findall(staged_log) and
            hashlib.sha256("\n".join(metrics).encode()).hexdigest() == staged_proof["placement_metrics_sha256"],
            "ordinary actual placement metrics differ from fresh staged-v2")
    ac_log = selected_log_prefix(g8, log, staged_log, phase["specs"], phase["ac_selection"], phase["ac_trial"])
    # Parse losslessly and construct native drivers/users before any Boolean
    # utilities or explicit reference-copy operation.
    actual_before = top(g8, prior["fast"].FULL / "routed.json")
    actual_after = top(g8, folder / "routed.json")
    staged_top = top(g8, staged_folder / "placed.json")
    buffers = load_pinned(audit, prior["buffer_module"], BUFFER_SHA, "narrow_full_native_buffers_v2")
    old_native, new_native = buffers.Native(actual_before), buffers.Native(actual_after)
    old, new = NativeView(g8, buffers, old_native), NativeView(g8, buffers, new_native)
    report = read(folder / "timing.json")
    parent_report = read(prior["fast"].FULL / "timing.json")
    timing = timing_gates(report, parent_report, log, record)
    evidence, rejection = {}, None
    try:
        cached_ac, old_ac = parent_ac(g8, old, prior["accepted_proof"])
        specs, trials = phase["specs"], prior["selected_trials"]
        require(len(specs) == len(trials) == 2 and specs[0]["candidate"] == 0 and specs[1]["candidate"] == 0,
                "fresh selected reduction stages/ordinals differ from the activated profile")
        cones = []
        for index, (spec, trial, count) in enumerate(zip(specs, trials, (11, 12))):
            cached = staged_proof["applied_eleven_evidence" if index == 0 else "applied_twelve_evidence"]["source_conditional_cube"]
            proof, cone = prove_reduction(g8, buffers, old, new, spec["root"], count, trial, cached)
            evidence["selected_eleven" if index == 0 else "selected_twelve"] = proof
            cones.append(cone)
        require(cones[0].isdisjoint(cones[1]), "selected11/12 original reused cones overlap")
        ac, new_ac = prove_ac(g8, buffers, old, new, cached_ac, phase["ac_trial"], staged_top)
        evidence["fresh_ac128"] = ac
        scope = exact_scope(g8, old, new, staged_top, cones, old_ac, ac, prior, phase)
        evidence["predeclared_physical_scope"] = scope
        declared_ena = ff_ena_declaration(old, new, ac)
        ledger = buffers.prove_buffers(g8, actual_before, actual_after, phase["allowed_alms"], declared_ena)
        require(all(row["ff"] in scope["eligible_ffs"] for row in ledger["permitted_original_ff_datain_deltas"]),
                "actual changed-buffer FF lies outside the predeclared eligible population")
        evidence["native_buffer_equivalence"] = ledger
        delta_count = len(ledger["removed_buffers"]) + len(ledger["added_buffers"])
        if delta_count == 0:
            require(query_binding_path is None and query_binding_sha256 is None,
                    "zero changed BUFs must not attach an unused query payload")
            evidence["buffer_A_route_equivalence"] = {"buffer_A_native_route_proof_available": True,
                "vacuous_no_buffer_additions_or_removals": True, "changed_buffer_count": 0,
                "buffer_A_routes": [], "query_required": False, "query_executed_by_this_module": False,
                "unchanged_buffer_metadata_native_connections_users_and_full_pins_proved_by_native_ledger": True}
        else:
            require(query_binding_path is not None and type(query_binding_sha256) is str,
                    "mandatory actual queried BUF.A binding is unavailable; no physical full proof")
            query_path = Path(query_binding_path).absolute()
            audit.bind(query_path, query_binding_sha256)
            query = read(query_path)
            require(query["schema"] == 2 and set(query["scope"]) == {"path", "sha256"},
                    "actual supplemental query lacks its v3 immutable scope identity")
            query_scope_path = Path(query["scope"]["path"])
            audit.bind(query_scope_path, query["scope"]["sha256"])
            query_scope = read(query_scope_path)
            require(query_scope["reference_kind"] == "full_profile" and
                    query_scope["reference"] == {"path": str(seal.PROFILE), "sha256": sha(seal.PROFILE)} and
                    query_scope["eligible_halves"] == serial(scope["eligible_halves"]),
                    "supplemental query scope does not name this exact pre-run full profile/eligible halves")
            require(seal.A_V3_SHA == A_SHA and prior["scope_manifest"] == phase["scope"],
                    "actual v3 bridge identity or pre-run scope changed")
            a_routes = load_pinned(audit, prior["a_module"], A_SHA, "narrow_full_buffer_A_routes_v3")
            a_proof = a_routes.prove_buffer_a_routes(g8, actual_before, actual_after, ledger, query,
                                                    query["validation"]["sha256"], serial(scope["eligible_halves"]))
            for filename, digest in a_proof["authenticated_file_sha256"].items():
                audit.bind(Path(filename), digest, execution=not Path(filename).resolve().is_relative_to(ROOT))
            evidence["buffer_A_route_equivalence"] = a_proof
        control_path = g8.staged.CONTROL / "routed.json"
        audit.bind(control_path, prior["accepted_proof"]["artifact_sha256"][relative(control_path)])
        comb_guide_path = Path(g8.comb.GUIDE_REPORT)
        audit.bind(comb_guide_path, prior["accepted_proof"]["artifact_sha256"][relative(comb_guide_path)])
        control_native = buffers.Native(top(g8, control_path))
        evidence["retained_stack"] = retained_functions(g8, NativeView(g8, buffers, control_native), new,
                                                        phase, log, prior["accepted_proof"], read(comb_guide_path), audit)
        evidence["outside_original_native_graph"] = outside_native(g8, buffers, old, new, cones, old_ac, new_ac,
                                                                   cached_ac, ac, ledger, staged_top)
        guide_path = Path(phase["report_path"])
        audit.bind(guide_path, phase["report_sha256"])
        reference, reference_proof = restored_ac_guide_reference(g8, buffers, new, ac)
        evidence["fresh_actual_guide_path_indices"] = g8.relevant_guide_edges(reference, ac["selected_internal_input"], read(guide_path))
        evidence["guide_reference_after_native_and_function_proof"] = reference_proof
        evidence["actual_fresh_ac_selected_log"] = g8.verify_decomposition_log(ac_log, phase["ac_selection"], ac)
    except ValueError as error:
        rejection = str(error)
    graph_proved = rejection is None
    audit.finish()
    return {"phase": "route", "compiler_commit": source["result_commit"], "candidate_completed": True,
            "validator_sha256": sha(Path(__file__)), "prior_validator_sha256": PRIOR_VALIDATOR_SHA,
            "previous_supplemental_validator_sha256": PREVIOUS_SUPPLEMENTAL_VALIDATOR_SHA,
            "previous_pin_validator_sha256": PREVIOUS_PIN_VALIDATOR_SHA,
            "previous_pin_comparison_sha256": PREVIOUS_PIN_COMPARISON_SHA,
            "previous_pin_structural_rejection": PREVIOUS_PIN_REJECTION,
            "prior_comparison_sha256": PRIOR_COMPARISON_SHA, "prior_structural_rejection": PRIOR_REJECTION,
            "prior_rejection_record_preserved": True,
            "validator_change": "Retain prior supplemental corrections and check exporter-grouped cell vectors against every raw indexed pin, with scalar or indexed-zero coverage including empty scalar ports on both graphs; exact full pin snapshot metadata equality, native BUF/user proofs, actual graphs, physical scope, plan and gates remain unchanged.",
            "comparison_is_postroute_supplemental_revalidation": True,
            "elapsed_seconds": record["elapsed_seconds"], "profile_sha256": sha(seal.PROFILE),
            "graph_proof_available": graph_proved, "structural_rejection": rejection,
            "native_original_graphs_built_before_function_or_buffer_interpretation": True,
            "native_buffer_outputs_collapsed": False, "original_graphs_mutated_or_globally_normalized": False,
            "backend_route_checks": {"successful_nonempty_rbf_and_normal_exit": True,
                "genuine_mistral_pips_accepted_by_same_chipdb_rnode_link": True,
                "synthetic_wire_pips_skipped_by_rnode_link": True,
                "synthetic_edges_from_fixed_arch_adjacency_and_binding_checks": True,
                "changed_ff_ingress_buf_pins_and_a_ancestry_proved": graph_proved,
                "independent_every_exported_pip_topology_proof": False},
            "full_physical_evidence": evidence, "raw_timing": timing,
            "passes_practical_timing_gate": graph_proved and timing["passes_practical_timing_gate"],
            "passes_strict_diagnostic_gate_vs_accepted_g8": graph_proved and timing["passes_practical_timing_gate"] and
                                                          timing["all_clock_fmax_nonregression_vs_accepted_g8"],
            "candidate_accepted_under_confirmed_target_clock_rule": graph_proved and timing["passes_practical_timing_gate"],
            "matched_ordinary_placement_metrics": 71,
            "cached_old_comparisons_reexecuted": False, "qualification_inherited_from_old_runs": False,
            "default_recipe_selected": False, "hardware_tested": False,
            "final_metadata_stable_during_comparison": True,
            "artifact_sha256": dict(sorted(audit.artifacts.items())),
            "execution_file_sha256": dict(sorted(audit.execution.items())),
            "proof_limitations": ["Actual native drivers and named consumer triples are proved; indexed-store slot/free-list/bucket or GPU ID state is not serialized.",
                                  "Physical LUT images are derived from actual serialized pin states and occupancy; RBF/CRAM bits are not independently decoded.",
                                  "PLL duplicate output occurrences are preserved losslessly; absent per-occurrence physical PLL pins are not invented.",
                                  "Cell vector pin coverage uses the exporter's zero-based raw indexed names; missing indices or unsupported nonzero offsets reject proof, and empty scalar ports still require their raw pin entry.",
                                  "Successful RBF generation checks every genuine Mistral pip through the same chipdb rnode_link; synthetic local edges use fixed Arch adjacency/binding plus changed FF/BUF pin/ingress/A ancestry proofs. This is not an independent exported-pip or RBF decoder.",
                                  "A missing or unsupported actual physical-port query rejects full physical proof; cached diagnostic lookup never authorizes other coordinates.",
                                  "Practical acceptance requires target memory gain, required non-target constraints/positive windows and zero final holds; reduced positive non-target headroom is disclosed."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--query-binding", type=Path)
    parser.add_argument("--query-binding-sha256")
    args = parser.parse_args()
    require(not (args.folder / "comparison-v4.json").exists(), "comparison-v4 output already exists")
    require((args.query_binding is None) == (args.query_binding_sha256 is None),
            "supplemental query requires both its original path and expected digest")
    result = comparison(args.folder, args.query_binding, args.query_binding_sha256)
    with (args.folder / "comparison-v4.json").open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({key: result[key] for key in ("graph_proof_available", "structural_rejection",
                                                "candidate_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__":
    main()
