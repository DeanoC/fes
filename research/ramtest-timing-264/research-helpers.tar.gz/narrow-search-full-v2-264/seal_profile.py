"""Root-only full route with a fresh selected11/12/AC stack.

Cached completed proofs are artifact-bound once through the staged flat audit.
The allowed late-buffer ALMs and fixed FF halves are sealed before execution.
The old coordinate-specific BUF.A query is diagnostic evidence only; actual
post-route query evidence must separately close every changed buffer.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
INITIAL = RAW / "narrow-search-264"
STAGED = RAW / "narrow-search-staged-v2-264"
STAGED_FOLDER = STAGED / "list-ac-e0-t0"
STAGED_PROFILE = STAGED / "profile.json"
STAGED_PROOF = STAGED_FOLDER / "comparison.json"
STAGED_SEAL_SHA = "7dc6b84bd276224e402f4d7f30d3f4212ff3c353fc823bd24474104795fa9a0c"
STAGED_RUNNER_SHA = "8a243535940585b770d97067b80ccc01e914df257eaa28445410f997bc703aff"
STAGED_COMPARATOR_SHA = "c6e4faaa21eeb129eaaa8d2b111b6110609a6d4b90bfc5850f861b2a01d6703e"
STAGED_PROFILE_SHA = "94ceb5dd0dd67ee87ae93831c5af8c4d2bb9c90b4ab324beb89c96527affafab"
# These are the completed root-operated fresh AC listing, never old AC ranking.
STAGED_PROOF_SHA = "05f720f7f5b220ccff7e1cfd1af8842b0edd65ac88bccf4a40c69ee4506b452e"
SELECTED_AC = 0
PROFILE = HERE / "profile.json"
PHASES = ("route",)
MINIMUM_PS, DEFAULT_MINIMUM_PS = 200, 250
MINIMUM_LOG = "Info: Placed reduction minimum branch gain: 200ps."
TARGET_FMAX = 116.27906799316406
PROOF_DIR = RAW / "narrow-search-route-264"
PLAN_PATH = PROOF_DIR / "route-equivalence-plan.json"
PLAN_SHA = "164862996efc5550dd64d801444533846700f127d6b75ff060a19a8550c642bf"
BUFFER_PATH = PROOF_DIR / "prove_route_buffers_v2.py"
BUFFER_SHA = "220e0dc45b9948d746dc9372b6951bfe1566419ddc76a9ae4c2eda3b6ecef06c"
A_PATH = PROOF_DIR / "prove_buffer_a_routes.py"
A_SHA = "900afadc2b62ca9f636418eafcb1c8c8745b4e9b3a83918066f5044136d299f4"
# Separately reviewed generic supplemental protocol, pinned before full launch.
# Root must receive the final peer hashes before this profile can be sealed.
A_V3_PATH = PROOF_DIR / "prove_buffer_a_routes_v3.py"
A_V3_SHA = "0434ef77bf1b203cf6650de90f16e94c43a2807e7c5a79caad419479a17b574a"
QUERY_V3_PATH = PROOF_DIR / "validate_port_query_v3.py"
QUERY_V3_SHA = "52d06cc9c70fe5c809ccc2920f8298d466a541fd1b763d5e1ab79015570a655e"
DIAGNOSTIC_FILES = {
    "diagnose_route_buffers_v2_checked.py": "3fcdb8c363391f3694b18d7108fb3fc97166c3793c78778e0a48f63275596b23",
    "diagnostic-buffer-v2-checked.json": "e29d44004852ded5d13dfd75394f1c8ccdf2c0fd2863c98332bf66543aad2463",
    "diagnostic-query-binding.json": "a679109995d8294c44403fd5ce41af408c96633a49f853a3d7ac8c6acd10ee56",
    "port-query-validation.json": "6e49f085d244789713eb6ea75b3ca33b8024b7e0fa09feaa0ead3dcc1da0c857",
    "validate_port_query.py": "af662b0b1f00691fb7beac8ed3d00a127ddc621dfbc1f56cae461b1ae4a343f7",
    "physical_port_query_v2.cc": "da48e2de2b0ab817bb03fe721f9c3246c4b7bd1adeaa4beec95a82fb01693360",
    "physical_port_query_v2": "e5faaca4f116085156ed6c1ac866239801e9fe85b47177e0c26a83c1d51e77cf",
    "diagnose_buffer_a_routes.py": "33fc267802f1814bc0aba4c9d9efff1e0b0ded3c2a8e9d2f3d9a610c81964b40",
    "diagnostic-buffer-a-routes.json": "447cc617d1cd4883acfe07b31aba7112d8d84970bd404e542115472547642d54",
}
BEL = re.compile(r"MISTRAL_(M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)")
DIGEST = re.compile(r"[0-9a-f]{64}")
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite: " + value)))


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def relative(path):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT), "artifact escaped the checkout")
    return str(path.relative_to(ROOT))


def canonical(value):
    return json.loads(json.dumps(value, sort_keys=True, allow_nan=False))


def digest_value(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def location(value, kind=None):
    match = BEL.fullmatch(value)
    require(match is not None, "unsupported declared physical BEL: " + value)
    cell_kind, x, y, z = match.groups()
    x, y, z = int(x), int(y), int(z)
    require(0 <= z < 60 and (z % 6 >= 2 if cell_kind == "FF" else z % 6 < 2) and
            (kind is None or (cell_kind == "FF") == (kind == "FF")), "invalid declared BEL half")
    return [x, y, z // 6], z % 6


def actual_top(g8, path):
    document = g8.read_netlist(path)
    require(set(document["modules"]) == {"top"}, "unexpected actual export module set")
    return document["modules"]["top"]


def selected_ac_trial(g8, log, proof):
    require(type(SELECTED_AC) is int and SELECTED_AC >= 0 and SELECTED_AC in proof["qualified_ac_ordinals"],
            "selected AC ordinal lacks its fresh completed proof")
    candidates, pending, selected = [], None, None
    for line in log.splitlines():
        trial = g8.TRIAL.fullmatch(line)
        if trial:
            pending = {"original_root": trial[1], "sink": trial[2], "port": trial[3],
                "definition": int(trial[4]), "encoder_count": int(trial[5]), "root_bel": trial[6],
                "code_bels": trial[7].split(";"), "gain_ps": float(trial[8]),
                "guards": [int(trial[i]) for i in range(9, 14)], "trial_log": line}
        candidate = g8.CANDIDATE.fullmatch(line)
        if candidate:
            require(pending is not None and int(candidate[1]) == len(candidates) and
                [candidate[2], candidate[3], candidate[4], int(candidate[5]), float(candidate[6])] ==
                [pending["original_root"], pending["sink"], pending["port"], pending["encoder_count"], pending["gain_ps"]] and
                pending["guards"] == [1] * 5 and pending["gain_ps"] >= 250 and
                len(pending["code_bels"]) == pending["encoder_count"], "AC candidate has no matching guarded actual trial")
            row = {**pending, "candidate": int(candidate[1]), "candidate_log": line}
            candidates.append(row)
            if row["candidate"] == SELECTED_AC:
                selected = row
            pending = None
    require(selected is not None and proof["qualified_ac_ordinals"] == list(range(len(candidates))) and
        proof["fresh_ac_candidate_rows"] == [{"candidate": row["candidate"], "original_root": row["original_root"],
            "sink": row["sink"], "port": row["port"], "encoder_count": row["encoder_count"],
            "modeled_gain_ps": row["gain_ps"]} for row in candidates], "fresh AC proof/log ordinal rows disagree")
    return selected


def scope_for(g8, old_top, new_top, proof, ac, old_ac):
    declared, alms = [], set()
    for label, count in (("eleven", 11), ("twelve", 12)):
        evidence = proof["applied_" + label + "_evidence"]
        require(len(evidence["reused_cells"]) == 3 and evidence["root"] in evidence["reused_cells"] and
                evidence["actual_conditional_cube"]["assignments_checked"] == 1 << count,
                "selected reduction lacks its exact three-cell conditional proof")
        for name in evidence["reused_cells"]:
            old, new = old_top["cells"][name], new_top["cells"][name]
            require(old["type"].startswith("MISTRAL_ALUT") and new["type"].startswith("MISTRAL_ALUT"),
                    "declared reduction cell is not an actual original LUT")
            before, after = old["attributes"]["NEXTPNR_BEL"], new["attributes"]["NEXTPNR_BEL"]
            for bel in (before, after):
                alm, _ = location(bel, "COMB")
                alms.add(tuple(alm))
            declared.append({"stage": label, "cell": name, "before_bel": before, "after_bel": after})
        root = evidence["root"]
        require(old_top["cells"][root]["attributes"]["NEXTPNR_BEL"] ==
                new_top["cells"][root]["attributes"]["NEXTPNR_BEL"], "declared public root moved")
    old_clones = old_ac["encoders"] + [old_ac["root"]]
    for detail in old_clones:
        name, bel = detail["cell"], detail["bel"]
        require(old_top["cells"][name]["attributes"]["NEXTPNR_BEL"] == bel,
                "old AC proof does not bind its actual routed clone BEL")
        alm, _ = location(bel, "COMB")
        alms.add(tuple(alm))
        declared.append({"stage": "old_ac", "cell": name, "before_bel": bel})
    probe_bels = [ac["root_bel"], *ac["code_bels"]]
    require(len(probe_bels) == len(set(probe_bels)), "new AC probe has duplicate BELs")
    for index, bel in enumerate(probe_bels):
        alm, _ = location(bel, "COMB")
        alms.add(tuple(alm))
        declared.append({"stage": "new_ac_probe", "role": "root" if index == 0 else "code" + str(index - 1), "after_bel": bel})
    eligible = []
    for name, cell in old_top["cells"].items():
        if cell["type"] != "MISTRAL_FF":
            continue
        bel = cell["attributes"]["NEXTPNR_BEL"]
        alm, half = location(bel, "FF")
        if tuple(alm) in alms:
            require(name in new_top["cells"] and new_top["cells"][name]["type"] == "MISTRAL_FF" and
                    new_top["cells"][name]["attributes"]["NEXTPNR_BEL"] == bel, "eligible original FF moved in selected listing")
            require("FES_PINMAP_V1" in cell["attributes"], "old eligible FF has no physical snapshot")
            eligible.append({"cell": name, "bel": bel, "alm": alm, "ff_slot": half,
                "old_full_cell_sha256": digest_value(cell),
                "old_full_pinmap_sha256": digest_value(cell["attributes"]["FES_PINMAP_V1"])})
    halves = sorted({tuple(row["alm"] + [(row["ff_slot"] - 2) // 2]) for row in eligible})
    return {"schema": 1, "derivation": "authenticated old full and actual selected11/12 export plus fresh selected AC trial",
        "declared_cells_and_probe_sites": declared, "allowed_alms": [list(alm) for alm in sorted(alms)],
        "eligible_original_ffs": eligible, "eligible_buffer_halves": [list(half) for half in halves],
        "maximum_one_buffer_per_comb_half": True,
        "scope_was_derived_before_full_route": True, "postroute_observed_deltas_do_not_expand_scope": True,
        "source_export_sha256": sha(STAGED_FOLDER / "placed.json")}


def cached_context():
    require(type(STAGED_PROOF_SHA) is str and DIGEST.fullmatch(STAGED_PROOF_SHA) and
            type(SELECTED_AC) is int and SELECTED_AC >= 0, "fresh AC proof/ordinal is unpinned")
    require(all(type(value) is str and DIGEST.fullmatch(value) for value in (A_V3_SHA, QUERY_V3_SHA)),
            "generic post-route BUF.A bridge/validator code is not sealed before launch")
    require(sha(STAGED / "seal_profile.py") == STAGED_SEAL_SHA, "frozen staged-v2 seal changed")
    staged = module_at(STAGED / "seal_profile.py", "full_frozen_staged_v2")
    context = staged.load_profile()  # One shared flat closure for this entry.
    parent_profile, g8, base, source, control, prior = context
    audit, fast = prior["audit"], prior["fast"]
    for path, digest in ((STAGED / "seal_profile.py", STAGED_SEAL_SHA), (STAGED / "route.py", STAGED_RUNNER_SHA),
                         (STAGED / "compare_applied.py", STAGED_COMPARATOR_SHA), (STAGED_PROFILE, STAGED_PROFILE_SHA)):
        audit.bind(path, digest)
    for name in ("run.json", "route.log", "placed.json"):
        audit.bind(STAGED_FOLDER / name)
    record = read(STAGED_FOLDER / "run.json")
    phase = staged.authenticate_phase(record, context)
    require(record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0 and
        type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
        record["elapsed_seconds"] >= 0 and phase["folder"] == STAGED_FOLDER and
        not any(key in record for key in ("failure", "exit_code_is_adapter_sentinel", "fmax", "final_reported_hold_violations")),
        "fresh staged-v2 AC listing failed or has final route claims")
    proof = staged.bind_proof(audit, STAGED_PROOF, STAGED_PROOF_SHA)
    require(proof["phase"] == "list-ac" and proof["candidate_completed"] is True and
        proof["compiler_commit"] == source["result_commit"] and proof["profile_sha256"] == STAGED_PROFILE_SHA and
        proof["selected_eleven_ordinal"] == staged.SELECTED_ELEVEN == 0 and
        proof["selected_twelve_ordinal"] == staged.SELECTED_TWELVE == 0 and
        proof["parent_qualification_inherited"] is False and proof["fresh_selected12_qualification_used"] is True and
        proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False and
        proof["route_started"] is False and proof["timing_acceptance_available"] is False and
        proof["applied_ac128_equivalence_proof_available"] is False and
        proof["matched_placement_metrics"] == 71 and proof["placement_metrics_identical"] is True and
        proof["cached_old_comparisons_reexecuted"] is False and proof["final_metadata_stable_during_comparison"] is True and
        proof["fresh_ac_qualification"]["log_complete"] is True and proof["fresh_ac_qualification"]["none_applied"] is True,
        "staged proof is not a completed fresh partial qualification")
    require(all(proof["artifact_sha256"].get(relative(Path(path))) == digest for path, digest in record["input_sha256"].items()) and
        all(proof["artifact_sha256"].get(relative(STAGED_FOLDER / name)) == audit.bind(STAGED_FOLDER / name)
            for name in ("run.json", "route.log", "placed.json")) and
        proof["execution_file_sha256"] == record["execution"]["files"], "staged proof omits exact actual run/input/runtime closure")
    ac = selected_ac_trial(g8, (STAGED_FOLDER / "route.log").read_text(), proof)
    # The immutable accepted-g8 schema predates execution_file_sha256. Its
    # artifact closure and actual runtime were already authenticated by the
    # staged flat context; do not project a newer proof schema onto it.
    audit.bind(fast.FULL / "comparison.json", fast.FULL_PROOF_SHA)
    accepted = read(fast.FULL / "comparison.json")
    old_top = actual_top(g8, fast.FULL / "routed.json")
    new_top = actual_top(g8, STAGED_FOLDER / "placed.json")
    old_ac = accepted["decomposition_equivalence_on_ready_aligned_original_graph"]
    scope = scope_for(g8, old_top, new_top, proof, ac, old_ac)
    for path, digest in ((PLAN_PATH, PLAN_SHA), (BUFFER_PATH, BUFFER_SHA), (A_PATH, A_SHA)):
        audit.bind(path, digest)
    audit.bind(A_V3_PATH, A_V3_SHA)
    audit.bind(QUERY_V3_PATH, QUERY_V3_SHA)
    require(read(PLAN_PATH)["schema"] == 1, "predeclared route plan schema changed")
    for name, digest in DIAGNOSTIC_FILES.items():
        audit.bind(PROOF_DIR / name, digest)
    query_diagnostic = read(PROOF_DIR / "diagnostic-query-binding.json")
    # Bind producer dependency paths without treating the old two-row payload as
    # a semantic query for any future new route-through half.
    for key in ("dependency_sha256", "runtime_file_sha256"):
        for filename, digest in query_diagnostic.get(key, {}).items():
            path = Path(filename) if Path(filename).is_absolute() else ROOT / filename
            audit.bind(path, digest, execution=(key == "runtime_file_sha256" or not path.resolve().is_relative_to(ROOT)))
    exercise = read(PROOF_DIR / "diagnostic-buffer-a-routes.json")
    require(exercise["module_sha256"] == A_SHA and exercise["buffer_module_sha256"] == BUFFER_SHA and
        exercise["query_binding_sha256"] == DIAGNOSTIC_FILES["diagnostic-query-binding.json"] and
        exercise["wrapper_sha256"] == DIAGNOSTIC_FILES["diagnose_buffer_a_routes.py"] and
        exercise["diagnostic_only"] is True and exercise["final_original_path_hash_audit_passed"] is True and
        exercise["whole_graph_equivalence_proved"] is False and exercise["practical_acceptance"] is False,
        "host BUF.A exercise identity or diagnostic limits changed")
    for filename, digest in exercise["artifact_sha256"].items():
        require(not Path(filename).is_absolute(), "diagnostic artifact is not checkout relative")
        audit.bind(ROOT / filename, digest)
    for filename, digest in exercise["external_dependency_runtime_sha256"].items():
        audit.bind(Path(filename), digest, execution=True)
    return g8, base, source, control, {**prior, "staged": staged, "staged_profile": parent_profile,
        "staged_record": record, "staged_proof": proof, "record": record, "proof": proof,
        "accepted_record": base, "accepted_proof": accepted,
        "selected_trials": [proof["applied_eleven_evidence"]["selected_trial"], proof["applied_twelve_evidence"]["selected_trial"]],
        "ac_trial": ac, "allowed_alms": scope["allowed_alms"], "scope_manifest": scope,
        "eligible_ffs": scope["eligible_original_ffs"], "eligible_halves": scope["eligible_buffer_halves"],
        "buffer_module": BUFFER_PATH, "a_module": A_V3_PATH, "query_validator": QUERY_V3_PATH,
        "a_diagnostic_module": A_PATH, "query_diagnostic_binding_only": query_diagnostic,
        "a_exercise_diagnostic_only": exercise,
        "presealed_external_file_sha256": {str(path): digest for path, digest in sorted(audit.paths.items())
                                            if not path.resolve().is_relative_to(ROOT)}}


def phase_folder(phase="route"):
    require(phase in PHASES and type(SELECTED_AC) is int and SELECTED_AC >= 0, "full AC ordinal is unpinned")
    return HERE / f"route-e0-t0-ac{SELECTED_AC}"


def specifications(base, phase="route"):
    require(phase in PHASES, "unknown full phase")
    old = base["experimental_placed_reduction"].split()
    require(len(old) == 3 and old[1:] == ["6", "0"], "reference eleven diagnostic changed")
    return [{"root": old[0], "radius": 6, "candidate": 0, "minimum_branch_gain_ps": DEFAULT_MINIMUM_PS},
        {"root": "ddr0_test.group_valid_MISTRAL_ALUT6_E_F_MISTRAL_ALUT5_Q", "radius": 6,
         "candidate": 0, "minimum_branch_gain_ps": MINIMUM_PS}]


def expected_diagnostic_environment(base, phase="route"):
    first, second = specifications(base, phase)
    return {"NEXTPNR_MISTRAL_CAPTURE_LOCALITY": base["experimental_capture_locality"],
        "NEXTPNR_MISTRAL_PLACED_REDUCTION": f"{first['root']} 6 0\n{second['root']} 6 0 {MINIMUM_PS}"}


def expected_command(base, phase="route"):
    command = list(base["command"])
    require(phase in PHASES and "--no-route" not in command and "--gpu-opt" not in command and
        command.count("--router") == command.count("--gpu-device") == 1 and
        command[command.index("--router") + 1] == "gpu" and command[command.index("--gpu-device") + 1] == "1",
        "accepted reference command has unexpected route controls")
    command[0] = str(INITIAL / "nextpnr-mistral")
    for option, value in (("--remap-plan", str(INITIAL / "local-plan.json")),
        ("--write", str(phase_folder(phase) / "routed.json")), ("--report", str(phase_folder(phase) / "timing.json")),
        ("--rbf", str(phase_folder(phase) / "core.rbf")), ("--remap-decompose-candidate", str(SELECTED_AC))):
        require(command.count(option) == 1, "accepted command option is ambiguous: " + option)
        command[command.index(option) + 1] = value
    return command


def input_map(prior):
    audit, inputs = prior["audit"], dict(prior["staged_profile"]["input_sha256"])
    for filename, digest in prior["staged_proof"]["artifact_sha256"].items():
        path = str((ROOT / filename).resolve())
        require(path not in inputs or inputs[path] == digest, "conflicting cached artifact digest")
        inputs[path] = digest
    for path, digest in ((STAGED_PROFILE, STAGED_PROFILE_SHA), (STAGED_PROOF, STAGED_PROOF_SHA),
        (PLAN_PATH, PLAN_SHA), (BUFFER_PATH, BUFFER_SHA), (A_PATH, A_SHA),
        (A_V3_PATH, A_V3_SHA), (QUERY_V3_PATH, QUERY_V3_SHA)):
        inputs[str(path)] = audit.bind(path, digest)
    for name, digest in DIAGNOSTIC_FILES.items():
        path = PROOF_DIR / name
        inputs[str(path)] = audit.bind(path, digest)
    for filename, digest in prior["a_exercise_diagnostic_only"]["artifact_sha256"].items():
        path = str(ROOT / filename)
        require(path not in inputs or inputs[path] == digest, "diagnostic dependency conflicts with a sealed input")
        inputs[path] = audit.bind(Path(path), digest)
    for filename, digest in prior["query_diagnostic_binding_only"]["dependency_sha256"].items():
        path = Path(filename)
        if path.resolve().is_relative_to(ROOT):
            require(filename not in inputs or inputs[filename] == digest, "query dependency conflicts with sealed input")
            inputs[filename] = audit.bind(path, digest)
    for path in (Path(__file__).resolve(), HERE / "route.py", HERE / "compare_full.py"):
        inputs[str(path)] = audit.bind(path)
    return inputs


def profile_aliases(base, source, prior):
    return {"schema": 1, "scope": "fresh selected11/default250 and12/min200 plus fresh selected AC full route",
        "compiler_commit": source["result_commit"], "base_compiler_commit": prior["fast"].BASE_COMMIT,
        "source_identity_sha256": prior["fast"].SOURCE_SHA, "disabled_control_sha256": prior["fast"].CONTROL_SHA,
        "source_archive_sha256": source["source_archive_sha256"], "binary_sha256": source["binary_sha256"],
        "staged_profile_sha256": STAGED_PROFILE_SHA, "staged_proof_sha256": STAGED_PROOF_SHA,
        "staged_comparator_sha256": STAGED_COMPARATOR_SHA, "selected_eleven_ordinal": 0, "selected_twelve_ordinal": 0,
        "selected_ac_ordinal": SELECTED_AC, "placed_reduction_plan": specifications(base),
        "selected_ac_trial": prior["ac_trial"], "predeclared_physical_scope": prior["scope_manifest"],
        "predeclared_physical_scope_sha256": digest_value(prior["scope_manifest"]), "route_equivalence_plan_sha256": PLAN_SHA,
        "diagnostic_token_counts": [3, 4], "expected_nondefault_minimum_log": MINIMUM_LOG,
        "fresh_current_qualifications_used": True, "parent_qualification_inherited": False,
        "route_phase_allowed": True, "target_reference_fmax_mhz": TARGET_FMAX,
        "old_strict_all_clock_flags_preserved": True, "actual_buffer_a_query_required_for_changed_buffers": True,
        "supplemental_query_protocol": {"bridge_path": relative(A_V3_PATH), "bridge_sha256": A_V3_SHA,
            "validator_path": relative(QUERY_V3_PATH), "validator_sha256": QUERY_V3_SHA,
            "actual_postroute_binding_is_separate_from_compiler_record": True,
            "required_consumer_arguments": ["query_binding", "expected_validation_sha256", "eligible_halves"],
            "zero_changed_buffers_require_explicit_vacuous_proof": True},
        "presealed_external_file_sha256": prior["presealed_external_file_sha256"],
        "old_coordinate_query_is_diagnostic_only": True, "default_recipe_selected": False, "hardware_tested": False}


def load_profile():
    g8, base, source, control, prior = cached_context()
    prior["audit"].bind(PROFILE)
    profile = read(PROFILE)
    aliases = profile_aliases(base, source, prior)
    require(set(profile) == set(aliases) | {"input_sha256"} and
        all(profile[key] == canonical(value) for key, value in aliases.items()) and
        profile["input_sha256"] == input_map(prior), "full profile aliases/input/scope closure changed")
    return profile, g8, base, source, control, prior


def sealed_input_map(profile):
    return {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}


def full_bindings(profile, base, source, prior):
    report = Path(base["command"][base["command"].index("--remap-decompose-critical") + 1])
    reference_timing = {"accepted": prior["audit"].bind(prior["fast"].FULL / "timing.json"),
        "parent116": prior["audit"].bind(report, base["decomposition_report_sha256"]), "target_fmax_mhz": TARGET_FMAX}
    return {"producer_commit": source["result_commit"], "source_identity_sha256": prior["fast"].SOURCE_SHA,
        "source_archive_sha256": source["source_archive_sha256"], "compiler_binary_sha256": source["binary_sha256"],
        "disabled_control_sha256": prior["fast"].CONTROL_SHA, "experiment_profile_sha256": sha(PROFILE),
        "full_runner_sha256": sha(HERE / "route.py"), "full_validator_sha256": sha(HERE / "compare_full.py"),
        "full_command": expected_command(base), "full_diagnostic_environment": expected_diagnostic_environment(base),
        "full_input_sha256": sealed_input_map(profile), "fresh_eleven_proof_sha256": prior["staged"].FIRST_PROOF_SHA,
        "selected_eleven_ordinal": 0, "fresh_twelve_proof_sha256": prior["staged"].SELECTED_PROOF_SHA,
        "selected_twelve_ordinal": 0, "fresh_ac_proof_sha256": STAGED_PROOF_SHA, "selected_ac_ordinal": SELECTED_AC,
        "selected_stage_graph_and_placement_closure_sha256": digest_value({"staged_proof": STAGED_PROOF_SHA,
            "placed": prior["audit"].bind(STAGED_FOLDER / "placed.json"), "ac_trial": prior["ac_trial"]}),
        "eligible_buffer_alm_and_ff_closure_sha256": digest_value(prior["scope_manifest"]),
        "target_clock_and_reference_timing_closure_sha256": digest_value(reference_timing)}


def tool_identity(base_commit, source):
    return f"base_commit={base_commit}; experimental_source_sha256={source['source_archive_sha256']}; sha256={source['binary_sha256']}"


def record_template(profile, base, source, prior, execution, phase="route"):
    environment = expected_diagnostic_environment(base, phase)
    record = {**base, "kind": "generic narrow-search fully routed fresh selected11/12/AC", "phase": phase,
        "command": expected_command(base, phase), "diagnostic_environment": environment,
        "experimental_placed_reduction": environment["NEXTPNR_MISTRAL_PLACED_REDUCTION"],
        "placed_reduction_plan": specifications(base, phase), "eleven_selection": 0, "twelve_selection": 0,
        "reduction_selection": 0, "decomposition_selection": SELECTED_AC,
        "compiler_commit": source["result_commit"], "base_compiler_commit": prior["fast"].BASE_COMMIT,
        "measured_compiler_commit": base["compiler_commit"], "compiler_bytes_unchanged": False,
        "compiler_bytes_unchanged_from_fresh_eleven_listing": True,
        "source_identity_sha256": prior["fast"].SOURCE_SHA, "source_archive_sha256": source["source_archive_sha256"],
        "disabled_control_sha256": prior["fast"].CONTROL_SHA, "profile_sha256": sha(PROFILE),
        "runner_sha256": sha(HERE / "route.py"), "reference_run_sha256": prior["audit"].bind(prior["fast"].FULL / "run.json"),
        "remap_plan_sha256": prior["audit"].bind(INITIAL / "local-plan.json"),
        "staged_ac_proof_sha256": STAGED_PROOF_SHA, "staged_profile_sha256": STAGED_PROFILE_SHA,
        "fresh_current_qualifications_used": True, "parent_qualification_inherited": False,
        "retained_stage_minimum_branch_gain_ps": DEFAULT_MINIMUM_PS, "new_stage_minimum_branch_gain_ps": MINIMUM_PS,
        "diagnostic_token_counts": [3, 4], "expected_nondefault_minimum_log": MINIMUM_LOG, "minimum_log_verified": False,
        "full_phase_bindings": full_bindings(profile, base, source, prior), "predeclared_physical_scope": prior["scope_manifest"],
        "actual_buffer_a_query_binding": None, "old_coordinate_query_is_diagnostic_only": True,
        "presealed_external_file_sha256": prior["presealed_external_file_sha256"],
        "listing_lineage": {"eleven_listing": str(INITIAL / "list-eleven"),
            "twelve_listing": str(prior["staged"].SELECTED_FOLDER), "ac_listing": str(STAGED_FOLDER)},
        "tool_identity": tool_identity(prior["fast"].BASE_COMMIT, source), "list_only": False, "fresh_listing": False,
        "execution": execution, "input_sha256": sealed_input_map(profile), "completed": False, "hardware_acceptance": False}
    for key in ("elapsed_seconds", "exit_code", "failure", "fmax", "final_reported_hold_violations", "exit_code_is_adapter_sentinel"):
        record.pop(key, None)
    return record


def authenticate_phase(record, context):
    profile, _, base, source, _, prior = context
    phase = record["phase"]
    expected = record_template(profile, base, source, prior, record["execution"], phase)
    state = {"elapsed_seconds", "exit_code", "failure", "exit_code_is_adapter_sentinel", "completed",
             "minimum_log_verified", "fmax", "final_reported_hold_violations"}
    require(canonical({key: value for key, value in record.items() if key not in state}) ==
        canonical({key: value for key, value in expected.items() if key not in state}),
        "actual full command/environment/source/profile/scope or inherited field changed")
    require(type(record["completed"]) is bool and type(record["minimum_log_verified"]) is bool and "failure" not in record,
        "full state is malformed or failed")
    prior["fast"].runtime(prior["audit"], record, base)
    if record["completed"]:
        log = (phase_folder(phase) / "route.log").read_text()
        require(record["minimum_log_verified"] is True and
            [line for line in log.splitlines() if "Placed reduction minimum branch gain:" in line] == [MINIMUM_LOG] and
            type(record["exit_code"]) is int and record["exit_code"] == 0 and
            type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0 and type(record["final_reported_hold_violations"]) is bool and
            record["fmax"] == read(phase_folder(phase) / "timing.json")["fmax"], "full completed record lacks exact outputs/state")
    report = Path(base["command"][base["command"].index("--remap-decompose-critical") + 1])
    return {"phase": phase, "folder": phase_folder(phase), "specs": specifications(base, phase),
        "reduction_steps": specifications(base, phase), "local_steps": base["remap_plan"]["steps"],
        "command": expected["command"], "environment": expected["diagnostic_environment"],
        "report_path": report, "report_sha256": base["decomposition_report_sha256"],
        "ac_selection": SELECTED_AC, "ac_trial": prior["ac_trial"], "allowed_alms": prior["allowed_alms"],
        "scope": prior["scope_manifest"]}


def main():
    require(not PROFILE.exists(), "full profile already exists")
    _, base, source, _, prior = cached_context()
    expected_command(base)
    profile = {**profile_aliases(base, source, prior), "input_sha256": input_map(prior)}
    prior["audit"].finish()
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"profile_sha256": sha(PROFILE), "sealed_inputs": len(profile["input_sha256"]),
        "selected_ac_ordinal": SELECTED_AC, "allowed_alms": prior["allowed_alms"],
        "eligible_original_ffs": len(prior["eligible_ffs"]), "scope": profile["scope"]}, indent=2))


if __name__ == "__main__":
    main()
