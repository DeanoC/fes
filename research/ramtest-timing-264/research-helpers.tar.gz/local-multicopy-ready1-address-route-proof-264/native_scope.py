"""Pure named-slot proof of two added ready1 copies in final routed images."""
import copy
import re

PINS = "ABCDEF"
COMB = "ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D$comb_remap$ddr1_test.pass_end_MISTRAL_ALUT5_D$E"
DECOMP = "ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E$decomposition$ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B$C"
OWNERS = (COMB, DECOMP + "$code0", DECOMP + "$code1", DECOMP + "$root")


def require(value, message):
    if not value:
        raise ValueError(message)


def scalar(cell, port):
    bits = cell["connections"][port]
    require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0,
            "native scalar required: " + port)
    return bits[0]


def lut(cell):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", cell["type"])
    require(match is not None and set(cell["parameters"]) == {"LUT"}, "ordinary LUT schema differs")
    width, text = int(match[1]), cell["parameters"]["LUT"]
    expected = {pin: "input" for pin in PINS[:width]} | {"Q": "output"}
    require(type(text) is str and len(text) == 1 << width and set(text) <= {"0", "1"} and
            cell["port_directions"] == expected and set(cell["connections"]) == set(expected),
            "ordinary LUT mask/ports differ")
    return width, int(text, 2), [scalar(cell, pin) for pin in PINS[:width]], scalar(cell, "Q")


def net_record(net):
    result = copy.deepcopy(net)
    result.get("attributes", {}).pop("ROUTING", None)
    return result


def aliases(top):
    result = {}
    for name, net in top["netnames"].items():
        for bit in net["bits"]:
            result.setdefault(bit, []).append(name)
    return result


def prove(native, selected, before_doc, after_doc, ready, profile, trial):
    """No reads/imports inside; compare complete lossless documents and named ledgers."""
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "document schema differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    clone, retained, second = ready["new_clone"], ready["retained_first_copy"], ready["retained_second_copy"]
    model = profile["prefix_fresh_local_models"][4]
    earlier = profile["prefix_fresh_local_models"][3]
    source, sink, port = profile["declared_driver_edge"]
    driver_clone = source + "$lut_driver_copy$" + sink + "$" + port
    successor = profile["driver_current_immediate_carry_successor"]["cell"]
    alias = clone + "$Q"
    second_alias = second + "$Q"
    added_names = {clone, second}
    added_aliases = {alias, second_alias}
    require(clone == model["outer"] + "$local_remap$2" and second == model["outer"] + "$local_remap$1" and
            retained == model["outer"] + "$local_remap" and model["outer"] == earlier["outer"] and
            ready["declared_ena_redirect_count"] == len(ready["declared_ena_redirects"]) == 6 and
            set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and list(a) == list(b) and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (20133, 20135, 21871, 21873) and
            set(b["cells"]) == set(a["cells"]) | added_names and not added_names & set(a["cells"]) and
            set(b["netnames"]) == set(a["netnames"]) | added_aliases and not added_aliases & set(a["netnames"]) and
            [name for name in b["cells"] if name not in added_names] == list(a["cells"]) and
            [name for name in b["netnames"] if name not in added_aliases] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "complete module/order/PLL/two-copy population differs")
    require("FES_LABSTATE_V1" in a["attributes"] and all("FES_PINMAP_V1" in cell["attributes"]
            for top in (a, b) for cell in top["cells"].values()), "final physical snapshots missing")
    od, ou = selected.native_tables(a)
    nd, nu = selected.native_tables(b)
    aa, ba = aliases(a), aliases(b)
    allowed, frames = {}, []

    def frame(owner, named_alias, kind):
        old, new = scalar(a["cells"][owner], "Q"), scalar(b["cells"][owner], "Q")
        users = ou.get(old)
        require(od.get(old) == nd.get(new) == [(owner, "Q", 0, 0)] and users and users == nu.get(new),
                "private owner driver/complete named users differ: " + owner)
        for top, bit, names in ((a, old, aa), (b, new, ba)):
            require(names.get(bit) == [named_alias] and top["netnames"][named_alias]["bits"] == [bit] and
                    all(bit not in p["bits"] for p in top["ports"].values()), "private alias/boundary differs: " + owner)
        left, right = net_record(a["netnames"][named_alias]), net_record(b["netnames"][named_alias])
        left["bits"], right["bits"] = [], []
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + owner)
        for slot in [(owner, "Q", 0, 0)] + users:
            require(slot not in allowed and slot[3] == 0, "private named slot overlaps/occurrence unsupported")
            allowed[slot] = (old, new)
        row = {"owner": owner, "alias": named_alias, "old_raw_bit": old, "new_raw_bit": new,
               "named_consumer_slots": [list(slot) for slot in users], "kind": kind}
        frames.append(row)
        return row

    private = [frame(owner, owner + "$Q", "existing_private_output") for owner in OWNERS]
    driver = frame(driver_clone, driver_clone + "$Q", "existing_driver_copy_output")
    require(driver["named_consumer_slots"] == [[sink, port, 0, 0]], "driver copy has another consumer")
    buffers = {name for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_BUF"}
    require(len(buffers) == 5232 and buffers == {name for name, cell in b["cells"].items() if cell["type"] == "MISTRAL_BUF"},
            "existing named buffer population differs")
    buffer_rows = []
    for name in sorted(buffers):
        row = frame(name, name + "$conn$Q", "existing_late_buffer_output")
        require(len(row["named_consumer_slots"]) == 1, "buffer output does not have one consumer")
        ff, ff_port, index, occurrence = row["named_consumer_slots"][0]
        require(ff_port == "DATAIN" and index == occurrence == 0 and a["cells"][ff]["type"] == b["cells"][ff]["type"] == "MISTRAL_FF" and
                a["cells"][name]["port_directions"] == b["cells"][name]["port_directions"] == {"A": "input", "Q": "output"} and
                set(a["cells"][name]["connections"]) == set(b["cells"][name]["connections"]) == {"A", "Q"} and
                scalar(a["cells"][name], "A") == scalar(b["cells"][name], "A"), "buffer input/unique FF identity differs")
        bit = scalar(a["cells"][name], "A")
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit), "buffer input native driver differs")
        buffer_rows.append({**row, "buffer": name, "ff": ff, "input_raw_bit": bit, "input_native_driver": list(od[bit][0])})
    require(len({row["old_raw_bit"] for row in frames}) == len({row["new_raw_bit"] for row in frames}) == len(frames),
            "private owner output frames overlap")
    wi, mi, ai, qi = lut(a["cells"][model["inner"]])
    wo, mo, ao, qo = lut(a["cells"][model["outer"]])
    wp, mp, ap, qp = lut(a["cells"][retained])
    wc, mc, ac, qc = lut(b["cells"][clone])
    wone, mone, aone, qone = lut(b["cells"][second])
    require((wi, wo, wp, wc, wone, mi, mo, mp, mc, mone) == (2, 3, 4, 4, 4, 0xb, 0x32, 0x4440, 0x4440, 0x4440) and
            ao.count(qi) == 1 and len(set(ac)) == 4 and ac == ap == aone and
            set(ac) == set(ai + [bit for bit in ao if bit != qi]) and
            not ({qi, qo, qp, qc, qone} & set(ac)) and len({qi, qo, qp, qc, qone}) == 5 and
            b["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
            b["cells"][second]["attributes"]["NEXTPNR_BEL"] == earlier["bel"] and
            a["cells"][retained]["attributes"]["NEXTPNR_BEL"] == "MISTRAL_COMB.29.13.0" and
            b["netnames"][alias]["bits"] == [qc] and nd.get(qc) == [(clone, "Q", 0, 0)] and
            ba.get(qc) == [alias] and b["netnames"][second_alias]["bits"] == [qone] and nd.get(qone) == [(second, "Q", 0, 0)] and
            ba.get(qone) == [second_alias] and all(qc not in p["bits"] and qone not in p["bits"] for p in b["ports"].values()), "ready cone/copy/private placement differs")
    for name, net_alias in ((second, second_alias), (clone, alias)):
        left, right = copy.deepcopy(a["cells"][retained]), copy.deepcopy(b["cells"][name])
        for cell in (left, right):
            cell["attributes"].pop("NEXTPNR_BEL")
            cell["attributes"].pop("FES_PINMAP_V1")
            cell["connections"].pop("Q")
        require(native.canonical(left) == native.canonical(right) and
                list(a["cells"][retained]["connections"]) == list(b["cells"][name]["connections"]) and
                list(a["cells"][retained]["port_directions"]) == list(b["cells"][name]["port_directions"]),
                "new ready copy metadata or input order differs: " + name)
        left, right = net_record(a["netnames"][retained + "$Q"]), net_record(b["netnames"][net_alias])
        left["bits"], right["bits"] = [], []
        require(native.canonical(left) == native.canonical(right), "new ready private alias metadata differs")
    chosen = []
    redirect_specs = [(tuple(slot), qone) for slot in ready["retained_second_copy_consumers"]] + [
        ((row["cell"], "ENA", row["vector_index"], row["occurrence"]), qc) for row in ready["declared_ena_redirects"]]
    require(len(redirect_specs) == 7 and len({slot for slot, _ in redirect_specs}) == 7, "new one-plus-six cohort overlaps")
    for slot, new_bit in redirect_specs:
        require(slot[1:] == ("ENA", 0, 0), "declared new consumer is not a scalar ENA")
        ff = slot[0]
        require(slot not in allowed and a["cells"][ff]["type"] == b["cells"][ff]["type"] == "MISTRAL_FF" and
                scalar(a["cells"][ff], "ENA") == qo and scalar(b["cells"][ff], "ENA") == new_bit and
                scalar(a["cells"][ff], "CLK") == scalar(b["cells"][ff], "CLK") == 3549, "declared ENA/clock differs")
        allowed[slot] = (qo, new_bit)
        chosen.append(slot)
    retained_users = [tuple(slot) for slot in ready["retained_first_copy_consumers"]]
    require(ou.get(qp) == nu.get(qp) == sorted(retained_users) and len(retained_users) == 2 and
            ou.get(qo) and len(ou[qo]) == 109 and len(nu.get(qo, [])) == 102 and
            nu.get(qone) == sorted(slot for slot, bit in redirect_specs if bit == qone) and len(nu.get(qone, [])) == 1 and
            nu.get(qc) == sorted(slot for slot, bit in redirect_specs if bit == qc) and len(nu.get(qc, [])) == 6 and
            sorted(slot for slot in ou[qo] if slot not in chosen) == nu[qo], "ready original/retained/new cohort differs")
    for slot in ou[qo] + ou[qp]:
        require(slot[1:] == ("ENA", 0, 0) and a["cells"][slot[0]]["type"] == "MISTRAL_FF" and
                scalar(a["cells"][slot[0]], "CLK") == scalar(b["cells"][slot[0]], "CLK") == 3549,
                "complete original ready cohort is not the known common-clock FF ENA union")
    truth = []
    for assignment in range(16):
        values = {bit: (assignment >> i) & 1 for i, bit in enumerate(ac)}
        iv = (mi >> sum(values[bit] << i for i, bit in enumerate(ai))) & 1
        original = (mo >> sum((iv if bit == qi else values[bit]) << i for i, bit in enumerate(ao))) & 1
        retained_value = (mp >> sum(values[bit] << i for i, bit in enumerate(ap))) & 1
        require(original == retained_value == (mc >> assignment) & 1 == (mone >> assignment) & 1, "ready logical composition differs")
        truth.append({"assignment": assignment, "value": original})
    for bit in ac:
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit) and
                a["cells"][od[bit][0][0]]["type"] != "MISTRAL_CONST", "ready leaf is not an unchanged ordinary driver")
    ws, ms, ins, qs = lut(a["cells"][source])
    require(ws == 3 and ms == 0x20 and len(ou.get(qs, [])) == len(nu.get(qs, [])) == 48 and ou[qs] == nu[qs] and
            od.get(qs) == nd.get(qs) == [(source, "Q", 0, 0)] and
            (sink, port, 0, 0) not in ou[qs] and trial["source"] == source and trial["sink"] == sink and trial["port"] == port and
            b["cells"][driver_clone]["attributes"]["NEXTPNR_BEL"] == trial["bel"], "driver source retained users/selected actual site differs")
    driver_truth = []
    for top in (a, b):
        wd, md, ind, _ = lut(top["cells"][driver_clone])
        require((wd, md, ind) == (ws, ms, ins) and len(set(ins)) == 3 and
                top["cells"][sink]["type"] == top["cells"][successor]["type"] == "MISTRAL_ALUT_ARITH" and
                scalar(top["cells"][sink], "CO") == scalar(top["cells"][successor], "CI"), "driver Boolean inputs/carry successor differ")
        for bit in ins:
            require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit), "driver input native owner differs")
        driver_truth.append([{"assignment": i, "value": (md >> i) & 1} for i in range(8)])
    co = scalar(a["cells"][sink], "CO")
    require(ou.get(co) == nu.get(co) == [(successor, "CI", 0, 0)], "dedicated carry successor has another consumer")
    expected_drivers = dict(od)
    for row in frames:
        del expected_drivers[row["old_raw_bit"]]
    require(qc not in expected_drivers and qone not in expected_drivers, "new ready output overlaps a retained ordinary bit")
    for row in frames:
        bit = row["new_raw_bit"]
        require(bit not in expected_drivers and bit not in {qc, qone}, "private frame overlaps another driver/new clone")
        expected_drivers[bit] = [(row["owner"], "Q", 0, 0)]
    expected_drivers[qc] = [(clone, "Q", 0, 0)]
    expected_drivers[qone] = [(second, "Q", 0, 0)]
    require(nd == expected_drivers, "complete native drivers differ beyond explicit frames")
    expected_users = {}
    for bit, slots in ou.items():
        for slot in slots:
            new_bit = allowed[slot][1] if slot in allowed else bit
            expected_users.setdefault(new_bit, []).append(slot)
    for name, inputs in ((second, aone), (clone, ac)):
        for i, bit in enumerate(inputs):
            expected_users.setdefault(bit, []).append((name, PINS[i], 0, 0))
    require(nu == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete native users differ beyond named frames/seven ENAs/eight input loads")
    for name, old in a["cells"].items():
        expected = copy.deepcopy(old)
        for port_name, bits in expected["connections"].items():
            for index, bit in enumerate(bits):
                slot = (name, port_name, index, 0)
                if slot in allowed:
                    require(allowed[slot][0] == bit, "declared original slot bit differs")
                    bits[index] = allowed[slot][1]
        require(native.canonical(expected) == native.canonical(b["cells"][name]) and
                list(old["connections"]) == list(b["cells"][name]["connections"]) and
                list(old["port_directions"]) == list(b["cells"][name]["port_directions"]),
                "original metadata/BEL/full pins/connected slots differ: " + name)
    private_nets = {row["alias"]: row for row in frames}
    for name, old in a["netnames"].items():
        expected = net_record(old)
        if name in private_nets:
            expected["bits"] = [private_nets[name]["new_raw_bit"]]
        require(native.canonical(expected) == native.canonical(net_record(b["netnames"][name])),
                "original alias/raw bits/metadata differ: " + name)
    return {"ready": ready, "driver": {"source": source, "clone": driver_clone, "sink": sink, "port": port, "successor": successor},
            "buffer_rows": buffer_rows, "private_output_rows": private, "driver_output_row": driver,
            "evidence": {"serialized_native_scope_proved": True, "original_cells": len(a["cells"]),
                "new_cells": len(b["cells"]), "buffer_count": len(buffer_rows), "private_output_owner_count": len(private),
                "complete_driver_and_user_tables_proved": True, "all_original_full_pins_bels_metadata_exact": True,
                "whole_module_lab_snapshot_exact": True, "retained_first_copy_two_users_exact": True,
                "declared_ena_redirect_count": len(chosen), "new_one_user_ready_copy": second, "new_six_user_ready_copy": clone,
                "original_root_users_before": 109, "original_root_users_after": 102,
                "actual_one_user_ready_q": qone, "actual_ready_q": qc, "actual_ready_conditional_rows": truth,
                "driver_source_retained_users": 48, "driver_copy_users": 1, "driver_conditional_rows_per_frame": driver_truth,
                "before_creator": before_doc["creator"], "after_creator": after_doc["creator"],
                "conditional_plain_sig_assumptions": True, "physical_pin_truth_or_sta_inherited": False}}
