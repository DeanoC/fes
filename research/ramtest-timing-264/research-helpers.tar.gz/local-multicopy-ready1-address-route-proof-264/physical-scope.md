# Actual exported physical proof of two additional ready copies

`physical.py` is a pure module. Its entrypoint is
`evaluate(before_doc, after_doc, logical_ledger, profile, driver_trial)`.
Both inputs are complete final routed documents parsed by the pinned lossless
32fd parser, including ordered paired PLL port records. The outer comparator
binds the accepted 117.34334564208984MHz reference, the actual current five-stage
route, source/profile/runtime/trial, this module and this scope. It independently
proves every native owner, raw slot, alias and named user. This helper performs
no file reads, authentication, execution, numerical STA or acceptance.

The first 527 lines retain the previously validated frozen 0f524952 pure
evaluator verbatim. The remaining functions are adapted from the validated
four-stage physical helper4f018c0a. No historical validator, comparison,
authentication, generator or main executes. Actual per-image pin records and
native driver tokens are reconstructed rather than imported from predicted
raw IDs.

The logical ledger has exactly four keys. `ready` is the actual positive fifth
prefix's `native_graph_evidence`; `driver` names the actual source, copy, operand,
port and immediate carry successor; `buffer_rows` names all 5,232 existing
buffer/unique-FF pairs; `private_output_rows` names the four original private
LUT output owners. The fifth prefix's separate existing$1 output frame has no
owner in the accepted reference and is not reused as a before frame. Both new
ready outputs are independently derived from the routed image. The profile
supplies all five fresh local models and the predeclared whole-LAB FF rows; the
fresh driver trial supplies its actual qualified site.

The accepted original ALUT2 (0xb), outer ALUT3 (0x32) and retained ALUT4
(0x4440) remain exact. In the current routed image, two additional ALUT4s
(0x4440) must be the actual $1 and $2 owners at the separately qualified stage3
and stage4 sites. All four original/native/copy functions are checked over all
16 assignments of the same four actual external native driver tokens. Full
exported pin states, inversions, constants and aliases participate in the
evaluation; this replaces the prefix's conditional plain-SIG truth evidence.

The old two named ENA consumers remain on the retained original copy. Exactly
one plus six disjoint named scalar ENA slots move from original root to $1/$2;
the original root's actual complete consumer count must be109→102. All111
original FF consumers share raw CLK3549. Each changed FF retains its full pins
and clock; only its independently equivalent ENA driver is allowed to change.
Every other FF control remains exact. Both actual new outputs have precisely
their declared consumers and their sites agree with the current five models.

The reference already contains a driver copy. Each image is independently
checked for the ALUT3 source/copy eight-row function, actual effective input
states, 48 preserved original source-Q users and one private-Q arithmetic
operand. The current copy's BEL must match the fresh trial. Both arithmetic
LUT0/LUT1 banks, dedicated CO-to-CI successor and original source/operand/carry
pins and effective banks remain strict. No absent-before copy proof is reused.

Whole-LAB closure includes all predeclared local/source/operand/carry sites and
the actual old/current driver-copy sites, both added ready sites, retained
ready owner and four private owners. Every original FF and all ten ALMs in
each LAB are evaluated. Original occupied banks remain exact after accounting
only for the two added ready copies and each per-image driver copy. Shared
physical A/B inputs must denote the same actual native driver within each
image. The complete exported LAB geometry, modes and selectors must be exact;
there is no blanket LAB-field or control-set allowance.

Every existing buffer is reconstructed with its actual input driver, unique
private scalar Q alias, sole named FF.DATAIN consumer, physical bank and full
FF controls. All 5,232 names, physical pins, metadata and input functions remain
exact. Individual private numeric Q changes belong to the outer named-owner
ledger; there is no global offset, renaming or buffer collapse. The four other
original private owners' actual occupied banks remain exact. Added input-load
multiplicity and whole native graph equality are the outer comparator's duties.

The inherited model covers active-low ALUT2-to-5 halves, dual-bank ALUT6,
arithmetic `q0 + !q1 + CI`, dedicated carry coordinates, constants and actual
alias constraints. MCOMB logic uses the final64-bit logic permutation rather
than RAM-initialization reversal. Unsupported occupants, incomplete physical
records, bank/input sharing conflicts or missing FF controls fail closed.

This is an exported final-snapshot function/control proof. It does not decode
RBF/CRAM, routed mux/pip selections or physical control routing; prove hidden
combination caches, GPU indices or in-memory ownership; calculate independent
numerical STA; or establish hardware behavior. Complete native evidence and
all current clock/window/last-hold checks remain separate. No future run hash,
route result or gain is assumed; physical evidence alone cannot accept a trial.
