New verified fixed-input OSS result: **116.645279 MHz memory**, up **0.366211 MHz** from the accepted 116.279068 MHz profile. The generic compiler follow-up is open in [nextpnr PR #103](https://github.com/DeanoC/nextpnr/pull/103).

| Clock | Accepted reference MHz | New profile MHz | Required MHz |
| --- | ---: | ---: | ---: |
| Memory | 116.279068 | 116.645279 | 130.005203 |
| Pixel | 93.896713 | 93.309692 | 74.250069 |
| Phase-shifted capture | 307.631805 | 307.631805 | 130.005203 |

The full GPU route completed with no final reported hold violations. Every non-target reported setup window remains positive; capture-to-memory headroom stays **2.887 ns in its 5 ns window**. Pixel Fmax decreases by 0.587021 MHz but still meets its constraint. The agreed target-clock acceptance rule passes; the stricter all-clock Fmax nonregression diagnostic remains false. **130 MHz remains unresolved** (memory's complete critical delay is 8.573 ns against 7.692 ns).

The changes extend generic three-LUT read-once reduction balancing to 7–12 distinct literals, add an optional positive per-stage admission margin with the existing 250 ps default, and rank bounded narrow placements using future root arcs and distinct ALMs for ALUT6 leaves. No RAM-test names or locations are embedded in those production rules. The selected combined profile retains the local/comb/capture stack, freshly qualifies eleven-literal/default250 and twelve-literal/minimum200 stages, then selects fresh decomposition candidate 0. No isolated per-commit timing gain is claimed.

Both compiler/backend-test builds pass, as do all 37 focused backend cases. The final full comparison independently passes LUT truth, native graph/consumer/alias, original physical pin/BEL/FF/PLL and declared late route-through buffer checks. Proof SHA256 `0de965ae99e9708c158b590d62bdcfca31205e821e0b178b5bfb809fefb8918c` authenticates 316 artifact and 282 execution-file hashes. Versioned validator fixes preserve the prior failed records; the earlier 116.130531 MHz minimum-200 route remains rejected.

Measured compiler source: `cc00795f772def091160da354018992600c82869`; publication head `910026834351902d7c528c5a69eacd5bd5de9d9d` adds documentation only. Synthesis SHA256 `61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28`, BUILD_ID `7168b508ab424b70f1c0f87b2035d821`, constraints, seed 2 and GPU1 are unchanged. [Profile, command, margins and artifact identities](https://github.com/DeanoC/nextpnr/blob/910026834351902d7c528c5a69eacd5bd5de9d9d/docs/mistral-narrow-reduction.md).

This is an opt-in host-side routed timing result. No hardware acceptance or default FES recipe/lock selection is claimed. It has not yet been benchmarked with merged main's #96 locked-LAB changes or #102 regression additions; fresh combined-source validation is next. The new limiting memory path is the phase/burst decode through the command-address carry chain into `cmd_end`, which provides the next compiler/physical optimization lead.
