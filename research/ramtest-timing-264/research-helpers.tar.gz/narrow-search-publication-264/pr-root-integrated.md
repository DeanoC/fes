The placed reduction remapper currently accepts only eleven-literal three-LUT cubes, and its narrow search can rank candidates without the rewritten root's input arcs or retain both halves of the same ALM. Extend it to verified read-once cubes with 7–12 distinct literals and improve the bounded search.

- Balance the literals into ceil/floor leaf groups; repeated literals and reconvergence remain rejected.
- Allow an optional positive fourth `MIN_BRANCH_GAIN_PS` token per diagnostic stage. Three-field specifications retain the 250 ps default; endpoint, clock, hold, legality, rollback and probe-budget guards remain required.
- Include actual future ALUT2 root arcs in narrow ranking. For ALUT6 leaves, shortlist distinct ALMs with legal original-site priority. The 24-site/16-probe bounds and sharing behavior for leaves with at most five inputs remain.

These are generic, opt-in compiler changes. RTL names and coordinates occur only in runtime diagnostic inputs and the recorded benchmark profile.

The fixed-input RAM-test profile improves **116.279068 → 116.645279 MHz memory (+0.366211 MHz)**. Pixel changes 93.896713 → 93.309692 MHz against its 74.250069 MHz constraint; capture remains 307.631805 MHz. Every non-target reported setup window is positive, capture-to-memory headroom remains **2.887 ns in its 5 ns window**, and final signoff reports no hold violations. Memory still misses 130 MHz.

The full comparison passes independent native graph, LUT truth, outside physical-pin/BEL/FF/PLL and declared routing-buffer checks. It preserves the earlier failed validator records and the older rejected timing attempt. The agreed acceptance rule requires target-memory improvement and passing non-target constraints/windows/holds; the stricter all-clock Fmax nonregression result remains false because pixel Fmax decreased.

Validation: both compiler/backend-test targets build; all **37 focused backend cases pass**, including actual root-arc ranking, blocked-original-site/distinct-ALM behavior, exhaustive truth and exact rollback. Fresh 11-literal, 12-literal/minimum200 and decomposition listings were qualified on the current binary before the full GPU route. [Measurement, selected profile and hashes](docs/mistral-narrow-reduction.md) record the combined result; it does not assign an isolated gain to one commit.

Measured source is `cc00795f772def091160da354018992600c82869`. A fresh replay on merged main `e792486c5763564ffc8a9b56366a11cebd982baa` (including #96 and #102) at `0c59d78a9d672f5ddc4a81b622055b125f1d2522` reproduces exactly **116.645279 / 93.309692 / 307.631805 MHz**, with no final hold violations. Its independently checked native module, owner order, numeric IDs, routing, full pins/BELs, PLL outputs and RBF bytes are identical to the accepted run; only creator/version metadata differs. All 71 placement metrics and current selected-stage qualification messages match.

The combined compiler build, 37 backend cases, five CLI targets and both #96 host diagnostics pass. [Integration record](docs/validation/ramtest-narrow-integrated-2026-09-30.json) binds the fresh source/binary/host checks and graph/RBF reproduction proof `01886d65d6e55f1f1c1d5345e00e3dee5358ce672b0f4a3bac3135f6ec155d4e`. Publication commits add documentation only. No default FES recipe/lock or hardware acceptance is claimed.

Full comparison SHA256: `0de965ae99e9708c158b590d62bdcfca31205e821e0b178b5bfb809fefb8918c`.

Related: DeanoC/fes#264. Follow-up to #97.
