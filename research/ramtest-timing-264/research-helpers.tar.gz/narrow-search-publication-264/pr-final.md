Follow-up to PR #97: extend the generic placed-reduction experiment to smaller read-once cubes and improve its bounded two-leaf placement search.

- Recognize three-LUT cubes with 7–12 distinct literals and balance them into ceil/floor leaf groups. The existing 11-literal partition remains 6/5; repeated literals and reconvergence remain rejected.
- Accept an optional positive fourth `MIN_GAIN_PS` token per diagnostic stage. Three-token specifications retain the 250 ps default. Endpoint, clock, hold, legality, rollback and probe-budget guards remain required.
- Rank narrow placements using actual future-ALUT2 root input delays. For ALUT6 leaves, prefer distinct ALMs within each LAB shortlist while retaining legal original-site priority and the 24-site/16-probe bounds. Leaves of at most five inputs retain their sharing behavior.

The implementation is the three-commit sequence `8e305cb9`, `6552942d`, `cc00795f`. All 37 focused backend cases passed, including actual root-arc ordering and blocked-original-site/distinct-ALM regressions. Both compiler and backend-test builds passed.

The accepted full route used source `cc00795f772def091160da354018992600c82869`, the same RTL/synthesis inputs, BUILD_ID `7168b508ab424b70f1c0f87b2035d821`, and seed 2 as the published groups8 reference. It retained that local/comb/capture stack, then selected freshly qualified eleven-literal/default250, twelve-literal/minimum200 and AC candidates.

| Reported clock | Published groups8 reference | Accepted new route | Required constraint |
| --- | ---: | ---: | ---: |
| Memory | 116.279 MHz | 116.645 MHz | 130.005 MHz |
| Pixel | 93.897 MHz | 93.310 MHz | 74.250 MHz |
| Capture | 307.632 MHz | 307.632 MHz | 130.005 MHz |

Memory improves by 0.3662109375 MHz. The capture-to-memory 5 ns window retains 2.887 ns setup headroom, all required non-target windows remain positive, and final signoff reports zero hold violations. Memory still misses its 130 MHz constraint; pixel remains above its constraint with Fmax lower by 0.5870208740234375 MHz. These figures describe the combined selected profile and do not isolate one change's contribution.

Full native-graph and physical validation passed in `comparison-v4.json`, SHA256 `0de965ae99e9708c158b590d62bdcfca31205e821e0b178b5bfb809fefb8918c`, using validator SHA256 `4905f32ab25b89ff6289c64c5501a9894b83f258229f30cb0156d0948372671f`. It closes selected reduction/AC truth, preserved original graph and physical metadata outside declared changes, native consumers and aliases, PLL outputs, and separately declared late route-through BUF changes with actual physical-A ancestry. The proof binds 316 artifact hashes and 282 execution-file hashes. Earlier validator rejection records remain preserved.

The user-confirmed practical acceptance rule passed: target-memory gain, passing non-target constraints and required windows, and no final holds. The stricter all-clock diagnostic remains false because pixel Fmax decreased. RBF generation succeeded; no independent RBF/CRAM decoding, reconstructed in-memory GPU IDs, or hardware acceptance is claimed.

These are opt-in compiler experiments; the 250 ps default remains unchanged. The measurement uses the retained compiler branch rather than a rebuild on current merged main. Main's #96 locked-LAB changes and latest #102 test-only addition have not been benchmarked in combination with this result.
