Follow-up to PR #97: extend the generic placed-reduction experiment to smaller read-once cubes and improve its bounded two-leaf placement search.

- Recognize three-LUT cubes with 7–12 distinct literals and balance them into ceil/floor leaf groups. The existing 11-literal partition remains 6/5; repeated literals and reconvergence remain rejected.
- Accept an optional positive fourth `MIN_GAIN_PS` token per diagnostic stage. Three-token specifications retain the 250 ps default. This adjusts admission only; endpoint, clock, hold, legality, rollback and probe-budget guards remain required.
- Rank narrow placements using the actual future ALUT2 root input delays. For ALUT6 leaves, prefer distinct ALMs within each LAB shortlist while retaining legal original-site priority and the 24-site/16-probe bounds. Leaves of at most five inputs retain their sharing behavior.

The implementation is the three-commit sequence `8e305cb9`, `6552942d`, `cc00795f`; this PR adds to the compiler changes already merged in #97. The current source passed all 37 focused backend cases, including actual root-arc ordering and blocked-original-site/distinct-ALM regressions. Both compiler and backend-test builds passed.

The full route below used source `cc00795f772def091160da354018992600c82869`, the same RTL/synthesis inputs, BUILD_ID `7168b508ab424b70f1c0f87b2035d821`, and seed 2. It retained the published groups8 local/comb/capture stack, then selected freshly qualified 11-literal/default250, 12-literal/minimum200 and AC candidates.

| Reported clock | Published reference | New raw route | Required constraint |
| --- | ---: | ---: | ---: |
| Memory | 116.279 MHz | 116.645 MHz | 130.005 MHz |
| Pixel | 93.897 MHz | 93.310 MHz | 74.250 MHz |
| Capture | 307.632 MHz | 307.632 MHz | 130.005 MHz |

The raw target gain is 0.366 MHz. The capture-to-memory 5 ns window retains approximately 2.887 ns setup headroom, and final signoff reports no hold violations. Memory still misses its 130 MHz constraint; pixel remains above its constraint with lower Fmax. These figures describe the combined selected profile and do not isolate one change's contribution.

**Publication status: physical/native-graph validation is still pending.** The versioned validators preserve earlier rejection records and are closing actual pin, alias, consumer and late route-through buffer evidence. Replace this status with the final authenticated proof result before publishing a verified-gain claim. The confirmed practical acceptance rule requires a strictly higher target-memory Fmax, passing non-target constraints and reported windows, and no final holds; it does not require every non-target Fmax to stay unchanged.

These are opt-in compiler experiments; no default recipe or RTL behavior is intentionally changed. The measurement uses the retained compiler branch rather than a rebuild on current merged main. Main's #96 locked-LAB changes have not been benchmarked in combination with this result. No hardware acceptance or independently decoded RBF configuration is claimed.
