# Fresh composed-copy listing rollback comparison

This new inactive comparator has explicit UNFROZEN compiler, ELF, archive,
host/test/check, recorder, profile and run identities. ROOT must fill only actual
closed identities, review the final bytes and supply all six CLI hashes before
activation. It writes only exclusive listing/comparison-copy-listing.json.
No previous source, helper, closed failure or evidence file changes.

The current composed-copy source is based on e137ca5b, independently qualified
by its own complete committed nine-file delta, archive, model/submodule bytes,
object dependency manifests and original/resolved files, current test and
production ELFs, all58 current native cases across four suites and51 CLI methods.
Initial failed builds are separately retained by the current host record. A
prior compiler's host or transformation acceptance is not inherited.

Three immutable prerequisites are separately bound and must be positive:
e137 endpoint-diagnostic reproduction12a957, original5a ready0 listing94627,
and5a disabled-TEN dual-reference control9498. Their exact profiles, closed runs,
recorder/comparer/scope sources and complete flat artifacts/runtime closures
are read without replaying any previous operational entrypoint. All three
actual images, reports and model/placement records are direct references.

The fresh completed record must match every prepared profile field, the exact
profile-plus-own-profile input union, loaded execution snapshot and three output
hashes, with successful compiler read audit and final stable original paths.
The fresh source invocation retains the literal TEN plan00bf and descriptors,
device, JSON/QSF/SDC/seed, fixed8,221 FFs, ten existing copy cohorts, unchanged
current single-path guide9bdad541 and hardware/library/environment bytes.
The command copies the closed e137 diagnostic argv. Only the independently
bound compiler/PATH and fresh outputs change, plus the
explicit composed-copy mode at the existing pair listing stage. Candidate-1
and no-route remain. No post plan, driver, replay, RBF or route executes.

Only hash-pinned lower definitions run:32fd lossless native JSON/Audit and
placement metrics,72131 complete raw driver/user tables and report topology
with its8601 dependency in a module-local import namespace, and the new
recorder's pure command/runtime/definition-loader/qualification methods.
The disabled-control TEN pure parser chain is bound individually to the current
input map. Actual loaded project-module files are also bound. No previous
prepare, execute, comparison, authenticator, generator, clean-source helper or
high-level native/physical/timing evaluator runs.

All14,907 cells/16,645 netnames and the ENTIRE native module must equal all
three direct references. All types, masks, controls, pin attributes, ports,
aliases, literal raw IDs, complete reconstructed driver/user occurrence slots,
full nested metadata/list/owner/port ordering, lossless paired PLL entries and
all8,221 original FF records/BELs are strict. Only separate document creator
strings may differ as compiler provenance; actual strings and observed equality
are recorded. No private-owner alignment, numerical renaming, buffer collapse,
native-field exception or unexported architecture/cache proof is permitted.

The saved recorder's TEN-model, metric and report diagnostic flags must equal
the independent comparisons against e137; all three prepared historical identity
fields and the exact called TEN parser ledger are also checked.
The full ten freshly parsed guarded model dictionaries, all71 placement rows
and the ENTIRE predicted report must equal each reference. The four actual
images independently validate15,290 native paths across seven real clock pairs,
cap16,384, preserved endpoint/window sets and finite complete signed terms.
Structural, model/copy-log and topology rejection are separate; mismatches
retain current report evidence and finish the full original-path rehash.

Composed-copy discovery/composition/domain/trial/candidate/final-listing grammar
is parsed again from the complete fresh log and bound exactly to the recorder.
The parser must cover0..8 cones and up to16 actual trials per cone, possible
rejections, five guard booleans, actual private clone BELs, complete cohort and
leaf/truth-row/mask data. Every reported qualified candidate requires all
guards and at least250ps improvement. No old relocation trial count, rejection
endpoint, zero-candidate result, particular candidate existence or composed
copy application is assumed. Distinct observed cone identities must equal the
discovery count; supported rejections bind their actual phase and nonrejected
cones require both composition and domain records. Listing must apply no candidate.

Only all gates permit fresh_lut_pair_copy_listing_reproduction_proved. This
proves listing rollback and predicted-report reproduction, with no selected
candidate, independent function/physical equivalence, routed gain, numerical
STA calibration, decoded bitstream or hardware acceptance. The accepted routed
five-stage117.771759MHz result remains a separate reference.
