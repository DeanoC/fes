# Fresh ready0 composed-copy listing recorder

Author-only inactive recorder for the isolated `nextpnr-lut-pair-compose-copy-264`
source based on e137ca5bda7c5e68e6da65f37b5830d12f58727a. Actual result commit,
ELF, archive, host, test, check-results, host-helper and host-scope pins remain
`UNFROZEN`. ROOT supplies those literal pins only after fresh checks close. The
recorder refuses preparation before that happens; authoring does not execute it.

The new independent host must bind the clean nine-file committed delta, committed
archive, live source/submodules/external model and object-dependency closures,
58 native cases (12 pair, 11 copy, 25 plan, 10 driver) and 51 CLI methods (17 pair,
24 plan, 10 driver). Build failures and test failures retained by the host recorder
are historical evidence, never substituted for the required positive current host.

Preparation directly binds the closed e137 diagnostic profile b894dd50, run
f0806756 and positive reproduction 12a95709, the prior 5a listing profile53f82bb5,
run15e5a0c3 and reproduction94627ac9, and disabled TEN control d8c15d6b/581f3dd6/
9498fb62. The last proof must retain strict parity against both the original d7e
TEN construction and b3d disabled-post TEN control. All historical flat artifact
and runtime ledgers, profile input unions, output triplets, recorder/comparer bytes
and scopes are adopted at their original paths and rehashed. Those old graph and
report proofs qualify the reference only; they do not prove this new listing.

The one-path guide is the immutable 9bdad541 ready0 guide from the prior proved
listing. Its complete original path object and clocks/window/delays are preserved.
There is no regenerated guide, source graph replay, post-driver buffer metadata or
unfiltered critical report. Literal TEN plan00bf, source JSON, device, QSF, SDC,
seed and every existing option/environment field remain unchanged. The fresh argv
copies the closed e137 diagnostic argv, substitutes only the fresh ELF and write/
report paths, and adds explicit `--remap-lut-pair-compose-copy`. Candidate is -1;
`--no-route` remains present. Post-plan, driver copy, RBF, packing/placement skips
and candidate application are rejected. Controlled PATH and the sole ELF runtime
file change together; all other FunctionalInvocation fields/files stay exact.

Only the pinned disabled-control definitions loader and TEN qualification chain
are called. Every one of its eight lower parser modules is included in the input
closure and `pure_function_helper_sha256`. No old prepare, execute, main, source
authentication, comparison evaluator or operational entrypoint is called. Fresh
execution loads the exact five project-module paths/hashes and uses the existing
FunctionalInvocation/read-audit mechanisms. ROOT alone performs imports, AST,
prepare, compiler execution and all tests.

The new copy parser requires one bounded discovery and one final listing summary,
with zero through eight cones and no applied candidate. It records every actual
composition, domain, rejection, trial and qualified candidate line. Distinct
observed cone identities must exactly equal discovery; one supported final
rejection must bind its actual pre-composition or post-domain phase. At most16
different destination tiles per actual cone and128 total STA trials are accepted;
cohort and composition rows bind each trial. Leaf count0..6, truth-row count and
stored mask width are checked as observed log grammar; this is no independent
native or physical truth proof. Candidate indices are contiguous and each binds
its immediately preceding same-identity/BEL/cohort guarded trial, gain>=250ps and
all five guard flags. Both zero and positive candidate counts are permitted;
candidate0 existence is reported only after it actually appears.

Normal predicted completion, exact fresh TEN complete model dictionaries, report
cap16384/count15290 and finite positive reported Fmax are required. The 71 placement
metrics and complete report are compared diagnostically against e137's proved
listing; a later independent whole native/report reproduction comparator is still
required. No single-cone, sixteen-trial, zero-candidate or old endpoint-diagnostic
outcome is assumed. Full log and actual placed/report bytes are retained.

Outputs are exclusive `source-identity.json` and `listing/{run.json,phase.log,
placed.json,timing.json}` in this new directory. Existing profile/output collisions
fail closed. Inputs, runtime, outputs and clean committed source are rechecked on
success and on retained partial failure. Preparation CLI requires actual self,
scope, binary, archive and host SHA arguments; execution requires the resulting
actual profile SHA. The record grants no selected transformation, graph equality,
physical truth, numerical calibration, routed gain, RBF decoding or hardware claim.
