"""Record a fresh predicted ready0 composed-copy listing; no candidate is applied."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-lut-pair-compose-copy-264"
COMPILER = RAW / "lut-pair-compose-copy-264"
COMMIT, BASE = "cae5eb9a326507b688414ba934421286f648a43b", "e137ca5bda7c5e68e6da65f37b5830d12f58727a"
BINARY, ARCHIVE, HOST = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz", COMPILER / "validation/host-validation.json"
BINARY_SHA, ARCHIVE_SHA, HOST_SHA = "a2b5da93a9a91cd95d411fb5773e86136ff62e1fce7896d371c97c756004885e", "c64eb65c4e1ac01a277322bddc90172be836fddd60f2d3a0baf66bad62522dd2", "84416288f9a9b4f85c956ad32dc264efc14d007d2d3278c3abc952a006cc6a1e"
TEST_SHA, CHECKS_SHA, HOST_HELPER_SHA, HOST_SCOPE_SHA = "b0e912b15ebd4ce11cb56cec7a356809ce4bf84ef347851fbcccfbf978a20484", "f0b694224d40ae6eb8c081d13fd0cc1fc75c1e337bd7093168a7a3759a3b6721", "e5cf3243801bcf13f4aed5086ad4914502ed1765bbff15eedf7cf4d589157439", "071a7d054e6dafd79d92962ad0f9466d5987da9aa793a38de2b1c41f019b95a3"
DIAG, OLD, CONTROL = (RAW / name for name in
    ("lut-pair-ready0-endpoint-diagnostic-264", "lut-pair-ready0-listing-264", "lut-pair-ten-control-264"))
DIAG_PROFILE, DIAG_RUN, DIAG_PROOF = DIAG / "source-identity.json", DIAG / "diagnostic/run.json", DIAG / "diagnostic/comparison-diagnostic.json"
DIAG_PROFILE_SHA = "b894dd50f695a788060509567f9d930e7277b63f5e2038af3909f33e43a985b6"
DIAG_RUN_SHA = "f08067560d5fe7c753b403666b89583ee8d5eba03b66a6432cf16f564b69824f"
DIAG_PROOF_SHA = "12a957094445aa1e0eb12409abce889a4a69ba0d9f486f43251498aab0f347d8"
DIAG_HELPER_SHA, DIAG_SCOPE_SHA = "3ea527220aa116a50d3930802fcec56a92572d2b91f685e5fb0e11e0d80f76d6", "a7bd7c1b16d169a96a55dac3747ddbb5e91b1d8c0f35ddf005c557124bfd3d8c"
DIAG_COMPARER_SHA, DIAG_COMPARISON_SCOPE_SHA = "d827962d106bb68bc34eff33d2856aa0ab98324a15370174f52f32d15d51220b", "615c5ba0a2a3a6606cdbc311582fa14b2971d7b1b64843220368f21fdf83fb4c"
OLD_PROFILE_SHA = "53f82bb5adc3bcac143097cade72eefbbb076344cb4243c31f109cd8993b9103"
OLD_RUN_SHA = "15e5a0c3e188811d870201e204b0cb0b9dcfadca545d0b051d2580f62e5f2fe4"
OLD_PROOF_SHA = "94627ac9a7ce2d8df01549d673233e914326fed48e9dd538042e5a37597f50d5"
OLD_HELPER_SHA, OLD_SCOPE_SHA = "6a053c8b28d5fa20ede4ba5ffdfe72f45bba48128931242407e380ac874b4964", "fb6d6ab4ce4ac93ac5d7293da2773b6756d898b1831531b7eff02b64d9a15c19"
OLD_COMPARER_SHA, OLD_COMPARISON_SCOPE_SHA = "558d267935a07370971aa54748662131fd8473a35738ddb7442bbb67060de205", "d33bc3f0ee3f4dd9bf831b3fafefe4ea5c243b913739064e771655429c261e2e"
CONTROL_PROFILE_SHA = "d8c15d6b1ec82481f4dd3131136a8e7a913488a9f2961ec5da2f9e9a19f16413"
CONTROL_RUN_SHA = "581f3dd629fc00c7887bca7b6d8415fec214ce1cbe042c754e9eff776dbe3caa"
CONTROL_PROOF_SHA = "9498fb62edd6a9a25a3d8db137f1b7c32cc03dccd3be5a81233be639c81a196e"
CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA = "f72f98877a989f2457800989a69de7ef24d449cac4f6af759abc34a8ca447b13", "90494f8f0085b28b1d3a762508b09dff66396fab5c29994a869a319c3eaee903"
CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA = "1350e1ae0913ded6504c44bf3b75174c5121a06995e8c2924162d9a59864da2e", "a9a8951997616e288371ca9532bb573b136704f2f880b0a69e9ba9453f1cf1b2"
OLD_COMPILER = RAW / "lut-pair-endpoint-diagnostics-264/nextpnr-mistral"
OLD_COMPILER_SHA = "ac6a481b0f8d57a2f8da7dee22a7be00e9003aa4bc941d504093c6285bb42a08"
GUIDE, GUIDE_SHA = OLD / "ready0-guide.json", "9bdad54100c802d4a4aa366203afcaaffcfd4f69456d0ec2b0f6ac58ac786d41"
PLAN, PLAN_SHA = RAW / "local-plan16-ready1-command-stage-264/local-plan.json", "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "listing"
PHASE = "lut-pair-ready0-compose-copy-predicted-listing"
OLD_COMMIT = "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc"
CHANGED = {"mistral/lut_pair_copy.cc", "mistral/arch.h", "mistral/main.cc", "mistral/lut_pair_placement.cc",
    "mistral/lut_pair_placement.h", "mistral/CMakeLists.txt", "mistral/lut_pair_placement.md",
    "mistral/tests/lut_pair_placement.cc", "mistral/tests/lut_pair_placement_cli.py"}
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch("[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original pathname hash")
    if path not in inputs:
        require(sha(path) == expected, "original input differs: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat runtime entry is not absolute"); bind(inputs, name, expected)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def definitions():
    control = load(CONTROL / "run_baseline.py", CONTROL_HELPER_SHA, "ready0_copy_listing_ten_pure")
    return control, control.definitions()


def command(old):
    result = list(old["command"])
    require(result[0] == str(OLD_COMPILER) and result.count("--no-route") == result.count("--remap-plan") ==
        result.count("--remap-lut-pair-critical") == result.count("--remap-lut-pair-candidate") == 1 and
        result[result.index("--remap-plan") + 1] == str(PLAN) and result[result.index("--remap-lut-pair-critical") + 1] == str(GUIDE) and
        result[result.index("--remap-lut-pair-candidate") + 1] == "-1" and not any(flag in result for flag in
        ("--no-pack", "--no-place", "--rbf", "--remap-post-plan", "--remap-lut-pair-compose-copy", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")),
        "proved diagnostic listing command role differs")
    result[0] = str(BINARY)
    for flag, name in (("--write", "placed.json"), ("--report", "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector"); result[result.index(flag) + 1] = str(FOLDER / name)
    return result + ["--remap-lut-pair-compose-copy"]


def expected_execution(old):
    result = copy.deepcopy(old["execution"])
    require(result["files"].pop(str(OLD_COMPILER)) == OLD_COMPILER_SHA and str(BINARY) not in result["files"] and
        result["environment"]["PATH"] == str(OLD_COMPILER.parent) + ":/usr/bin:/bin", "proved diagnostic compiler/PATH differs")
    result["files"][str(BINARY)] = BINARY_SHA; result["files"] = dict(sorted(result["files"].items()))
    result["environment"]["PATH"] = str(BINARY.parent) + ":/usr/bin:/bin"
    return result


def closed_record(record, profile, path, expected, execution_key):
    require(record["completed"] is True and record["exit_code"] == 0 and
        record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
        record["source_identity_sha256"] == expected and record["execution"] == profile[execution_key] and
        record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(canonical(record[key]) == canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "prerequisite profile/run is not closed")


def validate_host(host):
    counts = {"pair_backend": 12, "copy_backend": 11, "native_plan": 25, "driver_backend": 10,
        "pair_cli": 17, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and
        host["check_results_sha256"] == CHECKS_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and set(host["changed_source_files"]) == CHANGED and
        set(host["checks"]) == set(counts) and all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
        all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"] and
        all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in host["committed_archive_manifest_sha256"]), "new independent compose-copy host/source/check qualification differs")


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == CHANGED,
        "new copy source is not the clean reviewed nine-file commit")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
        [(SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "current model/submodule identity changed")


def qualification(log, control, parsers):
    lines = log.splitlines()
    discovery = list(re.finditer(r"^Info: LUT pair copy discovery: (\d+) bounded cones\.$", log, re.M))
    summary = list(re.finditer(r"^Info: LUT pair copy: (\d+) qualified candidates; no candidate applied\.$", log, re.M))
    require(len(discovery) == len(summary) == 1 and discovery[0].end() < summary[0].start() and int(discovery[0][1]) <= 8 and
        not any(line.startswith("Info: LUT pair placement") or line.startswith("Info: LUT pair copy applied") for line in lines), "fresh copy-only listing discovery/summary differs")
    models = control.qualification(log[:discovery[0].start()], parsers)
    patterns = {
        "composition": r"composition inner=(\S+) outer=(\S+) sink=(\S+\.ENA) cohort=(\d+) leaves=(\d+) truth_rows=(\d+) mask=(0x[0-9a-f]{16})",
        "domains": r"domains inner=(\S+) outer=(\S+) sink=(\S+\.ENA) endpoints=(\d+) timed_pairs=(\d+) unrelated_pairs=(\d+) hold_pairs=(\d+) reference_free=([01])",
        "trial": r"trial inner=(\S+) outer=(\S+) sink=(\S+\.ENA) clone_bel=(\S+) gain=(-?\d+)ps improve=([01]) endpoints=([01]) clocks=([01]) hold=([01]) fixed=([01]) cohort=(\d+)",
        "candidate": r"candidate (\d+): inner=(\S+) outer=(\S+) sink=(\S+\.ENA) clone_bel=(\S+) gain=(-?\d+)ps cohort=(\d+)\.",
        "rejection": r"rejection inner=(\S+) outer=(\S+) sink=(\S+\.ENA) reason=(\S+)"}
    early_reasons = {"source-pair-not-safe-ordinary-luts", "target-not-safe-ordinary-ff-enable", "target-clock-unavailable",
        "whole-enable-cohort-unavailable", "composition-unavailable", "boundary-clock-or-fanout-unavailable",
        "native-baseline-unavailable", "endpoint-or-arrival-coverage-unavailable"}
    observed = {kind: [] for kind in patterns}; frames = {}; trials = []; choices = []; raw = []; last_kind = None
    for event in re.finditer(r"^Info: LUT pair copy.*$", log, re.M):
        line = event[0]
        raw.append(line)
        if line == discovery[0][0] or line == summary[0][0]: continue
        require(discovery[0].end() < event.start() < summary[0].start(), "copy evidence is outside its listing block")
        matches = [(kind, re.fullmatch("Info: LUT pair copy " + pattern, line)) for kind, pattern in patterns.items()]
        matches = [(kind, match) for kind, match in matches if match]
        require(len(matches) == 1, "unknown copy listing diagnostic form")
        kind, match = matches[0]; row = list(match.groups()); observed[kind].append(row)
        require(kind != "candidate" or last_kind == "trial", "copy candidate is not immediately after its actual trial")
        last_kind = kind
        identity = tuple(row[1:4] if kind == "candidate" else row[:3])
        frame = frames.setdefault(identity, {"composition": None, "domains": None, "trials": [], "rejection": None})
        require(frame["rejection"] is None, "copy cone emits evidence after its final rejection")
        if kind == "rejection":
            require(not frame["trials"] and ((row[3] in early_reasons and frame["composition"] is frame["domains"] is None) or
                (row[3] == "private-name-space-exhausted" and frame["composition"] and frame["domains"])), "copy rejection reason/phase differs")
            frame["rejection"] = row
        elif kind == "composition":
            cohort, leaves, truth = map(int, row[3:6])
            require(frame["composition"] is None and cohort > 0 and 0 <= leaves <= 6 and truth == 1 << leaves and
                int(row[6], 16) < 1 << (1 << max(2, leaves)), "copy composition count/mask bounds differ")
            frame["composition"] = row
        elif kind == "domains":
            endpoints, timed, unrelated, holds, reference = map(int, row[3:])
            require(frame["composition"] and frame["domains"] is None and endpoints > 0 and timed + unrelated > 0 and
                holds <= timed + unrelated and reference == int(unrelated > 0), "copy actual domain counts/order differ")
            frame["domains"] = row
        elif kind == "trial":
            bel = re.fullmatch(r"MISTRAL_M?COMB\.(\d+)\.(\d+)\.(\d+)", row[3])
            require(frame["composition"] and frame["domains"] and bel and int(row[10]) == int(frame["composition"][3]) and
                len(frame["trials"]) < 16 and not any(prior[3].split(".")[1:3] == row[3].split(".")[1:3] for prior in frame["trials"]), "copy trial site/cohort/bounds differ")
            frame["trials"].append(row); trials.append(row)
        else:
            require(trials and int(row[0]) == len(choices), "copy candidate order/trial absent")
            trial = trials[-1]
            require(row[1:6] == trial[:5] and row[6] == trial[10] and trial[5:10] == ["1"] * 5 and int(trial[4]) >= 250,
                "copy candidate lacks its preceding complete guarded actual trial")
            choices.append({"candidate": int(row[0]), "inner": row[1], "outer": row[2], "sink": row[3],
                "clone_bel": row[4], "gain_ps": int(row[5]), "cohort": int(row[6]), "actual_guarded_trial": trial})
    qualified = [row for row in trials if row[5:10] == ["1"] * 5 and int(row[4]) >= 250]
    require(len(frames) == int(discovery[0][1]) and all(frame["rejection"] or (frame["composition"] and frame["domains"]) for frame in frames.values()) and
        len(trials) <= 128 and len(choices) == int(summary[0][1]) == len(qualified) and
        [row["actual_guarded_trial"] for row in choices] == qualified and len(models) == 10, "bounded copy listing candidate/actual trial totals differ")
    return models, {"discovered_bounded_cones": int(discovery[0][1]), "qualified_candidates": len(choices), "candidate0_reported": bool(choices),
        "actual_trial_count": len(trials), "actual_trial_rows": trials, "actual_qualified_candidates": choices,
        "actual_composition_rows": observed["composition"], "actual_domain_rows": observed["domains"], "actual_rejection_rows": observed["rejection"],
        "all_copy_diagnostic_lines": raw, "candidate_applied": False, "native_or_physical_composition_independently_proved": False,
        "selected_candidate_or_routed_gain_accepted": False}


def prepare(self_sha, scope_sha, binary_sha, archive_sha, host_sha):
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in
        (self_sha, scope_sha, BINARY_SHA, ARCHIVE_SHA, HOST_SHA, TEST_SHA, CHECKS_SHA, HOST_HELPER_SHA, HOST_SCOPE_SHA)), "actual copy compiler/host pins remain UNFROZEN")
    require((binary_sha, archive_sha, host_sha) == (BINARY_SHA, ARCHIVE_SHA, HOST_SHA) and not PROFILE.exists() and not FOLDER.exists(), "actual activation pins/exclusive listing outputs required")
    inputs = {}
    anchors = ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (DIAG_PROFILE, DIAG_PROFILE_SHA), (DIAG_RUN, DIAG_RUN_SHA), (DIAG_PROOF, DIAG_PROOF_SHA),
        (DIAG / "run_diagnostic.py", DIAG_HELPER_SHA), (DIAG / "scope.md", DIAG_SCOPE_SHA), (DIAG / "compare_diagnostic.py", DIAG_COMPARER_SHA), (DIAG / "comparison-scope.md", DIAG_COMPARISON_SCOPE_SHA),
        (OLD / "source-identity.json", OLD_PROFILE_SHA), (OLD / "listing/run.json", OLD_RUN_SHA), (OLD / "listing/comparison-listing.json", OLD_PROOF_SHA),
        (OLD / "run_listing.py", OLD_HELPER_SHA), (OLD / "scope.md", OLD_SCOPE_SHA), (OLD / "compare_listing.py", OLD_COMPARER_SHA), (OLD / "comparison-scope.md", OLD_COMPARISON_SCOPE_SHA),
        (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA), (CONTROL / "baseline/run.json", CONTROL_RUN_SHA), (CONTROL / "baseline/comparison-control.json", CONTROL_PROOF_SHA),
        (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA), (CONTROL / "scope.md", CONTROL_SCOPE_SHA), (CONTROL / "compare_control.py", CONTROL_COMPARER_SHA), (CONTROL / "comparison-scope.md", CONTROL_COMPARISON_SCOPE_SHA),
        (HOST, host_sha), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA), (BINARY, binary_sha), (ARCHIVE, archive_sha), (GUIDE, GUIDE_SHA), (PLAN, PLAN_SHA))
    for path, expected in anchors: bind(inputs, path, expected)
    previous, previous_profile, diag_proof, old, old_profile, old_proof, control_record, control_profile, control_proof, host = (read(path) for path in
        (DIAG_RUN, DIAG_PROFILE, DIAG_PROOF, OLD / "listing/run.json", OLD / "source-identity.json", OLD / "listing/comparison-listing.json",
         CONTROL / "baseline/run.json", CONTROL / "source-identity.json", CONTROL / "baseline/comparison-control.json", HOST))
    for record, profile, path, expected, execution_key in ((previous, previous_profile, DIAG_PROFILE, DIAG_PROFILE_SHA, "diagnostic_execution"),
        (old, old_profile, OLD / "source-identity.json", OLD_PROFILE_SHA, "listing_execution"), (control_record, control_profile, CONTROL / "source-identity.json", CONTROL_PROFILE_SHA, "baseline_execution")):
        closed_record(record, profile, path, expected, execution_key)
    specifications = ((diag_proof, "lut-pair-ready0-endpoint-diagnostic-native-reproduction", DIAG_PROFILE_SHA, "current_diagnostic_run_sha256", DIAG_RUN_SHA, DIAG_COMPARER_SHA, DIAG_COMPARISON_SCOPE_SHA, DIAG_HELPER_SHA, DIAG_SCOPE_SHA, BASE, previous, "fresh_lut_pair_endpoint_diagnostic_reproduction_proved", "model_or_diagnostic_rejection"),
        (old_proof, "lut-pair-ready0-listing-native-reproduction", OLD_PROFILE_SHA, "current_listing_run_sha256", OLD_RUN_SHA, OLD_COMPARER_SHA, OLD_COMPARISON_SCOPE_SHA, OLD_HELPER_SHA, OLD_SCOPE_SHA, OLD_COMMIT, old, "fresh_lut_pair_listing_reproduction_proved", "model_or_listing_rejection"),
        (control_proof, "lut-pair-disabled-ten-stage-native-control", CONTROL_PROFILE_SHA, "current_baseline_run_sha256", CONTROL_RUN_SHA, CONTROL_COMPARER_SHA, CONTROL_COMPARISON_SCOPE_SHA, CONTROL_HELPER_SHA, CONTROL_SCOPE_SHA, OLD_COMMIT, control_record, "fresh_lut_pair_control_prerequisite_proved", None))
    for proof, phase, profile_sha, run_key, run_sha, generator, scope, recorder, recorder_scope, commit, record, flag, model_rejection in specifications:
        require(proof["schema"] == 1 and proof["phase"] == phase and proof["source_identity_sha256"] == profile_sha and proof[run_key] == run_sha and
            proof["generator_sha256"] == generator and proof["scope_sha256"] == scope and proof["recorder_sha256"] == recorder and proof["recorder_scope_sha256"] == recorder_scope and
            proof["compiler_commit"] == commit and proof["current_actual_execution"] == record["execution"] and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and (model_rejection is None or proof[model_rejection] is None) and
            all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact",
                "complete_predicted_report_exact", flag, "final_original_path_metadata_and_runtime_hashes_stable")), "closed historical reproduction prerequisite differs")
        adopt(inputs, proof)
    require(all(control_proof[key] == {"d7e_original_ten": True, "b3d_disabled_post_ten": True} for key in
        ("ten_model_equality_by_reference", "placement_metric_equality_by_reference", "complete_report_equality_by_reference")), "historical dual-reference parity differs")
    validate_host(host)
    for entry in (previous, old, control_record):
        folder = Path(entry["command"][entry["command"].index("--write") + 1]).parent
        require(set(entry["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")}, "prerequisite output triplet differs")
        for ledger in (entry["input_sha256"], entry["output_sha256"], entry["execution"]["files"]):
            for path, expected in ledger.items():
                require(Path(path).is_absolute(), "original closure path is not absolute"); bind(inputs, path, expected)
    for ledger in (host[key] for key in HOST_MAPS):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "host closure path is not absolute"); bind(inputs, path, expected)
    for name, expected in SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    control, parsers = definitions()
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    models = control.qualification((CONTROL / "baseline/phase.log").read_text(), parsers)
    require(len(models) == 10 and all(canonical(entry["actual_selected_local_qualification"]) == canonical(models) for entry in (previous, old, control_record)) and
        all(canonical(proof["fresh_local_models"]) == canonical(models) for proof in (diag_proof, old_proof, control_proof)) and
        previous["compiler_commit"] == BASE and previous["binary_sha256"] == OLD_COMPILER_SHA and read(GUIDE) == {"critical_paths": [previous["exact_current_path_object"]]} and
        read(PLAN)["steps"] == previous["local_plan_steps"] == old["local_plan_steps"] == control_record["local_plan_steps"] and
        len(previous["local_plan_steps"]) == 10 and len(previous["all_original_ff_bel_manifest"]) == 8221, "proved TEN/guide/current compiler provenance differs")
    profile = {"schema": 1, "phase": PHASE, "compiler_commit": COMMIT, "delta_base_commit": BASE, "binary_sha256": BINARY_SHA,
        "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "previous_diagnostic_profile_sha256": DIAG_PROFILE_SHA, "previous_diagnostic_run_sha256": DIAG_RUN_SHA, "previous_diagnostic_proof_sha256": DIAG_PROOF_SHA,
        "previous_listing_profile_sha256": OLD_PROFILE_SHA, "previous_listing_run_sha256": OLD_RUN_SHA, "previous_listing_proof_sha256": OLD_PROOF_SHA,
        "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": CONTROL_RUN_SHA, "control_proof_sha256": CONTROL_PROOF_SHA,
        "guide_path": str(GUIDE), "guide_sha256": GUIDE_SHA, "exact_current_path_object": previous["exact_current_path_object"],
        "original_plan_path": str(PLAN), "original_plan_sha256": PLAN_SHA, "local_plan_steps": previous["local_plan_steps"],
        "retained_local_models": models, "retained_copy_cohorts": previous["retained_copy_cohorts"], "all_original_ff_bel_manifest": previous["all_original_ff_bel_manifest"],
        "pair_candidate_selection": -1, "compose_copy_requested": True, "command": command(previous), "cwd": previous["cwd"],
        "diagnostic_environment": previous["diagnostic_environment"], "listing_execution": expected_execution(previous),
        "pure_function_helper_sha256": {str(CONTROL / "run_baseline.py"): CONTROL_HELPER_SHA, **{str(path): expected for path, expected in control.PARSERS}},
        "authorized_runtime_delta": {"old_compiler_path": str(OLD_COMPILER), "old_compiler_sha256": OLD_COMPILER_SHA, "new_compiler_path": str(BINARY),
            "new_compiler_sha256": BINARY_SHA, "controlled_path_directory_replaced": True, "all_other_execution_fields_and_files_exact": True},
        "post_plan_requested": False, "driver_pass_executed": False, "native_or_physical_reproduction_inherited": False, "routed_gain_accepted": False,
        "hardware_tested": False, "input_sha256": dict(sorted(inputs.items()))}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "compose_copy_listing_only": True}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, previous, host = read(PROFILE), read(DIAG_RUN), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    require(not FOLDER.exists() and profile["phase"] == PHASE and profile["command"] == command(previous) and profile["listing_execution"] == expected_execution(previous) and
        profile["cwd"] == previous["cwd"] == str(MODULE) and profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
        profile["pair_candidate_selection"] == -1 and profile["compose_copy_requested"] is True and
        all(inputs[str(path)] == profile[key] == expected for path, key, expected in ((DIAG_PROFILE, "previous_diagnostic_profile_sha256", DIAG_PROFILE_SHA),
            (DIAG_RUN, "previous_diagnostic_run_sha256", DIAG_RUN_SHA), (DIAG_PROOF, "previous_diagnostic_proof_sha256", DIAG_PROOF_SHA), (HOST, "host_validation_sha256", HOST_SHA),
            (BINARY, "binary_sha256", BINARY_SHA), (ARCHIVE, "source_archive_sha256", ARCHIVE_SHA), (GUIDE, "guide_sha256", GUIDE_SHA))) and
        inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
        read(GUIDE) == {"critical_paths": [profile["exact_current_path_object"]]}, "frozen copy listing profile/guide/command/runtime differs")
    control, parsers = definitions(); validate_host(host); clean_source(host)
    require(profile["pure_function_helper_sha256"] == {str(CONTROL / "run_baseline.py"): CONTROL_HELPER_SHA, **{str(path): expected for path, expected in control.PARSERS}} and
        all(inputs[path] == expected for path, expected in profile["pure_function_helper_sha256"].items()), "pure parser closure differs")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["listing_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual copy listing runtime differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "fresh compose-copy listing did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step")) and
            not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "compose-copy listing is not final predicted-only")
        models, listing = qualification(log, control, parsers)
        record["actual_selected_local_qualification"], record["actual_pair_copy_listing"] = models, listing
        record["all_ten_complete_trial_models_exact"] = canonical(models) == canonical(profile["retained_local_models"])
        require(record["all_ten_complete_trial_models_exact"], "fresh compose-copy compiler changed TEN models")
        metric = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
        rows, old_rows = metric.findall(log), metric.findall((DIAG_RUN.parent / "phase.log").read_text())
        record["all_71_placement_metrics_exact_diagnostic"] = len(rows) == len(old_rows) == 71 and rows == old_rows
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "complete predicted report count/cap/Fmax differs")
        record["actual_predicted_fmax"] = report["fmax"]
        record["complete_predicted_report_exact_diagnostic"] = canonical(report) == canonical(read(DIAG_RUN.parent / "timing.json"))
        record["output_sha256"] = {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "actual listing output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "trials": listing["actual_trial_count"], "qualified_candidates": listing["qualified_candidates"],
            "native_or_physical_reproduction_inherited": False, "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                    try:
                        finish({**inputs, **record["output_sha256"]}); invocation.verify(); clean_source(host)
                        record["final_original_input_output_runtime_hashes_stable"] = True
                    except BaseException as final_error:
                        record["final_original_input_output_runtime_hashes_stable"] = False; record["final_hash_or_runtime_failure"] = repr(final_error)
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "binary-sha256", "archive-sha256", "host-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.binary_sha256, args.archive_sha256, args.host_sha256)
        require(all(values), "actual preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
