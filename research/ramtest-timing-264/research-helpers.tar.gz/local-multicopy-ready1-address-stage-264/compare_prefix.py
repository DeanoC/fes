"""Conditional native proof of exactly six additional ready1 ENA transfers."""
import argparse
import copy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PREVIOUS = RAW / "local-multicopy-ready1-264"
PROFILE_SHA = "a1bb561addd651de30f027006ec9e69665090d4d5bb9b8dca7f22a5b368c01dc"
RUNNER_SHA = "a2d626253826a6b187713f42904720ecdb1d06754ab2776c1fa9d7b39437e2f4"
RUNNER_SCOPE_SHA = "b21d94fd2180981a84abb697044ca41f85051e17a04bcc66f683bfff752d7c52"
PREFIX_SHA = "10016a0f227b801995eebc5c41a79c3b08d28bb6932b785349a60529d0048709"
PREVIOUS_RUN_SHA = "2e3996888f9297140962000d890102de5ea6936a014bca1c9c603fbe19284e5e"
OLD_HELPER_SHA = "0a52299ec2c2547dd24407bbad78caa904093ee0514c0c28ea6eda04e1e44744"
COMMIT, BASE = "81243a1300304d7e598156c692be2fcbf2c16268", "5dd69a8ddece6280d576816d2277c73f80607f52"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, expected, name):
    import hashlib
    import importlib.util
    import sys
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def prove(native, selected, old, before_doc, after_doc, profile, models):
    require(set(before_doc) == set(after_doc) == {"creator", "modules"} and before_doc["creator"] == after_doc["creator"] and
            set(before_doc["modules"]) == set(after_doc["modules"]) == {"top"}, "predicted document schema/creator differs")
    a, b = before_doc["modules"]["top"], after_doc["modules"]["top"]
    model = models[4]
    inner, outer = model["inner"], model["outer"]
    retained, second, clone = outer + "$local_remap", outer + "$local_remap$1", outer + "$local_remap$2"
    alias = clone + "$Q"
    require(clone == profile["expected_additional_copy_name"] and retained == profile["retained_first_copy"] and
            second == profile["retained_second_copy"] and set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and
            list(a) == list(b) and all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "attributes", "ports")) and
            list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (14901, 14902, 16639, 16640) and
            set(b["cells"]) == set(a["cells"]) | {clone} and clone not in a["cells"] and
            set(b["netnames"]) == set(a["netnames"]) | {alias} and alias not in a["netnames"] and
            [name for name in b["cells"] if name != clone] == list(a["cells"]) and
            [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports), "exact module/order/PLL/one-cell/one-net population differs")
    require(all("FES_LABSTATE_V1" not in top["attributes"] and
            all(cell["type"] != "MISTRAL_BUF" and "FES_PINMAP_V1" not in cell["attributes"] for cell in top["cells"].values())
            for top in (a, b)), "predicted frame unexpectedly contains physical snapshots or late buffers")
    od, ou = selected.native_tables(a)
    nd, nu = selected.native_tables(b)
    allowed, frames = {}, []
    for owner in (*old.PRIVATE_OWNERS, second):
        named_alias = owner + "$Q"
        old.lut(a["cells"][owner]); old.lut(b["cells"][owner])
        old_bit, new_bit = old.scalar(a["cells"][owner], "Q"), old.scalar(b["cells"][owner], "Q")
        users = ou.get(old_bit)
        require(od.get(old_bit) == nd.get(new_bit) == [(owner, "Q", 0, 0)] and users and users == nu.get(new_bit),
                "declared private owner unique driver/complete named consumers differ: " + owner)
        for top, bit in ((a, old_bit), (b, new_bit)):
            require([name for name, net in top["netnames"].items() if bit in net["bits"]] == [named_alias] and
                    top["netnames"][named_alias]["bits"] == [bit] and all(bit not in p["bits"] for p in top["ports"].values()),
                    "private output sole alias/no-public boundary differs: " + owner)
        left, right = copy.deepcopy(a["netnames"][named_alias]), copy.deepcopy(b["netnames"][named_alias])
        left.pop("bits"); right.pop("bits")
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + owner)
        for slot in [(owner, "Q", 0, 0)] + users:
            require(slot not in allowed and slot[3] == 0 and
                    a["cells"][slot[0]]["connections"][slot[1]][slot[2]] == old_bit and
                    b["cells"][slot[0]]["connections"][slot[1]][slot[2]] == new_bit, "private named slots overlap or differ")
            allowed[slot] = (old_bit, new_bit)
        frames.append({"owner": owner, "alias": named_alias, "old_raw_bit": old_bit, "new_raw_bit": new_bit,
            "raw_bit_changed": old_bit != new_bit, "named_consumer_slots": [list(slot) for slot in users],
            "native_driver": [owner, "Q", 0, 0]})
    require(len({row["old_raw_bit"] for row in frames}) == len({row["new_raw_bit"] for row in frames}) == 5,
            "five declared private output frames overlap")
    wi, mi, ai, qi = old.lut(a["cells"][inner])
    wo, mo, ao, qo = old.lut(a["cells"][outer])
    wp, mp, ap, qp = old.lut(a["cells"][retained])
    ws, ms, ais, qsecond = old.lut(a["cells"][second])
    wc, mc, ac, qc = old.lut(b["cells"][clone])
    require((wi, wo, wp, ws, wc, mi, mo, mp, ms, mc) == (2, 3, 4, 4, 4, 0xb, 0x32, 0x4440, 0x4440, 0x4440) and
            ao.count(qi) == 1 and len(set(ac)) == 4 and ac == ap == ais and
            set(ac) == set(ai + [bit for bit in ao if bit != qi]) and
            not ({qi, qo, qp, qsecond, qc} & set(ac)) and len({qi, qo, qp, qsecond}) == 4 and qc not in {qi, qo, qp} and
            b["cells"][clone]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
            b["netnames"][alias]["bits"] == [qc] and nd.get(qc) == [(clone, "Q", 0, 0)] and
            [name for name, net in b["netnames"].items() if qc in net["bits"]] == [alias] and
            all(qc not in p["bits"] for p in b["ports"].values()), "actual ready composition/new private site differs")
    left, right = copy.deepcopy(a["cells"][second]), copy.deepcopy(b["cells"][clone])
    for cell in (left, right):
        cell["attributes"].pop("NEXTPNR_BEL")
        cell["connections"].pop("Q")
    require(native.canonical(left) == native.canonical(right) and
            list(a["cells"][second]["connections"]) == list(b["cells"][clone]["connections"]) and
            list(a["cells"][second]["port_directions"]) == list(b["cells"][clone]["port_directions"]),
            "third-copy metadata/input/port order differs beyond its fresh BEL/Q")
    left, right = dict(a["netnames"][second + "$Q"]), dict(b["netnames"][alias])
    left.pop("bits"); right.pop("bits")
    require(native.canonical(left) == native.canonical(right), "new private alias metadata differs")
    first_slots = [tuple(slot) for slot in profile["retained_first_copy_consumers"]]
    second_slots = [(row["cell"], row["port"], row["vector_index"], row["occurrence"]) for row in profile["retained_second_copy_consumers"]]
    require(ou.get(qp) == nu.get(qp) == sorted(first_slots) and len(first_slots) == 2 and
            native.canonical(a["cells"][retained]) == native.canonical(b["cells"][retained]) and
            ou.get(qsecond) == nu.get(old.scalar(b["cells"][second], "Q")) == sorted(second_slots) and len(second_slots) == 1,
            "original two-user or existing one-user copy/cohort differs")
    chosen = nu.get(qc, [])
    declared = sorted((row["cell"], row["port"], row["vector_index"], row["occurrence"]) for row in profile["declared_ena_cohort"])
    group = sorted(slot for slot in ou.get(qo, []) if old.lab(a["cells"][slot[0]]) == model["primary_lab"])
    require(model["primary_lab"] == [24, 12] and model["selected_groups"] == 1 and model["ena_users"] == 6 and
            len(ou.get(qo, [])) == 108 and len(nu.get(qo, [])) == 102 and chosen == group == declared and len(chosen) == 6 and
            sorted(slot for slot in ou[qo] if slot not in chosen) == nu[qo] and
            not set(chosen) & (set(first_slots) | set(second_slots)), "original108→102/fifth6/retained2+1 ENA partition differs")
    for slot in ou[qo] + first_slots + second_slots:
        cell = a["cells"][slot[0]]
        require(slot[1:] == ("ENA", 0, 0) and cell["type"] == "MISTRAL_FF" and old.scalar(cell, "CLK") == 3549,
                "original ready union is not the common-clock scalar FF ENA cohort")
    redirects = []
    for slot in chosen:
        require(slot not in allowed and old.scalar(a["cells"][slot[0]], "ENA") == qo and
                old.scalar(b["cells"][slot[0]], "ENA") == qc, "declared fifth ENA slot overlaps or differs")
        allowed[slot] = (qo, qc)
        redirects.append({"cell": slot[0], "port": "ENA", "vector_index": 0, "occurrence": 0,
            "old_raw_bit": qo, "new_raw_bit": qc, "bel": a["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"]})
    truth, leaves = [], []
    for i, bit in enumerate(ac):
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit) and a["cells"][od[bit][0][0]]["type"] != "MISTRAL_CONST",
                "ready boundary lacks a unique unchanged ordinary driver")
        leaves.append({"port": old.PINS[i], "raw_bit": bit, "native_driver": list(od[bit][0])})
    for assignment in range(16):
        values = {bit: (assignment >> i) & 1 for i, bit in enumerate(ac)}
        iv = (mi >> sum(values[bit] << i for i, bit in enumerate(ai))) & 1
        original = (mo >> sum((iv if bit == qi else values[bit]) << i for i, bit in enumerate(ao))) & 1
        one = (mp >> sum(values[bit] << i for i, bit in enumerate(ap))) & 1
        two = (ms >> sum(values[bit] << i for i, bit in enumerate(ais))) & 1
        new = (mc >> assignment) & 1
        require(original == one == two == new, "conditional original/three-copy ready function differs")
        truth.append({"assignment": assignment, "original": original, "retained_first": one, "retained_second": two, "third": new})
    expected_drivers = dict(od)
    for row in frames:
        del expected_drivers[row["old_raw_bit"]]
    require(qc not in expected_drivers, "new output overlaps an undeclared retained driver")
    for row in frames:
        bit = row["new_raw_bit"]
        require(bit not in expected_drivers and bit != qc, "private output frames overlap another retained/new owner")
        expected_drivers[bit] = [(row["owner"], "Q", 0, 0)]
    expected_drivers[qc] = [(clone, "Q", 0, 0)]
    require(nd == expected_drivers, "complete native driver table differs beyond five named frames/new copy")
    expected_users = {}
    for bit, slots in ou.items():
        for slot in slots:
            expected_users.setdefault(allowed[slot][1] if slot in allowed else bit, []).append(slot)
    for i, bit in enumerate(ac):
        expected_users.setdefault(bit, []).append((clone, old.PINS[i], 0, 0))
    require(nu == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete native users differ beyond named slots/four new input loads")
    for name, cell in a["cells"].items():
        expected = copy.deepcopy(cell)
        for port, bits in expected["connections"].items():
            for index, bit in enumerate(bits):
                slot = (name, port, index, 0)
                if slot in allowed:
                    require(allowed[slot][0] == bit, "original named slot bit differs")
                    bits[index] = allowed[slot][1]
        require(native.canonical(expected) == native.canonical(b["cells"][name]) and
                list(cell["connections"]) == list(b["cells"][name]["connections"]) and
                list(cell["port_directions"]) == list(b["cells"][name]["port_directions"]), "original cell metadata/BEL/order/undeclared raw slot differs: " + name)
    private_aliases = {row["alias"]: row for row in frames}
    for name, net in a["netnames"].items():
        expected = copy.deepcopy(net)
        if name in private_aliases:
            expected["bits"] = [private_aliases[name]["new_raw_bit"]]
        require(native.canonical(expected) == native.canonical(b["netnames"][name]), "original alias/raw bits/metadata differs: " + name)
    ff_bels = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(ff_bels == profile["all_original_ff_bel_manifest"], "complete original FF BEL declaration differs")
    selected_lab = old.lab(b["cells"][clone])
    original_members = [{"cell": name, "record": cell} for name, cell in a["cells"].items()
        if cell["type"] == "MISTRAL_FF" and old.lab(cell) == selected_lab]
    return {"serialized_native_scope_proved": True, "inner": inner, "outer": outer, "new_clone": clone,
        "new_private_alias": alias, "actual_clone_q": qc, "original_root_q": qo,
        "declared_ena_redirects": redirects, "declared_ena_redirect_count": 6,
        "retained_first_copy": retained, "retained_first_copy_consumers": [list(slot) for slot in first_slots],
        "retained_second_copy": second, "retained_second_copy_consumers": [list(slot) for slot in second_slots],
        "original_root_users_before": 108, "original_root_users_after": 102,
        "explicit_private_output_owners": frames, "private_output_owner_count": 5,
        "actual_new_output_reuses_only_declared_old_private_bit": qc not in od or qc in {row["old_raw_bit"] for row in frames},
        "whole_selected_lab": selected_lab, "original_ffs_in_selected_lab": sorted(original_members, key=lambda row: row["cell"]),
        "whole_selected_lab_native_ff_count": len(original_members), "conditional_boundary": leaves,
        "assignments_checked": 16, "conditional_plain_sig_truth_rows": truth,
        "all_original_ff_placements_and_nonprivate_raw_slots_exact": True, "complete_native_driver_and_user_tables_proved": True,
        "original_export_order_and_paired_pll_records_exact": True,
        "physical_pins_lab_cache_gpu_or_independent_sta_proved": False}


def comparison(args):
    require(not (HERE / "baseline/comparison-prefix.json").exists(), "prefix comparison output already exists")
    native = load(PURE, PURE_SHA, "address_prefix_native")
    audit = native.Audit()
    for path, expected in ((PURE, PURE_SHA), (Path(__file__), args.self_sha256), (HERE / "comparison-scope.md", args.scope_sha256),
            (HERE / "run_baseline.py", RUNNER_SHA), (HERE / "scope.md", RUNNER_SCOPE_SHA), (HERE / "source-identity.json", PROFILE_SHA),
            (HERE / "baseline/run.json", args.run_sha256), (PREVIOUS / "baseline/comparison-prefix.json", PREFIX_SHA),
            (PREVIOUS / "baseline/run.json", PREVIOUS_RUN_SHA), (PREVIOUS / "compare_prefix.py", OLD_HELPER_SHA)):
        audit.bind(path, expected)
    runner = load(HERE / "run_baseline.py", RUNNER_SHA, "address_prefix_current_runner_defs")
    profile, record = native.read(HERE / "source-identity.json"), native.read(HERE / "baseline/run.json")
    previous_proof, previous = native.read(PREVIOUS / "baseline/comparison-prefix.json"), native.read(PREVIOUS / "baseline/run.json")
    for name, expected in previous_proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in previous_proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        audit.bind(Path(name), expected, execution=True)
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    require(previous_proof["structural_rejection"] is None and previous_proof["native_graph_proof_available"] is True and
            previous_proof["compiler_commit"] == COMMIT and profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            profile["phase"] == "local-multicopy-ready1-address-fifth-stage-predicted-baseline" and
            profile["previous_prefix_proof_sha256"] == PREFIX_SHA and profile["previous_baseline_run_sha256"] == PREVIOUS_RUN_SHA and
            profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            profile["binary_sha256"] == runner.BINARY_SHA and profile["source_archive_sha256"] == runner.ARCHIVE_SHA and
            profile["host_validation_sha256"] == runner.HOST_SHA and profile["control_proof_sha256"] == runner.CONTROL_SHA,
            "positive prior prefix/current compiler/profile roles differ")
    for key, value in profile.items():
        if key != "input_sha256":
            require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["source_identity_sha256"] == PROFILE_SHA and record["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): PROFILE_SHA} and
            record["command"] == runner.command(previous) and record["execution"] == profile["baseline_execution"] == previous["execution"] and
            record["diagnostic_environment"] == previous["diagnostic_environment"] and record["cwd"] == previous["cwd"] and
            record["original_four_selected_models_exact"] is True, "closed fresh five-stage record/current runtime differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is outside frozen closure")
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")},
            "complete predicted output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output empty")
        audit.bind(Path(name), expected)
    for path, expected in ((runner.SELECTED, runner.SELECTED_SHA), (runner.FREEZE, runner.FREEZE_SHA),
            (PREVIOUS / "run_baseline.py", runner.LOCAL_SHA)):
        require(audit.paths.get(path) == expected, "pure dependency is not in frozen closure")
    frozen = runner.load(runner.FREEZE, runner.FREEZE_SHA, "address_prefix_freeze")
    selected = runner.load(runner.SELECTED, runner.SELECTED_SHA, "address_prefix_tables", frozen)
    old = runner.load(PREVIOUS / "compare_prefix.py", OLD_HELPER_SHA, "address_prefix_old_pure_lut_defs")
    log = (HERE / "baseline/phase.log").read_text()
    four_parser = runner.load(PREVIOUS / "run_baseline.py", runner.LOCAL_SHA, "address_prefix_four_log_parser")
    models = runner.qualification(log, four_parser)
    require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
            native.canonical(models[:4]) == native.canonical(previous["actual_selected_local_qualification"]) == native.canonical(profile["retained_local_models"]),
            "actual fresh five/retained four log models differ")
    placement_exact = native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall((PREVIOUS / "baseline/phase.log").read_text())
    before = native.read_netlist(PREVIOUS / "baseline/placed.json")
    after = native.read_netlist(HERE / "baseline/placed.json")
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(PREVIOUS / "baseline/timing.json")
    topology = selected.report_topology(after, report, old_report)
    require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and
            report["fmax"] == record["actual_predicted_fmax"], "current complete native report topology/count/Fmax differs")
    evidence, rejection = None, None
    try:
        require(placement_exact, "original71 placement metric sequence differs")
        evidence = prove(native, selected, old, before, after, profile, models)
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        rejection = str(error)
    audit.finish()
    return {"schema": 1, "phase": "local-multicopy-ready1-address-fifth-stage-conditional-native-prefix",
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "source_identity_sha256": PROFILE_SHA,
        "current_baseline_run_sha256": args.run_sha256, "previous_prefix_proof_sha256": PREFIX_SHA,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256,
        "candidate_completed": True, "structural_rejection": rejection, "native_graph_proof_available": rejection is None,
        "fresh_driver_guide_available_after_conditional_prefix_proof": rejection is None,
        "native_graph_evidence": evidence, "fresh_local_models": models, "previous_local_models": models[:4],
        "all_71_placement_metrics_exact": placement_exact, "current_complete_native_report_topology": topology,
        "actual_predicted_fmax": report["fmax"], "complete_predicted_report_exact_required": False,
        "conditional_plain_sig_equivalence_only": True, "physical_pin_lab_cache_gpu_or_sta_acceptance_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "run-sha256"):
        parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    import json
    with (HERE / "baseline/comparison-prefix.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_graph_proof_available")}, indent=2))


if __name__ == "__main__":
    main()
