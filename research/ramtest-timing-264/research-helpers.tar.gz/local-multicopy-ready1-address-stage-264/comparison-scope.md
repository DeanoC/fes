# Conditional native proof of the fifth ready1 copy

Root alone activates this new comparator after the actual five-stage run closes.
The current run SHA is mandatory; profilea1bb561a and frozen runnera2d62625/
scopeb21d94fd are fixed. The positive prior prefix10016, its entire flat closure,
the current profile's complete inputs/current runtime and the exact three new
output paths are hashed before use and after comparison. Existing files are
unchanged; the new comparison output is exclusive. Only byte-pinned pure32fd
read/Audit,72131/8601 native topology,440013 four-stage log parser, new runner's
command/fifth log parser and0a522 scalar/LUT/BEL definitions are called. No older
authentication, preparation, execution, comparison, generator or main runs.

The native before image is the actual four-stage predicted graph; after is the
actual fresh five-stage graph. The first four complete model records and all71
placement metrics must be exact. Exactly one ALUT4/private net is added with
the fresh fifth candidate0 site, original ready1 cone, one group/six ENAs and
zero FF shift/clock/hold/boundary/min250ps guards. The old two-user copy keeps
its complete literal cell/raw output/alias/consumer metadata. The existing
one-user second copy keeps its masks/parameters/BEL/metadata/input signals and
the same named ENA consumer; its private Q is separately ledgered because a
later pass may allocate its image-local output ID differently.

Only the entire six existing original-root ENAs in LAB24.12 move to the new$2
copy. The exact original-root partition is108→102, old two plus second one stay
disjoint, and the new output has precisely six named consumers. The actual
four distinct unchanged native leaf signals drive a16-row conditional proof
of original inner0xb/outer0x32 and all three copy0x4440 functions. This assumes
plain signal pin states; predicted exports contain no physical pin/LAB snapshot
or late buffers and cannot establish physical equivalence.

The four other known private LUT output owners and the existing one-user copy
each have their own scalar Q/unique sole alias/no public boundary/complete named
consumer ledger. All actual driver/consumer slots are checked independently in
both images. Whole native driver/user tables are rebuilt from those five
explicit frames, the six ENA transfers and four new input loads. The new output
may reuse only a freed declared private output bit, never an undeclared retained
driver. There is no global offset, numeric normalization or frame mutation.
Every other original raw bit, alias, cell/type/mask/parameter/BEL/metadata,
module/settings/public port, owner/port order and paired ordered PLL occurrence
must be exact. Unexpected additional changes become saved structural rejection;
there is no generic metadata or raw-ID waiver.

Every original FF BEL is checked against the prepared global declaration. The
actual new clone site determines its whole LAB FF neighborhood dynamically from
the bound before image; all its original FFs remain present with their original
metadata, except explicitly ledgered ENA/private consumer slots. No candidate
site is inferred from an earlier experiment. The declared target six rows and
old2/new1 preservation are proven from the actual serialized graph.

The current complete15290-path/seven-pair endpoint/window report is independently
checked against the current graph and prior four-stage report even when structural
proof rejects. Predicted Fmax values remain diagnostic; complete report equality,
routed gain, numerical STA, phase margin, pins/controls/CRAM/cache/GPU state and
hardware acceptance are not claimed. A positive result supplies only a fresh
driver discovery guide after this conditional native prefix proof. Full routing
and independent native/physical/timing acceptance remain separate obligations.
