"""Record a fresh fifth ready1 remap while retaining the exact first four stages."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
PREVIOUS = RAW / "local-multicopy-ready1-264"
FULL = RAW / "local-multicopy-ready1-route-264"
GUIDE_FOLDER = RAW / "local-multicopy-ready1-address-guide-264"
COMPILER = RAW / "local-multicopy-264"
COMMIT, BASE = "81243a1300304d7e598156c692be2fcbf2c16268", "5dd69a8ddece6280d576816d2277c73f80607f52"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-local-multicopy-264"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
CONTROL_SHA = "f3e1f1e84d408db29088c39006b205284ad173bfe900a36f89c6b6122bdb076c"
PREVIOUS_PROFILE_SHA = "8678aa88a57a59c43fc94bab14ff71fdff47b95a9e95d8bc308c82ad7826e88b"
PREVIOUS_RUN_SHA = "2e3996888f9297140962000d890102de5ea6936a014bca1c9c603fbe19284e5e"
PREFIX_SHA = "10016a0f227b801995eebc5c41a79c3b08d28bb6932b785349a60529d0048709"
LOCAL_SHA = "440013e34d68841d103ca0bea4e3d927a9fd9f50917e10800ad604caa1aec36a"
LOCAL_SCOPE_SHA = "a62cb693434bdaa996f00e1694f4768543c98c4794d2c6f4ca3521736e89e170"
FULL_PROFILE_SHA = "83ddcc2b29edb2ed1e6423860a65a3d9806d077dc33a349972ce2d17bf3afcdc"
FULL_RUN_SHA = "8fce72fda3635cc4a6521b8b279fb46826c269bba304f10524e7f8e674ba0c28"
GUIDE, DERIVATION = GUIDE_FOLDER / "ready-guide.json", GUIDE_FOLDER / "derivation.json"
GUIDE_SHA = "704a9e39e17108df4fe371bdbc8e79bdf6569693712a002db2802d4386c645b7"
DERIVATION_SHA = "c95303450d8dccc4f9b8f05996cbc7a55ac9201629607cb21946d57efa726889"
GUIDE_HELPER_SHA = "05b9c2921e1f84ef163e049a7fe7a542a89701351356333bf6840d9217633553"
GUIDE_SCOPE_SHA = "017bbb90a91b318b9307abd005b8098abd1d5d63f2eb8fcf6385a3d716e3b0fe"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PROFILE, PLAN, FOLDER = HERE / "source-identity.json", HERE / "local-plan.json", HERE / "baseline"
INNER, OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B"
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected) and
            (path not in inputs or inputs[path] == expected), "invalid/conflicting original path hash")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path)
        inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original byte pathname changed")


def adopt(inputs, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        bind(inputs, name, expected)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure helper hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure helper path differs")
    return module


def clean_source():
    def git(*args):
        return subprocess.run(["git", "-C", str(SOURCE), *args], check=True, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()
    require(git("rev-parse", "HEAD") == COMMIT and not git("status", "--porcelain", "--untracked-files=all") and
            git("merge-base", BASE, COMMIT) == BASE and set(git("diff", "--name-only", BASE, COMMIT).splitlines()) ==
            {"mistral/local_remap.cc", "mistral/tests/remap_plan.cc"}, "compiler is not the clean committed two-file result")


def command(previous):
    result = list(previous["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == 1 and
            not any(flag in result for flag in ("--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "previous predicted role differs")
    for flag, path in (("--remap-plan", PLAN), ("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous plan/output selector")
        result[result.index(flag) + 1] = str(path)
    return result


def qualification(log, old_parser):
    headers = list(re.finditer(r"^Info: Local-remap plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, h.groups())) for h in headers] == [(i, 0, g, 0, 1) for i, g in enumerate((8, 1, 1, 1, 1))],
            "fresh five-stage headers differ")
    models = old_parser.local_qualification(log[:headers[4].start()])
    block = log[headers[4].end():]
    trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
    choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
    applications = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
    require(trials and len(choices) == len(applications) == 1 and choices[0][1] == applications[0][1] == "0" and
            trials[-1].end() < choices[0].start() < applications[0].start(), "fresh fifth candidate0/application lacks a final guarded trial")
    row, choice = trials[-1].groups(), choices[0].groups()[1:]
    require((row[0], row[1], row[4], row[12], row[7]) == choice and row[:2] == (INNER, OUTER) and
            row[2:4] == ("24", "12") and row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and
            row[11:13] == ("1", "6") and int(row[7]) >= 250, "fresh six-ENA fixed-FF/clock/hold/boundary/gain guards differ")
    models.append({"index": 4, "candidate": 0, "groups_budget": 1, "selected_groups": 1, "inner": INNER, "outer": OUTER,
        "primary_lab": [24, 12], "bel": row[4], "ena_users": 6, "gain_ps": int(row[7]), "actual_trial_count": len(trials),
        "prior_trial_rows": [x.groups() for x in trials[:-1]], "ff_shift": [0, 0],
        "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False})
    return models


def prepare(self_sha, scope_sha):
    require(not any(path.exists() for path in (PROFILE, PLAN, FOLDER)), "fifth-stage profile/plan/outputs already exist")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (GUIDE, GUIDE_SHA), (DERIVATION, DERIVATION_SHA),
            (GUIDE_FOLDER / "derive_guide.py", GUIDE_HELPER_SHA), (GUIDE_FOLDER / "scope.md", GUIDE_SCOPE_SHA),
            (PREVIOUS / "source-identity.json", PREVIOUS_PROFILE_SHA), (PREVIOUS / "baseline/run.json", PREVIOUS_RUN_SHA),
            (PREVIOUS / "baseline/comparison-prefix.json", PREFIX_SHA), (PREVIOUS / "run_baseline.py", LOCAL_SHA),
            (PREVIOUS / "scope.md", LOCAL_SCOPE_SHA), (FULL / "source-identity.json", FULL_PROFILE_SHA),
            (FULL / "route-c0/run.json", FULL_RUN_SHA), (COMPILER / "baseline/comparison-control.json", CONTROL_SHA),
            (COMPILER / "validation/host-validation.json", HOST_SHA), (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA),
            (PURE, PURE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        bind(inputs, path, expected)
    prefix, derived = read(PREVIOUS / "baseline/comparison-prefix.json"), read(DERIVATION)
    adopt(inputs, prefix); adopt(inputs, derived)
    require(prefix["structural_rejection"] is None and prefix["native_graph_proof_available"] is True and
            prefix["compiler_commit"] == COMMIT and prefix["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and
            prefix["current_baseline_run_sha256"] == PREVIOUS_RUN_SHA and prefix["control_proof_sha256"] == CONTROL_SHA and
            derived["phase"] == "local-multicopy-ready1-worst-remaining-lab-exact-guide" and derived["route_profile_sha256"] == FULL_PROFILE_SHA and
            derived["current_full_run_sha256"] == FULL_RUN_SHA and derived["prefix_proof_sha256"] == PREFIX_SHA and
            derived["generator_sha256"] == GUIDE_HELPER_SHA and derived["scope_sha256"] == GUIDE_SCOPE_SHA and
            derived["guide_path"] == str(GUIDE) and derived["guide_sha256"] == GUIDE_SHA and derived["selected_lab"] == [24, 12] and
            derived["selected_paths"] == 6 and derived["all_current_root_paths"] == 108 and
            derived["exact_path_objects_and_original_source_order_preserved"] is True and
            derived["clock_terms_locations_sources_windows_or_segment_delays_modified"] is False,
            "positive fourth-stage prefix or actual six-path guide derivation differs")
    previous, original, full, host = read(PREVIOUS / "baseline/run.json"), read(PREVIOUS / "source-identity.json"), read(FULL / "route-c0/run.json"), read(COMPILER / "validation/host-validation.json")
    require(previous["completed"] is full["completed"] is True and previous["exit_code"] == full["exit_code"] == 0 and
            previous["compiler_read_audit_passed"] is full["compiler_read_audit_passed"] is True and
            previous["compiler_commit"] == full["compiler_commit"] == host["compiler_commit"] == COMMIT and
            previous["binary_sha256"] == full["binary_sha256"] == host["binary_sha256"] == BINARY_SHA and
            previous["source_archive_sha256"] == full["source_archive_sha256"] == host["source_archive_sha256"] == ARCHIVE_SHA and
            previous["execution"] == original["baseline_execution"] == full["execution"] and
            previous["source_identity_sha256"] == PREVIOUS_PROFILE_SHA and full["source_identity_sha256"] == FULL_PROFILE_SHA and
            previous["actual_selected_local_qualification"] == prefix["fresh_local_models"] == full["actual_selected_local_qualification"] and
            previous["input_sha256"] == {**original["input_sha256"], str(PREVIOUS / "source-identity.json"): PREVIOUS_PROFILE_SHA} and
            host["result_commit"] == COMMIT and host["build_passed"] is host["clean_committed_checkout"] is True,
            "closed compiler/source/four-stage/runtime roles differ")
    for record in (previous, full):
        require(all(inputs.get(path) == expected for path, expected in {**record["input_sha256"], **record["output_sha256"],
                **record["execution"]["files"]}.items()), "closed original input/output/runtime closure differs")
    old_plan = read(PREVIOUS / "local-plan.json")
    require(set(old_plan) == {"steps"} and old_plan["steps"] == previous["local_plan_steps"] == original["local_plan_steps"] and
            len(old_plan["steps"]) == 4 and [step["groups"] for step in old_plan["steps"]] == [8, 1, 1, 1], "exact first-four descriptors differ")
    native = load(PURE, PURE_SHA, "address_stage_native")
    frozen = load(FREEZE, FREEZE_SHA, "address_stage_freeze")
    selected = load(SELECTED, SELECTED_SHA, "address_stage_tables", frozen)
    before_doc = native.read_netlist(PREVIOUS / "baseline/placed.json")
    full_doc = native.read_netlist(FULL / "route-c0/routed.json")
    before, routed = before_doc["modules"]["top"], full_doc["modules"]["top"]
    guide, full_report = read(GUIDE), read(FULL / "route-c0/timing.json")
    expected_paths = [path for path in full_report["critical_paths"] if path["path"][-1]["to"]["cell"] in derived["selected_endpoints"] and
        path["path"][-1]["to"]["port"] == "ENA" and path["from"] == path["to"] == "posedge ram_clock.clocks[0]"]
    expected_guide = {**full_report, "critical_paths": expected_paths}
    require(canonical(guide) == canonical(expected_guide) and len(expected_paths) == 6, "guide paths/source order or other report fields changed")
    _, users = selected.native_tables(before)
    q = before["cells"][OUTER]["connections"]["Q"][0]
    cohort = sorted(slot for slot in users[q] if before["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"].startswith("MISTRAL_FF.24.12."))
    require(len(users[q]) == 108 and len(cohort) == 6 and {slot[0] for slot in cohort} == set(derived["selected_endpoints"]),
            "fifth region is not exactly the six remaining original-root users in the current predicted LAB")
    target_rows = []
    for cell_name, port, index, occurrence in cohort:
        a, b = before["cells"][cell_name], routed["cells"][cell_name]
        require((port, index, occurrence) == ("ENA", 0, 0) and a["type"] == b["type"] == "MISTRAL_FF" and
                a["connections"]["CLK"] == b["connections"]["CLK"] == [3549] and a["connections"]["ENA"] == b["connections"]["ENA"] == [q] and
                a["attributes"]["NEXTPNR_BEL"] == b["attributes"]["NEXTPNR_BEL"], "declared actual FF ENA/clock/BEL differs")
        target_rows.append({"cell": cell_name, "port": port, "vector_index": index, "occurrence": occurrence,
            "bel": a["attributes"]["NEXTPNR_BEL"], "old_raw_bit": q, "clock_raw_bit": 3549, "before_record": a})
    retained = prefix["native_graph_evidence"]
    for copy_name, slots in ((retained["retained_copy"], retained["retained_two_consumer_slots"]),
                            (retained["new_clone"], [[row["cell"], "ENA", 0, 0] for row in retained["declared_ena_redirects"]])):
        bit = before["cells"][copy_name]["connections"]["Q"][0]
        require(users.get(bit) == sorted(tuple(slot) for slot in slots) and not set(cohort) & set(tuple(slot) for slot in slots),
                "retained old-two/new-one consumers differ or overlap fifth cohort")
    expected_name = OUTER + "$local_remap$2"
    require(all(name not in before["cells"] and name not in before["netnames"] for name in (expected_name, expected_name + "$Q")),
            "expected next clone pair is occupied in cell/net/alias namespace")
    models = previous["actual_selected_local_qualification"]
    labs = {(24, 12)} | {tuple(model["primary_lab"]) for model in models}
    owners = {INNER, OUTER, retained["retained_copy"], retained["new_clone"]}
    for index, model in enumerate(models):
        owners.update((model["inner"], model["outer"], model["outer"] + ("$local_remap$1" if index == 3 else "$local_remap")))
    for name in owners:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", before["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared cone/copy lacks a placed BEL")
        labs.add(tuple(map(int, match.groups())))
    ff_bels, neighborhoods = {}, []
    for name, cell in before["cells"].items():
        if cell["type"] != "MISTRAL_FF":
            continue
        bel = cell["attributes"].get("NEXTPNR_BEL", "")
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", bel)
        require(match is not None, "original FF lacks a placed BEL")
        ff_bels[name] = bel
        if tuple(map(int, match.groups())) in labs:
            neighborhoods.append({"cell": name, "record": cell})
    for name, expected in SCRIPTS.items():
        bind(inputs, MODULE / "scripts" / name, expected)
    plan = copy.deepcopy(old_plan)
    plan["steps"].append({"report": str(GUIDE), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True})
    require(plan["steps"][:4] == old_plan["steps"], "first-four descriptor order/path/value changed")
    finish(inputs); clean_source()
    with PLAN.open("x") as stream:
        stream.write(json.dumps(plan, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, PLAN, sha(PLAN))
    profile = {"schema": 1, "phase": "local-multicopy-ready1-address-fifth-stage-predicted-baseline", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA,
        "control_proof_sha256": CONTROL_SHA, "previous_prefix_proof_sha256": PREFIX_SHA, "previous_source_identity_sha256": PREVIOUS_PROFILE_SHA,
        "previous_baseline_run_sha256": PREVIOUS_RUN_SHA, "current_full_profile_sha256": FULL_PROFILE_SHA, "current_full_run_sha256": FULL_RUN_SHA,
        "guide_sha256": GUIDE_SHA, "guide_derivation_sha256": DERIVATION_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha,
        "original_four_plan_sha256": inputs[str(PREVIOUS / "local-plan.json")], "local_plan_sha256": inputs[str(PLAN)], "local_plan_steps": plan["steps"],
        "retained_local_models": models, "authorized_plan_delta": {"append_index": 4, "step": plan["steps"][4], "first_four_descriptors_exact": True},
        "expected_additional_copy_name": expected_name, "declared_ena_cohort": target_rows,
        "retained_first_copy": retained["retained_copy"], "retained_first_copy_consumers": retained["retained_two_consumer_slots"],
        "retained_second_copy": retained["new_clone"], "retained_second_copy_consumers": retained["declared_ena_redirects"],
        "declared_whole_labs": sorted(map(list, labs)), "original_ffs_in_declared_labs": sorted(neighborhoods, key=lambda row: row["cell"]),
        "all_original_ff_bel_manifest": dict(sorted(ff_bels.items())), "actual_fifth_site_neighborhood_requires_later_prefix_proof": True,
        "command": command(previous), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"],
        "baseline_execution": previous["execution"], "input_sha256": dict(sorted(inputs.items())),
        "driver_pass_executed": False, "native_graph_or_physical_equivalence_inherited": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source()
    with PROFILE.open("x") as stream:
        stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs)
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "plan_sha256": inputs[str(PLAN)],
        "declared_ena_slots": len(target_rows), "original_ff_bels": len(ff_bels)}, indent=2))


def execute(profile_sha):
    inputs = {}
    bind(inputs, PROFILE, profile_sha)
    profile = read(PROFILE)
    for path, expected in profile["input_sha256"].items():
        bind(inputs, path, expected)
    previous = read(PREVIOUS / "baseline/run.json")
    require(not FOLDER.exists() and profile["command"] == command(previous) and profile["baseline_execution"] == previous["execution"] and
            profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["cwd"] == previous["cwd"] == str(MODULE) and
            profile["compiler_commit"] == COMMIT and profile["retained_local_models"] == previous["actual_selected_local_qualification"] and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and
            inputs[str(BINARY)] == BINARY_SHA and inputs[str(ARCHIVE)] == ARCHIVE_SHA and inputs[str(PLAN)] == profile["local_plan_sha256"] and
            read(PLAN)["steps"] == profile["local_plan_steps"], "frozen current role/helper/command/runtime/plan differs")
    clean_source()
    old_parser = load(PREVIOUS / "run_baseline.py", LOCAL_SHA, "address_stage_four_log_parser")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected,
                "loaded project module differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env),
                "actual current runtime or ambient diagnostics changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            result = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"],
                env={**invocation.env, **profile["diagnostic_environment"]}, stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = result.returncode, True
        invocation.verify()
        require(result.returncode == 0, "fresh fifth-stage compiler did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis...", "LUT driver copy")) and
                not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "actual role is not predicted-only")
        record["actual_selected_local_qualification"] = qualification(log, old_parser)
        record["original_four_selected_models_exact"] = canonical(record["actual_selected_local_qualification"][:4]) == canonical(profile["retained_local_models"])
        require(record["original_four_selected_models_exact"], "fresh first-four models differ from the closed fourth-stage baseline")
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()),
                "actual predicted report cap/count/Fmax differs")
        record["actual_predicted_fmax"], record["output_sha256"] = report["fmax"], {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual predicted output absent")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source()
        record["completed"] = True
        print(json.dumps({"completed": True, "first_four_models_exact": True,
            "actual_fifth_qualification": record["actual_selected_local_qualification"][4], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); finish({**inputs, **record.get("output_sha256", {})}); clean_source()
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False
                    record["final_original_input_output_runtime_hashes_stable"] = False
                    record["final_rehash_failure"] = repr(error)
                    raise
                finally:
                    (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(args.self_sha256 and args.scope_sha256, "helper preparation pins required")
        prepare(args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256, "profile activation pin required")
        execute(args.profile_sha256)


if __name__ == "__main__":
    main()
