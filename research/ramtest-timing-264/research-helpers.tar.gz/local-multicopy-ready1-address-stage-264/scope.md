# Fifth-stage predicted recorder for the remaining ready1 address group

Root alone activates the new prepare/execute entrypoints. Existing helpers,
outputs, compiler81243, binary91a and archivec947 remain unchanged. Preparation
binds the executed six-path guide704a9e39/derivationc9530345, their exact generator
and scope, closed current full83dd/8fce, positive four-stage prefix10016 and
closed predicted8678/2e399, current controlf3e1, host98c1 and all flat original
artifact/input/output/runtime closures. No old generator, authentication,
prepare, execute, comparator or main entrypoint is invoked. Imports use only
byte-pinned pure32fd/72131/8601 definitions and, during execution, the440013
four-stage log parser. Current project execution modules and their exact loaded
paths/hashes remain bound to the actual current runtime.

The only plan delta appends zero-based stage4: the six-path guide, candidate0,
groups1, pinsfalse and fixed FF placement. All first four8/1/1/1 descriptor
values/order/report paths remain exact. The command changes only its plan and
fresh write/report aliases; source/RTL/headers/BUILD_ID/options/seed/device,
preceding/later transforms, compiler path/hash, diagnostic environment and
FunctionalInvocation runtime remain those of the current four-stage baseline.
The phase performs no driver copy, GPU routing, signoff or RBF generation.

Preparation independently checks the exact original full-report path objects,
their source order and all other preserved guide fields. It derives the entire
six-ENA cohort in LAB24.12 from the bound four-stage predicted image and requires
it to equal the six actual full-report endpoints. Each named scalar slot's
clock3549/ENA/BEL agrees across those images. The old two-user copy and second
one-user copy remain disjoint from that group. Base/$1 owners remain present;
the expected next$2 cell/private-net name pair is absent from the complete
cell/net/alias namespaces. These checks declare the allowed future change;
they do not prove that a new output graph implements it.

The profile records all known source/cone/retained-copy/target LAB neighborhoods
with every original FF record, every original FF BEL globally, and the entire
authenticated pre-stage native document. The fresh fifth-copy BEL is not guessed.
The later native-prefix proof must derive and close the selected site's whole
LAB neighborhood using those bound original bytes, prove retention of old2+new1,
prove exactly six further ENA transfers, and independently account for any
later private output ID changes by named owner. No numeric preservation or
Boolean/physical/STA/gain evidence is inherited from this recorder.

All five candidates must freshly qualify/apply candidate0 with their actual final
preceding trial. First-four model records must equal the closed2e399 models;
their parser sees only those four log blocks. The new fifth parser requires the
same original ALUT2→ALUT3 cone, primary LAB24.12, one group/six ENA users,
zero FF shift, unchanged clock/hold/boundary guards and at least250ps predicted
gain. Earlier rejected trials are retained. Successful execution records the
actual fifth site and complete cap16384/15,290-path predicted report with finite
positive Fmax fields. New clone names/cohorts are future independent native
proof obligations, not inferred from qualification text.

Preparation and output creation are exclusive. Current committed source
cleanliness/ancestry/two-file delta, actual runtime and every bound original input
and output path are rechecked before and after execution, including failure
paths. Failures retain their actual exit code, log and partial hashes; adapter
sentinel statuses are labelled explicitly. The private invocation is always
closed. Completion establishes no native/physical equivalence, numerical STA,
routed gain, RBF identity or hardware acceptance. The117.34334564208984MHz
accepted full result remains the later full-route comparison threshold.
