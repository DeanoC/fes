# Current g1 prefix: fresh driver qualification and full route recorder

Root alone prepares and runs this package. Preparation binds the completed
84afc015 g1 conditional native proof, its flat original artifact/runtime
closure, the unchanged DOMAIN compiler/archive paths and bytes, and these
two new files. No historical generator, recursive authenticator, compiler
build or comparison executes. The completed g1 record's inputs must equal
its profile inputs union the profile's own absolute pathname and digest.

The current baseline command changes only by removing its sole `--no-route`,
replacing write/report output paths, and adding the complete actual current
baseline timing guide, fresh driver candidate0 and a new RBF output path.
All other inputs, diagnostic environment, 8/1/1 plan, original guides,
geometry, seed, report cap16384, GPU1 and exact runtime snapshot remain
unchanged. The frozen g1 runner is imported only for its pure local-log
parser. Fresh local candidate0 trials must bind the proved selected models:
stage1 at COMB29.21.1 with one ENA, stages0/2 unchanged. Rejected trial
diagnostics remain recorded. Candidate0 must freshly qualify the ordinary
burst LUT to arithmetic.A edge with 49 source consumers, eight truth rows,
complete compiled domain coverage and all four final trial guards. Its
actual chosen BEL and gain come from this run, never the previous driver
candidate. Per-pair numeric before/after STA values are not serialized and
are not independently proved by these guard summaries.

Before execution the profile names the three proved ENA transfers, the
existing stage1 clone's relocation from COMB29.13.0 to COMB29.21.1, and every
original FF's complete serialized cell record in whole LABs29.12/29.13/29.21.
These declarations do not authorize arbitrary movement or normalization.
Later routed proof must establish equivalent actual ready enable functions,
exact declared transfers and original FF BELs, clocks, native pin states,
shared selectors and LAB controls; preserve every other original LUT,
carry, FF, PLL and BUF record/consumer; and independently prove the actual
driver source/copy/sink/immediate carry-successor and affected ALM closure.
The pre-route prefix proof supplies conditional serialized evidence, not
unseen full pin-state, LAB-control, cache, GPU-ID or routed Boolean proof.
No BUF delta or raw-ID normalization is waived here.

Exclusive new outputs and the compiler read audit record the literal
invocation, actual qualifications, all four outputs, Fmax and LAST signoff
hold diagnostic. All original input/runtime paths are rehashed on success.
Failures retain available partial output hashes and false completion.
The five direct FES project imports are pinned before loading and their
actual loaded paths/bytes checked. This recorder grants no native physical,
CRAM/pip, RBF byte-equivalence, routed gain or hardware acceptance. A later
independent proof must require memory strictly above117.34334564208984MHz,
actual non-target clock constraints and all six non-target windows of the
seven current domain pairs positive, zero LAST signoff holds, and complete
native/physical equivalence. Lower positive headroom must be disclosed;
all-clock Fmax nonregression remains a separate diagnostic.
