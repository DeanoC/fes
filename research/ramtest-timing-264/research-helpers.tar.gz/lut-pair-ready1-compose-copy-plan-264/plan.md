# Ready1 composed-copy target from the current routed report

This is static planning only. No guide, compiler invocation or candidate has
been created or accepted. The current route completed normally but its memory
clock is 114.39030456542969 MHz, below the accepted FIVE reference
117.77175903320312 MHz. Current native/physical route comparison is still a
separate prerequisite; the report alone does not supply that proof.

The inspected fresh route is lut-pair-ready0-compose-copy-route-264/route:

- run.json: b76ff6967705654e9cb1a9d8756d3302f4a7db035f3fb4c4f6490c3f376a8f22
- routed.json: 48de3e15140b9627796762988a2e654606b397a8245373380db22370db9e06c6
- timing.json: 826d4d19817d7df017ea36a65c335522f4f356ad69443ca10043155d5f94c785
- route.log: f77a9c1c216320ed164291ed483c45068f3e0d5aaad8b959340e358050be1295
- route profile: 79e71f1ed628b0bb0f4f97432fd8bca62ccf18e1066403c613c056215096a27b

The exact guide format is a copy of the COMPLETE current timing.json object
with only critical_paths replaced by a one-element array containing its
unchanged critical_paths[1] object. Preserve from/to clocks, max_delay, every
segment delay, endpoint location, net label, sources list and segment order.
Record tied row2975 separately as the second cohort endpoint; do not fabricate
a merged path or reduce the guide to routing segments alone.

Row1 is posedge ram_clock.clocks[0] to the same edge, window
7.691999912261963 ns, total8.742000252008438 ns including +0.166 ns skew and
-0.196 ns setup. Its complete native routing-edge signature is:

| Net | Driver | Consumer |
| --- | --- | --- |
| hps_ddr.cmd_ready_1 | hps_ddr.f2sdram.cmd_ready_1 (52,53) | hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q.A (33,19) |
| hps_ddr.port1.slot_free | hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q.Q (33,19) | hps_ddr.port1.slot_free_MISTRAL_ALUT3_B.B (27,16) |
| hps_ddr.port1.slot_free_MISTRAL_ALUT3_B_Q | hps_ddr.port1.slot_free_MISTRAL_ALUT3_B.Q (27,16) | hps_ddr.port1.skid_byteenable_MISTRAL_FF_Q_5.ENA (25,20) |

The actual inner is ALUT2 LUT0xb at COMB33.19.37, Q97422, inputs
A98308/B98312. The outer is ALUT3 LUT0x32 at COMB27.16.48, Q109091,
inputs A23880/B97422/C107546. The conditional plain-input composition has four
leaf signals [98308,98312,23880,107546] and mask0x4440; fresh backend and native
proof must derive the actual effective function, including exported pin states.
The current original root has100 input consumers, all retained outside the new
exact cohort. These raw IDs describe this saved image, not future allocations.

The complete selected same-LAB/same-clock root cohort is TWO weak FFs:

- hps_ddr.port1.skid_byteenable_MISTRAL_FF_Q_5 at FF25.20.46;
- hps_ddr.port1.skid_byteenable_MISTRAL_FF_Q_4 at FF25.20.44.

Both ENA slots use109091 and both CLK slots use3549. Row2975 is the identical
8.742000252008438 ns ready1 launch to FF4.ENA. The LAB contains15 original FFs
in total; all15 controls and placements, plus physical sharing/neighbours,
must be retained in any later proof. Exported weak attributes show no keep or
dont_touch on these FFs/pair. No ARITH/MLAB/keep/dont_touch owner was observed
in either source LAB33.19 or27.16. Unexported region/cluster/pin/cache and fresh
destination eligibility remain backend qualification obligations.

There is no clash with the TEN plan's existing port1 outer3 copies. Their
actual private Q/cohort populations remain literal:

| Existing suffix | Q | Consumers |
| --- | --- | --- |
| $local_remap | 120710 | burstcount FF4/FF1 in LAB29.12 (two) |
| $local_remap$1 | 120714 | writedata FF35 in LAB29.21 (one) |
| $local_remap$2 | 120716 | address FF28/27/23/2/19/15 in LAB24.12 (six) |
| $local_remap$3 | 120724 | byteenable FF7/FF3 in LAB27.21 (two) |

The new naming stem outer+$lut_pair_copy and its paired $Q alias are both
absent from the actual current cell/net namespaces. All ten earlier cohorts
21/2/10/1/6/1/1/3/2/8 must remain exact. The source pair and all other original
users must remain fixed; only the two proven-equivalent ENAs may redirect.

No compiler change is needed to test THIS alternative generic cone: use a
fresh original synth input and the literal TEN00bf plan, set
--remap-lut-pair-critical to the new one-path guide, retain
--remap-lut-pair-compose-copy, and list with candidate-1/--no-route/no--rbf.
Candidate indices/sites/gains are fresh results, never inherited from ready0.
The existing frozen evidence helpers bind ready0 guide9bdad541 explicitly;
they need separate newly authorized ready1 helpers rather than in-place edits.

There is only ONE pair report/selection hook after the TEN/internal/decomposition
prefix. Replacing its guide makes this an alternative to the extra ready0
$lut_pair_copy at36.28.6; it does not stack both composed copies. Loading the
routed/processed graph is prohibited by the fresh/unrouted guards. Preserving
that additional ready0 copy while adding ready1 would require a separately
authorized generic multi-step orchestration capability and fresh qualification.

Relevant frozen source: lut_pair_copy.cc SHA7b55713eadc8b2b003f354a2db41d7bb746b4ca85ed9bc299fec049301bea13c
(discovery150-169, cohort187-203, composition205-253, strict fanout260-329,
paired names365-377); remap_report.h SHAf92a025d639db576fdbfcc3f093838264347a53354faf80b89c4007c926b0446;
main.cc SHA f3bfe989da51bd6b5ea0a581c3f09668ac7a75a675deb15fbf0ec718baa38a2c
(CLI368-393); lut_pair_placement.md SHAac2d3de2ccfaac30a3bbd74aa4d95d05c9b9a3040f0a2189077906304b674ac0.
Strict endpoint negative-baseline/hold/reference/global-clock guards stay intact.
Extra leaf loading can still reject candidates, and a shorter target does not
establish routed gain, independent numerical STA, RBF decoding or hardware
acceptance.
