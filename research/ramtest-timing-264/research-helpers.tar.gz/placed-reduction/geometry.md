# Eleven-literal reduction geometry

Evidence: `capture-locality/route-b64-r24/{routed.json,timing.json}`. This is the complete 110.9631577 MHz memory route. Geometry and placement-time timing arithmetic below are diagnostic evidence, not proof of a routed improvement.

The eleven inputs are error-counter bits 21 through 31. Their driver FF locations are:

| Bit | FF X,Y | FF z |
| --- | --- | --- |
| 21 | 16,25 | 22 |
| 22 | 12,32 | 28 |
| 23 | 33,14 | 44 |
| 24 | 4,32 | 8 |
| 25 | 4,32 | 32 |
| 26 | 9,32 | 8 |
| 27 | 9,32 | 40 |
| 28 | 33,14 | 32 |
| 29 | 6,32 | 22 |
| 30 | 9,32 | 46 |
| 31 | 6,32 | 58 |

Seven inputs sit on Y32; two remote inputs, bits 23 and 28, share X33,Y14. Numeric partitioning splits those remote inputs across both children.

The original conjunction is a chain:

- ALUT4 `COMB.4.14.37`: A=28, B=27, C=26, D=25.
- ALUT5 `COMB.4.14.18`: A=24, B=23, C=22, D=21, E=first ALUT4 Q.
- ALUT4 root `COMB.10.22.18`: A=31, B=30, C=29, D=middle ALUT5 Q.
- Its Q feeds D of the unchanged final ALUT5 enable driver `COMB.10.22.42`.

The first two LUTs share a LAB, but **different ALMs**: z37 is ALM6/half1 and z18 is ALM3/half0. ALM3 also contains an unrelated ALUT3 at z19 and an unrelated FF at z22. Therefore changing the middle cell to an ALUT6 makes its original BEL illegal because the neighboring ALUT3 would exceed the ALM's 64-bit LUT storage. ALM6 contains no other COMB or FF occupant in this routed snapshot. The root ALM3 at X10,Y22 contains an unrelated BUF and two FFs; its preserved ALUT2 replacement is checked against those fixed occupants.

The measured critical bit27 path contains 2.805 ns routing into the first LUT, 0.512 ns first-LUT logic, 0.429 ns routing plus 0.097 ns middle-LUT logic, 1.516 ns routing plus 0.097 ns root logic, 0.588 ns routing plus 0.400 ns enable logic, and 2.028 ns routing to the bit18 ENA endpoint at X2,Y5. Clock-to-Q is 0.731 ns, clock skew +0.005 ns and setup -0.196 ns: total 9.012 ns. Eliminating a LUT level is useful, but long incoming and final enable routes remain material.

The enable net has 32 FF ENA consumers across nine LAB locations:

| X,Y | Consumers |
| --- | --- |
| 2,5 | 2 |
| 4,32 | 2 |
| 6,13 | 1 |
| 6,32 | 7 |
| 9,32 | 5 |
| 10,18 | 1 |
| 12,32 | 5 |
| 16,25 | 1 |
| 33,14 | 8 |

This spans X2..33,Y5..32. The fixed root and enable driver remain at X10,Y22, so a local input rewrite cannot remove this final fanout spread.

## Numeric partition versus input pin ordering

The current rewrite assigns bits21..26 to ALUT6 A..F and bits27..31 to ALUT5 A..E. It puts both remote inputs (23 and28) on 0.510 ns logical LUT arcs. The backend's ALUT6 F and ALUT5 E arcs are 0.097 ns. These are concrete unequal input costs in `mistral/delay.cc`.

For an illustrative **already legal V1 trial pair**, child6 at X12,Y22 and child5 at X13,Y22 with fixed root X10,Y22, the placement-time model predicts the following costs. Each value includes worst FF-to-child predicted routing, child logic, child-to-root predicted routing and root input logic. It omits the common FF clock-to-Q and everything after the root. It is **not an absolute arrival measurement**.

| Assignment | Maximum model cost |
| --- | --- |
| Numeric groups and numeric pin order | 4.065 ns |
| Same numeric groups; minimize maximum cost by assigning slowest incoming routes to fastest pins | 3.810 ns |
| Enumerate all 462 possible 6/5 partitions at these fixed sites, with optimal pin assignment | 3.652 ns |

An example best geometric partition is six={21,22,23,26,27,29}, five={24,25,28,30,31}; several others tie. Notably it still splits the remote inputs. Separating remote inputs into one child is therefore not automatically best: the LUT input asymmetry, root input asymmetry and fixed-site distances matter together.

These calculations use backend `predictDelay`: same LAB=0.300 ns; otherwise 0.650 ns plus0.250 ns for a row change, plus0.035 ns per X and0.100 ns per Y. ALUT6 A..F max logic delays are {0.605,0.583,0.510,0.512,0.400,0.097} ns; ALUT5 A..E are {0.583,0.510,0.512,0.400,0.097} ns; root ALUT2 A/B are0.400/0.097 ns. The arithmetic ignores detailed routing, input upstream arrival differences, candidate occupancy beyond the quoted legal pair and potential routing congestion. It supports a pin-order experiment, not a gain claim.

V1's 16 legal spatial trials all reported endpoint gain0 ps while clock/hold checks passed. Another input of the final enable LUT can dominate its ENA endpoint arrival even if this conjunction branch improves. Root-Q slack improvement with every downstream endpoint nonregressing is a suitable abstract candidate gate; full routed setup/hold reports still decide acceptance.

## Bounded generic pin permutation

Keep the currently recognized signed conjunction, literal partition, cells, net identities and fixed-root placement. For each candidate child BEL, enumerate at most6!=720 permutations (5!=120 for the second child) of its distinct verified literals. Precompute a6x6 or5x5 cost matrix using `predictArcDelay(literal_net,{child,pin}) + getCellDelay(child,pin,Q).maxDelay()`, then minimize the maximum matrix entry over each permutation. Add unchanged child-to-root/root logic cost for comparing sites. Deterministic ties should prefer the existing literal order, then ordinal permutation order.

Scoring need not mutate the graph: canonical A..F ports and pin maps already exist after the verified rewrite. Store the winning literal order with the candidate site. Once both children are placed, apply their selected permutations in one mutation: each literal keeps its original live indexed consumer slot, but its PortRef and the target port's user_idx change together. Recompute the cube truth table's single satisfying row using the literal's required polarity; do not drop active-low literals. The rewritten input pins remain PIN_SIG with their signs encoded by the mask. Preserve Q pin data, output nets, every unrelated port and every net store's free-list structure.

Run assignArchInfo, full affected-LAB legality, ctx->check and fresh STA after application. Require root-Q slack gain and nonregressing downstream endpoint setup, every clock and holds; otherwise restore the complete saved logical/physical state. Check all2^11 assignments in the generic fixture and consumer-slot/BEL/pin-state preservation. Test pin assignment independently of partition changes first. A later generic partition search can enumerate the462 unique 6/5 splits and reuse the matrix calculation, but changing grouping and pin order together would make the first experiment harder to attribute.
