# Strict current full-route one-copy proof

Root alone executes this new helper after the actual full route completes.
All older source, helpers, records and outputs remain immutable. Before-run
scope is the frozen `driver-copy-route-264` identity `d56a1207…`, derived from
actual selected proof `c9a2da27…`; it authorizes one ordinary ALUT3 copy and
one arithmetic operand redirect, with the declared source/copy/sink/immediate
carry successor ALMs. The completed selected flat closure supplies the accepted
integration proof `01886d65…` and native routed reference `0ecb9e44…`.

The comparator authenticates the frozen new full helper once, adopts its
verified flat inputs, then binds actual run/runtime/log/native/report/RBF
outputs and its own two code/document hashes. No old generator or recursive
authenticator is called. Only `32fd10…` lossless native parser/canonical/Audit
and constants, the new frozen full recorder's provenance functions, the frozen
board HIP guard, and pure physical evaluator `0f524952…` are reused. Root's
successful reference exercise `ded95d82…` is bound as limited host evidence.
Original artifact and runtime paths are rehashed at exit.

The default graph gate requires zero BUF population or metadata changes.
Every original cell, type, LUT parameter, BEL, attribute, complete pin image,
native port connection and ordered PLL occurrence stays exact, except the one
predeclared scalar arithmetic operand. Every original named net/alias/numeric
bit and non-routing attribute stays exact. Only net `ROUTING` attributes may
differ. Original full exported owner order must remain exact after removing
the one copy cell/private Q net. Filtering actual routed owners to the selected
pre-route owners must preserve its original prefix/private suffix order;
route-created BUF owners are also preserved in their actual full-reference
order, without assuming the copy was created after those buffers. No numeric identity renaming,
buffer collapse, LAB-wide normalization or inferred physical movement is used.
Source Q has 49 original users, 48 remain, and private copy Q has exactly the
selected operand. Every copied logical input load/slot and native source is
checked, including multiplicity when inputs alias.

Actual routed pin states, constants, inversions, both physical LUT halves,
shared actual native input identities, active-low storage, MCOMB logic
permutation, arithmetic LUT0/LUT1 and dedicated carry succession are evaluated
from current full snapshots. Whole original LAB snapshots and the declared
neighbor FF controls remain strict. These are exported-model checks, not
independent RBF/CRAM decoding, whole-pip validation, unexported cache/index/GPU
state reconstruction or hardware acceptance.

The actual report may have many paths; the old reference has six. It is never
compared byte-for-byte. Every current path must use current native cells,
ports, aliases and clock attribution, with finite complete segment sums and
at most 16,384 unique endpoints per actual domain pair. The old six numeric
windows remain exact; complete current pair/window coverage must match the
actual selected same-profile report, including any negative-edge memory
relation. Positive headroom is required for every actual non-target pair.
Capture's actual five-nanosecond window is explicit. Memory must strictly
exceed 116.64527893066406 MHz; required other achieved clocks must meet their
actual quantized constraints, with zero final-signoff hold warnings. Target
130 MHz may remain unmet and is disclosed. The historical all-clock Fmax
nonregression result is retained as a separate diagnostic.

A structural rejection records its exact reason and actual timing diagnostics,
but never accepts a result or automatically grants an old/new buffer ledger.
Any later bounded refinement requires separately authored, reviewed and
versioned evidence; these bytes and their output become immutable on execution.
