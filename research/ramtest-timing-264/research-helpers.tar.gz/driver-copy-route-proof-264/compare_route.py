"""Independent strict one-copy routed proof; root is the sole executor."""
import argparse
from collections import Counter
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
FULL = RAW / "driver-copy-route-264"
FOLDER = FULL / "route-c0"
FULL_ID_SHA = "d56a1207bcf255c6e39bcab6bd322ece712f48cefd9ad65280c2fd29d51beee2"
FREEZE_SHA = "189fb1eff6b184dff01cd0780dfdf5e401371978ebea577f8ffb4b7b0f17aa35"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
REFERENCE = RAW / "narrow-integrated-264/route-reproduction"
REFERENCE_PROOF_SHA = "01886d65d6e55f1f1c1d5345e00e3dee5358ce672b0f4a3bac3135f6ec155d4e"
REFERENCE_GRAPH_SHA = "0ecb9e44978dae407841680836d7881ef3cc3ce084a28ce3253a4431bec4e05b"
PHYSICAL = RAW / "driver-copy-physical-264"
PHYSICAL_SHA = "0f5249524010cd3adac4949ca283e70fbfdd6a624404b841858bef6d2a463176"
PHYSICAL_SCOPE_SHA = "73050669a06db73e71e220709d6b624c77046394aa0867afd58114727db365ec"
REFERENCE_VALIDATION_SHA = "ded95d82f114f8926061bf1fe99de60c7c1bad309f1c3fc9cf1c123262837c40"
MEMORY, PIXEL, CAPTURE = "ram_clock.clocks[0]", "display.pixel_clk", "ram_clock.clocks[1]"
TARGET_MHZ = 116.64527893066406
CONSTRAINTS = {MEMORY: 130.00520324707031, PIXEL: 74.25006866455078, CAPTURE: 130.00520324707031}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def tables(top):
    """Actual numeric bits and every named port/vector/PLL occurrence slot."""
    drivers, users = {}, {}
    cells = top["cells"]
    for name, cell in cells.items():
        special = cells.pll_ports.get(name)
        directions = special["port_directions"] if special else list(cell["port_directions"].items())
        connections = special["connections"] if special else list(cell["connections"].items())
        require([port for port, _ in directions] == [port for port, _ in connections], "native port entry order differs")
        occurrences = Counter()
        for (port, direction), (_, bits) in zip(directions, connections):
            occurrence = occurrences[port]
            occurrences[port] += 1
            require(direction in {"input", "output", "inout"} and type(bits) is list and
                    all(type(bit) is int and bit >= 0 for bit in bits), "unsupported native bit/direction")
            for index, bit in enumerate(bits):
                slot = name, port, index, occurrence
                if direction in {"output", "inout"}:
                    drivers.setdefault(bit, []).append(slot)
                if direction in {"input", "inout"}:
                    users.setdefault(bit, []).append(slot)
    return ({bit: sorted(rows) for bit, rows in drivers.items()},
            {bit: sorted(rows) for bit, rows in users.items()})


def pin_coverage(physical, view):
    count = 0
    for name, cell in view.cells.items():
        pins = view.pins(name)
        for port, bits in cell["connections"].items():
            covered = port in pins or port + "[0]" in pins if len(bits) <= 1 else all(
                port + "[" + str(index) + "]" in pins for index in range(len(bits)))
            require(covered, "full scalar/vector physical pin coverage missing: " + name + "." + port)
            count += len(bits)
    return count


def prove_graph(native, physical, before, after, ctx):
    old, new = before["modules"]["top"], after["modules"]["top"]
    graph = ctx["proof"]["graph_evidence"]
    source, clone, sink, port, private = (graph[key] for key in ("source", "clone", "sink", "sink_port", "private_net"))
    old_buf = {name for name, cell in old["cells"].items() if cell["type"] == "MISTRAL_BUF"}
    new_buf = {name for name, cell in new["cells"].items() if cell["type"] == "MISTRAL_BUF"}
    require(new_buf == old_buf, "strict buffer population changed; added=" + repr(sorted(new_buf - old_buf)) +
            " removed=" + repr(sorted(old_buf - new_buf)))
    require(set(new) == set(old) and native.canonical({key: value for key, value in new.items() if key not in {"cells", "netnames"}}) ==
            native.canonical({key: value for key, value in old.items() if key not in {"cells", "netnames"}}),
            "native top metadata/settings/public ports/whole LAB snapshot changed")
    require(set(new["cells"]) == set(old["cells"]) | {clone} and clone not in old["cells"] and
            set(new["netnames"]) == set(old["netnames"]) | {private} and private not in old["netnames"],
            "undeclared original/new cell or named net population change")
    selected_top = ctx["selected_document"]["modules"]["top"]
    for dictionary, addition in (("cells", clone), ("netnames", private)):
        require([name for name in new[dictionary] if name != addition] == list(old[dictionary]),
                "original full native exported owner order changed")
        require([name for name in new[dictionary] if name in selected_top[dictionary]] == list(selected_top[dictionary]),
                "selected pre-route owner prefix/private suffix order changed among routed owners")
    require(native.canonical(old["cells"].pll_ports) == native.canonical(new["cells"].pll_ports), "ordered PLL occurrences changed")
    a, copied = old["cells"][source], new["cells"][clone]
    newq, oldq = copied["connections"]["Q"], a["connections"]["Q"]
    require(len(newq) == len(oldq) == 1 and type(newq[0]) is int and newq != oldq and
            new["cells"][sink]["connections"][port] == newq and old["cells"][sink]["connections"][port] == oldq,
            "actual copy does not redirect precisely the selected scalar operand")
    for name, cell in old["cells"].items():
        expected = copy.deepcopy(cell) if name == sink else cell
        if name == sink:
            expected["connections"][port] = newq
        require(native.canonical(new["cells"][name]) == native.canonical(expected),
                "original cell metadata/BEL/full pins/params/native ports changed: " + name)
    for name, net in old["netnames"].items():
        expected, actual = copy.deepcopy(net), copy.deepcopy(new["netnames"][name])
        expected["attributes"].pop("ROUTING", None)
        actual["attributes"].pop("ROUTING", None)
        require(native.canonical(actual) == native.canonical(expected),
                "original named net native ID/alias/non-routing metadata changed: " + name)
    selected_copy = ctx["selected_document"]["modules"]["top"]["cells"][clone]
    require(set(copied) == set(selected_copy) and copied["type"] == selected_copy["type"] and
            copied["parameters"] == selected_copy["parameters"] and copied["port_directions"] == selected_copy["port_directions"] and
            copied["hide_name"] == selected_copy["hide_name"] and
            {key: value for key, value in copied["attributes"].items() if key != "FES_PINMAP_V1"} == selected_copy["attributes"] and
            "FES_PINMAP_V1" in copied["attributes"], "routed copy differs from its predeclared selected identity/placement/table")
    for pin in "ABC":
        require(copied["connections"][pin] == a["connections"][pin], "copy input native identity changed: " + pin)
    require(set(copied["connections"]) == {"A", "B", "C", "Q"}, "copy port schema changed")
    named = new["netnames"][private]
    require(set(named) == {"hide_name", "bits", "attributes"} and named["hide_name"] == int(private.startswith("$")) and
            named["bits"] == newq and set(named["attributes"]) == {"ROUTING"} and
            type(named["attributes"]["ROUTING"]) is str and named["attributes"]["ROUTING"].strip(),
            "private copy output net lacks its sole actual routed alias")
    old_drivers, old_users = tables(old)
    new_drivers, new_users = tables(new)
    expected_drivers, expected_users = copy.deepcopy(old_drivers), copy.deepcopy(old_users)
    require(newq[0] not in old_drivers and newq[0] not in old_users, "copy Q reuses an original native bit")
    expected_drivers[newq[0]] = [(clone, "Q", 0, 0)]
    chosen = sink, port, 0, 0
    require(len(expected_users[oldq[0]]) == 49 and expected_users[oldq[0]].count(chosen) == 1,
            "accepted original Q consumer manifest differs from selected49")
    expected_users[oldq[0]].remove(chosen)
    expected_users[newq[0]] = [chosen]
    loads = []
    for pin in "ABC":
        bits = copied["connections"][pin]
        if bits:
            require(len(bits) == 1 and len(old_drivers.get(bits[0], [])) == 1, "copy input lacks one preserved native source")
            expected_users.setdefault(bits[0], []).append((clone, pin, 0, 0))
            loads.append({"logical_port": pin, "native_bit": bits[0], "native_driver": list(old_drivers[bits[0]][0])})
    expected_users = {bit: sorted(rows) for bit, rows in expected_users.items()}
    require(new_drivers == expected_drivers and new_users == expected_users, "actual driver/consumer slots changed outside one operand/copy loads")
    require(loads == graph["declared_copy_input_loads"], "actual copy input load multiplicity differs from pre-run declaration")
    before_view, after_view = physical.PhysicalView(old), physical.PhysicalView(new)
    coverage = [pin_coverage(physical, view) for view in (before_view, after_view)]
    result = physical.prove_lut_copy(before_view, after_view, source, clone, sink, port, expected_original_users=49)
    keys = [tuple(key) for key in ctx["scope"]["declared_alm_keys"]]
    actual_scope = []
    for key in keys:
        before_alm, after_alm = physical.evaluate_alm(before_view, key), physical.evaluate_alm(after_view, key)
        require(before_alm["saved_fields"] == after_alm["saved_fields"], "declared ALM/FF/LAB selectors changed")
        actual_scope.append({"alm": list(key), "before": before_alm, "after": after_alm})
    controls = physical.compare_ff_controls(before_view, after_view, sorted({key[:2] for key in keys}))
    return {"complete_original_cells_params_attrs_bels_full_pins_exact_except_selected_operand": True,
            "all_original_named_native_ids_aliases_and_nonrouting_metadata_exact": True,
            "original_full_cell_and_net_export_order_exact": True,
            "selected_pre_route_owner_prefix_and_private_suffix_order_exact": True, "lossless_ordered_pll_records_exact": True,
            "source_q_users_before": 49, "source_q_users_after": 48, "private_q_users": 1,
            "all_native_output_drivers_and_port_vector_occurrence_user_slots_exact": True,
            "declared_copy_input_loads": loads, "distinct_input_load_nets": len({row["native_bit"] for row in loads}),
            "all_original_buffer_cells_exact_zero_delta": True, "buffer_count": len(old_buf),
            "connected_bit_pin_snapshot_coverage_counts": coverage, "actual_physical_lut_copy": result,
            "declared_source_clone_sink_immediate_carry_alm_evidence": actual_scope,
            "whole_declared_lab_ff_controls": controls, "creator_metadata": {"before": before["creator"], "after": after["creator"]},
            "routing_attributes_are_the_only_ignored_net_metadata": True,
            "rbf_cram_decoded_or_all_route_pips_independently_checked": False,
            "in_memory_caches_indexed_users_or_gpu_ids_proved": False}


def port_data(cells, name, port):
    require(name in cells, "path references absent cell: " + name)
    cell = cells[name]
    if port in cell["connections"]:
        bits, direction = cell["connections"][port], cell["port_directions"][port]
        require(type(bits) is list and len(bits) == 1, "path references nonscalar terminal")
        return bits, direction
    match = re.fullmatch(r"(.+)\[(\d+)\]", port)
    require(match is not None and match[1] in cell["connections"], "path port is absent")
    bits, index = cell["connections"][match[1]], int(match[2])
    require(index < len(bits), "path vector index is out of bounds")
    return [bits[index]], cell["port_directions"][match[1]]


def terminal(top, value):
    require(type(value) is dict and set(value) == {"cell", "port", "loc"} and type(value["cell"]) is str and
            type(value["port"]) is str and type(value["loc"]) is list and len(value["loc"]) == 2 and
            all(type(v) is int for v in value["loc"]), "native timing terminal schema differs")
    name, pin = value["cell"], value["port"]
    port_data(top["cells"], name, pin)
    match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", top["cells"][name]["attributes"].get("NEXTPNR_BEL", ""))
    require(match is not None and value["loc"] == [int(match[1]), int(match[2])], "timing terminal placement is stale")
    return name, pin


def event(top, value):
    if value == "<async>":
        return None
    match = re.fullmatch(r"(posedge|negedge) (.+)", value)
    require(match is not None and match[2] in top["netnames"] and len(top["netnames"][match[2]]["bits"]) == 1,
            "timing clock event is not its actual scalar native alias")
    return match[1], match[2], top["netnames"][match[2]]["bits"]


def register_clock(cells, node):
    name, pin = node
    kind = cells[name]["type"]
    if kind == "MISTRAL_FF" or kind.startswith("MISTRAL_MUL"):
        clock = "CLK"
    elif kind == "MISTRAL_MLAB":
        clock = "CLK1"
    elif kind == "cyclonev_hps_interface_fpga2sdram":
        match = re.fullmatch(r"(cmd_data|cmd_valid|wrack_ready|cmd_ready|wrack_data|wrack_valid|wr_data|wr_valid|wr_ready|rd_ready|rd_data|rd_valid)_(\d+)(?:\[\d+\])?", pin)
        require(match is not None, "unsupported HPS registered endpoint")
        clock = ("cmd_port_clk" if match[1].startswith(("cmd_", "wrack_")) else
                 "wr_clk" if match[1].startswith("wr_") else "rd_clk") + "_" + match[2]
    else:
        require(False, "unsupported actual registered primitive: " + kind)
    bits, direction = port_data(cells, name, clock)
    require(direction == "input", "registered clock is not an input")
    return bits


def report_paths(top, report):
    require(type(report.get("critical_paths")) is list and report["critical_paths"] and report.get("timing_report_paths") == 16384,
            "actual expanded final setup report absent")
    windows, endpoints, worst, counts = {}, set(), {}, {}
    cells = top["cells"]
    for path in report["critical_paths"]:
        require(set(path) == {"from", "to", "max_delay", "path"} and type(path["path"]) is list and path["path"] and
                type(path["max_delay"]) in (int, float) and math.isfinite(path["max_delay"]) and path["max_delay"] > 0,
                "actual path/window schema differs")
        pair = path["from"], path["to"]
        require(pair not in windows or windows[pair] == path["max_delay"], "one actual domain pair has inconsistent windows")
        windows[pair] = path["max_delay"]
        launch, capture = event(top, pair[0]), event(top, pair[1])
        end = terminal(top, path["path"][-1]["to"])
        identity = (*pair, *end)
        require(identity not in endpoints, "duplicate actual pair/endpoint")
        endpoints.add(identity)
        counts[pair] = counts.get(pair, 0) + 1
        require(counts[pair] <= 16384, "actual report exceeds per-pair cap")
        first, previous, setup, prefixes, delays = None, None, False, set(), []
        for segment in path["path"]:
            require(type(segment) is dict and {"type", "delay", "from", "to"} <= set(segment) and
                    type(segment["delay"]) in (int, float) and math.isfinite(segment["delay"]), "unknown/nonfinite actual segment")
            src, dst = terminal(top, segment["from"]), terminal(top, segment["to"])
            kind, delay = segment["type"], segment["delay"]
            delays.append(delay)
            a, adir = port_data(cells, *src)
            b, bdir = port_data(cells, *dst)
            if kind in {"clk-skew", "clk-to-clk"}:
                require(first is None and previous is None and not setup and kind not in prefixes and
                        launch is not None and capture is not None and a == launch[2] and b == capture[2],
                        "stale/duplicate actual clock prefix")
                prefixes.add(kind)
                continue
            require(not setup and (previous is None or previous == src), "actual data path is discontinuous")
            if kind in {"clk-to-q", "source"}:
                require(first is None and previous is None and src == dst and adir == "output" and delay >= 0 and
                        (register_clock(cells, src) == launch[2] if kind == "clk-to-q" and launch is not None
                         else kind == "source" and launch is None), "stale actual data launch/clock")
                first = src
            elif kind == "routing":
                require(first is not None and adir == "output" and bdir == "input" and a == b and delay >= 0 and
                        segment.get("net") in top["netnames"] and top["netnames"][segment["net"]]["bits"] == a and
                        type(segment.get("sources")) is list, "reported routing is not its current native edge/alias")
            elif kind == "logic":
                require(first is not None and src[0] == dst[0] and adir == "input" and bdir == "output" and delay >= 0,
                        "reported logic is not its current native primitive arc")
            elif kind == "setup":
                require(first is not None and src == dst == end and bdir == "input" and capture is not None and
                        register_clock(cells, dst) == capture[2] and segment is path["path"][-1], "stale/duplicate setup endpoint")
                setup = True
            else:
                require(False, "unknown actual segment type: " + str(kind))
            previous = dst
        require(first is not None and setup, "actual registered path is incomplete")
        total = math.fsum(delays)
        require(math.isfinite(total), "actual complete path sum is nonfinite")
        if pair not in worst or total > worst[pair]["complete_delay_ns"]:
            worst[pair] = {"complete_delay_ns": total, "headroom_ns": path["max_delay"] - total,
                           "actual_worst_path": path}
    return windows, endpoints, worst, counts


def timing(native, top, report, parent_report, selected_report, log, record):
    require(set(report["fmax"]) == set(parent_report["fmax"]) == set(CONSTRAINTS), "required clock set changed")
    clocks = {}
    for name, constraint in CONSTRAINTS.items():
        row, before = report["fmax"][name], parent_report["fmax"][name]
        require(set(row) == set(before) == {"achieved", "constraint"} and row["constraint"] == before["constraint"] == constraint and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for value in (row["achieved"], before["achieved"])),
                "actual finite Fmax/quantized constraint differs")
        clocks[name] = {"before_mhz": before["achieved"], "after_mhz": row["achieved"], "gain_mhz": row["achieved"] - before["achieved"],
                        "constraint_mhz": constraint, "constraint_passed": row["achieved"] >= constraint}
    require(clocks[MEMORY]["before_mhz"] == TARGET_MHZ, "accepted memory baseline changed")
    windows, endpoints, worst, counts = report_paths(top, report)
    old_windows = {(path["from"], path["to"]): path["max_delay"] for path in parent_report["critical_paths"]}
    selected_windows = {}
    for path in selected_report["critical_paths"]:
        key = path["from"], path["to"]
        require(key not in selected_windows or selected_windows[key] == path["max_delay"], "selected actual pair windows disagree")
        selected_windows[key] = path["max_delay"]
    require(len(old_windows) == 6 and all(windows.get(key) == value for key, value in old_windows.items()) and
            windows == selected_windows, "actual final pair/window identities differ from accepted six or same-profile selected domain coverage")
    target = ("posedge " + MEMORY, "posedge " + MEMORY)
    capture = ("posedge " + CAPTURE, "negedge " + MEMORY)
    require(windows[capture] == 5, "capture phase is not actual5ns")
    relations = [{"from": key[0], "to": key[1], "window_ns": windows[key], **worst[key],
                  "positive_headroom_required": key != target, "passes_window": key == target or worst[key]["headroom_ns"] > 0,
                  "reported_paths": counts[key], "present_in_old_six_path_report": key in old_windows} for key in sorted(windows)]
    require("Running signoff timing analysis..." in log, "final analogue signoff block absent")
    last = log.rsplit("Running signoff timing analysis...", 1)[1]
    hold_lines = [line for line in last.splitlines() if re.search(r"hold", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
    holds = "Hold/min time violation" in last or bool(hold_lines)
    require(record["actual_timing_report_summary"]["fmax"] == report["fmax"] and
            record["actual_last_signoff"]["reported_hold_warning_lines"] == hold_lines,
            "actual runner Fmax/final hold diagnostics differ")
    practical = clocks[MEMORY]["gain_mhz"] > 0 and all(clocks[name]["constraint_passed"] for name in (PIXEL, CAPTURE)) and \
        all(row["passes_window"] for row in relations) and not holds
    return {"passes_practical_timing_gate": practical, "memory_strict_gain_vs_116_64527893066406": clocks[MEMORY]["gain_mhz"] > 0,
            "memory_130mhz_closed": clocks[MEMORY]["constraint_passed"], "clocks": clocks,
            "all_actual_required_non_target_windows": relations, "complete_current_path_count": len(endpoints),
            "final_reported_hold_violations": holds, "last_signoff_hold_warning_lines": hold_lines,
            "all_clock_fmax_nonregression_vs_accepted_reference": all(row["gain_mhz"] >= 0 for row in clocks.values()),
            "lower_positive_headroom_allowed_and_disclosed": True,
            "timing_path_native_topology_and_all_finite_segment_sums_checked": True,
            "unreported_pair_numeric_extrema_or_physical_delays_independently_recomputed": False}


def comparison(generator_sha, scope_sha):
    require(PURE.is_file(), "pinned native parser absent")
    with PURE.open("rb") as stream:
        require(hashlib.file_digest(stream, "sha256").hexdigest() == PURE_SHA, "native parser bytes changed before import")
    # The pure module contains no top-level authenticator; only these APIs are used.
    native = load(PURE, "copy_full_native_parser")
    audit = native.Audit()
    audit.bind(PURE, PURE_SHA)
    audit.bind(Path(__file__).resolve(), generator_sha)
    audit.bind(HERE / "scope.md", scope_sha)
    audit.bind(FULL / "freeze.py", FREEZE_SHA)
    frozen = load(FULL / "freeze.py", "copy_full_frozen_recorder")
    require(frozen.HERE == FULL and frozen.FOLDER == FOLDER and frozen.PURE_SHA == PURE_SHA, "frozen full API paths differ")
    profile, inputs, ctx = frozen.authenticate_freeze(FULL_ID_SHA)
    for path, digest in inputs.items():
        audit.adopt_verified(Path(path), digest)
    audit.bind(FULL / "source-identity.json", FULL_ID_SHA)
    audit.bind(FOLDER / "run.json")
    record = frozen.read(FOLDER / "run.json")
    frozen.authenticate_phase(record, profile, FULL_ID_SHA, ctx)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True,
            "full route not normally completed/audited")
    for path, digest in record["execution"]["files"].items():
        audit.bind(Path(path), digest, execution=True)
    for path, digest in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "full output empty")
        audit.bind(Path(path), digest)
    audit.bind(REFERENCE / "comparison.json", REFERENCE_PROOF_SHA)
    accepted = native.read(REFERENCE / "comparison.json")
    require(accepted["reproduction_proved"] is True and accepted["native_graph_and_rbf_reproduced"] is True and
            accepted["candidate_accepted_under_confirmed_target_clock_rule"] is True,
            "cached accepted integration proof not closed")
    for path, digest in accepted["artifact_sha256"].items():
        require(inputs.get(str(ROOT / path)) == digest, "accepted artifact absent from selected flat closure")
    for path, digest in accepted["execution_file_sha256"].items():
        require(inputs.get(path) == digest, "accepted runtime absent from selected flat closure")
    audit.bind(REFERENCE / "routed.json", REFERENCE_GRAPH_SHA)
    audit.bind(PHYSICAL / "physical_lut.py", PHYSICAL_SHA)
    audit.bind(PHYSICAL / "scope.md", PHYSICAL_SCOPE_SHA)
    audit.bind(PHYSICAL / "reference-validation.json", REFERENCE_VALIDATION_SHA)
    validation = native.read(PHYSICAL / "reference-validation.json")
    require(validation["actual_reference_snapshot_validation_passed"] is True and
            validation["copy_or_new_route_equivalence_proved"] is False, "physical reference exercise invalid")
    for path, digest in validation["input_sha256"].items():
        audit.bind(Path(path), digest)
    audit.bind(PHYSICAL / "validate_reference.py", validation["validator_sha256"])
    physical = load(PHYSICAL / "physical_lut.py", "copy_full_physical_evaluator")
    before, after = native.read_netlist(REFERENCE / "routed.json"), native.read_netlist(FOLDER / "routed.json")
    ctx["selected_document"] = native.read_netlist(frozen.SELECTED_FOLDER / "placed.json")
    log = (FOLDER / "route.log").read_text()
    require("Info: Program finished normally." in log and "Running the GPU router" in log and
            not any(line.startswith("ERROR:") for line in log.splitlines()), "full GPU/compiler normal completion missing")
    module = ROOT / "sources/misteross"
    board_path = module / "scripts/fes_build_common.py"
    require(str(board_path) in record["input_sha256"], "board GPU validator not frozen")
    audit.bind(board_path, record["input_sha256"][str(board_path)])
    sys.path.insert(0, str(module))
    board = load(board_path, "copy_full_gpu_backend_guard")
    backend = board._require_gpu_backend(log)
    require(re.search(r"GPU router time [^\n]+backend hip:", log), "live HIP routing completion diagnostic missing")
    current_report, parent_report = native.read(FOLDER / "timing.json"), native.read(REFERENCE / "timing.json")
    selected_report = native.read(frozen.SELECTED_FOLDER / "timing.json")
    raw_timing = timing(native, after["modules"]["top"], current_report, parent_report, selected_report, log, record)
    rejection, graph = None, None
    try:
        selected_log = (frozen.SELECTED_FOLDER / "phase.log").read_text()
        prefixes = native.DIAGNOSTIC_PREFIXES + ("Info: LUT driver copy",)
        require([line for line in log.splitlines() if line.startswith(prefixes)] ==
                [line for line in selected_log.splitlines() if line.startswith(prefixes)], "fresh selected/upstream qualification messages differ")
        require(len(native.PLACEMENT_METRICS.findall(log)) == 71 and
                native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(selected_log), "71 placement metrics differ")
        graph = prove_graph(native, physical, before, after, ctx)
    except (ValueError, KeyError, TypeError) as error:
        rejection = str(error)
    proved = rejection is None
    audit.finish()
    return {"schema": 1, "phase": "strict-lut-driver-copy-full", "compiler_commit": profile["result_commit"],
            "source_identity_sha256": FULL_ID_SHA, "selected_proof_sha256": ctx["proof_sha256"],
            "reference_proof_sha256": REFERENCE_PROOF_SHA, "generator_sha256": generator_sha,
            "scope_sha256": scope_sha, "pure_native_parser_sha256": PURE_SHA, "physical_evaluator_sha256": PHYSICAL_SHA,
            "physical_reference_validation_sha256": REFERENCE_VALIDATION_SHA,
            "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"], "gpu_backend": backend,
            "structural_rejection": rejection, "graph_proof_available": proved, "full_graph_and_pin_equivalence_proved": proved,
            "actual_one_copy_and_one_operand_proof": graph, "raw_timing": raw_timing,
            "passes_practical_timing_gate": proved and raw_timing["passes_practical_timing_gate"],
            "passes_strict_all_clock_diagnostic_gate": proved and raw_timing["passes_practical_timing_gate"] and
                                                        raw_timing["all_clock_fmax_nonregression_vs_accepted_reference"],
            "candidate_accepted_under_confirmed_target_clock_rule": proved and raw_timing["passes_practical_timing_gate"],
            "rbf_sha256": record["output_sha256"][str(FOLDER / "core.rbf")], "rbf_or_cram_independently_decoded": False,
            "old_generators_or_authenticators_replayed": False, "hardware_tested": False, "default_recipe_selected": False,
            "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True,
            "proof_limitations": [
                "The actual selected prefix and root-executed full compiler are hash-bound; no old proof generator is replayed.",
                "Zero buffer delta and exact original native identities, full cells/pins/BELs/PLL/consumers are mandatory; no numeric renaming or BUF collapse is used.",
                "Only actual net ROUTING attributes may differ. All other original metadata and whole LAB snapshots stay strict.",
                "Physical masks/carry/FF controls derive from exported model snapshots; no CRAM decoder, omitted cache/index/GPU-state proof or independent physical STA is claimed.",
                "All current expanded paths are native and finite; old six windows stay exact, other current pair windows are bound to the actual selected same-profile report.",
                "A structural failure retains actual timing diagnostics but prevents acceptance. Lower positive non-target headroom is permitted and disclosed.",
                "Successful RBF production exercises the backend routing writer; this proof does not independently decode every chipdb pip or establish hardware behavior."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compare-route-py-sha256", required=True)
    parser.add_argument("--scope-md-sha256", required=True)
    args = parser.parse_args()
    output = HERE / "comparison.json"
    require(not output.exists(), "full proof output already exists")
    result = comparison(args.compare_route_py_sha256, args.scope_md_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("graph_proof_available", "structural_rejection",
                                                 "candidate_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__":
    main()
