"""Derive the exact current port0 burst-enable path as a search guide."""
import argparse
import builtins
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
ROUTE = RAW / "local-multicopy-ready1-address-route-264"
PREFIX = RAW / "local-multicopy-ready1-address-stage-264"
PROOF = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
PROOF_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
PROFILE_SHA = "d32305c1cf99c1f3ead93fe11ba7e7539b3c88ae2b2b1b44b93346da3ddb5f64"
RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
COMMIT = "81243a1300304d7e598156c692be2fcbf2c16268"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
NATIVE = RAW / "narrow-integrated-264/compare_route.py"
NATIVE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE = SELECTED.parent / "freeze.py"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
INNER, OUTER = "hps_ddr.port0.slot_free_MISTRAL_ALUT2_Q", "hps_ddr.port0.slot_free_MISTRAL_ALUT3_B"
RETAINED = OUTER + "$local_remap"
TARGET = "hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_6"
HPS, PAIR = "hps_ddr.f2sdram", ("posedge ram_clock.clocks[0]", "posedge ram_clock.clocks[0]")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure helper identity differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure helper path differs")
    return module


def derive(self_sha, scope_sha):
    guide, output = HERE / "port0-burst-guide.json", HERE / "derivation.json"
    require(not guide.exists() and not output.exists(), "exclusive guide or derivation exists")
    native = load(NATIVE, NATIVE_SHA, "port0_burst_native")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha),
            (PROOF, PROOF_SHA), (ROUTE / "source-identity.json", PROFILE_SHA), (ROUTE / "route-c0/run.json", RUN_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        audit.bind(path, expected)
    proof, profile, record = (native.read(path) for path in
        (PROOF, ROUTE / "source-identity.json", ROUTE / "route-c0/run.json"))
    for path, expected in proof["artifact_sha256"].items():
        require(not Path(path).is_absolute() and ".." not in Path(path).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    for path, expected in proof["execution_file_sha256"].items():
        require(Path(path).is_absolute(), "flat runtime path is not absolute")
        audit.bind(Path(path), expected, execution=True)
    for path, expected in profile["input_sha256"].items():
        require(Path(path).is_absolute(), "profile input path is not absolute")
        audit.bind(Path(path), expected, execution=not Path(path).resolve().is_relative_to(ROOT))
    require(proof["phase"] == "local-multicopy-ready1-address-fifth-stage-full-route-inspection" and
        proof["structural_rejection"] is None and all(proof[key] is True for key in
            ("candidate_completed", "native_graph_proof_available", "physical_scope_proved",
             "routed_gain_accepted_under_confirmed_target_clock_rule", "final_original_path_metadata_and_runtime_hashes_stable")) and
        proof["source_identity_sha256"] == PROFILE_SHA and proof["current_full_run_sha256"] == RUN_SHA and
        proof["compiler_commit"] == profile["compiler_commit"] == record["compiler_commit"] == COMMIT and
        profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and
        record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
        record["final_original_input_output_runtime_hashes_stable"] is True and
        not any(key in record for key in ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")) and
        record["source_identity_sha256"] == PROFILE_SHA and
        all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
        record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): PROFILE_SHA} and
        record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip" and
        record["final_reported_hold_violations"] is False and not record["last_signoff_hold_warning_lines"],
        "current accepted proof/profile/closed compiler/runtime roles differ")
    for path, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(path) == expected, "actual runtime is outside frozen profile")
        audit.bind(Path(path), expected, execution=True)
    require(set(record["output_sha256"]) == {str(ROUTE / "route-c0" / name)
        for name in ("route.log", "routed.json", "timing.json", "core.rbf")}, "actual full output set differs")
    for path, expected in record["output_sha256"].items():
        require(Path(path).stat().st_size > 0, "actual output is empty")
        audit.bind(Path(path), expected)
    document = native.read_netlist(ROUTE / "route-c0/routed.json")
    top, report = document["modules"]["top"], native.read(ROUTE / "route-c0/timing.json")
    frozen = load(FREEZE, FREEZE_SHA, "port0_burst_freeze")
    selected = load(SELECTED, SELECTED_SHA, "port0_burst_topology", frozen)
    topology = selected.report_topology(document, report, native.read(PREFIX / "baseline/timing.json"))
    require(report["fmax"] == record["fmax"] and report["timing_report_paths"] == 16384 and
        topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7,
        "actual complete report coverage differs")
    drivers, users = selected.native_tables(top)
    def scalar(name, port):
        bits = top["cells"][name]["connections"][port]
        require(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0, "native scalar differs")
        return bits[0]
    def q(name):
        bit = scalar(name, "Q")
        require(drivers.get(bit) == [(name, "Q", 0, 0)], "Q driver is not unique")
        return bit
    root_q, inner_q, retained_q = q(OUTER), q(INNER), q(RETAINED)
    require((top["cells"][INNER]["type"], top["cells"][OUTER]["type"], top["cells"][RETAINED]["type"]) ==
        ("MISTRAL_ALUT2", "MISTRAL_ALUT3", "MISTRAL_ALUT4") and
        [top["cells"][name]["parameters"]["LUT"] for name in (INNER, OUTER, RETAINED)] ==
        ["1011", "00110010", "0100010001000000"] and scalar(OUTER, "B") == inner_q and
        (len(users[root_q]), len(users[retained_q])) == (172, 10) and
        top["cells"][TARGET]["type"] == "MISTRAL_FF" and scalar(TARGET, "ENA") == root_q and
        top["cells"][TARGET]["attributes"]["NEXTPNR_BEL"] == "MISTRAL_FF.34.30.32",
        "actual port0 cone/retained copy/target population differs")
    def lab(name):
        match = re.fullmatch(r"MISTRAL_(?:M?COMB|FF)\.(\d+)\.(\d+)\.\d+",
            top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "actual fabric owner lacks a placed BEL")
        return tuple(map(int, match.groups()))
    for slot in users[root_q] + users[retained_q]:
        require(slot[1:] == ("ENA", 0, 0) and top["cells"][slot[0]]["type"] == "MISTRAL_FF" and
            scalar(slot[0], "CLK") == 3549, "actual complete port0 root/copy cohort clock or kind differs")
    require([slot for slot in users[root_q] if lab(slot[0]) == (34, 30)] == [(TARGET, "ENA", 0, 0)],
        "target LAB does not have precisely one original-root ENA")
    paths, indices, memory = [], [], []
    for index, path in enumerate(report["critical_paths"]):
        end = path["path"][-1]["to"]
        total = math.fsum(segment["delay"] for segment in path["path"])
        require(math.isfinite(total), "reported complete path sum is not finite")
        if (path["from"], path["to"]) == PAIR:
            memory.append((index, total))
        if end["cell"] != TARGET or end["port"] != "ENA":
            continue
        require((path["from"], path["to"]) == PAIR and path["path"][-1]["type"] == "setup" and
            total > path["max_delay"], "target is not the actual memory ENA window violation")
        routes = [segment for segment in path["path"] if segment["type"] == "routing"]
        require([(s["from"]["cell"], s["from"]["port"], s["to"]["cell"], s["to"]["port"]) for s in routes] ==
            [(HPS, "cmd_ready_0", INNER, "A"), (INNER, "Q", OUTER, "B"), (OUTER, "Q", TARGET, "ENA")],
            "actual ready0/inner/outer/FF path routing sequence differs")
        paths.append(path); indices.append(index)
    require(memory, "actual memory path set is empty")
    worst = max(total for _, total in memory)
    require(len(paths) == len(indices) == 1 and
        [(index, total) for index, total in memory if total == worst] ==
        [(indices[0], math.fsum(segment["delay"] for segment in paths[0]["path"]))],
        "selected target is not the unique actual worst memory path")
    names = (INNER, OUTER, RETAINED, TARGET)
    snapshots = {}
    for name in names:
        pins = json.loads(bytes.fromhex(top["cells"][name]["attributes"]["FES_PINMAP_V1"]).decode())
        require(set(pins) == {"count", "pins"} and pins["count"] == len(pins["pins"]) and
            set(pins["pins"]) == set(top["cells"][name]["connections"]), "actual full pin snapshot is incomplete")
        snapshots[name] = {"record": top["cells"][name], "decoded_pin_snapshot": pins}
    relevant_bits = {root_q, inner_q, retained_q} | {bit for name in names for bits in
        top["cells"][name]["connections"].values() for bit in bits}
    alias_rows = [{"name": name, "record": net} for name, net in top["netnames"].items()
        if any(bit in relevant_bits for bit in net["bits"])]
    labs = {lab(name) for name in names}
    ff_rows = [{"cell": name, "record": cell} for name, cell in top["cells"].items()
        if cell["type"] == "MISTRAL_FF" and lab(name) in labs]
    result = dict(report); result["critical_paths"] = paths
    require(native.canonical({key: value for key, value in result.items() if key != "critical_paths"}) ==
        native.canonical({key: value for key, value in report.items() if key != "critical_paths"}), "report metadata changed")
    audit.finish()
    with guide.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    audit.bind(guide, sha(guide)); audit.finish()
    derived = {"schema": 1, "phase": "local-multicopy-port0-burst-exact-current-path-guide",
        "generator_sha256": self_sha, "scope_sha256": scope_sha, "accepted_full_proof_sha256": PROOF_SHA,
        "route_profile_sha256": PROFILE_SHA, "current_full_run_sha256": RUN_SHA, "compiler_commit": COMMIT,
        "guide_path": str(guide), "guide_sha256": sha(guide), "selected_path_source_indices": indices,
        "selected_paths": len(paths), "selected_endpoint": TARGET, "selected_lab": [34, 30],
        "actual_selected_total_ns": math.fsum(segment["delay"] for segment in paths[0]["path"]),
        "actual_selected_window_ns": paths[0]["max_delay"], "full_current_report_topology": topology,
        "native_owner_snapshots": snapshots, "native_alias_records": alias_rows,
        "root_q": root_q, "inner_q": inner_q, "retained_copy_q": retained_q,
        "root_consumer_slots": [list(slot) for slot in users[root_q]],
        "retained_copy_consumer_slots": [list(slot) for slot in users[retained_q]],
        "inner_consumer_slots": [list(slot) for slot in users[inner_q]],
        "predeclared_whole_labs": sorted(map(list, labs)), "original_ffs_in_predeclared_labs": ff_rows,
        "source_fmax": report["fmax"], "exact_path_objects_and_original_source_order_preserved": True,
        "all_original_report_metadata_except_filtered_critical_paths_exact": True,
        "clock_terms_locations_sources_windows_or_segment_delays_modified": False,
        "search_guide_only_not_a_new_full_timing_report": True, "new_candidate_qualified": False,
        "new_native_or_physical_equivalence_proved": False, "routed_gain_accepted": False, "hardware_tested": False,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}
    with output.open("x") as stream:
        stream.write(json.dumps(derived, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"guide_sha256": sha(guide), "derivation_sha256": sha(output), "paths": len(paths)}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-sha256", required=True); parser.add_argument("--scope-sha256", required=True)
    args = parser.parse_args()
    derive(args.self_sha256, args.scope_sha256)


if __name__ == "__main__":
    main()
