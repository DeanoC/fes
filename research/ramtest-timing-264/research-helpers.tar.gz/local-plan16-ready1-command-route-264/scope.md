# Contingent tenth-stage full-route recorder

ROOT alone activates this new pair after final whole-byte/hash/AST and independent
peer review. Prepare requires explicit actual completed tenth-run3d69a28a, positive
V2 prefix, immutable strict-rejectionf71d5228 and self/scope SHA arguments. The
future positive proof hash is not guessed. Placement profile77fd5636/plan00bf9b8c,
recorder7a00db6a/scope0ee7db61 and guideee82097b/derivation53151caf are fixed.
The strict e4124425/d2a7faa7 initial prefix cannot activate this recorder. Only a
separate ROOT-authorized positive explicit-private-owner V2 may activate it; its
flat closure must preserve the actual strict rejection and original helper/scope.
ROOT authorized the separate V2 after observing exactly four private alias shifts;
that authoring authorization supplies neither a positive proof nor route activation.

Current source stays d7e5c61f/baseec0a8d0c/ELF41c2afe1/archive4fbebd5e/host0f3c11a5,
with positive fresh-eight control1cff85d6 and positive ninth predecessord1ee7000.
Actual ninth full5966273b/ea8e5bed/profile788f16d2 is positive native/physical
construction with rejected gain112.981582MHz. Numerical acceptance remains the
separate accepted fifth6dcf8c4b/run5ed3c077 at117.77175903320312MHz. Nothing here
inherits rejected timing, new-copy physical truth or final hardware acceptance.

Only lower pure hash/JSON/binding/adoption and allowlisted log definitions from
the tenth recorder are used. Ninth full recorder1381258c contributes scalar/users
and four literal owner names only, never its old raw-ID pairs or entrypoints.
Driver3e81198b contributes its unchanged compiled guard parser. No old prepare,
route/run/main/auth/comparison is called. This recorder owns its live clean-source
query; only ROOT executes it. All current host/source/dependency files, flat proof
closures and actual runtime paths remain bound/rehashed before and after.

Two command constructions must agree: actual ninth full command with only the
tenth plan/current predicted driver guide/fresh outputs changed, and actual tenth
baseline with exactly one --no-route removed plus fresh driver candidate0/RBF.
The executable and all platform/header/library/device/seed/RTL/BUILD_ID/options,
cwd and diagnostic environment stay exact. Runtime equals the tenth baseline
and current ninth full runtime literally; the older accepted frame differs only
by the previously qualified current compiler/PATH substitution. HIP device is1,
and no ambient NEXTPNR_MISTRAL setting is admitted.

The positive V2 must independently prove32 plain-SIG rows and exactly eight ENA
transfers from root87→79 at LAB25.16, preserving nine literal cohorts21/2/10/1/6/
1/1/3/2 and all8221 FF BELs. Exactly four known generated private output frames
are allowed only by that future explicit proof. The recorder rechecks actual
before/current owner Qs, singular drivers, private aliases and complete unchanged
named consumers, with no fixed guessed raw IDs or global translation. New-copy
Q, BEL and cohort are derived from the actual positive model/image. Complete FF
records cover all cone/copy/cohort LABs plus source/operand/immediate carry; the
future driver site's whole LAB must be independently added by the full proof.

The driver guide is the untouched own tenth predicted report. It must expose
exactly the existing violated burst-decoder→command-counter arithmetic A edge,
with mask0x20/three distinct inputs/eight rows and49 original users. The fresh
driver parser retains minimum250ps/all four compiled guards and exact complete
domain summary334 endpoints/331 timed/3 unrelated/331 hold/reference-free1.
Candidate0's BEL/gain remain actual future observations, never inherited.

Route requires the exclusive full profile SHA, authenticated current compiler
read-audit invocation and all10 fresh local model dictionaries exact against the
positive prefix. It checks actual HIP completion, normal RBF signoff, cap16384/
15290 paths, positive finite reported Fmax and clear LAST literal/broad hold scan.
Failure preserves separate partial hashed outputs; final source/input/output/
runtime rehash failure revokes completion. The recorder records clocks but does
not independently evaluate seven window headrooms or accept gain.

Only a separate current full native/exported-physical/timing proof can accept a
memory gain above117.771759MHz while retaining all six non-target positive window
headrooms, pixel/capture constraints and zero final holds. Shared banks, carry,
whole original FF controls, all BUF/private owner frames and actual driver-site
effects require that proof. RBF decoding, caches/GPU IDs, independent numerical
STA and hardware remain unproved. Old files, compiler defaults and records stay
untouched; this inactive pair produces no evidence until ROOT activation.
