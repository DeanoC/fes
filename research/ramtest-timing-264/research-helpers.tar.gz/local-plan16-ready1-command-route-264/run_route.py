"""Contingent fresh driver/GPU/RBF recorder for a positive tenth-stage V2 prefix."""
import argparse
import hashlib
import importlib.util
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
BASELINE = RAW / "local-plan16-ready1-command-stage-264"
PROOF, STRICT = BASELINE / "baseline/comparison-prefix-v2.json", BASELINE / "baseline/comparison-prefix.json"
STRICT_HELPER_SHA = "e4124425f593d5d8cfb6de13ccf8a54ab4430b6a83e5c7156e59baacaa466ec0"
STRICT_SCOPE_SHA = "d2a7faa74e7c7f4dd42449e2483cdc9eeab52c14b3bee372510d43e8647b8e0b"
PREFIX_PROFILE_SHA = "77fd5636a7947d349605147bc164ba7cf562dc5885aa09072a1cc2945931e546"
PREFIX_RUN_SHA = "3d69a28a7fb1741349f1b4e77be6f13bbdae21dfeb4bacd77ef5f5862059ad11"
STRICT_REJECTION_SHA = "f71d52283200fdee82b4176bda3c0bcc134174bb9b28e7007e5bda6f7864a5af"
PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
TENTH_SHA = "7a00db6a5bb6f045bfdac8805f234e16b9d67d75cbe13e52db912b7361a595e5"
TENTH_SCOPE_SHA = "0ee7db618025c004c861d9ab73148e33c0ad2ecdf4e11361b81e5e02db2dfd92"
GUIDE_SHA = "ee82097b60d255e7a1ef9cc1e3eab33cb2f33d22d33269dff29e7cec3bda850f"
DERIVATION_SHA = "53151cafd46efd4626bde52f9488805b7d3aec82367b6a204171a75086ca4719"
PARENT_HELPER = RAW / "local-plan16-ready1-skid-byte-route-264/run_route.py"
PARENT_HELPER_SHA = "1381258caa20e3e4925e5c817c6ff36092270bd348f4816f325b86360e3a89bd"
PARENT_SCOPE_SHA = "355863f20df2280dad3a46d3316baa72e229fe8eaf767d60a35686e5e8fd62c6"
DRIVER = RAW / "local-multicopy-ready1-route-264/run_route.py"
DRIVER_SHA = "3e81198bb1c9c89c8c63144b0354138514c5c10ba5b0ef5ecd82d15e3956ccf3"
DRIVER_SCOPE_SHA = "6f98611a39b498b329909bff3b0d764dab10f94214ae85039528812ecdf8f414"
EXPERIMENT = RAW / "local-plan16-ready1-skid-byte-route-proof-264/comparison.json"
EXPERIMENT_SHA = "5966273babe8b4405ce23571d30cc9b7e342fbdd062272ac4b575df54596b95a"
TEMPLATE_FOLDER = RAW / "local-plan16-ready1-skid-byte-route-264"
TEMPLATE_RUN_SHA = "ea8e5bed840dc8ec53c077b669fc2cc2cc3a8081afd27476695be1bd675f9ba5"
TEMPLATE_PROFILE_SHA = "788f16d21d128edbf0ffce4fb32b63db6e47135cf9faa5686d084d6fd4aa780d"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
ACCEPTED_FOLDER = RAW / "local-multicopy-ready1-address-route-264"
ACCEPTED_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
MINIMUM_MEMORY_MHZ = 117.77175903320312
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "route-c0"


def require(value, message):
    if not value: raise ValueError(message)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def definitions():
    tenth = load(BASELINE / "run_baseline.py", TENTH_SHA, "command_tenth_route_baseline_pure")
    ninth, control, local = tenth.local_definitions()
    parent = load(PARENT_HELPER, PARENT_HELPER_SHA, "command_tenth_route_parent_scalar_pure")
    driver = load(DRIVER, DRIVER_SHA, "command_tenth_route_driver_log_pure")
    return tenth, ninth, control, local, parent, driver


def clean_source(tenth, host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(tenth.SOURCE, "rev-parse", "HEAD") == tenth.COMMIT and not git(tenth.SOURCE, "status", "--porcelain", "--untracked-files=all") and
            git(tenth.SOURCE, "merge-base", tenth.BASE, tenth.COMMIT) == tenth.BASE and
            set(git(tenth.SOURCE, "diff", "--name-only", tenth.BASE, tenth.COMMIT).splitlines()) == set(host["changed_source_files"]), "current compiler is not clean committed host delta")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + \
            [(tenth.SOURCE / name, commit) for name, commit in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def command(baseline, template, tenth):
    result, predicted = list(template["command"]), list(baseline["command"])
    require(result[0] == predicted[0] == str(tenth.BINARY) and "--no-route" not in result and "--compress-rbf" not in result and
            result.count("--router") == result.count("--gpu-device") == result.count("--remap-lut-driver-candidate") == 1 and
            result[result.index("--router") + 1] == "gpu" and result[result.index("--gpu-device") + 1] == "1" and
            result[result.index("--remap-lut-driver-candidate") + 1] == "0", "current ninth full command selectors differ")
    require(predicted.count("--no-route") == 1 and not any(flag in predicted for flag in
            ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "current tenth predicted role differs")
    for flag, path in (("--remap-plan", BASELINE / "local-plan.json"), ("--remap-lut-driver-critical", BASELINE / "baseline/timing.json"),
            ("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json"), ("--rbf", FOLDER / "core.rbf")):
        require(result.count(flag) == 1, "ambiguous prior full selector"); result[result.index(flag) + 1] = str(path)
    predicted.remove("--no-route")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json")):
        require(predicted.count(flag) == 1, "ambiguous tenth output selector"); predicted[predicted.index(flag) + 1] = str(path)
    predicted += ["--remap-lut-driver-critical", str(BASELINE / "baseline/timing.json"), "--remap-lut-driver-candidate", "0", "--rbf", str(FOLDER / "core.rbf")]
    require(result == predicted, "full command differs outside ten-plan/own driver guide/fresh output aliases")
    return result


def prepare(prefix_sha, run_sha, strict_sha, self_sha, scope_sha):
    require(all(type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) and value != "0" * 64
            for value in (prefix_sha, run_sha, strict_sha, self_sha, scope_sha)) and run_sha == PREFIX_RUN_SHA and strict_sha == STRICT_REJECTION_SHA and
            not PROFILE.exists() and not FOLDER.exists(), "actual positive V2/closedrun/strict rejection/helper pins and exclusive outputs required")
    tenth, ninth, control, local, parent, driver = definitions(); inputs = {}
    for path, expected in ((PROOF, prefix_sha), (STRICT, strict_sha), (BASELINE / "compare_prefix.py", STRICT_HELPER_SHA), (BASELINE / "prefix-scope.md", STRICT_SCOPE_SHA),
            (BASELINE / "baseline/run.json", run_sha), (BASELINE / "source-identity.json", PREFIX_PROFILE_SHA), (BASELINE / "local-plan.json", PLAN_SHA),
            (BASELINE / "run_baseline.py", TENTH_SHA), (BASELINE / "scope.md", TENTH_SCOPE_SHA), (Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha),
            (PARENT_HELPER, PARENT_HELPER_SHA), (PARENT_HELPER.parent / "scope.md", PARENT_SCOPE_SHA), (DRIVER, DRIVER_SHA), (DRIVER.parent / "scope.md", DRIVER_SCOPE_SHA),
            (EXPERIMENT, EXPERIMENT_SHA), (TEMPLATE_FOLDER / "route-c0/run.json", TEMPLATE_RUN_SHA), (TEMPLATE_FOLDER / "source-identity.json", TEMPLATE_PROFILE_SHA),
            (ACCEPTED, ACCEPTED_SHA), (ACCEPTED_FOLDER / "route-c0/run.json", ACCEPTED_RUN_SHA),
            (tenth.BINARY, tenth.BINARY_SHA), (tenth.ARCHIVE, tenth.ARCHIVE_SHA), (tenth.HOST, tenth.HOST_SHA)): tenth.bind(inputs, path, expected)
    proof, strict, identity, baseline, template, accepted, experiment, accepted_proof, host, prerequisite = (tenth.read(path) for path in
        (PROOF, STRICT, BASELINE / "source-identity.json", BASELINE / "baseline/run.json", TEMPLATE_FOLDER / "route-c0/run.json",
         ACCEPTED_FOLDER / "route-c0/run.json", EXPERIMENT, ACCEPTED, tenth.HOST, ninth.CONTROL / "baseline/comparison-control.json"))
    for manifest in (proof, strict, experiment, accepted_proof, prerequisite): tenth.adopt(inputs, manifest)
    owners = set(parent.PRIVATE_OUTPUTS)
    require(strict["phase"] == "local-plan16-ready1-command-tenth-stage-bounded-native-prefix" and strict["generator_sha256"] == STRICT_HELPER_SHA and
            strict["scope_sha256"] == STRICT_SCOPE_SHA and strict["source_identity_sha256"] == PREFIX_PROFILE_SHA and strict["current_baseline_run_sha256"] == run_sha and
            strict["native_path_topology_rejection"] is None and strict["native_graph_proof_available"] is strict["fresh_driver_guide_available_after_conditional_prefix_proof"] is False and
            strict["structural_rejection"]["exception_type"] == "ValueError" and strict["structural_rejection"]["reason"] in
                {"original alias/raw bits/metadata differs: " + owner + "$Q" for owner in owners}, "immutable strict tenth private-alias rejection differs")
    control.host_valid(host, tenth.HOST_SHA)
    require(proof["schema"] == 1 and proof["phase"] == "local-plan16-ready1-command-tenth-stage-explicit-private-owner-native-prefix" and
            proof["compiler_commit"] == tenth.COMMIT and proof["delta_base_commit"] == tenth.BASE and proof["immutable_strict_prefix_rejection_sha256"] == strict_sha and
            proof["source_identity_sha256"] == PREFIX_PROFILE_SHA and proof["current_baseline_run_sha256"] == run_sha and proof["control_proof_sha256"] == tenth.CONTROL_PROOF_SHA and
            proof["previous_prefix_proof_sha256"] == tenth.PREVIOUS_PROOF_SHA and proof["previous_baseline_run_sha256"] == tenth.PREVIOUS_RUN_SHA and
            proof["runner_sha256"] == TENTH_SHA and proof["runner_scope_sha256"] == TENTH_SCOPE_SHA and proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and
            all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
                "all_nine_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "final_original_path_metadata_and_runtime_hashes_stable")), "actual tenth V2 prefix is not independently positive")
    require(inputs.get(str(BASELINE / "compare_prefix_v2.py")) == proof["generator_sha256"] and inputs.get(str(BASELINE / "prefix-v2-scope.md")) == proof["scope_sha256"] and
            all(proof["artifact_sha256"].get(str(path.relative_to(ROOT))) == expected for path, expected in
                ((STRICT, strict_sha), (BASELINE / "compare_prefix.py", STRICT_HELPER_SHA), (BASELINE / "prefix-scope.md", STRICT_SCOPE_SHA))) and
            inputs.get(str(ninth.CONTROL / "baseline/comparison-control.json")) == tenth.CONTROL_PROOF_SHA and
            prerequisite["fresh_ninth_stage_control_prerequisite_proved"] is prerequisite["complete_predicted_report_exact"] is True and
            prerequisite["structural_rejection"] is prerequisite["native_path_topology_rejection"] is None, "positive V2/immutable strict/current compiler control closure differs")
    require(identity["phase"] == "local-plan16-ready1-command-tenth-stage-predicted-baseline" and identity["helper_sha256"] == TENTH_SHA and
            identity["scope_sha256"] == TENTH_SCOPE_SHA and identity["local_plan_sha256"] == PLAN_SHA and identity["guide_sha256"] == GUIDE_SHA and
            identity["guide_derivation_sha256"] == DERIVATION_SHA and identity["control_proof_sha256"] == tenth.CONTROL_PROOF_SHA and identity["host_validation_sha256"] == tenth.HOST_SHA and
            identity["experimental_current_full_proof_sha256"] == EXPERIMENT_SHA and identity["accepted_current_full_proof_sha256"] == ACCEPTED_SHA and
            baseline["source_identity_sha256"] == PREFIX_PROFILE_SHA and baseline["original_nine_complete_trial_models_exact"] is True and
            all(tenth.canonical(baseline[key]) == tenth.canonical(value) for key, value in identity.items() if key != "input_sha256") and
            baseline["input_sha256"] == {**identity["input_sha256"], str(BASELINE / "source-identity.json"): PREFIX_PROFILE_SHA}, "tenth record/profile union differs")
    require(experiment["current_full_run_sha256"] == TEMPLATE_RUN_SHA and experiment["source_identity_sha256"] == TEMPLATE_PROFILE_SHA and experiment["accepted_full_proof_sha256"] == ACCEPTED_SHA and
            experiment["structural_rejection"] is None and experiment["native_graph_proof_available"] is experiment["physical_scope_proved"] is True and
            experiment["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and accepted_proof["current_full_run_sha256"] == ACCEPTED_RUN_SHA and
            accepted_proof["structural_rejection"] is None and accepted_proof["native_graph_proof_available"] is accepted_proof["physical_scope_proved"] is
            accepted_proof["routed_gain_accepted_under_confirmed_target_clock_rule"] is True, "ninth construction versus accepted fifth timing roles differ")
    for record in (baseline, template, accepted):
        require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
                not any(key in record for key in ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")), "closed run is incomplete")
        for ledger in (record["input_sha256"], record["output_sha256"], record["execution"]["files"]):
            for path, expected in ledger.items(): tenth.bind(inputs, path, expected)
    for key in control.HOST_MAPS:
        for path, expected in host[key].items(): tenth.bind(inputs, path, expected)
    require(baseline["compiler_commit"] == template["compiler_commit"] == tenth.COMMIT and baseline["delta_base_commit"] == template["delta_base_commit"] == tenth.BASE and
            baseline["binary_sha256"] == template["binary_sha256"] == tenth.BINARY_SHA and baseline["source_archive_sha256"] == template["source_archive_sha256"] == tenth.ARCHIVE_SHA and
            baseline["execution"] == identity["baseline_execution"] == template["execution"] == control.expected_execution(accepted) and
            baseline["diagnostic_environment"] == template["diagnostic_environment"] == accepted["diagnostic_environment"] and
            baseline["cwd"] == template["cwd"] == accepted["cwd"] == str(MODULE), "current compiler/runtime/frame differs")
    for name, expected in control.SCRIPTS.items(): tenth.bind(inputs, MODULE / "scripts" / name, expected)
    for path, expected in control.PARSERS: tenth.bind(inputs, path, expected)
    models = tenth.qualification((BASELINE / "baseline/phase.log").read_text(), ninth, control, local)
    require(len(models) == 10 and tenth.canonical(models) == tenth.canonical(baseline["actual_selected_local_qualification"]) == tenth.canonical(proof["fresh_local_models"]) and
            tenth.canonical(models[:9]) == tenth.canonical(identity["retained_local_models"]) == tenth.canonical(proof["previous_local_models"]) and
            tenth.read(BASELINE / "local-plan.json")["steps"] == identity["local_plan_steps"] and len(identity["local_plan_steps"]) == 10 and
            identity["local_plan_steps"][:9] == tenth.read(tenth.PREVIOUS / "source-identity.json")["local_plan_steps"], "fresh ten models/exact nine descriptors differ")
    tenth.bind(inputs, tenth.NATIVE, tenth.NATIVE_SHA)
    native = load(tenth.NATIVE, tenth.NATIVE_SHA, "command_tenth_route_native_pure")
    top = native.read_netlist(BASELINE / "baseline/placed.json")["modules"]["top"]
    prior_top = native.read_netlist(tenth.PREVIOUS / "baseline/placed.json")["modules"]["top"]
    graph = proof["native_graph_evidence"]
    require(graph["serialized_native_scope_proved"] is graph["complete_native_driver_and_user_tables_proved"] is True and graph["new_clone"] ==
            identity["expected_additional_copy_name"] == models[9]["outer"] + "$local_remap$2" and graph["declared_ena_redirect_count"] == len(graph["declared_ena_redirects"]) == models[9]["ena_users"] == 8 and
            graph["assignments_checked"] == 32 and graph["original_root_users_before"] == 87 and graph["original_root_users_after"] == 79 and
            tenth.canonical(graph["retained_copy_cohorts"]) == tenth.canonical(identity["retained_copy_cohorts"]), "tenth graph/cohort scope differs")
    private_rows = graph["explicit_private_output_owners"]
    require(graph["private_output_owner_count"] == len(private_rows) == 4 and graph["private_output_frame_alignment_used"] is graph["all_original_nonprivate_raw_slots_exact"] is True and
            {row["owner"] for row in private_rows} == owners, "explicit four-owner partition differs")
    for row in private_rows:
        owner, alias = row["owner"], row["alias"]; old, new = parent.scalar(prior_top["cells"][owner], "Q"), parent.scalar(top["cells"][owner], "Q")
        slots = sorted(tuple(slot) for slot in row["named_consumer_slots"])
        require(alias == owner + "$Q" and row["before_raw_bit"] == old and row["after_raw_bit"] == new and old != new and
                row["before_driver"] == row["after_driver"] == [owner, "Q", 0, 0] and parent.users(prior_top, old) == parent.users(top, new) == slots and
                tenth.canonical(prior_top["netnames"][alias]) == tenth.canonical(row["before_alias_record"]) and tenth.canonical(top["netnames"][alias]) == tenth.canonical(row["after_alias_record"]), "actual named private owner/Q/alias/complete consumers differs")
    rows, frames = graph["retained_copy_cohorts"], graph["actual_retained_copy_output_rows"]
    require(len(rows) == len(frames) == 9 and [len(row["consumer_slots"]) for row in rows] == [21, 2, 10, 1, 6, 1, 1, 3, 2], "nine retained cohorts differ")
    cohort, declared, labs = set(), {graph["new_clone"], driver.SOURCE, driver.SINK}, {tuple(model["primary_lab"]) for model in models}
    for row, frame, model in zip(rows, frames, models[:9]):
        name, cell = row["cell"], top["cells"][row["cell"]]
        require(frame["cell"] == name and frame["before_raw_bit"] == frame["after_raw_bit"] == parent.scalar(row["record"], "Q") == parent.scalar(cell, "Q") and
                frame["consumer_slots"] == row["consumer_slots"] and parent.users(top, parent.scalar(cell, "Q")) == [tuple(slot) for slot in row["consumer_slots"]] and
                tenth.canonical(cell) == tenth.canonical(row["record"]) and cell["attributes"]["NEXTPNR_BEL"] == model["bel"], "retained owner/Q/record/consumer slots differs")
        cohort.update(slot[0] for slot in row["consumer_slots"]); declared.add(name)
    clone = top["cells"][graph["new_clone"]]
    chosen = sorted((row["cell"], "ENA", 0, 0) for row in graph["declared_ena_redirects"])
    expected_chosen = sorted((row["cell"], "ENA", 0, 0) for row in identity["declared_ena_cohort"])
    require(clone["attributes"]["NEXTPNR_BEL"] == models[9]["bel"] == graph["actual_clone_bel"] and parent.scalar(clone, "Q") == graph["actual_clone_q"] and
            len(set(chosen)) == len(chosen) == 8 and chosen == expected_chosen == parent.users(top, parent.scalar(clone, "Q")), "new tenth clone/eight predeclared ENAs differs")
    cohort.update(slot[0] for slot in chosen)
    source, sink = top["cells"][driver.SOURCE], top["cells"][driver.SINK]
    q, lut = parent.scalar(source, "Q"), source["parameters"].get("LUT"); source_users = parent.users(top, q)
    require(source["type"] == "MISTRAL_ALUT3" and sink["type"] == "MISTRAL_ALUT_ARITH" and parent.scalar(sink, "A") == q and type(lut) is str and len(lut) == 8 and
            set(lut) <= {"0", "1"} and int(lut, 2) == 0x20 and len({parent.scalar(source, port) for port in "ABC"}) == 3 and len(source_users) == 49 and
            (driver.SINK, "A", 0, 0) in source_users and all(q not in port["bits"] for port in top["ports"].values()), "current source49/eight-row/arithmetic operand edge differs")
    carry = parent.scalar(sink, "CO")
    successors = [(name, cell) for name, cell in top["cells"].items() if name != driver.SINK and cell["type"] == "MISTRAL_ALUT_ARITH" and cell["connections"].get("CI") == [carry]]
    require(len(successors) == 1, "actual immediate CO-to-CI successor is not unique"); declared.add(successors[0][0])
    for model in models: declared.update((model["inner"], model["outer"]))
    for name in declared | cohort:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared owner/cohort lacks placed BEL"); labs.add(tuple(map(int, match.groups())))
    ff_rows = []
    for name, cell in top["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", cell["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None and identity["all_original_ff_bel_manifest"].get(name) == cell["attributes"]["NEXTPNR_BEL"], "original FF BEL manifest differs")
        if tuple(map(int, match.groups())) in labs: ff_rows.append({"cell": name, "record": cell})
    require(len(identity["all_original_ff_bel_manifest"]) == 8221 and cohort <= {row["cell"] for row in ff_rows} and
            all(top["cells"][name]["connections"]["CLK"] == [3549] for name in cohort), "complete FF/common-clock/wholeLAB scope differs")
    report, parent_report = tenth.read(BASELINE / "baseline/timing.json"), tenth.read(ACCEPTED_FOLDER / "route-c0/timing.json")
    relevant = set()
    for path in report["critical_paths"]:
        if math.fsum(segment["delay"] for segment in path["path"]) <= path["max_delay"]: continue
        for segment in path["path"]:
            if segment["type"] != "routing": continue
            a, b = segment["from"], segment["to"]
            if top["cells"][a["cell"]]["type"] in {"MISTRAL_ALUT" + str(width) for width in range(2, 7)} and \
                    top["cells"][b["cell"]]["type"] == "MISTRAL_ALUT_ARITH" and b["port"] in {"A", "B", "C", "D0", "D1"}: relevant.add((a["cell"], b["cell"], b["port"]))
    require(relevant == {(driver.SOURCE, driver.SINK, "A")} and report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            parent_report["fmax"]["ram_clock.clocks[0]"]["achieved"] == MINIMUM_MEMORY_MHZ, "driver guide membership/cap/count/accepted threshold differs")
    result = {"schema": 1, "phase": "local-plan16-ready1-command-tenth-stage-fresh-driver-full-route", "compiler_commit": tenth.COMMIT, "delta_base_commit": tenth.BASE,
        "binary_sha256": tenth.BINARY_SHA, "source_archive_sha256": tenth.ARCHIVE_SHA, "prefix_proof_sha256": prefix_sha, "prefix_source_identity_sha256": PREFIX_PROFILE_SHA,
        "prefix_baseline_run_sha256": run_sha, "prefix_generator_sha256": proof["generator_sha256"], "prefix_scope_sha256": proof["scope_sha256"],
        "local_plan_sha256": PLAN_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha, "host_validation_sha256": tenth.HOST_SHA,
        "control_proof_sha256": tenth.CONTROL_PROOF_SHA, "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": ACCEPTED_RUN_SHA,
        "experimental_ninth_full_proof_sha256": EXPERIMENT_SHA, "experimental_ninth_full_run_sha256": TEMPLATE_RUN_SHA, "experimental_ninth_routed_gain_accepted": False,
        "command": command(baseline, template, tenth), "cwd": baseline["cwd"], "diagnostic_environment": baseline["diagnostic_environment"], "baseline_execution": baseline["execution"],
        "input_sha256": dict(sorted(inputs.items())), "prefix_fresh_local_models": models, "declared_driver_edge": [driver.SOURCE, driver.SINK, "A"], "driver_candidate": 0,
        "driver_site_must_qualify_freshly": True, "declared_ena_redirects": graph["declared_ena_redirects"], "new_ready_clone": graph["new_clone"], "new_ready_clone_bel": models[9]["bel"],
        "retained_copy_cohorts": rows, "actual_retained_copy_output_rows": frames, "prefix_private_output_frame_alignment_used": graph["private_output_frame_alignment_used"],
        "prefix_explicit_private_output_owners": private_rows, "immutable_strict_prefix_rejection_sha256": strict_sha,
        "driver_current_source_record": source, "driver_current_source_consumer_slots": [list(slot) for slot in source_users],
        "driver_source_conditional_truth_rows": [{"assignment": i, "Q": (int(lut, 2) >> i) & 1} for i in range(8)], "driver_current_sink_record": sink,
        "driver_current_immediate_carry_successor": {"cell": successors[0][0], "record": successors[0][1]}, "declared_original_local_driver_and_carry_cells": sorted(declared),
        "affected_whole_labs": sorted(map(list, labs)), "all_original_ff_members_in_affected_labs": sorted(ff_rows, key=lambda row: row["cell"]),
        "actual_fresh_driver_site_neighborhood_requires_independent_full_proof": True, "minimum_accepted_memory_mhz": MINIMUM_MEMORY_MHZ, "accepted_fmax": parent_report["fmax"],
        "routed_graph_proof_available": False, "physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    tenth.finish(inputs); clean_source(tenth, host)
    with PROFILE.open("x") as stream: stream.write(tenth.canonical(result) + "\n")
    print(tenth.canonical({"profile_sha256": tenth.sha(PROFILE), "inputs": len(inputs), "whole_labs": len(labs), "original_ffs": len(ff_rows)}))


def route(profile_sha):
    tenth, ninth, control, local, parent, driver = definitions(); inputs = {}
    tenth.bind(inputs, PROFILE, profile_sha); profile = tenth.read(PROFILE)
    for path, expected in profile["input_sha256"].items(): tenth.bind(inputs, path, expected)
    baseline, template, host = (tenth.read(path) for path in (BASELINE / "baseline/run.json", TEMPLATE_FOLDER / "route-c0/run.json", tenth.HOST))
    require(not FOLDER.exists() and profile["compiler_commit"] == tenth.COMMIT and profile["command"] == command(baseline, template, tenth) and
            profile["baseline_execution"] == baseline["execution"] and profile["diagnostic_environment"] == baseline["diagnostic_environment"] and
            inputs[str(BASELINE / "baseline/run.json")] == profile["prefix_baseline_run_sha256"] and inputs[str(PROOF)] == profile["prefix_proof_sha256"] and
            inputs[str(STRICT)] == profile["immutable_strict_prefix_rejection_sha256"] and inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and
            inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and profile["minimum_accepted_memory_mhz"] == MINIMUM_MEMORY_MHZ, "frozen exclusive fullroute role differs")
    control.host_valid(host, tenth.HOST_SHA); clean_source(tenth, host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in control.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(inputs.get(str(MODULE / "scripts" / name)) == expected and Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and
                tenth.sha(loaded.__file__) == expected, "executed project dependency differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(tenth.BINARY,
        f"base_commit={tenth.BASE}; experimental_source_sha256={tenth.ARCHIVE_SHA}; sha256={tenth.BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}; started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual current runtime/ambient diagnostics differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(tenth.canonical(record) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "actual tenth full compiler failed")
        log = (FOLDER / "route.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and "Running the GPU router" in log and
                "Running signoff timing analysis..." in log and "Running predicted placed timing analysis for --report" not in log, "actual GPU/RBF signoff provenance absent")
        models = tenth.qualification(log, ninth, control, local)
        require(tenth.canonical(models) == tenth.canonical(profile["prefix_fresh_local_models"]), "actual ten fresh models differ from positive prefix")
        trial = driver.qualification(log)
        require(trial["domain_summary"] == ["334", "331", "3", "331", "1"], "complete timed/unrelated/hold/reference-free domain coverage differs")
        record["actual_selected_local_qualification"], record["actual_fresh_driver_qualification"] = models, trial
        report = tenth.read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and all(type(value) in (int, float) and math.isfinite(value) and value > 0
            for row in report["fmax"].values() for value in row.values()), "actual full report cap/count/Fmax differs")
        record["fmax"], record["actual_live_gpu_backend"] = report["fmax"], board._require_gpu_backend(log)
        require(record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log), "actual HIP completion absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        record["final_reported_hold_violations"] = "Hold/min time violation" in last
        record["last_signoff_hold_warning_lines"] = [line for line in last.splitlines() if re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not record["final_reported_hold_violations"] and not record["last_signoff_hold_warning_lines"], "LAST signoff hold/min violation")
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "actual full output absent"); record["output_sha256"][str(path)] = tenth.sha(path)
        tenth.finish({**inputs, **record["output_sha256"]}); clean_source(tenth, host); record["completed"] = True
        print(tenth.canonical({"completed": True, "fmax": record["fmax"], "driver": trial, "routed_gain_accepted": False}))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): tenth.sha(FOLDER / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); tenth.finish({**inputs, **record.get("output_sha256", {})}); clean_source(tenth, host); record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False; record["final_original_input_output_runtime_hashes_stable"] = False; record["final_rehash_failure"] = repr(error); raise
                finally: (FOLDER / "run.json").write_text(tenth.canonical(record) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "route"))
    for name in ("prefix-sha256", "run-sha256", "strict-rejection-sha256", "self-sha256", "scope-sha256", "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.prefix_sha256, args.run_sha256, args.strict_rejection_sha256, args.self_sha256, args.scope_sha256)
        require(all(values), "actual positive V2/closedrun/strict rejection/helper pins required"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared full profile pin required"); route(args.profile_sha256)


if __name__ == "__main__": main()
