project_open top
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist
set output_dir [lindex $quartus(args) 0]
set pins [get_pins -hierarchical {*f2sdram*rd_data_0*}]
set sinks [get_registers {*port0*returned_data*}]
puts "READ_DATA_PINS [get_collection_size $pins]"
puts "RETURNED_DATA_REGISTERS [get_collection_size $sinks]"
report_timing -setup -through $pins -to $sinks -npaths 20 -nworst 1 -detail full_path -show_routing -file [file join $output_dir quartus-read-data0.rpt]
foreach_in_collection pin $pins {
    set name [get_pin_info -name $pin]
    if {[string first {rd_data_0[48]} $name] >= 0} {
        puts "EXACT_READ_DATA_PIN $name"
        report_timing -setup -through $pin -to $sinks -npaths 2 -detail full_path -show_routing -file [file join $output_dir quartus-read-data0-bit48.rpt]
    }
}
project_close
