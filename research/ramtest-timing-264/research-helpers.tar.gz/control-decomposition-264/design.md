# Bounded control-cut decomposition

Read-only algebra and compiler feasibility analysis, 2026-09-30. The retained
parent is `remap-plan-264/route-c0-g1-third-c0-g1`, memory Fmax 116.171005 MHz,
BUILD_ID `7168b508ab424b70f1c0f87b2035d821`, compiler
`b8f321400f78637a3347f5b020c05afc555bffd5` based on
`664599e39086d89104a0eeeaa44f192038f88ae6`. This proposal does not require an
accepted24 rewrite: R remains an external signal with its original nine users.
No qualification, legal placement, routed gain, recipe selection or hardware
acceptance follows from the Boolean proof.

## Actual graph and masks

These names identify observed evidence, not optimizer matching rules. All
relevant logical input/output states in the actual parent `FES_PINMAP_V1`
snapshots are SIG. Port orders below are A first, with A as the least
significant truth-row bit.

```text
R  = ddr1_test.pass_end_MISTRAL_ALUT5_D_1_Q_MISTRAL_ALUT3_Q.Q
N0 = ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT2_Q_B_MISTRAL_ALUT2_Q
n  = ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT2_Q_B_MISTRAL_ALUT3_Q
N1 = ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT2_Q
N2 = ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_E
T  = ddr1_test.cmd_end_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_B
s  = ddr1_test.state_MISTRAL_FF_Q_4.Q
a  = ddr1_test.state_MISTRAL_FF_Q_3.Q
q  = ram_clock.locked_MISTRAL_ALUT2_A_Q_MISTRAL_FF_DATAIN_1_Q_MISTRAL_FF_DATAIN.Q
t  = ddr0_test.stop_MISTRAL_FF_Q.Q
b  = ddr1_test.burst_end_MISTRAL_FF_Q.Q
h  = ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT6_Q.Q
```

| Node | Inputs | Mask | Function obtained from actual mask |
| --- | --- | --- | --- |
| N0 | s,R | `0x8` | s R |
| n | a,q,R | `0x4c` | q (~a OR ~R) |
| N1 | N0,n | `0xb` | N0 OR ~n |
| N2 | s,t,b,h,N1 | `0x7500` | h ~N1 (~s OR ~t b) |
| T | a,u,N2 | `0xd0` | N2 (~a OR u), with u left external |

The N2 mask sets rows 8,10,12,13,14; the n mask sets rows 2,3,6. Direct
substitution gives

```text
N2 = h q ((~a ~s) OR (~R (~s OR (~t b))))
R=0: N2 = h q (~s OR (~t b))
R=1: N2 = h q ~a ~s
```

The exact seven boundary signals are [a,s,t,b,R,h,q]. Their parent raw Q bits
are respectively [23776,22954,4223,23027,23772,23888,23037]; raw bit numbers
are evidence observations, never stable identity/matching rules. The original
critical path is R→N0→N1.A→N2.E→T.C, ending at generated
`ddr1_address_MISTRAL_FF_Q_18.ENA`, logical address[10].

## All 128 rows and three column classes

Choose bound inputs [a,s,t,b], row `a+2s+4t+8b`, and free inputs [R,h,q], row
`R+2h+4q`. Evaluating the four actual masks gives these complete eight-bit
columns for bound rows 0 through 15:

```text
c0 40 00 00  c0 40 00 00  c0 40 40 40  c0 40 00 00
```

Thus the free functions are 0, h q ~R, and h q, with multiplicities 6,6,4.
All 16×8 assignments are covered; the total number of true rows is
6×0 + 6×1 + 4×2 = 14. R=0 contributes ten true bound rows at h=q=1;
R=1 contributes four. No input is inessential: a toggles the R=1,s=0 case;
s toggles R=1,a=0; t and b toggle R=0,s=1; R toggles a column 0x40; h and q
each gate a nonzero column. These statements hold for arbitrary seven-bit
assignments, without one-hot state, lock/stop or other RTL correlations.

Canonical class codes [0,1,2] for columns [00,40,c0] give encoding masks
`0x2e22` and `0x1111` on [a,s,t,b], and root mask `0x00c04000` on
[R,h,q,e0,e1], with unused code3 set to zero.

Trying all `4P3=24` injective two-bit code assignments improves support.
Assign classes [00,40,c0] codes [00,01,11]:

| Generated LUT | Essential inputs | Mask | Function |
| --- | --- | --- | --- |
| U | s,t,b | `0x75` | ~s OR ~t b |
| V | a,s | `0x1` | ~a ~s |
| H | R,h,q,U,V | `0xc0004000` | h q U (~R OR V) |

Only codes (U,V)=00,10,11 in tuple notation, numeric 0,1,3 with U as bit0,
can occur. Numeric code2 (U=0,V=1) is unreachable because V implies U;
its root rows are explicitly zero. This is an invariant of the generated
encoders over all sixteen bound assignments, not an RTL-state don't-care.
Recomposing U,V,H covers every one of the original 128 assignments. The
implementation uses ALUT3+ALUT2+ALUT5, three new cells and at most two levels;
late R,h,q each reaches H in one level.

A second verified partition demonstrates the generic four-class case:
bound [s,a,q,t], free [R,b,h], classes {0,h,h~R,h~R b}. Codes 0,1,2,3 for
those classes give encoder masks `0x10b0`,`0x40e0` and root mask
`0x4050f000` on [R,b,h,e0,e1]. It also has fourteen true original rows and
keeps R free, but these encoders have wider support than U/V. It establishes
four-class policy coverage, not a superior placement or timing result.

## Bounded generic implementation and acceptance

Current discovery extracts only two/three contiguous LUTs on report paths
(`comb_remap.cc:110`). It misses the four-node DAG N0,n,N1,N2 because n is a
parallel fanin. It also rejects more than six raw inputs before composition
(:179); `local_remap_cut_policy.h` stores at most three node values and a
64-row result. Raising only a pruning bound cannot solve either limitation.

Add a separate bounded, report-anchored backward DAG closure with at most
four LUTs and seven unique boundary variables. Preserve input aliases,
constants and actual PIN_INV states, topologically validate each internal
edge, and reject cycles/unsupported ports or protected boundaries. Enumerate
bounded cut alternatives rather than greedily absorbing every LUT fanin:
R and h are themselves LUT outputs but remain boundary signals here. A
reported three-node spine plus one off-path fanin is one generic way to
include n while retaining those boundaries. Represent 128 rows without shifts
of a 64-bit word by 64 or more. For each of the
`C(7,4)=35` four-input bound partitions, form sixteen eight-bit columns and
accept at most four distinct classes. Enumerate injective code assignments
(24 for either three or four classes), prune each encoder's essential inputs,
and validate every recomposed original row before graph mutation. Explicitly
represent constant/one-input results or reject unsupported LUT widths.
Keep candidate, site and STA budgets finite and deterministic; use actual
arrival/arc information to rank equivalent realizations, without semantic
cell-name or state assumptions.

Retain R,N0,n,N1,N2 cells, their Q identities, masks, BELs, pin states and all
side users. Add U,V,H cells/nets and change only T.C from N2.Q to H.Q;
N2's many direct FF ENA users remain untouched.
R.Q gains H.R as a tenth direct consumer: preserve all original nine indexed
user entries and allow exactly the declared new edge, rather than requiring
the final total to stay nine. The three new LUTs need joint
legal placement and physical pin assignment, not the existing one-clone site
loop. Check protected LABs, ALM pairing, occupied FF route-through resources
and every original neighbor; preserve every original FF placement. Snapshot
the selected sink port and every affected original boundary/output indexed
user store, including free-list state; remove all three clone cells/nets and
restore exact snapshots on failed probes/listing. Original-root relocation
is not part of this proposal.

Retain affected endpoint, boundary, all-clock and hold nonregression checks
and the existing >=250 ps modeled qualification threshold. Full routes must
then prove actual masks/polarities, all original side-user slots represented
by JSON, outside-cone full logical/physical pin states and BUF preservation,
plus strict comparisons with parent116 and earlier controls. JSON cannot
prove internal indexed-store slots/capacity: exact backend snapshots cover
that separately. A strictly validated guide must match the current graph;
a later accepted24 rewrite changes the old R cone, so a stale parent guide
cannot substitute for a fresh guide. Listing-only JSON supplies partial
topology/BEL evidence, not routed Boolean/pin/BUF or Fmax acceptance.

## Retained evidence

The following hashes were read independently; no helper/interpreter, test,
compiler, route or Quartus execution was performed for this note.

| Parent116 artifact | SHA256 |
| --- | --- |
| run.json | `b9777988d346a1352686feb7a129f9fe2822a1683f8d6dfdf76fa9fccf31d087` |
| routed.json | `f41c95937d9c17064ef4bf5af28a130c1d846fbfbaf3aa07f5430cd4f8ffd28b` |
| timing.json | `61f2985a5cdfd46f9f0ff0fcd023780ec9b8c1988b8ac1a69673f63884d78c86` |
| comparison.json | `10c026d58b655f9e96edf733be451cccfc84619525f8de145287cbb5b2fcb846` |
| route.log | `fc19a2b6074e9444a3c0b138663170d777d46382986cba75e2e4db735e201685` |

Parent source archive SHA256 is
`af50bb375a0753013a6ff35a1eb531ac3e18c8b4791f697c03f4c883f49211c9`;
frozen binary SHA256 is
`1fe6cb0c76902b476c2bf0e670df4a6a666c4e660cb7e53f115a8f7624eb7698`.
The preserved `twenty-four-reduction-264/frontier-followup.md` has SHA256
`e603af5121706d10853ca0c5ec2fc84cc74c03f01783bfd79d8f15f44a37997f`.
Only this new ignored `control-decomposition-264/design.md` was written.
