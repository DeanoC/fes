# Exact seven-input decomposition: first route rejected

Compiler 2d521858a686d68dc12c40cacf4e76459f07297b over ec3fc0156a60a3d3193142def03d992a875aaab0. Generic optional four-LUT fanin/seven-input exact decomposition; all 128 assignments are checked in the policy. Fixed BUILD_ID and parent116 profile.

| Full GPU1 run | Memory MHz | Pixel MHz | Phase MHz |
| --- | ---: | ---: | ---: |
| Retained parent | 116.171005 | 93.668045 | 378.582397 |
| Decomposition candidate 0 | 116.414436 | 92.395821 | 275.551514 |

Exit0,715.181995 seconds, no final reported hold violations. Reject this route: other clocks regress and a new encoder shares an ALM with one original LUT, changing its physical pin mapping. Independent evidence records all strict diagnostic gates false and no decomposition/retained-clone equivalence claim after that isolation failure. Both ordered PLL outputs/aliases/direct consumers are losslessly preserved. The exporter duplicates outclk keys; manifests/plans remain strict JSON.

Fresh listing: 16 qualified 917ps placement-model probes, no candidate applied; full helper confirms 71 identical placement metrics and partial original graph rollback evidence. Listing JSON cannot prove final physical pins or route-created BUFs; indexed slot/bucket preservation is tested in backend tests rather than inferred from JSON.

Acceptance regression reproduces cell/net iteration reversal and original ALM sharing on2d. Follow-up fddbdac2 fixes reverse-key owner reinsertion and excludes ALMs with original COMB/MCOMB/FF occupants, allowing new clones to share with each other. All25 focused tests pass, independent review clean; separate immutable measurement under ../control-decomposition-isolation-264.

Source/default/package selection and hardware remain unchanged. No RTL, recipe, ABI or hardware modification. No PR milestone reached by this result; 130MHz remains unresolved.

Listing comparison SHA256:2997148b00a8dd4c261b847611ff91e44e79edfa34f031b787d8af47ff40c48a.
Route comparison SHA256:afd4f9b00749f642b551ef6f6efa015cedd8cb6dae6ebd2a1b18d9b36ac49030.
Frozen helper SHA256:5b92392ac0daaa0e21c32ec9f12b1ec5c20c154755d7d9af56b80f9cf9a30862.
