"""Validate the frozen capture-locality experiment and record its tradeoff."""
import hashlib
import json
from pathlib import Path
import re
import tarfile

RAW = Path(__file__).resolve().parent
ROOT = RAW.parents[2]
BASE = RAW.parent / "route-slots-final"
FINAL = RAW / "route-b64-r24"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


record = read(FINAL / "run.json")
assert record["completed"] and record["exit_code"] == 0
assert record["final_reported_hold_violations"] is False
for filename, digest in record["input_sha256"].items():
    assert sha(Path(filename)) == digest, filename
assert sha(BASE / "timing.json") == record["capture_report_sha256"]
identity = read(RAW / "source-identity.json")
assert sha(RAW / "nextpnr-mistral") == identity["binary_sha256"]
with tarfile.open(RAW / "source.tar.gz") as archive:
    for filename, digest in identity["source_sha256"].items():
        assert hashlib.sha256(archive.extractfile(filename).read()).hexdigest() == digest, filename

baseline = read(BASE / "timing.json")
candidate = read(FINAL / "timing.json")
assert set(candidate["fmax"]) == set(baseline["fmax"])
clocks = {}
for clock, result in candidate["fmax"].items():
    old = baseline["fmax"][clock]
    assert old["constraint"] == result["constraint"]
    clocks[clock] = {"baseline_mhz": old["achieved"], "candidate_mhz": result["achieved"],
                     "constraint_mhz": result["constraint"],
                     "gain_mhz": result["achieved"] - old["achieved"],
                     "gain_percent": 100 * (result["achieved"] / old["achieved"] - 1)}
    if clock != "ram_clock.clocks[0]":
        assert result["achieved"] >= result["constraint"], clock
assert clocks["ram_clock.clocks[0]"]["gain_mhz"] > 0
pattern = re.compile(r"^(Info:.*at (?:initial placer iter|iteration #).*?)(?:; time = .*|$)", re.M)
old_metrics = pattern.findall((BASE / "route.log").read_text())
new_metrics = pattern.findall((FINAL / "route.log").read_text())
assert old_metrics == new_metrics and len(new_metrics) == 71
old_cells = read(BASE / "routed.json")["modules"]["top"]["cells"]
new_cells = read(FINAL / "routed.json")["modules"]["top"]["cells"]
common = set(old_cells) & set(new_cells)
changed = [name for name in sorted(common) if old_cells[name]["attributes"].get("NEXTPNR_BEL") !=
           new_cells[name]["attributes"].get("NEXTPNR_BEL")]
critical = next(p for p in candidate["critical_paths"]
                if p["from"] == p["to"] == "posedge ram_clock.clocks[0]")
summary = {
    "status": "experimental tradeoff; strict all-clock nonregression gate fails",
    "build_id": record["build_id"], "base_compiler_commit": identity["base_commit"],
    "fmax": clocks, "final_reported_hold_violations": False,
    "elapsed_seconds": record["elapsed_seconds"], "matched_placement_metrics": len(new_metrics),
    "common_cells": len(common), "changed_common_bels": changed,
    "added_cells": sorted(set(new_cells) - set(old_cells)),
    "removed_cells": sorted(set(old_cells) - set(new_cells)),
    "critical_memory_path": critical,
    "artifact_sha256": {str(p.relative_to(ROOT)): sha(p) for p in
                        (FINAL / "run.json", FINAL / "timing.json", FINAL / "core.rbf",
                         RAW / "source.tar.gz", RAW / "ctest.log")},
    "default_recipe_selected": False, "hardware_tested": False,
}
(RAW / "comparison.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k not in
                  ("critical_memory_path", "artifact_sha256", "changed_common_bels", "added_cells")}, indent=2))
