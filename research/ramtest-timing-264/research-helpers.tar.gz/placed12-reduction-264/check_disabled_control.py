"""Root-operated real JSON-loader control with all transforms disabled.

Compare modules against the sealed g8 disabled control, retaining and auditing
both occurrences of its known duplicate PLL outclk export. No old comparison
helper is replayed, and no pack/place/route/default/hardware acceptance follows.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import time

from freeze import HERE, ROOT, PARENT, MEASURED, sha, require, read, authenticate_freeze

MODULE = ROOT / "sources/misteross"
G8_HELPER = PARENT / "compare_control_decomposition.py"
G8_HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
FULL = PARENT / "route-c0/comparison.json"
FULL_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
CONTROL = PARENT / "disabled-control/comparison.json"
CONTROL_SHA = "7d7d890ebc7a76e3922b025bc76169913d97ca1a2a0ba5d811e5bd2333cdf0f1"
ACCEPTED = PARENT / "disabled-control/candidate.json"
ACCEPTED_SHA = "4d9333b4ce26872c6a77ff24b699e361b498b0c2cb7193dcaf87b5eedf5a0835"


def load_reference():
    require(sha(FULL) == FULL_SHA and sha(CONTROL) == CONTROL_SHA and sha(ACCEPTED) == ACCEPTED_SHA and
            sha(G8_HELPER) == G8_HELPER_SHA, "sealed measured/control/helper reference changed")
    full, old = read(FULL), read(CONTROL)
    require(full["graph_proof_available"] is True and full["final_metadata_stable_during_comparison"] is True and
            old["completed"] is True and type(old["exit_code"]) is int and old["exit_code"] == 0 and
            type(old["elapsed_seconds"]) in (int, float) and math.isfinite(old["elapsed_seconds"]) and
            old["compiler_commit"] == MEASURED and old["candidate_sha256"] == ACCEPTED_SHA,
            "cached g8 full/control proof is not finalized")
    inputs = {str(FULL): FULL_SHA, str(CONTROL): CONTROL_SHA, str(ACCEPTED): ACCEPTED_SHA, str(G8_HELPER): G8_HELPER_SHA}
    for filename, digest in full["artifact_sha256"].items():
        path = (ROOT / filename).resolve()
        require(path.is_relative_to(ROOT) and sha(path) == digest, "cached full artifact changed: " + filename)
        require(str(path) not in inputs or inputs[str(path)] == digest, "cached digest collision")
        inputs[str(path)] = digest
    require(full["artifact_sha256"].get(str(CONTROL.relative_to(ROOT))) == CONTROL_SHA and
            full["artifact_sha256"].get(str(ACCEPTED.relative_to(ROOT))) == ACCEPTED_SHA and
            full["artifact_sha256"].get(str(G8_HELPER.relative_to(ROOT))) == G8_HELPER_SHA,
            "full proof omits the disabled control or parser binding")
    for filename, digest in old["input_sha256"].items():
        path = Path(filename)
        require(sha(path) == digest and (str(path) not in inputs or inputs[str(path)] == digest),
                "cached disabled input changed: " + filename)
        inputs[str(path)] = digest
    spec = importlib.util.spec_from_file_location("sealed_placed12_g8_netlist_parser", G8_HELPER)
    g8 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g8)
    expected = g8.read_netlist(ACCEPTED)["modules"]
    modules_sha = hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    require(modules_sha == old["modules_sha256"], "cached normalized module digest changed")
    return g8, old, expected, modules_sha, inputs


def main():
    source_identity = authenticate_freeze()
    g8, old, expected, modules_sha, inputs = load_reference()
    for filename, digest in source_identity["input_sha256"].items():
        require(filename not in inputs or inputs[filename] == digest, "source/control input digest collision")
        inputs[filename] = digest
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    source = Path(old["command"][old["command"].index("--json")+1])
    selector = old["command"][old["command"].index("--balance-reduction-root")+1]
    binary, archive = HERE / "nextpnr-mistral", HERE / "source.tar.gz"
    output = HERE / "disabled-control"
    require(not output.exists(), "disabled control output already exists")
    inputs.update({str(path): sha(path) for path in (binary, archive, HERE / "source-identity.json", HERE / "change.patch",
                                                  HERE / "freeze.py", Path(__file__).resolve(), source)})
    require(all(sha(Path(path)) == digest for path, digest in inputs.items()), "control inputs changed before execution")
    output.mkdir()
    identity = f"base_commit={source_identity['base_commit']}; experimental_source_sha256={sha(archive)}; sha256={sha(binary)}"
    command = [str(binary), "--json", str(source), "--device", "5CSEBA6U23I7", "--no-pack", "--no-place",
               "--no-route", "--balance-reduction-root", selector, "--write", str(output / "candidate.json")]
    record = {"command": command, "cwd": str(MODULE), "tool_identity": identity,
              "base_compiler_commit": source_identity["base_commit"], "compiler_commit": source_identity["result_commit"],
              "measured_base_commit": MEASURED, "source_identity_sha256": sha(HERE / "source-identity.json"),
              "source_archive_sha256": sha(archive), "binary_sha256": sha(binary), "execution": None,
              "input_sha256": inputs, "completed": False, "kind": "host-only disabled-transform JSON-loader control",
              "reference_comparison_sha256": CONTROL_SHA, "reference_sha256": ACCEPTED_SHA,
              "cached_measured_full_proof_sha256": FULL_SHA, "cached_comparison_helpers_reexecuted": False,
              "all_transform_options_disabled": True,
              "root_selector_only_is_not_balance_reduction_enable": True,
              "default_recipe_selected": False, "hardware_tested": False,
              "proof_limitations": ["Exact modules and ordered duplicate PLL outputs are compared; creator/version metadata outside modules may differ.",
                                    "This no-pack/no-place/no-route control does not prove placed physical pins, timing, holds, RBF or hardware behavior."]}
    invocation, start = None, time.monotonic()
    try:
        invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, identity)}, 1)
        record["execution"] = invocation.inputs
        require(not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "disabled control has transform environment")
        with (output / "loader.log").open("x") as log:
            result = audited_run(command, source_root=MODULE, cwd=MODULE, env=invocation.env, stdout=log,
                                 stderr=subprocess.STDOUT, check=False, timeout=300)
        record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic()-start
        require(result.returncode == 0, "disabled loader failed")
        invocation.verify()
        log = (output / "loader.log").read_text()
        require("Info: Program finished normally." in log and not any(marker in log for marker in
                ("Running the GPU router", "Local remap", "Comb remap", "Decomposition", "Capture locality", "Placed reduction")),
                "disabled loader executed a transform or failed to complete")
        actual = g8.read_netlist(output / "candidate.json")["modules"]
        require(actual == expected, "disabled module dictionaries changed")
        audits = {}
        for name in expected:
            before, after = expected[name], actual[name]
            audits[name] = g8.pll_port_audit(g8.Netlist(before["cells"], before["netnames"]),
                                            g8.Netlist(after["cells"], after["netnames"]))
        record["modules_sha256"] = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        require(record["modules_sha256"] == modules_sha, "disabled normalized module digest changed")
        require(all(sha(Path(path)) == digest for path, digest in inputs.items()), "control inputs changed during execution")
        record.update({"completed": True, "modules_equivalent": True, "original_module_dictionaries_identical": True,
                       "lossless_pll_port_audit": audits, "ordered_duplicate_pll_exports_preserved": True,
                       "candidate_sha256": sha(output / "candidate.json"), "loader_log_sha256": sha(output / "loader.log"),
                       "output_sha256": {str(output / name): sha(output / name) for name in ("candidate.json", "loader.log")}})
        print(json.dumps({key: record[key] for key in ("completed", "modules_sha256", "candidate_sha256",
                                                     "ordered_duplicate_pll_exports_preserved")}), flush=True)
    except BaseException as error:
        record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic()-start
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        with (output / "comparison.json").open("x") as metadata:
            metadata.write(json.dumps(record, indent=2, sort_keys=True)+"\n")
        if invocation is not None:
            invocation.close()


if __name__ == "__main__":
    main()
