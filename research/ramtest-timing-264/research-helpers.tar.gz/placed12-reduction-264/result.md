The root-operated initial twelve-literal listing completed successfully in **576.579613 seconds**, but **none of its 16 timed trials qualified**. The best modeled branch and endpoint gain was **234 ps**, 16 ps below the unchanged 250 ps minimum; that trial passed the endpoint, clock and hold guards. No twelve-literal rewrite was applied. No AC listing, full route, final timing report, RBF or hardware test followed. **No new timing gain is accepted; the retained practical memory result remains 116.279067993 MHz.**

This host-only experiment extends generic three-cell, read-once literal-cube reductions to 7–12 literals with balanced ceil/floor leaves. It changes only the external Mistral compiler implementation, documentation and tests; no RTL or FES/module/shared contract changed. The source result is `8e305cb994d797a79a93a0cf2f30aaf9980d8642`, **unpushed at this handoff**, based on `91f3ad1bd8bbebd09e5a7ffb92e5026c5558e771`; the retained measured implementation is `6ad210a60991f93a607ac4490d6282b1267ec64a`. Root built both compiler/test targets, passed all **31 focused backend tests** in 128.435 seconds and the reduction-balance CLI suite in 155.61 seconds, and recorded a clean independent source/test review in [host-validation.json](validation/host-validation.json).

The fixed profile retained the original sixteen-literal balance, three local stages with groups **8/1/1**, legacy comb candidate 0, 60 capture moves from the 64/radius24 diagnostic, and the existing placed11 radius6/candidate0. It appended radius6/list-only selection−1 for `ddr0_test.group_valid_MISTRAL_ALUT6_E_F_MISTRAL_ALUT5_Q`; AC was explicitly absent. Device `5CSEBA6U23I7`, seed2, 74.25 MHz and heap weight10/exponent2 were unchanged. The sealed [profile.json](profile.json) binds all 181 inputs, guides, cached proof artifacts, command/environment/runtime inputs and new compiler/control identities. Cached old comparison helpers were not rerun; the new disabled-loader candidate matched the old candidate bytes exactly.

Root's [comparison.json](list-reduction/comparison.json) passed on its first invocation. The source is a read-once twelve-input NOR, checked over **4096 rows** using authenticated routed g8 logical pin states, with only row0 true. The actual current downstream closure has **five distinct Q nets and 227 FF ENA endpoints**, without cycles or reconvergence. All 71 initial placement metrics match the same-phase g8 listing. The restored export matches that listing byte-for-byte, including named graph/order, masks, BELs, FF connections, retained transforms and ordered duplicate PLL outputs.

This is partial listing evidence. The current export lacks actual logical/physical pin snapshots, so its 4096-row calculation is conditional on the authenticated reference states. It does not prove current final pin mappings, routed BUF preservation, clock/hold signoff, in-memory owner identities/indexed-user slots/free lists or physical timing gain. The comparison preserves the earlier strict timing flags and inherits no performance. `qualified_reduction_ordinals=[]`; later selected-reduction/AC/full phases need both a newly qualified ordinal and additional independent comparison support. Search and minimum-gain changes belong to a separate phase; this listing and its threshold remain frozen.

Exact SHA-256 bindings:

| Artifact | SHA-256 |
| --- | --- |
| [source-identity.json](source-identity.json) | `fd1afaff4d70ba48aa98420ddc6ffd92bd638e2099ee0a8df0e83faaf2558034` |
| [source.tar.gz](source.tar.gz) | `e173e234773f37de85d5e0645ffe83ef2bd5b1e7119b6368caa8226384621e80` |
| [nextpnr-mistral](nextpnr-mistral) | `a146cb930a368afeabe9398c503f134cf8bdabec57083a5ec968c2a4ebbaedb2` |
| [host-validation.json](validation/host-validation.json) | `9bb9a41c7b269b2236d7a66c3476e7c7ec09a385a68c264a7db2cc078695ad0c` |
| [profile.json](profile.json) | `96c45636536d315ab24d134cd37d09499fd9ef6cf1464aaceffa75d249dfcdec` |
| [local-plan.json](local-plan.json) | `bff7c813ba6409a6b71d1fcdc549d1499bf9934abb926b686d8ff3bbc056e407` |
| [freeze.py](freeze.py) | `f08a7a21f3a73c239043d73b4cd2d23b758fb42c72bfb29bcb13542c745adcb3` |
| [check_disabled_control.py](check_disabled_control.py) | `5dc29a74d80c505b5e0fb147428ae86ec04ad0cf91d94f331ac513337555d68e` |
| [seal_profile.py](seal_profile.py) | `1b38401a02341656d8e32e8d71f526bf7beccfba0fba463cb49ef875d73dd7ee` |
| [route.py](route.py) | `54a56508bed772979178705a94134fb48c363dc90ea9190a26d1a0f2f9c66c75` |
| [compare.py](compare.py) | `1823103ae0b5838b7559874f69b52b280d4efc484d40debb6345dc6fd80e3d92` |
| [comparison.json](list-reduction/comparison.json) | `b7c9b20a715ce9db056d07a3776e218c6bd18e2bb42c9fef5d360fcfb30e7ed5` |
| [run.json](list-reduction/run.json) | `88616661e1165d50bd929e6b94e42c94bda5109b7d7aea1cf6f88812e732d456` |
| [route.log](list-reduction/route.log) | `20d2b8882a333de0b609fa9957f024f61848b89d1dfce91cefd17278463fce2f` |
| [placed.json](list-reduction/placed.json) | `6cf02f36dd7e36afe06fe904a5e2f53225a1df162bc5d797571189447800860b` |
| Fixed synthesis JSON, `out/ramtest-merged-remap/measured-diagnostic/synth.json` | `61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28` |
| Fixed `sources/misteross/cores/fes-ramtest/constraints.qsf` | `8f97054248c681aca77fc26f55d6e91478164cc7726ec03034b4e459f1ea48d4` |
| Fixed `sources/misteross/boards/de10nano/clocks.sdc` | `3ba280ad420fee63a546a7c5cda15fc6c480de58cad398c67af2e62d1e296041` |
