"""Root-only sealed profile and shared authentication for placed12 qualification."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
G8 = RAW / "ready-g8-decomposition-264"
FULL, LIST = G8 / "route-c0", G8 / "list"
PROFILE, LOCAL_PLAN = HERE / "profile.json", HERE / "local-plan.json"
HELPER = G8 / "compare_control_decomposition.py"
HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
FULL_PROOF_SHA = "3fe9d625951ec8d9b9d8034e279d456f82804106761854cefca42a1495830e1e"
LIST_PROOF_SHA = "20b7f1dc20c5ef5d2bbb1fb789e2bb00d2d77b08afaff3c7b0d07a7c06d9976d"
REDUCTION_ROOT = "ddr0_test.group_valid_MISTRAL_ALUT6_E_F_MISTRAL_ALUT5_Q"
PHASES = ("list-reduction", "list-ac", "route")
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata value: " + value)
    return json.loads(path.read_text(), object_pairs_hook=pairs, parse_constant=nonfinite)


def module_at(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_helper():
    require(sha(HELPER) == HELPER_SHA, "frozen groups8 helper changed")
    return module_at(HELPER, "sealed_placed12_groups8_reference")


def authenticate_cached(folder, required=()):
    """Authenticate saved proof bytes and their closure, without recomputing proofs."""
    proof, record = read(folder / "comparison.json"), read(folder / "run.json")
    require(proof["final_metadata_stable_during_comparison"] is True and proof["candidate_completed"] is True and
            record["completed"] is True and type(record["exit_code"]) is int and record["exit_code"] == 0,
            "cached proof/run is not finalized")
    for filename, digest in proof["artifact_sha256"].items():
        path = (ROOT / filename).resolve()
        require(path.is_relative_to(ROOT) and sha(path) == digest, "cached artifact changed: " + filename)
    for path in (folder / "run.json", folder / "route.log", *required,
                 *(Path(path) for path in record["input_sha256"])):
        require(proof["artifact_sha256"].get(str(path.relative_to(ROOT))) == sha(path),
                "cached proof omits a required artifact/input")
    return record, proof


def authenticate_references(g8):
    require(sha(FULL / "comparison.json") == FULL_PROOF_SHA and sha(LIST / "comparison.json") == LIST_PROOF_SHA,
            "root-validated groups8 proof record changed")
    base, full = authenticate_cached(FULL, [FULL / name for name in ("routed.json", "timing.json", "core.rbf")])
    listed, listing = authenticate_cached(LIST, [LIST / "placed.json"])
    require(base["compiler_commit"] == listed["compiler_commit"] == g8.RESULT_COMMIT and
            base["list_only"] is False and listed["list_only"] is True and
            base["final_reported_hold_violations"] is False and full["graph_proof_available"] is True and
            full["actual_local_and_ac_selected_prefix_match_fresh_listing"] is True and
            full["local_clone_count"] == 3 and full["comb_clone_count"] == 1,
            "retained groups8+AC proof changed")
    require(listing["partial_graph_evidence_available"] is True and listing["graph_proof_available"] is False and
            listing["decomposition_selection"]["none_applied"] is True and
            listing["decomposition_selection"]["qualified_candidates"] > base["decomposition_selection"],
            "old fresh listing did not qualify its measured AC")
    require(sha(G8 / "route.py") == g8.SEALED_RUNNER and
            full["artifact_sha256"].get(str(HELPER.relative_to(ROOT))) == HELPER_SHA, "old helper/runner binding changed")
    plan_path = Path(base["command"][base["command"].index("--remap-plan") + 1])
    require(read(plan_path) == base["remap_plan"] and len(base["remap_plan"]["steps"]) == 3 and
            [step["groups"] for step in base["remap_plan"]["steps"]] == [8, 1, 1] and
            all(step["candidate"] == 0 and step["preserve_ff_placement"] is True and step["optimize_pins"] is False
                for step in base["remap_plan"]["steps"]), "retained three-stage plan changed")
    require(base["experimental_placed_reduction"].endswith(" 6 0") and
            base["experimental_capture_locality"].endswith(" 64 24"), "retained diagnostic parameters changed")
    return base, full, listing


def authenticate_new_source(g8, base):
    freezer = module_at(HERE / "freeze.py", "sealed_placed12_freeze")
    source = freezer.authenticate_freeze()
    require(source["measured_base_commit"] == base["compiler_commit"] and
            source["result_commit"] != base["compiler_commit"], "new compiler/measured lineage changed")
    control = read(HERE / "disabled-control/comparison.json")
    old_control = read(G8 / "disabled-control/comparison.json")
    require(control["completed"] is True and type(control["exit_code"]) is int and control["exit_code"] == 0 and
            control["compiler_commit"] == source["result_commit"] and
            control["base_compiler_commit"] == source["base_commit"] and
            control["measured_base_commit"] == base["compiler_commit"] and
            control["source_identity_sha256"] == sha(HERE / "source-identity.json") and
            control["binary_sha256"] == sha(HERE / "nextpnr-mistral") and
            control["modules_sha256"] == old_control["modules_sha256"], "new disabled loader control is not proved")
    require(control["modules_equivalent"] is True and control["original_module_dictionaries_identical"] is True and
            control["ordered_duplicate_pll_exports_preserved"] is True and
            control["all_transform_options_disabled"] is True and control["cached_comparison_helpers_reexecuted"] is False,
            "disabled control omits the exact loader/PLL proof")
    for filename, digest in control["input_sha256"].items():
        require(sha(Path(filename)) == digest, "disabled control input changed: " + filename)
    candidate = HERE / "disabled-control/candidate.json"
    require(sha(candidate) == control["candidate_sha256"], "disabled control export changed")
    require(control["output_sha256"] == {str(HERE / "disabled-control" / name): sha(HERE / "disabled-control" / name)
                                          for name in ("candidate.json", "loader.log")} and
            control["loader_log_sha256"] == sha(HERE / "disabled-control/loader.log"), "disabled output bytes changed")
    actual = g8.read_netlist(candidate)["modules"]
    expected = g8.read_netlist(G8 / "disabled-control/candidate.json")["modules"]
    require(actual == expected and hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            == control["modules_sha256"], "actual disabled module dictionaries differ")
    audits = {name: g8.pll_port_audit(g8.Netlist(expected[name]["cells"], expected[name]["netnames"]),
                                     g8.Netlist(actual[name]["cells"], actual[name]["netnames"])) for name in expected}
    require(control["lossless_pll_port_audit"] == json.loads(json.dumps(audits)),
            "ordered duplicate PLL audit differs from actual exports")
    binary, archive = HERE / "nextpnr-mistral", HERE / "source.tar.gz"
    require(control["command"][0] == str(binary) and control["source_archive_sha256"] == sha(archive) and
            control["input_sha256"].get(str(binary)) == sha(binary) and
            control["input_sha256"].get(str(archive)) == sha(archive), "disabled control uses another freeze")
    g8.ready.authenticate_execution(control, base)
    return source, control


def phase_folder(phase, reductionordinal, acordinal):
    require(phase in PHASES, "unknown phase")
    if phase == "list-reduction":
        require(reductionordinal == -1 and acordinal is None, "initial listing must select final reduction -1 only")
        return HERE / "list-reduction"
    require(type(reductionordinal) is int and 0 <= reductionordinal <= 2147483647, "invalid reduction candidate")
    if phase == "list-ac":
        require(acordinal == -1, "fresh AC listing must select -1")
        return HERE / f"list-ac-r{reductionordinal}"
    require(type(acordinal) is int and 0 <= acordinal <= 2147483647, "invalid fresh AC candidate")
    return HERE / f"route-reduction{reductionordinal}-ac{acordinal}"


def reduction_steps(base, phase, reductionordinal):
    old = base["experimental_placed_reduction"].split()
    require(len(old) == 3 and old[1:] == ["6", "0"], "retained placed11 stage changed")
    return [{"root": old[0], "radius": 6, "candidate": 0},
            {"root": REDUCTION_ROOT, "radius": 6,
             "candidate": -1 if phase == "list-reduction" else reductionordinal}]


def expected_diagnostic_environment(base, phase, reductionordinal):
    spec = "\n".join(f"{step['root']} {step['radius']} {step['candidate']}"
                     for step in reduction_steps(base, phase, reductionordinal))
    return {"NEXTPNR_MISTRAL_CAPTURE_LOCALITY": base["experimental_capture_locality"],
            "NEXTPNR_MISTRAL_PLACED_REDUCTION": spec}


def expected_command(base, phase, reductionordinal, acordinal):
    folder = phase_folder(phase, reductionordinal, acordinal)
    old, command, index = base["command"], [str(HERE / "nextpnr-mistral")], 1
    require("--gpu-opt" not in old and "--no-route" not in old, "old route has unexpected overrides")
    removed = {"--write", "--report", "--rbf", "--remap-decompose-critical", "--remap-decompose-candidate"}
    if phase != "route":
        removed |= {"--router", "--gpu-device"}
    while index < len(old):
        option = old[index]
        if option in removed:
            require(index + 1 < len(old), "missing old command value")
            index += 2
        elif option == "--compress-rbf" and phase != "route":
            index += 1
        elif option == "--remap-plan":
            command += [option, str(LOCAL_PLAN)]
            index += 2
        else:
            command.append(option)
            index += 1
    command += ["--write", str(folder / ("routed.json" if phase == "route" else "placed.json"))]
    if phase != "route":
        command += ["--no-route"]
    else:
        command += ["--report", str(folder / "timing.json"), "--rbf", str(folder / "core.rbf")]
    if phase != "list-reduction":
        guide = old[old.index("--remap-decompose-critical") + 1]
        command += ["--remap-decompose-critical", guide, "--remap-decompose-candidate", str(acordinal)]
    return command


def load_profile():
    profile = read(PROFILE)
    require(set(profile) == {"schema", "helper_sha256", "reference_full", "reference_listing", "base_plan",
                            "new_reduction", "source_identity_sha256", "disabled_control_sha256", "input_sha256"} and
            profile["schema"] == 1 and profile["helper_sha256"] == HELPER_SHA and
            profile["reference_full"] == str(FULL) and profile["reference_listing"] == str(LIST) and
            profile["new_reduction"] == {"root": REDUCTION_ROOT, "radius": 6}, "sealed placed12 profile changed")
    for filename, digest in profile["input_sha256"].items():
        require(sha(Path(filename)) == digest, "sealed input changed: " + filename)
    g8 = load_helper()
    base, full, listing = authenticate_references(g8)
    source, disabled = authenticate_new_source(g8, base)
    require(profile["base_plan"] == read(LOCAL_PLAN) == base["remap_plan"] and
            profile["source_identity_sha256"] == sha(HERE / "source-identity.json") and
            profile["disabled_control_sha256"] == sha(HERE / "disabled-control/comparison.json"), "profile aliases changed")
    return profile, g8, base, full, listing, source, disabled


def sealed_input_map(profile, phase, reductionordinal, acordinal):
    inputs = {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}
    dependencies = [] if phase == "list-reduction" else [HERE / "list-reduction"]
    if phase == "route":
        dependencies.append(HERE / f"list-ac-r{reductionordinal}")
    for previous in dependencies:
        record, proof = authenticate_cached(previous, [previous / "placed.json"])
        require(record["profile_sha256"] == sha(PROFILE) and record["list_only"] is True and
                proof["partial_graph_evidence_available"] is True and proof["graph_proof_available"] is False,
                "fresh listing prerequisite is not sealed")
        comparator = HERE / "compare.py"
        require(proof["artifact_sha256"].get(str(comparator.relative_to(ROOT))) == sha(comparator),
                "fresh qualification proof does not bind its final comparator")
        if previous.name == "list-reduction":
            ordinals, selected = proof["qualified_reduction_ordinals"], reductionordinal
            require(record["phase"] == "list-reduction", "wrong reduction listing prerequisite")
        else:
            ordinals, selected = proof["qualified_ac_ordinals"], acordinal
            require(record["phase"] == "list-ac" and record["reduction_selection"] == reductionordinal and
                    record["decomposition_selection"] == -1, "wrong AC listing prerequisite")
        require(type(ordinals) is list and all(type(ordinal) is int and 0 <= ordinal <= 2147483647 for ordinal in ordinals) and
                ordinals == sorted(set(ordinals)) and selected in ordinals, "selected ordinal is not freshly qualified")
        extra = {str(ROOT / path): digest for path, digest in proof["artifact_sha256"].items()}
        extra[str(previous / "comparison.json")] = sha(previous / "comparison.json")
        require(all(path not in inputs or inputs[path] == digest for path, digest in extra.items()), "input digest collision")
        inputs.update(extra)
    return inputs


def authenticate_phase(record):
    profile, g8, base, _, _, source, disabled = load_profile()
    phase, reduction, ac = record["phase"], record["reduction_selection"], record["decomposition_selection"]
    folder = phase_folder(phase, reduction, ac)
    diagnostics = expected_diagnostic_environment(base, phase, reduction)
    require(record["command"] == expected_command(base, phase, reduction, ac) and
            record["remap_plan"] == profile["base_plan"] and record["remap_plan_sha256"] == sha(LOCAL_PLAN) and
            record["placed_reduction_plan"] == reduction_steps(base, phase, reduction) and
            record["input_sha256"] == sealed_input_map(profile, phase, reduction, ac), "phase command/plan/inputs changed")
    require(record["diagnostic_environment"] == diagnostics and
            record["experimental_placed_reduction"] == diagnostics["NEXTPNR_MISTRAL_PLACED_REDUCTION"] and
            record["experimental_capture_locality"] == base["experimental_capture_locality"] and
            record["retained_comb_report_sha256"] == base["retained_comb_report_sha256"] and
            record["decomposition_report_sha256"] == (None if phase == "list-reduction" else base["decomposition_report_sha256"]),
            "retained-transform/diagnostic environment changed")
    identity = f"base_commit={source['base_commit']}; experimental_source_sha256={sha(HERE / 'source.tar.gz')}; sha256={sha(HERE / 'nextpnr-mistral')}"
    require(record["compiler_commit"] == source["result_commit"] and record["base_compiler_commit"] == source["base_commit"] and
            record["measured_compiler_commit"] == base["compiler_commit"] and record["compiler_bytes_unchanged"] is False and
            record["tool_identity"] == identity and record["source_archive_sha256"] == sha(HERE / "source.tar.gz") and
            record["source_identity_sha256"] == sha(HERE / "source-identity.json") and
            record["disabled_control_sha256"] == sha(HERE / "disabled-control/comparison.json"), "new compiler aliases changed")
    require(record["list_only"] is (phase != "route") and record["fresh_listing"] is (phase != "route") and
            record["profile_sha256"] == sha(PROFILE) and record["reference_run_sha256"] == sha(FULL / "run.json") and
            record["runner_sha256"] == sha(HERE / "route.py") and record["cwd"] == base["cwd"], "phase metadata changed")
    lineage = {} if phase == "list-reduction" else {"reduction_listing": str(HERE / "list-reduction")}
    if phase == "route":
        lineage["ac_listing"] = str(HERE / f"list-ac-r{reduction}")
    require(record["listing_lineage"] == lineage, "fresh listing lineage changed")
    g8.ready.authenticate_execution(record, base)
    steps = [{**step, "index": index, "report_path": Path(step["report"]), "report_json": g8.read(Path(step["report"])),
              "report_sha256": sha(Path(step["report"]))} for index, step in enumerate(record["remap_plan"]["steps"])]
    return {"phase": phase, "folder": folder, "local_plan_path": LOCAL_PLAN, "local_steps": steps,
            "reduction_steps": record["placed_reduction_plan"], "reduction_selection": reduction,
            "ac_selection": ac, "source": source, "disabled_control": disabled}


def seal():
    require(not PROFILE.exists() and not LOCAL_PLAN.exists(), "profile/plan already sealed")
    g8 = load_helper()
    base, full, listing = authenticate_references(g8)
    source, disabled = authenticate_new_source(g8, base)
    paths = {Path(path) for path in base["input_sha256"]}
    paths |= {ROOT / path for proof in (full, listing) for path in proof["artifact_sha256"]}
    paths |= {FULL / "comparison.json", LIST / "comparison.json"}
    paths |= {Path(path) for record in (source, disabled) for path in record["input_sha256"]}
    paths |= {HERE / name for name in ("seal_profile.py", "route.py", "freeze.py", "check_disabled_control.py",
                                     "nextpnr-mistral", "source.tar.gz", "source-identity.json", "change.patch",
                                     "disabled-control/comparison.json", "disabled-control/candidate.json", "disabled-control/loader.log")}
    paths |= {path for path in (HERE / "validation").rglob("*") if path.is_file()}
    # The independent comparator is bound by the first listing's proof and
    # then by later execution prerequisites; it is not an initial compiler input.
    with LOCAL_PLAN.open("x") as output:
        output.write(json.dumps(base["remap_plan"], indent=2, sort_keys=True) + "\n")
    paths.add(LOCAL_PLAN)
    digests = {str(path): sha(path) for path in sorted(paths)}
    profile = {"schema": 1, "helper_sha256": HELPER_SHA, "reference_full": str(FULL), "reference_listing": str(LIST),
               "base_plan": copy.deepcopy(base["remap_plan"]), "new_reduction": {"root": REDUCTION_ROOT, "radius": 6},
               "source_identity_sha256": sha(HERE / "source-identity.json"),
               "disabled_control_sha256": sha(HERE / "disabled-control/comparison.json"), "input_sha256": digests}
    require(all(sha(Path(path)) == digest for path, digest in digests.items()), "inputs changed during sealing")
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"profile": str(PROFILE), "sha256": sha(PROFILE), "inputs": len(digests)}, indent=2))


if __name__ == "__main__":
    seal()
