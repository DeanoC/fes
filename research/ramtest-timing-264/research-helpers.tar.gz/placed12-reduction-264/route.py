"""Root-only fresh placed12 listing, fresh AC qualification, or full HIP route."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
from seal_profile import (HERE, FULL, LOCAL_PLAN, PROFILE, PHASES, authenticate_phase, expected_command,
                          expected_diagnostic_environment, load_profile, phase_folder, reduction_steps,
                          require, sealed_input_map, sha)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=PHASES, required=True)
    parser.add_argument("--reduction-candidate", type=int)
    parser.add_argument("--ac-candidate", type=int)
    args = parser.parse_args()
    if args.phase == "list-reduction":
        require(args.reduction_candidate is None and args.ac_candidate is None, "initial listing takes no selected ordinal")
        reduction, ac = -1, None
    elif args.phase == "list-ac":
        require(args.reduction_candidate is not None and args.ac_candidate is None, "AC listing requires only a fresh reduction ordinal")
        reduction, ac = args.reduction_candidate, -1
    else:
        require(args.reduction_candidate is not None and args.ac_candidate is not None, "full route requires both fresh ordinals")
        reduction, ac = args.reduction_candidate, args.ac_candidate
    folder = phase_folder(args.phase, reduction, ac)
    require(not folder.exists(), "phase output already exists")
    profile, g8, base, _, _, source, _ = load_profile()
    inputs = sealed_input_map(profile, args.phase, reduction, ac)
    module, binary = Path(base["cwd"]), HERE / "nextpnr-mistral"
    sys.path.insert(0, str(module))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    from scripts.search_placer_qor import _score_report, has_failed_route_arc
    from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS
    identity = f"base_commit={source['base_commit']}; experimental_source_sha256={sha(HERE / 'source.tar.gz')}; sha256={sha(binary)}"
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, identity)}, 1)
    try:
        diagnostics = expected_diagnostic_environment(base, args.phase, reduction)
        require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env), "ambient compiler diagnostic environment")
        env = {**invocation.env, **diagnostics}
        record = {**base, "kind": "scratch placed12 qualification/full route; unselected", "phase": args.phase,
                  "reduction_selection": reduction, "decomposition_selection": ac,
                  "placed_reduction_plan": reduction_steps(base, args.phase, reduction),
                  "experimental_placed_reduction": diagnostics["NEXTPNR_MISTRAL_PLACED_REDUCTION"],
                  "diagnostic_environment": diagnostics, "command": expected_command(base, args.phase, reduction, ac),
                  "remap_plan_sha256": sha(LOCAL_PLAN), "runner_sha256": sha(HERE / "route.py"),
                  "profile_sha256": sha(PROFILE), "reference_run_sha256": sha(FULL / "run.json"),
                  "base_compiler_commit": source["base_commit"], "compiler_commit": source["result_commit"],
                  "measured_compiler_commit": base["compiler_commit"], "compiler_bytes_unchanged": False,
                  "source_archive_sha256": sha(HERE / "source.tar.gz"), "source_identity_sha256": sha(HERE / "source-identity.json"),
                  "disabled_control_sha256": sha(HERE / "disabled-control/comparison.json"), "tool_identity": identity,
                  "list_only": args.phase != "route", "fresh_listing": args.phase != "route", "execution": invocation.inputs,
                  "input_sha256": inputs, "completed": False,
                  "listing_lineage": {} if args.phase == "list-reduction" else {"reduction_listing": str(HERE / "list-reduction")}}
        if args.phase == "route":
            record["listing_lineage"]["ac_listing"] = str(HERE / f"list-ac-r{reduction}")
        if args.phase == "list-reduction":
            record["decomposition_report_sha256"] = None
        for key in ("exit_code", "elapsed_seconds", "fmax", "final_reported_hold_violations", "failure",
                    "exit_code_is_adapter_sentinel", "comparator_sha256", "listing_reused_from", "profile_run"):
            record.pop(key, None)
        authenticate_phase(record)
        folder.mkdir()
        manifest, started = folder / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True) + "\n")
        try:
            with (folder / "route.log").open("x") as log:
                result = audited_run(record["command"], source_root=module, cwd=module, env=env, stdout=log,
                                     stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            invocation.verify()
            for filename, digest in record["input_sha256"].items():
                require(sha(Path(filename)) == digest, "phase input changed: " + filename)
            log = (folder / "route.log").read_text()
            require(result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log),
                    "phase did not complete normally")
            if args.phase != "route":
                require((folder / "placed.json").exists() and "Running the GPU router" not in log and
                        not any((folder / name).exists() for name in ("core.rbf", "routed.json", "timing.json")), "listing started a route")
                if args.phase == "list-reduction":
                    require("Decomposition" not in log, "initial reduction listing ran AC")
            else:
                board._require_gpu_backend(log)
                require((folder / "core.rbf").stat().st_size > 0 and "Running signoff timing analysis..." in log,
                        "full RBF/signoff is absent")
                record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
                report = g8.read(folder / "timing.json")
                _score_report(report, REQUIRED_CLOCKS)
                require(set(report["fmax"]) == {name for name, _ in REQUIRED_CLOCKS}, "required clock set changed")
                record["fmax"] = report["fmax"]
            record["completed"] = True
            print(json.dumps({key: record[key] for key in ("phase", "elapsed_seconds", "completed", "fmax",
                              "final_reported_hold_violations") if key in record}, indent=2))
        except BaseException as error:
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
