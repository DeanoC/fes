"""Root-operated committed-source freeze for the generic 12-literal extension.

Only the exact six-file delta from the docs-only 91f baseline is archived.
All other implementation bytes remain the measured 6ad implementation.
The copied binary is supplied by the root's completed build; freezing does
not build, place, route, or select a default/package artifact.
"""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SRC = ROOT / "sources/misteross/build/toolchain-ramtest-timing/src/nextpnr"
BUILD = ROOT / "sources/misteross/build/toolchain-ramtest-timing/build/nextpnr"
PARENT = HERE.parent / "ready-g8-decomposition-264"
BASE = "91f3ad1bd8bbebd09e5a7ffb92e5026c5558e771"
MEASURED = "6ad210a60991f93a607ac4490d6282b1267ec64a"
RESULT = "8e305cb994d797a79a93a0cf2f30aaf9980d8642"
EXPECTED_BINARY_SHA = "a146cb930a368afeabe9398c503f134cf8bdabec57083a5ec968c2a4ebbaedb2"
BASE_DOCS = {"docs/mistral-reduction-balance.md", "docs/mistral-capture-locality.md", "docs/mistral-control-remapping.md"}
HOST_VALIDATION = HERE / "validation/host-validation.json"
CHANGED = {"mistral/reduction_balance_policy.h", "mistral/reduction_balance.cc", "mistral/reduction_balance.md",
           "mistral/placed_reduction.cc", "mistral/tests/local_remap.cc", "mistral/tests/placed_reduction.cc"}
PARENT_FILES = {"source-identity.json": "2cc4985c404ac5e2047a359df3682af51dabf033f95b3ff57adc46e9fe80d4ac",
                "source.tar.gz": "af9b2c05bc7e4fe513f7f879d06c51c94fb696d2bde23469400fc7d041eff209",
                "nextpnr-mistral": "ba39ad814af51c4a6af3ca1854fcd1dd992af350bb09741d5b6becfa2d7d4b18"}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata value: " + value)
    return json.loads(path.read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def git(*args, text=True):
    return subprocess.check_output(["git", *args], cwd=SRC, text=text)


def parent_source():
    for filename, digest in PARENT_FILES.items():
        require(sha(PARENT / filename) == digest, "frozen measured compiler changed: " + filename)
    parent = read(PARENT / "source-identity.json")
    require(parent["result_commit"] == MEASURED and parent["binary_sha256"] == PARENT_FILES["nextpnr-mistral"] and
            parent["source_archive_sha256"] == PARENT_FILES["source.tar.gz"], "measured source identity differs")
    with tarfile.open(PARENT / "source.tar.gz", "r:gz") as archive:
        members = archive.getmembers()
        require(len(members) == len(parent["source_sha256"]) and all(member.isfile() for member in members) and
                {member.name for member in members} == set(parent["source_sha256"]), "measured archive member set differs")
        for member in members:
            payload = archive.extractfile(member).read()
            require(hashlib.sha256(payload).hexdigest() == parent["source_sha256"][member.name],
                    "measured archived source bytes differ: " + member.name)
    return parent


def host_validation(source_hashes):
    validation = read(HOST_VALIDATION)
    require(validation["delta_base_commit"] == BASE and validation["result_commit"] == RESULT and
            validation["source_sha256"] == source_hashes and validation["binary_sha256"] == EXPECTED_BINARY_SHA and
            validation["build_passed"] is True and validation["build_performed_before_commit_with_identical_committed_file_bytes"] is True and
            set(validation["build_targets"]) == {"nextpnr-mistral", "nextpnr-mistral-test"} and
            validation["backend_tests"] == validation["backend_passed"] == 31 and validation["cli_suite_passed"] is True and
            validation["cli_suites"] == 1 and validation["diff_check"] == "pass" and
            type(validation["independent_review"]) is str and validation["independent_review"] and
            validation["default_recipe_selected"] is False and validation["hardware_tested"] is False and
            validation["timing_gain_proved"] is False,
            "root host validation does not bind the committed source, reviewed passing checks and validated binary")
    expected = {HOST_VALIDATION.parent / name for name in ("build.log", "backend.log", "cli.log", "cli-details.log", "test-inventory.log")}
    artifacts = {(ROOT / name).resolve(): digest for name, digest in validation["artifact_sha256"].items()}
    require(set(artifacts) == expected and all(path.is_relative_to(ROOT) and sha(path) == digest for path, digest in artifacts.items()),
            "host validation artifact closure differs")
    return validation, {str(HOST_VALIDATION): sha(HOST_VALIDATION), **{str(path): digest for path, digest in artifacts.items()}}


def authenticate_freeze():
    """Read-only frozen-file validation for the later disabled control/runner."""
    parent_source()
    source = read(HERE / "source-identity.json")
    require(source["measured_base_commit"] == MEASURED and source["base_commit"] == BASE and
            re.fullmatch(r"[0-9a-f]{40}", source["base_commit"]) and
            source["result_commit"] == RESULT and source["binary_sha256"] == EXPECTED_BINARY_SHA and
            set(source["source_sha256"]) == CHANGED and source["changed_files"] == sorted(CHANGED) and
            set(source["baseline_docs_only_changed_files"]) == BASE_DOCS and
            source["clean_committed_checkout_at_freeze"] is True and
            source["unchanged_6ad_implementation_except_declared_delta"] is True,
            "new source identity is not the declared committed six-file extension")
    require(sha(HERE / "nextpnr-mistral") == source["binary_sha256"] and
            sha(HERE / "source.tar.gz") == source["source_archive_sha256"] and
            sha(HERE / "change.patch") == source["change_patch_sha256"], "frozen binary/archive/patch changed")
    for filename, digest in source["input_sha256"].items():
        require(sha(Path(filename)) == digest, "freeze input changed: " + filename)
    _, host_inputs = host_validation(source["source_sha256"])
    require(source["host_validation_sha256"] == sha(HOST_VALIDATION) and
            all(source["input_sha256"].get(name) == digest for name, digest in host_inputs.items()),
            "freeze omits the root host validation closure")
    with tarfile.open(HERE / "source.tar.gz", "r:gz") as archive:
        members = archive.getmembers()
        require(len(members) == len(CHANGED) and all(member.isfile() for member in members) and
                {member.name for member in members} == CHANGED, "new source archive is not the exact six-file delta")
        for member in members:
            require(hashlib.sha256(archive.extractfile(member).read()).hexdigest() == source["source_sha256"][member.name],
                    "new source archive payload differs: " + member.name)
    return source


def freeze():
    parent = parent_source()
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "source-identity.json", "change.patch")),
            "freeze artifacts already exist")
    base, result = git("rev-parse", BASE + "^{commit}").strip(), git("rev-parse", "HEAD^{commit}").strip()
    require(base == BASE and result == RESULT, "new validated committed result is missing")
    subprocess.run(["git", "merge-base", "--is-ancestor", MEASURED, base], cwd=SRC, check=True)
    subprocess.run(["git", "merge-base", "--is-ancestor", base, result], cwd=SRC, check=True)
    require(not git("status", "--porcelain", "--untracked-files=all").strip(), "compiler checkout is not clean and committed")
    changed = set(git("diff", "--name-only", "--no-renames", base, result, "--").splitlines())
    require(changed == CHANGED, "committed delta differs from the exact six authorized files")
    docs = git("diff", "--name-only", "--no-renames", MEASURED, base, "--").splitlines()
    require(set(docs) == BASE_DOCS,
            "91f baseline changes implementation relative to measured 6ad")
    cumulative = set(git("diff", "--name-only", "--no-renames", MEASURED, result, "--").splitlines())
    require(cumulative <= CHANGED | set(docs), "implementation changes exceed the declared delta")
    preserved = {}
    for filename, digest in parent["source_sha256"].items():
        require(hashlib.sha256(git("show", f"{MEASURED}:{filename}", text=False)).hexdigest() == digest,
                "measured Git source disagrees with its frozen archive: " + filename)
        if filename not in CHANGED and not filename.endswith(".md"):
            payload = git("show", f"{result}:{filename}", text=False)
            require(hashlib.sha256(payload).hexdigest() == digest, "previous experimental implementation changed: " + filename)
            preserved[filename] = digest
    payloads = {name: git("show", f"{result}:{name}", text=False) for name in sorted(CHANGED)}
    payload_hashes = {name: hashlib.sha256(payload).hexdigest() for name, payload in payloads.items()}
    validation, host_inputs = host_validation(payload_hashes)
    require(all((SRC / name).is_file() and not (SRC / name).is_symlink() and (SRC / name).read_bytes() == payload
                for name, payload in payloads.items()), "working source differs from committed HEAD bytes")
    build_binary = BUILD / "nextpnr-mistral"
    require(build_binary.is_file() and not build_binary.is_symlink(), "root-built binary is unavailable")
    build_sha = sha(build_binary)
    require(build_sha == validation["binary_sha256"] == EXPECTED_BINARY_SHA and
            sha(BUILD / "nextpnr-mistral-test") == validation["test_binary_sha256"],
            "producer binaries differ from the passing root host validation")
    frozen_inputs = {str(PARENT / filename): digest for filename, digest in PARENT_FILES.items()}
    frozen_inputs[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
    frozen_inputs.update(host_inputs)
    shutil.copy2(build_binary, HERE / "nextpnr-mistral")
    require(sha(HERE / "nextpnr-mistral") == build_sha == sha(build_binary), "producer binary changed while copying")
    timestamp = int(git("show", "-s", "--format=%ct", result).strip())
    with tarfile.open(HERE / "source.tar.gz", "w:gz") as archive:
        for name, payload in payloads.items():
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = len(payload), 0o644, timestamp
            archive.addfile(member, io.BytesIO(payload))
    patch = git("diff", "--binary", "--no-ext-diff", "--no-textconv", base, result, "--", text=False)
    with (HERE / "change.patch").open("xb") as output:
        output.write(patch)
    require(git("rev-parse", "HEAD^{commit}").strip() == result and
            not git("status", "--porcelain", "--untracked-files=all").strip(), "checkout changed while freezing")
    require(all(sha(Path(path)) == digest for path, digest in frozen_inputs.items()), "measured inputs changed while freezing")
    record = {"base_commit": base, "delta_base_commit": base, "measured_base_commit": MEASURED, "result_commit": result,
              "source_tree_git_id": git("rev-parse", result + "^{tree}").strip(), "changed_files": sorted(CHANGED),
              "source_sha256": payload_hashes,
              "binary_sha256": build_sha, "source_archive_sha256": sha(HERE / "source.tar.gz"),
              "change_patch_sha256": sha(HERE / "change.patch"), "input_sha256": frozen_inputs,
              "host_validation_sha256": sha(HOST_VALIDATION), "host_validation_path": str(HOST_VALIDATION),
              "validated_test_binary_sha256": validation["test_binary_sha256"],
              "preserved_measured_implementation_sha256": preserved, "baseline_docs_only_changed_files": docs,
              "clean_committed_checkout_at_freeze": True, "unchanged_6ad_implementation_except_declared_delta": True,
              "archive_scope": "Exact six changed files read from committed HEAD; remaining source is bound by the base/result Git commits and validated diff scope.",
              "producer_binary_path": str(build_binary), "branch": git("branch", "--show-current").strip(),
              "status": "committed generic 12-literal placed reduction experiment; no default/package/hardware selection"}
    with (HERE / "source-identity.json").open("x") as output:
        output.write(json.dumps(record, indent=2, sort_keys=True)+"\n")
    authenticate_freeze()
    print(json.dumps(record, indent=2), flush=True)


if __name__ == "__main__":
    freeze()
