# Late DDR0 errors predicted experiment

ROOT alone prepares and executes this new recorder after whole-file, hash, AST
and independent peer review. Preparation requires explicit self/scope,
completed current-control run/proof, guide and derivation SHA arguments. The
actual prepared profile SHA activates execution. Profile, post-plan and baseline
outputs are exclusive; failures retain partial outputs and the real compiler exit
or an explicitly labelled adapter sentinel. No frozen earlier file is changed.

Current b3d03654, ELF0c880559, archive338f71f6 and host3751b2eb are bound to their
own committed nine-file source/build/dependency closure and current checks
(25 plan and10 driver native cases;24 plan and10 driver CLI cases). Their clean
source, selected child/model repositories and all absolute artifacts/dependencies
are checked before and after preparation/execution. No old host qualification is
used for the new compiler. Historical closures remain immutable byte evidence.

The immediate prerequisite is the independently positive disabled-post-plan
ten-stage control, profile2294abbb. Its actual run/proof pins are required rather
than guessed. The prerequisite must prove complete raw native and predicted
report reproduction, all ten complete models and71 placement metric rows. Its
flat closure, actual outputs and exact current execution frame are rehashed
directly. Prior authenticators, generators, comparisons and entrypoints are never
invoked. Only the pinned current control's loader and pure ten-stage log parser
are called; its prepare/execute/host/source validation functions are not called.

The early --remap-plan pathname,00bf bytes and ten descriptors remain literal.
A separate post-plan contains one step0: the immutable errors guide, candidate0,
groups1, optimize_pins=false and preserve_ff_placement=true. The combined request
is11, within the existing16-step bound. The command adds --remap-post-plan and
swaps only the write/report outputs; compiler, controlled PATH, seed, constraints,
device, all reduction/comb/decomposition settings, diagnostic environment and
every runtime file remain those of the new completed control. There is no driver
pass, routing, analogue signoff or RBF in this predicted experiment.

The guidea9813f90/derivation3af38679 preserves the original current10 full path
object at index2975 to errors FF11.ENA, including clocks, windows, native edge
names, segment delays and all other report metadata. Current10 cd8ad7ff/1a6d4f7b
is positive native/physical construction with rejected116.809 MHz timing. The
accepted fifth6dcf8c4b and117.771759 MHz threshold remain separate. Neither the
guide nor this recorder qualifies a routed gain. The failed early errors attempt
e0354da3/logf1420b54 is bound as rejected provenance only; its command, graph and
failure cannot qualify the current control or new stage.

Preparation derives the actual current post-decomposition native errors cone:
inner ALUT2 mask0xd/Q4973 with161 users (160 status ENAs plus outerE), outer ALUT5
mask0x7fff0000/Q4300 with32 ENAs, six literal leaves
[4242,15932,4969,4970,4971,4972]. The guide's existing64-row composition is
0x0ddddddddddddddd. The unused paired cell/Q namespace is checked. The exact
whole LAB33.14 cohort has eight original errors FF ENAs on CLK3549; the remaining
24 root users and all inner users are predeclared obligations for a later graph
proof. All ten existing copies/cohorts remain fully recorded, together with all
8221 original FF BELs and complete FF records in the known cone/copy/cohort LABs.
The selected new BEL, Q, neighboring FF records and complete original graph
preservation require the later bounded prefix proof; they are not guessed here.

The log is split before its sole 'Local-remap post-plan step0' header. All ten
early complete trial dictionaries must remain exact. The late step must follow
both placed reductions and decomposition, and independently bind its sole
candidate0/application to the final preceding actual trial: eight ENAs in
LAB33.14, one selected group, zero FF shift, at least250 ps predicted gain, and
all compiled clock/hold/boundary guards true. Rejected prior probes are retained.
The post step has index0 explicitly, while combined logical model index10 is a
recording convention. Compiled guards are not independent numerical STA.

The complete predicted report must actually contain15290 paths under cap16384
with finite positive Fmax/constraints. The recorder captures actual outputs and
final original-path/runtime hashes. It does not prove whole native equivalence,
Boolean or physical truth of a new copy, exported pin/bank sharing, unexported
LAB caches, full current native endpoint topology, independent STA, calibration,
RBF decoding, hardware behavior or accepted gain. Those remain separate gates.
