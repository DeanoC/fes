"""Inspect a closed late errors remap against the fresh same-compiler ten-stage control."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
CONTROL = RAW / "post-remap-plan-ten-control-264"
CONTROL_PROFILE_SHA = "2294abbbadb2d74df4657344f841a2dcbaaf57854e33d7484a5e3e7841f9ab06"
CONTROL_RUNNER_SHA = "90c284ac6af56d19b07fb807fac4809aca4924378f46259b42665cad81002ecd"
CONTROL_SCOPE_SHA = "316fae0e22ed5f1b65fb1a0d8854cd9f2f98f25965c28fa67e583220e6b27e52"
CONTROL_COMPARE_SHA = "a03142215d8b205931d877af26dce1af5ed54854bfd8fc388553340dadad4c85"
CONTROL_COMPARE_SCOPE_SHA = "bdd231b06c1a8b6e74d729194a2058e1d70f23dac38b84072ef5197bab571e6b"
COMMIT, BASE = "b3d036549c29a333e67c61bd1b23e705bce75d41", "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
HOST = RAW / "post-remap-plan-264/validation/host-validation.json"
HOST_SHA = "3751b2ebc0c0f802ac2b4251150a693764487939c0b08e42fe100c2047eb6fe0"
BINARY_SHA = "0c8805598c4e59ad77683956cdc1739b8d2ed183c73eab51c85c9b7a52ea18ad"
ARCHIVE_SHA = "338f71f67188fa29dbb9f6fa616f6d33f4bc926b3acd00bfb5122ef543a8c2fb"
OLD_PLAN = RAW / "local-plan16-ready1-command-stage-264/local-plan.json"
OLD_PLAN_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
GUIDES = RAW / "local-plan16-ddr0-errors-ena-guide-264"
GUIDE_SHA = "a9813f9039aed67ebced9a3c4cdb2536f796f33d5a8c65b825116b442c1d612d"
DERIVATION_SHA = "3af3867921fe3fc1f3f1933debab88c717845c53e4c1df6f7df12521ecd4c7b5"
GUIDE_HELPER_SHA = "640bb5755d7edf56f2f04bc7b6662c664d809a221da916854fb950d4f277f92e"
GUIDE_SCOPE_SHA = "6310761b4b3d7ceb6eb5879a94616d99205a189768375f54b49edf2ab2559f29"
EXPERIMENT = RAW / "local-plan16-ready1-command-route-proof-264/comparison-v2.json"
EXPERIMENT_SHA = "cd8ad7ff8fd40b7136ff265d645806e3d661cde186b3da819975658040b8f74a"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
LAWS, LAWS_SHA = RAW / "local-multicopy-ready1-264/compare_prefix.py", "0a52299ec2c2547dd24407bbad78caa904093ee0514c0c28ea6eda04e1e44744"
GRAPH, GRAPH_SHA = RAW / "local-plan16-ddr0-errors-ena-stage-264/compare_prefix.py", "1d306fd1b309bca5b12b7498d39e4e878bbf376da0a70f2d09eac354e035d721"
GRAPH_SCOPE, GRAPH_SCOPE_SHA = GRAPH.parent / "prefix-scope.md", "2f383cec76b0123a32cb04173fc608f756c9b387cffdaf7a7f90d1d4a6af86c3"
TARGET = "ddr0_errors_MISTRAL_FF_Q_11"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def adopt(audit, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution entry is not absolute")
        audit.bind(Path(name), expected, execution=True)


def comparison(args):
    native = load(NATIVE, NATIVE_SHA, "post_errors_prefix_native_pure")
    audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), args.self_sha256), (HERE / "prefix-scope.md", args.scope_sha256),
            (HERE / "run_baseline.py", args.runner_sha256), (HERE / "scope.md", args.runner_scope_sha256),
            (HERE / "source-identity.json", args.profile_sha256), (HERE / "baseline/run.json", args.run_sha256),
            (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA), (CONTROL / "baseline/run.json", args.control_run_sha256),
            (CONTROL / "baseline/comparison-control.json", args.control_proof_sha256), (CONTROL / "run_baseline.py", CONTROL_RUNNER_SHA),
            (CONTROL / "scope.md", CONTROL_SCOPE_SHA), (CONTROL / "compare_control.py", CONTROL_COMPARE_SHA),
            (CONTROL / "comparison-scope.md", CONTROL_COMPARE_SCOPE_SHA), (HOST, HOST_SHA), (OLD_PLAN, OLD_PLAN_SHA),
            (GUIDES / "errors-ena-guide.json", GUIDE_SHA), (GUIDES / "derivation.json", DERIVATION_SHA),
            (GUIDES / "derive_guide.py", GUIDE_HELPER_SHA), (GUIDES / "scope.md", GUIDE_SCOPE_SHA), (EXPERIMENT, EXPERIMENT_SHA),
            (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (LAWS, LAWS_SHA), (GRAPH, GRAPH_SHA), (GRAPH_SCOPE, GRAPH_SCOPE_SHA)):
        audit.bind(path, expected)
    runner = load(HERE / "run_baseline.py", args.runner_sha256, "post_errors_prefix_runner_pure")
    control_runner = load(CONTROL / "run_baseline.py", CONTROL_RUNNER_SHA, "post_errors_prefix_control_pure")
    profile, record, original, previous, proof, host, derived, experiment = (native.read(path) for path in
        (HERE / "source-identity.json", HERE / "baseline/run.json", CONTROL / "source-identity.json", CONTROL / "baseline/run.json",
         CONTROL / "baseline/comparison-control.json", HOST, GUIDES / "derivation.json", EXPERIMENT))
    control_runner.validate_host(host)
    for manifest in (proof, derived, experiment):
        adopt(audit, manifest)
    for ledger in (profile["input_sha256"], original["input_sha256"], previous["output_sha256"], *(host[key] for key in control_runner.HOST_MAPS)):
        for name, expected in ledger.items():
            require(Path(name).is_absolute(), "profile/host/control input is not absolute")
            audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    require(proof["phase"] == "post-remap-plan-disabled-ten-stage-native-control" and proof["compiler_commit"] == COMMIT and
            proof["delta_base_commit"] == BASE and proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and
            proof["current_baseline_run_sha256"] == args.control_run_sha256 and proof["generator_sha256"] == CONTROL_COMPARE_SHA and
            proof["scope_sha256"] == CONTROL_COMPARE_SCOPE_SHA and proof["recorder_sha256"] == CONTROL_RUNNER_SHA and
            proof["recorder_scope_sha256"] == CONTROL_SCOPE_SHA and proof["host_validation_sha256"] == HOST_SHA and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and
            all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
                "all_71_placement_metrics_exact", "complete_predicted_report_exact", "fresh_post_plan_control_prerequisite_proved",
                "final_original_path_metadata_and_runtime_hashes_stable")), "fresh disabled-post control is not a closed positive prerequisite")
    require(previous["completed"] is True and previous["exit_code"] == 0 and previous["compiler_read_audit_passed"] is True and
            previous["final_original_input_output_runtime_hashes_stable"] is True and previous["source_identity_sha256"] == CONTROL_PROFILE_SHA and
            all(native.canonical(previous[key]) == native.canonical(value) for key, value in original.items() if key != "input_sha256") and
            previous["input_sha256"] == {**original["input_sha256"], str(CONTROL / "source-identity.json"): CONTROL_PROFILE_SHA} and
            previous["actual_selected_local_qualification"] == proof["fresh_local_models"] and len(proof["fresh_local_models"]) == 10,
            "fresh control completed record/profile/model union differs")
    require(profile["phase"] == "post-remap-plan-ddr0-errors-late-single-stage-predicted-baseline" and
            profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and
            profile["source_archive_sha256"] == ARCHIVE_SHA and profile["host_validation_sha256"] == HOST_SHA and
            profile["helper_sha256"] == args.runner_sha256 and profile["scope_sha256"] == args.runner_scope_sha256 and
            profile["control_profile_sha256"] == CONTROL_PROFILE_SHA and profile["control_run_sha256"] == args.control_run_sha256 and
            profile["control_proof_sha256"] == args.control_proof_sha256 and profile["guide_sha256"] == GUIDE_SHA and
            profile["guide_derivation_sha256"] == DERIVATION_SHA and profile["experimental_current_full_proof_sha256"] == EXPERIMENT_SHA and
            profile["accepted_current_full_proof_sha256"] == ACCEPTED_SHA and profile["minimum_accepted_memory_mhz"] == 117.77175903320312,
            "current compiler/control/guide/accepted-reference roles differ")
    require(derived["phase"] == "local-plan16-ddr0-errors-ena-exact-current-path-guide" and derived["generator_sha256"] == GUIDE_HELPER_SHA and
            derived["scope_sha256"] == GUIDE_SCOPE_SHA and derived["guide_sha256"] == GUIDE_SHA and
            derived["experimental_full_proof_sha256"] == EXPERIMENT_SHA and derived["accepted_reference_full_proof_sha256"] == ACCEPTED_SHA and
            derived["source_tenth_experiment_timing_gain_accepted"] is False and derived["selected_endpoint"] == TARGET and
            derived["selected_lab"] == [33, 14] and derived["selected_path_source_indices"] == [2975] and
            derived["existing_function_assignments_checked"] == 64 and derived["root_q"] == 4300 and derived["root_consumer_count"] == 32 and
            derived["inner_q"] == 4973 and derived["six_literal_leaves_in_composed_pin_order"] == [4242, 15932, 4969, 4970, 4971, 4972] and
            derived["existing_composed_mask_hex"] == "0x0ddddddddddddddd" and experiment["native_graph_proof_available"] is True and
            experiment["physical_scope_proved"] is True and experiment["structural_rejection"] is None and
            experiment["routed_gain_accepted_under_confirmed_target_clock_rule"] is False,
            "current guide construction is not the bound native/physical-positive timing-rejected source")
    for key, value in profile.items():
        if key != "input_sha256":
            require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
            record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == args.profile_sha256 and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(HERE / "source-identity.json"): args.profile_sha256} and
            record["command"] == runner.command(previous) and record["execution"] == profile["baseline_execution"] == previous["execution"] and
            record["cwd"] == previous["cwd"] and record["diagnostic_environment"] == previous["diagnostic_environment"] and
            record["original_ten_complete_trial_models_exact"] is True, "completed late-stage runtime/input union differs")
    for runtime in (previous["execution"], record["execution"]):
        for name, expected in runtime["files"].items():
            require(profile["input_sha256"].get(name) == expected, "actual runtime outside frozen closure")
            audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(HERE / "baseline" / name) for name in ("phase.log", "placed.json", "timing.json")}, "complete predicted output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual predicted output empty")
        audit.bind(Path(name), expected)
    expected_post = {"report": str(GUIDES / "errors-ena-guide.json"), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True}
    require(profile["local_plan_steps"] == original["local_plan_steps"] and len(profile["local_plan_steps"]) == 10 and
            profile["original_ten_plan_path"] == str(OLD_PLAN) and profile["original_ten_plan_sha256"] == OLD_PLAN_SHA and
            profile["post_plan_steps"] == [expected_post] and profile["combined_requested_step_count"] == 11 and
            profile["post_plan_path"] == str(HERE / "post-plan.json") and
            audit.paths.get(Path(profile["post_plan_path"])) == profile["post_plan_sha256"] and
            native.read(profile["post_plan_path"]) == {"steps": [expected_post]}, "literal ten early descriptors and sole late descriptor differ")
    definitions = runner.definitions()
    parser_helpers = ((HERE / "run_baseline.py", args.runner_sha256), (CONTROL / "run_baseline.py", CONTROL_RUNNER_SHA), *control_runner.PARSERS)
    called_helpers = {str(path): expected for path, expected in ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA),
        (FREEZE, FREEZE_SHA), (LAWS, LAWS_SHA), (GRAPH, GRAPH_SHA), *parser_helpers)}
    for path, expected in parser_helpers:
        require(profile["input_sha256"].get(str(path)) == expected, "called parser is outside the frozen input closure")
        audit.bind(path, expected)
    early_models, post_models = runner.qualification((HERE / "baseline/phase.log").read_text(), definitions)
    models = early_models + post_models
    require(len(early_models) == 10 and len(post_models) == 1 and
            native.canonical(early_models) == native.canonical(previous["actual_selected_local_qualification"]) == native.canonical(profile["retained_local_models"]) ==
            native.canonical(record["actual_early_selected_local_qualification"]) and
            native.canonical(post_models) == native.canonical(record["actual_post_selected_local_qualification"]) and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
            post_models[0]["post_step_index"] == 0 and post_models[0]["plan_kind"] == "post",
            "fresh ten early models and independently qualified late index0 binding differ")
    frozen = load(FREEZE, FREEZE_SHA, "post_errors_prefix_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "post_errors_prefix_tables_topology_pure", frozen)
    laws = load(LAWS, LAWS_SHA, "post_errors_prefix_scalar_lut_lab_pure")
    graph = load(GRAPH, GRAPH_SHA, "post_errors_prefix_graph_definitions_only")
    before, after = native.read_netlist(CONTROL / "baseline/placed.json"), native.read_netlist(HERE / "baseline/placed.json")
    report, old_report = native.read(HERE / "baseline/timing.json"), native.read(CONTROL / "baseline/timing.json")
    log, old_log = (HERE / "baseline/phase.log").read_text(), (CONTROL / "baseline/phase.log").read_text()
    metrics = len(native.PLACEMENT_METRICS.findall(log)) == 71 and native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall(old_log)
    evidence, rejection, topology, topology_rejection = None, None, None, None
    try:
        require(metrics, "all71 original placement metrics are not exact")
        evidence = graph.prove(native, selected, laws, before, after, profile, models)
    except (ValueError, TypeError, KeyError, IndexError, AttributeError, StopIteration) as error:
        rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    try:
        topology = selected.report_topology(after, report, old_report)
        require(topology["current_report_paths"] == 15290 and len(topology["domain_pair_endpoint_counts"]) == 7 and
                report["timing_report_paths"] == 16384 and report["fmax"] == record["actual_predicted_fmax"], "current native report count/pairs/cap/Fmax differs")
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error:
        topology_rejection = {"exception_type": type(error).__name__, "reason": str(error)}
    require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Info: Local-remap post-plan step 0:") == 1 and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy")),
            "actual late errors phase is not one post stage in a predicted-only run")
    audit.finish()
    positive = rejection is None and topology_rejection is None
    return {"schema": 1, "phase": "post-remap-plan-ddr0-errors-ena-eleventh-stage-strict-native-prefix", "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "source_identity_sha256": args.profile_sha256, "current_baseline_run_sha256": args.run_sha256,
        "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": args.control_run_sha256, "control_proof_sha256": args.control_proof_sha256,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256, "runner_sha256": args.runner_sha256, "runner_scope_sha256": args.runner_scope_sha256,
        "guide_sha256": GUIDE_SHA, "guide_derivation_sha256": DERIVATION_SHA, "candidate_completed": True,
        "structural_rejection": rejection, "native_path_topology_rejection": topology_rejection, "native_graph_proof_available": rejection is None,
        "fresh_driver_guide_available_after_conditional_prefix_proof": positive, "native_graph_evidence": evidence,
        "fresh_local_models": models, "fresh_early_local_models": early_models, "fresh_post_local_models": post_models,
        "previous_local_models": previous["actual_selected_local_qualification"], "all_ten_retained_complete_trial_models_exact": True,
        "all_71_placement_metrics_exact": metrics, "current_complete_native_report_topology": topology, "actual_predicted_fmax": report["fmax"],
        "complete_predicted_report_exact": native.canonical(report) == native.canonical(old_report), "complete_predicted_report_exact_required": False,
        "experimental_current_full_proof_sha256": EXPERIMENT_SHA, "accepted_current_full_proof_sha256": ACCEPTED_SHA,
        "minimum_accepted_memory_mhz": 117.77175903320312, "conditional_plain_sig_equivalence_only": True,
        "private_output_alignment_or_global_normalization_used": False, "failed_early_errors_attempt_used_as_positive_source": False,
        "physical_pin_lab_cache_gpu_or_sta_acceptance_inherited": False, "routed_gain_accepted": False, "hardware_tested": False,
        "pure_function_helper_sha256": dict(sorted(called_helpers.items())),
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "runner-sha256", "runner-scope-sha256", "profile-sha256", "run-sha256", "control-run-sha256", "control-proof-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual closed SHA activation pins required")
    output = HERE / "baseline/comparison-prefix.json"
    require(not output.exists(), "exclusive late errors prefix already exists")
    result = comparison(args)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_path_topology_rejection", "native_graph_proof_available")}))


if __name__ == "__main__":
    main()
