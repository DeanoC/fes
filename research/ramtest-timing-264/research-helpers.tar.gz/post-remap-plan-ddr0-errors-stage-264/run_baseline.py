"""Record a fresh late DDR0 errors remap after the reproduced ten-stage prefix."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
CONTROL = RAW / "post-remap-plan-ten-control-264"
CONTROL_PROFILE_SHA = "2294abbbadb2d74df4657344f841a2dcbaaf57854e33d7484a5e3e7841f9ab06"
CONTROL_HELPER_SHA = "90c284ac6af56d19b07fb807fac4809aca4924378f46259b42665cad81002ecd"
CONTROL_SCOPE_SHA = "316fae0e22ed5f1b65fb1a0d8854cd9f2f98f25965c28fa67e583220e6b27e52"
CONTROL_COMPARE_SHA = "a03142215d8b205931d877af26dce1af5ed54854bfd8fc388553340dadad4c85"
CONTROL_COMPARE_SCOPE_SHA = "bdd231b06c1a8b6e74d729194a2058e1d70f23dac38b84072ef5197bab571e6b"
COMPILER = RAW / "post-remap-plan-264"
SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-post-remap-plan-264"
COMMIT, BASE = "b3d036549c29a333e67c61bd1b23e705bce75d41", "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
BINARY, ARCHIVE = COMPILER / "nextpnr-mistral", COMPILER / "source.tar.gz"
BINARY_SHA = "0c8805598c4e59ad77683956cdc1739b8d2ed183c73eab51c85c9b7a52ea18ad"
ARCHIVE_SHA = "338f71f67188fa29dbb9f6fa616f6d33f4bc926b3acd00bfb5122ef543a8c2fb"
HOST, HOST_SHA = COMPILER / "validation/host-validation.json", "3751b2ebc0c0f802ac2b4251150a693764487939c0b08e42fe100c2047eb6fe0"
HOST_HELPER_SHA = "bb805c58ea34c224902be3748595a94bdb02ebf8ea5fc2d4dfd7c69b74b37989"
HOST_SCOPE_SHA = "0a20383eea87e07e16c2b1e71c509522e1757462b939a508153080e0f1135eda"
OLD = RAW / "local-plan16-ready1-command-stage-264"
EARLY_PLAN, EARLY_PLAN_SHA = OLD / "local-plan.json", "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
FULL = RAW / "local-plan16-ready1-command-route-264"
FULL_PROOF = RAW / "local-plan16-ready1-command-route-proof-264/comparison-v2.json"
FULL_PROOF_SHA = "cd8ad7ff8fd40b7136ff265d645806e3d661cde186b3da819975658040b8f74a"
FULL_PROFILE_SHA = "ea03398546c1a1c8f9f099d0ed6ce4b156661d3276e0ec2057c7f09e563fe305"
FULL_RUN_SHA = "1a6d4f7b8efcc1e22c3af4c73b07a6fcfe609ce9ee07cc36c6d618a40c699428"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
GUIDE_FOLDER = RAW / "local-plan16-ddr0-errors-ena-guide-264"
GUIDE, DERIVATION = GUIDE_FOLDER / "errors-ena-guide.json", GUIDE_FOLDER / "derivation.json"
GUIDE_SHA = "a9813f9039aed67ebced9a3c4cdb2536f796f33d5a8c65b825116b442c1d612d"
DERIVATION_SHA = "3af3867921fe3fc1f3f1933debab88c717845c53e4c1df6f7df12521ecd4c7b5"
GUIDE_HELPER_SHA = "640bb5755d7edf56f2f04bc7b6662c664d809a221da916854fb950d4f277f92e"
GUIDE_SCOPE_SHA = "6310761b4b3d7ceb6eb5879a94616d99205a189768375f54b49edf2ab2559f29"
FAILED = RAW / "local-plan16-ddr0-errors-ena-stage-264"
FAILED_RUN_SHA = "e0354da32300c51d85dd7f7752a161215aed983ca0f202f3ff6dd6de7d9a2439"
FAILED_LOG_SHA = "f1420b544842730e6d6b45919f74e5abc56a9cf57e83a3641f7832662499562b"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
PROFILE, PLAN, FOLDER = HERE / "source-identity.json", HERE / "post-plan.json", HERE / "baseline"
INNER = "ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT2_B"
OUTER = "ddr0_errors_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_Q"
TARGET = "ddr0_errors_MISTRAL_FF_Q_11"
LEAVES = [4242, 15932, 4969, 4970, 4971, 4972]
COMPOSED_LUT = "0000110111011101110111011101110111011101110111011101110111011101"
COHORT_COUNTS = [21, 2, 10, 1, 6, 1, 1, 3, 2, 8]
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
CHANGED = {"mistral/arch.h", "mistral/arch.cc", "mistral/lut_driver_copy.h", "mistral/lut_driver_copy.cc", "mistral/main.cc",
    "mistral/remap_plan.cc", "mistral/tests/remap_plan.cc", "mistral/tests/remap_plan_cli.py", "mistral/remap_plan.md"}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key); result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected) and expected != "0" * 64 and
        (path not in inputs or inputs[path] == expected), "invalid/conflicting original pathname hash")
    if path not in inputs:
        require(sha(path) == expected, "original input changed: " + path); inputs[path] = expected


def finish(inputs):
    require(all(sha(path) == expected for path, expected in inputs.items()), "original input/output/runtime bytes changed")


def adopt(inputs, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT"); bind(inputs, ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute"); bind(inputs, name, expected)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure module pathname differs")
    return module


def definitions():
    control = load(CONTROL / "run_baseline.py", CONTROL_HELPER_SHA, "late_errors_control_pure")
    return control, control.definitions()


def qualification(log, definitions):
    control, parsers = definitions
    headers = list(re.finditer(r"^Info: Local-remap post-plan step (\d+): candidate=(-?\d+) groups=(\d+) pins=(\d+) preserve_ffs=(\d+)\.$", log, re.M))
    require([tuple(map(int, row.groups())) for row in headers] == [(0, 0, 1, 0, 1)], "fresh single late-plan header differs")
    start = headers[0].start(); preceding, block = log[:start], log[headers[0].end():]
    early = control.qualification(preceding, parsers)
    require(len(early) == 10 and preceding.count("Info: Decomposition applied candidate 0; full routing and signoff still required.") == 1 and
        re.findall(r"^Info: Placed reduction stage ([01]):", preceding, re.M) == ["0", "1"] and
        len(re.findall(r"^Info: Placed reduction candidate 0,", preceding, re.M)) == 2 and
        not any(label in preceding for label in ("LUT driver copy", "Local-remap post-plan step")), "late stage did not follow both placed reductions and decomposition")
    trials = list(re.finditer(r"^Info: Local remap trial inner=(\S+) outer=(\S+) lab=(\d+),(\d+) bel=(\S+) shift=(-?\d+),(-?\d+) gain=(-?\d+)ps clocks=(\d+) hold=(\d+) boundaries=(\d+) groups=(\d+) sinks=(\d+)$", block, re.M))
    choices = list(re.finditer(r"^Info: Local remap candidate (\d+): (.+) \+ (.+) -> (\S+), (\d+) ENA users, predicted gain (-?\d+)ps\.$", block, re.M))
    applied = list(re.finditer(r"^Info: Local remap applied candidate (\d+); full routing and signoff still required\.$", block, re.M))
    require(trials and len(choices) == len(applied) == 1 and choices[0][1] == applied[0][1] == "0" and
        trials[-1].end() < choices[0].start() < applied[0].start(), "fresh post candidate0 lacks its final guarded trial/application")
    row = trials[-1].groups()
    require((row[0], row[1], row[4], row[12], row[7]) == choices[0].groups()[1:] and row[:2] == (INNER, OUTER) and
        row[2:4] == ("33", "14") and row[5:7] == ("0", "0") and row[8:11] == ("1", "1", "1") and row[11:13] == ("1", "8") and
        int(row[7]) >= 250 and not any(label in block for label in ("LUT driver copy", "Local-remap plan step")), "late eight-ENA clock/hold/boundary/fixed-FF/minimum-gain guards differ")
    post = [{"index": 10, "plan_kind": "post", "post_step_index": 0, "candidate": 0, "groups_budget": 1, "selected_groups": 1,
        "inner": INNER, "outer": OUTER, "primary_lab": [33, 14], "bel": row[4], "ena_users": 8, "gain_ps": int(row[7]),
        "actual_trial_count": len(trials), "prior_trial_rows": [trial.groups() for trial in trials[:-1]], "ff_shift": [0, 0],
        "compiled_clock_hold_boundary_guards_passed": True, "independent_sta_proved": False}]
    return early, post


def command(previous):
    result = list(previous["command"])
    require(result[0] == str(BINARY) and result.count("--no-route") == result.count("--remap-plan") == 1 and
        result[result.index("--remap-plan") + 1] == str(EARLY_PLAN) and not any(flag in result for flag in
        ("--remap-post-plan", "--rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "new disabled-post control command role differs")
    for flag, path in (("--write", FOLDER / "placed.json"), ("--report", FOLDER / "timing.json")):
        require(result.count(flag) == 1, "ambiguous output selector"); result[result.index(flag) + 1] = str(path)
    result.extend(("--remap-post-plan", str(PLAN)))
    return result


def clean_source(host):
    def git(repo, *args): return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
    require(git(SOURCE, "rev-parse", "HEAD") == COMMIT and not git(SOURCE, "status", "--porcelain", "--untracked-files=all") and
        git(SOURCE, "merge-base", BASE, COMMIT) == BASE and set(git(SOURCE, "diff", "--name-only", BASE, COMMIT).splitlines()) == CHANGED,
        "current source differs from its clean committed host result")
    for repo, commit in [(Path(host["external_model_path"]), host["external_model_commit"])] + [(SOURCE / name, value) for name, value in host["required_submodule_commits"].items()]:
        require(git(repo, "rev-parse", "HEAD") == commit and not git(repo, "status", "--porcelain"), "selected source dependency changed")


def validate_host(host):
    counts = {"native_plan": 25, "driver_backend": 10, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["generator_sha256"] == HOST_HELPER_SHA and
        host["scope_sha256"] == HOST_SCOPE_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        set(host["checks"]) == set(counts) and set(host["changed_source_files"]) == CHANGED and all(row["passed"] is True and
            row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()), "current host/source/checks differ")


def prepare(self_sha, scope_sha, control_run_sha, control_proof_sha, guide_sha, derivation_sha):
    pins = (self_sha, scope_sha, control_run_sha, control_proof_sha, guide_sha, derivation_sha)
    require(all(type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) and value != "0" * 64 for value in pins) and
        (guide_sha, derivation_sha) == (GUIDE_SHA, DERIVATION_SHA) and not any(path.exists() for path in (PROFILE, PLAN, FOLDER)), "actual pins and exclusive outputs required")
    inputs = {}
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "scope.md", scope_sha), (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA),
        (CONTROL / "baseline/run.json", control_run_sha), (CONTROL / "baseline/comparison-control.json", control_proof_sha),
        (CONTROL / "run_baseline.py", CONTROL_HELPER_SHA), (CONTROL / "scope.md", CONTROL_SCOPE_SHA),
        (CONTROL / "compare_control.py", CONTROL_COMPARE_SHA), (CONTROL / "comparison-scope.md", CONTROL_COMPARE_SCOPE_SHA),
        (BINARY, BINARY_SHA), (ARCHIVE, ARCHIVE_SHA), (HOST, HOST_SHA), (COMPILER / "record_host.py", HOST_HELPER_SHA), (COMPILER / "host-scope.md", HOST_SCOPE_SHA),
        (EARLY_PLAN, EARLY_PLAN_SHA), (GUIDE, guide_sha), (DERIVATION, derivation_sha), (GUIDE_FOLDER / "derive_guide.py", GUIDE_HELPER_SHA),
        (GUIDE_FOLDER / "scope.md", GUIDE_SCOPE_SHA), (FULL_PROOF, FULL_PROOF_SHA), (FULL / "source-identity.json", FULL_PROFILE_SHA),
        (FULL / "route-c0/run.json", FULL_RUN_SHA), (ACCEPTED, ACCEPTED_SHA), (FAILED / "baseline/run.json", FAILED_RUN_SHA),
        (FAILED / "baseline/phase.log", FAILED_LOG_SHA), (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA)):
        bind(inputs, path, expected)
    original, previous, proof, host, derived, experiment, accepted, failed = (read(path) for path in
        (CONTROL / "source-identity.json", CONTROL / "baseline/run.json", CONTROL / "baseline/comparison-control.json", HOST, DERIVATION, FULL_PROOF, ACCEPTED, FAILED / "baseline/run.json"))
    validate_host(host)
    require(proof["phase"] == "post-remap-plan-disabled-ten-stage-native-control" and proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and
        proof["current_baseline_run_sha256"] == control_run_sha and proof["compiler_commit"] == COMMIT and proof["delta_base_commit"] == BASE and
        proof["generator_sha256"] == CONTROL_COMPARE_SHA and proof["scope_sha256"] == CONTROL_COMPARE_SCOPE_SHA and
        proof["recorder_sha256"] == CONTROL_HELPER_SHA and proof["recorder_scope_sha256"] == CONTROL_SCOPE_SHA and
        proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and all(proof[key] is True for key in
            ("candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact", "all_71_placement_metrics_exact", "complete_predicted_report_exact",
             "fresh_post_plan_control_prerequisite_proved", "final_original_path_metadata_and_runtime_hashes_stable")), "actual fresh control is not positive")
    require(previous["completed"] is True and previous["exit_code"] == 0 and previous["compiler_read_audit_passed"] is previous["final_original_input_output_runtime_hashes_stable"] is True and
        previous["source_identity_sha256"] == CONTROL_PROFILE_SHA and previous["compiler_commit"] == COMMIT and previous["binary_sha256"] == BINARY_SHA and
        previous["source_archive_sha256"] == ARCHIVE_SHA and previous["execution"] == original["baseline_execution"] and
        previous["input_sha256"] == {**original["input_sha256"], str(CONTROL / "source-identity.json"): CONTROL_PROFILE_SHA} and
        all(canonical(previous[key]) == canonical(value) for key, value in original.items() if key != "input_sha256") and previous["all_ten_complete_trial_models_exact"] is True and
        not any(key in previous for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "fresh control profile/run/runtime is not closed")
    require(failed["completed"] is False and failed["exit_code"] == 125 and failed["compiler_read_audit_passed"] is failed["partial_outputs_only"] is True and
        failed["output_sha256"] == {str(FAILED / "baseline/phase.log"): FAILED_LOG_SHA} and "Stale remap report edge" in (FAILED / "baseline/phase.log").read_text(),
        "failed early errors attempt rejection provenance differs")
    for manifest in (proof, derived, experiment, accepted): adopt(inputs, manifest)
    for ledger in (previous["input_sha256"], previous["output_sha256"], previous["execution"]["files"], failed["input_sha256"], failed["output_sha256"], failed["execution"]["files"], *(host[key] for key in HOST_MAPS)):
        for path, expected in ledger.items():
            require(Path(path).is_absolute(), "flat input/runtime path is not absolute"); bind(inputs, path, expected)
    require(experiment["structural_rejection"] is None and experiment["native_graph_proof_available"] is experiment["physical_scope_proved"] is True and
        experiment["current_full_run_sha256"] == FULL_RUN_SHA and experiment["source_identity_sha256"] == FULL_PROFILE_SHA and
        experiment["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and experiment["accepted_full_proof_sha256"] == ACCEPTED_SHA and
        accepted["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and derived["phase"] == "local-plan16-ddr0-errors-ena-exact-current-path-guide" and
        derived["experimental_full_proof_sha256"] == FULL_PROOF_SHA and derived["current_full_run_sha256"] == FULL_RUN_SHA and
        derived["route_profile_sha256"] == FULL_PROFILE_SHA and derived["accepted_reference_full_proof_sha256"] == ACCEPTED_SHA and
        derived["accepted_memory_reference_mhz"] == 117.77175903320312 and derived["source_tenth_experiment_timing_gain_accepted"] is derived["new_candidate_qualified"] is False and
        derived["guide_sha256"] == GUIDE_SHA and derived["guide_path"] == str(GUIDE) and derived["selected_path_source_indices"] == [2975] and
        derived["selected_endpoint"] == TARGET and derived["selected_lab"] == [33, 14] and derived["selected_paths"] == 1 and
        derived["expected_next_copy_name"] == OUTER + "$local_remap" and derived["existing_function_assignments_checked"] == 64 and
        derived["root_q"] == 4300 and derived["root_consumer_count"] == len(derived["root_consumer_slots"]) == 32 and derived["inner_q"] == 4973 and
        len(derived["inner_consumer_slots"]) == 161 and derived["six_literal_leaves_in_composed_pin_order"] == LEAVES and
        derived["existing_composed_mask_hex"] == "0x0ddddddddddddddd" and derived["generator_sha256"] == GUIDE_HELPER_SHA and derived["scope_sha256"] == GUIDE_SCOPE_SHA and
        all(derived[key] is True for key in ("final_original_path_metadata_and_runtime_hashes_stable", "exact_path_objects_and_original_source_order_preserved",
            "all_original_report_metadata_except_filtered_critical_paths_exact")) and derived["clock_terms_locations_sources_windows_or_segment_delays_modified"] is False,
        "old measured guide/current construction/accepted timing roles differ")
    control, parsers = definitions()
    for path, expected in control.PARSERS: bind(inputs, path, expected)
    for name, expected in control.SCRIPTS.items(): bind(inputs, MODULE / "scripts" / name, expected)
    models = control.qualification((CONTROL / "baseline/phase.log").read_text(), parsers)
    require(canonical(models) == canonical(previous["actual_selected_local_qualification"]) == canonical(original["retained_local_models"]) ==
        canonical(proof["fresh_local_models"]) == canonical(derived["retained_local_models"]), "fresh ten complete models differ from the guide construction")
    native = load(NATIVE, NATIVE_SHA, "late_errors_native_pure")
    frozen = load(FREEZE, FREEZE_SHA, "late_errors_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "late_errors_selected_pure", frozen)
    before = native.read_netlist(CONTROL / "baseline/placed.json")["modules"]["top"]
    routed = native.read_netlist(FULL / "route-c0/routed.json")["modules"]["top"]
    report = read(FULL / "route-c0/timing.json"); path = report["critical_paths"][2975]
    require(canonical(read(GUIDE)) == canonical({**report, "critical_paths": [path]}) and path["path"][-1]["to"]["cell"] == TARGET and
        path["path"][-1]["to"]["port"] == "ENA", "original selected path/report metadata differs")
    for segment in path["path"]:
        for endpoint in (segment["from"], segment["to"]):
            name, port = endpoint["cell"], endpoint["port"]; a, b = before["cells"][name], routed["cells"][name]
            require(a["type"] == b["type"] and a["parameters"] == b["parameters"] and a["attributes"]["NEXTPNR_BEL"] == b["attributes"]["NEXTPNR_BEL"] and
                a["port_directions"][port] == b["port_directions"][port] and a["connections"][port] == b["connections"][port], "late guide native endpoint is stale in current post-decomposition image")
    drivers, users = selected.native_tables(before)
    require(before["cells"][INNER]["type"] == "MISTRAL_ALUT2" and before["cells"][INNER]["parameters"] == {"LUT": "1101"} and
        before["cells"][INNER]["connections"] == {"Q": [4973], "B": [15932], "A": [4242]} and before["cells"][OUTER]["type"] == "MISTRAL_ALUT5" and
        before["cells"][OUTER]["parameters"] == {"LUT": "01111111111111110000000000000000"} and
        before["cells"][OUTER]["connections"] == {"Q": [4300], "E": [4973], "D": [4972], "C": [4971], "B": [4970], "A": [4969]} and
        drivers[4973] == [(INNER, "Q", 0, 0)] and len(users[4973]) == 161 and drivers[4300] == [(OUTER, "Q", 0, 0)] and len(users[4300]) == 32,
        "actual current six-leaf errors cone/side-user counts differ")
    cohort = [slot for slot in users[4300] if before["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"].startswith("MISTRAL_FF.33.14.")]
    require(len(cohort) == 8 and all(slot[1:] == ("ENA", 0, 0) for slot in cohort) and derived["declared_target_lab_ena_slots"] == [list(slot) for slot in cohort] and
        (TARGET, "ENA", 0, 0) in cohort, "whole original-root LAB33.14 cohort differs")
    target_rows = []
    for name, port, index, occurrence in cohort:
        cell = before["cells"][name]; require(cell["type"] == "MISTRAL_FF" and cell["connections"]["CLK"] == [3549], "target original FF clock differs")
        target_rows.append({"cell": name, "port": port, "vector_index": index, "occurrence": occurrence, "old_raw_bit": 4300,
            "clock_raw_bit": 3549, "bel": cell["attributes"]["NEXTPNR_BEL"], "before_record": cell})
    copies = copy.deepcopy(original["retained_copy_cohorts"])
    require(len(copies) == 10 and [len(row["consumer_slots"]) for row in copies] == COHORT_COUNTS, "ten retained cohorts differ")
    owners, labs = {INNER, OUTER, *(slot[0] for slot in cohort)}, {(33, 14)}
    for row, model in zip(copies, models):
        name = row["cell"]; cell = before["cells"][name]; bit = cell["connections"]["Q"][0]
        require(canonical(cell) == canonical(row["record"]) and row["consumer_slots"] == [list(slot) for slot in users[bit]] and
            cell["attributes"]["NEXTPNR_BEL"] == model["bel"] and len(users[bit]) == model["ena_users"] and not set(users[bit]) & set(cohort), "current retained copy record/cohort differs")
        owners.update((model["inner"], model["outer"], name)); owners.update(slot[0] for slot in users[bit]); labs.add(tuple(model["primary_lab"]))
    expected_name = OUTER + "$local_remap"
    require(all(name not in before["cells"] and name not in before["netnames"] for name in (expected_name, expected_name + "$Q")), "unused new paired namespace is occupied")
    for name in owners:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", before["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "original cone/copy/cohort lacks placed BEL"); labs.add(tuple(map(int, match.groups())))
    ff_bels, neighborhoods = {}, []
    for name, cell in before["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        bel = cell["attributes"].get("NEXTPNR_BEL", ""); match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", bel)
        require(match is not None, "original FF lacks placed BEL"); ff_bels[name] = bel
        if tuple(map(int, match.groups())) in labs: neighborhoods.append({"cell": name, "record": cell})
    require(len(ff_bels) == 8221 and ff_bels == original["all_original_ff_bel_manifest"], "all original FF owner/BELs differ")
    early_plan = read(EARLY_PLAN)
    require(early_plan == {"steps": original["local_plan_steps"]} and len(early_plan["steps"]) == 10 and original["original_plan_sha256"] == EARLY_PLAN_SHA,
        "literal early ten descriptors differ")
    post_plan = {"steps": [{"report": str(GUIDE), "candidate": 0, "groups": 1, "optimize_pins": False, "preserve_ff_placement": True}]}
    finish(inputs); clean_source(host)
    with PLAN.open("x") as stream: stream.write(json.dumps(post_plan, indent=2, sort_keys=True, allow_nan=False) + "\n")
    bind(inputs, PLAN, sha(PLAN))
    profile = {"schema": 1, "phase": "post-remap-plan-ddr0-errors-late-single-stage-predicted-baseline", "compiler_commit": COMMIT, "delta_base_commit": BASE,
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA, "host_validation_sha256": HOST_SHA,
        "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": control_run_sha, "control_proof_sha256": control_proof_sha,
        "experimental_current_full_proof_sha256": FULL_PROOF_SHA, "accepted_current_full_proof_sha256": ACCEPTED_SHA,
        "minimum_accepted_memory_mhz": 117.77175903320312, "rejected_early_errors_run_sha256": FAILED_RUN_SHA, "rejected_early_errors_log_sha256": FAILED_LOG_SHA,
        "rejected_attempt_used_as_structural_or_command_source": False, "guide_sha256": guide_sha, "guide_derivation_sha256": derivation_sha,
        "helper_sha256": self_sha, "scope_sha256": scope_sha, "original_ten_plan_path": str(EARLY_PLAN), "original_ten_plan_sha256": EARLY_PLAN_SHA,
        "local_plan_steps": early_plan["steps"], "post_plan_path": str(PLAN), "post_plan_sha256": inputs[str(PLAN)], "post_plan_steps": post_plan["steps"], "combined_requested_step_count": 11,
        "authorized_plan_delta": {"late_step_index": 0, "step": post_plan["steps"][0], "first_ten_descriptors_exact": True, "early_plan_path_and_bytes_exact": True},
        "retained_local_models": models, "retained_copy_cohorts": copies, "declared_ena_cohort": target_rows,
        "expected_additional_copy_name": expected_name, "expected_additional_copy_type": "MISTRAL_ALUT6", "expected_leaf_raw_bits": LEAVES, "expected_composed_lut": COMPOSED_LUT,
        "declared_whole_labs": sorted(map(list, labs)), "original_ffs_in_declared_labs": sorted(neighborhoods, key=lambda row: row["cell"]),
        "all_original_ff_bel_manifest": dict(sorted(ff_bels.items())), "actual_post_site_neighborhood_requires_later_prefix_proof": True,
        "command": command(previous), "cwd": previous["cwd"], "diagnostic_environment": previous["diagnostic_environment"], "baseline_execution": previous["execution"],
        "input_sha256": dict(sorted(inputs.items())), "driver_pass_executed": False, "native_graph_or_physical_equivalence_inherited": False,
        "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source(host)
    with PROFILE.open("x") as stream: stream.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finish(inputs); clean_source(host)
    print(json.dumps({"profile_sha256": sha(PROFILE), "post_plan_sha256": sha(PLAN), "inputs": len(inputs), "target_ena_count": len(target_rows)}, indent=2))


def execute(profile_sha):
    inputs = {}; bind(inputs, PROFILE, profile_sha); profile, previous, host = read(PROFILE), read(CONTROL / "baseline/run.json"), read(HOST)
    for path, expected in profile["input_sha256"].items(): bind(inputs, path, expected)
    validate_host(host)
    require(not FOLDER.exists() and profile["phase"] == "post-remap-plan-ddr0-errors-late-single-stage-predicted-baseline" and profile["command"] == command(previous) and
        profile["baseline_execution"] == previous["execution"] and profile["diagnostic_environment"] == previous["diagnostic_environment"] and profile["cwd"] == previous["cwd"] == str(MODULE) and
        inputs[str(CONTROL / "source-identity.json")] == profile["control_profile_sha256"] == CONTROL_PROFILE_SHA and
        inputs[str(CONTROL / "baseline/run.json")] == profile["control_run_sha256"] and inputs[str(CONTROL / "baseline/comparison-control.json")] == profile["control_proof_sha256"] and
        inputs[str(BINARY)] == profile["binary_sha256"] == BINARY_SHA and inputs[str(ARCHIVE)] == profile["source_archive_sha256"] == ARCHIVE_SHA and
        inputs[str(HOST)] == profile["host_validation_sha256"] == HOST_SHA and inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and
        inputs[str(HERE / "scope.md")] == profile["scope_sha256"] and inputs[str(PLAN)] == profile["post_plan_sha256"] and
        read(PLAN) == {"steps": profile["post_plan_steps"]} and len(profile["post_plan_steps"]) == 1 and
        inputs[str(EARLY_PLAN)] == EARLY_PLAN_SHA and read(EARLY_PLAN) == {"steps": profile["local_plan_steps"]} and len(profile["local_plan_steps"]) == 10 and
        profile["combined_requested_step_count"] == 11, "frozen late profile/helper/current runtime/plans differ")
    modules = definitions(); control, _ = modules; clean_source(host)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in control.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded current project module bytes/path differ")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(BINARY,
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "loaded current runtime/ambient diagnostic frame differs")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "phase.log").open("x") as output:
            actual = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = actual.returncode, True
        invocation.verify(); require(actual.returncode == 0, "late errors stage did not complete")
        log = (FOLDER / "phase.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
            not any(label in log for label in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy")) and
            not any((FOLDER / name).exists() for name in ("core.rbf", "routed.json")), "late baseline is not predicted-only")
        early, post = qualification(log, modules)
        require(canonical(early) == canonical(profile["retained_local_models"]), "fresh late invocation changed the ten retained complete models")
        record.update({"actual_early_selected_local_qualification": early, "actual_post_selected_local_qualification": post,
            "actual_selected_local_qualification": early + post, "original_ten_complete_trial_models_exact": True,
            "late_post_step_follows_reductions_and_decomposition": True})
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "predicted report cap/count/Fmax invalid")
        record["actual_predicted_fmax"], record["output_sha256"] = report["fmax"], {}
        for name in ("phase.log", "placed.json", "timing.json"):
            path = FOLDER / name; require(path.is_file() and path.stat().st_size > 0, "late predicted output absent"); record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source(host)
        record["completed"] = record["final_original_input_output_runtime_hashes_stable"] = True
        print(json.dumps({"completed": True, "fresh_post_stage_qualified": True, "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1; record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json") if (FOLDER / name).is_file()}
                    try:
                        finish({**inputs, **record["output_sha256"]}); invocation.verify(); clean_source(host)
                        record["final_original_input_output_runtime_hashes_stable"] = True
                    except BaseException as error:
                        record["final_original_input_output_runtime_hashes_stable"] = False
                        record["final_failure_revalidation_error"] = repr(error)
                (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally: invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("phase", choices=("prepare", "execute"))
    for name in ("self-sha256", "scope-sha256", "control-run-sha256", "control-proof-sha256", "guide-sha256", "derivation-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        values = (args.self_sha256, args.scope_sha256, args.control_run_sha256, args.control_proof_sha256, args.guide_sha256, args.derivation_sha256)
        require(all(values), "actual preparation pins missing"); prepare(*values)
    else:
        require(args.profile_sha256, "actual prepared profile activation pin missing"); execute(args.profile_sha256)


if __name__ == "__main__": main()
