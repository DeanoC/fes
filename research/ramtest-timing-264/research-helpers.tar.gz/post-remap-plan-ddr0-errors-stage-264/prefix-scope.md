# Late errors-copy strict native prefix

ROOT alone activates this comparison after whole-file, hash, AST and independent
peer review. Actual self/scope, reviewed late-recorder/scope, prepared late profile,
completed late run, completed current control run and positive control comparison
SHA arguments are mandatory. It exclusively writes baseline/comparison-prefix.json.
No unknown future run or qualification is assumed. No compiler, build, test, GPU,
Quartus, old validator, authenticator, source-clean query or entrypoint is invoked.

The selected compiler b3d03654/ELF0c880559/archive338f71f6/host3751b2eb is current.
The fresh same-compiler ten-stage control profile2294 is the before image. Its
positive comparison must prove full native/model/metric/report equality and bind
its actual closed run, recorder90c284/scope316fae and comparatora03142/scopebdd231.
The old d7e run3d69 is transitive construction provenance, not the new before image.
The failed early errors attempt e035 is never a completed prerequisite or selected
graph. Historical rejection bytes in existing flat closures remain history only.

All source/host/dependency/profile/runtime/output and cached construction maps
are rehashed directly, without replaying parent authentication. The literal ten
early descriptors and old00bf plan pathname stay exact. One separate post plan
contains errors-guidea981, candidate0, groups1, no pin optimization and fixed FFs.
It runs after reductions/decomposition and before a future driver request. Early
models10 and the fresh post-index0 model are parsed separately, then combined for
the logical scope with explicit plan_kind=post. No fake eleventh early header is
created. All actual first-ten decisions and71 placement metric rows stay exact.

The immutable guide/derivationa981/3af386 describes the exact original full path2975
to errorsFF11.ENA and all eight original-root consumers in LAB33.14. Its source
cd8ad7ff is native/physical-positive with rejected timing116.809. The accepted fifth
6dc/117.771759 MHz route remains a separate gain reference; neither source supplies
new timing acceptance. The late descriptor is validated by the compiler against
its actual graph at its new phase, with existing stale-edge checks unchanged.

Only pinned32fd parsing/Audit/canonical,72131 raw tables/report topology,8601's
import hook,0a522 scalar/LUT/LAB definitions, and 1d306fd1's lower prove and
copy_pin_snapshot definitions are reused. The latter module is an inactive
earlier prefix; its comparison/main/authentication and failed-run activation are
never called. Its constants describe the exact same errors cone independently
revalidated against current native inputs. New recorder definitions are loaded
only for pure command and actual early/post qualification checks.
The complete called ten-stage parser chain is listed by original pathname/hash
in pure_function_helper_sha256 and required in the frozen profile input closure.

The initial graph gate admits only one new errorsALUT6/private Q, eight named ENA
redirects and six new input loads:14907→14908 cells/16645→16646 nets. Every original
alias/raw bit, full cell/parameter/attribute/available pin map/BEL, connected slot,
public port, top metadata, owner/port order and ordered paired PLL occurrence stays
exact outside those eight ENAs. No private-output alignment, global translation,
buffer collapse or unobserved pin waiver is permitted. All ten existing copy
records, literal Q drivers, complete cohorts and all8221 FF names/BELs stay exact.
The original inner Q4973 retains all161 users, including160 status ENAs; rootQ4300
keeps24 of32 ENAs and the new copy owns exactly the declared eight. Full raw driver
and user tables are reconstructed independently in both images.

Six distinct unchanged ordinary drivers feed native leaves
4242,15932,4969,4970,4971,4972. Actual inner0xd/outer0x7fff0000/newALUT6
0x0ddddddddddddddd are enumerated independently over all64 plain-SIG assignments.
This conditional logical proof does not establish absent physical input states.
Optional NEWcopy FES_PINMAP may vary by actual half: its complete ABCDEFQ snapshot
must have six distinct SIG inputs in A/B/C/D/Ehalf/Fhalf and Q=COMBOUT. All original
pin metadata remains exact. Shared-half legality, stored LUT banks and physical
truth require a later routed evaluator. Every original FF in the predeclared LABs
and the dynamically chosen clone LAB is retained as complete native records.

The own current15290/seven-pair report is validated against the own lossless
native image and fresh-control endpoint/window set, with cap16384 and recorded
Fmax. Full report equality is diagnostic, not required after a new copy. Structural
and topology rejections are saved separately with final original-path hashes.
A positive prefix proves only exported native scope and conditional logical
composition; it does not independently recompute STA, prove physical banks/cache,
accept routed gain, inherit rejected experiments, or test/authorize hardware.
