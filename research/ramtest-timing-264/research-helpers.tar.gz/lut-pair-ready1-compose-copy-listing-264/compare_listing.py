"""Independently prove ready1 composed-copy listing rollback and exact guide provenance."""
import argparse
import builtins
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
PROFILE, RUN, RUNNER = HERE / "source-identity.json", HERE / "listing/run.json", HERE / "run_listing.py"
COMPILER = RAW / "lut-pair-compose-copy-264"
COMMIT, BASE = "cae5eb9a326507b688414ba934421286f648a43b", "e137ca5bda7c5e68e6da65f37b5830d12f58727a"
BINARY_SHA, ARCHIVE_SHA, HOST_SHA = "a2b5da93a9a91cd95d411fb5773e86136ff62e1fce7896d371c97c756004885e", "c64eb65c4e1ac01a277322bddc90172be836fddd60f2d3a0baf66bad62522dd2", "84416288f9a9b4f85c956ad32dc264efc14d007d2d3278c3abc952a006cc6a1e"
TEST_SHA, CHECKS_SHA = "b0e912b15ebd4ce11cb56cec7a356809ce4bf84ef347851fbcccfbf978a20484", "f0b694224d40ae6eb8c081d13fd0cc1fc75c1e337bd7093168a7a3759a3b6721"
HOST_HELPER_SHA, HOST_SCOPE_SHA = "e5cf3243801bcf13f4aed5086ad4914502ed1765bbff15eedf7cf4d589157439", "071a7d054e6dafd79d92962ad0f9466d5987da9aa793a38de2b1c41f019b95a3"
PROFILE_SHA, RUN_SHA = "6616243ae94f8bd0963be660bc4b4b3cbc64873b68296bf2792480638b8c0019", "540bb108cc203685edc1afa0d3fbd1cbe72c38e5a30801a8f17ce349f99ba942"
RUNNER_SHA, RUNNER_SCOPE_SHA = "18884eb7ca69b2c5ed4da3f40fd2992c67124de7cce1cbadd677c805f46f73a4", "5ae7fce2c094dca99d5cb0950d7a8a4243b5229b0ce890adb99a0517ca8f5ecc"
HOST = COMPILER / "validation/host-validation.json"
NATIVE, NATIVE_SHA = RAW / "narrow-integrated-264/compare_route.py", "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED, SELECTED_SHA = RAW / "driver-copy-selected-264/compare_selected.py", "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
GUIDE, GUIDE_SHA = RAW / "lut-pair-ready1-compose-copy-plan-264/ready1-guide.json", "ea8eb8119decde1de7e4437bdc96a22678145678228037c48dce08936d8a5c31"
ORIGIN, ORIGIN_SHA = GUIDE.parent / "guide-origin.json", "c95af4366f8aeaf22e394618cd68d44fbced0b62bf93125d70662064a0c8f5e2"
OLD_GUIDE = RAW / "lut-pair-ready0-listing-264/ready0-guide.json"
OLD_GUIDE_SHA = "9bdad54100c802d4a4aa366203afcaaffcfd4f69456d0ec2b0f6ac58ac786d41"
GUIDE_ROUTE = RAW / "lut-pair-ready0-compose-copy-route-264"
GUIDE_PROFILE_SHA = "79e71f1ed628b0bb0f4f97432fd8bca62ccf18e1066403c613c056215096a27b"
GUIDE_RUN_SHA = "b76ff6967705654e9cb1a9d8756d3302f4a7db035f3fb4c4f6490c3f376a8f22"
GUIDE_REPORT_SHA = "826d4d19817d7df017ea36a65c335522f4f356ad69443ca10043155d5f94c785"
GUIDE_SELECTED = RAW / "lut-pair-ready0-compose-copy-selected-264/selected/placed.json"
GUIDE_SELECTED_SHA = "11b385756263d1db95809b15957b563c3607cb420ba46c3ccf026ba5fcef6cce"
PLAN, PLAN_SHA = RAW / "local-plan16-ready1-command-stage-264/local-plan.json", "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
HOST_MAPS = ("artifact_sha256", "source_sha256", "source_submodule_file_sha256", "external_model_source_sha256",
    "build_dependency_manifest_sha256", "build_dependency_file_sha256")
CHANGED = {"mistral/CMakeLists.txt", "mistral/arch.h", "mistral/lut_pair_copy.cc", "mistral/lut_pair_placement.cc",
    "mistral/lut_pair_placement.h", "mistral/lut_pair_placement.md", "mistral/main.cc",
    "mistral/tests/lut_pair_placement.cc", "mistral/tests/lut_pair_placement_cli.py"}
REFERENCES = {
    "endpoint_diagnostic": ("lut-pair-ready0-endpoint-diagnostic-264", "diagnostic", "diagnostic_execution", "comparison-diagnostic.json",
        "b894dd50f695a788060509567f9d930e7277b63f5e2038af3909f33e43a985b6", "f08067560d5fe7c753b403666b89583ee8d5eba03b66a6432cf16f564b69824f",
        "12a957094445aa1e0eb12409abce889a4a69ba0d9f486f43251498aab0f347d8", "run_diagnostic.py",
        "3ea527220aa116a50d3930802fcec56a92572d2b91f685e5fb0e11e0d80f76d6", "a7bd7c1b16d169a96a55dac3747ddbb5e91b1d8c0f35ddf005c557124bfd3d8c",
        "compare_diagnostic.py", "d827962d106bb68bc34eff33d2856aa0ab98324a15370174f52f32d15d51220b", "615c5ba0a2a3a6606cdbc311582fa14b2971d7b1b64843220368f21fdf83fb4c",
        "lut-pair-ready0-endpoint-diagnostic-native-reproduction", "current_diagnostic_run_sha256", "fresh_lut_pair_endpoint_diagnostic_reproduction_proved", BASE),
    "original_listing": ("lut-pair-ready0-listing-264", "listing", "listing_execution", "comparison-listing.json",
        "53f82bb5adc3bcac143097cade72eefbbb076344cb4243c31f109cd8993b9103", "15e5a0c3e188811d870201e204b0cb0b9dcfadca545d0b051d2580f62e5f2fe4",
        "94627ac9a7ce2d8df01549d673233e914326fed48e9dd538042e5a37597f50d5", "run_listing.py",
        "6a053c8b28d5fa20ede4ba5ffdfe72f45bba48128931242407e380ac874b4964", "fb6d6ab4ce4ac93ac5d7293da2773b6756d898b1831531b7eff02b64d9a15c19",
        "compare_listing.py", "558d267935a07370971aa54748662131fd8473a35738ddb7442bbb67060de205", "d33bc3f0ee3f4dd9bf831b3fafefe4ea5c243b913739064e771655429c261e2e",
        "lut-pair-ready0-listing-native-reproduction", "current_listing_run_sha256", "fresh_lut_pair_listing_reproduction_proved", "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc"),
    "disabled_control": ("lut-pair-ten-control-264", "baseline", "baseline_execution", "comparison-control.json",
        "d8c15d6b1ec82481f4dd3131136a8e7a913488a9f2961ec5da2f9e9a19f16413", "581f3dd629fc00c7887bca7b6d8415fec214ce1cbe042c754e9eff776dbe3caa",
        "9498fb62edd6a9a25a3d8db137f1b7c32cc03dccd3be5a81233be639c81a196e", "run_baseline.py",
        "f72f98877a989f2457800989a69de7ef24d449cac4f6af759abc34a8ca447b13", "90494f8f0085b28b1d3a762508b09dff66396fab5c29994a869a319c3eaee903",
        "compare_control.py", "1350e1ae0913ded6504c44bf3b75174c5121a06995e8c2924162d9a59864da2e", "a9a8951997616e288371ca9532bb573b136704f2f880b0a69e9ba9453f1cf1b2",
        "lut-pair-disabled-ten-stage-native-control", "current_baseline_run_sha256", "fresh_lut_pair_control_prerequisite_proved", "5a4a28eb788675a16c6aef3187cedc73ebcdbfbc")}


def require(value, message):
    if not value: raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream: return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pinned pure module bytes/name differ")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "loaded pure pathname differs")
    return module


def bind_absolute(audit, ledger, runtime=False):
    for name, expected in ledger.items():
        path = Path(name); require(path.is_absolute(), "flat original pathname is not absolute")
        audit.bind(path, expected, execution=runtime or not path.resolve().is_relative_to(ROOT))


def bind_proof(audit, proof):
    for name, expected in proof["artifact_sha256"].items():
        path = Path(name); require(not path.is_absolute() and ".." not in path.parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / path, expected)
    bind_absolute(audit, proof["execution_file_sha256"], True)


def closed_record(native, record, profile, path, expected, execution_key):
    require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
        record["final_original_input_output_runtime_hashes_stable"] is True and record["source_identity_sha256"] == expected and
        record["execution"] == profile[execution_key] and record["input_sha256"] == {**profile["input_sha256"], str(path): expected} and
        all(native.canonical(record[key]) == native.canonical(value) for key, value in profile.items() if key != "input_sha256") and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel")), "record is not its closed exact profile/inputs/runtime")


def order_frame(value):
    if isinstance(value, dict): return [(key, order_frame(item)) for key, item in value.items()]
    if isinstance(value, list): return [order_frame(item) for item in value]
    return None


def prove_module(native, selected, before, after, manifest):
    require(set(before) == set(after) == {"creator", "modules"} and set(before["modules"]) == set(after["modules"]) == {"top"} and
        type(before["creator"]) is type(after["creator"]) is str, "complete document shape/creator type differs")
    a, b = before["modules"]["top"], after["modules"]["top"]
    require(len(a["cells"]) == len(b["cells"]) == 14907 and len(a["netnames"]) == len(b["netnames"]) == 16645 and
        native.canonical(before["modules"]) == native.canonical(after["modules"]), "complete native module/metadata/raw IDs differ")
    require(order_frame(before) == order_frame(after) and native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
        "complete owner/port/nested metadata order or paired PLL entries differ")
    require(selected.native_tables(a) == selected.native_tables(b), "complete raw driver/user occurrence tables differ")
    ffs = [{name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_FF"} for top in (a, b)]
    require(len(manifest) == 8221 and ffs[0] == ffs[1] == manifest, "all8221 FF names/BELs differ")
    return {"complete_native_module_exact": True, "complete_native_document_order_exact": True, "lossless_paired_pll_entries_exact": True,
        "native_driver_and_user_slot_tables_exact": True, "all_original_ff_records_and_bels_exact": True, "original_ff_count": 8221,
        "cells": 14907, "netnames": 16645, "creator_strings_exact": before["creator"] == after["creator"],
        "native_field_waiver_or_raw_id_alignment_used": False, "unexported_physical_state_proved": False}


def guide_provenance(native, selected, audit, profile, baseline_doc):
    prepared_path, run_path, report_path = GUIDE_ROUTE / "source-identity.json", GUIDE_ROUTE / "route/run.json", GUIDE_ROUTE / "route/timing.json"
    for path, expected in ((ORIGIN, ORIGIN_SHA), (prepared_path, GUIDE_PROFILE_SHA), (run_path, GUIDE_RUN_SHA), (report_path, GUIDE_REPORT_SHA), (GUIDE_SELECTED, GUIDE_SELECTED_SHA), (OLD_GUIDE, OLD_GUIDE_SHA)):
        audit.bind(path, expected)
    origin, prepared, entry, report = (native.read(path) for path in (ORIGIN, prepared_path, run_path, report_path))
    closed_record(native, entry, prepared, prepared_path, GUIDE_PROFILE_SHA, "route_execution")
    bind_absolute(audit, prepared["input_sha256"]); bind_absolute(audit, entry["input_sha256"])
    bind_absolute(audit, entry["output_sha256"]); bind_absolute(audit, entry["execution"]["files"], True)
    require(entry["output_sha256"][str(report_path)] == GUIDE_REPORT_SHA and entry["fmax"] == report["fmax"] and
        entry["phase"] == "lut-pair-ready0-compose-copy-fresh-selected-full-route" and entry["compiler_commit"] == COMMIT and
        entry["binary_sha256"] == BINARY_SHA and entry["source_archive_sha256"] == ARCHIVE_SHA and entry["host_validation_sha256"] == HOST_SHA and
        entry["driver_pass_executed"] is entry["post_plan_requested"] is False and entry["rbf_generation_requested"] is True and
        entry["actual_selected_pair_copy_qualification"]["candidate_applied"] is True and
        origin["schema"] == 1 and origin["complete_source_run"] == str(run_path) and origin["complete_source_run_sha256"] == GUIDE_RUN_SHA and
        origin["complete_source_report"] == str(report_path) and origin["complete_source_report_sha256"] == GUIDE_REPORT_SHA and
        origin["actual_selected_graph"] == str(GUIDE_SELECTED) and origin["actual_selected_graph_sha256"] == GUIDE_SELECTED_SHA and
        origin["guide_path"] == str(GUIDE) and origin["guide_sha256"] == GUIDE_SHA and
        origin["actual_complete_critical_path_preserved"] is origin["guide_contains_only_supported_critical_paths_field"] is True and
        origin["guide_clock_or_window_or_segment_changed"] is origin["routed_gain_accepted"] is False,
        "current guide source/origin is not its actual completed unaccepted route")
    guide = native.read(GUIDE)
    require(set(guide) == {"critical_paths"} and len(guide["critical_paths"]) == 1 and
        origin["actual_critical_path_index"] == profile["actual_critical_path_index"] == 1 and
        origin["actual_tied_cohort_path_index"] == profile["actual_tied_cohort_path_index"] == 2975 and
        native.canonical(guide["critical_paths"][0]) == native.canonical(report["critical_paths"][1]) == native.canonical(profile["exact_current_path_object"]) and
        native.canonical(profile["exact_tied_current_path_object"]) == native.canonical(report["critical_paths"][2975]) and
        report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290,
        "guide or tied path is not its exact supported current object/source order")
    document = native.read_netlist(GUIDE_SELECTED); top = document["modules"]["top"]; cells = top["cells"]
    pair = profile["declared_original_lut_pair"]
    routing = [row for row in guide["critical_paths"][0]["path"] if row["type"] == "routing"]
    require(type(pair) is list and len(pair) == 2 and all(set(row) == {"cell", "record"} and cells[row["cell"]] == row["record"] for row in pair) and
        len(routing) == 3 and routing[0]["to"]["cell"] == pair[0]["cell"] and
        routing[1]["from"]["cell"] == pair[0]["cell"] and routing[1]["from"]["port"] == "Q" and routing[1]["to"]["cell"] == pair[1]["cell"] and
        routing[2]["from"]["cell"] == pair[1]["cell"] and routing[2]["from"]["port"] == "Q" and routing[2]["to"]["port"] == "ENA",
        "current guide declared original pair/routing edges differ")
    baseline = baseline_doc["modules"]["top"]["cells"]
    for segment in guide["critical_paths"][0]["path"]:
        for endpoint in (segment["from"], segment["to"]):
            name, port = endpoint["cell"], endpoint["port"]; cell = cells[name]
            require(native.canonical(cell) == native.canonical(baseline[name]) and port in cell["connections"] and
                list(map(int, cell["attributes"]["NEXTPNR_BEL"].split(".")[1:3])) == endpoint["loc"], "guide original path frame differs from TEN")
    for segment in routing:
        source, sink = segment["from"], segment["to"]
        bit = cells[source["cell"]]["connections"][source["port"]]
        require(len(bit) == 1 and type(bit[0]) is int and cells[sink["cell"]]["connections"][sink["port"]] == bit and
            cells[source["cell"]]["port_directions"][source["port"]] == "output" and cells[sink["cell"]]["port_directions"][sink["port"]] == "input" and
            bit[0] in top["netnames"][segment["net"]]["bits"], "guide edge or original net alias differs")
    target = routing[-1]["to"]["cell"]
    bel = cells[target]["attributes"]["NEXTPNR_BEL"]
    location = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.(\d+)", bel)
    require(location and cells[target]["type"] == "MISTRAL_FF" and all(cells[target]["port_directions"].get(port) == "input" and
        len(cells[target]["connections"][port]) == 1 and type(cells[target]["connections"][port][0]) is int for port in ("CLK", "ENA")), "guide FF control/location is not scalar")
    lab = "MISTRAL_FF." + location[1] + "." + location[2]
    root, clock = cells[target]["connections"]["ENA"][0], cells[target]["connections"]["CLK"][0]
    cohort = sorted([{"cell": name, "port": "ENA", "index": 0, "bit": root, "record": cell} for name, cell in cells.items()
        if cell["type"] == "MISTRAL_FF" and cell["attributes"]["NEXTPNR_BEL"].startswith(lab + ".") and
        cell["connections"]["ENA"] == [root] and cell["connections"]["CLK"] == [clock]], key=lambda row: row["cell"])
    whole = [{"cell": name, "record": cell} for name, cell in cells.items() if cell["type"] == "MISTRAL_FF" and cell["attributes"]["NEXTPNR_BEL"].startswith(lab + ".")]
    drivers, users = selected.native_tables(top)
    lab_users = [slot for slot in users[root] if cells[slot[0]]["attributes"].get("NEXTPNR_BEL", "").split(".")[1:3] == [location[1], location[2]]]
    require(lab == origin["actual_target_lab"] == profile["target_whole_lab"] and root == profile["declared_root_q"] and clock == profile["declared_clock_q"] and
        origin["actual_target_enable"] == [root] and origin["actual_target_clock"] == [clock] and
        drivers[root] == [(pair[1]["cell"], "Q", 0, 0)] and len(cohort) == 2 and len(whole) == 15 and
        set(origin["actual_native_ena_cohort"]) == {row["cell"] for row in cohort} and
        native.canonical(cohort) == native.canonical(profile["declared_ena_cohort"]) and native.canonical(whole) == native.canonical(profile["all_original_ff_members_in_target_lab"]) and
        sorted(lab_users) == sorted((row["cell"], "ENA", 0, 0) for row in cohort) and all(native.canonical(row["record"]) == native.canonical(baseline[row["cell"]]) for row in whole) and
        all((row["cell"], "ENA", 0, 0) in users[root] for row in cohort) and
        report["critical_paths"][2975]["path"][-1]["to"]["cell"] in {row["cell"] for row in cohort} - {target},
        "current whole LAB/two-FF same-clock enable cohort differs")
    require(all(profile[key] == expected for key, expected in (("guide_origin_path", str(ORIGIN)), ("guide_origin_sha256", ORIGIN_SHA),
        ("guide_source_profile_sha256", GUIDE_PROFILE_SHA), ("guide_source_run_sha256", GUIDE_RUN_SHA), ("guide_source_report_sha256", GUIDE_REPORT_SHA), ("guide_source_selected_graph_sha256", GUIDE_SELECTED_SHA))),
        "prepared current guide provenance ledger differs")
    return {"current_full_source_profile_sha256": GUIDE_PROFILE_SHA, "current_full_source_run_sha256": GUIDE_RUN_SHA,
        "current_full_source_report_sha256": GUIDE_REPORT_SHA, "guide_origin_sha256": ORIGIN_SHA, "exact_path_source_index": 1, "exact_tied_path_source_index": 2975,
        "declared_original_lut_pair": pair, "whole_target_lab": lab, "declared_ena_cohort": cohort, "whole_original_ff_count": len(whole),
        "previous_extra_ready0_copy_is_not_stacked": True, "source_routed_gain_or_physical_frame_inherited": False}


def diagnostic(error):
    return {"exception_type": type(error).__name__, "reason": str(error)}


def compare(self_sha, scope_sha, profile_sha, run_sha, runner_sha, runner_scope_sha):
    require(re.fullmatch("[0-9a-f]{40}", COMMIT) and all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in
        (BINARY_SHA, ARCHIVE_SHA, HOST_SHA, TEST_SHA, CHECKS_SHA, HOST_HELPER_SHA, HOST_SCOPE_SHA, PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA)) and
        (profile_sha, run_sha, runner_sha, runner_scope_sha) == (PROFILE_SHA, RUN_SHA, RUNNER_SHA, RUNNER_SCOPE_SHA), "actual copy listing identities remain UNFROZEN or differ")
    native = load(NATIVE, NATIVE_SHA, "ready1_copy_listing_native_pure"); audit = native.Audit()
    for path, expected in ((Path(__file__).resolve(), self_sha), (HERE / "comparison-scope.md", scope_sha), (PROFILE, profile_sha), (RUN, run_sha),
        (RUNNER, runner_sha), (HERE / "scope.md", runner_scope_sha), (HOST, HOST_SHA), (COMPILER / "record_host.py", HOST_HELPER_SHA),
        (COMPILER / "host-scope.md", HOST_SCOPE_SHA), (COMPILER / "nextpnr-mistral", BINARY_SHA), (COMPILER / "source.tar.gz", ARCHIVE_SHA),
        (NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (GUIDE, GUIDE_SHA), (ORIGIN, ORIGIN_SHA), (PLAN, PLAN_SHA)):
        audit.bind(path, expected)
    profile, record, host = (native.read(path) for path in (PROFILE, RUN, HOST))
    closed_record(native, record, profile, PROFILE, profile_sha, "listing_execution")
    runner = load(RUNNER, runner_sha, "ready1_copy_listing_recorder_pure")
    require((runner.COMMIT, runner.BASE, runner.BINARY_SHA, runner.ARCHIVE_SHA, runner.HOST_SHA, runner.TEST_SHA, runner.CHECKS_SHA,
        runner.HOST_HELPER_SHA, runner.HOST_SCOPE_SHA) == (COMMIT, BASE, BINARY_SHA, ARCHIVE_SHA, HOST_SHA, TEST_SHA, CHECKS_SHA, HOST_HELPER_SHA, HOST_SCOPE_SHA), "new recorder identities differ")
    references = {}
    for name, spec in REFERENCES.items():
        directory, folder, execution_key, proof_file, psha, rsha, fsha, helper, hsha, hscope, comparer, csha, cscope, phase, run_key, positive_key, commit = spec
        base = RAW / directory; prepared_path = base / "source-identity.json"; output = base / folder
        for path, expected in ((prepared_path, psha), (output / "run.json", rsha), (output / proof_file, fsha),
            (base / helper, hsha), (base / "scope.md", hscope), (base / comparer, csha), (base / "comparison-scope.md", cscope)):
            audit.bind(path, expected)
        prepared, entry, proof = (native.read(path) for path in (prepared_path, output / "run.json", output / proof_file))
        closed_record(native, entry, prepared, prepared_path, psha, execution_key)
        require(proof["schema"] == 1 and proof["phase"] == phase and proof["compiler_commit"] == commit and entry["compiler_commit"] == commit and
            proof["source_identity_sha256"] == psha and proof[run_key] == rsha and proof["generator_sha256"] == csha and proof["scope_sha256"] == cscope and
            proof["recorder_sha256"] == hsha and proof["recorder_scope_sha256"] == hscope and proof["current_actual_execution"] == entry["execution"] and
            proof["structural_rejection"] is proof["native_path_topology_rejection"] is None and
            all(proof[key] is True for key in (positive_key, "candidate_completed", "native_graph_proof_available", "all_ten_complete_trial_models_exact",
                "all_71_placement_metrics_exact", "complete_predicted_report_exact", "final_original_path_metadata_and_runtime_hashes_stable")) and
            native.canonical(proof["fresh_local_models"]) == native.canonical(entry["actual_selected_local_qualification"]), "closed reference prerequisite differs: " + name)
        bind_proof(audit, proof); bind_absolute(audit, prepared["input_sha256"]); bind_absolute(audit, entry["input_sha256"])
        require(set(entry["output_sha256"]) == {str(output / suffix) for suffix in ("phase.log", "placed.json", "timing.json")}, "reference output triplet differs")
        bind_absolute(audit, entry["output_sha256"]); bind_absolute(audit, entry["execution"]["files"], True)
        references[name] = {"profile": prepared, "record": entry, "proof": proof, "folder": output}
    counts = {"pair_backend": 12, "copy_backend": 11, "native_plan": 25, "driver_backend": 10, "pair_cli": 17, "remap_plan_cli": 24, "driver_cli": 10}
    require(host["schema"] == 1 and host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and host["test_binary_sha256"] == TEST_SHA and host["check_results_sha256"] == CHECKS_SHA and
        host["generator_sha256"] == HOST_HELPER_SHA and host["scope_sha256"] == HOST_SCOPE_SHA and host["clean_committed_checkout"] is host["build_passed"] is True and
        set(host["changed_source_files"]) == CHANGED and set(host["checks"]) == set(counts) and
        all(row["passed"] is True and row["exit_code"] == 0 and row["cases"] == counts[key] for key, row in host["checks"].items()) and
        all(host[key] for key in HOST_MAPS) and host["committed_archive_manifest_sha256"] and
        all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in host["committed_archive_manifest_sha256"]), "fresh composed-copy host/dependency/source qualification differs")
    for key in HOST_MAPS: bind_absolute(audit, host[key])
    bind_absolute(audit, profile["input_sha256"]); bind_absolute(audit, record["input_sha256"]); bind_absolute(audit, record["execution"]["files"], True)
    require(set(record["output_sha256"]) == {str(RUN.parent / name) for name in ("phase.log", "placed.json", "timing.json")}, "fresh output triplet differs")
    bind_absolute(audit, record["output_sha256"])
    previous, old = references["endpoint_diagnostic"]["record"], references["original_listing"]["record"]
    require(profile["schema"] == 1 and profile["phase"] == "lut-pair-ready1-compose-copy-predicted-listing" and profile["command"] == runner.command(previous) and
        profile["listing_execution"] == record["execution"] == runner.expected_execution(previous) and
        all(profile[key] == expected for key, expected in (("compiler_commit", COMMIT), ("delta_base_commit", BASE), ("binary_sha256", BINARY_SHA),
            ("source_archive_sha256", ARCHIVE_SHA), ("host_validation_sha256", HOST_SHA), ("helper_sha256", runner_sha), ("scope_sha256", runner_scope_sha))) and
        profile["pair_candidate_selection"] == -1 and profile["compose_copy_requested"] is True and
        all(profile[key] is False for key in ("post_plan_requested", "driver_pass_executed", "native_or_physical_reproduction_inherited", "routed_gain_accepted", "hardware_tested")), "fresh listing command/runtime/roles differ")
    for name, prefix in (("endpoint_diagnostic", "previous_diagnostic"), ("original_listing", "previous_listing"), ("disabled_control", "control")):
        require(all(profile[prefix + suffix] == REFERENCES[name][index] for suffix, index in
            (("_profile_sha256", 4), ("_run_sha256", 5), ("_proof_sha256", 6))), "prepared historical identity differs: " + name)
    require(profile["authorized_runtime_delta"] == {"old_compiler_path": str(runner.OLD_COMPILER), "old_compiler_sha256": runner.OLD_COMPILER_SHA,
        "new_compiler_path": str(runner.BINARY), "new_compiler_sha256": BINARY_SHA, "controlled_path_directory_replaced": True,
        "all_other_execution_fields_and_files_exact": True}, "declared runtime substitution differs")
    for reference in references.values():
        entry = reference["record"]
        require(profile["cwd"] == entry["cwd"] == str(ROOT / "sources/misteross") and profile["diagnostic_environment"] == entry["diagnostic_environment"] and
            profile["all_original_ff_bel_manifest"] == entry["all_original_ff_bel_manifest"] and profile["retained_copy_cohorts"] == entry["retained_copy_cohorts"], "reference fixed invocation/FF/cohort differs")
    control, parsers = runner.definitions()
    pure = ((NATIVE, NATIVE_SHA), (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (RUNNER, runner_sha),
        (RAW / REFERENCES["disabled_control"][0] / "run_baseline.py", REFERENCES["disabled_control"][8]), *control.PARSERS)
    require(profile["pure_function_helper_sha256"] == {str(path): expected for path, expected in (*pure[4:], (NATIVE, NATIVE_SHA))}, "complete TEN pure parser chain ledger differs")
    for path, expected in pure:
        audit.bind(path, expected)
        if path not in (NATIVE, SELECTED, FREEZE): require(profile["input_sha256"].get(str(path)) == expected, "called pure parser outside input closure")
    for name, expected in runner.SCRIPTS.items():
        path = ROOT / "sources/misteross/scripts" / name; audit.bind(path, expected)
        require(profile["input_sha256"].get(str(path)) == expected, "executed project module outside input closure")
    require(all(audit.paths.get(Path(path)) == expected for path, expected in profile["input_sha256"].items()) and
        audit.paths.get(runner.BINARY) == BINARY_SHA and audit.paths.get(runner.ARCHIVE) == ARCHIVE_SHA, "fresh original input/runtime/source closure incomplete")
    plan, guide = native.read(PLAN), native.read(GUIDE)
    require(profile["original_plan_path"] == old["original_plan_path"] == str(PLAN) and profile["original_plan_sha256"] == old["original_plan_sha256"] == PLAN_SHA and
        set(plan) == {"steps"} and plan["steps"] == profile["local_plan_steps"] == old["local_plan_steps"] and len(plan["steps"]) == 10 and
        [step["groups"] for step in plan["steps"]] == [8] + [1] * 9 and all(set(step) == {"report", "candidate", "groups", "optimize_pins", "preserve_ff_placement"} and
            step["candidate"] == 0 and step["optimize_pins"] is False and step["preserve_ff_placement"] is True and Path(step["report"]) in audit.paths for step in plan["steps"]) and
        profile["guide_path"] == str(GUIDE) and profile["guide_sha256"] == GUIDE_SHA and old["guide_path"] == str(OLD_GUIDE) and old["guide_sha256"] == OLD_GUIDE_SHA and
        native.canonical(guide) == native.canonical({"critical_paths": [profile["exact_current_path_object"]]}) and
        profile["authorized_guide_delta"] == {"old_guide_path": str(OLD_GUIDE), "old_guide_sha256": OLD_GUIDE_SHA, "new_guide_path": str(GUIDE), "new_guide_sha256": GUIDE_SHA,
            "only_pair_report_selector_path_changed": True, "previous_extra_ready0_copy_is_not_stacked": True}, "literal TEN plan/current one-path guide delta differs")
    log = (RUN.parent / "phase.log").read_text()
    models, copy, model_rejection = None, None, None
    try:
        models, copy = runner.qualification(log, control, parsers)
        require(native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) and
            native.canonical(copy) == native.canonical(record["actual_pair_copy_listing"]) and copy["candidate_applied"] is False,
            "actual copy grammar/model record or unapplied listing differs")
    except (ValueError, TypeError, KeyError, IndexError) as error: model_rejection = diagnostic(error)
    models_by_reference = {name: model_rejection is None and len(models) == 10 and native.canonical(models) == native.canonical(ref["record"]["actual_selected_local_qualification"])
        for name, ref in references.items()}
    metrics = native.PLACEMENT_METRICS.findall(log)
    reference_metrics = {name: native.PLACEMENT_METRICS.findall((ref["folder"] / "phase.log").read_text()) for name, ref in references.items()}
    metrics_by_reference = {name: len(metrics) == len(rows) == 71 and metrics == rows for name, rows in reference_metrics.items()}
    report = native.read(RUN.parent / "timing.json")
    reports = {name: native.read(ref["folder"] / "timing.json") for name, ref in references.items()}
    report_by_reference = {name: native.canonical(report) == native.canonical(data) for name, data in reports.items()}
    recorder_diagnostics = {key: record[key] is expected for key, expected in
        (("all_ten_complete_trial_models_exact", models_by_reference["endpoint_diagnostic"]),
         ("all_71_placement_metrics_exact_diagnostic", metrics_by_reference["endpoint_diagnostic"]),
         ("complete_predicted_report_exact_diagnostic", report_by_reference["endpoint_diagnostic"]))}
    require(native.canonical(profile["retained_local_models"]) == native.canonical(previous["actual_selected_local_qualification"]), "prepared TEN models differ")
    frozen = load(FREEZE, FREEZE_SHA, "ready1_copy_listing_freeze_pure")
    selected = load(SELECTED, SELECTED_SHA, "ready1_copy_listing_selected_pure", frozen)
    document = native.read_netlist(RUN.parent / "placed.json")
    documents = {name: native.read_netlist(ref["folder"] / "placed.json") for name, ref in references.items()}
    guide_evidence = guide_provenance(native, selected, audit, profile, documents["disabled_control"])
    evidence, rejections, topology, topology_rejections = {}, {}, {}, {}
    for name, before in documents.items():
        try: evidence[name] = prove_module(native, selected, before, document, profile["all_original_ff_bel_manifest"])
        except (ValueError, TypeError, KeyError, IndexError) as error: rejections[name] = diagnostic(error)
    for name, doc, data in [(key, documents[key], reports[key]) for key in documents] + [("fresh_copy_listing", document, report)]:
        try:
            topology[name] = selected.report_topology(doc, data, reports["disabled_control"])
            require(data["timing_report_paths"] == 16384 and topology[name]["current_report_paths"] == 15290 and
                len(topology[name]["domain_pair_endpoint_counts"]) == 7, "complete native paths/clock pairs/cap differ")
        except (ValueError, TypeError, KeyError, IndexError) as error: topology_rejections[name] = diagnostic(error)
    require(record["actual_predicted_fmax"] == report["fmax"] and "Info: Program finished normally." in log and
        not any(line.startswith("ERROR:") for line in log.splitlines()) and log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
        not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis", "Running final routed timing analysis", "LUT driver copy", "Local-remap post-plan step",
            "LUT pair placement discovery", "LUT pair placement applied candidate", "LUT pair copy applied candidate")) and
        not any((RUN.parent / name).exists() for name in ("core.rbf", "routed.json")), "fresh copy listing is not final predicted-only completion")
    audit.finish()
    models_exact, metrics_exact, report_exact = all(models_by_reference.values()), all(metrics_by_reference.values()), all(report_by_reference.values())
    positive = not rejections and model_rejection is None and not topology_rejections and models_exact and metrics_exact and report_exact and all(recorder_diagnostics.values())
    return {"schema": 1, "phase": "lut-pair-ready1-compose-copy-listing-native-reproduction", "source_identity_sha256": profile_sha,
        "current_copy_listing_run_sha256": run_sha, "compiler_commit": COMMIT, "delta_base_commit": BASE, "generator_sha256": self_sha,
        "scope_sha256": scope_sha, "recorder_sha256": runner_sha, "recorder_scope_sha256": runner_scope_sha, "host_validation_sha256": HOST_SHA,
        "reference_proof_sha256": {name: spec[6] for name, spec in REFERENCES.items()}, "candidate_completed": True, "elapsed_seconds": record["elapsed_seconds"],
        "current_actual_execution": record["execution"], "creator_strings": {**{name: doc["creator"] for name, doc in documents.items()}, "fresh_copy_listing": document["creator"]},
        "only_creator_provenance_difference_permitted": True, "creator_difference_observed": any(doc["creator"] != document["creator"] for doc in documents.values()),
        "fresh_local_models": models, "reference_local_models": {name: ref["record"]["actual_selected_local_qualification"] for name, ref in references.items()},
        "actual_pair_copy_listing": copy, "model_or_copy_listing_rejection": model_rejection, "all_ten_complete_trial_models_exact": models_exact,
        "recorder_diagnostic_flags_match_independent_comparison": recorder_diagnostics,
        "ten_model_equality_by_reference": models_by_reference, "all_71_placement_metrics_exact": metrics_exact, "placement_metric_equality_by_reference": metrics_by_reference,
        "placement_metric_rows": metrics, "reference_placement_metric_rows": reference_metrics, "structural_rejection": rejections or None,
        "native_graph_proof_available": not rejections, "native_graph_evidence": evidence, "current_predicted_native_paths": topology,
        "native_path_topology_rejection": topology_rejections or None, "complete_predicted_report_exact": report_exact, "complete_report_equality_by_reference": report_by_reference,
        "actual_predicted_fmax": report["fmax"], "current_exact_guide_provenance": guide_evidence, "fresh_lut_pair_copy_listing_reproduction_proved": positive,
        "fresh_selected_composed_copy_prerequisite_available": positive and copy["qualified_candidates"] > 0 and bool(copy["actual_qualified_candidates"]),
        "raw_id_alignment_or_native_module_field_waiver_used": False, "selected_candidate_accepted": False,
        "independent_functional_or_physical_equivalence_proved": False, "independent_numerical_sta_proved": False, "routed_gain_accepted": False,
        "hardware_tested": False, "pure_function_helper_sha256": {str(path): expected for path, expected in pure},
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())), "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "profile-sha256", "run-sha256", "runner-sha256", "runner-scope-sha256"): parser.add_argument("--" + name, required=True)
    args = parser.parse_args(); require(all(re.fullmatch("[0-9a-f]{64}", value) and value != "0" * 64 for value in vars(args).values()), "actual SHA activation pins required")
    output = HERE / "listing/comparison-copy-listing.json"; require(not output.exists(), "immutable copy listing comparison exists")
    result = compare(args.self_sha256, args.scope_sha256, args.profile_sha256, args.run_sha256, args.runner_sha256, args.runner_scope_sha256)
    with output.open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"comparison_sha256": sha(output), "native_graph_proof_available": result["native_graph_proof_available"],
        "structural_rejection": result["structural_rejection"], "fresh_lut_pair_copy_listing_reproduction_proved": result["fresh_lut_pair_copy_listing_reproduction_proved"]}, indent=2))


if __name__ == "__main__": main()
