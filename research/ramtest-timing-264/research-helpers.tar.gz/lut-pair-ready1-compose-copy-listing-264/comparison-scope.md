# Ready1 composed-copy listing reproduction

This new inactive comparator owns only compare_listing.py and this scope. ROOT
alone imports, AST-checks or executes helpers and operates the compiler. Four
actual profile/run/recorder/scope identities remain explicit UNFROZEN literals
until their real closures; ROOT fills those quoted values and reviews the final
bytes before activation. All six CLI hashes are mandatory. Existing files and
evidence are untouched. Output is exclusive listing/comparison-copy-listing.json.

The unchanged compiler is cae5eb9a, ELFa2b5/archivec64e/host844162. Its current
nine-file committed delta, all58 native cases/four suites and51 CLI methods,
source/model/submodule/archive/object/dependency and runtime bytes remain bound.
The host's preserved failed attempts remain distinct from final qualification.
No new compiler build, inherited transformation or routing acceptance is claimed.

Three direct immutable TEN references remain positive and separately bound:
e137 endpoint-diagnostic reproduction12a957, original5a listing94627, and5a
disabled-TEN dual-reference control9498. Profiles, runs, recorder/comparer/scopes,
all flat artifacts and original runtime paths are authenticated without replaying
an old prepare/execute/main/authenticator or comparison evaluator.

Only approved pinned lower definitions run:32fd lossless native JSON/Audit and
placement metrics;72131 complete native tables/report topology with isolated8601;
the NEW recorder's pure command/runtime/definitions/qualification chain and its
individually pinned TEN parsers. No old high-level graph, physical or timing proof
is invoked. Called parser/project-module paths must be in the own input ledger.

The new supported one-path guide ea8eb811/origin c95af436 is independently bound
to closed current ready0 full profile79e71/runb76ff/report826d and own selected
graph11b385. The complete report object at source index1 and tied index2975 are
kept exactly, including signed delays, metadata, clocks, window and locations.
Original native routing edges/aliases, declared two ordinary LUT records and
all path-cell records/ports/BELs match the actual TEN baseline. The complete
same-LAB root input-user partition must be exactly two FF.ENA slots with the
same clock. All15 original target-LAB FF records are independently reconstructed.
Source current full-route completion/input/output/read-audit/runtime closure is
bound; its rejected timing and historical physical frame are never inherited.

Fresh argv retains literal TEN plan00bf, all ten descriptors, source JSON/QSF/SDC,
device/seed/cwd/environment and runtime libraries. The historical invocation's
only changes are explicit current ELF/PATH, fresh output aliases, compose-copy
listing mode and ready0→ready1 pair-guide path. Candidate=-1 and no-route remain.
No post plan, driver, RBF, routing, replay or skipped packing/placement is allowed.
The earlier extra ready0 composed copy is not stacked: the entire fresh native
image must still match the original TEN references exactly.

All14,907 cells/16,645 aliases, complete native module/interface/settings/metadata,
types/tables/control slots, literal raw IDs, nested owner/port/list ordering,
lossless paired PLLs, full raw driver/user occurrence tables and8,221 FF records/
BELs remain strict against all three images. Only separate document creator
strings may differ as disclosed compiler provenance. No private-owner/raw-ID
alignment, metadata or pin-map exemption, buffer collapse or unexported cache
equivalence is allowed.

Freshly parsed TEN model dictionaries,71 placement rows and the ENTIRE own
predicted report must equal all three references. Saved diagnostic flags must
match the independent comparisons. Four images independently validate all15,290
native paths/seven clock-pair endpoint/window sets, cap16,384 and finite signed
terms. Own predicted Fmax is read from its actual fresh report, not inherited.
Structural, model/copy-log and topology rejections remain separate and current
report evidence/final full path rehash survive structural failure.

The current strict copy parser is invoked on the complete fresh log. It covers
0..8 cone identities, supported phase-specific terminal rejections, composition/
domain records, at most16 distinct-tile trials per cone/128 total and contiguous
candidate indices. Each qualified candidate must bind its actual preceding
same-identity/BEL/cohort trial, allfive strict guards and gain>=250ps. No ready0
trial count/domain/mask/site/gain, candidate0 existence or qualification is assumed.
Listing applies no candidate. A zero-qualified result can prove exact rollback,
but fresh_selected_composed_copy_prerequisite_available remains FALSE.

Only all gates permit fresh_lut_pair_copy_listing_reproduction_proved. A positive
listing establishes rollback/report reproduction; actual selection and independent
conditional function, routed graph/physical/timing proofs remain necessary.
No numerical STA calibration, routed gain, decoded RBF or hardware claim is made.
Accepted FIVE117.771759MHz remains a separate future timing threshold.
