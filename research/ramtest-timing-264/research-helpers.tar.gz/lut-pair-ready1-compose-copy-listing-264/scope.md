# Fresh ready1 composed-copy listing recorder

This new recorder owns only run_listing.py and this scope. ROOT alone imports,
AST-checks, prepares and executes it. It uses the existing frozen cae5eb9a
compiler/ELFa2b5/archivec64e/host844162, with58 native and51 CLI cases already
closed; no fresh compiler change or repeated test claim is introduced.

The three direct TEN references remain the e137 diagnostic b894/f080/12a957,
old5a listing53f82/15e5/94627 and disabled control d8c15/581f/9498, including
strict originald7e/b3d parity. Their flat original-path input/runtime/output
closures, full TEN model dictionaries, literal TEN00bf descriptors and8,221 FF
BELs remain fixed. The new listing must separately reproduce the complete
native graph,71 metrics and full predicted report; this recorder records the
metrics/report comparisons diagnostically and grants no graph equality.

The guide is NEW ready1 ea8eb811, origin c95af436. It contains only the supported
critical_paths field and the exact unchanged full current report row1 from
ready0 composed-copy route b76ff696/profile79e71/report826d. Tied row2975 remains
separately recorded. The source closed profile/run union, current compiler/host,
full report, selected native graph11b38575, output/runtime/input ledgers and
route recorder89fcae45/scope51246f72 are bound and rehashed before/after.
The routed guide supplies a search target, never an inherited graph, physical
truth, candidate qualification or gain acceptance.

The guide observation derives its final two ordinary LUT owners and terminal
FF.ENA from the actual routing segments. Every original path cell/port/BEL
location and native routing net alias is checked against the own selected image
AND the unchanged TEN baseline. Complete same-LAB outer.Q input consumers must
be exactly the two same-clock byte-enable FF4/FF5 in LAB25.20, as observed by
the immutable origin. Full target FF records and all15 original LAB FFs are
recorded; future placements/sites/Q IDs/gains are not assumed. No pin/cache or
composed-function proof is granted from this observation.

Fresh argv comes from the closed e137 diagnostic invocation. The reviewed delta
still changes only ELF/PATH/write/report aliases and adds compose-copy; the
NEW explicit delta additionally replaces the ready0 pair-report path with the
ready1 guide path. Source synth/device/QSF/SDC/seed/TEN/internal/decomposition
options, cwd, GPU1 FunctionalInvocation/runtime files and environment remain
fixed. Candidate=-1 and --no-route are retained; no RBF, post-plan, driver copy,
processed graph, skipped placement/packing or applied candidate is allowed.
This alternative preserves all TEN copies but does not stack the extra ready0
composed copy.

Only pinned lower control definitions/TEN qualification and32fd read_netlist
are reused, with all called parser paths in the input/pure-helper closure.
No old prepare/execute/main/authenticator or comparison evaluator is called.
The lossless paired-PLL reader is needed for the guide-source native observation;
it does not qualify a previous routed physical frame.

The NEW copy parser is the reviewed e2c listing parser: exact discovery cone
identity completeness, supported rejection phases, composition/domain rows,
up to8 cones/16 distinct-tile trials percone/128 total trials and contiguous
qualified candidate indices. Every actual candidate binds its immediately
preceding same-identity/BEL/cohort trial with allfive strict guards andgain>=250.
Zero candidates is valid. All actual raw copy rows and complete log are retained.
No ready0 trial/domain/mask/cohort outcome or candidate0 existence is assumed.

Actual completion requires the same10 complete early models,16384 report cap,
15,290 current paths and finite positive Fmax fields. No source graph replay or
historical private-output alignment is used. Current source/model/submodule,
all loadedfive project modules/read-audit, inputs/runtime/outputs and hashes
are rechecked on success or retained partial failure.

Outputs are exclusive source-identity.json and listing/{run.json,phase.log,
placed.json,timing.json} here. Prepare requires explicit actualself/scope/binary/
archive/host hashes; execute requires the resulting actualprofile hash. This
record supplies no selected transformation, functional/native/physical/cache
equivalence, independent numerical STA, routed gain, RBF decode or hardware
claim. Separate listing reproduction, actual selection and fresh routing/
physical/timing proofs remain necessary before acceptance.
