"""Root-only sealing after finalized, structurally proved and timing-rejected g8."""
import json
from pathlib import Path
from compare import (HERE, FULL, LIST, PROFILE, HELPER, HELPER_SHA, DELTA, authenticate_references,
                     expected_command, frozen_helper, require, sha)


def seal():
    require(not PROFILE.exists(), "profile already sealed")
    g8 = frozen_helper()
    record, full, listing = authenticate_references(g8)
    expected_command(record["command"])
    paths = {Path(path) for path in record["input_sha256"]}
    paths |= {g8.ready.ROOT / path for proof in (full, listing) for path in proof["artifact_sha256"]}
    paths |= {folder / "comparison.json" for folder in (FULL, LIST)}
    paths |= {HERE / name for name in ("seal_profile.py", "route.py", "compare.py")}
    paths.add(HELPER)
    digests = {str(path): sha(path) for path in sorted(paths)}
    require(all(digests[path] == digest for path, digest in record["input_sha256"].items()), "g8 run inputs changed")
    profile = {"schema": 1, "reference_full": str(FULL), "reference_listing": str(LIST),
               "helper_sha256": HELPER_SHA, "gpu_delta": DELTA, "input_sha256": digests}
    require(all(sha(Path(path)) == digest for path, digest in digests.items()), "seal inputs changed during authentication")
    with PROFILE.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"profile": str(PROFILE), "sha256": sha(PROFILE), "inputs": len(digests)}, indent=2))


if __name__ == "__main__":
    seal()
