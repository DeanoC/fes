# GPU repair-band trial

Measured compiler: `6ad210a60991f93a607ac4490d6282b1267ec64a`; source and binary unchanged from the groups8 precursor. The only routing override was `--gpu-opt repairBand=3000`; all other retained inputs, seed, GPU, placement, transformations and options were unchanged.

The full route completed in 832.557983405 seconds with exit zero and no reported final hold violations. Achieved memory/pixel/capture-clock frequencies were **112.536575 / 93.896713 / 407.795502 MHz**. The phase-shifted capture-to-memory transfer used 1.594 ns of its reported 5 ns setup window, leaving 3.406 ns.

Independent comparison passed the complete actual graph, original pin/BEL, BUF/user, local/comb/placed11/decomposition truth, clock and provenance checks. All 71 ordinary placement metrics matched. Cached reference proofs were bound to their complete artifact closures; no unchanged historical graph comparison was executed again. The one actual settings difference (`gpurouter/repairBand`) was explicitly verified and aligned only in the algebraic reference.

**Rejected as a timing improvement.** Capture-clock margin recovered, but memory fell below the retained 116.171005 MHz result. No default recipe or hardware selection changed. Raw measurements, comparison, source/binary/profile hashes and invocation are adjacent.
