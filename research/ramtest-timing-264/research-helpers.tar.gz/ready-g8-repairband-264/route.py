"""Root-only fresh route; only repairBand3000 differs from sealed groups8 profile."""
import json
from pathlib import Path
import subprocess
import sys
import time
from compare import HERE, FULL, LIST, OUTPUT, PROFILE, DELTA, expected_command, load_profile, require, sha


def route():
    profile, g8, base = load_profile()
    require(not OUTPUT.exists(), "route output already exists")
    require(base["compiler_commit"] == g8.RESULT_COMMIT and base["decomposition_selection"] == 0 and
            base["list_only"] is False, "source/candidate/profile changed")
    module = Path(base["cwd"])
    sys.path.insert(0, str(module))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    from scripts.search_placer_qor import _score_report, has_failed_route_arc
    from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS
    binary = Path(base["command"][0])
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(binary, base["tool_identity"])}, 1)
    command = expected_command(base["command"])
    env = dict(invocation.env)
    env["NEXTPNR_MISTRAL_CAPTURE_LOCALITY"] = base["experimental_capture_locality"]
    env["NEXTPNR_MISTRAL_PLACED_REDUCTION"] = base["experimental_placed_reduction"]
    record = {**base, "command": command, "kind": "scratch groups8 repairBand3000 full HIP route; unselected",
              "runner_sha256": sha(HERE / "route.py"), "comparator_sha256": sha(HERE / "compare.py"),
              "profile_sha256": sha(PROFILE), "gpu_routing_delta": DELTA,
              "profile_run": str(FULL), "listing_reused_from": str(LIST), "execution": invocation.inputs,
              "input_sha256": {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}, "completed": False}
    for key in ("exit_code", "elapsed_seconds", "fmax", "final_reported_hold_violations"):
        record.pop(key, None)
    g8.ready.authenticate_execution(record, base)
    OUTPUT.mkdir()
    manifest, started = OUTPUT / "run.json", time.monotonic()
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    try:
        with (OUTPUT / "route.log").open("x") as log:
            result = audited_run(command, source_root=module, cwd=module, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, check=False, timeout=2400)
        record["exit_code"] = result.returncode
        record["elapsed_seconds"] = time.monotonic() - started
        invocation.verify()
        for filename, digest in record["input_sha256"].items():
            require(sha(Path(filename)) == digest, "route input changed: " + filename)
        log = (OUTPUT / "route.log").read_text()
        require(result.returncode == 0 and "Info: Program finished normally." in log and not has_failed_route_arc(log),
                "route did not complete normally")
        board._require_gpu_backend(log)
        require((OUTPUT / "core.rbf").stat().st_size > 0 and "Running signoff timing analysis..." in log,
                "full RBF/signoff is absent")
        record["final_reported_hold_violations"] = "Hold/min time violation" in log.rsplit("Running signoff timing analysis...", 1)[1]
        report = g8.read(OUTPUT / "timing.json")
        _score_report(report, REQUIRED_CLOCKS)
        require(set(report["fmax"]) == {name for name, _ in REQUIRED_CLOCKS}, "required clocks changed")
        record["fmax"], record["completed"] = report["fmax"], True
        print(json.dumps({key: record[key] for key in ("elapsed_seconds", "fmax", "final_reported_hold_violations")}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        record["elapsed_seconds"] = time.monotonic() - started
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
        invocation.close()


if __name__ == "__main__":
    route()
