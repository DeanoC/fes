"""Root-operated, full-route GPU-option trial using frozen groups8 proofs."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
G8 = HERE.parent / "ready-g8-decomposition-264"
FULL, LIST = G8 / "route-c0", G8 / "list"
OUTPUT = HERE / "route-band3000"
PROFILE = HERE / "profile.json"
HELPER = G8 / "compare_control_decomposition.py"
HELPER_SHA = "132c1ecb34fd4e26e5b0ddc40f72f1e65e7e9ace0c4af5df67c5d8fc01903bb0"
DELTA = ["--gpu-opt", "repairBand=3000"]
OUTPUTS = {"--write": "routed.json", "--report": "timing.json", "--rbf": "core.rbf"}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite JSON value: " + value)
    return json.loads(path.read_text(), object_pairs_hook=pairs, parse_constant=nonfinite)


def frozen_helper():
    require(sha(HELPER) == HELPER_SHA, "frozen groups8 helper changed")
    spec = importlib.util.spec_from_file_location("frozen_g8_repair_reference", HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def authenticate_references(g8):
    """Bind root-validated cached proofs to every artifact, without replaying them."""
    proofs = []
    for folder in (FULL, LIST):
        proof = read(folder / "comparison.json")
        record = read(folder / "run.json")
        require(proof["final_metadata_stable_during_comparison"] and proof["candidate_completed"] and
                proof["compiler_commit"] == record["compiler_commit"] == g8.RESULT_COMMIT and
                proof["list_only"] is record["list_only"], "cached groups8 proof is not finalized")
        for filename, digest in proof["artifact_sha256"].items():
            artifact = (g8.ready.ROOT / filename).resolve()
            require(artifact.is_relative_to(g8.ready.ROOT) and sha(artifact) == digest,
                    "cached proof artifact changed: " + filename)
        required = [folder / "run.json", folder / "route.log", HELPER, G8 / "route.py"]
        required += [folder / "placed.json"] if record["list_only"] else [folder / name for name in OUTPUTS.values()]
        for artifact in required + [Path(path) for path in record["input_sha256"]]:
            require(proof["artifact_sha256"].get(g8.relative(artifact)) == sha(artifact), "cached proof omits an input/artifact")
        require(sha(G8 / "route.py") == g8.SEALED_RUNNER, "frozen groups8 runner changed")
        proofs.append(proof)
    full, listing = proofs
    record = read(FULL / "run.json")
    require(record["completed"] is True and record["exit_code"] == 0 and record["list_only"] is False and
            not record["final_reported_hold_violations"], "g8 full route is not a completed hold-clean reference")
    require(full["graph_proof_available"] and full["actual_local_and_ac_selected_prefix_match_fresh_listing"] and
            not full["passes_strict_diagnostic_gate_vs_116"], "repair trial requires proved g8 graph and rejected timing")
    require(listing["partial_graph_evidence_available"] and not listing["graph_proof_available"] and
            listing["decomposition_selection"]["none_applied"] and
            listing["decomposition_selection"]["qualified_candidates"] > record["decomposition_selection"] == 0,
            "fresh listing does not qualify selected candidate zero")
    return record, full, listing


def expected_command(base, folder=OUTPUT):
    command = list(base)
    require("--gpu-opt" not in command and "--no-route" not in command, "baseline has unexpected routing override")
    for option, name in OUTPUTS.items():
        require(command.count(option) == 1, "missing/repeated baseline output option")
        index = command.index(option) + 1
        require(index < len(command) and command[index] == str(FULL / name), "baseline output path changed")
        command[index] = str(folder / name)
    return command + DELTA


def load_profile():
    profile = read(PROFILE)
    require(set(profile) == {"schema", "reference_full", "reference_listing", "helper_sha256", "gpu_delta", "input_sha256"} and
            profile["schema"] == 1 and profile["reference_full"] == str(FULL) and profile["reference_listing"] == str(LIST) and
            profile["helper_sha256"] == HELPER_SHA and profile["gpu_delta"] == DELTA, "sealed bounded profile changed")
    for filename, digest in profile["input_sha256"].items():
        require(sha(Path(filename)) == digest, "sealed profile input changed: " + filename)
    g8, base = frozen_helper(), read(FULL / "run.json")
    require(base["completed"] is True and base["exit_code"] == 0 and base["list_only"] is False,
            "sealed reference is incomplete")
    return profile, g8, base


def comparison():
    profile, g8, base = load_profile()
    inputs = {**profile["input_sha256"], str(PROFILE): sha(PROFILE)}
    output_digests = {str(OUTPUT / name): sha(OUTPUT / name) for name in
                      ("run.json", "route.log", "routed.json", "timing.json", "core.rbf")}
    record, report, _, log, route = g8.previous.route_evidence(OUTPUT)
    require(type(record["elapsed_seconds"]) in (int, float) and math.isfinite(record["elapsed_seconds"]) and
            record["elapsed_seconds"] >= 0, "elapsed time is not final")
    reference, full_proof, listing_proof = authenticate_references(g8)
    require(reference == base and record["command"] == expected_command(base["command"]) and
            record["input_sha256"] == inputs, "new run exceeds the single literal GPU/output delta")
    new = {"profile_sha256", "comparator_sha256", "gpu_routing_delta", "listing_reused_from", "profile_run"}
    mutable = {"command", "input_sha256", "execution", "runner_sha256", "kind", "completed", "elapsed_seconds",
               "exit_code", "fmax", "final_reported_hold_violations"}
    require(set(record) == set(base) | new and all(record[key] == value for key, value in base.items() if key not in mutable),
            "retained run metadata changed")
    require(record["profile_sha256"] == inputs[str(PROFILE)] and record["runner_sha256"] == inputs[str(HERE / "route.py")] and
            record["comparator_sha256"] == inputs[str(HERE / "compare.py")] and record["gpu_routing_delta"] == DELTA and
            record["listing_reused_from"] == str(LIST) and record["profile_run"] == str(FULL), "trial provenance aliases disagree")
    verified = g8.previous.authenticate_inputs(record)
    source, parent_source = g8.authenticate_compiler(record)
    disabled = full_proof["disabled_loader_equivalence"]
    g8.ready.authenticate_execution(record, base)
    parent_record, parent_report, _, parent_log, _ = g8.previous.route_evidence(g8.BEST)
    plans = g8.authenticate_profile(record, parent_record)
    parent_proof = g8.read(g8.BEST / "comparison.json")
    require(parent_proof["graph_proof_available"] and parent_proof["local_clone_count"] == 3 and
            parent_proof["comb_clone_count"] == 1 and inputs.get(str(g8.BEST / "comparison.json")) ==
            sha(g8.BEST / "comparison.json"), "cached parent116 full proof is not bound")
    control_record, control_report, _, control_log, _ = g8.previous.route_evidence(g8.staged.CONTROL)
    metrics = g8.previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and metrics == g8.previous.PLACEMENT_METRICS.findall(parent_log) ==
            g8.previous.PLACEMENT_METRICS.findall((FULL / "route.log").read_text()), "ordinary placement metrics changed")
    prefix = g8.retained_placed_prefix(log, plans["placed_specs"][0], True)
    stack = g8.ready.transform_stack(log, control_log)
    placed_selection = g8.ranking.verify_selection(prefix, plans["placed_specs"][0])
    listing_log = (LIST / "route.log").read_text()
    selected, candidates = plans["selection"], list(g8.CANDIDATE.finditer(log))
    reference_candidates = list(g8.CANDIDATE.finditer(listing_log))
    require(0 <= selected < len(reference_candidates) and candidates and candidates[-1].group(0) ==
            reference_candidates[selected].group(0), "actual AC candidate differs from reused fresh listing")
    messages = lambda text, stop: [line for line in text[:stop].splitlines() if "Decomposition" in line]
    require(messages(log, candidates[-1].end()) == messages(listing_log, reference_candidates[selected].end()) and
            g8.local_models(log, plans) == g8.local_models(listing_log, plans), "actual local/AC selected prefix changed")
    top = g8.read_netlist(OUTPUT / "routed.json")["modules"]["top"]
    same_top = g8.read_netlist(FULL / "routed.json")["modules"]["top"]
    expected_settings = {**same_top["settings"], "gpurouter/repairBand": "3000"}
    require(same_top["settings"]["gpurouter/repairBand"] == "300.000000" and top["settings"] == expected_settings,
            "actual routed settings exceed repairBand3000")
    old_top = g8.read_netlist(g8.BEST / "routed.json")["modules"]["top"]
    require(old_top["settings"] == same_top["settings"], "parent reference settings differ beyond proved groups8 profile")
    proof_error, proof, extension, locals_, composed, placed = None, None, None, None, None, None
    try:
        aligned, extension = g8.ready_alignment(old_top, top, plans, log, parent_proof)
        # Explicit control-metadata alignment only; actual exports remain untouched.
        aligned["settings"]["gpurouter/repairBand"] = top["settings"]["gpurouter/repairBand"]
        proof = g8.prove_rewrite(aligned, top, g8.read(plans["guide"]))
        locals_, composed, placed = g8.replay_actual_stack(top, plans, log, parent_proof)
    except ValueError as error:
        proof_error = str(error)
    reports = {"parent_116": parent_report, "g8_same_profile": g8.read(FULL / "timing.json"),
               "control_115": control_report, "baseline_108": g8.read(g8.staged.BASE / "timing.json"),
               "ready_control_113": g8.read(g8.comb.READY_CONTROL / "timing.json")}
    require(set(report["fmax"]) == set(g8.ready.REQUIRED_CLOCKS) and all(
            report["fmax"][clock]["constraint"] >= nominal for clock, nominal in g8.ready.REQUIRED_CLOCKS.items()),
            "required clock set/constraints changed")
    clocks = {label: g8.previous.compare_clocks(before, report) for label, before in reports.items()}
    raw = {label: all(row["gain_mhz"] >= 0 for row in values.values()) and values[g8.ready.MEMORY_CLOCK]["gain_mhz"] > 0 and
           not route["final_reported_hold_violations"] for label, values in clocks.items()}
    gates = {label: passed and proof_error is None for label, passed in raw.items()}
    result = {"status": "experimental GPU repairBand3000; unselected", "compiler_commit": record["compiler_commit"],
              "source": source, "unchanged_6ad_precursor_source": parent_source, "authenticated_inputs": verified,
              "disabled_loader_equivalence": disabled, "gpu_routing_delta": DELTA, "profile_sha256": sha(PROFILE),
              "reference_full": str(FULL), "reused_fresh_listing": str(LIST), "no_new_listing_claimed": True,
              "cached_reference_proofs_artifact_bound": True, "cached_disabled_loader_proof_artifact_bound": True,
              "no_transitive_cached_graph_proof_reexecution": True,
              "cached_proof_bindings": {str(folder / "comparison.json"): inputs[str(folder / "comparison.json")]
                  for folder in (FULL, LIST, g8.BEST)},
              "actual_local_and_ac_selected_prefix_match_fresh_listing": True, "matched_placement_metrics": len(metrics),
              "retained_transform_stack": stack, "retained11_selection": placed_selection,
              "routing_settings_reference_adjustment": {"key": "gpurouter/repairBand", "before": "300.000000", "after": "3000",
                  "all_other_routed_settings_identical": True, "algebra_only_reference": True, "actual_exports_unchanged": True},
              "candidate_completed": True, "list_only": False, "elapsed_seconds": record["elapsed_seconds"], "exit_code": 0,
              "candidate_route": route, "graph_proof_available": proof_error is None, "structural_rejection": proof_error,
              "decomposition_selection": g8.verify_decomposition_log(log, selected, proof if proof_error is None else None),
              "ready_g8_equivalence": extension if proof_error is None else None,
              "decomposition_equivalence_on_ready_aligned_original_graph": proof if proof_error is None else None,
              "retained_local_clone_equivalences": locals_ if proof_error is None else None,
              "retained_comb_equivalence": composed if proof_error is None else None,
              "retained_placed11_symbolic_equivalence": placed if proof_error is None else None,
              "fmax_comparisons": clocks, "all_clock_nonregression": {label: all(row["gain_mhz"] >= 0 for row in values.values())
                  for label, values in clocks.items()}, "passes_raw_timing_gates_without_isolation_acceptance": raw,
              "passes_strict_diagnostic_gates": gates, "passes_strict_diagnostic_gate_vs_116": gates["parent_116"],
              "passes_strict_diagnostic_gate_vs_115": gates["control_115"], "passes_strict_diagnostic_gate_vs_108": gates["baseline_108"],
              "passes_all_clock_constraints": all(row["meets_constraint"] for row in clocks["parent_116"].values()),
              "critical_path_comparisons": g8.ready.critical_path_comparison(parent_report, report),
              "default_recipe_selected": False, "hardware_tested": False}
    if proof_error is None:
        result.update({"local_clone_count": 3, "comb_clone_count": 1,
                       "selected_ff_ena_count": sum(row["selected_ff_count"] for row in locals_),
                       "required_target_ena_coverage_proved": extension["required_target_ena_coverage_proved"],
                       "lossless_pll_port_audit": proof["lossless_pll_port_audit"],
                       "retained_selected_ena_arrival_comparisons": g8.staged.selected_ena_arrivals(locals_, {**reports, "candidate": report})})
    else:
        result.update({"status": "rejected GPU repairBand3000; actual graph/pin/BUF/truth proof failed",
                       "candidate_accepted": False, "raw_timing_diagnostic_only": True})
    digests = {**inputs, **output_digests}
    require(all(sha(Path(filename)) == digest for filename, digest in digests.items()), "immutable evidence changed during comparison")
    result.update({"artifact_sha256": {g8.relative(Path(filename)): digest for filename, digest in digests.items()},
                   "final_metadata_stable_during_comparison": True})
    return result


if __name__ == "__main__":
    result = comparison()
    (OUTPUT / "comparison.json").open("x").write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: result[key] for key in ("status", "graph_proof_available", "structural_rejection",
          "candidate_route", "fmax_comparisons", "passes_strict_diagnostic_gates")}, indent=2))
