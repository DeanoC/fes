# Saved Quartus hints for the HPS-ready remap

Read-only inspection, 2026-09-30; base FES `7ce9926941a5f72cc3ca4b0ed61b7b06e76e5304`. No Quartus query/build, OSS route, tracked edit, or hardware operation.

`current/` below means `out/ramtest-compiler-gains/quartus-current-matched/` in the compiler-gains FES worktree. `old/` means `/home/deano/kepler/worktrees/fes-fes-ramtest-oss-lane-timing-264-17a49c0d/out/ramtest-quartus-control-cones/`. These are different saved fits.

## Endpoint distinction

The frozen OSS 115.380 critical endpoint is **output address** `hps_ddr.m1_address_MISTRAL_FF_Q_18` ENA, confirmed directly in `placed-reduction-root-slack/route-local-r6-s0/timing.json` and `routed.json`. Its two LUTs are `slot_free_MISTRAL_ALUT2_Q` at 33,19 and `slot_free_MISTRAL_ALUT4_C` at 25,19, with the FF at 24,13. The outer root has 109 FF ENA consumers across 22 LABs.

The saved one-LUT Quartus precedent below controls **skid address**. It is an adjacent command-control cone, not proof of the exact function proposed for the present output-address endpoint.

## Current saved fit

- `current/ready1-all.rpt:262-279` reports ready1 → `port1|m_address[8]` ENA with **two logic levels**, 4.329 ns data delay and +2.475 ns setup slack at a 7.692 ns relationship. `:376-389` identifies `slot_free` at MLAB 34,63,N33 (fanout 4), then `m_address[0]~0` at MLAB 34,63,N12 (fanout 107), then FF 36,62,N47 ENA. The two control LUTs share one LAB; the sink is nearby. This report supplies no fitted truth table for these cells.
- `current/ready1-skid-address.rpt:55-72` reports ready1 → `skid_address[24]` ENA with **one logic level**, 3.830 ns data delay and +2.968 ns slack. `:169-177` identifies its sole cell `skid_byteenable[0]~0` at MLAB 34,63,N39, fanout 109, and FF 37,62,N34 ENA. The saved timing report proves depth and placement, not this newer fit's active input count or Boolean mask.
- Both ready reports expose the HPS signal's physical exit at HIO_BUFFER 51,64 (`ready1-all.rpt:157`, `ready1-skid-address.rpt:158`). Compare signal-exit geometry with the frozen OSS route beginning at GIN 51,64,18, rather than using the HPS BEL anchor 52,53 as the exit.
- `current/project/output_files/top.fit.rpt:587-589` explicitly records routability duplicates of port1 draining, finishing and owed_zero registers. It does not record duplication of the ready-control root.

## Older saved fitted connectivity: concrete five-input precedent

- `old/nodes.tsv:5025` places node 5096 `port1|skid_write~0` at LABCELL 35,62,N9. `old/inputs.tsv:3169-3173` shows exactly five active inputs: DATAA=m_read, DATAC=filler, DATAD=m_write, DATAE=from_core~0, DATAF=cmd_ready_1. DATAB is unused.
- `old/outputs.tsv:950` records mask `50F55FF00000000` and 109 consumers. Rechecked directly over 64 physical truth rows (32 unique active-input combinations), the function is `(m_read | m_write) & ~cmd_ready_1 & (filler | from_core)`. The saved Quartus textual-mask ordering is row 0 at the leftmost padded binary bit, with DATAA as row-index bit 0; ordinary LSB-first integer decoding would reverse it.
- The raw fanout list resolves to109 FFs, all input-port 7. The exact `old/reports/ready1-address27.rpt:37-53,149-156` endpoint is skid_address[27] ENA at FF 37,62,N25; its only logic cell is node 5096, with 3.427 ns data delay and +3.385 ns slack at 7.692 ns. Across all 109 consumers, the raw node inventory has 19 LABs within X34..40/Y59..66. This is evidence of a single shared root and a compact consumer neighborhood, not per-LAB root replication.
- `old/outputs.tsv:3` gives ready1 two direct consumers: the original slot_free node 4081 and composed skid-enable node 5096. The original slot_free is retained at LAB 35,62,N42 (`nodes.tsv:4010`), with 4 consumers (`outputs.tsv:934`). Thus the broader cut coexists with the shared original slot_free, as a generic composition/cloning strategy should preserve other consumers.
- Node 4203 `from_core~0` at LAB 35,60,N36 (`nodes.tsv:4132`) receives finishing/draining duplicate FFs from 35,60/N28 and 34,60/N55 (`inputs.tsv:3119-3124`, `nodes.tsv:16034-16035`). This shows nearby duplicated state feeding the precondition; it does not show duplication of the 109-consumer enable root.
- Older output-address root node 4204 `m_address[0]~0` is at LAB 35,62,N15 (`nodes.tsv:4133`), alongside the original slot_free. The saved selected connectivity omits node 4204 inputs/output, so no exact composed five-input output-address implementation can be claimed from this older inventory.

## Implication and limits

A one-LUT, five-active-input ready-control cut **exists in saved Quartus evidence**, for skid ENA. The comparable output-address ready path remains two LUTs in the current saved fit, packed into one LAB. The practical hints are preserving the shared original cone, choosing a broader verified Boolean cut where useful, and keeping ready-control logic and consumers near the physical HPS exit. Neither LUT reduction alone nor replicating the root predicts a routed gain for frozen OSS 115.380.

Current Quartus BUILD_ID is `52991ce22369904849b68bdd900f9ae1`; older-fit BUILD_ID is `cd3e4c315005fde83065dff7483ae0d7`; frozen OSS BUILD_ID is `7168b508ab424b70f1c0f87b2035d821`. Quartus also omits RAM_OSS_HIGH_SPEED and uses native PLL/SDC and different timing models. These observations are mapping/locality evidence, **not equivalent physical-route timing calibration, whole-design elaboration equivalence, or new hardware acceptance**.

## Recomputed SHA256

| Source | SHA256 |
| --- | --- |
| `current/ready1-all.rpt` | `a855a13af64150777f120bc4f3ff5ea07ea885801c1e51c3f0a2411d94380e49` |
| `current/ready1-skid-address.rpt` | `95126b15cbaef3e63fadceb80a8a0175e8addeeda0d501c700b112f53e96a0bd` |
| `current/project/top.qsf` | `db71b993984823bbfc4a9bfcc530a037280ea36a1ded8c9d7bc4acab7caff46d` |
| `current/project/output_files/top.fit.rpt` | `8db149dbb9e2d5afeca75cc81f29abe2ed0e113dcced4e16f58a8ccea4f4d75b` |
| `old/reports/ready1-address27.rpt` | `bb745e91e543bf72ddd14c0e7bc924ef2783c1cad70fcf3fa81471b6cff788b7` |
| `old/nodes.tsv` | `c26bc777db47bdad9b6f0920cec4318ba83514da3291a179e9f5d0662031d655` |
| `old/inputs.tsv` | `be83316202b87e0d6345c7a03cd02af16666c7c68bb394766cfb452ba50a06ab` |
| `old/outputs.tsv` | `2147fea902b78f065cd4bbb65860896c61df743e27abc6b6034bbaad43b3ae22` |
| `old/project/top.qsf` | `7dac9740dacdf217062ad3bf84b6b3c9080b19bb12ca148dc0e2fb68371e0f43` |
| `placed-reduction-root-slack/route-local-r6-s0/timing.json` | `2e301287ab5109ffae6f4ed801d94a9f5fd68923adb3031596fd54692ea2b4f4` |
| `placed-reduction-root-slack/route-local-r6-s0/routed.json` | `12b2b6e334d38ea113918d0c1800853cc77f1e6d6fbbf3a91d05b2d7b09b016e` |
| `route-slots-final/run.json` | `7706cd9268be473f1955ffab7b1bcd2b80b2835c36252b81f5edf10e52bae144` |
| `sources/misteross/docs/validation/2026-09-29-ramtest-fixed-input.md` | `4f39ee21b6c6528a3655fd1666a275ae4e44f0899604c06bbd4d9bb546d26984` |
