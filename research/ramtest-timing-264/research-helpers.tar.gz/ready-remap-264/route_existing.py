"""Route existing generic remapping on the frozen 115 MHz compiler stack."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
MODULE = ROOT / 'sources/misteross'
RAW = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation
from scripts.search_placer_qor import _score_report, has_failed_route_arc
from scripts.diagnose_fes_ramtest_timing import REQUIRED_CLOCKS

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--groups', type=int, default=1, choices=range(1, 9))
parser.add_argument('--candidate', type=int, default=0)
parser.add_argument('--pins', action='store_true', help='use the separately frozen optional pin-order compiler')
args = parser.parse_args()
assert args.candidate >= 0
control = RAW / 'placed-reduction-root-slack/route-local-r6-s0'
frozen = control.parent
previous = json.loads((control / 'run.json').read_text())
assert previous['completed'] and previous['exit_code'] == 0
for filename, digest in previous['input_sha256'].items():
    assert sha(Path(filename)) == digest
binary = frozen / 'nextpnr-mistral'
identity = previous['tool_identity']
compiler_commit = 'f2a8373d42dd0f2b0a422177b46d9d36ffc8a559'
if args.pins:
    frozen = HERE / 'pin-order'
    frozen_identity = json.loads((frozen / 'source-identity.json').read_text())
    binary = frozen / 'nextpnr-mistral'
    assert sha(binary) == frozen_identity['binary_sha256']
    identity = f"base_commit={frozen_identity['base_commit']}; experimental_source_sha256={frozen_identity['source_archive_sha256']}; sha256={sha(binary)}"
    compiler_commit = frozen_identity.get('result_commit', frozen_identity['base_commit'] + '+pin-order-experiment')
source = Path(previous['command'][previous['command'].index('--json') + 1])
qsf = MODULE / 'cores/fes-ramtest/constraints.qsf'
sdc = MODULE / 'boards/de10nano/clocks.sdc'
capture_report = RAW / 'route-slots-final/timing.json'
remap_report = control / 'timing.json'
archive = frozen / 'source.tar.gz'
output = HERE / (f'route-g{args.groups}-c{args.candidate}' + ('-pins' if args.pins else ''))
output.mkdir(exist_ok=False)
invocation = FunctionalInvocation({'nextpnr-mistral': board.AuthenticatedTool(binary, identity)}, 1)
cmd = [str(binary), '--json', str(source), '--device', '5CSEBA6U23I7', '--qsf', str(qsf), '--sdc', str(sdc),
       '--freq', '74.25', '--seed', '2', '--placer-heap-timingweight', '10', '--placer-heap-critexp', '2',
       '--router', 'gpu', '--replicate-enables', '4', '--timing-allow-fail', '--detailed-timing-report',
       '--balance-reduction-root', 'ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT6_F_E_MISTRAL_ALUT5_Q_1',
       '--remap-critical', str(remap_report), '--remap-candidate', str(args.candidate), '--remap-groups', str(args.groups),
       '--write', str(output / 'routed.json'), '--report', str(output / 'timing.json'),
       '--rbf', str(output / 'core.rbf'), '--compress-rbf', '--gpu-device', '1']
if args.pins:
    cmd.append('--remap-optimize-pins')
env = dict(invocation.env)
env['NEXTPNR_MISTRAL_CAPTURE_LOCALITY'] = previous['experimental_capture_locality']
env['NEXTPNR_MISTRAL_PLACED_REDUCTION'] = previous['experimental_placed_reduction']
record = {'kind': 'scratch route; no compiler or package selection', 'command': cmd, 'cwd': str(MODULE),
          'tool_identity': identity, 'compiler_commit': compiler_commit,
          'build_id': previous['build_id'], 'execution': invocation.inputs, 'completed': False,
          'control_run_sha256': sha(control / 'run.json'),
          'input_sha256': {str(p): sha(p) for p in (binary, archive, source, qsf, sdc, capture_report, remap_report)},
          'source_archive_sha256': sha(archive), 'capture_report_sha256': sha(capture_report),
          'remap_report_sha256': sha(remap_report), 'remap_groups': args.groups, 'remap_candidate': args.candidate,
          'experimental_capture_locality': env['NEXTPNR_MISTRAL_CAPTURE_LOCALITY'],
          'experimental_placed_reduction': env['NEXTPNR_MISTRAL_PLACED_REDUCTION']}
manifest = output / 'run.json'
manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
start = time.monotonic()
try:
    with (output / 'route.log').open('w') as log:
        result = audited_run(cmd, source_root=MODULE, cwd=MODULE, env=env, stdout=log,
                             stderr=subprocess.STDOUT, check=False, timeout=2400)
    record['exit_code'] = result.returncode
    record['elapsed_seconds'] = time.monotonic() - start
    invocation.verify()
    for filename, digest in record['input_sha256'].items():
        assert sha(Path(filename)) == digest
    log = (output / 'route.log').read_text()
    assert result.returncode == 0 and 'Info: Program finished normally.' in log and not has_failed_route_arc(log)
    board._require_gpu_backend(log)
    assert (output / 'core.rbf').stat().st_size > 0 and 'Running signoff timing analysis...' in log
    record['final_reported_hold_violations'] = 'Hold/min time violation' in log.rsplit('Running signoff timing analysis...', 1)[1]
    report = json.loads((output / 'timing.json').read_text())
    _score_report(report, REQUIRED_CLOCKS)
    assert set(report['fmax']) == {name for name, _ in REQUIRED_CLOCKS}
    record['fmax'] = report['fmax']
    record['completed'] = True
    print(json.dumps({'elapsed_seconds': record['elapsed_seconds'], 'fmax': record['fmax'],
                      'final_reported_hold_violations': record['final_reported_hold_violations']}, indent=2), flush=True)
except BaseException as exc:
    record['failure'] = repr(exc)
    raise
finally:
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    invocation.close()
