# DDR1 seven-LUT cone: routing evidence and bounded next targets

Read-only assessment, 2026-09-30. FES base `7ce9926941a5f72cc3ca4b0ed61b7b06e76e5304`; no tracked edits, builds, routes, compiler/package selection or hardware operation. This note compares the completed **unoptimized-pin** `route-g1-c0` trial using nextpnr `f2a8373d42dd0f2b0a422177b46d9d36ffc8a559` against the frozen 115.380 control. The separate pin-order trial is outside this evidence.

Paths below are relative to `out/ramtest-wide-reduction-264/`, except explicitly marked `old/` and `src/`. `control/` is `placed-reduction-root-slack/route-local-r6-s0/`; `candidate/` is `ready-remap-264/route-g1-c0/`; `src/` is `sources/misteross/build/toolchain-ramtest-timing/src/nextpnr/mistral/`. `old/` is `/home/deano/kepler/worktrees/fes-fes-ramtest-oss-lane-timing-264-17a49c0d/out/ramtest-quartus-control-cones/`.

## What actually changed

Memory Fmax changed from **115.38018035888672 to 113.77859497070312 MHz**. The newly worst same-clock memory path is logical `ddr1_test.idle[22]`, mapped to `ddr1_test.idle_MISTRAL_FF_Q_8` at `(37,16)`, through seven LUTs to `ddr1_test.beats_left_MISTRAL_FF_Q_6.ENA` at `(25,33)`. Its sum is **8.789000120 ns** against 7.691999912 ns. The control's worst memory path was the HPS ready-to-address cone; that does not provide the old exact DDR1 idle[22] path delay.

Every DDR1 LUT in the table retains exactly the same type, truth table, connections, BEL and serialized `FES_PINMAP_V1` in both routes. The source/sink FF types, truth-affecting parameters, BELs and pin maps also match. Their DATAIN bit identifiers shifted by two, but resolve to the same named generated ROUTETHRU driver cells; their Q/ENA net identifiers match. The only remap clone in this trial is the separate HPS `slot_free_MISTRAL_ALUT4_C$local_remap` at `(25,13)`, serving the selected two address ENA users. This is **unchanged DDR1 Boolean mapping and placement with changed data routing**, not a seven-LUT mapping introduced by the remap.

The memory-clock route contains 9,359 `(wire,pip,strength)` triples in each file. The multisets match exactly; its different serialized string reflects ordering only. Of the eight data nets on the DDR1 critical path, four have actual route-triple changes: idle[22], L3 Q, L5 Q and L6 Q. L1 Q, L2 Q, L4 Q and L7 Q have identical triple multisets. Thus comparing raw `ROUTING` strings alone overstates route changes. The detailed-net timing maximum at L7 Q → beats_left[6].ENA rises from 9.883999825 to 10.262999535 ns (+0.378999710), while its minimum stays 5.223999977 ns. These are endpoint fan-in summaries, not the precise old idle[22] path or an interchangeable Fmax calculation.

## Observed critical path

Each table row lists the incoming routing delay followed by that LUT's input-to-Q delay, in ns. LUT masks use logical A as truth-row bit 0; all relevant serialized logical input states are `PIN_SIG`.

| Label | Cell | Type/mask | BEL | Incoming route / logic |
| --- | --- | --- | --- | ---: |
| L1 | `ddr1_test.pass_end_MISTRAL_ALUT5_D_1_Q_MISTRAL_ALUT3_Q_C_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_Q` | ALUT4 `0x1` | `MISTRAL_COMB.37.16.12` | 1.298 / 0.512 (B) |
| L2 | `ddr1_test.pass_end_MISTRAL_ALUT5_D_1_Q_MISTRAL_ALUT3_Q_C_MISTRAL_ALUT5_Q` | ALUT5 `0x80000000` | `MISTRAL_MCOMB.39.16.42` | 0.640 / 0.097 (E) |
| L3 | `ddr1_test.pass_end_MISTRAL_ALUT5_D_1_Q_MISTRAL_ALUT3_Q` | ALUT3 `0x80` | `MISTRAL_MCOMB.34.16.30` | 0.701 / 0.097 (C) |
| L4 | `ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT2_Q_B_MISTRAL_ALUT2_Q` | ALUT2 `0x8` | `MISTRAL_COMB.33.13.6` | 0.991 / 0.097 (B) |
| L5 | `ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT2_Q` | ALUT2 `0x2` | `MISTRAL_COMB.33.13.54` | 0.277 / 0.097 (B) |
| L6 | `ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D` | ALUT4 `0xe400` | `MISTRAL_COMB.31.16.18` | 0.975 / 0.097 (D) |
| L7 | `ddr1_test.pass_end_MISTRAL_ALUT5_D` | ALUT5 `0x5f7f0000` | `MISTRAL_COMB.31.16.1` | 0.108 / 0.097 (E) |

The path includes +0.020 clock skew, 0.731 clock-to-Q, **7.140 routing**, **1.094 LUT logic**, and -0.196 setup. The final L7-to-ENA route alone is 2.150 ns. L7 drives eight FF ENAs in five LABs: `(35,12)` one, `(25,33)` one, `(33,12)` four, `(31,15)` one, `(30,14)` one. L6 drives 106 FF ENAs and L7 E; its high fanout is shared control, not private intermediate logic.

## Concrete generic targets and present limits

**Private 24-literal equality balance.** L3 is the root of an exclusive seven-LUT, three-level comparator for `idle == 24'd1000000` (`0x0f4240`), not idle==0. Each of three eight-bit branches uses ALUT4 then ALUT5; all six nonroot outputs have one internal consumer. Four ALUT6 leaves followed by an ALUT4 root can express the same 24 literals in five LUTs and two levels. The prefix through L3 takes 4.076 ns excluding skew: 0.731 clock-to-Q + 2.639 routing + 0.706 logic. Current reduction recognition accepts only three-LUT/11-literal or four-LUT/16-literal cubes, the planner stops after four LUTs, and placed reduction requires three cells. Two-LUT/eight-literal branches also do not match. Therefore neither existing placed11 nor reduction16 applies directly. A bounded generic placed24 extension is needed, including safe downstream reconvergence handling; see `ready-remap-264/next-remap-design.md` for the compositional proof, private-fanout inventory and guard assessment. Its canonical logical-graph SHA256 is `3e23bfe7ba716ab6e25d7195c9be510b322273db383401a4d61dfbbd81f99853`.

**Three-LUT/five-input internal cut.** L4/L5/L6 together have exactly five essential external inputs. In sorted routed net-bit order:

| Truth-row bit | Net bit | Driver endpoint | Essential toggle pairs |
| --- | ---: | --- | ---: |
| 0 | 22954 | `ddr1_test.state_MISTRAL_FF_Q_4.Q` | 4 |
| 1 | 23019 | `ddr1_test.write_MISTRAL_ALUT5_B.Q` | 2 |
| 2 | 23037 | `ram_clock.locked_MISTRAL_ALUT2_A_Q_MISTRAL_FF_DATAIN_1_Q_MISTRAL_FF_DATAIN.Q` | 6 |
| 3 | 23053 | `ddr1_test.state_MISTRAL_FF_Q_1.Q` | 4 |
| 4 | 23772 | L3 Q, timeout equality | 2 |

The 32-row composed mask is **`0x5000d080`**. Recomputed proof: for row variables `(a,b,c,d,e)` in the order above, `L4=a&e`, `L5=c&~L4`, then evaluate original `0xe400` at row index `a + 2*d + 4*b + 8*L5`. Every row equals the composed mask. The ascending-row output string is `00000001000010110000000000001010`, SHA256 `6902f19dd1f08ad0e64c1d8af5d6e412211784f52c697b76991d008add7ac8d6`. Each essential count is the number of unequal output pairs differing only in that variable; all are nonzero. This proves a single ALUT5 representation without sequential-state assumptions.

A bounded clone of this cut could feed **only L7 E**, preserving all original L4/L5/L6 side users and the original L6 root's 106 FF ENAs. It removes two LUT levels on the beats_left branch; observed L3→L6 routing plus logic is 2.534 ns, but that is not a predicted saving. New input loads, legal placement, actual route and setup/hold guards determine qualification. Rewriting L6 in place is a broader alternative affecting all 107 consumers and must independently establish ALUT5/ALM legality. The current local remapper only selects the last two LUTs ending directly at FF ENA groups, so it cannot discover/apply this internal three-LUT cut. Merely cloning L6 for its FF ENA users leaves L7 unchanged and does not help this endpoint.

**The existing final-pair remap rejects correctly.** L6+L7 have seven distinct essential external inputs. Exhaustive 128-row evaluation has 26 true rows; every input has a nonzero toggle-pair count. No pin permutation can fit that cut into the remapper's six-input limit. Earlier adjacent cuts L1+L2 and L2+L3 have eight and seven essential inputs respectively. L3+L4 and L4+L5 fit small LUTs but do not end directly at FF ENA groups.

**Placement/replication opportunity is already screened.** L7 is physically far from the critical single FF at `(25,33)`. Candidate `route.log:229-230` records existing enable replication considering this exact L7 root, five LAB groups/five signal inputs, followed by zero accepted replicas with budget four. Raising the budget alone does not address a candidate that already failed qualification. The saved log does not identify the rejecting gain/input-delay/legality guard. An optional bounded placement or clone search can probe this locality target while preserving input and endpoint slack, but no routed gain is established. L6's mixed FF/LUT consumers exclude it from the current pure-enable replication pass.

## Saved Quartus comparison

`old/reports/idle14-beats2.rpt` reports DDR1 idle[14] → beats_left[2] **D**, with three LUT levels, 4.048 ns data delay and +3.414 ns slack at 7.692 ns. Its fitted cells are `Equal13~2` at `(33,59,N42)` (fanout 7), `beats_left[5]~1` at `(34,62,N6)` (fanout 3), and `Selector51~0` at `(30,60,N24)` (fanout 1), followed by the FF at `(30,60,N26)`. This supports shallower factored comparator/control mapping and nearby logic, not equality of that D function with the current ENA cone. The previously saved DDR2 timeout→address ENA path likewise has three levels and parallel six-bit equality factoring; it is a mapping hint for a generic literal reduction.

Quartus older BUILD_ID `cd3e4c315005fde83065dff7483ae0d7`, current saved fit `52991ce22369904849b68bdd900f9ae1`, and this OSS BUILD_ID `7168b508ab424b70f1c0f87b2035d821` differ. Quartus omits RAM_OSS_HIGH_SPEED and uses native PLL/SDC/timing models. These saved fits are **not equivalent physical-route timing calibration, whole-design elaboration equivalence or hardware acceptance**. Ready-path detail and its separate five-input skid-enable precedent remain in `ready-remap-264/quartus-hints.md`.

## Evidence hashes

SHA256 was recomputed from the saved files below. `src/` hashes identify the read-only reviewed source snapshot, including the separately uncommitted optional pin-order code; they do not assert that the completed f2a8373d route used those uncommitted bytes.

| Source | SHA256 |
| --- | --- |
| `control/routed.json` | `12b2b6e334d38ea113918d0c1800853cc77f1e6d6fbbf3a91d05b2d7b09b016e` |
| `control/timing.json` | `2e301287ab5109ffae6f4ed801d94a9f5fd68923adb3031596fd54692ea2b4f4` |
| `control/run.json` | `ef200d550a24095adad4dcefb7cbaeac23cb0c05e26fb1e85c6f648102397130` |
| `candidate/routed.json` | `5522e373e81d83a123e063cacd4ada64040a75f1b1b31c2acf069d0f2831b9d1` |
| `candidate/timing.json` | `ef53b32dcc5151869b0a67927b96ebdafbe04d9fd304b549c8522a36f3759a16` |
| `candidate/run.json` | `d34656e181750cca02056a99bcee6c783e243cef00cf37a16acef419b7ab908d` |
| `candidate/route.log` | `0d55ad5a2badca8ec1aa1a843ffac94209e22ab2583449fc8929393b8dfb3a20` |
| `candidate/comparison.json` | `0206b654f4d2fd189424990305697ace483e5fed46bfef969b81fefdf4dbc454` |
| `src/local_remap.cc` | `366e881beceeb494fece87874e311e30025b95bd5ba1365335253ccd72098ad4` |
| `src/local_remap_policy.h` | `a2ac574f0c04d117aaa861847578c99a0fd7bc968a38201751d2bc2a6d4dc863` |
| `src/reduction_balance.cc` | `0ca60e78547787c70c6c7ea80ad554282bfddec1c5e753385f5ed1b1211544ad` |
| `src/reduction_balance_policy.h` | `418cf82e2d516b69676a9d9ea10954c29d775829d4736cd68d93645bbc956054` |
| `src/placed_reduction.cc` | `e5e35aec07293d491754c959e2101af42d4cbf030108fec96a512dd179e842e0` |
| `src/enable_replication.cc` | `7c82be3fa090376b937de0408b06ffeaf0b291f5958915fa8fc61209d0aa55ce` |
| `old/reports/idle14-beats2.rpt` | `1a88350154e2f8846cff7de81abcc7ef84d34f78156bbed53b44c0df4d6855e9` |
| `old/reports/idle23-address25.rpt` | `1e83022bc9f2d363735065778b05a3dc63bae1a661a2a60e36f4e748d0e8ae92` |
| `old/nodes.tsv` | `c26bc777db47bdad9b6f0920cec4318ba83514da3291a179e9f5d0662031d655` |
| `old/inputs.tsv` | `be83316202b87e0d6345c7a03cd02af16666c7c68bb394766cfb452ba50a06ab` |
| `old/outputs.tsv` | `2147fea902b78f065cd4bbb65860896c61df743e27abc6b6034bbaad43b3ae22` |
| `old/project/top.qsf` | `7dac9740dacdf217062ad3bf84b6b3c9080b19bb12ca148dc0e2fb68371e0f43` |
| `ready-remap-264/next-remap-design.md` | `d664754c6eaee5ad8dce9c1299a2f3d92440356ed7e42e4d2e307af16dfcae73` |
| `ready-remap-264/quartus-hints.md` | `7efedd8054726e6d1e16ef255625e160ba4bddeb290daf52117b6c2fce01e28f` |
| `RTL ddr_channel.v` | `f0f6286143a292af490efa9d5ae5875d53690e9cc557127bf657050742710843` |
