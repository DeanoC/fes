# DDR1 next-target Boolean and guard assessment

Read-only assessment of the completed `route-g1-c0` artifact. FES base is
`7ce9926941a5f72cc3ca4b0ed61b7b06e76e5304`; this route used the immutable
nextpnr `f2a8373d` binary without the optional pin-order change. Memory Fmax is
113.77859497070312 MHz. No compiler/RTL edits, builds, routes or hardware actions
were performed for this assessment. The concurrent pin-order route is a separate
artifact. Quartus comparison and route-versus-logic assessment live in
`next-cone.md`, owned by the other reviewer.

Inputs:

- `route-g1-c0/timing.json`: SHA256
  `ef53b32dcc5151869b0a67927b96ebdafbe04d9fd304b549c8522a36f3759a16`.
- `route-g1-c0/routed.json`: SHA256
  `5522e373e81d83a123e063cacd4ada64040a75f1b1b31c2acf069d0f2831b9d1`.

## Existing terminal two-LUT remap declines this path

The memory critical path starts at logical `ddr1_test.idle[22]` (mapped FF suffix
`_8`) and ends at `ddr1_test.beats_left_MISTRAL_FF_Q_6.ENA` at LAB `(25,33)`.
Its seven LUTs end with:

- Inner: `ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT4_D`,
  ALUT4 mask `0xe400`, BEL `MISTRAL_COMB.31.16.18`.
- Outer: `ddr1_test.pass_end_MISTRAL_ALUT5_D`, ALUT5 mask `0x5f7f0000`,
  BEL `MISTRAL_COMB.31.16.1`; its E pin receives the inner Q.

The shared external input is inner A / outer A, sourced by
`ddr1_test.state_MISTRAL_FF_Q_4.Q`. Four inner inputs plus four other outer inputs,
less that alias, give seven distinct external inputs. In the generic collector's
order they are:

| Index | Source | Essential toggle-pair count |
| --- | --- | ---: |
| 0 | `ddr1_test.state_MISTRAL_FF_Q_4.Q` | 16 |
| 1 | `ddr1_test.state_MISTRAL_FF_Q_1.Q` | 16 |
| 2 | `ddr1_test.write_MISTRAL_ALUT5_B.Q` | 10 |
| 3 | `ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT2_Q.Q` | 26 |
| 4 | `ddr0_test.stop_MISTRAL_FF_Q.Q` | 2 |
| 5 | `ddr1_test.burst_end_MISTRAL_FF_Q.Q` | 6 |
| 6 | `ddr1_test.pass_end_MISTRAL_FF_Q.Q` | 2 |

Exhaustive evaluation of the 128 independent-input assignments gives mask
`0x44004400e400e4004400e400e400e400`, with 26 true rows. Every input is essential.
There is no six-input implementation of this cut without extra sequential-state
assumptions, which the generic remapper does not make. Its `compose()` rejects
more than six signals before placement trials; pin permutation cannot change
that support limit.

The outer output has eight FF ENA users in five LABs, with one user in the critical
LAB. Input-side consumers are ordinary LUT/FF data/control consumers in the
unrouted graph; no direct hard-block or clock-input boundary was found on these
seven inputs. Both candidate LUT LABs and the sink LAB show no memory/arithmetic
or explicit protected occupants, excluding normal post-route feedthrough buffers.
These observations do not replace the live movability, clock, legality, setup,
hold and boundary guards. The structural seven-input rejection already suffices.

The report has one ENA-ending critical path. Comparing the seven critical LUTs
and sink against the frozen 115.380 route confirms identical logical types,
parameters, input source endpoints and BELs, resolving generated feedthroughs.
A fresh identical HeAP placement can validate that path. An invocation selecting
this report does not automatically
retain the preceding HPS-ready clone: the pass keeps only one candidate per run.

## Private 24-literal comparator is the concrete reduction target

Root:
`ddr1_test.pass_end_MISTRAL_ALUT5_D_1_Q_MISTRAL_ALUT3_Q`
at `MISTRAL_MCOMB.34.16.30`, ALUT3 mask `0x80`.

The cone has exactly seven ordinary LUTs, 24 distinct FF inputs and three levels.
Its three branches each use ALUT4 then ALUT5 to compare eight bits:

| Logical bits | ALUT4 mask | ALUT5 mask |
| --- | --- | --- |
| 0..7 | `0x4` | `0x10000` |
| 8..15 | `0x4` | `0x100000` |
| 16..23 | `0x1` | `0x80000000` |

All serialized input pin states are `PIN_SIG`. Recursive unique-row recognition
proves the complete function is **`idle == 24'd1000000` (`0x0f4240`)**. Bits
6, 9, 14, 16, 17, 18 and 19 must be high; all other bits must be low. Each local
LUT has one satisfying row for the required output polarity, and all 24 input
identities are distinct. This compositional proof establishes the unique global
assignment without an exhaustive 2^24 loop.

All six nonroot Q nets have exactly one consumer inside the cone and no external
or top-level observation. The root Q has eight external ordinary-LUT consumers;
its net identity and all those user slots must remain intact. The root and all
six children are weakly placed, with no explicit keep/dont-touch attributes or
memory/arithmetic occupants in their LABs observed in the saved artifact.

Canonical logical-graph SHA256:
`3e23bfe7ba716ab6e25d7195c9be510b322273db383401a4d61dfbbd81f99853`.
The hashed UTF-8 compact JSON uses sorted keys and contains `root`, `cells`, and
`external_inputs`. Cells are sorted by name; each records name/type/integer LUT
mask and A..F inputs with pin name, source `[driver-cell, driver-port]` and
serialized pin state. External source endpoints are sorted lexically. BELs,
physical pin maps and transient JSON net-bit IDs are excluded. This is a
diagnostic logical-graph fingerprint, not a package or execution identity.

The critical source-to-comparator-Q prefix is 4.076 ns excluding clock skew,
including 0.731 ns clock-to-Q, 2.639 ns routing and 0.706 ns LUT logic. The
comparator has three logic levels. A four-ALUT6 leaf layer plus an ALUT4 root can
express the same 24 literals in two levels and five LUTs. No timing gain is
claimed; shared-ALM legality and routed delay remain to be checked.

Current `plan_reduction()` stops after four visited LUTs, `recognize()` accepts
only three-LUT/eleven-literal or four-LUT/sixteen-literal conjunctions, and
`placed_reduction()` additionally requires exactly three cells. The individual
eight-bit branches contain only two LUTs/eight literals. No existing eleven-input
branch matches this comparator.

An additional guard needs attention in any future extension: the current placed
endpoint collector rejects a previously visited downstream net, including benign
reconvergence. This root reaches about 31 nets and 283 distinct FF endpoints
(278 ENA, five DATAIN, tracing through generated feedthroughs), with no hard data
boundary found, but two paths converge at
`ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT2_Q.Q`. Therefore merely increasing the
recognition sizes would still decline this target. Endpoint traversal should
distinguish completed repeated visits from cycles while retaining bounded graph,
clock, endpoint, legality and hold checks.

## Alternative bounded three-LUT cut

The three LUTs immediately before the final ALUT5 form a five-input cut:

1. `ddr1_nack_MISTRAL_FF_Q_ENA_MISTRAL_ALUT2_Q_B_MISTRAL_ALUT2_Q`, mask `0x8`.
2. `ddr1_burst_MISTRAL_FF_Q_ENA_MISTRAL_ALUT4_Q_D_MISTRAL_ALUT5_Q_E_MISTRAL_ALUT2_Q`, mask `0x2`.
3. The inner ALUT4 above, mask `0xe400`.

Exhaustive 32-row evaluation yields `0x5000d080` in sorted external net-bit order
22954, 23019, 23037, 23053, 23772:

| Truth-row bit | Source endpoint | Essential toggle-pair count |
| --- | --- | ---: |
| 0 | `ddr1_test.state_MISTRAL_FF_Q_4.Q` | 4 |
| 1 | `ddr1_test.write_MISTRAL_ALUT5_B.Q` | 2 |
| 2 | `ram_clock.locked_MISTRAL_ALUT2_A_Q_MISTRAL_FF_DATAIN_1_Q_MISTRAL_FF_DATAIN.Q` | 6 |
| 3 | `ddr1_test.state_MISTRAL_FF_Q_1.Q` | 4 |
| 4 | The 24-bit comparator root Q | 2 |

All five inputs are essential. A cloned
ALUT5 could feed only E of the final ALUT5 while keeping the three shared original
cells and all side users, including the original L6 root's 106 FF ENAs. The present
pass targets two LUTs ending directly at FF
ENA groups, so it does not discover or apply this internal three-LUT cut. This
alternative requires generic bounded-cut discovery and internal-edge cloning.

## Recommended next scope

Prioritize an optional, bounded **placed 24-literal conjunction rewrite** for the
private comparator, preserving the root Q identity and every unrelated placement.
Extend the existing recognizer/planner rather than encoding DDR names, masks or
coordinates; retain exact user-slot restoration, protected-LAB checks, output
branch-slack improvement, nonregressing endpoint/setup/Fmax/hold guards and full
routing. Handle the demonstrated acyclic downstream reconvergence conservatively.
This scope has a complete Boolean proof and private intermediates, and removes
one level on the observed prefix. The bounded placement metric should improve the
comparator root's setup slack while preserving setup slack at all reachable FF
endpoints and all existing clock Fmax/hold checks; the acceptance metric is the
completed same-context all-clock route, compared against the frozen control and
the completed ready-remap route. Keep the generic internal three-LUT cut as an
independent alternative if the comparator rewrite cannot qualify legal placement
or routed improvement. Neither experiment changes RTL, pipeline latency, shared
contracts, compiler selection or hardware acceptance by itself.
