"""Real JSON-loader control against the authenticated retained single-root output."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / 'sources/misteross'
RAW = HERE.parent
FROZEN = HERE / 'pin-order'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sys.path.insert(0, str(MODULE))
from scripts import fes_build_common as board
from scripts.compiler_read_audit import audited_run
from scripts.functional_execution import FunctionalInvocation

reference = RAW / 'placed-reduction-root-slack/single-root-control-equivalence'
old = json.loads((reference / 'comparison.json').read_text())
accepted = reference / 'accepted.json'
assert old['completed'] and sha(accepted) == old['runs']['accepted']['transformed_sha256']
identity = json.loads((FROZEN / 'source-identity.json').read_text())
binary = FROZEN / 'nextpnr-mistral'
assert sha(binary) == identity['binary_sha256']
source = Path(old['runs']['candidate']['command'][2])
assert sha(source) == old['input_sha256'][str(source)]
output = FROZEN / 'disabled-control'
output.mkdir(exist_ok=False)
invocation = FunctionalInvocation({'nextpnr-mistral': board.AuthenticatedTool(binary, 'sha256=' + sha(binary))}, 1)
command = [str(binary), '--json', str(source), '--device', '5CSEBA6U23I7',
           '--no-pack', '--no-place', '--no-route', '--balance-reduction-root', old['root'],
           '--write', str(output / 'candidate.json')]
record = {'command': command, 'execution': invocation.inputs, 'completed': False,
          'input_sha256': {str(p): sha(p) for p in (binary, source, accepted, reference / 'comparison.json')},
          'kind': 'host-only disabled-option JSON-loader control'}
try:
    assert not any(key.startswith('NEXTPNR_MISTRAL_') for key in invocation.env)
    with (output / 'loader.log').open('w') as log:
        result = audited_run(command, source_root=MODULE, cwd=MODULE, env=invocation.env,
                             stdout=log, stderr=subprocess.STDOUT, check=False, timeout=300)
    assert result.returncode == 0
    invocation.verify()
    expected = json.loads(accepted.read_text())['modules']
    actual = json.loads((output / 'candidate.json').read_text())['modules']
    assert expected == actual
    record['modules_sha256'] = hashlib.sha256(json.dumps(actual, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert record['modules_sha256'] == old['modules_sha256']
    for path, digest in record['input_sha256'].items():
        assert sha(Path(path)) == digest
    record['completed'] = True
    print(record['modules_sha256'], flush=True)
finally:
    (output / 'comparison.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    invocation.close()
