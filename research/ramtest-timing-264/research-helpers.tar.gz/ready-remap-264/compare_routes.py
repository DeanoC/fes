#!/usr/bin/env python3
"""Authenticate a ready-control remap of the frozen 115.380 MHz route.

Run only after route_existing.py has finalized run.json. This helper writes
comparison.json beside the candidate; it does not build, select or load an RBF.
The previous pure evidence helper supplies the established route/archive checks.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
ROOT = RAW.parents[1]
FROZEN = RAW / "placed-reduction-root-slack"
PIN_ORDER = HERE / "pin-order"
CONTROL = FROZEN / "route-local-r6-s0"
EARLIER = RAW / "capture-locality/route-b64-r24"
BASE = RAW / "route-slots-final"
PREVIOUS_HELPER = FROZEN / "compare_routes.py"
spec = importlib.util.spec_from_file_location("placed_reduction_evidence", PREVIOUS_HELPER)
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
require = previous.require
read = previous.read
sha = previous.sha
relative = previous.relative
MEMORY_CLOCK = previous.MEMORY_CLOCK
REQUIRED_CLOCKS = {"display.pixel_clk": 74.25, MEMORY_CLOCK: 130.0, "ram_clock.clocks[1]": 130.0}
EXPECTED_OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT4_C"
EXPECTED_INNER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q"
EXPECTED_SINKS = {"hps_ddr.m1_address_MISTRAL_FF_Q_14", "hps_ddr.m1_address_MISTRAL_FF_Q_18"}
ARTIFACT_NAMES = ("run.json", "route.log", "timing.json", "routed.json", "core.rbf")


def argument(command, option):
    require(command.count(option) == 1, f"missing or repeated command option: {option}")
    return command[command.index(option) + 1]


def compiler_folder(record):
    binary = Path(record["command"][0])
    require(binary.name == "nextpnr-mistral" and binary.parent in (FROZEN, PIN_ORDER),
            "candidate must use the original frozen compiler or the pin-order freeze")
    return binary.parent


def authenticate_compiler(record, folder, control_source):
    source = previous.source_identity(folder, record)
    identity_fields = dict(part.strip().split("=", 1) for part in record["tool_identity"].split(";")
                           if "=" in part)
    require(identity_fields.get("base_commit") == source["base_commit"] and
            identity_fields.get("experimental_source_sha256") == source["archive_sha256"] and
            identity_fields.get("sha256") == source["binary_sha256"], "compiler identity text disagrees with freeze")
    optimized = folder == PIN_ORDER
    require(record["command"].count("--remap-optimize-pins") == int(optimized),
            "pin-order option must occur exactly once for the pin-order compiler and be absent otherwise")
    result_commit = source.get("result_commit")
    result_recorded = isinstance(result_commit, str) and previous.re.fullmatch(r"[0-9a-f]{40}", result_commit) is not None
    if optimized:
        require(source["base_commit"] == control_source["result_commit"],
                "pin-order compiler is not based on the frozen f2a8373d compiler")
        if "base_compiler_commit" in record:
            require(record["base_compiler_commit"] == source["base_commit"], "recorded compiler base changed")
        if result_recorded:
            require(record.get("compiler_commit") == result_commit, "candidate compiler result commit changed")
    else:
        require(record["compiler_commit"] == source["result_commit"], "candidate compiler commit changed")
    archive = folder / "source.tar.gz"
    require(record["source_archive_sha256"] == record["input_sha256"].get(str(archive)) == sha(archive),
            "candidate frozen source archive was not authenticated")
    return {**source, "freeze_path": relative(folder), "remap_optimize_pins": optimized,
            "result_commit_recorded": result_recorded}


def fixed_command(command):
    ignored_values = {"--write", "--report", "--rbf", "--remap-critical", "--remap-candidate", "--remap-groups"}
    fixed = []
    index = 1
    while index < len(command):
        option = command[index]
        if option in ignored_values:
            index += 2
        elif option == "--remap-optimize-pins":
            index += 1
        else:
            fixed.append(option)
            index += 1
    return fixed


def authenticate_execution(record, control):
    current, old = record["execution"], control["execution"]
    current_binary, old_binary = record["command"][0], control["command"][0]
    current_files = {p: h for p, h in current["files"].items() if p != current_binary}
    old_files = {p: h for p, h in old["files"].items() if p != old_binary}
    require(current_files == old_files, "noncompiler execution identity changed")
    require(current["files"].get(current_binary) == record["input_sha256"].get(current_binary),
            "compiler execution/input digests disagree")
    expected_env = {**old["environment"], "PATH": str(Path(current_binary).parent) + ":/usr/bin:/bin"}
    require(current["environment"] == expected_env, "controlled execution environment changed")
    require({k: v for k, v in current.items() if k not in ("files", "environment")} ==
            {k: v for k, v in old.items() if k not in ("files", "environment")},
            "execution platform/GPU identity changed")
    for filename, expected in current["files"].items():
        require(sha(Path(filename)) == expected, f"execution input changed: {filename}")


def transform_stack(log, control_log):
    families = {"balance_sixteen": "Balanced four-LUT reduction", "replication": "Enable replication",
                "capture_locality": "Capture locality", "placed_reduction": "Placed reduction",
                "balance_eleven": "Balanced three-LUT reduction"}
    result = {}
    for name, marker in families.items():
        lines = [line for line in log.splitlines() if marker in line]
        control_lines = [line for line in control_log.splitlines() if marker in line]
        result[name] = {"candidate_log": lines, "control_log": control_lines,
                        "identical_to_control": lines == control_lines}
    require(all(item["identical_to_control"] for item in result.values()),
            "a retained transform differs from the frozen 115.380 stack")
    require(len(result["capture_locality"]["candidate_log"]) == 61 and
            "eligible 64, retained 60 moves" in result["capture_locality"]["candidate_log"][-1],
            "capture64r24 did not retain its 60 moves")
    result["capture_locality"].update({"eligible": 64, "retained_moves": 60,
                                      "source": "hps_ddr.f2sdram.rd_clk_0"})
    require(any("0 replicas, budget 4;" in line for line in result["replication"]["candidate_log"]),
            "replication no longer matches the retained zero-replica result")
    result["replication"].update({"budget": 4, "replicas_created": 0})
    return result


def critical_path_comparison(control, candidate):
    def summary(path):
        return {"from": path["from"], "to": path["to"], "relationship_ns": path["max_delay"],
                "total_ns": sum(step["delay"] for step in path["path"]),
                "routing_ns": sum(step["delay"] for step in path["path"] if step["type"] == "routing"),
                "logic_levels": sum(step["type"] == "logic" for step in path["path"]),
                "source": path["path"][1]["from"], "endpoint": path["path"][-1]["to"], "path": path}
    result = {}
    for clock in REQUIRED_CLOCKS:
        old_path = next(path for path in control["critical_paths"] if path["from"] == "posedge " + clock)
        new_path = next(path for path in candidate["critical_paths"] if path["from"] == "posedge " + clock)
        a, b = summary(old_path), summary(new_path)
        result[clock] = {"control": a, "candidate": b, "total_ns_change": b["total_ns"] - a["total_ns"],
                         "same_source_and_endpoint": a["source"] == b["source"] and a["endpoint"] == b["endpoint"],
                         "same_logic_levels": a["logic_levels"] == b["logic_levels"]}
    return result


class Netlist:
    """Identify logical drivers independently of route-created transparent BUFs."""
    def __init__(self, cells):
        self.cells = cells
        self.drivers = {}
        for name, cell in cells.items():
            for port, direction in cell["port_directions"].items():
                if direction == "output":
                    for index, bit in enumerate(cell["connections"][port]):
                        require(bit not in self.drivers, f"multiple net drivers: {bit}")
                        self.drivers[bit] = (name, port, index)

    def token(self, bit, stack=frozenset()):
        if isinstance(bit, str):
            require(bit in ("0", "1"), f"unknown constant: {bit}")
            return ("constant", int(bit))
        require(bit not in stack, "cyclic transparent-buffer chain")
        if bit not in self.drivers:
            return ("undriven", bit)
        name, port, index = self.drivers[bit]
        cell = self.cells[name]
        if cell["type"] == "MISTRAL_BUF":
            require(port == "Q" and index == 0 and len(cell["connections"]["A"]) == 1,
                    f"unexpected transparent buffer shape: {name}")
            return self.token(cell["connections"]["A"][0], stack | {bit})
        return (name, port, index)

    def inputs(self, name):
        cell = self.cells[name]
        return {port: [self.token(bit) for bit in cell["connections"][port]]
                for port, direction in cell["port_directions"].items() if direction == "input"}

    def lut_inputs(self, name):
        cell = self.cells[name]
        require(is_lut(cell), f"not a Boolean LUT: {name}")
        width = int(cell["type"].removeprefix("MISTRAL_ALUT"))
        return [self.token(cell["connections"][pin][0]) for pin in "ABCDEF"[:width]]

    def expression(self, token, leaves, visited, stack=frozenset()):
        if token[0] == "constant":
            return token
        if token in leaves:
            return ("variable", token)
        require(token not in stack, "cyclic remap cone")
        require(len(token) == 3 and token[0] in self.cells, f"unmatched external cone input: {token}")
        name, port, index = token
        cell = self.cells[name]
        require(is_lut(cell) and port == "Q" and index == 0,
                f"cone does not stop at the clone's declared external inputs: {token}")
        visited.add(name)
        return ("lut", int(cell["parameters"]["LUT"], 2),
                [self.expression(t, leaves, visited, stack | {token}) for t in self.lut_inputs(name)])


def is_lut(cell):
    return cell["type"] in {f"MISTRAL_ALUT{i}" for i in range(2, 7)}


def detail(name, cell):
    result = {"cell": name, "type": cell["type"], "bel": previous.bel(cell),
              "parameters": cell["parameters"], "connections": cell["connections"]}
    pinmap = cell["attributes"].get("FES_PINMAP_V1")
    if pinmap:
        result["physical_pinmap"] = json.loads(bytes.fromhex(pinmap).decode())
    return result


def prove_clone(old, new, clone, selected):
    external_order = new.lut_inputs(clone)
    leaves = set(external_order) - {("constant", 0), ("constant", 1)}
    require(len(leaves) <= 6 and all(t[0] != "undriven" for t in leaves), "invalid clone external inputs")
    old_roots = {tuple(entry["control_driver"]) for entry in selected}
    require(len(old_roots) == 1, f"clone replaced more than one original root: {clone}")
    old_root = old_roots.pop()
    visited = set()
    tree = old.expression(old_root, leaves, visited)
    clone_mask = int(new.cells[clone]["parameters"]["LUT"], 2)
    rows = []
    expected_mask = 0
    # Enumerate physical LUT rows in its actual A..F order. Unique-input rows
    # cover the Boolean function even if a clone has duplicated/constant pins.
    tokens = sorted(leaves)
    for assignment in range(1 << len(tokens)):
        values = {token: (assignment >> i) & 1 for i, token in enumerate(tokens)}
        physical_row = sum((t[1] if t[0] == "constant" else values[t]) << i
                           for i, t in enumerate(external_order))
        expected = previous.evaluate(tree, values)
        actual = (clone_mask >> physical_row) & 1
        require(actual == expected, f"composed LUT truth table changed: {clone}, row {assignment}")
        expected_mask |= expected << physical_row
        rows.append({"assignment": assignment, "clone_row": physical_row,
                     "inputs": [(assignment >> i) & 1 for i in range(len(tokens))],
                     "retained_cone_output": expected, "clone_output": actual})
    return {"clone": detail(clone, new.cells[clone]), "control_root": old_root,
            "retained_cone": {n: detail(n, old.cells[n]) for n in sorted(visited)},
            "external_inputs": tokens, "clone_input_order": dict(zip("ABCDEF", external_order)),
            "equivalent": True, "assignments_checked": len(rows), "truth_rows": rows,
            "clone_mask_hex": hex(clone_mask), "composed_mask_hex": hex(expected_mask),
            "control_lut_depth": previous.depth(tree), "candidate_lut_depth": 1,
            "selected_ff_ena_users": selected,
            "expected_ready_cone": old_root == (EXPECTED_OUTER, "Q", 0) and
                                   visited == {EXPECTED_INNER, EXPECTED_OUTER},
            "expected_mask_0xbbbbbbb0": clone_mask == 0xbbbbbbb0}


def compare_netlists(old_cells, new_cells):
    old, new = Netlist(old_cells), Netlist(new_cells)
    common = set(old_cells) & set(new_cells)
    added = sorted(set(new_cells) - set(old_cells))
    removed = sorted(set(old_cells) - set(new_cells))
    require(all(old_cells[n]["type"] == "MISTRAL_BUF" for n in removed), "original non-BUF cell removed")
    clones = [n for n in added if is_lut(new_cells[n])]
    require(all(new_cells[n]["type"] == "MISTRAL_BUF" or n in clones for n in added),
            "cell added outside a Boolean clone or transparent BUF")
    old_ffs = {n for n, c in old_cells.items() if c["type"] == "MISTRAL_FF"}
    new_ffs = {n for n, c in new_cells.items() if c["type"] == "MISTRAL_FF"}
    require(old_ffs == new_ffs, "FF population changed")
    original_luts = {n for n, c in old_cells.items() if c["type"].startswith("MISTRAL_ALUT")}
    changed_bels = {"ff": [], "original_lut": [], "transparent_buffer": [], "other": []}
    changed_ena = []
    for name in sorted(common):
        a, b = old_cells[name], new_cells[name]
        require(a["type"] == b["type"] and a["parameters"] == b["parameters"],
                f"original cell type or parameters changed: {name}")
        category = "ff" if name in old_ffs else "original_lut" if name in original_luts else \
                   "transparent_buffer" if a["type"] == "MISTRAL_BUF" else "other"
        if previous.bel(a) != previous.bel(b):
            changed_bels[category].append({"cell": name, "control_bel": previous.bel(a),
                                           "candidate_bel": previous.bel(b)})
        if category == "transparent_buffer":
            continue
        ai, bi = old.inputs(name), new.inputs(name)
        require(set(ai) == set(bi), f"original input-port set changed: {name}")
        for port in sorted(ai):
            if ai[port] == bi[port]:
                continue
            require(name in old_ffs and port == "ENA" and len(ai[port]) == len(bi[port]) == 1,
                    f"original non-ENA logical connection changed: {name}.{port}")
            require(bi[port][0][0] in clones and bi[port][0][1:] == ("Q", 0),
                    f"FF ENA changed to a non-clone driver: {name}")
            changed_ena.append({"ff": name, "bel": previous.bel(b),
                                "control_net": a["connections"]["ENA"],
                                "candidate_net": b["connections"]["ENA"],
                                "control_driver": ai[port][0], "candidate_driver": bi[port][0]})
    require(not changed_bels["ff"], "FF BEL changed")
    require(not changed_bels["other"], "BEL changed outside original LUTs and transparent BUFs")
    proofs = []
    for clone in clones:
        selected = [e for e in changed_ena if e["candidate_driver"][0] == clone]
        require(selected, f"added clone does not feed changed FF ENA users: {clone}")
        proofs.append(prove_clone(old, new, clone, selected))
    # A qualified whole-group move can relocate the original root instead of
    # adding a clone. Its unchanged parameters and normalized inputs above
    # preserve its function, and all consumers keep their original connection.
    moved_originals = [{**entry, "cell_detail": detail(entry["cell"], new_cells[entry["cell"]]),
                        "ff_ena_users": sorted(n for n in old_ffs if old.inputs(n)["ENA"] ==
                                               [(entry["cell"], "Q", 0)])}
                       for entry in changed_bels["original_lut"]]
    require(proofs or moved_originals, "requested remap made no observable clone or original-LUT move")
    original_ready_users = sorted(n for n in old_ffs if old.inputs(n)["ENA"] == [(EXPECTED_OUTER, "Q", 0)])
    rewired = {e["ff"] for e in changed_ena}
    unselected_ready = [n for n in original_ready_users if n not in rewired]
    require(all(old.inputs(n)["ENA"] == new.inputs(n)["ENA"] for n in unselected_ready),
            "unselected original ready FF ENA connection changed")
    return {"common_cells": len(common), "common_ff_cells": len(old_ffs),
            "original_lut_cells": len(original_luts), "ff_placements_identical": True,
            "original_lut_placements_identical": not changed_bels["original_lut"],
            "original_nonbuf_type_parameters_preserved": True,
            "original_nonena_logical_connections_preserved": True,
            "changed_common_bels_by_kind": changed_bels,
            "added_cells": [detail(n, new_cells[n]) for n in added],
            "removed_cells": [detail(n, old_cells[n]) for n in removed],
            "added_clone_count": len(clones),
            "added_buffer_count": sum(new_cells[n]["type"] == "MISTRAL_BUF" for n in added),
            "removed_buffer_count": len(removed), "clone_equivalence": proofs,
            "whole_group_or_original_lut_moves": moved_originals,
            "selected_ff_ena_connections": changed_ena,
            "all_unselected_ff_ena_connections_preserved": True,
            "unselected_ff_ena_count": len(old_ffs) - len(rewired),
            "original_ready_ff_ena_users": original_ready_users,
            "unselected_original_ready_ff_ena_users": unselected_ready,
            "unselected_original_ready_ff_ena_count": len(unselected_ready),
            "shared_original_ready_cells": {n: {"control": detail(n, old_cells[n]),
                                                "candidate": detail(n, new_cells[n])}
                                            for n in (EXPECTED_INNER, EXPECTED_OUTER)},
            "expected_two_primary_ff_ena_users_selected": rewired == EXPECTED_SINKS}


def comparison(folder):
    # Require finalized metadata before hashing the immutable evidence snapshot.
    record = read(folder / "run.json")
    require(record.get("completed") and record.get("exit_code") == 0, "candidate metadata is not final")
    candidate_compiler = compiler_folder(record)
    artifact_paths = [ref / name for ref in (folder, CONTROL, EARLIER, BASE) for name in ARTIFACT_NAMES]
    artifact_paths += [FROZEN / name for name in ("source-identity.json", "source.tar.gz", "nextpnr-mistral")]
    artifact_paths += [EARLIER.parent / name for name in ("source-identity.json", "source.tar.gz", "nextpnr-mistral")]
    artifact_paths += [PREVIOUS_HELPER, Path(__file__).resolve(),
                       RAW / "validated-nextpnr-mistral", RAW / "nextpnr-slots-fixed-source.tar.gz",
                       RAW / "slot-fixed-source-hashes.json"]
    artifact_paths += [candidate_compiler / name for name in ("source-identity.json", "source.tar.gz", "nextpnr-mistral")]
    digests = {path: sha(path) for path in artifact_paths}
    record, report, cells, log, route = previous.route_evidence(folder)
    old_record, old_report, old_cells, old_log, old_route = previous.route_evidence(CONTROL)
    earlier_record, earlier_report, _, earlier_log, earlier_route = previous.route_evidence(EARLIER)
    base_record, base_report, _, base_log, base_route = previous.route_evidence(BASE)
    require(record["build_id"] == old_record["build_id"] == earlier_record["build_id"] == base_record["build_id"],
            "BUILD_ID changed across the fixed-input routes")
    inputs = previous.authenticate_inputs(record)
    old_inputs = previous.authenticate_inputs(old_record)
    earlier_inputs = previous.authenticate_inputs(earlier_record)
    base_inputs = previous.authenticate_inputs(base_record, RAW / "validated-nextpnr-mistral")
    old_source = previous.source_identity(FROZEN, old_record)
    source = authenticate_compiler(record, candidate_compiler, old_source)
    earlier_source = previous.source_identity(EARLIER.parent, earlier_record)
    base_source = previous.verify_archive(RAW / "nextpnr-slots-fixed-source.tar.gz",
                                          read(RAW / "slot-fixed-source-hashes.json"))
    if candidate_compiler == FROZEN:
        require(record["tool_identity"] == old_record["tool_identity"], "frozen compiler identity changed")
    require(record["control_run_sha256"] == sha(CONTROL / "run.json"), "remap control metadata changed")
    require(fixed_command(record["command"]) == fixed_command(old_record["command"]),
            "candidate changed a command option outside remap selection/pin optimization/output paths")
    for option in ("--json", "--qsf", "--sdc", "--device", "--freq", "--seed", "--placer-heap-timingweight",
                   "--placer-heap-critexp", "--router", "--replicate-enables", "--balance-reduction-root", "--gpu-device"):
        value = argument(record["command"], option)
        require(all(argument(other["command"], option) == value for other in
                    (old_record, earlier_record, base_record)), f"fixed route option changed: {option}")
        if option in ("--json", "--qsf", "--sdc"):
            expected = record["input_sha256"].get(value)
            require(expected and all(other["input_sha256"].get(value) == expected for other in
                                     (old_record, earlier_record, base_record)), f"functional input changed: {option}")
    require(argument(record["command"], "--remap-critical") == str(CONTROL / "timing.json"), "wrong remap report")
    require(int(argument(record["command"], "--remap-candidate")) == record["remap_candidate"], "candidate selection mismatch")
    require(int(argument(record["command"], "--remap-groups")) == record["remap_groups"], "group budget mismatch")
    require(record["remap_report_sha256"] == record["input_sha256"].get(str(CONTROL / "timing.json")) ==
            sha(CONTROL / "timing.json"), "remap report was not authenticated")
    require(record["experimental_capture_locality"] == old_record["experimental_capture_locality"] ==
            earlier_record["experimental_capture_locality"] == str(BASE / "timing.json") + " 64 24",
            "capture64r24 options changed")
    require(record["experimental_placed_reduction"] == old_record["experimental_placed_reduction"] ==
            previous.ROOT_CELL + " 6 0", "placed eleven-input reduction options changed")
    require(record["capture_report_sha256"] == old_record["capture_report_sha256"] ==
            earlier_record["capture_report_sha256"] == sha(BASE / "timing.json"), "capture report changed")
    require(record["input_sha256"].get(str(BASE / "timing.json")) == sha(BASE / "timing.json"),
            "capture report missing from input manifest")
    authenticate_execution(record, old_record)
    for option, name in (("--write", "routed.json"), ("--report", "timing.json"), ("--rbf", "core.rbf")):
        require(argument(record["command"], option) == str(folder / name), f"output path mismatch: {option}")
    metrics = previous.PLACEMENT_METRICS.findall(log)
    require(len(metrics) == 71 and all(previous.PLACEMENT_METRICS.findall(other) == metrics
                                      for other in (old_log, earlier_log, base_log)),
            "ordinary HeAP trajectory changed or does not contain exactly 71 metrics")
    require(set(report["fmax"]) == set(REQUIRED_CLOCKS), "required clock set changed")
    require(all(report["fmax"][clock]["constraint"] >= nominal for clock, nominal in REQUIRED_CLOCKS.items()),
            "clock constraint relaxed below its nominal requirement")
    clock_comparisons = {label: previous.compare_clocks(reference, report) for label, reference in
                         (("control_115", old_report), ("earlier_110", earlier_report), ("baseline_108", base_report))}
    placement = compare_netlists(old_cells, cells)
    stacked = transform_stack(log, old_log)
    # Rehash finalized metadata and payloads before publishing the comparison.
    require(all(sha(path) == digest for path, digest in digests.items()), "evidence changed during comparison")
    clocks_close = all(row["meets_constraint"] for row in clock_comparisons["control_115"].values())
    nonregression = {label: all(row["gain_mhz"] >= 0 for row in rows.values())
                     for label, rows in clock_comparisons.items()}
    return {"status": "experimental ready remap; unselected", "build_id": record["build_id"],
            "compiler_commit": record.get("compiler_commit"), "base_compiler_commit": source["base_commit"],
            "elapsed_seconds": record["elapsed_seconds"], "remap_candidate": record["remap_candidate"],
            "remap_groups": record["remap_groups"], "candidate_route": route,
            "source": source, "authenticated_inputs": inputs,
            "execution_inputs_authenticated": True, "final_metadata_stable_during_comparison": True,
            "control_115": {"path": relative(CONTROL), "route": old_route, "source": old_source,
                            "authenticated_inputs": old_inputs},
            "earlier_110": {"path": relative(EARLIER), "route": earlier_route, "source": earlier_source,
                            "authenticated_inputs": earlier_inputs},
            "baseline_108": {"path": relative(BASE), "route": base_route, "source": base_source,
                             "authenticated_inputs": base_inputs},
            "fmax_comparisons": clock_comparisons, "all_clock_nonregression": nonregression,
            "passes_all_clock_constraints": clocks_close,
            "nonmemory_required_clocks_close": all(row["meets_constraint"] for clock, row in
                clock_comparisons["control_115"].items() if clock != MEMORY_CLOCK),
            "memory_improved_vs_115": clock_comparisons["control_115"][MEMORY_CLOCK]["gain_mhz"] > 0,
            "placement_metrics_identical": True, "matched_placement_metrics": len(metrics),
            "placement_metrics_sha256": hashlib.sha256("\n".join(metrics).encode()).hexdigest(),
            "bel_reference": relative(CONTROL), **placement,
            "transform_stack": stacked,
            "critical_path_comparisons": critical_path_comparison(old_report, report),
            "remap_log": [line for line in log.splitlines() if "remap" in line.lower()],
            "placed_reduction_log": [line for line in log.splitlines() if "Placed reduction" in line],
            "critical_memory_path": next(p for p in report["critical_paths"] if
                                         p["from"] == p["to"] == "posedge " + MEMORY_CLOCK),
            "artifact_sha256": {relative(path): digest for path, digest in digests.items()},
            "default_recipe_selected": False, "hardware_tested": False,
            "caveats": ["All three controls are retained as distinct experimental/accepted evidence; timing gates are explicit.",
                        "The hold screen reads final nextpnr warnings; it is not package or hardware acceptance.",
                        "Boolean proof is bounded to the remapped cone and preserved logical connections."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", nargs="?", default="route-g1-c0", help="completed candidate directory within ready-remap-264")
    args = parser.parse_args()
    folder = (HERE / args.route).resolve()
    require(folder.parent == HERE, "candidate must be a direct directory within ready-remap-264")
    result = comparison(folder)
    (folder / "comparison.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    keys = ("status", "compiler_commit", "elapsed_seconds", "remap_candidate", "remap_groups", "candidate_route",
            "fmax_comparisons", "all_clock_nonregression", "passes_all_clock_constraints", "memory_improved_vs_115",
            "matched_placement_metrics", "common_ff_cells", "original_lut_cells", "ff_placements_identical",
            "original_lut_placements_identical", "added_clone_count", "added_buffer_count", "removed_buffer_count",
            "selected_ff_ena_connections", "unselected_original_ready_ff_ena_count",
            "expected_two_primary_ff_ena_users_selected", "default_recipe_selected", "hardware_tested")
    print(json.dumps({key: result[key] for key in keys}, indent=2))


if __name__ == "__main__":
    main()
