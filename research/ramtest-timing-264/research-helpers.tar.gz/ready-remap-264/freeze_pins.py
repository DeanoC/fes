"""Freeze an experimental compiler; never select a package producer."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / 'sources/misteross'
SRC = MODULE / 'build/toolchain-ramtest-timing/src/nextpnr'
BUILD = MODULE / 'build/toolchain-ramtest-timing/build/nextpnr'
OUT = HERE / 'pin-order'
BASE = 'f2a8373d42dd0f2b0a422177b46d9d36ffc8a559'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SRC, text=True).strip() == BASE
tracked = subprocess.check_output(['git', 'diff', '--name-only', BASE], cwd=SRC, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=SRC, text=True).splitlines()
files = sorted(set(tracked + untracked))
assert files and all(path.startswith('mistral/') for path in files)
OUT.mkdir(exist_ok=False)
shutil.copy2(BUILD / 'nextpnr-mistral', OUT / 'nextpnr-mistral')
with tarfile.open(OUT / 'source.tar.gz', 'w:gz') as archive:
    for path in files:
        archive.add(SRC / path, arcname=path)
(OUT / 'change.patch').write_bytes(subprocess.check_output(['git', 'diff', BASE], cwd=SRC))
record = {'base_commit': BASE, 'source_sha256': {path: sha(SRC / path) for path in files},
          'binary_sha256': sha(OUT / 'nextpnr-mistral'), 'source_archive_sha256': sha(OUT / 'source.tar.gz'),
          'branch': subprocess.check_output(['git', 'branch', '--show-current'], cwd=SRC, text=True).strip(),
          'status': 'uncommitted opt-in generic LUT input-order experiment; host-only, no selection'}
(OUT / 'source-identity.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, indent=2), flush=True)
