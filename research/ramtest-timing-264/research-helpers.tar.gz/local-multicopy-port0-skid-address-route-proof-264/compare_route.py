"""Authenticate and inspect an eighth port0 skid-address-copy/fresh-driver full route."""
import argparse
import builtins
import hashlib
import importlib.util
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
ROUTE = RAW / "local-multicopy-port0-skid-address-route-264"
PREFIX = RAW / "local-multicopy-port0-skid-address-stage-264"
PARENT = RAW / "local-multicopy-ready1-address-route-264/route-c0"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
PARENT_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
BEFORE = RAW / "local-multicopy-ready1-byteenable-route-264/route-c0"
CONSTRUCTION = RAW / "local-multicopy-ready1-byteenable-route-proof-264/comparison.json"
CONSTRUCTION_SHA = "4653836bce4881dbde29261ad689368c77339357bf456c34acbdff5a2802ef19"
CONSTRUCTION_RUN_SHA = "e45404227879c7896abdf9fe6e63caa0f0e5f3c0ed98303c86d6897bd9368017"
CONSTRUCTION_PROFILE_SHA = "a1b5b12727cd0c2161f6fff8b54e8dd7e04d8f543f484615a8e31dc7e00c4c7a"
PROFILE_SHA = "539376c79a565e3f114c20349a1a764059443217c68b088c2892bc66de1960c0"
RUNNER_SHA = "af8f6f335d16b8a4893d06e41a89e599183a700eeefaa72b3d17a8231fc97d32"
RUNNER_SCOPE_SHA = "13d89b8e98198194382558d5a9f5362c9c103f77cbbbb36009bb6fe02c98cc08"
PREFIX_SHA = "2706d818d1731bb0a2c3b61fab075b771522eb9656075169768864f885757621"
PREFIX_PROFILE_SHA = "53fe73fd486120cf9c87b8253e13e9a7aa53c9184fb3545b6c52a09f5b11464c"
PREFIX_RUN_SHA = "edc2c732a26faba762743e28c4ed827ee1a39825c36a910737ed334b0b099cd0"
CONTROL_SHA = "f3e1f1e84d408db29088c39006b205284ad173bfe900a36f89c6b6122bdb076c"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
COMMIT, BASE = "81243a1300304d7e598156c692be2fcbf2c16268", "5dd69a8ddece6280d576816d2277c73f80607f52"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
LOCAL, LOCAL_SHA = PREFIX / "run_baseline.py", "a7ef2ec62622491626357ff5ddf8fc6bb689a7f26a0d773f125b055c7a24ecff"
SEVEN_LOCAL = RAW / "local-multicopy-ready1-byteenable-stage-264/run_baseline.py"
SEVEN_LOCAL_SHA = "abd9832d33e9705a75deb404b7349282921ff5321216b4ec8d526391e90040bd"
SIX_LOCAL = RAW / "local-multicopy-port0-burst-stage-264/run_baseline.py"
SIX_LOCAL_SHA = "57ec4a9c788d3fbf59f1a5123ee1f197bb967f4390fb4daf9642345aee6b0362"
LOCAL_SCOPE_SHA = "4c3932d15e01ddd513916011aa387efc0837c46cf0523a9ac8e4de7c9df41386"
FIVE_LOCAL = RAW / "local-multicopy-ready1-address-stage-264/run_baseline.py"
FIVE_LOCAL_SHA = "a2d626253826a6b187713f42904720ecdb1d06754ab2776c1fa9d7b39437e2f4"
FOUR_LOCAL = RAW / "local-multicopy-ready1-264/run_baseline.py"
FOUR_LOCAL_SHA = "440013e34d68841d103ca0bea4e3d927a9fd9f50917e10800ad604caa1aec36a"
DRIVER_DEFS = RAW / "local-multicopy-ready1-route-264/run_route.py"
DRIVER_DEFS_SHA = "3e81198bb1c9c89c8c63144b0354138514c5c10ba5b0ef5ecd82d15e3956ccf3"
PHYSICAL_CORE = RAW / "local-multicopy-ready1-address-route-proof-264/physical.py"
PHYSICAL_CORE_SHA = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"
PHYSICAL_CORE_SCOPE_SHA = "976c13d6111f7bda5c7cfdc49df5089e23af4969b3294c12dee2a392dc46790a"
TIMING_CORE = RAW / "driver-copy-ready-groups8-proof-264/timing.py"
TIMING_CORE_SHA = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
TIMING_CORE_SCOPE_SHA = "5088a952653ccd349edb109bd68e038cace200c911ec7707cef1d958897d8032"
DEPS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def comparison(args):
    require(args.prefix_sha256 == PREFIX_SHA and args.profile_sha256 == PROFILE_SHA and not (HERE / "comparison.json").exists(),
            "actual positive prefix/profile pins and exclusive output required")
    native = load(PURE, PURE_SHA, "skid_address_full_native_parser")
    audit = native.Audit()
    pins = ((PURE, PURE_SHA), (Path(__file__), args.self_sha256), (HERE / "scope.md", args.scope_sha256),
        (HERE / "native_scope.py", args.native_sha256), (HERE / "native-scope.md", args.native_scope_sha256),
        (HERE / "physical.py", args.physical_sha256), (HERE / "physical-scope.md", args.physical_scope_sha256),
        (HERE / "timing.py", args.timing_sha256), (HERE / "timing-scope.md", args.timing_scope_sha256),
        (ROUTE / "source-identity.json", args.profile_sha256), (ROUTE / "run_route.py", RUNNER_SHA), (ROUTE / "scope.md", RUNNER_SCOPE_SHA),
        (ROUTE / "route-c0/run.json", args.run_sha256), (PREFIX / "baseline/comparison-prefix.json", args.prefix_sha256),
        (PREFIX / "source-identity.json", PREFIX_PROFILE_SHA), (PREFIX / "baseline/run.json", PREFIX_RUN_SHA),
        (ACCEPTED, ACCEPTED_SHA), (PARENT / "run.json", PARENT_RUN_SHA),
        (CONSTRUCTION, CONSTRUCTION_SHA), (BEFORE / "run.json", CONSTRUCTION_RUN_SHA), (LOCAL, LOCAL_SHA), (PREFIX / "scope.md", LOCAL_SCOPE_SHA),
        (SEVEN_LOCAL, SEVEN_LOCAL_SHA), (SIX_LOCAL, SIX_LOCAL_SHA), (FIVE_LOCAL, FIVE_LOCAL_SHA), (FOUR_LOCAL, FOUR_LOCAL_SHA), (DRIVER_DEFS, DRIVER_DEFS_SHA),
        (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (PHYSICAL_CORE, PHYSICAL_CORE_SHA),
        (PHYSICAL_CORE.parent / "physical-scope.md", PHYSICAL_CORE_SCOPE_SHA),
        (TIMING_CORE, TIMING_CORE_SHA), (TIMING_CORE.parent / "timing-scope.md", TIMING_CORE_SCOPE_SHA))
    for path, expected in pins: audit.bind(path, expected)
    profile, record = native.read(ROUTE / "source-identity.json"), native.read(ROUTE / "route-c0/run.json")
    prefix, parent, construction = (native.read(path) for path in (PREFIX / "baseline/comparison-prefix.json", ACCEPTED, CONSTRUCTION))
    for manifest in (prefix, parent, construction):
        for name, expected in manifest["artifact_sha256"].items():
            require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
            audit.bind(ROOT / name, expected)
        for name, expected in manifest["execution_file_sha256"].items():
            require(Path(name).is_absolute(), "flat execution pathname is not absolute")
            audit.bind(Path(name), expected, execution=True)
    require(prefix["structural_rejection"] is parent["structural_rejection"] is None and
            prefix["native_graph_proof_available"] is parent["native_graph_proof_available"] is parent["physical_scope_proved"] is
            parent["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and prefix["compiler_commit"] == COMMIT and
            prefix["source_identity_sha256"] == PREFIX_PROFILE_SHA and prefix["current_baseline_run_sha256"] == PREFIX_RUN_SHA and
            parent["current_full_run_sha256"] == PARENT_RUN_SHA and
            profile["phase"] == "local-multicopy-port0-skid-address-eighth-stage-fresh-driver-full-route" and
            profile["prefix_proof_sha256"] == PREFIX_SHA and profile["prefix_baseline_run_sha256"] == PREFIX_RUN_SHA and
            profile["control_proof_sha256"] == CONTROL_SHA and profile["host_validation_sha256"] == HOST_SHA and
            profile["accepted_full_proof_sha256"] == ACCEPTED_SHA and profile["accepted_full_run_sha256"] == PARENT_RUN_SHA and
            profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and
            profile["source_archive_sha256"] == ARCHIVE_SHA and profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
            profile["minimum_accepted_memory_mhz"] == 117.77175903320312, "actual prefix/accepted-current/profile/compiler roles differ")
    require(construction["structural_rejection"] is None and construction["native_graph_proof_available"] is
            construction["physical_scope_proved"] is True and construction["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and
            construction["current_full_run_sha256"] == CONSTRUCTION_RUN_SHA and construction["source_identity_sha256"] == CONSTRUCTION_PROFILE_SHA and
            construction["accepted_full_proof_sha256"] == ACCEPTED_SHA and profile["experimental_seventh_full_proof_sha256"] == CONSTRUCTION_SHA and
            profile["experimental_seventh_full_run_sha256"] == CONSTRUCTION_RUN_SHA and len(profile["prefix_fresh_local_models"]) == 8,
            "seventh construction-only provenance or eighth model count differs")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    for key, value in profile.items():
        if key != "input_sha256": require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["source_identity_sha256"] == args.profile_sha256 and record["completed"] is True and record["exit_code"] == 0 and
            record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): args.profile_sha256} and
            record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip", "actual closed run/profile union/runtime differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is outside frozen input closure")
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(ROUTE / "route-c0" / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")}, "actual complete output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output empty")
        audit.bind(Path(name), expected)
    for name, expected in DEPS.items(): audit.bind(ROOT / "sources/misteross/scripts" / name, expected)
    runner = load(ROUTE / "run_route.py", RUNNER_SHA, "skid_address_full_record_definitions")
    driver_defs = load(DRIVER_DEFS, DRIVER_DEFS_SHA, "skid_address_full_driver_log_definitions")
    local = load(LOCAL, LOCAL_SHA, "skid_address_full_eighth_log_parser")
    seven = load(SEVEN_LOCAL, SEVEN_LOCAL_SHA, "skid_address_full_seventh_log_parser")
    six = load(SIX_LOCAL, SIX_LOCAL_SHA, "skid_address_full_sixth_log_parser")
    five = load(FIVE_LOCAL, FIVE_LOCAL_SHA, "skid_address_full_fifth_log_parser")
    four = load(FOUR_LOCAL, FOUR_LOCAL_SHA, "skid_address_full_four_log_parser")
    baseline, accepted_run = native.read(PREFIX / "baseline/run.json"), native.read(PARENT / "run.json")
    require(record["command"] == runner.command(baseline, accepted_run, driver_defs) and
            baseline["execution"] == record["execution"] == accepted_run["execution"] and
            record["cwd"] == baseline["cwd"] == accepted_run["cwd"] and record["diagnostic_environment"] ==
            baseline["diagnostic_environment"] == accepted_run["diagnostic_environment"], "actual command/runtime/environment differs")
    log = (ROUTE / "route-c0/route.log").read_text()
    trial, models = driver_defs.qualification(log), local.qualification(log, seven, six, five, four)
    require(native.canonical(trial) == native.canonical(record["actual_fresh_driver_qualification"]) and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) ==
            native.canonical(profile["prefix_fresh_local_models"]) == native.canonical(prefix["fresh_local_models"]), "fresh driver/eight-local guarded log models differ")
    require(native.canonical(models[:7]) == native.canonical(native.read(BEFORE / "run.json")["actual_selected_local_qualification"]),
            "all seven fresh models differ from actual structural before-image")
    placement_exact = native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall((PREFIX / "baseline/phase.log").read_text())
    before, after = native.read_netlist(BEFORE / "routed.json"), native.read_netlist(ROUTE / "route-c0/routed.json")
    predicted = native.read_netlist(PREFIX / "baseline/placed.json")
    report, parent_report = native.read(ROUTE / "route-c0/timing.json"), native.read(PARENT / "timing.json")
    predicted_report = native.read(PREFIX / "baseline/timing.json")
    timing_core = load(TIMING_CORE, TIMING_CORE_SHA, "skid_address_full_timing_lower_definitions")
    timing = load(HERE / "timing.py", args.timing_sha256, "skid_address_full_current_timing_gate")
    timing_result = timing.evaluate(timing_core, after, report, parent_report, predicted_report, log, record)
    for name, expected in timing_result["evidence"]["pinned_pure_module_sha256"].items():
        require(audit.paths.get(Path(name)) == expected, "timing imported dependency is unauthenticated")
    frozen = load(FREEZE, FREEZE_SHA, "skid_address_full_freeze_definitions")
    selected = load(SELECTED, SELECTED_SHA, "skid_address_full_native_tables", frozen)
    proof = load(HERE / "native_scope.py", args.native_sha256, "skid_address_full_named_slot_proof")
    physical_core = load(PHYSICAL_CORE, PHYSICAL_CORE_SHA, "skid_address_full_physical_lower_definitions")
    physical = load(HERE / "physical.py", args.physical_sha256, "skid_address_full_current_physical_proof")
    graph, physical_evidence, rejection = None, None, None
    try:
        require(after["creator"] == predicted["creator"] and placement_exact, "current compiler creator/original placement sequence differs")
        graph = proof.prove(native, selected, before, after, prefix["native_graph_evidence"], profile, trial)
        ledger = {key: graph[key] for key in ("ready", "driver", "buffer_rows", "private_output_rows")}
        physical_evidence = physical.evaluate(physical_core, before, after, ledger, profile, trial)
        require(physical_evidence["physical_scope_proved"] is True, "independent physical scope did not pass")
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        rejection = str(error)
    audit.finish()
    passed = rejection is None and timing_result["passes_practical_timing_gate"]
    return {"schema": 1, "phase": "local-multicopy-port0-skid-address-eighth-stage-full-route-inspection",
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "source_identity_sha256": args.profile_sha256,
        "current_full_run_sha256": args.run_sha256, "prefix_proof_sha256": args.prefix_sha256, "accepted_full_proof_sha256": ACCEPTED_SHA,
        "structural_before_full_proof_sha256": CONSTRUCTION_SHA, "structural_before_full_run_sha256": CONSTRUCTION_RUN_SHA,
        "structural_before_timing_gain_accepted": False,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256, "native_helper_sha256": args.native_sha256,
        "native_scope_sha256": args.native_scope_sha256, "physical_helper_sha256": args.physical_sha256,
        "physical_scope_sha256": args.physical_scope_sha256, "timing_helper_sha256": args.timing_sha256, "timing_scope_sha256": args.timing_scope_sha256,
        "candidate_completed": True, "structural_rejection": rejection, "native_graph_proof_available": graph is not None,
        "physical_scope_proved": physical_evidence is not None and rejection is None,
        "native_graph_evidence": graph, "physical_evidence": physical_evidence, "timing": timing_result,
        "routed_gain_accepted_under_confirmed_target_clock_rule": passed, "all_71_placement_metrics_exact": placement_exact,
        "actual_fresh_driver_qualification": trial, "fresh_local_models": models, "compiler_read_audit_passed": True,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True,
        "independent_numerical_sta_proved": False, "rbf_decoded_or_hardware_tested": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "native-sha256", "native-scope-sha256", "physical-sha256", "physical-scope-sha256",
            "timing-sha256", "timing-scope-sha256", "prefix-sha256", "run-sha256", "profile-sha256"):
        parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    import json
    with (HERE / "comparison.json").open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "native_graph_proof_available",
        "physical_scope_proved", "routed_gain_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__":
    main()
