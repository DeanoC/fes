# Eighth full-route timing scope

The pure timing evaluator receives the complete fresh eighth lossless native document, current final signoff report, accepted fifth final report, own eighth predicted report, actual full log and completed record. It imports only pinned lower-level _load/_paths definitions, the native topology parser and closed board dependency modules; no historical timing evaluator or threshold is called.

Timing compares directly with accepted fifth 6dcf8c4b / 5ed3c077 at memory 117.77175903320312 MHz, pixel 93.6504898071289 MHz and capture 259.49139404296875 MHz. The structurally validated but rejected seventh result is not a timing reference. All 15290 current native paths, endpoints, seven clock pairs, signed finite segment sums and reported windows must match the accepted and own predicted coverage. The reported capture-to-memory window remains 5 ns, and memory half-cycle remains 3.8459999561309814 ns.

Acceptance requires a strict memory gain over 117.77175903320312 MHz, pixel and capture meeting their actual constraints, strictly positive headroom for all six non-target pairs and no final signoff hold/min warning. The target 130 MHz miss is explicitly disclosed rather than converted into a positive window. Lower positive phase headroom is allowed and reported; all-clock Fmax nonregression is diagnostic. Actual HIP/normal completion and recorder Fmax/last-hold scan are independently crosschecked.

The wrapper computes this timing result before structural/physical checks so a rejected graph still preserves actual timing evidence. No unreported extrema, numerical physical delays, fitted equivalence, RBF decoding or hardware result is independently inferred.
