"""Record fresh driver candidate0/full routing from a proved additive ready1 prefix."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
BASELINE = HERE.parent / "local-multicopy-ready1-264"
COMPILER = HERE.parent / "local-multicopy-264"
PROOF = BASELINE / "baseline/comparison-prefix.json"
PROOF_SHA = "10016a0f227b801995eebc5c41a79c3b08d28bb6932b785349a60529d0048709"
PREFIX_HELPER_SHA = "0a52299ec2c2547dd24407bbad78caa904093ee0514c0c28ea6eda04e1e44744"
PREFIX_SCOPE_SHA = "a1f8eef2d59053bcebcf3e0106ace9eaa764c00f73a0abc138df2f452e43caab"
CONTROL = COMPILER / "baseline/comparison-control.json"
CONTROL_SHA = "f3e1f1e84d408db29088c39006b205284ad173bfe900a36f89c6b6122bdb076c"
HOST = COMPILER / "validation/host-validation.json"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
ACCEPTED = HERE.parent / "driver-copy-route-proof-v2-264/comparison.json"
ACCEPTED_SHA = "a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304"
ACCEPTED_RUN = HERE.parent / "driver-copy-route-264/route-c0/run.json"
ACCEPTED_RUN_SHA = "71b2575f309d2fdfe9d23ad356f6c19c361a228477a85c446e442b0c75ff3bb2"
FOLDER, PROFILE = HERE / "route-c0", HERE / "source-identity.json"
COMMIT = "81243a1300304d7e598156c692be2fcbf2c16268"
BASE = "5dd69a8ddece6280d576816d2277c73f80607f52"
IDENTITY_SHA = "8678aa88a57a59c43fc94bab14ff71fdff47b95a9e95d8bc308c82ad7826e88b"
BASELINE_RUN_SHA = "2e3996888f9297140962000d890102de5ea6936a014bca1c9c603fbe19284e5e"
PLAN_SHA = "5431fbdd541657117f5782ea107b60c573f1a820f2a579e5a2e9c0f4f1af8b94"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
OLD_BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
OLD_ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
COMPILER_SOURCE = MODULE / "build/toolchain-ramtest-timing/src/nextpnr-local-multicopy-264"
PURE = HERE.parent / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
LOCAL = BASELINE / "run_baseline.py"
LOCAL_SHA = "440013e34d68841d103ca0bea4e3d927a9fd9f50917e10800ad604caa1aec36a"
SOURCE = "ddr0_test.burst_MISTRAL_ALUT3_Q"
SINK = "ddr0_test.cmd_following_MISTRAL_ALUT_ARITH_SO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO_SO_MISTRAL_ALUT2_B_Q_MISTRAL_ALUT3_Q_C_MISTRAL_ALUT_ARITH_SO_CI_MISTRAL_ALUT_ARITH_CO_CI_MISTRAL_ALUT_ARITH_CO"
MODEL_KEYS = ("index", "candidate", "groups_budget", "selected_groups", "inner", "outer", "primary_lab", "bel",
    "ena_users", "gain_ps", "ff_shift", "compiled_clock_hold_boundary_guards_passed")
SCRIPTS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
    "functional_execution.py": "095843d0ba243056489e058f40b768b30f7613bd7087797c210549da4013ae50",
    "compiler_read_audit.py": "276254d178ee3371d056e0278251648196ab566329eeb70ad810d7562147d437",
    "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
    "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON field: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(type(expected) is str and re.fullmatch(r"[0-9a-f]{64}", expected), "invalid SHA256")
    if path in inputs:
        require(inputs[path] == expected, "conflicting original pathname hash")
    else:
        require(sha(path) == expected, "original artifact changed: " + path)
        inputs[path] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "bound original pathname changed: " + path)


def load(path, name, expected):
    require(sha(path) == expected, "pure parser bytes differ before import")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def clean_source():
    def git(*args):
        return subprocess.run(["git", "-C", str(COMPILER_SOURCE), *args], check=True, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.strip()
    require(git("rev-parse", "HEAD") == COMMIT and not git("status", "--porcelain", "--untracked-files=all") and
        git("merge-base", BASE, COMMIT) == BASE and set(git("diff", "--name-only", BASE, COMMIT).splitlines()) ==
        {"mistral/local_remap.cc", "mistral/tests/remap_plan.cc"}, "compiler is not the clean two-file multicopy result")


def command(baseline, accepted):
    result = list(accepted["command"])
    require("--no-route" not in result and "--compress-rbf" not in result and
        result.count("--router") == result.count("--gpu-device") == result.count("--remap-lut-driver-candidate") == 1 and
        result[result.index("--router") + 1] == "gpu" and result[result.index("--gpu-device") + 1] == "1" and
        result[result.index("--remap-lut-driver-candidate") + 1] == "0", "accepted full GPU selectors unexpected")
    require(baseline["command"][0] == str(COMPILER / "nextpnr-mistral") and baseline["command"].count("--no-route") == 1 and
        not any(flag in baseline["command"] for flag in ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")),
        "proved baseline selectors unexpected")
    result[0] = baseline["command"][0]
    for flag, path in (("--remap-plan", BASELINE / "local-plan.json"),
            ("--remap-lut-driver-critical", BASELINE / "baseline/timing.json"),
            ("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json"), ("--rbf", FOLDER / "core.rbf")):
        require(result.count(flag) == 1, "ambiguous output selector")
        result[result.index(flag) + 1] = str(path)
    equivalent = list(baseline["command"])
    equivalent.remove("--no-route")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json")):
        equivalent[equivalent.index(flag) + 1] = str(path)
    equivalent += ["--remap-lut-driver-critical", str(BASELINE / "baseline/timing.json"),
        "--remap-lut-driver-candidate", "0", "--rbf", str(FOLDER / "core.rbf")]
    require(result == equivalent, "full command changes outside compiler/four-stage plan/current guide/outputs")
    return result


def prepare(proof_sha, self_sha, scope_sha):
    require(proof_sha == PROOF_SHA and not PROFILE.exists() and not FOLDER.exists(), "wrong positive proof or outputs already exist")
    inputs = {}
    for path, expected in ((PROOF, proof_sha), (HERE / "run_route.py", self_sha), (HERE / "scope.md", scope_sha)):
        bind(inputs, path, expected)
    proof = read(PROOF)
    require(proof["schema"] == 1 and proof["phase"] == "local-multicopy-ready1-additive-conditional-native-prefix" and
        proof["compiler_commit"] == COMMIT and proof["source_identity_sha256"] == IDENTITY_SHA and
        proof["delta_base_commit"] == BASE and proof["current_baseline_run_sha256"] == BASELINE_RUN_SHA and
        proof["control_proof_sha256"] == CONTROL_SHA and proof["generator_sha256"] == PREFIX_HELPER_SHA and
        proof["scope_sha256"] == PREFIX_SCOPE_SHA and
        all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available",
            "fresh_driver_guide_available_after_conditional_prefix_proof", "final_original_path_metadata_and_runtime_hashes_stable")) and
        proof["structural_rejection"] is None, "additive prefix lacks its closed bounded proof")
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "runtime pathname is not absolute")
        bind(inputs, name, expected)
    require(inputs.get(str(BASELINE / "compare_prefix.py")) == proof["generator_sha256"] and
        inputs.get(str(BASELINE / "comparison-scope.md")) == proof["scope_sha256"] and
        inputs.get(str(CONTROL)) == CONTROL_SHA and inputs.get(str(HOST)) == HOST_SHA and
        inputs.get(str(BASELINE / "local-plan.json")) == PLAN_SHA, "closed proof/control/helper/plan anchors differ")
    control, host = read(CONTROL), read(HOST)
    require(control["compiler_commit"] == COMMIT and control["structural_rejection"] is None and
        all(control[key] is True for key in ("candidate_completed", "native_graph_proof_available",
            "complete_predicted_report_exact", "fresh_additive_stage_control_prerequisite_proved")) and
        host["result_commit"] == host["compiler_commit"] == COMMIT and host["binary_sha256"] == BINARY_SHA and
        host["source_archive_sha256"] == ARCHIVE_SHA and host["build_passed"] is host["clean_committed_checkout"] is True,
        "proved three-stage control or current host/compiler differs")
    identity, baseline = read(BASELINE / "source-identity.json"), read(BASELINE / "baseline/run.json")
    require(inputs.get(str(BASELINE / "source-identity.json")) == IDENTITY_SHA and
        inputs.get(str(BASELINE / "baseline/run.json")) == BASELINE_RUN_SHA and identity["compiler_commit"] == baseline["compiler_commit"] == COMMIT and
        identity["delta_base_commit"] == baseline["delta_base_commit"] == BASE and
        identity["binary_sha256"] == baseline["binary_sha256"] == BINARY_SHA and
        identity["source_archive_sha256"] == baseline["source_archive_sha256"] == ARCHIVE_SHA and
        baseline["completed"] is True and baseline["exit_code"] == 0 and baseline["compiler_read_audit_passed"] is True,
        "closed current source/run identity differs")
    require(baseline["input_sha256"] == {**identity["input_sha256"], str(BASELINE / "source-identity.json"): IDENTITY_SHA} and
        all(inputs.get(path) == expected for path, expected in {**baseline["input_sha256"],
            **baseline["output_sha256"], **baseline["execution"]["files"]}.items()), "current profile-union input/runtime/output closure differs")
    require(baseline["command"] == identity["command"] and baseline["diagnostic_environment"] == identity["diagnostic_environment"] and
        baseline["cwd"] == identity["cwd"] == str(MODULE) and baseline["execution"] == identity["baseline_execution"] and
        baseline["execution"]["gpu_device"] == 1 and inputs.get(str(COMPILER / "nextpnr-mistral")) == BINARY_SHA and
        inputs.get(str(COMPILER / "source.tar.gz")) == ARCHIVE_SHA, "current exact compiler invocation differs")
    bind(inputs, PURE, PURE_SHA)
    bind(inputs, LOCAL, LOCAL_SHA)
    for name, expected in SCRIPTS.items():
        bind(inputs, MODULE / "scripts" / name, expected)
    require(inputs.get(str(ACCEPTED)) == ACCEPTED_SHA and inputs.get(str(ACCEPTED_RUN)) == ACCEPTED_RUN_SHA,
        "accepted full command/proof are not in closed flat inputs")
    accepted_proof, accepted = read(ACCEPTED), read(ACCEPTED_RUN)
    require(accepted_proof["structural_rejection"] is None and accepted_proof["candidate_accepted_under_confirmed_target_clock_rule"] is True and
        accepted["completed"] is True and accepted["exit_code"] == 0 and accepted["compiler_read_audit_passed"] is True and
        accepted["compiler_commit"] == BASE and accepted["binary_sha256"] == OLD_BINARY_SHA and
        accepted["source_archive_sha256"] == OLD_ARCHIVE_SHA and accepted["diagnostic_environment"] == baseline["diagnostic_environment"] and
        accepted["cwd"] == baseline["cwd"], "accepted full command/source role differs")
    expected_runtime = copy.deepcopy(accepted["execution"])
    require(expected_runtime["files"].pop(accepted["command"][0]) == OLD_BINARY_SHA,
        "accepted runtime compiler alias is not its actual binary")
    expected_runtime["files"][str(COMPILER / "nextpnr-mistral")] = BINARY_SHA
    expected_runtime["environment"]["PATH"] = str(COMPILER) + ":/usr/bin:/bin"
    require(expected_runtime == baseline["execution"], "hardware/runtime changes outside compiler file and controlled PATH")
    native, local = load(PURE, "ready1_route_native", PURE_SHA), load(LOCAL, "ready1_route_local", LOCAL_SHA)
    actual_models = local.local_qualification((BASELINE / "baseline/phase.log").read_text())
    require(canonical(actual_models) == canonical(proof["fresh_local_models"]) ==
        canonical(baseline["actual_selected_local_qualification"]), "fresh current local model/log/record differs")
    require([model["groups_budget"] for model in actual_models] == [8, 1, 1, 1] and
        all(canonical({key: actual_models[index][key] for key in MODEL_KEYS}) ==
            canonical({key: proof["old_local_models"][index][key] for key in MODEL_KEYS}) for index in range(3)) and
        actual_models[1]["bel"] == "MISTRAL_COMB.29.13.0" and actual_models[1]["ena_users"] == 2 and
        actual_models[3]["bel"] == "MISTRAL_COMB.29.21.1" and actual_models[3]["ena_users"] == 1 and
        read(BASELINE / "local-plan.json")["steps"] == identity["local_plan_steps"] and
        identity["local_plan_steps"][:3] == read(identity["original_plan_path"])["steps"],
        "proved original-three/additive local stages or descriptors differ")
    top = native.read_netlist(BASELINE / "baseline/placed.json")["modules"]["top"]
    graph = proof["native_graph_evidence"]
    require(graph["serialized_native_scope_proved"] is True and graph["retained_copy_and_consumers_exact"] is True and
        graph["all_original_ff_placements_and_nonprivate_raw_slots_exact"] is True and
        graph["declared_ena_redirect_count"] == len(graph["declared_ena_redirects"]) == 1 and
        graph["new_clone"] == actual_models[3]["outer"] + "$local_remap$1" and graph["assignments_checked"] == 16 and
        graph["retained_copy"] == actual_models[1]["outer"] + "$local_remap" and
        len(graph["retained_two_consumer_slots"]) == 2 and
        graph["private_output_owner_count"] == len(graph["explicit_private_output_owners"]) == 4 and
        top["cells"][graph["new_clone"]]["attributes"]["NEXTPNR_BEL"] == actual_models[3]["bel"] and
        top["cells"][graph["retained_copy"]]["attributes"]["NEXTPNR_BEL"] == actual_models[1]["bel"],
        "declared additive/retained ready1 copy and ENA scope differs")
    source, sink = top["cells"][SOURCE], top["cells"][SINK]
    require(source["type"] == "MISTRAL_ALUT3" and sink["type"] == "MISTRAL_ALUT_ARITH" and
        source["connections"]["Q"] == sink["connections"]["A"] and len(source["connections"]["Q"]) == 1,
        "actual current native LUT-to-arithmetic edge differs")
    qbit = source["connections"]["Q"][0]
    users = [(name, port, index) for name, cell in top["cells"].items() for port, bits in cell["connections"].items()
        if cell["port_directions"][port] == "input" for index, bit in enumerate(bits) if bit == qbit]
    require(type(qbit) is int and len(users) == 49 and (SINK, "A", 0) in users and
        not any(qbit in port["bits"] for port in top["ports"].values()), "current source Q user boundary differs")
    carry_bit = sink["connections"]["CO"]
    successors = [(name, cell) for name, cell in top["cells"].items() if cell["type"] == "MISTRAL_ALUT_ARITH" and
        cell["connections"].get("CI") == carry_bit and name != SINK]
    require(len(carry_bit) == 1 and type(carry_bit[0]) is int and len(successors) == 1,
        "actual immediate carry successor is not uniquely attributable")
    labs = {tuple(model["primary_lab"]) for model in actual_models}
    names = {SOURCE, SINK, successors[0][0], graph["retained_copy"], graph["new_clone"]}
    for index, model in enumerate(actual_models):
        names.update((model["inner"], model["outer"]))
        if index < 3:
            names.add(model["outer"] + "$local_remap")
    for name in sorted(names):
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared local/driver/carry owner lacks an actual placed BEL")
        labs.add(tuple(map(int, match.groups()[:2])))
    all_ffs = []
    for name, cell in top["cells"].items():
        if cell["type"] != "MISTRAL_FF":
            continue
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None, "original FF lacks its placed BEL")
        if tuple(map(int, match.groups()[:2])) in labs:
            all_ffs.append({"cell": name, "record": cell})
    selected_names = {row["cell"] for row in graph["declared_ena_redirects"]} | {
        slot[0] for slot in graph["retained_two_consumer_slots"]}
    require(selected_names <= {row["cell"] for row in all_ffs}, "declared old/new ready cohorts miss the whole-FF closure")
    report = read(BASELINE / "baseline/timing.json")
    relevant = set()
    for path in report["critical_paths"]:
        if math.fsum(segment["delay"] for segment in path["path"]) <= path["max_delay"]:
            continue
        for segment in path["path"]:
            if segment["type"] == "routing":
                launch, capture = segment["from"], segment["to"]
                if (top["cells"][launch["cell"]]["type"] in {"MISTRAL_ALUT" + str(width) for width in range(2, 7)} and
                        top["cells"][capture["cell"]]["type"] == "MISTRAL_ALUT_ARITH" and capture["port"] in {"A", "B", "C", "D0", "D1"}):
                    relevant.add((launch["cell"], capture["cell"], capture["port"]))
    require(relevant == {(SOURCE, SINK, "A")} and report["timing_report_paths"] == 16384 and
        len(report["critical_paths"]) == 15290, "actual fresh guide relevant edge/report differs")
    result = {"schema": 1, "phase": "local-multicopy-ready1-additive-combined-fresh-driver-full-route", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA,
        "prefix_proof_sha256": proof_sha, "prefix_source_identity_sha256": IDENTITY_SHA, "helper_sha256": self_sha,
        "scope_sha256": scope_sha, "host_validation_sha256": HOST_SHA, "control_proof_sha256": CONTROL_SHA,
        "prefix_baseline_run_sha256": BASELINE_RUN_SHA, "local_plan_sha256": PLAN_SHA,
        "prefix_generator_sha256": proof["generator_sha256"], "prefix_scope_sha256": proof["scope_sha256"],
        "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": ACCEPTED_RUN_SHA,
        "command": command(baseline, accepted), "cwd": baseline["cwd"],
        "diagnostic_environment": baseline["diagnostic_environment"], "baseline_execution": baseline["execution"],
        "input_sha256": dict(sorted(inputs.items())), "prefix_fresh_local_models": actual_models,
        "declared_driver_edge": [SOURCE, SINK, "A"], "driver_candidate": 0, "driver_site_must_qualify_freshly": True,
        "declared_ena_redirects": graph["declared_ena_redirects"], "new_ready_clone": graph["new_clone"],
        "new_ready_clone_bel": actual_models[3]["bel"], "retained_ready_copy": graph["retained_copy"],
        "retained_ready_copy_consumers": graph["retained_two_consumer_slots"],
        "prefix_private_output_owner_bijections": graph["explicit_private_output_owners"],
        "driver_current_source_record": source, "driver_current_sink_record": sink,
        "driver_current_immediate_carry_successor": {"cell": successors[0][0], "record": successors[0][1]},
        "declared_original_local_driver_and_carry_cells": sorted(names),
        "affected_whole_labs": sorted(map(list, labs)), "all_original_ff_members_in_affected_labs": sorted(all_ffs, key=lambda row: row["cell"]),
        "minimum_accepted_memory_mhz": 117.34334564208984, "routed_graph_proof_available": False,
        "physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    finish(inputs); clean_source()
    with PROFILE.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"profile_sha256": sha(PROFILE), "inputs": len(inputs), "affected_labs": result["affected_whole_labs"],
        "original_ffs_in_affected_labs": len(all_ffs)}, indent=2))


def qualification(log):
    discovery = re.findall(r"^Info: LUT driver copy discovery: (\d+) bounded data edges\.$", log, re.M)
    sources = re.findall(r"^Info: LUT driver copy discovery source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) users=(\d+) rows=(\d+)$", log, re.M)
    domains = re.findall(r"^Info: LUT driver copy domains source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) endpoints=(\d+) timed_pairs=(\d+) unrelated_pairs=(\d+) hold_pairs=(\d+) reference_free=([01])$", log, re.M)
    require(discovery == ["1"] and sources == [(SOURCE, SINK, "A", "49", "8")] and len(domains) == 1 and
        domains[0][:3] == (SOURCE, SINK, "A"), "fresh driver discovery/source/domain coverage differs")
    endpoint_count, timed, unrelated, hold, reference_free = map(int, domains[0][3:])
    require(endpoint_count > 0 and timed + unrelated >= endpoint_count and hold <= timed + unrelated and
        reference_free == int(unrelated > 0), "fresh driver pair coverage is incomplete")
    candidates = list(re.finditer(r"^Info: LUT driver copy candidate (\d+): source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps\.$", log, re.M))
    trials = list(re.finditer(r"^Info: LUT driver copy trial source=(\S+) sink=(\S+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps improve=([01]) endpoints=([01]) clocks=([01]) hold=([01])$", log, re.M))
    applications = list(re.finditer(r"^Info: LUT driver copy applied candidate (\d+); full routing and signoff still required\.$", log, re.M))
    require(len(candidates) == len(applications) == 1 and trials and candidates[0].groups()[0:4] == ("0", SOURCE, SINK, "A") and
        applications[0][1] == "0" and trials[-1].end() < candidates[0].start() < applications[0].start(), "fresh selected driver qualification missing")
    chosen, trial = candidates[0].groups()[1:], trials[-1].groups()
    require(chosen == trial[:5] and trial[5:] == ("1", "1", "1", "1") and int(trial[4]) >= 250,
        "selected driver does not bind its fresh final guarded trial")
    return {"source": SOURCE, "sink": SINK, "port": "A", "candidate": 0, "bel": trial[3], "gain_ps": int(trial[4]),
        "actual_trial_count": len(trials), "domain_summary": list(domains[0][3:]),
        "compiler_model_guards_passed": True, "independent_sta_proved": False}


def route(profile_sha):
    inputs = {}
    bind(inputs, PROFILE, profile_sha)
    profile = read(PROFILE)
    require(profile["compiler_commit"] == COMMIT and not FOLDER.exists(), "route output exists or compiler identity changed")
    for path, expected in profile["input_sha256"].items():
        bind(inputs, path, expected)
    require(inputs[str(HERE / "run_route.py")] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"],
        "frozen helper/scope differs")
    baseline, accepted = read(BASELINE / "baseline/run.json"), read(ACCEPTED_RUN)
    require(profile["command"] == command(baseline, accepted) and profile["baseline_execution"] == baseline["execution"] and
        profile["diagnostic_environment"] == baseline["diagnostic_environment"], "frozen command/runtime differs")
    for name, expected in SCRIPTS.items():
        require(inputs.get(str(MODULE / "scripts" / name)) == expected and sha(MODULE / "scripts" / name) == expected, "executed project dependency differs")
    clean_source()
    local = load(LOCAL, "ready1_route_local_actual", LOCAL_SHA)
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and sha(loaded.__file__) == expected, "loaded project module differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(Path(profile["command"][0]),
        f"base_commit={BASE}; experimental_source_sha256={ARCHIVE_SHA}; sha256={BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs,
        "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env),
            "actual runtime/ambient diagnostics changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream:
            stream.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            result = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = result.returncode, True
        invocation.verify()
        require(result.returncode == 0, "full selected route failed")
        log = (FOLDER / "route.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
            "Running the GPU router" in log and "Running signoff timing analysis..." in log and
            "Running predicted placed timing analysis for --report" not in log, "full GPU signoff provenance missing")
        record["actual_selected_local_qualification"] = local.local_qualification(log)
        require(canonical([{key: row[key] for key in MODEL_KEYS} for row in record["actual_selected_local_qualification"]]) ==
            canonical([{key: row[key] for key in MODEL_KEYS} for row in profile["prefix_fresh_local_models"]]), "fresh local stages differ from proved additive prefix")
        record["actual_fresh_driver_qualification"] = qualification(log)
        report = read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
            all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()),
            "fresh full timing report invalid")
        record["fmax"] = report["fmax"]
        record["actual_live_gpu_backend"] = board._require_gpu_backend(log)
        require(record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log),
            "actual live HIP routing completion absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        record["final_reported_hold_violations"] = "Hold/min time violation" in last
        record["last_signoff_hold_warning_lines"] = [line for line in last.splitlines() if
            re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not record["final_reported_hold_violations"] and not record["last_signoff_hold_warning_lines"],
            "LAST signoff contains a hold/min warning or violation")
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "full actual output missing")
            record["output_sha256"][str(path)] = sha(path)
        finish({**inputs, **record["output_sha256"]}); clean_source()
        record["completed"] = True
        print(json.dumps({"completed": True, "fmax": record["fmax"], "driver": record["actual_fresh_driver_qualification"],
            "final_reported_hold_violations": record["final_reported_hold_violations"], "routed_gain_accepted": False}, indent=2))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): sha(FOLDER / name) for name in
                        ("route.log", "routed.json", "timing.json", "core.rbf") if (FOLDER / name).is_file()}
                try:
                    invocation.verify()
                    finish({**inputs, **record.get("output_sha256", {})})
                    clean_source()
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False
                    record["final_original_input_output_runtime_hashes_stable"] = False
                    record["final_rehash_failure"] = repr(error)
                    raise
                finally:
                    (FOLDER / "run.json").write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "route"))
    for name in ("prefix-proof-sha256", "self-sha256", "scope-sha256", "profile-sha256"):
        parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(all((args.prefix_proof_sha256, args.self_sha256, args.scope_sha256)), "prepare pins missing")
        prepare(args.prefix_proof_sha256, args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256 is not None, "route profile pin missing")
        route(args.profile_sha256)


if __name__ == "__main__":
    main()
