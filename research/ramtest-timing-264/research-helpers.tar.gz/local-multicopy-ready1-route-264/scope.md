# Additive ready1 prefix: fresh driver qualification and full route recorder

Root alone prepares and runs this recorder, without a concurrent GPU job.
Preparation requires the explicit `--prefix-proof-sha256` of the completed
positive additive prefix `10016a0f...`. Its actual comparison helper/scope
`0a52299e...`/`a1f8eef2...`, profile `8678aa88...`, baseline run `2e399688...`,
plan `5431fbdd...`, positive original-three control `f3e1f1e8...`, current
host `98c1f40a...`, and complete flat original-path artifact/runtime closure
are bound. No old generator, authenticator, main, build, test or benchmark
is replayed. Only pure pinned32fd lossless parsing and the frozen440013e3
runner's local qualification parser are imported.

The exact current compiler81243, binary91a and archivec947 paths remain in
use. The source must remain the clean committed two-file multicopy result
on base5dd. The full command is derived independently from the accepted
full RBF invocation and the proved current no-driver baseline. Relative
to the accepted command, only the compiler pathname, four-stage plan,
fresh current predicted driver guide, and write/report/RBF output aliases
change. Relative to the current baseline, the sole no-route flag is
removed and fresh driver candidate0/RBF options are appended. Both full
command arrays must agree exactly. The original three8/1/1 descriptors,
all other options, inputs, seed, GPU1 and diagnostic environment remain
unchanged. The fourth descriptor remains current109/candidate0/group1,
with pin optimization disabled and fixed FF placement.

The accepted execution is compared to the current baseline frame after
only its actual old executable file and controlled PATH are replaced by
the current compiler file/PATH. Hardware, kernel, KFD files, GPU1, tracer,
libraries and all other environment values must agree exactly. This is
an explicit cross-compiler lineage comparison, not a claim that the old
accepted route used compiler81243. FunctionalInvocation must then capture
exactly the proved current baseline runtime. All five loaded project
Python module paths and hashes are checked before controlled audited_run.

The conditional prefix independently retains the old ready1 copy at
COMB29.13.0 and its two consumers, and adds `$local_remap$1` at COMB29.21.1
for the one complete fresh LAB cohort. Its16-row plain-SIG function and
four per-owner private-output records are bound as pre-route evidence.
They grant no arbitrary raw-ID, buffer, pin or placement normalization in
the future routed image. All four local stages must freshly reproduce
the prefix's selected model fields and compiled fixed-FF/clock/hold/
boundary guards. Earlier rejected trials remain part of the actual log.

Preparation declares the actual original LUT source, arithmetic operand
sink and unique immediate CO-to-CI carry successor. Their LABs are included
in the whole-LAB FF-record closure, together with all retained/local cone
owners, their clone sites, primary LABs and old/new ready cohorts. Every
original FF serialized record in that union is retained. This is a
predeclaration for later physical review; pre-route pin/LAB/cache state
that was not exported is not independently proved. The future driver
clone site is not preselected by this recorder.

The full current cap16384/15,290-path report must contain the unique
violated ordinary burst-LUT-to-ARITH.A edge. Its49 source-Q users, no public
Q boundary and native immediate carry identity are checked from the
current prefix. Driver candidate0 must qualify anew: discovery, eight-row
source width, complete compiled domain summary, final preceding trial,
actual site/gain, all four guards and application must match. No candidate
site or numerical gain is borrowed from an old driver listing. Unserialized
per-pair extrema are compiled guard evidence, not independently recomputed
STA.

Execution writes exclusive new outputs and requires normal live HIP GPU
completion, no CPU fallback, actual RBF signoff, finite positive Fmax,
cap16384/15,290 paths and zero LAST-signoff literal or broader hold/min
warnings. Actual Fmax, local/driver qualifications and every output digest
are recorded. Success and failure paths recheck the current runtime,
source and all original input/output hashes; failures retain actual status
and available partial output hashes. A rejected/incomplete prefix cannot
prepare this route profile.

Compiler completion is not native, physical LUT/FF/carry/BUF/LAB equivalence,
numerical timing-window, RBF-identity or gain acceptance. Those flags remain
false. A later independent full proof must establish the additive ready
copy while preserving the old two users, original FFs and controls, actual
source/copy/operand/immediate carry closure, complete native paths/windows,
memory strictly above117.34334564208984MHz, required non-target constraints,
positive non-target headroom and zero final holds. Lower positive margins
must be disclosed; all-clock Fmax nonregression is a separate diagnostic.
Hardware acceptance remains false.
