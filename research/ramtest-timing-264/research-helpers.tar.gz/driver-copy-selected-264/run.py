"""Root-only selected candidate0 no-route snapshot; no full routing API."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

import freeze


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    profile, inputs, ctx = freeze.authenticate_freeze(args.source_identity_sha256)
    freeze.require(not freeze.FOLDER.exists(), "selected snapshot output folder already exists")
    sys.path.insert(0, str(freeze.MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    tool_identity = (f"base_commit={freeze.BASE}; experimental_source_sha256={profile['source_archive_sha256']}; "
                     f"sha256={profile['binary_sha256']}")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(freeze.HERE / "nextpnr-mistral", tool_identity)}, 1)
    try:
        freeze.require(not any(name.startswith("NEXTPNR_MISTRAL_") for name in invocation.env),
                       "ambient compiler diagnostics are forbidden")
        record = freeze.record_template(profile, args.source_identity_sha256, invocation.inputs, ctx)
        freeze.authenticate_phase(record, profile, args.source_identity_sha256, ctx)
        for path, expected in record["execution"]["files"].items():
            freeze.bind(inputs, path, expected)
        freeze.FOLDER.mkdir()
        manifest, started = freeze.FOLDER / "run.json", time.monotonic()
        with manifest.open("x") as output:
            output.write(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
        try:
            with (freeze.FOLDER / "phase.log").open("x") as log:
                result = audited_run(record["command"], source_root=freeze.MODULE, cwd=record["cwd"],
                    env={**invocation.env, **record["diagnostic_environment"]}, stdout=log,
                    stderr=subprocess.STDOUT, check=False, timeout=2400)
            record["exit_code"], record["elapsed_seconds"] = result.returncode, time.monotonic() - started
            record["compiler_read_audit_passed"] = True
            invocation.verify()
            freeze.require(result.returncode == 0 and all((freeze.FOLDER / name).is_file() and
                           (freeze.FOLDER / name).stat().st_size > 0 for name in ("phase.log", "placed.json", "timing.json")),
                           "selected snapshot failed or omitted actual outputs")
            log = (freeze.FOLDER / "phase.log").read_text()
            freeze.require("Info: Program finished normally." in log and
                           not any(line.startswith("ERROR:") for line in log.splitlines()) and
                           log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1 and
                           log.count("Info: LUT driver copy applied candidate 0; full routing and signoff still required.") == 1 and
                           not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...")) and
                           not any((freeze.FOLDER / name).exists() for name in ("core.rbf", "routed.json")),
                           "selected phase is not its normal no-route candidate0 application")
            record["output_sha256"] = {str(freeze.FOLDER / name): freeze.sha(freeze.FOLDER / name)
                                      for name in ("phase.log", "placed.json", "timing.json")}
            record["completed"] = True
            freeze.authenticate_phase(record, profile, args.source_identity_sha256, ctx)
            freeze.finish({**inputs, **record["output_sha256"]})
            print(json.dumps({key: record[key] for key in ("phase", "compiler_commit", "completed", "exit_code", "elapsed_seconds")}, indent=2))
        except BaseException as error:
            record["completed"] = False
            record["failure"], record["elapsed_seconds"] = repr(error), time.monotonic() - started
            if "exit_code" not in record:
                record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
                record["exit_code_is_adapter_sentinel"] = True
            raise
        finally:
            manifest.write_text(json.dumps(record, indent=2, sort_keys=True, allow_nan=False) + "\n")
    finally:
        invocation.close()


if __name__ == "__main__":
    main()
