# Fresh candidate0 selected snapshot

Root alone activates and runs this package. It supports one selected no-route
snapshot; it has no routed execution or acceptance API. Previous artifacts,
helpers, source and builds are immutable. Authors execute no helpers or tests.

The completed same-binary domains listing proof `2af21990…` binds 491 artifacts
and 281 runtime files, including own baseline proof `e6cee54c…`, the whole
upstream accepted/diagnostic closure and actual 15,290-path guide. Its source
identity is `c0ff5c87…`, compiler result `5dd69a8d…` on `9dc3633a…`, binary
`2ebe29ca…`. Activation copies that exact frozen binary/archive/config; it
does not rebuild, retest, generate a new baseline or replay old authenticators.
All original pathnames remain bound and rehashed, including symlinks.

Candidate0 is derived from the finalized current listing: ordinary ALUT3
decoder to one arithmetic A operand, original Q has 49 consumers, qualified
site `MISTRAL_COMB.33.31.0`, modeled gain 1,512ps and all four trial guards true.
Domain counts are 334 endpoints, 331 timed setup pairs, 3 unrelated pairs,
331 hold-related pairs and a separate reference-free frame. Counts and
numerical domain guards are compiled/tested evidence; individual numerical
before/after bounds are not serialized or independently reconstructed.

The command retains every prior input, seed, selection, report cap16,384,
constraint, diagnostic environment and GPU selector. Only the executable
alias, write/report output paths and final driver candidate -1 to 0 change.
The guide remains the actual same-binary disabled domains baseline report.
One --no-route remains; no RBF/router/signoff operation executes. Runtime and
compiler-read audit are controlled with FunctionalInvocation/audited_run.

Selected proof requires exactly one ordinary LUT and one private Q net added,
one original scalar ARITH operand redirected and all other typed original
native bits/aliases/ports/params/attrs/BELs/order/duplicate PLL records exact.
Source Q retains the exact other 48 consumer slots; clone Q has only the
selected operand. Each distinct connected input net gains exactly the clone
input port slots, including repeated input multiplicity; folded constants
gain no net loads. The existing source/root/carry/FF/BUF population cannot move
or acquire unrelated topology/metadata changes. Any serialized selector
setting difference must be absent or independently checked against its
literal actual command; there is no blanket settings normalization.

Raw source/clone LUT tables and native input bindings are checked exhaustively
(8 rows for this ALUT3). Actual effective packed constants/inversions and
complete physical pin maps are not exported by this no-route snapshot.
Thus raw-table equality is explicitly conditional on the compiler's copied
packed pin states. No independent physical Boolean copy, combInfo cache,
indexed-store/free-list/bucket/pointer, GPU ID, CRAM/RBF, final hold or hardware
proof is claimed. The actual selected snapshot must precede any separate
full physical evaluator and before-run routed scope.

The new report uses only actual current native paths and emitted finite
delays/windows. Constraints and actual clock-pair windows stay bound to the
same-binary baseline, with native pair/endpoint coverage and cap. Path changes
must reference the actual clone/redirected operand; no guide pruning, copied
routed delays, BUF collapse or numeric bit renaming is permitted. Modeled
Fmax changes are diagnostic, not routed gain.

Root sequence: freeze with exact precursor identity/listing proof/candidate0
and four helper SHA arguments; run with the newly emitted identity SHA;
compare_selected.py with that identity SHA. Every output is exclusive.
