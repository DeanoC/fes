"""Seal one freshly qualified driver copy for a selected no-route snapshot."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODULE = ROOT / "sources/misteross"
DOMAIN = HERE.parent / "driver-domains-264"
BASELINE = DOMAIN / "baseline"
FOLDER = HERE / "selected-c0"
IDENTITY = HERE / "source-identity.json"
PRECURSOR_ID = DOMAIN / "source-identity.json"
PRECURSOR_ID_SHA = "c0ff5c870267dea40ce12d2d01b7c8d587504ad5897c911778122c387a7b98f5"
LISTING_PROOF = DOMAIN / "list-driver/comparison.json"
LISTING_PROOF_SHA = "2af219908f88cc0dc42d6fea29740868e9b9ab40f6379f855d1b54cbe441fa96"
BASELINE_PROOF_SHA = "e6cee54cf9227d81766b90ea337aef81ace71a5ea8266a77f3c5105788c7f377"
PRECURSOR_GENERATOR_SHA = "4b018c4b05200309629c5056c4c0c9497cca234f0bb4aa9b6f66e5cbceeee0ff"
COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"
BASE = "9dc3633aa0c5395df9a81be8437d1a746ba54b5d"
BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
PURE = HERE.parent / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
HELPERS = ("freeze.py", "run.py", "compare_selected.py", "proof-scope.md")


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(value, width=64):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{%d}" % width, value) is not None and len(set(value)) > 1


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate metadata key: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError("nonfinite metadata: " + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def bind(inputs, path, expected):
    path = str(Path(path).absolute())
    require(digest(expected), "unset/invalid artifact identity: " + path)
    if path in inputs:
        require(inputs[path] == expected, "conflicting artifact identity: " + path)
    else:
        require(sha(path) == expected, "original artifact path changed: " + path)
        inputs[path] = expected


def finish(inputs):
    for path, expected in inputs.items():
        require(sha(path) == expected, "original input path changed during operation: " + path)


def reference(inputs):
    """Authenticate the finalized flat proof; never execute its generator."""
    bind(inputs, LISTING_PROOF, LISTING_PROOF_SHA)
    proof = read(LISTING_PROOF)
    require(proof["phase"] == "driver-domains-list-driver" and proof["compiler_commit"] == COMMIT and
            proof["delta_base_commit"] == BASE and proof["source_identity_sha256"] == PRECURSOR_ID_SHA and
            proof["generator_sha256"] == PRECURSOR_GENERATOR_SHA and proof["frozen_native_parser_sha256"] == PURE_SHA and
            proof["timing_report_paths"] == 16384 and proof["legacy_report_path_count"] == 6 and
            proof["additional_reported_setup_path_count"] == 15284 and
            proof["legacy_report_path_count"] + proof["additional_reported_setup_path_count"] == 15290 and
            proof["qualified_driver_ordinals"] == list(range(16)) and all(proof[key] is True for key in (
                "candidate_completed", "typed_native_module_bits_consumers_bels_attrs_params_ports_exact",
                "cell_and_net_export_order_exact", "lossless_ordered_pll_occurrences_exact",
                "baseline_native_graph_matches_predecessor", "complete_predicted_report_exact",
                "same_new_binary_listing_rollback_proved", "current_predicted_timing_report_exact_after_listing_rollback",
                "final_original_path_metadata_and_runtime_hashes_stable")), "fresh qualified listing proof differs")
    require(len(proof["artifact_sha256"]) == 491 and len(proof["execution_file_sha256"]) == 281,
            "fresh flat proof closure shape differs")
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "cached artifact escapes ROOT")
        bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "cached runtime pathname is not absolute")
        bind(inputs, name, expected)
    require(inputs.get(str(PRECURSOR_ID)) == PRECURSOR_ID_SHA and
            inputs.get(str(BASELINE / "comparison.json")) == BASELINE_PROOF_SHA and
            inputs.get(str(PURE)) == PURE_SHA, "fresh listing omits its source/baseline/native parser")
    source, listing = read(PRECURSOR_ID), read(DOMAIN / "list-driver/run.json")
    baseline = read(BASELINE / "run.json")
    require(source["result_commit"] == COMMIT and source["delta_base_commit"] == BASE and
            source["binary_sha256"] == BINARY_SHA and source["source_archive_sha256"] == ARCHIVE_SHA and
            source["current_host_case_counts"] == {"driver_backend": 10, "timing_paths_backend": 7,
                                                  "driver_cli": 10, "timing_paths_cli": 4}, "frozen compiler identity differs")
    for path, expected in source["input_sha256"].items():
        require(inputs.get(path) == expected, "frozen source input is absent from the completed flat proof")
    for phase, run in (("baseline", baseline), ("list-driver", listing)):
        folder = DOMAIN / phase
        require(run["phase"] == phase and run["source_identity_sha256"] == PRECURSOR_ID_SHA and
                run["compiler_commit"] == COMMIT and run["completed"] is True and run["exit_code"] == 0 and
                run["compiler_read_audit_passed"] is True and "failure" not in run and
                set(run["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")},
                "cached actual source phase did not complete")
        require(all(inputs.get(path) == expected for path, expected in
                    {**run["input_sha256"], **run["output_sha256"], **run["execution"]["files"]}.items()),
                "cached phase metadata/runtime/output is outside its finalized proof")
    require(listing["driver_guide_sha256"] == proof["driver_guide_sha256"] == inputs[str(BASELINE / "timing.json")] and
            source["commands"]["list-driver"] == listing["command"] and
            source["commands"]["baseline"] == baseline["command"] and
            listing["diagnostic_environment"] == baseline["diagnostic_environment"] == source["diagnostic_environment"],
            "cached actual baseline guide/commands/environment differ")
    qualification = proof["fresh_driver_qualification"]
    require(qualification["bounded_reported_edges"] == 1 and qualification["no_candidate_applied"] is True and
            qualification["pretrial_rejections"] == [] and len(qualification["eligible_probed_edges"]) == 1,
            "fresh qualification is not the expected sole eligible edge")
    edge = qualification["eligible_probed_edges"][0]
    require(edge["original_q_users"] == 49 and edge["raw_truth_rows_reported"] == 8 and
            len(edge["trials"]) == 16 and [row["ordinal"] for row in edge["trials"]] == list(range(16)),
            "fresh edge population/qualification sequence differs")
    trial = edge["trials"][0]
    require(trial["edge"] == edge["edge"] and trial["ordinal"] == 0 and trial["bel"] == "MISTRAL_COMB.33.31.0" and
            trial["gain_ps"] == 1512 and all(trial[key] == 1 for key in ("improve", "endpoints", "clocks", "hold")) and
            edge["domains"] == {"endpoints": 334, "hold_pairs": 331, "timed_pairs": 331, "unrelated_pairs": 3,
                "reference_free": True, "numeric_before_after_pair_extrema_independently_proved": False,
                "unrelated_pairs_guarded_as_finite_transfer_bounds_with_no_setup_window": True},
            "selected ordinal0 does not match its fresh guarded trial and domain coverage")
    require(len(edge["edge"]) == 3 and all(type(value) is str for value in edge["edge"]) and
            edge["edge"][2] in {"A", "B", "C", "D0", "D1"}, "actual selected edge shape differs")
    src, sink, port = edge["edge"]
    clone = src + "$lut_driver_copy$" + sink + "$" + port
    return {"source": source, "listing_proof": proof, "listing_run": listing, "baseline_run": baseline,
            "edge": edge["edge"], "trial": trial, "domains": edge["domains"], "clone": clone,
            "private_net": clone + "$Q"}


def expected_command(ctx):
    command = list(ctx["listing_run"]["command"])
    require(command.count("--no-route") == 1 and command.count("--timing-report-paths") == 1 and
            command[command.index("--timing-report-paths") + 1] == "16384" and
            command.count("--remap-lut-driver-critical") == 1 and
            command[command.index("--remap-lut-driver-critical") + 1] == str(BASELINE / "timing.json") and
            command.count("--remap-lut-driver-candidate") == 1 and
            command[command.index("--remap-lut-driver-candidate") + 1] == "-1" and
            command[-2:] == ["--remap-lut-driver-candidate", "-1"], "source listing command/selectors differ")
    command[command.index("--remap-lut-driver-candidate") + 1] = "0"
    for option, output in (("--write", "placed.json"), ("--report", "timing.json")):
        require(command.count(option) == 1, "source output selector is ambiguous")
        command[command.index(option) + 1] = str(FOLDER / output)
    command[0] = str(HERE / "nextpnr-mistral")
    require(command.count("--router") == 1 and command[command.index("--router") + 1] == "gpu" and
            command.count("--gpu-device") == 1 and command[command.index("--gpu-device") + 1] == "1" and
            not any(flag in command for flag in ("--rbf", "--compress-rbf", "--no-place", "--no-pack")),
            "selected snapshot is not the unchanged inherited no-route profile")
    return command


def expected_runtime(ctx, profile):
    result = json.loads(json.dumps(ctx["listing_run"]["execution"]))
    require(result["files"].pop(ctx["listing_run"]["command"][0]) == BINARY_SHA, "cached runtime executable differs")
    result["files"][str(HERE / "nextpnr-mistral")] = profile["binary_sha256"]
    result["environment"]["PATH"] = str(HERE) + ":/usr/bin:/bin"
    return result


def record_template(profile, identity_sha, execution, ctx):
    return {"schema": 1, "phase": "selected-c0", "kind": "fresh qualified ordinary LUT copy selected no-route snapshot",
        "compiler_commit": profile["result_commit"], "delta_base_commit": BASE,
        "source_identity_sha256": identity_sha, "precursor_source_identity_sha256": PRECURSOR_ID_SHA,
        "source_archive_sha256": profile["source_archive_sha256"], "binary_sha256": profile["binary_sha256"],
        "listing_proof_sha256": LISTING_PROOF_SHA, "selected_candidate": 0, "selected_trial": ctx["trial"],
        "driver_guide_sha256": ctx["listing_run"]["driver_guide_sha256"], "timing_report_paths": 16384,
        "helper_sha256": profile["helper_sha256"], "command": expected_command(ctx),
        "diagnostic_environment": ctx["listing_run"]["diagnostic_environment"], "cwd": ctx["listing_run"]["cwd"],
        "execution": execution, "input_sha256": {**profile["input_sha256"], str(IDENTITY): identity_sha},
        "same_compiled_binary_as_fresh_listing": True, "driver_stage_is_last": True, "diagnostic_only": True,
        "routed_proof_or_timing_gain_claimed": False, "full_phase_available": False,
        "completed": False, "hardware_tested": False}


def authenticate_phase(run, profile, identity_sha, ctx):
    expected = record_template(profile, identity_sha, run["execution"], ctx)
    mutable = {"completed", "elapsed_seconds", "exit_code", "output_sha256", "compiler_read_audit_passed",
               "failure", "exit_code_is_adapter_sentinel"}
    require({key: value for key, value in run.items() if key not in mutable} ==
            {key: value for key, value in expected.items() if key not in mutable} and
            run["execution"] == expected_runtime(ctx, profile), "actual selected command/env/runtime/profile differs")
    require(type(run["completed"]) is bool and "failure" not in run and "exit_code_is_adapter_sentinel" not in run,
            "selected snapshot has failure/sentinel execution")
    if run["completed"]:
        require(type(run["exit_code"]) is int and run["exit_code"] == 0 and run["compiler_read_audit_passed"] is True and
                type(run["elapsed_seconds"]) in (int, float) and math.isfinite(run["elapsed_seconds"]) and
                run["elapsed_seconds"] >= 0 and set(run["output_sha256"]) ==
                {str(FOLDER / name) for name in ("phase.log", "placed.json", "timing.json")},
                "completed selected snapshot lacks audited normal exit/output closure")


def authenticate_freeze(identity_sha):
    inputs = {}
    bind(inputs, IDENTITY, identity_sha)
    profile = read(IDENTITY)
    require(profile["schema"] == 1 and profile["result_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            profile["precursor_source_identity_sha256"] == PRECURSOR_ID_SHA and
            profile["listing_proof_sha256"] == LISTING_PROOF_SHA and profile["selected_candidate"] == 0 and
            profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and
            profile["selected_no_route_only"] is True and profile["full_phase_available"] is False,
            "selected package identity differs")
    for path, expected in profile["input_sha256"].items():
        require(Path(path).is_absolute(), "selected frozen input is not an original absolute pathname")
        bind(inputs, path, expected)
    ctx = reference(inputs)
    require(profile["helper_sha256"] == {name: inputs.get(str(HERE / name)) for name in HELPERS} and
            profile["selected_trial"] == ctx["trial"] and profile["selected_edge"] == ctx["edge"] and
            profile["command"] == expected_command(ctx) and
            profile["diagnostic_environment"] == ctx["listing_run"]["diagnostic_environment"] and
            inputs.get(str(HERE / "nextpnr-mistral")) == BINARY_SHA and
            inputs.get(str(HERE / "source.tar.gz")) == ARCHIVE_SHA and
            profile["repositories"] == ctx["source"]["repositories"], "selected copied source/profile aliases differ")
    return profile, inputs, ctx


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    parser.add_argument("--listing-proof-sha256", required=True)
    parser.add_argument("--candidate", type=int, required=True)
    for name in HELPERS:
        parser.add_argument("--" + name.replace(".", "-").replace("_", "-") + "-sha256", required=True)
    args = parser.parse_args()
    require(args.source_identity_sha256 == PRECURSOR_ID_SHA and args.listing_proof_sha256 == LISTING_PROOF_SHA and
            args.candidate == 0, "explicit actual source/proof/candidate pins differ")
    require(not any((HERE / name).exists() for name in ("nextpnr-mistral", "source.tar.gz", "build-config.txt",
                                                      "source-identity.json", "selected-c0")), "selected freeze outputs already exist")
    inputs = {}
    ctx = reference(inputs)
    for name in HELPERS:
        bind(inputs, HERE / name, getattr(args, name.replace(".", "_").replace("-", "_") + "_sha256"))
    command = expected_command(ctx)
    finish(inputs)
    for name in ("nextpnr-mistral", "source.tar.gz", "build-config.txt"):
        origin, target = DOMAIN / name, HERE / name
        expected = inputs.get(str(origin))
        require(digest(expected), "fresh frozen source omitted its copied artifact: " + name)
        with target.open("xb") as output, origin.open("rb") as source:
            shutil.copyfileobj(source, output)
        target.chmod(0o555 if name == "nextpnr-mistral" else 0o444)
        bind(inputs, target, expected)
    profile = {"schema": 1, "result_commit": COMMIT, "delta_base_commit": BASE,
        "precursor_source_identity_sha256": PRECURSOR_ID_SHA, "listing_proof_sha256": LISTING_PROOF_SHA,
        "selected_candidate": 0, "selected_trial": ctx["trial"], "selected_edge": ctx["edge"],
        "binary_sha256": BINARY_SHA, "source_archive_sha256": ARCHIVE_SHA,
        "repositories": ctx["source"]["repositories"], "helper_sha256": {name: inputs[str(HERE / name)] for name in HELPERS},
        "command": command, "diagnostic_environment": ctx["listing_run"]["diagnostic_environment"],
        "same_compiled_binary_as_fresh_listing": True, "selected_no_route_only": True, "full_phase_available": False,
        "input_sha256": inputs, "hardware_tested": False}
    finish(inputs)
    with IDENTITY.open("x") as output:
        output.write(json.dumps(profile, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"source_identity_sha256": sha(IDENTITY), "candidate": 0, "selected_trial": ctx["trial"],
                      "binary_sha256": BINARY_SHA, "inputs": len(inputs)}, indent=2))


if __name__ == "__main__":
    main()
