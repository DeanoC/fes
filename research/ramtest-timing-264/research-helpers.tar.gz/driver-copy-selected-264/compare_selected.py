"""Actual selected one-edge LUT copy, with explicit pre-route proof limits."""
import argparse
from collections import Counter
import copy
import importlib.util
import json
import math
from pathlib import Path
import re

import freeze


def native_helper(inputs):
    freeze.bind(inputs, freeze.PURE, freeze.PURE_SHA)
    spec = importlib.util.spec_from_file_location("selected_driver_frozen_native_parser", freeze.PURE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def port_data(cells, name, port):
    freeze.require(name in cells, "path cell is absent: " + name)
    connections, directions = cells[name]["connections"], cells[name]["port_directions"]
    if port in connections:
        bits = connections[port]
        freeze.require(port in directions and type(bits) is list and len(bits) == 1,
                       "path terminal is not a scalar native port: " + name + "." + port)
        return bits, directions[port]
    match = re.fullmatch(r"(.+)\[(\d+)\]", port)
    freeze.require(match is not None and match[1] in connections and match[1] in directions,
                   "path terminal is absent from native ports: " + name + "." + port)
    bits, index = connections[match[1]], int(match[2])
    freeze.require(type(bits) is list and index < len(bits), "native vector path index is out of bounds")
    return [bits[index]], directions[match[1]]


def native_endpoint(top, value):
    freeze.require(type(value) is dict and set(value) == {"cell", "port", "loc"} and
                   type(value["cell"]) is str and type(value["port"]) is str and
                   type(value["loc"]) is list and len(value["loc"]) == 2 and
                   all(type(item) is int for item in value["loc"]), "path endpoint schema differs")
    terminal = value["cell"], value["port"]
    port_data(top["cells"], *terminal)
    bel = top["cells"][terminal[0]]["attributes"].get("NEXTPNR_BEL")
    match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.(\d+)", bel or "")
    freeze.require(match is not None and value["loc"] == [int(match[1]), int(match[2])],
                   "path endpoint BEL/coordinates are stale")
    return terminal


def clock_event(value, top):
    if value == "<async>":
        return None
    match = re.fullmatch(r"(posedge|negedge) (.+)", value or "")
    freeze.require(match is not None and match[2] in top["netnames"] and
                   len(top["netnames"][match[2]]["bits"]) == 1 and
                   type(top["netnames"][match[2]]["bits"][0]) is int,
                   "path event is not an actual scalar clock net")
    return match[1], match[2], top["netnames"][match[2]]["bits"]


def register_clock(cells, terminal):
    name, port = terminal
    cell = cells[name]
    if cell["type"] == "MISTRAL_FF":
        clock = "CLK"
    elif cell["type"] == "cyclonev_hps_interface_fpga2sdram":
        match = re.fullmatch(r"(cmd_data|cmd_valid|wrack_ready|cmd_ready|wrack_data|wrack_valid|wr_data|wr_valid|wr_ready|rd_ready|rd_data|rd_valid)_(\d+)(?:\[\d+\])?", port)
        freeze.require(match is not None, "HPS registered path port is unsupported")
        prefix = "cmd_port_clk" if match[1].startswith(("cmd_", "wrack_")) else "wr_clk" if match[1].startswith("wr_") else "rd_clk"
        clock = prefix + "_" + match[2]
    elif cell["type"].startswith("MISTRAL_MUL"):
        clock = "CLK"
    elif cell["type"] == "MISTRAL_MLAB":
        clock = "CLK1"
    else:
        freeze.require(False, "registered path clock audit lacks this actual primitive: " + cell["type"])
    bits, direction = port_data(cells, name, clock)
    freeze.require(direction == "input" and type(bits[0]) is int, "registered clock is not a native signal input")
    return bits


def native_tables(top):
    """Keep actual native bit identities and every serialized port bit slot."""
    drivers, users = {}, {}
    cells = top["cells"]
    for name, cell in cells.items():
        special = cells.pll_ports.get(name)
        directions = special["port_directions"] if special else list(cell["port_directions"].items())
        connections = special["connections"] if special else list(cell["connections"].items())
        freeze.require([port for port, _ in directions] == [port for port, _ in connections],
                       "native direction/connection entry order differs: " + name)
        occurrences = Counter()
        for (port, direction), (_, bits) in zip(directions, connections):
            occurrence = occurrences[port]
            occurrences[port] += 1
            freeze.require(direction in ("input", "output", "inout") and type(bits) is list and
                           all(type(bit) is int and bit >= 0 for bit in bits),
                           "native port has unsupported direction/bit representation")
            for index, bit in enumerate(bits):
                slot = name, port, index, occurrence
                if direction in ("output", "inout"):
                    drivers.setdefault(bit, []).append(slot)
                if direction in ("input", "inout"):
                    users.setdefault(bit, []).append(slot)
    return ({bit: sorted(rows) for bit, rows in drivers.items()},
            {bit: sorted(rows) for bit, rows in users.items()})


def conditional_table(source, clone):
    match = re.fullmatch(r"MISTRAL_ALUT([2-6])", source["type"])
    freeze.require(match is not None and clone["type"] == source["type"], "copy type is not an ordinary 2..6-input LUT")
    width = int(match[1])
    pins = list("ABCDEF"[:width])
    directions = {pin: "input" for pin in pins} | {"Q": "output"}
    freeze.require(source["port_directions"] == directions and clone["port_directions"] == directions and
                   set(source["connections"]) == set(directions) and set(clone["connections"]) == set(directions),
                   "source/copy logical port schema differs")
    freeze.require(set(source["parameters"]) == {"LUT"} and clone["parameters"] == source["parameters"],
                   "copied LUT parameters differ")
    table = source["parameters"]["LUT"]
    freeze.require(type(table) is str and len(table) == 1 << width and set(table) <= {"0", "1"},
                   "source truth table is not fully defined at its exact width")
    for pin in pins:
        freeze.require(source["connections"][pin] == clone["connections"][pin] and
                       len(source["connections"][pin]) <= 1,
                       "copy input connection/alias differs: " + pin)
    mask, copied = int(table, 2), int(clone["parameters"]["LUT"], 2)
    rows = [{"logical_row": row, "source": (mask >> row) & 1, "copy": (copied >> row) & 1}
            for row in range(1 << width)]
    freeze.require(all(row["source"] == row["copy"] for row in rows), "raw copied truth table differs")
    return {"width": width, "logical_input_order": pins, "source_mask": hex(mask), "copy_mask": hex(copied),
            "raw_truth_rows": rows, "raw_truth_row_count": len(rows),
            "conditional_raw_table_equivalence_proved": True,
            "actual_packed_input_polarities_and_constants_exported": False,
            "independent_actual_packed_boolean_equivalence_proved": False,
            "condition": "The raw table and logical input aliases are equal; actual packed input states must be identical. Pre-route JSON does not export those states."}


def prove_copy(native, before, after, ctx):
    require = freeze.require
    require(before["creator"] == after["creator"], "same-binary creator metadata changed")
    old, new = before["modules"]["top"], after["modules"]["top"]
    source, sink, port = ctx["edge"]
    clone, private = ctx["clone"], ctx["private_net"]
    trial = ctx["trial"]
    require(clone == source + "$lut_driver_copy$" + sink + "$" + port and private == clone + "$Q" and
            port in ("A", "B", "C", "D0", "D1") and trial["edge"] == ctx["edge"] and trial["ordinal"] == 0,
            "declared copy identity is not the authenticated selected data edge")
    require(set(new) == set(old) and
            native.canonical({key: value for key, value in new.items() if key not in ("cells", "netnames")}) ==
            native.canonical({key: value for key, value in old.items() if key not in ("cells", "netnames")}),
            "top metadata/public ports/settings changed")
    require(set(new["cells"]) == set(old["cells"]) | {clone} and clone not in old["cells"] and
            set(new["netnames"]) == set(old["netnames"]) | {private} and private not in old["netnames"],
            "actual selected graph adds/removes undeclared cell/net owners")
    require(list(new["cells"]) == list(old["cells"]) + [clone] and
            list(new["netnames"]) == list(old["netnames"]) + [private],
            "original native owner prefix/new private suffix differs")
    require(native.canonical(old["cells"].pll_ports) == native.canonical(new["cells"].pll_ports),
            "lossless ordered PLL output occurrences changed")
    require(source in old["cells"] and sink in old["cells"] and old["cells"][sink]["type"] == "MISTRAL_ALUT_ARITH",
            "selected source/sink types are absent or unsupported")
    a, b, copied = old["cells"][source], old["cells"][sink], new["cells"][clone]
    q, qdir = port_data(old["cells"], source, "Q")
    operand, odir = port_data(old["cells"], sink, port)
    newq, newqdir = port_data(new["cells"], clone, "Q")
    newoperand, newodir = port_data(new["cells"], sink, port)
    require(q == operand and qdir == newqdir == "output" and odir == newodir == "input" and
            newq == newoperand and type(q[0]) is int and type(newq[0]) is int and q != newq,
            "actual redirect is not precisely source.Q -> private copy.Q -> selected scalar operand")
    require(newq[0] not in {bit for net in old["netnames"].values() for bit in net["bits"]},
            "new private Q reuses an original named net identity")
    expected_sink = copy.deepcopy(b)
    expected_sink["connections"][port] = newq
    for name, cell in old["cells"].items():
        expected = expected_sink if name == sink else cell
        require(native.canonical(new["cells"][name]) == native.canonical(expected),
                "original native cell changed outside declared operand: " + name)
    for name, net in old["netnames"].items():
        require(native.canonical(new["netnames"][name]) == native.canonical(net),
                "original named net/alias/metadata/native bit changed: " + name)
    require(set(copied) == {"hide_name", "type", "parameters", "attributes", "port_directions", "connections"} and
            type(copied["hide_name"]) is int and copied["hide_name"] == int(clone.startswith("$")) and
            copied["attributes"] == {"NEXTPNR_BEL": trial["bel"], "BEL_STRENGTH": format(1, "032b")},
            "new clone has undeclared metadata or is not at its fresh selected weak BEL")
    require(new["netnames"][private] == {"hide_name": int(private.startswith("$")), "bits": newq,
                                        "attributes": {"ROUTING": " "}},
            "new output net is not the sole private unrouted Q alias")
    match = re.fullmatch(r"MISTRAL_(?:M?COMB)\.(\d+)\.(\d+)\.(\d+)", trial["bel"])
    require(match is not None, "selected clone BEL is not an ordinary COMB/MCOMB site")
    selected_alm = int(match[1]), int(match[2]), int(match[3]) // 6
    occupied = []
    for name, cell in old["cells"].items():
        bel = re.fullmatch(r"MISTRAL_(?:M?COMB|FF)\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
        if bel and (int(bel[1]), int(bel[2]), int(bel[3]) // 6) == selected_alm:
            occupied.append(name)
    require(not occupied, "fresh clone shares an original COMB/MCOMB/FF ALM")
    truth = conditional_table(a, copied)
    require(truth["raw_truth_row_count"] == ctx["listing_proof"]["fresh_driver_qualification"]["eligible_probed_edges"][0]["raw_truth_rows_reported"],
            "actual raw copy table width disagrees with fresh discovery")
    old_drivers, old_users = native_tables(old)
    new_drivers, new_users = native_tables(new)
    require(old_drivers.get(q[0]) == [(source, "Q", 0, 0)] and
            new_drivers.get(newq[0]) == [(clone, "Q", 0, 0)] and newq[0] not in old_drivers,
            "original/private Q has missing/competing actual native drivers")
    expected_drivers = copy.deepcopy(old_drivers)
    expected_drivers[newq[0]] = [(clone, "Q", 0, 0)]
    require(new_drivers == expected_drivers, "native output drivers changed outside private clone Q")
    expected_users = copy.deepcopy(old_users)
    chosen = sink, port, 0, 0
    require(expected_users[q[0]].count(chosen) == 1, "selected operand is not one original serialized user slot")
    expected_users[q[0]].remove(chosen)
    expected_users[newq[0]] = [chosen]
    additions = []
    for pin in truth["logical_input_order"]:
        bits = copied["connections"][pin]
        if bits:
            bit, slot = bits[0], (clone, pin, 0, 0)
            require(bit in old_drivers and len(old_drivers[bit]) == 1 and bit in old_users,
                    "copy input lacks its unchanged actual native source/user identity")
            expected_users.setdefault(bit, []).append(slot)
            additions.append({"logical_port": pin, "native_bit": bit, "native_driver": list(old_drivers[bit][0])})
    expected_users = {bit: sorted(rows) for bit, rows in expected_users.items()}
    require(new_users == expected_users, "actual native input users changed outside declared copy loads/operand redirect")
    require(len(old_users[q[0]]) == ctx["listing_proof"]["fresh_driver_qualification"]["eligible_probed_edges"][0]["original_q_users"] and
            len(new_users[q[0]]) == len(old_users[q[0]]) - 1 and len(new_users[newq[0]]) == 1,
            "original Q/private Q user counts disagree with fresh discovery and one-edge redirect")
    return {"complete_original_native_cells_except_one_operand_exact": True,
            "all_original_named_nets_bits_aliases_and_metadata_exact": True,
            "all_original_serialized_ff_buf_lut_bels_params_attrs_and_available_pins_exact": True,
            "original_cell_net_export_prefix_and_private_suffix_exact": True,
            "lossless_ordered_pll_occurrences_exact": True,
            "all_actual_native_drivers_and_input_consumer_slots_closed": True,
            "indexed_in_memory_user_slots_proved": False,
            "source": source, "sink": sink, "sink_port": port, "clone": clone, "private_net": private,
            "original_source_bel": a["attributes"]["NEXTPNR_BEL"],
            "original_sink_bel": b["attributes"]["NEXTPNR_BEL"], "selected_clone_bel": trial["bel"],
            "source_q_native_bit": q[0], "clone_q_native_bit": newq[0],
            "source_q_users_before": len(old_users[q[0]]), "source_q_users_after": len(new_users[q[0]]),
            "clone_q_users": [list(chosen)], "declared_copy_input_loads": additions,
            "distinct_loaded_native_input_nets": len({row["native_bit"] for row in additions}),
            "clone_alm_no_original_serialized_occupants": True, "clone_alm": list(selected_alm),
            "conditional_function": truth}


def report_topology(document, report, baseline):
    """Check current native paths; copy selection need not preserve old delays."""
    require = freeze.require
    top, cells = document["modules"]["top"], document["modules"]["top"]["cells"]
    require(type(report.get("critical_paths")) is list and report["critical_paths"] and
            type(report.get("timing_report_paths")) is int and
            report["timing_report_paths"] == baseline["timing_report_paths"], "current expanded report/path limit differs")
    require(set(report["fmax"]) == set(baseline["fmax"]) and
            all(type(row["achieved"]) in (int, float) and math.isfinite(row["achieved"]) and row["achieved"] > 0 and
                row["constraint"] == baseline["fmax"][name]["constraint"]
                for name, row in report["fmax"].items()), "current modeled Fmax/constraint set is invalid")
    def identities(paths):
        windows, endpoints = {}, set()
        for path in paths:
            pair = path["from"], path["to"]
            require(pair not in windows or windows[pair] == path["max_delay"], "one domain pair has inconsistent windows")
            windows[pair] = path["max_delay"]
            terminal = path["path"][-1]["to"]
            identity = (*pair, terminal["cell"], terminal["port"])
            require(identity not in endpoints, "report duplicates a domain-pair/native endpoint")
            endpoints.add(identity)
        return windows, endpoints
    old_windows, old_endpoints = identities(baseline["critical_paths"])
    windows, endpoints = identities(report["critical_paths"])
    require(windows == old_windows and endpoints == old_endpoints,
            "selected report changed actual registered endpoint/domain-pair/window coverage")
    counts, order = {}, {}
    for position, path in enumerate(report["critical_paths"]):
        require(type(path) is dict and set(path) == {"from", "to", "max_delay", "path"} and
                type(path["path"]) is list and path["path"], "current path schema is incomplete")
        pair = path["from"], path["to"]
        launch, capture = clock_event(pair[0], top), clock_event(pair[1], top)
        require(type(path["max_delay"]) in (int, float) and math.isfinite(path["max_delay"]) and path["max_delay"] > 0,
                "current actual window is nonfinite/nonpositive")
        endpoint = native_endpoint(top, path["path"][-1]["to"])
        counts[pair] = counts.get(pair, 0) + 1
        require(counts[pair] <= report["timing_report_paths"], "current pair exceeds its endpoint cap")
        previous, first, setup, prefixes, delays_ps = None, None, False, set(), []
        for segment in path["path"]:
            require(type(segment) is dict and {"type", "delay", "from", "to"} <= set(segment), "current segment schema differs")
            source, sink = native_endpoint(top, segment["from"]), native_endpoint(top, segment["to"])
            delay, kind = segment["delay"], segment["type"]
            require(type(delay) in (int, float) and math.isfinite(delay), "current path contains a nonfinite delay")
            delays_ps.append(round(delay * 1000))
            if kind in ("clk-skew", "clk-to-clk"):
                require(previous is None and first is None and not setup and kind not in prefixes and
                        launch is not None and capture is not None and
                        port_data(cells, *source)[0] == launch[2] and port_data(cells, *sink)[0] == capture[2],
                        "current clock prefix has stale native clock attribution")
                prefixes.add(kind)
                continue
            require(not setup and (previous is None or previous == source), "current native data path is disconnected")
            a, adir = port_data(cells, *source)
            b, bdir = port_data(cells, *sink)
            if kind in ("clk-to-q", "source"):
                require(first is None and previous is None and source == sink and adir == "output" and delay >= 0,
                        "current launch is not its actual native output")
                first = source
                require(register_clock(cells, source) == launch[2] if kind == "clk-to-q" and launch is not None
                        else kind == "source" and launch is None, "current launch event/clock is stale")
            elif kind == "routing":
                require(first is not None and adir == "output" and bdir == "input" and a == b and
                        type(a[0]) is int and delay >= 0 and segment.get("net") in top["netnames"] and
                        top["netnames"][segment["net"]]["bits"] == a and type(segment.get("sources")) is list,
                        "current routing segment is not an actual named native signal edge")
            elif kind == "logic":
                require(first is not None and source[0] == sink[0] and adir == "input" and bdir == "output" and delay >= 0,
                        "current logic is not an actual native input/output arc")
            elif kind == "setup":
                require(first is not None and source == sink == endpoint and bdir == "input" and capture is not None and
                        register_clock(cells, sink) == capture[2] and segment is path["path"][-1],
                        "current setup endpoint/registered clock is stale")
                setup = True
            else:
                require(False, "unsupported current setup segment: " + str(kind))
            previous = sink
        require(setup and first is not None and math.isfinite(sum(segment["delay"] for segment in path["path"])),
                "current actual registered path is incomplete/nonfinite")
        if position >= 6 and launch is not None and capture is not None and launch[2] == capture[2]:
            order.setdefault(pair, []).append((-sum(delays_ps), *endpoint))
    require(all(rows == sorted(rows) for rows in order.values()), "current same-clock extra path order differs")
    return {"current_report_all_native_paths_clocks_and_finite_segments_validated": True,
            "actual_registered_domain_pair_endpoint_set_and_windows_exact": True,
            "current_report_paths": len(report["critical_paths"]),
            "domain_pair_endpoint_counts": [{"from": pair[0], "to": pair[1], "count": count}
                                          for pair, count in sorted(counts.items())],
            "same_clock_extra_path_sum_and_name_order_checked": True,
            "async_cross_clock_order_and_unexported_phase_independently_recomputed": False,
            "old_path_delays_or_path_topology_inherited": False,
            "fmax": report["fmax"], "baseline_fmax": baseline["fmax"],
            "modeled_fmax_differences_mhz": {name: row["achieved"] - baseline["fmax"][name]["achieved"]
                                           for name, row in report["fmax"].items()}}


def selected_log(log, reference_log, baseline_log, native, ctx):
    current = [line for line in log.splitlines() if line.startswith("Info: LUT driver copy")]
    old = [line for line in reference_log.splitlines() if line.startswith("Info: LUT driver copy")]
    candidate = re.compile(r"^Info: LUT driver copy candidate 0: source=(.+) sink=(.+)\.(A|B|C|D0|D1) bel=(\S+) gain=(-?\d+)ps\.$")
    positions = [index for index, line in enumerate(old) if candidate.fullmatch(line)]
    freeze.require(len(positions) == 1, "cached current listing lacks exactly one fresh candidate0")
    match = candidate.fullmatch(old[positions[0]])
    freeze.require([match[1], match[2], match[3]] == ctx["edge"] and match[4] == ctx["trial"]["bel"] and
                   int(match[5]) == ctx["trial"]["gain_ps"] and ctx["trial"]["gain_ps"] >= 250 and
                   all(ctx["trial"][key] == 1 for key in ("improve", "endpoints", "clocks", "hold")),
                   "cached selected trial identity/guards differ")
    freeze.require(current == old[:positions[0] + 1] +
                   ["Info: LUT driver copy applied candidate 0; full routing and signoff still required."],
                   "actual current selected stage differs from its exact fresh qualified prefix/application")
    freeze.require(native.diagnostics(log) == native.diagnostics(baseline_log), "retained upstream qualification messages changed")
    metrics = native.PLACEMENT_METRICS.findall(baseline_log)
    freeze.require(len(metrics) == 71 and native.PLACEMENT_METRICS.findall(log) == metrics, "ordinary71 placement metrics changed")
    return {"actual_selected_candidate": 0, "fresh_selected_trial": ctx["trial"],
            "fresh_selected_domain_summary": ctx["domains"], "selected_qualified_log_prefix_exact": True,
            "retained_upstream_qualification_messages_and_71_metrics_exact": True,
            "reported_modeled_gain_ps": ctx["trial"]["gain_ps"],
            "per_pair_numeric_extrema_independently_proved": False,
            "modeled_qualification_inherited_without_actual_replay": False}


def comparison(identity_sha):
    profile, inputs, ctx = freeze.authenticate_freeze(identity_sha)
    native = native_helper(inputs)
    folder = freeze.FOLDER
    freeze.bind(inputs, folder / "run.json", freeze.sha(folder / "run.json"))
    run = freeze.read(folder / "run.json")
    freeze.authenticate_phase(run, profile, identity_sha, ctx)
    freeze.require(run["completed"] is True and run["exit_code"] == 0 and run["compiler_read_audit_passed"] is True and
                   type(run["elapsed_seconds"]) in (int, float) and math.isfinite(run["elapsed_seconds"]) and
                   run["elapsed_seconds"] >= 0, "actual selected no-route invocation did not complete normally")
    for path, expected in run["input_sha256"].items():
        freeze.bind(inputs, path, expected)
    for path, expected in run["execution"]["files"].items():
        freeze.bind(inputs, path, expected)
    freeze.require(set(run["output_sha256"]) == {str(folder / name) for name in ("phase.log", "placed.json", "timing.json")},
                   "actual selected output closure differs")
    for path, expected in run["output_sha256"].items():
        freeze.require(Path(path).stat().st_size > 0, "actual selected output is empty")
        freeze.bind(inputs, path, expected)
    freeze.require(not any((folder / name).exists() for name in ("core.rbf", "routed.json")), "no-route invocation has routed outputs")
    log = (folder / "phase.log").read_text()
    freeze.require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                   not any(text in log for text in ("Running the GPU router", "Running signoff timing analysis...")) and
                   log.count("Running predicted placed timing analysis for --report (no routing or analogue signoff).") == 1,
                   "selected invocation did not execute solely current predicted placed report semantics")
    old = native.read_netlist(freeze.BASELINE / "placed.json")
    new = native.read_netlist(folder / "placed.json")
    graph = prove_copy(native, old, new, ctx)
    report = freeze.read(folder / "timing.json")
    timing = report_topology(new, report, freeze.read(freeze.BASELINE / "timing.json"))
    rows = re.findall(r"^Info: Timing report includes (\d+) additional registered setup endpoint paths \(limit (\d+) per domain pair\)\.$", log, re.M)
    freeze.require(rows == [(str(len(report["critical_paths"]) - 6), str(report["timing_report_paths"]))],
                   "actual final report count/limit diagnostic differs")
    qualification = selected_log(log, (freeze.DOMAIN / "list-driver/phase.log").read_text(),
                                 (freeze.BASELINE / "phase.log").read_text(), native, ctx)
    freeze.finish(inputs)
    artifacts = {str(Path(path).relative_to(freeze.ROOT)): value for path, value in inputs.items()
                 if Path(path).is_relative_to(freeze.ROOT)}
    execution = {path: value for path, value in inputs.items() if not Path(path).is_relative_to(freeze.ROOT)}
    execution.update(run["execution"]["files"])
    return {"schema": 1, "phase": "driver-copy-selected-no-route", "compiler_commit": profile["result_commit"],
            "source_identity_sha256": identity_sha, "precursor_source_identity_sha256": profile["precursor_source_identity_sha256"],
            "listing_proof_sha256": profile["listing_proof_sha256"],
            "generator_sha256": profile["helper_sha256"]["compare_selected.py"],
            "frozen_native_parser_sha256": freeze.PURE_SHA, "candidate_completed": True,
            "elapsed_seconds": run["elapsed_seconds"], "selected_serialized_native_graph_proved": True,
            "graph_evidence": graph, "qualification_evidence": qualification, "current_report_evidence": timing,
            "partial_graph_evidence_available": True, "routed_graph_proof_available": False,
            "independent_actual_packed_boolean_equivalence_proved": False, "complete_physical_pin_preservation_proved": False,
            "in_memory_cache_indexed_store_owner_storage_or_gpu_identity_proved": False,
            "routed_gain_rbf_final_hold_or_hardware_acceptance_proved": False,
            "passes_practical_timing_gate": None, "candidate_accepted_under_confirmed_target_clock_rule": False,
            "old_comparators_generators_or_authenticators_replayed": False, "hardware_tested": False,
            "proof_limitations": [
                "This is an actual selected pre-route copy, not routing, RBF, analogue signoff, final hold or hardware acceptance.",
                "Original serialized native identities, available attributes/pins and consumers are exact outside the one declared scalar arithmetic operand and private copy/input loads; no BUF collapse or graph normalization is used.",
                "All raw LUT rows and logical input aliases are checked; actual packed input polarity/constant states and complete physical pin maps are unavailable in pre-route JSON, so actual physical Boolean equivalence remains conditional.",
                "Export order and serialized port-bit user slots do not prove indexed-store/free-list/bucket/pointer identity, carry caches, hidden LAB state or GPU IDs.",
                "All selected-report native paths/windows/constraints are current and checked; no old path or routed delay is imported. Async/cross-clock order and unexported phase/numeric STA remain current frozen-getter provenance.",
                "Current exact selected-trial flags and domain summaries are compiler-reported qualification. Numeric before/after pair extrema and the modeled gain are not independently recomputed physical signoff."],
            "artifact_sha256": dict(sorted(artifacts.items())), "execution_file_sha256": dict(sorted(execution.items())),
            "final_original_path_metadata_and_runtime_hashes_stable": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-identity-sha256", required=True)
    args = parser.parse_args()
    output = freeze.FOLDER / "comparison.json"
    freeze.require(not output.exists(), "selected comparison output already exists")
    result = comparison(args.source_identity_sha256)
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("phase", "compiler_commit", "selected_serialized_native_graph_proved",
                                                "routed_graph_proof_available")}, indent=2))


if __name__ == "__main__":
    main()
