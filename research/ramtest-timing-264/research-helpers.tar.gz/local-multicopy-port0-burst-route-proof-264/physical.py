"""Pure incremental physical proof using a separately pinned accepted core."""

CORE_SHA256 = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"


def require(value, message):
    if not value:
        raise ValueError(message)


def _ready(core, before, after, ready, profile):
    models = profile["prefix_fresh_local_models"]
    require(len(models) == 6 and ready["inner"] == models[5]["inner"] and ready["outer"] == models[5]["outer"], "sixth physical model differs")
    inner, outer = ready["inner"], ready["outer"]
    retained, clone = outer + "$local_remap", ready["new_clone"]
    require(clone == outer + "$local_remap$1" and clone not in before.cells and clone in after.cells and
            after.cells[clone]["attributes"]["NEXTPNR_BEL"] == models[5]["bel"], "additional owner/fresh site differs")
    frames = [(core._shape(view, inner), core._shape(view, outer), core._shape(view, retained)) for view in (before, after)]
    added = core._shape(after, clone)
    require(all((i["type"], o["type"], r["type"], i["tables"], o["tables"], r["tables"]) ==
                ("MISTRAL_ALUT2", "MISTRAL_ALUT3", "MISTRAL_ALUT4", [0xb], [0x32], [0x4440]) for i, o, r in frames) and
            added["type"] == "MISTRAL_ALUT4" and added["tables"] == [0x4440], "actual port0 LUT function differs")
    require(all(before.cells[name] == after.cells[name] and before.pins(name) == after.pins(name)
                for name in (inner, outer, retained)), "original port0 physical state changed")
    boundary = None
    for i, o, r in frames:
        token = i["outputs"]["Q"]
        require(sum(entry.get("driver") == token for entry in o["inputs"]) == 1, "outer does not consume exactly one actual inner Q")
        signals = (core._boundary(i) | core._boundary(o)) - {token}
        require(len(signals) == 4 and core._boundary(r) == signals and (boundary is None or signals == boundary), "actual native boundary differs")
        boundary = signals
    require(core._boundary(added) == boundary, "new copy effective native boundary differs")
    boundary, rows = sorted(boundary), []
    for assignment in range(16):
        values = {token: (assignment >> index) & 1 for index, token in enumerate(boundary)}
        outputs = []
        for i, o, r in frames:
            with_inner = {**values, i["outputs"]["Q"]: core._read_shape(i, values)}
            outputs.extend((core._read_shape(o, with_inner), core._read_shape(r, values)))
        outputs.append(core._read_shape(added, values))
        require(len(set(outputs)) == 1, "actual pin-state/inversion/constant composition differs")
        rows.append({"assignment": assignment, "original_before": outputs[0], "retained_before": outputs[1],
            "original_after": outputs[2], "retained_after": outputs[3], "additional_after": outputs[4]})
    old_root, new_root = frames[0][1]["outputs"]["Q"], frames[1][1]["outputs"]["Q"]
    old_copy, new_copy = frames[0][2]["outputs"]["Q"], frames[1][2]["outputs"]["Q"]
    output = added["outputs"]["Q"]
    require(old_root == new_root and old_copy == new_copy and len({old_root, old_copy, output}) == 3, "original output identities differ")
    declared = ready["declared_ena_redirects"]
    require(type(declared) is list and len(declared) == ready["declared_ena_redirect_count"] == models[5]["ena_users"] == 1 and
            declared[0]["occurrence"] == declared[0]["vector_index"] == 0 and declared[0]["port"] == "ENA", "single declared enable schema differs")
    chosen = (declared[0]["cell"], "ENA", 0)
    old_users = before.native.users.get(old_root, [])
    require(chosen == ("hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_6", "ENA", 0) and
            len(old_users) == 172 and chosen in old_users and after.native.users.get(output) == [chosen] and
            after.native.users.get(new_root) == [slot for slot in old_users if slot != chosen] and
            len(after.native.users[new_root]) == 171 and len(before.native.users.get(old_copy, [])) == 10 and
            before.native.users[old_copy] == after.native.users.get(new_copy), "root172-to171/retained10/new1 partition differs")
    retained_rows = ready["retained_copy_cohorts"]
    require(len(retained_rows) == 5 and len({row["cell"] for row in retained_rows}) == 5, "retained five-copy inventory differs")
    for row, model in zip(retained_rows, models[:5]):
        name = row["cell"]
        require(all(type(slot) is list and len(slot) == 4 and slot[1:] == ["ENA", 0, 0] for slot in row["consumer_slots"]), "retained scalar ENA slot schema differs")
        slots = [tuple(slot[:3]) for slot in row["consumer_slots"]]
        token = before.scalar(name, "Q", "output")
        require(before.cells[name] == after.cells[name] and before.pins(name) == after.pins(name) and
                before.cells[name]["attributes"]["NEXTPNR_BEL"] == model["bel"] and
                token == after.scalar(name, "Q", "output") and before.native.users.get(token) == after.native.users.get(token) == slots and
                len(slots) == model["ena_users"], "retained copy actual physical/user state differs")
        for ff, port, index in slots:
            require(port == "ENA" and index == 0 and before.cells[ff]["type"] == after.cells[ff]["type"] == "MISTRAL_FF" and
                    before.cells[ff]["connections"]["CLK"] == after.cells[ff]["connections"]["CLK"] == [3549], "retained common-clock cohort differs")
    for ff, port, index in old_users:
        require(port == "ENA" and index == 0 and before.cells[ff]["type"] == after.cells[ff]["type"] == "MISTRAL_FF" and
                before.cells[ff]["connections"]["CLK"] == after.cells[ff]["connections"]["CLK"] == [3549], "original common-clock cohort differs")
    ff = chosen[0]
    require(before.scalar(ff, "ENA", "input") == old_root and after.scalar(ff, "ENA", "input") == output and
            before.pins(ff) == after.pins(ff) and before.cells[ff]["attributes"]["NEXTPNR_BEL"] ==
            after.cells[ff]["attributes"]["NEXTPNR_BEL"] == "MISTRAL_FF.34.30.32", "actual FF6 enable/pins/BEL differs")
    return {"inner": inner, "outer": outer, "retained_copy": retained, "new_clone": clone,
        "retained_copies": [row["cell"] for row in retained_rows], "actual_external_native_boundary": [list(token) for token in boundary],
        "actual_truth_rows": rows, "assignments_checked": 16, "physical_pin_states_inversions_constants_and_aliases_evaluated": True,
        "declared_additional_ena_slots": [list(chosen)], "original_root_users_before": 172, "original_root_users_after": 171}, {ff: (old_root, output)}


def evaluate(core, before_doc, after_doc, logical_ledger, profile, driver_trial):
    """Caller authenticates core bytes and all inputs; no file/import/STA operations."""
    require(set(logical_ledger) == {"ready", "driver", "buffer_rows", "private_output_rows"}, "physical ledger contract differs")
    before, after = core.PhysicalView(before_doc["modules"]["top"]), core.PhysicalView(after_doc["modules"]["top"])
    require(before.device == after.device and before.labs == after.labs, "whole original LAB geometry/modes/selectors snapshot differs")
    ready, enables = _ready(core, before, after, logical_ledger["ready"], profile)
    driver = core._driver_proof(before, after, logical_ledger["driver"], driver_trial)
    private_names = [row["owner"] for row in logical_ledger["private_output_rows"]]
    require(len(private_names) == len(set(private_names)) == 4, "four private physical owner identities differ")
    private = []
    for name in private_names:
        a, b = core.evaluate_lut(before, name), core.evaluate_lut(after, name)
        require(a["lut"] == b["lut"], "original private owner physical bank/function/pins differs")
        private.append({"owner": name, "before": a, "after": b})
    names = {ready["inner"], ready["outer"], ready["retained_copy"], ready["new_clone"], *ready["retained_copies"],
        driver["source"], driver["clone"], driver["sink"], driver["successor"], *private_names}
    labs = {tuple(key) for key in profile["affected_whole_labs"]}
    for view in (before, after): labs.update(core._alm_key(view, name)[:2] for name in names if name in view.cells)
    require(all(key in before.labs and key in after.labs for key in labs), "declared physical LAB absent")
    original_ffs = sorted(name for name, cell in before.cells.items() if cell["type"] == "MISTRAL_FF" and core._alm_key(before, name)[:2] in labs)
    require(set(original_ffs) == {name for name, cell in after.cells.items() if cell["type"] == "MISTRAL_FF" and core._alm_key(after, name)[:2] in labs} and
            {row["cell"] for row in profile["all_original_ff_members_in_affected_labs"]} <= set(original_ffs), "whole-LAB original FF closure differs")
    ff_rows = [core._ff_pair(before, after, name, enables) for name in original_ffs]
    banks, alms = 0, []
    for lab in sorted(labs):
        for index in range(10):
            key = (*lab, index)
            a, b = core.evaluate_alm(before, key), core.evaluate_alm(after, key)
            old = {row["cell"]: row for row in a["occupied_banks"] if row["cell"] != driver["clone"]}
            new = {row["cell"]: row for row in b["occupied_banks"] if row["cell"] not in {driver["clone"], ready["new_clone"]}}
            require(old == new, "original occupied ALM bank/function/shared pins changed")
            banks += len(old)
            alms.append({"alm": list(key), "before": a, "after": b})
    buffers = core._buffer_proof(before, after, logical_ledger["buffer_rows"], enables)
    return {"schema": 1, "physical_scope_proved": True, "pinned_pure_core_sha256": CORE_SHA256,
        "actual_exported_physical_function_scope_proved": True, "additional_port0_copy": ready,
        "per_frame_lut_driver_copy_and_immediate_carry": driver, "private_output_owner_banks": private,
        "whole_labs_including_actual_old_and_new_driver_sites": [list(key) for key in sorted(labs)],
        "whole_lab_ff_control_rows": ff_rows, "whole_lab_alm_rows": alms, "unchanged_original_occupied_banks_checked": banks,
        "complete_lab_snapshot_exact": True, "explicit_existing_buffer_scope": buffers,
        "unexported_comb_cache_and_gpu_ids_proved": False, "physical_route_muxes_or_pips_independently_decoded": False,
        "cram_bytes_or_rbf_independently_decoded": False, "independent_numerical_sta_proved": False,
        "routed_gain_accepted": False, "hardware_tested": False}
