# Fresh ready1 routed composed-copy proof

This new inactive wrapper owns only compare_route_copy.py and comparison-scope.md. ROOT
alone executes Python/import/AST/helper/compiler/test/GPU/Git operations. Current
compiler cae5eb9a/ELFa2b5/archivec64e/host844162 and the generic physical
helper3a3d97b2/new ready1 scopeef9115e0 are fixed. Nine own route profile/run/
runner/scope and selected profile/run/proof/comparer/graph identities remain
UNFROZEN until ROOT supplies actual closed evidence. Every activation requires
explicit self/scope, full-run and physical-helper/scope hashes;
no guessed run, inherited successful graph or candidate default is permitted.

The future independent ready1 selected proof/profile/run is the own logical
before-image, never the ready0 selected or historical routed physical image. Its explicit chosen candidate,
one clone, whole two-FF same-clock ENA cohort, conditional composition, all ten guarded models,
71 metrics, 8221 fixed FFs and full native topology are bound at original paths.
Current full argv differs only by routing/RBF/output aliases. Its source, host,
dependency/object/archive/runtime/loaded-module/read-audit and input/output closure
must equal the frozen profile. Clean current source/model/submodule state and all
original path hashes are checked again before immutable publication. The final
raw route log, routed JSON, full report and nonempty local RBF are all bound.

Only lower pinned definitions are used:32fd lossless JSON/Audit/metrics;72131 raw
native tables/report topology with isolated8601; e6ce _paths; the own route
recorder's pure definitions/command/runtime/qualification chain; and the new
physical helper's five-argument evaluate using only approved60ca lower symbols.
No old main/auth/prepare/execute/evaluate/native proof or historical driver-copy
transform is replayed. Physical ledger keys are exactly ready, buffer_rows and
private_output_rows. There is no driver or post-plan selector/trial in this run.

The own ready1 guideea8e/originc95a, exact current path1/tied2975 and positive
selected guide-native bridge stay bound. All15 target-LAB FF records are
independently checked from the actual selected image; only the two proof-bound
ENA connections differ from its listing before-image. The earlier extra ready0
copy is not stacked. Its rejected route provides guide provenance alone.

Native reconstruction starts from complete own selected14908-cell/16646-alias data.
All original owner/port/nested ordering, lossless paired PLLs, interface, types,
tables, BELs and raw connection slots remain literal. Only actual newly created
MISTRAL_BUF owners are added, each paired with its sole private alias and one
original FF DATAIN slot. Their exact original inputs/native drivers and complete
output consumers are reconstructed. The actual buffer population is derived,
never borrowed from a previous full route. Whole raw driver/user tables are rebuilt
and compared without BUF collapse or numerical renaming.

Any changed original private raw Q must belong to the four known generated
comb/decomposition owners present in the own selected graph or the selected
composed-copy owner. Each frame requires its exact sole named alias, unique typed
Q driver, complete explicit occurrence partition, preserved table/BEL/metadata
and no public exposure. All old frame driver keys are removed before new ones
are inserted, including explicit BUF forwarding of any original consumer.
All unrelated aliases and raw slots are exact; earlier ten-copy Qs remain literal.
Changed original alias inventory must equal those explicit frames exactly.

Route metadata is narrow and recorded: module step place→route plus new
FES_LABSTATE_V1, cell FES_PINMAP_V1 additions and net ROUTING metadata. Every
original nonrouting metadata field/order is exact. Existing settings and their
order are exact. Newly cached routing/RBF defaults must match typed literal
ctx->setting<bool/int/float> calls in the hash-bound CURRENT gpurouter.cc,
router1.cc, analogue.cc or bitstream.cc. The two actual inherited local defaults
must immediately follow their exact typed base definitions and match that value.
Current context.h117–127 and property.cc35–61 bind std::to_string plus Property's
trailing-space escaping of strings consisting only of binary-state characters.
The wrapper records each used source path/hash/line/type/literal/value and rejects
unrecognized or conflicting defaults.
No previous routed graph/settings values supply these defaults.

The physical helper independently interprets fresh FES pins/LAB states against
the own selected intended graph: actual source pair/copy constants/inversions
and exhaustive truth, exact cohort ENA delivery, original root side users,
every fresh buffer and explicit private frame, shared ALM banks/carry neighbors
and whole affected FF CLK/ENA/reset/control selectors. Unexported pre-route
physical/cache identity is never invented. No broad pin-map or original-bank
waiver is authorized. Actual physical rejection stays visible separately from
the already bound conditional selected function.

Reported timing is computed BEFORE native/physical checks so failure does not
erase genuine numbers. Accepted FIVE6dc/run5ed3 supplies NUMERICAL reference
117.77175903320312MHz, pixel93.65049/capture259.49139 and exact constraints only.
Its driver/native/physical graph is not inherited. Own selected and full routed
reports each validate all15290 native paths/seven clock-pair endpoint/windows.
Complete finite signed path sums, all six non-target positive headrooms, capture
5ns/half-cycle3.845999956ns, actual LAST CLI Fmax/report agreement, HIP/device1,
RBF signoff order and LAST holds0 are required. Gain additionally requires strict
memory improvement above accepted FIVE and native+physical success. 130MHz closure
is disclosed separately. Full report/topology and final hash closure survive
structural rejection. No independent delay calibration, route mux/RBF decoding,
hardware deployment, unexported cache or device-legality claim is made.

Output is exclusive comparison-copy-route.json in this NEW ready1 proof directory. Genuine native/physical/topology
rejections and measured timing are retained; only every gate permits
routed_gain_accepted_under_confirmed_target_clock_rule.

