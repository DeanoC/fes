# Fresh late errors physical scope

Authoring this pair does not activate it. ROOT must review complete bytes, parse
them and receive an independent static review before the new wrapper calls it.
The wrapper binds core 60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41
and every current/previous native document and separately proved native ledger.
Only lower pure PhysicalView/function/bank/driver/carry/FF/buffer definitions are
reused; the old high-level evaluate, ready proof and authentication are unused.

The before frame is the closed old ten full route 1a6d4f7b, physically proved by
cd8ad7ff but rejected for timing. The after frame is a future closed fresh b3d
eleven-remap full route. Actual future hashes must be supplied; this file grants
no acceptance or inherited gain. The old mate C pin already uses A; all original
occupied bank rows and pin metadata remain exact, with no F0-to-A exception.
The new ALUT6 changes exactly the saved l6-mode bit from0 to1 in previously empty
whole combinational ALM33.14.0. Device, ordered geometry, all other LAB/mode/clock/
enable/reset fields stay exact. Actual before/after occupancy, full ALM images and
mode consistency are reconstructed independently; this is no broader LAB waiver.

The new errors ALUT6 is derived from the actual ALUT2/ALUT5 six-input cone,
checking all64 independent native assignments using physical pin states. Its
64-row active-low physical image and whole ALM are independently reconstructed.
Exactly eight fixed FF ENAs move from root32 to a private copy; the remaining24
root and all161 inner users stay exact. All ten earlier copies preserve physical
function, pins, BEL, output driver and exact cohorts. Actual original/new driver
locations, source copy truth, immediate arithmetic carry, complete affected LAB
FF controls, every occupied ALM bank and all5232 existing BUF/FF frames are
checked through bound pure definitions. Native proof supplies exact raw-slot and
alias restrictions separately; no global ID matching or buffer collapse occurs.

No source query, file read/write, import, compiler, build/test, route, numerical
STA, calibration, PIP/mux/CRAM/RBF decode or hardware operation occurs here.
All six other target-clock margins and LAST holds are a separate timing gate.
