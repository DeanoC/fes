"""Inspect the fresh late-errors full route using closed, flat provenance."""
import argparse
import builtins
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
ROUTE = RAW / "post-remap-plan-ddr0-errors-route-264"
PREFIX = RAW / "post-remap-plan-ddr0-errors-stage-264"
CONTROL = RAW / "post-remap-plan-ten-control-264"
COMPILER = RAW / "post-remap-plan-264"
BEFORE = RAW / "local-plan16-ready1-command-route-264/route-c0"
CONSTRUCTION = RAW / "local-plan16-ready1-command-route-proof-264/comparison-v2.json"
CONSTRUCTION_SHA = "cd8ad7ff8fd40b7136ff265d645806e3d661cde186b3da819975658040b8f74a"
CONSTRUCTION_RUN_SHA = "1a6d4f7b8efcc1e22c3af4c73b07a6fcfe609ce9ee07cc36c6d618a40c699428"
CONSTRUCTION_PROFILE_SHA = "ea03398546c1a1c8f9f099d0ed6ce4b156661d3276e0ec2057c7f09e563fe305"
OLD_BINARY_SHA = "41c2afe14701fcb6971a3bbfac74f77a66e158fb2d9e0b56390568bf3a71598f"
PARENT = RAW / "local-multicopy-ready1-address-route-264/route-c0"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
PARENT_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
COMMIT, BASE = "b3d036549c29a333e67c61bd1b23e705bce75d41", "d7e5c61fcfe96a2262af9dd98ea94bad7c6ba58f"
BINARY_SHA = "0c8805598c4e59ad77683956cdc1739b8d2ed183c73eab51c85c9b7a52ea18ad"
ARCHIVE_SHA = "338f71f67188fa29dbb9f6fa616f6d33f4bc926b3acd00bfb5122ef543a8c2fb"
HOST_SHA = "3751b2ebc0c0f802ac2b4251150a693764487939c0b08e42fe100c2047eb6fe0"
RUNNER_SHA = "4dce38194372a3f5cc982654feee7774ee71da43e88f503da3ebd9eedecc3dec"
RUNNER_SCOPE_SHA = "8fe8c713e8d60df8e821d5567bbc5f0b8e72a496a7e2d9b38d99f4d279b75408"
PROFILE_SHA = "bc197fba334d453b4ec5d2de596b7d4d5c878faccd62ae3f019ecb61899d7bbd"
PREFIX_SHA = "459f3880009f37cbab05d13332bea503c9c347c924b3880d7dbb8db012741636"
PREFIX_PROFILE_SHA = "0e74e43ec78af51766d1b681c0727222f24ff3bc7635efdbb47e7c9da948b063"
PREFIX_RUN_SHA = "48ae5d992e2c4c966c671c741a45126aeb068e059e8c5279d8eb28e8287ba560"
PREFIX_GENERATOR_SHA = "25c049cb377c69a2d739892509a07032c96f2781eeec6c47e2b9b9bff1bd9e77"
PREFIX_SCOPE_SHA = "00d66d06b6bfc166da37d50522a5297cf91322194c1ef22129095b08e00d5c31"
LATE_RUNNER_SHA = "3bf57664d00c97120bf900dac76d35136f5656f5ca5d2364fc386511b4f50008"
LATE_SCOPE_SHA = "6360afec6b94dee7e6e15635a926db14383069483c0a5b9b66d82292a41b2fbb"
CONTROL_PROFILE_SHA = "2294abbbadb2d74df4657344f841a2dcbaaf57854e33d7484a5e3e7841f9ab06"
CONTROL_RUN_SHA = "3eb274cc9d2d2a40ba348e35b0055b14f0d39edc035ac8c49b8dc7da13b27dee"
CONTROL_SHA = "323846d51ef9c76047ba243f55d7505395fcb793dab4b32dd963f56c72b0a746"
CONTROL_RUNNER_SHA = "90c284ac6af56d19b07fb807fac4809aca4924378f46259b42665cad81002ecd"
CONTROL_SCOPE_SHA = "316fae0e22ed5f1b65fb1a0d8854cd9f2f98f25965c28fa67e583220e6b27e52"
POST_SHA = "b3ad7db8d95fbc0f2704d2050b546ccf090bc4cb5ebafef66e3960c0d70f7bd5"
EARLY = RAW / "local-plan16-ready1-command-stage-264/local-plan.json"
EARLY_SHA = "00bf9b8c633ecc438ae9683162fe711424eeff5ba6e3ec95f67237676c17aa23"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE, FREEZE_SHA = SELECTED.parent / "freeze.py", "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
LOWER = RAW / "local-plan16-ready1-command-route-proof-264/native_scope_v2.py"
LOWER_SHA = "5cfca0a63ce2c42355f5c21942a8bdeb0911dc0734fe42c621979a1e6b470e67"
LOWER_SCOPE_SHA = "0badb260f5e4d035704c67daf7f87d40c7f7d373088de487125daab4d8506b94"
NATIVE_SHA = "a8214eb9e6f1ef0e63483f405a35d6ce1047f1e50e4ef3ea94ae9815a8f31957"
NATIVE_SCOPE_SHA = "518b497b21206086cb38aa433371324de096cd7727ecf1a2ec4d7fa7cf0dc0e0"
PHYSICAL_SHA = "6a22ee37c7a39a7a9b749c1a36db5dede7d95428d244012522ca65e2b6e89e2a"
PHYSICAL_SCOPE_SHA = "c0c56299aa814d3bc7c67484729810671191810577df60752c8706a2643182fe"
PHYSICAL_CORE = RAW / "local-multicopy-ready1-address-route-proof-264/physical.py"
PHYSICAL_CORE_SHA = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"
PHYSICAL_CORE_SCOPE_SHA = "976c13d6111f7bda5c7cfdc49df5089e23af4969b3294c12dee2a392dc46790a"
TIMING = LOWER.parent / "timing.py"
TIMING_SHA = "859052ff16ded7bf9611727ecac3dd6512c145cd55361bd04e79510d77598fe2"
TIMING_SCOPE_SHA = "5bbb3d7c92529da50b6607ec11040d7797120f03152be287a1f5a1fe8d9ccfe8"
TIMING_CORE = RAW / "driver-copy-ready-groups8-proof-264/timing.py"
TIMING_CORE_SHA = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
TIMING_CORE_SCOPE_SHA = "5088a952653ccd349edb109bd68e038cace200c911ec7707cef1d958897d8032"


def require(value, message):
    if not value: raise ValueError(message)


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module; exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def adopt(audit, manifest):
    for name, expected in manifest["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
        audit.bind(ROOT / name, expected)
    for name, expected in manifest["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "flat execution pathname is not absolute")
        audit.bind(Path(name), expected, execution=True)


def comparison(args):
    require(args.profile_sha256 == PROFILE_SHA and args.prefix_sha256 == PREFIX_SHA and args.native_sha256 == NATIVE_SHA and args.native_scope_sha256 == NATIVE_SCOPE_SHA and
        args.physical_sha256 == PHYSICAL_SHA and args.physical_scope_sha256 == PHYSICAL_SCOPE_SHA and not (HERE / "comparison.json").exists(),
        "actual positive late prefix/helper pins and exclusive output required")
    native = load(PURE, PURE_SHA, "late_errors_full_proof_lossless_parser")
    audit = native.Audit()
    pins = ((PURE, PURE_SHA), (Path(__file__).resolve(), args.self_sha256), (HERE / "scope.md", args.scope_sha256),
        (HERE / "native_scope.py", args.native_sha256), (HERE / "native-scope.md", args.native_scope_sha256),
        (HERE / "physical.py", args.physical_sha256), (HERE / "physical-scope.md", args.physical_scope_sha256),
        (ROUTE / "source-identity.json", args.profile_sha256), (ROUTE / "route-c0/run.json", args.run_sha256),
        (ROUTE / "run_route.py", RUNNER_SHA), (ROUTE / "scope.md", RUNNER_SCOPE_SHA),
        (PREFIX / "source-identity.json", PREFIX_PROFILE_SHA), (PREFIX / "baseline/run.json", PREFIX_RUN_SHA),
        (PREFIX / "baseline/comparison-prefix.json", args.prefix_sha256), (PREFIX / "compare_prefix.py", PREFIX_GENERATOR_SHA),
        (PREFIX / "prefix-scope.md", PREFIX_SCOPE_SHA), (PREFIX / "run_baseline.py", LATE_RUNNER_SHA), (PREFIX / "scope.md", LATE_SCOPE_SHA),
        (PREFIX / "post-plan.json", POST_SHA), (EARLY, EARLY_SHA), (CONTROL / "source-identity.json", CONTROL_PROFILE_SHA),
        (CONTROL / "baseline/run.json", CONTROL_RUN_SHA), (CONTROL / "baseline/comparison-control.json", CONTROL_SHA),
        (CONTROL / "run_baseline.py", CONTROL_RUNNER_SHA), (CONTROL / "scope.md", CONTROL_SCOPE_SHA),
        (COMPILER / "validation/host-validation.json", HOST_SHA), (COMPILER / "nextpnr-mistral", BINARY_SHA), (COMPILER / "source.tar.gz", ARCHIVE_SHA),
        (CONSTRUCTION, CONSTRUCTION_SHA), (BEFORE / "run.json", CONSTRUCTION_RUN_SHA),
        (BEFORE.parent / "source-identity.json", CONSTRUCTION_PROFILE_SHA), (ACCEPTED, ACCEPTED_SHA), (PARENT / "run.json", PARENT_RUN_SHA),
        (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (LOWER, LOWER_SHA), (LOWER.parent / "native-v2-scope.md", LOWER_SCOPE_SHA),
        (PHYSICAL_CORE, PHYSICAL_CORE_SHA), (PHYSICAL_CORE.parent / "physical-scope.md", PHYSICAL_CORE_SCOPE_SHA),
        (TIMING, TIMING_SHA), (TIMING.parent / "timing-scope.md", TIMING_SCOPE_SHA),
        (TIMING_CORE, TIMING_CORE_SHA), (TIMING_CORE.parent / "timing-scope.md", TIMING_CORE_SCOPE_SHA))
    for path, expected in pins: audit.bind(path, expected)
    profile, record = (native.read(path) for path in (ROUTE / "source-identity.json", ROUTE / "route-c0/run.json"))
    prefix, parent, construction, control_proof = (native.read(path) for path in
        (PREFIX / "baseline/comparison-prefix.json", ACCEPTED, CONSTRUCTION, CONTROL / "baseline/comparison-control.json"))
    for manifest in (prefix, parent, construction, control_proof): adopt(audit, manifest)
    require(prefix["phase"] == "post-remap-plan-ddr0-errors-ena-eleventh-stage-strict-native-prefix" and
        prefix["generator_sha256"] == PREFIX_GENERATOR_SHA and prefix["scope_sha256"] == PREFIX_SCOPE_SHA and
        prefix["runner_sha256"] == LATE_RUNNER_SHA and prefix["runner_scope_sha256"] == LATE_SCOPE_SHA and
        prefix["source_identity_sha256"] == PREFIX_PROFILE_SHA and prefix["current_baseline_run_sha256"] == PREFIX_RUN_SHA and
        prefix["compiler_commit"] == COMMIT and prefix["delta_base_commit"] == BASE and prefix["control_profile_sha256"] == CONTROL_PROFILE_SHA and
        prefix["control_run_sha256"] == CONTROL_RUN_SHA and prefix["control_proof_sha256"] == CONTROL_SHA and
        prefix["structural_rejection"] is prefix["native_path_topology_rejection"] is None and all(prefix[key] is True for key in
        ("candidate_completed", "native_graph_proof_available", "fresh_driver_guide_available_after_conditional_prefix_proof",
         "all_ten_retained_complete_trial_models_exact", "all_71_placement_metrics_exact", "final_original_path_metadata_and_runtime_hashes_stable")),
        "actual complete positive late-prefix prerequisite differs")
    require(parent["structural_rejection"] is None and parent["native_graph_proof_available"] is parent["physical_scope_proved"] is
        parent["routed_gain_accepted_under_confirmed_target_clock_rule"] is True and parent["current_full_run_sha256"] == PARENT_RUN_SHA and
        construction["structural_rejection"] is None and construction["native_graph_proof_available"] is construction["physical_scope_proved"] is True and
        construction["routed_gain_accepted_under_confirmed_target_clock_rule"] is False and construction["current_full_run_sha256"] == CONSTRUCTION_RUN_SHA and
        construction["source_identity_sha256"] == CONSTRUCTION_PROFILE_SHA and control_proof["source_identity_sha256"] == CONTROL_PROFILE_SHA and
        control_proof["current_baseline_run_sha256"] == CONTROL_RUN_SHA and control_proof["fresh_post_plan_control_prerequisite_proved"] is True,
        "current tenth structural construction, disabled control and accepted fifth timing roles differ")
    require(profile["phase"] == "post-remap-plan-ddr0-errors-late-fresh-driver-full-route" and profile["prefix_proof_sha256"] == PREFIX_SHA and
        profile["prefix_source_identity_sha256"] == PREFIX_PROFILE_SHA and profile["prefix_baseline_run_sha256"] == PREFIX_RUN_SHA and
        profile["prefix_generator_sha256"] == PREFIX_GENERATOR_SHA and profile["prefix_scope_sha256"] == PREFIX_SCOPE_SHA and
        profile["control_profile_sha256"] == CONTROL_PROFILE_SHA and profile["control_run_sha256"] == CONTROL_RUN_SHA and
        profile["control_proof_sha256"] == CONTROL_SHA and profile["experimental_current_full_proof_sha256"] == CONSTRUCTION_SHA and
        profile["experimental_current_full_run_sha256"] == CONSTRUCTION_RUN_SHA and profile["accepted_full_proof_sha256"] == ACCEPTED_SHA and
        profile["accepted_full_run_sha256"] == PARENT_RUN_SHA and profile["minimum_accepted_memory_mhz"] == 117.77175903320312 and
        profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and profile["binary_sha256"] == BINARY_SHA and
        profile["source_archive_sha256"] == ARCHIVE_SHA and profile["host_validation_sha256"] == HOST_SHA and
        profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA and
        profile["combined_requested_step_count"] == 11 and profile["original_ten_plan_path"] == str(EARLY) and
        profile["original_ten_plan_sha256"] == EARLY_SHA and profile["post_plan_path"] == str(PREFIX / "post-plan.json") and
        profile["post_plan_sha256"] == POST_SHA and len(profile["prefix_fresh_local_models"]) == 11 and
        native.canonical(profile["prefix_native_graph_evidence"]) == native.canonical(prefix["native_graph_evidence"]),
        "prepared late profile/compiler/source/proof roles differ")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    for key, value in profile.items():
        if key != "input_sha256": require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["source_identity_sha256"] == args.profile_sha256 and record["completed"] is True and record["exit_code"] == 0 and
        record["compiler_read_audit_passed"] is record["final_original_input_output_runtime_hashes_stable"] is True and
        not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
        record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): args.profile_sha256} and
        record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip" and
        record["all_eleven_complete_local_models_exact"] is record["actual_post_driver_gpu_signoff_order_bound"] is True,
        "actual completed current run/profile/runtime differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is outside frozen input closure")
        audit.bind(Path(name), expected, execution=True)
    require(set(record["output_sha256"]) == {str(ROUTE / "route-c0" / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")},
        "complete actual output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output empty"); audit.bind(Path(name), expected)
    runner = load(ROUTE / "run_route.py", RUNNER_SHA, "late_errors_full_proof_current_record_definitions")
    definitions = runner.definitions(); late, local_defs, driver_defs = definitions; control, _ = local_defs
    for path, expected in ((runner.DRIVER, runner.DRIVER_SHA), (PREFIX / "run_baseline.py", LATE_RUNNER_SHA),
        (CONTROL / "run_baseline.py", CONTROL_RUNNER_SHA), *control.PARSERS):
        require(audit.paths.get(path) == expected, "called pure parser is outside closure")
    for name, expected in control.SCRIPTS.items(): require(audit.paths.get(MODULE / "scripts" / name) == expected, "current project dependency outside closure")
    host = native.read(COMPILER / "validation/host-validation.json")
    for key in runner.HOST_MAPS:
        for name, expected in host[key].items():
            require(Path(name).is_absolute(), "host source/dependency pathname is not absolute")
            audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    require(host["compiler_commit"] == host["result_commit"] == COMMIT and host["delta_base_commit"] == BASE and
        host["binary_sha256"] == BINARY_SHA and host["source_archive_sha256"] == ARCHIVE_SHA and
        host["clean_committed_checkout"] is host["build_passed"] is True and
        {key: row["cases"] for key, row in host["checks"].items()} == {"native_plan": 25, "driver_backend": 10, "remap_plan_cli": 24, "driver_cli": 10} and
        all(row["passed"] is True and row["exit_code"] == 0 for row in host["checks"].values()), "current host/source/check roles differ")
    baseline, template = (native.read(path) for path in (PREFIX / "baseline/run.json", BEFORE / "run.json"))
    runtime = copy.deepcopy(template["execution"])
    require(runtime["files"].pop(template["command"][0]) == OLD_BINARY_SHA and str(runner.BINARY) not in runtime["files"] and
        runtime["environment"]["PATH"] == str(Path(template["command"][0]).parent) + ":/usr/bin:/bin", "old full compiler/PATH frame differs")
    runtime["files"][str(runner.BINARY)] = BINARY_SHA; runtime["files"] = dict(sorted(runtime["files"].items()))
    runtime["environment"]["PATH"] = str(runner.BINARY.parent) + ":/usr/bin:/bin"
    require(record["command"] == runner.command(baseline, template) and record["execution"] == baseline["execution"] == runtime and
        record["cwd"] == baseline["cwd"] == template["cwd"] == str(MODULE) and
        record["diagnostic_environment"] == baseline["diagnostic_environment"] == template["diagnostic_environment"],
        "actual full command/runtime differs beyond authorized compiler, PATH, late plan, guide and outputs")
    log = (ROUTE / "route-c0/route.log").read_text()
    early, post, trial = runner.qualification(log, definitions); models = early + post
    require(native.canonical(trial) == native.canonical(record["actual_fresh_driver_qualification"]) and
        native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) == native.canonical(profile["prefix_fresh_local_models"]) == native.canonical(prefix["fresh_local_models"]) and
        native.canonical(early) == native.canonical(record["actual_early_selected_local_qualification"]) == native.canonical(prefix["fresh_early_local_models"]) and
        native.canonical(post) == native.canonical(record["actual_post_selected_local_qualification"]) == native.canonical(prefix["fresh_post_local_models"]) and
        native.canonical(early) == native.canonical(template["actual_selected_local_qualification"]), "actual early10/post0/driver fresh qualification differs")
    metrics = native.PLACEMENT_METRICS.findall(log)
    placement_exact = len(metrics) == 71 and metrics == native.PLACEMENT_METRICS.findall((PREFIX / "baseline/phase.log").read_text())
    before, after, predicted = (native.read_netlist(path) for path in (BEFORE / "routed.json", ROUTE / "route-c0/routed.json", PREFIX / "baseline/placed.json"))
    report, parent_report, predicted_report = (native.read(path) for path in (ROUTE / "route-c0/timing.json", PARENT / "timing.json", PREFIX / "baseline/timing.json"))
    timing_core = load(TIMING_CORE, TIMING_CORE_SHA, "late_errors_full_proof_timing_lower_definitions")
    for path, expected in ((timing_core.BOARD, timing_core.BOARD_SHA), *timing_core.DEPS.values()):
        require(audit.paths.get(path) == expected, "timing module project dependency outside authenticated closure")
    timing = load(TIMING, TIMING_SHA, "late_errors_full_proof_current_accepted_fifth_timing")
    timing_result, timing_rejection = None, None
    try:
        timing_result = timing.evaluate(timing_core, after, report, parent_report, predicted_report, log, record)
        for name, expected in timing_result["evidence"]["pinned_pure_module_sha256"].items():
            require(audit.paths.get(Path(name)) == expected, "timing imported dependency is unauthenticated")
        require(native.canonical(timing_result["evidence"]["current_native_report_topology"]) == native.canonical(record["actual_current_native_report_topology"]),
            "independent complete current native report differs from the recorder")
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        timing_rejection = str(error)
    frozen = load(FREEZE, FREEZE_SHA, "late_errors_full_proof_freeze_lower_definitions")
    selected = load(SELECTED, SELECTED_SHA, "late_errors_full_proof_native_tables", frozen)
    lower = load(LOWER, LOWER_SHA, "late_errors_full_proof_native_lower_definitions")
    proof = load(HERE / "native_scope.py", args.native_sha256, "late_errors_full_proof_current_named_slot_proof")
    physical_core = load(PHYSICAL_CORE, PHYSICAL_CORE_SHA, "late_errors_full_proof_physical_lower_definitions")
    physical = load(HERE / "physical.py", args.physical_sha256, "late_errors_full_proof_current_physical_proof")
    graph, physical_evidence, rejection = None, None, None
    try:
        require(placement_exact, "current original71 placement metric sequence differs")
        graph = proof.prove(native, selected, lower, before, after, predicted, prefix["native_graph_evidence"], profile, trial)
        ledger = {key: graph[key] for key in ("ready", "driver", "buffer_rows", "private_output_rows")}
        physical_evidence = physical.evaluate(physical_core, before, after, ledger, profile, trial)
        require(physical_evidence["physical_scope_proved"] is True, "independent exported physical scope did not pass")
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        rejection = str(error)
    audit.finish()
    passed = rejection is None and timing_rejection is None and timing_result["passes_practical_timing_gate"]
    return {"schema": 1, "phase": "post-remap-plan-ddr0-errors-late-eleventh-stage-full-route-inspection", "compiler_commit": COMMIT,
        "delta_base_commit": BASE, "source_identity_sha256": args.profile_sha256, "current_full_run_sha256": args.run_sha256,
        "prefix_proof_sha256": args.prefix_sha256, "prefix_baseline_run_sha256": PREFIX_RUN_SHA,
        "control_profile_sha256": CONTROL_PROFILE_SHA, "control_run_sha256": CONTROL_RUN_SHA, "control_proof_sha256": CONTROL_SHA,
        "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": PARENT_RUN_SHA,
        "experimental_current_full_proof_sha256": CONSTRUCTION_SHA, "experimental_current_full_run_sha256": CONSTRUCTION_RUN_SHA,
        "generator_sha256": args.self_sha256, "scope_sha256": args.scope_sha256, "native_sha256": args.native_sha256,
        "native_scope_sha256": args.native_scope_sha256, "physical_sha256": args.physical_sha256,
        "physical_scope_sha256": args.physical_scope_sha256, "timing_sha256": TIMING_SHA, "timing_scope_sha256": TIMING_SCOPE_SHA,
        "candidate_completed": True, "structural_rejection": rejection, "timing_rejection": timing_rejection,
        "native_graph_proof_available": graph is not None, "physical_scope_proved": rejection is None,
        "native_graph_evidence": None if graph is None else graph["evidence"], "native_explicit_ledger": graph,
        "physical_evidence": physical_evidence, "timing": timing_result, "routed_gain_accepted_under_confirmed_target_clock_rule": passed,
        "all_71_placement_metrics_exact": placement_exact, "actual_fresh_driver_qualification": trial,
        "fresh_local_models": models, "fresh_early_local_models": early, "fresh_post_local_models": post,
        "artifact_sha256": dict(sorted(audit.artifacts.items())), "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True, "independent_numerical_sta_proved": False,
        "rbf_decoded_or_hardware_tested": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "native-sha256", "native-scope-sha256", "physical-sha256", "physical-scope-sha256",
        "prefix-sha256", "run-sha256", "profile-sha256"):
        parser.add_argument("--" + name, required=True)
    result = comparison(parser.parse_args())
    with (HERE / "comparison.json").open("x") as stream: stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection", "timing_rejection", "native_graph_proof_available",
        "physical_scope_proved", "routed_gain_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__": main()
