# Late-errors full-route inspection

ROOT alone executes this NEW wrapper after whole-file review, hash/AST checks
and independent peer review. Actual prepared full profilebc197fba and completed
full-run hashes are mandatory CLI arguments; no future result or selected driver
site is guessed.
The output comparison.json is exclusive. Current native/physical helper and scope
pins are exact CLI arguments as well; self/scope and the actual positive prefix
459f3880 must also be supplied. No old generator, authenticator, comparator main,
prepare, route, source query, build, test or Quartus operation is called.

The closed late baseline48ae5d99/profile0e74e43e contains the literal old ten-step
00bf9b8c early plan and sole b3ad7db8 post-plan, after placed reduction and
decomposition. Its positive strict native prefix459f3880 supplies the actual
11 complete trial records, eight errors ENAs and ALUT6 conditional composition.
Current disabled-post ten control2294abbb/run3eb274cc/proof323846d5 independently
proved exact whole native graph and complete predicted-report reproduction.
Their flat artifact/runtime closures are rehashed directly; no prior authority
or generator is replayed. The failed early errors attempt remains historical
rejected provenance in that flat closure and supplies no positive graph or timing.

Current compiler b3d03654/base d7e5c61f, ELF0c880559, archive338f71f6 and host3751b2eb
are bound separately from old measured compilers. The host records current
25 plan/10 driver native cases and24 plan/10 driver CLI cases, all passed. Six
absolute source/submodule/model/object-dependency/artifact maps, current runtime
files and the exact committed archive are retained through final rehash. Source
and runtime provenance are not converted into numerical or hardware acceptance.

The actual full command is independently derived from the current late baseline
and the old tenth full command. Its only authorized differences from old full
are current compiler ELF/controlled PATH, the one late post-plan, the current
late predicted driver guide and fresh write/report/RBF outputs. All other flags,
diagnostics, hardware/runtime files, GPU1 selection and invocation paths remain
exact. The record input set must equal profile inputs union its own profile path.
All four completed output files, actual read audit, HIP completion and stable
source/runtime/input/output hashes are authenticated before proof calls.

Fresh full-log qualification is parsed from the original complete log. Only the
local parser's input is sliced before the sole actual driver discovery header;
the full log stays bound and actual post→driver→GPU→LAST signoff order is checked.
The canonical early10/post1 model dictionaries must equal the actual positive
prefix, and early10 must equal the old tenth full records. The driver separately
qualifies candidate0 with its actual site, minimum250 ps, all compiled guards,
source49/eight rows and exact334 endpoints/331 timed/3 unrelated/331 hold/
reference-free1 domain summary. These are compiled guard evidence, not an
independent per-pair numerical extrema proof. All71 placement metrics stay exact.

The structural before image is old tenth full1a6d4f7b/cd8ad7ff, native and physical
positive but timing rejected116.809 MHz. The after image is the actually closed
new b3d full route, with its creator checked against its own late predicted image.
Only this old/new creator difference is disclosed; every top/native interface,
original record, raw slot, owner order and lossless paired PLL remains governed
by current nativea8214eb9. It independently proves one ALUT6/eight ENAs, all64
conditional native rows, root32→24, all161 inner consumers and ten retained copy
cohorts. It rebuilds explicit four private owner, driver and5232 named BUF frames
without global numeric alignment or buffer collapse. Historical mate pin-map
exceptions are not inherited. Original pins and every LAB field remain strict
apart from the one explicitly proved new ALUT6 l6-mode bit at ALM33.14.0.

Current physical6a22ee37 receives only ready/driver/buffer_rows/private_output_rows
and frozen60ca4442 lower definitions. It independently proves actual ALUT6 pin
states/native boundary64 rows, ten retained banks, both driver frames and immediate
carry, all original occupied banks/shared pins, dynamic old/new driver LABs and
complete original FF controller neighborhoods, plus all5232 explicit BUF banks.
It independently reconstructs the sole ordered LAB-state l6-mode0→1 transition
at the previously empty whole combinational ALM33.14.0, now occupied only by the
new copy; all other geometry/mode/clock/reset/enable fields remain exact.
The old high-level physical evaluate and ready proof are not called. Lower5cfca0
supplies only native scalar/lut/net_record/aliases and four owner constants.

Timing is computed before structural checks using unchanged CURRENT timing859052ff
with pinned e6ce77b7 lower load/path functions, never the old timing evaluator.
Its board module and both project imports must already belong to the authenticated
closure. The accepted fifth6dcf8c4b/run5ed3c077 is the distinct timing reference:
memory must strictly exceed117.77175903320312 MHz; pixel/capture constraints,
all15290 current native endpoints across seven exact window pairs, all six
non-target positive headrooms and LAST signoff hold0 must pass. The130 MHz target
is reported separately; lower positive margins and all-clock nonregression are
disclosed. Own late predicted report supplies coverage, never inherited delay.

Structural or timing rejection remains an explicit result with whatever completed
native/physical/timing diagnostics are available and the full final flat closure.
Gain requires current native and physical success plus the independent current
timing gate. Exported pin/bank truth does not prove unexported caches/GPU IDs,
independent numerical STA, route mux/pip/CRAM or RBF decoding, calibration or
hardware. No default recipe, physical pins or benchmark result is changed here.
