# Full late-errors native scope

This NEW module is pure: prove(native, selected, lower, before_doc, after_doc,
own_predicted_doc, prefix_evidence, profile, driver_trial). It reads no files,
loads no modules and invokes no authenticator, generator, compiler, source query,
comparison, old high-level prove/evaluate or main. ROOT alone executes the later
hash-bound wrapper after complete review. Lower5cfca0 supplies only scalar, lut,
net_record, aliases and the four original owner names. All new full graph and
truth checks are authored here, not inherited from the old tenth evaluator.

The structural before image is current10 full1a6d4f7b with native/physical-positive
cd8ad7ff; its116.809 MHz timing is rejected. The after image is a future actually
closed b3d late-errors full route and must have the creator of its own b3d predicted
image. Separate old d7/new b3d document creator strings are disclosed only. Apart
from the single new-ALUT6 mode transition specified below, every top module field,
ordered public interface, owner/port order and lossless paired PLL occurrence
remains strict. The accepted fifth6dc/117.771759 MHz gain reference
is separate. Caller binds the own independently positive late prefix25c049cb,
actual current profile/run and fresh full driver trial; no future hash is guessed.

The only added cell/net is errorsENA$local_remap and its private Q alias:
20140→20141 full cells/21878→21879 nets. Actual innerALUT2 mask0xd/Q4973 and
outerALUT5 mask0x7fff0000/Q4300 feed the new ALUT6 mask0x0ddddddddddddddd through
six distinct unchanged ordinary leaf drivers4242,15932,4969,4970,4971,4972.
All64 plain-SIG native assignments are enumerated independently. The selected
post model is combined index10/post-index0, candidate0/group1/fixed FFs, at least
250 ps with all compiled guards; its actual site is bound rather than assumed.
The whole LAB33.14 eight errors FF5/4/3/28/23/16/12/11 ENAs move from root4300 to
the actual full new Q, leaving24 of32 original users. Inner4973 retains all161
users, including160 status enables and the original outerE. Full native Q values
are derived independently and need not equal a predicted private output number.

All ten previous copy records, literal Q drivers, complete cohorts21/2/10/1/6/1/
1/3/2/8, all8221 original FF owners/BELs and every undeclared connection remain
exact. Every original FES_PINMAP remains exact, including the previously proved
mate C=A at MCOMB25.16.6. The historical F0→A allowance is not replayed. Only the
existing freshly requalified driver clone's actual BEL/FES_PINMAP can change;
its physical function and complete old/new LAB neighborhood require a separate
independent evaluator. The new ALUT6's own site/pin attributes do not waive any
original neighboring record. The sole exported FES_LABSTATE change is the new
ALUT6's l6-mode bit from0 to1 at bound whole ALM33.14.0. The native check requires
no old combinational occupant and exactly the new ALUT6 there, decodes both
snapshots with duplicate/nonfinite rejection and checks device, ordered geometry,
all62 fields per LAB and every other mode/control value exactly. No clock, carry,
enable or reset selector exception is allowed. This bounded native mode evidence
does not prove physical consistency; the separate evaluator independently checks
both whole ALM images and actual occupancy against the saved mode.

Exactly four original private output owners, the existing driver-copy owner and
all5232 existing named BUF owners get separate per-image driver/sole-private-alias/
complete-original-consumer frames. BUF A raw input and unique original FF DATAIN
identity stay exact; every BUF function/bank remains a physical proof obligation.
All old frame driver keys are removed together before any new key is inserted.
No global numeric translation, net or buffer collapse, alias matching by function,
or arbitrary pin/metadata exception is used. Complete raw driver/user tables and
all original cell/net records are rebuilt with only the named frames, eight ENAs
and six new input loads. Ordinary ROUTING net attributes alone are omitted from
semantic net equality; their actual bytes still belong in the wrapper closure.

The original source ALUT3 mask0x20 retains all48 consumers; the existing private
driver clone retains only the one original arithmetic operand. Both images'
actual masks/three input drivers/eight logical rows are checked separately, along
with exact immediate dedicated CO→CI successor and its sole user. Full exported
pin truth, shared occupied banks, whole original LAB FF controllers, cache state,
numerical STA, RBF/pip/CRAM interpretation and hardware are not proved here.

The result retains the four-key physical ledger ready/driver/buffer_rows/
private_output_rows plus driver_output_row and independent native evidence.
Fresh driver candidate0/minimum250 ps/all compiled guards and complete actual
endpoint/timed/unrelated/hold/reference-free summary are checked without guessing
the site or counts. The predeclared full FF groups are checked against the own
predicted image, then extended with both actual driver sites, source/operand/
immediate carry and the new ALUT6's actual LAB. Complete original before/after FF
records in this union are returned for the independent physical controller proof.
Ready data records both the bound prefix and actual full-derived Q, redirects,
cone records, leaf tokens and64 rows; it does not substitute predicted raw IDs.
Caller must authenticate actual inputs/runtime/output closure and compute full
timing against accepted fifth6dc before any structural rejection is reported.
