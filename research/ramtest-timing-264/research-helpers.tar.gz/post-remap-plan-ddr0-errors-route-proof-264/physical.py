"""Pure physical proof for the fresh late errors copy and requalified driver."""

CORE_SHA256 = "60ca4442887cba2c175d714c2f10e330331ea61220b2259bed6d2645c6026d41"


def require(value, message):
    if not value:
        raise ValueError(message)


def _new_lut6_mode(core, before, after, clone):
    require(before.device == after.device and list(before.labs) == list(after.labs), "original device/ordered LAB geometry differs")
    key = core._alm_key(after, clone)
    require(key == (33, 14, 0) and after.cells[clone]["type"] == "MISTRAL_ALUT6" and clone not in before.cells,
            "bound newly occupied errors LUT6 ALM differs")
    require(not [row for row in before.occupants.get(key, []) if row[1] != "FF"] and
            [row[0] for row in after.occupants.get(key, []) if row[1] != "FF"] == [clone],
            "new LUT6 does not own exactly the previously empty whole combinational ALM")
    offset = 2 + 6 * key[2]
    for lab, old in before.labs.items():
        new = after.labs[lab]
        if lab != key[:2]:
            require(old == new, "another LAB geometry/mode/control selector changed")
            continue
        require(old[:3] == new[:3] and old[3][offset] == 0 and new[3][offset] == 1 and
                old[3][:offset] == new[3][:offset] and old[3][offset + 1:] == new[3][offset + 1:],
                "new LUT6 changes more than its single l6 mode bit")
    old_alm, new_alm = core.evaluate_alm(before, key), core.evaluate_alm(after, key)
    require(old_alm["occupied_banks"] == [] and len(new_alm["occupied_banks"]) == 1 and
            new_alm["occupied_banks"][0]["cell"] == clone and old_alm["saved_fields"]["l6_mode"] == 0 and
            new_alm["saved_fields"]["l6_mode"] == 1 and
            {name: value for name, value in old_alm["saved_fields"].items() if name != "l6_mode"} ==
            {name: value for name, value in new_alm["saved_fields"].items() if name != "l6_mode"},
            "actual empty-to-LUT6 whole ALM mode or unrelated control fields differ")
    return {"alm": list(key), "lab_field_index": offset, "before_l6_mode": 0, "after_l6_mode": 1,
            "previous_comb_occupants": [], "new_comb_occupants": [clone], "all_other_lab_geometry_and_mode_control_fields_exact": True,
            "before_alm": old_alm, "after_alm": new_alm}


def _errors(core, before, after, ready, profile):
    models = profile["prefix_fresh_local_models"]
    require(len(models) == 11 and models[-1]["plan_kind"] == "post" and models[-1]["post_step_index"] == 0,
            "fresh eleven-model late plan identity differs")
    inner, outer, clone = (ready[key] for key in ("inner", "outer", "new_clone"))
    require(inner == models[-1]["inner"] and outer == models[-1]["outer"] and clone == outer + "$local_remap" and
            clone not in before.cells and clone in after.cells and after.cells[clone]["attributes"]["NEXTPNR_BEL"] == models[-1]["bel"],
            "fresh errors copy owner or selected site differs")
    frames = [(core._shape(view, inner), core._shape(view, outer)) for view in (before, after)]
    added = core._shape(after, clone)
    require(all((i["type"], o["type"], i["tables"], o["tables"]) ==
                ("MISTRAL_ALUT2", "MISTRAL_ALUT5", [0xd], [0x7fff0000]) for i, o in frames) and
            added["type"] == "MISTRAL_ALUT6" and added["tables"] == [0x0ddddddddddddddd],
            "actual errors original or composed function differs")
    require(all(before.cells[name] == after.cells[name] and before.pins(name) == after.pins(name) for name in (inner, outer)),
            "original errors cone metadata or physical pins changed")
    boundary = None
    for i, o in frames:
        token = i["outputs"]["Q"]
        require(sum(entry.get("driver") == token for entry in o["inputs"]) == 1, "outer does not consume exactly one inner Q")
        signals = (core._boundary(i) | core._boundary(o)) - {token}
        require(len(signals) == 6 and (boundary is None or signals == boundary), "original six-input physical boundary differs")
        boundary = signals
    require(core._boundary(added) == boundary and all("driver" in entry and entry["state"] == 0 for entry in added["inputs"]),
            "fresh composed actual native drivers or physical input states differ")
    boundary, rows = sorted(boundary), []
    for assignment in range(64):
        values = {token: (assignment >> index) & 1 for index, token in enumerate(boundary)}
        original = [core._read_shape(o, {**values, i["outputs"]["Q"]: core._read_shape(i, values)}) for i, o in frames]
        actual = core._read_shape(added, values)
        require(original[0] == original[1] == actual, "actual pin-state errors composition differs")
        rows.append({"assignment": assignment, "original_before": original[0], "original_after": original[1], "additional_after": actual})
    old_root, new_root = (o["outputs"]["Q"] for _, o in frames)
    old_inner, new_inner = (i["outputs"]["Q"] for i, _ in frames)
    output = added["outputs"]["Q"]
    require(old_root == new_root and old_inner == new_inner and output not in (old_root, old_inner), "original output driver identities differ")
    declared = ready["declared_ena_redirects"]
    require(type(declared) is list and len(declared) == ready["declared_ena_redirect_count"] == models[-1]["ena_users"] == 8 and
            all(row["occurrence"] == row["vector_index"] == 0 and row["port"] == "ENA" for row in declared), "eight errors ENA declarations differ")
    chosen = sorted((row["cell"], "ENA", 0) for row in declared)
    old_users = before.native.users.get(old_root, [])
    require(len(set(chosen)) == 8 and len(old_users) == 32 and all(slot in old_users for slot in chosen) and
            after.native.users.get(output) == chosen and after.native.users.get(new_root) == [slot for slot in old_users if slot not in chosen] and
            len(after.native.users[new_root]) == 24 and len(before.native.users.get(old_inner, [])) == 161 and
            before.native.users[old_inner] == after.native.users.get(new_inner), "root32-to24 or all161 inner users differ")
    enables = {}
    declared_bels = {row["cell"]: row["bel"] for row in declared}
    for ff, port, index in chosen:
        require(before.cells[ff]["type"] == after.cells[ff]["type"] == "MISTRAL_FF" and
                before.cells[ff]["connections"]["CLK"] == after.cells[ff]["connections"]["CLK"] == [3549] and
                before.scalar(ff, "ENA", "input") == old_root and after.scalar(ff, "ENA", "input") == output and
                before.pins(ff) == after.pins(ff) and before.cells[ff]["attributes"]["NEXTPNR_BEL"] ==
                after.cells[ff]["attributes"]["NEXTPNR_BEL"] == declared_bels[ff], "chosen fixed FF enable/pins/BEL/clock differs")
        enables[ff] = (old_root, output)
    retained = ready["retained_copy_cohorts"]
    require(len(retained) == len({row["cell"] for row in retained}) == 10 and
            [len(row["consumer_slots"]) for row in retained] == [21, 2, 10, 1, 6, 1, 1, 3, 2, 8], "ten retained physical cohorts differ")
    retained_banks = []
    for row, model in zip(retained, models[:10]):
        name = row["cell"]
        require(all(type(slot) is list and len(slot) == 4 and slot[1:] == ["ENA", 0, 0] for slot in row["consumer_slots"]), "retained scalar ENA schema differs")
        slots = [tuple(slot[:3]) for slot in row["consumer_slots"]]
        token = before.scalar(name, "Q", "output")
        require(before.cells[name] == after.cells[name] and before.pins(name) == after.pins(name) and
                before.cells[name]["attributes"]["NEXTPNR_BEL"] == model["bel"] and token == after.scalar(name, "Q", "output") and
                before.native.users.get(token) == after.native.users.get(token) == slots and len(slots) == model["ena_users"],
                "retained copy actual physical/user identity differs")
        a, b = core.evaluate_lut(before, name), core.evaluate_lut(after, name)
        require(a["lut"] == b["lut"], "retained copy physical function/bank differs")
        retained_banks.append({"cell": name, "before": a, "after": b})
    new_bank = core.evaluate_lut(after, clone)
    require(new_bank["lut"]["physical_bank"]["physical_rows_derived"] ==
            new_bank["lut"]["physical_bank"]["alias_consistent_rows_checked"] == 64, "fresh ALUT6 physical bank lacks all64 rows")
    return {"inner": inner, "outer": outer, "new_clone": clone, "retained_copies": [row["cell"] for row in retained],
        "actual_external_native_boundary": [list(token) for token in boundary], "actual_truth_rows": rows, "assignments_checked": 64,
        "original_root_users_before": 32, "original_root_users_after": 24, "original_inner_consumers_checked": 161,
        "declared_additional_ena_slots": [list(slot) for slot in chosen], "actual_additional_bank": new_bank,
        "retained_copy_banks": retained_banks, "physical_pin_states_inversions_constants_and_aliases_evaluated": True}, enables


def evaluate(core, before_doc, after_doc, logical_ledger, profile, driver_trial):
    """Caller binds immutable core/input bytes. No files, imports, timing or activation."""
    require(set(logical_ledger) == {"ready", "driver", "buffer_rows", "private_output_rows"}, "physical ledger contract differs")
    before, after = core.PhysicalView(before_doc["modules"]["top"]), core.PhysicalView(after_doc["modules"]["top"])
    mode = _new_lut6_mode(core, before, after, logical_ledger["ready"]["new_clone"])
    errors, enables = _errors(core, before, after, logical_ledger["ready"], profile)
    driver = core._driver_proof(before, after, logical_ledger["driver"], driver_trial)
    private_names = [row["owner"] for row in logical_ledger["private_output_rows"]]
    require(len(private_names) == len(set(private_names)), "private output owners duplicated")
    private = []
    for name in private_names:
        a, b = core.evaluate_lut(before, name), core.evaluate_lut(after, name)
        require(a["lut"] == b["lut"], "original private owner bank/function/pins changed")
        private.append({"owner": name, "before": a, "after": b})
    names = {errors["inner"], errors["outer"], errors["new_clone"], *errors["retained_copies"],
        driver["source"], driver["clone"], driver["sink"], driver["successor"], *private_names}
    labs = {tuple(key) for key in profile["affected_whole_labs"]}
    for view in (before, after):
        labs.update(core._alm_key(view, name)[:2] for name in names if name in view.cells)
    require(all(key in before.labs and key in after.labs for key in labs), "affected actual physical LAB absent")
    original_ffs = sorted(name for name, cell in before.cells.items() if cell["type"] == "MISTRAL_FF" and core._alm_key(before, name)[:2] in labs)
    require(set(original_ffs) == {name for name, cell in after.cells.items() if cell["type"] == "MISTRAL_FF" and core._alm_key(after, name)[:2] in labs} and
            {row["cell"] for row in profile["all_original_ff_members_in_affected_labs"]} <= set(original_ffs), "whole affected LAB FF closure differs")
    ff_rows = [core._ff_pair(before, after, name, enables) for name in original_ffs]
    banks, alms = 0, []
    for lab in sorted(labs):
        for index in range(10):
            key = (*lab, index)
            a, b = core.evaluate_alm(before, key), core.evaluate_alm(after, key)
            old = {row["cell"]: row for row in a["occupied_banks"] if row["cell"] != driver["clone"]}
            new = {row["cell"]: row for row in b["occupied_banks"] if row["cell"] not in {driver["clone"], errors["new_clone"]}}
            require(old == new, "original occupied ALM banks/functions/shared pins changed")
            banks += len(old)
            alms.append({"alm": list(key), "before": a, "after": b})
    buffers = core._buffer_proof(before, after, logical_ledger["buffer_rows"], enables)
    return {"schema": 1, "physical_scope_proved": True, "pinned_pure_core_sha256": CORE_SHA256,
        "actual_exported_physical_function_scope_proved": True, "additional_errors_copy": errors,
        "per_frame_lut_driver_copy_and_immediate_carry": driver, "private_output_owner_banks": private,
        "whole_labs_including_actual_old_and_new_driver_sites": [list(key) for key in sorted(labs)],
        "whole_lab_ff_control_rows": ff_rows, "whole_lab_alm_rows": alms, "original_occupied_banks_proved": banks,
        "single_new_lut6_mode_delta_independently_proved": mode,
        "complete_lab_snapshot_exact_except_single_new_lut6_mode": True, "explicit_existing_buffer_scope": buffers,
        "original_paired_mate_pin_metadata_exception_allowed": False, "unexported_comb_cache_and_gpu_ids_proved": False,
        "physical_route_muxes_or_pips_independently_decoded": False, "cram_bytes_or_rbf_independently_decoded": False,
        "independent_numerical_sta_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
