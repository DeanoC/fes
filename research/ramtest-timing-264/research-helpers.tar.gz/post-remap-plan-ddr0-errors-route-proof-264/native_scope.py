"""Pure full late-errors graph proof with explicit per-image private output frames."""
import copy
import json
import re

INNER = "ddr0_test.group_valid_MISTRAL_ALUT6_E_Q_MISTRAL_ALUT2_B"
OUTER = "ddr0_errors_MISTRAL_FF_Q_ENA_MISTRAL_ALUT5_Q"
CLONE, PINS = OUTER + "$local_remap", "ABCDEF"
LEAVES = [4242, 15932, 4969, 4970, 4971, 4972]
MASK = 0x0ddddddddddddddd
COUNTS = [21, 2, 10, 1, 6, 1, 1, 3, 2, 8]
TARGETS = {"ddr0_errors_MISTRAL_FF_Q_" + str(index) for index in (5, 4, 3, 28, 23, 16, 12, 11)}


def require(value, message):
    if not value:
        raise ValueError(message)


def _new_lut6_lab_mode(native, before, after):
    """Decode the sole authorized mode delta; every other LAB field stays exact."""
    snapshots = []
    for top in (before, after):
        encoded = top["attributes"].get("FES_LABSTATE_V1")
        require(type(encoded) is str and re.fullmatch(r"(?:[0-9a-fA-F]{2})+", encoded), "missing or malformed LAB snapshot hex")
        value = json.loads(bytes.fromhex(encoded).decode("utf-8"), object_pairs_hook=native.unique_object, parse_constant=native.nonfinite)
        require(type(value) is dict and set(value) == {"device", "labs"} and type(value["device"]) is str and
                type(value["labs"]) is list, "ordered LAB snapshot schema differs")
        keys = set()
        for row in value["labs"]:
            require(type(row) is list and len(row) == 4 and all(type(field) is int for field in row[:3]) and
                    row[0] >= 0 and row[1] >= 0 and row[2] in (0, 1) and type(row[3]) is list and len(row[3]) == 62,
                    "LAB geometry or 62-field snapshot differs")
            key = tuple(row[:2])
            require(key not in keys, "duplicate LAB snapshot row")
            keys.add(key)
            for index, field in enumerate(row[3]):
                maximum = 2 if index >= 2 and (index - 2) % 6 in (2, 3) else 1
                require(type(field) is int and 0 <= field <= maximum, "LAB mode/control field schema differs")
        snapshots.append(value)
    old, new = snapshots
    require(list(old) == list(new) and old["device"] == new["device"] and len(old["labs"]) == len(new["labs"]),
            "ordered original snapshot fields, device or LAB population differs")
    changed = []
    for left, right in zip(old["labs"], new["labs"]):
        require(left[:3] == right[:3], "ordered original LAB geometry differs")
        if left[:2] == [33, 14]:
            require(left[3][2] == 0 and right[3][2] == 1 and left[3][:2] == right[3][:2] and left[3][3:] == right[3][3:],
                    "new LUT6 changes more than its sole l6 mode bit")
            changed.append(left[:2])
        else:
            require(left == right, "another LAB mode/control field differs")
    require(changed == [[33, 14]], "sole newly occupied LUT6 LAB absent")

    def occupants(top):
        result = []
        for name, cell in top["cells"].items():
            match = re.fullmatch(r"MISTRAL_(M?COMB)\.(\d+)\.(\d+)\.(\d+)", cell["attributes"].get("NEXTPNR_BEL", ""))
            if match is not None:
                x, y, z = map(int, match.groups()[1:])
                require(0 <= z < 60 and z % 6 in (0, 1), "invalid original combinational ALM slot")
                if (x, y, z // 6) == (33, 14, 0): result.append(name)
        return result
    clone_bel = re.fullmatch(r"MISTRAL_(M?COMB)\.33\.14\.0", after["cells"][CLONE]["attributes"]["NEXTPNR_BEL"])
    require(clone_bel is not None and after["cells"][CLONE]["type"] == "MISTRAL_ALUT6" and
            occupants(before) == [] and occupants(after) == [CLONE], "new LUT6 does not solely occupy the previously empty whole comb ALM")
    return {"alm": [33, 14, 0], "lab_field_index": 2, "before_l6_mode": 0, "after_l6_mode": 1,
            "previous_comb_occupants": [], "new_comb_occupants": [CLONE], "ordered_lab_rows_checked": len(old["labs"]),
            "all_other_lab_geometry_and_mode_control_fields_exact": True, "physical_mode_consistency_independently_proved": False}


def prove(native, selected, lower, before_doc, after_doc, predicted_doc, prefix, profile, trial):
    """No reads/imports; lower supplies only scalar/lut/net_record/aliases/constants."""
    scalar, lut, net_record, aliases = lower.scalar, lower.lut, lower.net_record, lower.aliases
    require(set(before_doc) == set(after_doc) == set(predicted_doc) == {"creator", "modules"} and
            all(type(doc["creator"]) is str and set(doc["modules"]) == {"top"} for doc in (before_doc, after_doc, predicted_doc)) and
            after_doc["creator"] == predicted_doc["creator"], "current full creator does not match own same-compiler predicted document")
    a, b, predicted = (doc["modules"]["top"] for doc in (before_doc, after_doc, predicted_doc))
    model, alias = profile["prefix_fresh_local_models"][10], CLONE + "$Q"
    source, sink, port = profile["declared_driver_edge"]
    driver_clone = source + "$lut_driver_copy$" + sink + "$" + port
    successor = profile["driver_current_immediate_carry_successor"]["cell"]
    require(len(profile["prefix_fresh_local_models"]) == 11 and (model["inner"], model["outer"]) == (INNER, OUTER) and
            model["index"] == 10 and model["plan_kind"] == "post" and model["post_step_index"] == 0 and
            model["candidate"] == 0 and model["selected_groups"] == 1 and model["ena_users"] == 8 and model["primary_lab"] == [33, 14] and
            model["ff_shift"] == [0, 0] and model["gain_ps"] >= 250 and model["compiled_clock_hold_boundary_guards_passed"] is True and
            prefix["serialized_native_scope_proved"] is True and (prefix["inner"], prefix["outer"], prefix["new_clone"]) == (INNER, OUTER, CLONE) and
            prefix["assignments_checked"] == 64 and prefix["new_composed_mask_hex"] == "0x0ddddddddddddddd" and
            prefix["declared_ena_redirect_count"] == len(prefix["declared_ena_redirects"]) == 8,
            "bound positive late-prefix cone/model/function declarations differ")
    require(set(a) == set(b) == {"settings", "attributes", "ports", "cells", "netnames"} and list(a) == list(b) and
            all(native.canonical(a[key]) == native.canonical(b[key]) for key in ("settings", "ports")) and
            list(a["attributes"]) == list(b["attributes"]) and
            native.canonical({key: value for key, value in a["attributes"].items() if key != "FES_LABSTATE_V1"}) ==
            native.canonical({key: value for key, value in b["attributes"].items() if key != "FES_LABSTATE_V1"}) and
            list(a["ports"]) == list(b["ports"]) and
            (len(a["cells"]), len(b["cells"]), len(a["netnames"]), len(b["netnames"])) == (20140, 20141, 21878, 21879) and
            set(b["cells"]) == set(a["cells"]) | {CLONE} and set(b["netnames"]) == set(a["netnames"]) | {alias} and
            all(name not in a["cells"] and name not in a["netnames"] for name in (CLONE, alias)) and
            [name for name in b["cells"] if name != CLONE] == list(a["cells"]) and
            [name for name in b["netnames"] if name != alias] == list(a["netnames"]) and
            native.canonical(a["cells"].pll_ports) == native.canonical(b["cells"].pll_ports),
            "complete module/order/PLL/interface/one-copy population differs")
    require("FES_LABSTATE_V1" in a["attributes"] and all("FES_PINMAP_V1" in cell["attributes"]
            for top in (a, b) for cell in top["cells"].values()), "actual full physical snapshots missing")
    lab_mode = _new_lut6_lab_mode(native, a, b)
    od, ou = selected.native_tables(a)
    nd, nu = selected.native_tables(b)
    aa, ba, allowed, frames = aliases(a), aliases(b), {}, []

    def frame(owner, named_alias, kind):
        old, new = scalar(a["cells"][owner], "Q"), scalar(b["cells"][owner], "Q")
        users = ou.get(old)
        require(od.get(old) == nd.get(new) == [(owner, "Q", 0, 0)] and users and users == nu.get(new),
                "private owner driver/complete named consumers differ: " + owner)
        for top, bit, names in ((a, old, aa), (b, new, ba)):
            require(names.get(bit) == [named_alias] and top["netnames"][named_alias]["bits"] == [bit] and
                    all(bit not in row["bits"] for row in top["ports"].values()), "private alias/public boundary differs: " + owner)
        left, right = net_record(a["netnames"][named_alias]), net_record(b["netnames"][named_alias])
        left["bits"], right["bits"] = [], []
        require(native.canonical(left) == native.canonical(right), "private alias metadata differs: " + owner)
        for slot in [(owner, "Q", 0, 0)] + users:
            require(slot not in allowed and slot[3] == 0 and
                    a["cells"][slot[0]]["connections"][slot[1]][slot[2]] == old and
                    b["cells"][slot[0]]["connections"][slot[1]][slot[2]] == new,
                    "private frame named slot overlaps/differs")
            allowed[slot] = (old, new)
        row = {"owner": owner, "alias": named_alias, "old_raw_bit": old, "new_raw_bit": new,
            "named_consumer_slots": [list(slot) for slot in users], "kind": kind}
        frames.append(row)
        return row

    private = [frame(owner, owner + "$Q", "existing_private_output") for owner in lower.OWNERS]
    require(len(private) == 4, "original bounded private-owner population differs")
    driver = frame(driver_clone, driver_clone + "$Q", "existing_driver_copy_output")
    require(driver["named_consumer_slots"] == [[sink, port, 0, 0]], "driver copy output does not own exactly its original operand")
    buffers = {name for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_BUF"}
    require(len(buffers) == 5232 and buffers == {name for name, cell in b["cells"].items() if cell["type"] == "MISTRAL_BUF"},
            "existing named BUF population differs")
    buffer_rows = []
    for name in sorted(buffers):
        row = frame(name, name + "$conn$Q", "existing_late_buffer_output")
        require(len(row["named_consumer_slots"]) == 1, "BUF output lacks one original consumer")
        ff, ff_port, index, occurrence = row["named_consumer_slots"][0]
        require(ff_port == "DATAIN" and index == occurrence == 0 and a["cells"][ff]["type"] == b["cells"][ff]["type"] == "MISTRAL_FF" and
                a["cells"][name]["port_directions"] == b["cells"][name]["port_directions"] == {"A": "input", "Q": "output"} and
                set(a["cells"][name]["connections"]) == set(b["cells"][name]["connections"]) == {"A", "Q"} and
                scalar(a["cells"][name], "A") == scalar(b["cells"][name], "A"), "BUF input/unique original FF identity differs")
        bit = scalar(a["cells"][name], "A")
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit), "BUF input native driver differs")
        buffer_rows.append({**row, "buffer": name, "ff": ff, "input_raw_bit": bit, "input_native_driver": list(od[bit][0])})
    require(len({row["old_raw_bit"] for row in frames}) == len({row["new_raw_bit"] for row in frames}) == len(frames), "private frame outputs overlap")
    wi, mi, ai, qi = lut(a["cells"][INNER])
    wo, mo, ao, qo = lut(a["cells"][OUTER])
    wc, mc, ac, qc = lut(b["cells"][CLONE])
    require((wi, wo, wc, mi, mo, mc) == (2, 5, 6, 0xd, 0x7fff0000, MASK) and
            qi == 4973 and qo == 4300 and ai == LEAVES[:2] and ao == LEAVES[2:] + [qi] and
            ac == LEAVES and len(set(ac)) == 6 and len({qi, qo, qc}) == 3 and not ({qi, qo, qc} & set(ac)) and
            b["cells"][CLONE]["attributes"]["NEXTPNR_BEL"] == model["bel"] and nd.get(qc) == [(CLONE, "Q", 0, 0)] and
            b["netnames"][alias]["bits"] == [qc] and ba.get(qc) == [alias] and all(qc not in row["bits"] for row in b["ports"].values()),
            "actual full errors six-leaf LUT/private Q/qualified site differs")
    prototype = prefix["retained_copy_cohorts"][0]["cell"]
    left, right = copy.deepcopy(a["cells"][prototype]), copy.deepcopy(b["cells"][CLONE])
    for cell in (left, right):
        cell["attributes"].pop("NEXTPNR_BEL"); cell["attributes"].pop("FES_PINMAP_V1")
        for key in ("type", "parameters", "connections", "port_directions"): cell.pop(key)
    require(native.canonical(left) == native.canonical(right), "new ALUT6 nonfunctional metadata differs")
    left, right = net_record(a["netnames"][prototype + "$Q"]), net_record(b["netnames"][alias])
    left["bits"], right["bits"] = [], []
    require(native.canonical(left) == native.canonical(right), "new private alias metadata differs")
    retained_rows, retained_slots = prefix["retained_copy_cohorts"], set()
    require(len(retained_rows) == 10 and [len(row["consumer_slots"]) for row in retained_rows] == COUNTS, "ten retained copy cohort declarations differ")
    for row, earlier in zip(retained_rows, profile["prefix_fresh_local_models"][:10]):
        name, slots = row["cell"], sorted(tuple(slot) for slot in row["consumer_slots"])
        bit = scalar(a["cells"][name], "Q")
        require(native.canonical(a["cells"][name]) == native.canonical(b["cells"][name]) and bit == scalar(row["record"], "Q") and
                scalar(b["cells"][name], "Q") == bit and a["cells"][name]["attributes"]["NEXTPNR_BEL"] == earlier["bel"] and
                od.get(bit) == nd.get(bit) == [(name, "Q", 0, 0)] and ou.get(bit) == nu.get(bit) == slots and
                len(slots) == earlier["ena_users"] and not retained_slots & set(slots), "retained full copy/Q/complete cohort differs: " + name)
        retained_slots.update(slots)
    declared = prefix["declared_ena_redirects"]
    require(all(row["port"] == "ENA" and row["vector_index"] == row["occurrence"] == 0 and row["old_raw_bit"] == qo for row in declared), "declared eight scalar ENA slots differ")
    chosen = sorted((row["cell"], "ENA", 0, 0) for row in declared)
    require(len(set(chosen)) == len(chosen) == 8 and {slot[0] for slot in chosen} == TARGETS and
            chosen == sorted(slot for slot in ou.get(qo, []) if a["cells"][slot[0]]["attributes"]["NEXTPNR_BEL"].startswith("MISTRAL_FF.33.14.")) and
            len(ou.get(qo, [])) == 32 and len(nu.get(qo, [])) == 24 and nu.get(qc) == chosen and
            [slot for slot in ou[qo] if slot not in chosen] == nu[qo], "full errors root32-to24/new8 whole-LAB partition differs")
    actual_redirects = []
    for slot in chosen:
        name = slot[0]; row = next(row for row in declared if row["cell"] == name)
        require(slot not in allowed and slot not in retained_slots and a["cells"][name]["type"] == b["cells"][name]["type"] == "MISTRAL_FF" and
                scalar(a["cells"][name], "ENA") == qo and scalar(b["cells"][name], "ENA") == qc and
                scalar(a["cells"][name], "CLK") == scalar(b["cells"][name], "CLK") == 3549 and
                a["cells"][name]["attributes"]["NEXTPNR_BEL"] == b["cells"][name]["attributes"]["NEXTPNR_BEL"] == row["bel"],
                "actual declared FF enable/clock/BEL differs")
        allowed[slot] = (qo, qc)
        actual_redirects.append({**row, "new_raw_bit": qc})
    for slot in ou[qo] + list(retained_slots):
        require(slot[1:] == ("ENA", 0, 0) and a["cells"][slot[0]]["type"] == "MISTRAL_FF" and
                scalar(a["cells"][slot[0]], "CLK") == scalar(b["cells"][slot[0]], "CLK") == 3549, "common-clock original/retained enable union differs")
    status = [slot for slot in ou.get(qi, []) if slot != (OUTER, "E", 0, 0)]
    require(ou.get(qi) == nu.get(qi) and len(ou[qi]) == 161 and len(status) == 160 and (OUTER, "E", 0, 0) in ou[qi] and
            all(slot[1:] == ("ENA", 0, 0) and a["cells"][slot[0]]["type"] == "MISTRAL_FF" and scalar(a["cells"][slot[0]], "CLK") == 3549
                for slot in status), "inner original161 users/160 status enables differ")
    boundary, truth = [], []
    for pin, bit in zip(PINS, ac):
        require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit) and a["cells"][od[bit][0][0]]["type"] != "MISTRAL_CONST", "errors leaf driver differs")
        boundary.append({"port": pin, "raw_bit": bit, "native_driver": list(od[bit][0])})
    require(len({tuple(row["native_driver"]) for row in boundary}) == 6, "errors leaves do not have six distinct native drivers")
    for assignment in range(64):
        values = {bit: (assignment >> index) & 1 for index, bit in enumerate(ac)}
        iv = (mi >> sum(values[bit] << index for index, bit in enumerate(ai))) & 1
        original = (mo >> sum((iv if bit == qi else values[bit]) << index for index, bit in enumerate(ao))) & 1
        require(original == (mc >> assignment) & 1, "actual errors original/new64-row composition differs")
        truth.append({"assignment": assignment, "value": original})
    ws, ms, ins, qs = lut(a["cells"][source])
    require(type(trial["domain_summary"]) is list and len(trial["domain_summary"]) == 5 and
            all(type(value) is str and re.fullmatch(r"\d+", value) for value in trial["domain_summary"]), "fresh driver domain row schema differs")
    endpoints, timed, unrelated, holds, reference_free = map(int, trial["domain_summary"])
    require(ws == 3 and ms == 0x20 and len(set(ins)) == 3 and len(ou.get(qs, [])) == len(nu.get(qs, [])) == 48 and ou[qs] == nu[qs] and
            od.get(qs) == nd.get(qs) == [(source, "Q", 0, 0)] and (sink, port, 0, 0) not in ou[qs] and
            trial["source"] == source and trial["sink"] == sink and trial["port"] == port and trial["candidate"] == 0 and
            trial["compiler_model_guards_passed"] is True and trial["gain_ps"] >= 250 and trial["actual_trial_count"] > 0 and
            endpoints > 0 and timed + unrelated >= endpoints and holds <= timed + unrelated and reference_free == int(unrelated > 0) and
            b["cells"][driver_clone]["attributes"]["NEXTPNR_BEL"] == trial["bel"], "driver source48/private1/fresh qualified site differs")
    driver_truth = []
    for top in (a, b):
        wd, md, inputs, _ = lut(top["cells"][driver_clone])
        require((wd, md, inputs) == (ws, ms, ins) and top["cells"][sink]["type"] == top["cells"][successor]["type"] == "MISTRAL_ALUT_ARITH" and
                scalar(top["cells"][sink], "CO") == scalar(top["cells"][successor], "CI"), "driver copied truth/carry successor differs")
        driver_truth.append([{"assignment": index, "value": (md >> index) & 1} for index in range(8)])
    for bit in ins: require(len(od.get(bit, [])) == 1 and od[bit] == nd.get(bit), "driver input native owner differs")
    co = scalar(a["cells"][sink], "CO")
    require(ou.get(co) == nu.get(co) == [(successor, "CI", 0, 0)], "dedicated carry has another consumer")
    expected_drivers = dict(od)
    for row in frames: del expected_drivers[row["old_raw_bit"]]
    require(qc not in expected_drivers, "new errors Q overlaps a surviving ordinary driver")
    for row in frames:
        bit = row["new_raw_bit"]
        require(bit not in expected_drivers and bit != qc, "new private frame overlaps another driver")
        expected_drivers[bit] = [(row["owner"], "Q", 0, 0)]
    expected_drivers[qc] = [(CLONE, "Q", 0, 0)]
    require(nd == expected_drivers, "complete raw drivers differ beyond declared private frames/new errors Q")
    expected_users = {}
    for bit, slots in ou.items():
        for slot in slots: expected_users.setdefault(allowed[slot][1] if slot in allowed else bit, []).append(slot)
    for pin, bit in zip(PINS, ac): expected_users.setdefault(bit, []).append((CLONE, pin, 0, 0))
    require(nu == {bit: sorted(slots) for bit, slots in expected_users.items()}, "complete raw users differ beyond named frames/eightENAs/sixloads")
    for name, old in a["cells"].items():
        expected = copy.deepcopy(old)
        for port_name, bits in expected["connections"].items():
            for index, bit in enumerate(bits):
                slot = (name, port_name, index, 0)
                if slot in allowed:
                    require(allowed[slot][0] == bit, "declared original slot value differs")
                    bits[index] = allowed[slot][1]
        if name == driver_clone:
            for field in ("NEXTPNR_BEL", "FES_PINMAP_V1"):
                require(field in expected["attributes"] and field in b["cells"][name]["attributes"], "actual driver site/pin field missing")
                expected["attributes"][field] = b["cells"][name]["attributes"][field]
        require(native.canonical(expected) == native.canonical(b["cells"][name]) and list(old["connections"]) == list(b["cells"][name]["connections"]) and
                list(old["port_directions"]) == list(b["cells"][name]["port_directions"]), "original metadata/BEL/pinmap/order/undeclared slot differs: " + name)
    private_nets = {row["alias"]: row for row in frames}
    for name, old in a["netnames"].items():
        expected = net_record(old)
        if name in private_nets: expected["bits"] = [private_nets[name]["new_raw_bit"]]
        require(native.canonical(expected) == native.canonical(net_record(b["netnames"][name])), "original alias/rawbits/metadata differs: " + name)
    ff_bels = {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in a["cells"].items() if cell["type"] == "MISTRAL_FF"}
    require(len(ff_bels) == 8221 and ff_bels == profile["all_original_ff_bel_manifest"] and
            ff_bels == {name: cell["attributes"]["NEXTPNR_BEL"] for name, cell in predicted["cells"].items() if cell["type"] == "MISTRAL_FF"},
            "all8221 original FF owner/BEL declarations differ")
    def lab(cell):
        match = re.fullmatch(r"MISTRAL_[A-Z0-9_]+\.(\d+)\.(\d+)\.(\d+)", cell["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "affected native occupant lacks actual placed BEL")
        return tuple(map(int, match.groups()[:2]))
    declared_labs = {tuple(row) for row in profile["affected_whole_labs"]}
    require(len(declared_labs) == len(profile["affected_whole_labs"]) and
            all(len(row) == 2 and all(type(value) is int and value >= 0 for value in row) for row in declared_labs), "declared whole-LAB scope differs")
    declared_rows = profile["all_original_ff_members_in_affected_labs"]
    require(len({row["cell"] for row in declared_rows}) == len(declared_rows) and
            {row["cell"] for row in declared_rows} == {name for name in ff_bels if lab(predicted["cells"][name]) in declared_labs} and
            all(native.canonical(row["record"]) == native.canonical(predicted["cells"][row["cell"]]) for row in declared_rows),
            "predeclared complete original FF neighborhoods differ from own predicted image")
    all_labs = declared_labs | {lab(top["cells"][name]) for top in (a, b) for name in (source, driver_clone, sink, successor)} | {lab(b["cells"][CLONE])}
    whole_ff_rows = [{"cell": name, "before_record": a["cells"][name], "after_record": b["cells"][name]}
        for name in sorted(ff_bels) if lab(a["cells"][name]) in all_labs]
    ready = {**copy.deepcopy(prefix), "declared_ena_redirects": actual_redirects, "predicted_clone_q": prefix["actual_clone_q"], "actual_clone_q": qc,
        "actual_new_clone_record": b["cells"][CLONE], "actual_full_clone_q": qc,
        "actual_full_new_clone_record": b["cells"][CLONE], "actual_full_original_cone_records": {name: a["cells"][name] for name in (INNER, OUTER)},
        "actual_full_conditional_boundary": boundary, "actual_full_conditional_truth_rows": truth}
    return {"ready": ready, "driver": {"source": source, "clone": driver_clone, "sink": sink, "port": port, "successor": successor},
        "buffer_rows": buffer_rows, "private_output_rows": private, "driver_output_row": driver,
        "affected_whole_labs": sorted(map(list, all_labs)), "actual_original_ff_rows_in_affected_labs": whole_ff_rows,
        "evidence": {"serialized_native_scope_proved": True, "original_cells": len(a["cells"]), "new_cells": len(b["cells"]),
            "buffer_count": len(buffer_rows), "private_output_owner_count": len(private), "complete_driver_and_user_tables_proved": True,
            "all_ten_retained_copy_records_and_consumer_slots_exact": True, "declared_ena_redirect_count": 8,
            "original_root_users_before": 32, "original_root_users_after": 24, "original_inner_all161_consumers_exact": True,
            "actual_errors_q": qc, "actual_errors_conditional_boundary": boundary, "actual_errors_conditional_rows": truth,
            "assignments_checked": 64, "all_original_metadata_exact_except_named_frames_and_requalified_driver_site": True,
            "whole_module_lab_snapshot_exact": False, "single_new_lut6_mode_delta": lab_mode,
            "whole_module_lab_snapshot_exact_except_single_new_lut6_mode": True, "all8221_original_ff_bels_exact": True,
            "whole_original_ff_neighborhood_count": len(whole_ff_rows), "actual_driver_domain_summary": trial["domain_summary"],
            "driver_source_retained_users": 48, "driver_copy_users": 1, "driver_conditional_rows_per_frame": driver_truth,
            "driver_site_before": a["cells"][driver_clone]["attributes"]["NEXTPNR_BEL"], "driver_site_after": b["cells"][driver_clone]["attributes"]["NEXTPNR_BEL"],
            "before_creator": before_doc["creator"], "after_creator": after_doc["creator"], "own_predicted_creator": predicted_doc["creator"],
            "document_creator_difference_disclosed_only": before_doc["creator"] != after_doc["creator"], "current_creator_matches_own_predicted": True,
            "conditional_plain_sig_assumptions": True, "global_numeric_alignment_or_buffer_collapse_used": False,
            "physical_pin_truth_or_sta_inherited": False}}
