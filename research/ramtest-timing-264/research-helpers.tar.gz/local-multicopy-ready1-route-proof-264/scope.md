# Additive ready1 full-route inspection

This new wrapper and pure `native_scope.py` inspect only the actual completed
81243 multicopy route from profile 83ddcc2b against accepted a4a91235/71b2575f.
Activation requires the closed current run hash and exact hashes of this wrapper,
this scope, the native helper and Ready's new physical helper/scope. Existing
helpers, raw outputs, source archives and binaries remain unchanged. The flat
profile, current prefix 10016a0f, accepted proof and their artifact/runtime maps
are rehashed before use and again before publishing an exclusive new comparison.
Historical external runtime files are retained provenance; actual current
execution must exactly equal the current profile/current baseline runtime.

Only byte-pinned pure definitions are loaded: lossless 32fd netlist/Audit parser,
72131 native tables/topology with its module-local 8601 `freeze` binding, the
current 3e811 recorder's command/qualification definitions, the current 440013
local-log parser, and e6ce77 reported-timing evaluator and its exact project
dependencies. No previous authentication, prepare, runner, comparator, generator,
test or build entrypoint is called. The command is independently checked by the
current recorder's two command constructions; current compiler, archive, options,
inputs, BUILD_ID, GPU device, four local descriptors and actual runtime are bound.

The native comparison has one added ALUT4/private net and one named FF.ENA
redirect. It retains the first ready1 copy and its two consumers, all original
cell masks, parameters, attributes, BELs, full serialized pins, port order,
public ports, settings, full LAB snapshot, paired ordered PLL occurrences and
all nonprivate numeric bit identities. Creator strings are reported across the
two authenticated compiler versions; the current full creator must match the
current predicted creator. Net ROUTING attributes are the only routing metadata
excluded from native graph equality; no input graph is mutated.

Every one of the 5232 existing named late buffers has a separate Q/sole private
alias/unique same FF.DATAIN ledger. Its actual A raw bit/native driver remains
exact. Four known private output owners and the existing driver-copy Q also have
separate complete named-consumer ledgers. Numeric output values may differ only
at those explicit driver/consumer slots and aliases. Complete raw driver/user
tables are reconstructed, including the four new ready-copy input loads. There
is no global offset, numeric normalization, unnamed owner substitution or BUF
collapse. The driver copy is present in both images: its fresh selected BEL is
bound to its guarded trial, its three actual input signals/mask are compared to
the original source in both images, and 48 original source consumers plus its
single arithmetic operand consumer remain exact. The immediate dedicated carry
successor is named and checked. If an original pin/BEL, buffer or LAB field
differs beyond these bounds, native proof rejects without a waiver.

The native 16-row ready composition and 8-row driver tables are conditional on
plain signal states. Ready's separately pinned physical helper must independently
evaluate actual serialized pin states, both occupied banks, aliases/constants,
shared ALM neighbors, carry semantics and the complete declared FF/LAB control
closure. Its row names declare scope only: prefix raw IDs, logical truth or
previous physical acceptance are not substituted for the current full image.
Native and physical rejection are saved separately from reported timing.

Timing is computed before structural proof. e6ce77 checks all 15290 current
native report paths, the same seven endpoint/pair/window sets against both the
accepted full report and the actual current predicted prefix report, finite
complete segment sums, actual live HIP completion and LAST signoff hold scan.
Acceptance requires memory strictly above 117.34334564208984 MHz, other required
clock constraints, positive headroom on all six non-target windows and no new
LAST hold/min warning or violation. Target 130 MHz closure remains a separate
reported fact. Lower positive non-target headroom is disclosed. All-clock Fmax
nonregression is an additional diagnostic. A timing failure records a rejection
even when native and physical evidence passes.

This is host diagnostic evidence. It does not independently recompute numerical
STA, decode the RBF/CRAM or pip routes, prove unexported caches/GPU state, or test
hardware. No gain or PR is accepted merely because a route completed.
