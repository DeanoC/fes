# Actual exported physical function scope

`physical.py` is a pure module. Its only entrypoint for this comparison is
`evaluate(before_doc, after_doc, logical_ledger, profile, driver_trial)`. Both
documents must be complete final routed documents parsed with the lossless
32fd native parser, including paired PLL port records. The calling comparator
authenticates every document, the positive additive prefix proof, the current
route/profile/trial, this module and this scope. It also independently proves
the complete native graph, raw-bit partition and named consumer ledgers.

The first 527 lines retain the frozen 0f524952 pure evaluator verbatim. No old
validator, authentication function, generator or executable entrypoint runs.
The appended API reconstructs its own actual pin records and per-image driver
tokens; it never borrows numeric IDs from the pre-route prefix proof.

The ledger has exactly four keys: `ready` is the bound 10016a0f prefix
`native_graph_evidence`; `driver` names source, clone, sink, port and immediate
carry successor; `buffer_rows` names all 5,232 existing buffers and unique FF
consumers; and `private_output_rows` names the four independently proved
private output owners. The supplied profile contains the four fresh local
models and predeclared whole-LAB FF neighborhood. The actual fresh driver
trial supplies its qualified candidate and physical site.

The original ready ALUT2 (0xb), outer ALUT3 (0x32), retained ALUT4 (0x4440)
and additional ALUT4 (0x4440) are evaluated over all 16 assignments of their
four actual external native signals. Full actual pin states, inversions,
constants and aliases participate. The original and retained cells remain
exact, including the old two named ENA consumers. Only the additional bound
cohort moves from the original ready Q to the new copy Q; its full FF pins and
raw CLK3549 remain exact. Every other FF control remains unchanged. This is
an actual final-snapshot function proof, separate from the prefix's explicitly
conditional plain-SIG table.

The accepted reference already contains the driver copy. Each routed image is
therefore independently checked for the ALUT3 source/copy eight-row function,
actual effective input states, 48 retained original Q consumers and the single
copy-Q arithmetic operand. The actual current clone BEL must match the fresh
trial. Both arithmetic LUT0/LUT1 banks and the dedicated immediate CO-to-CI
successor are evaluated; original source, operand and successor pins/functions
remain strict. The absent-before old `prove_lut_copy` API is not used.

All predeclared whole LABs are closed over every original FF and every one of
their ten ALMs. The union additionally includes both actual driver-copy sites
and every named ready/private/carry owner site. Original occupied banks remain
exact after separately accounting for the new ready copy and each per-image
driver copy. Shared A/B pins must have identical actual native drivers within
each image. The complete saved LAB geometry, modes and control selectors are
required to match exactly, with no LAB-field waiver.

Every existing buffer has its own actual input driver, unique scalar private
Q alias, sole named FF.DATAIN consumer, actual physical bank and full FF
control record reconstructed in each image. All 5,232 buffer names, physical
pins, metadata and input functions remain exact. Any private numeric Q changes
are tied to these named owners by the calling native ledger; there is no
global offset, renaming rule or buffer collapse. The four other private output
owners' actual occupied banks are separately checked and remain exact.

The inherited physical model derives active-low ALUT2-to-5 half banks,
dual-bank ALUT6 masks, arithmetic `q0 + !q1 + CI`, carry coordinates, constants
and actual alias constraints. MCOMB logic applies the final 64-bit logic
permutation rather than RAM initialization reversal. Unsupported occupants,
incomplete actual pin records, sharing conflicts or missing control records
fail closed.

The result proves only the supplied exported physical/function scope. It
does not decode RBF/CRAM bits, routed mux/pip selections or control routing;
prove unexported combination caches, GPU indices or in-memory ownership;
independently calculate numerical STA; or establish hardware behavior.
Numerical timing and complete-graph acceptance belong to the outer comparator.
This completed trial remains below the retained 117.34334564208984MHz target;
physical evidence cannot turn that timing rejection into an accepted gain.
