"""Authenticate and inspect the one additive ready1/fresh-driver full route."""
import argparse
import builtins
import hashlib
import importlib.util
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
ROUTE = RAW / "local-multicopy-ready1-route-264"
PREFIX = RAW / "local-multicopy-ready1-264"
PARENT = RAW / "driver-copy-route-264/route-c0"
PROFILE_SHA = "83ddcc2b29edb2ed1e6423860a65a3d9806d077dc33a349972ce2d17bf3afcdc"
RUNNER_SHA = "3e81198bb1c9c89c8c63144b0354138514c5c10ba5b0ef5ecd82d15e3956ccf3"
RUNNER_SCOPE_SHA = "6f98611a39b498b329909bff3b0d764dab10f94214ae85039528812ecdf8f414"
PREFIX_SHA = "10016a0f227b801995eebc5c41a79c3b08d28bb6932b785349a60529d0048709"
ACCEPTED = RAW / "driver-copy-route-proof-v2-264/comparison.json"
ACCEPTED_SHA = "a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304"
PARENT_RUN_SHA = "71b2575f309d2fdfe9d23ad356f6c19c361a228477a85c446e442b0c75ff3bb2"
PREFIX_PROFILE_SHA = "8678aa88a57a59c43fc94bab14ff71fdff47b95a9e95d8bc308c82ad7826e88b"
PREFIX_RUN_SHA = "2e3996888f9297140962000d890102de5ea6936a014bca1c9c603fbe19284e5e"
CONTROL_SHA = "f3e1f1e84d408db29088c39006b205284ad173bfe900a36f89c6b6122bdb076c"
HOST_SHA = "98c1f40aac52907e60f51e27db1e5a06b49c99020187b9c59dddffdcd332689e"
COMMIT = "81243a1300304d7e598156c692be2fcbf2c16268"
BASE = "5dd69a8ddece6280d576816d2277c73f80607f52"
BINARY_SHA = "91a51253a44e74a10f6ac97fa1f3d7bdd402bc45fdede6f46ff054a5d519b5cf"
ARCHIVE_SHA = "c9476dec61230fb01f03b1baafc5efae07288f069f88b3a27e97759bdee792ad"
PURE = RAW / "narrow-integrated-264/compare_route.py"
PURE_SHA = "32fd10ebbff4332816a81278c43b48d529db94914bfb4af49cdce44f53666379"
SELECTED = RAW / "driver-copy-selected-264/compare_selected.py"
SELECTED_SHA = "72131acf8311ed508278625c3f21cade3709a88461239de16fce669aeea489ba"
FREEZE = SELECTED.parent / "freeze.py"
FREEZE_SHA = "8601df44e0b9c904234da1c5cf8f309dd10d9cbe2ef75a5e38db432069e097dd"
LOCAL = PREFIX / "run_baseline.py"
LOCAL_SHA = "440013e34d68841d103ca0bea4e3d927a9fd9f50917e10800ad604caa1aec36a"
TIMING = RAW / "driver-copy-ready-groups8-proof-264/timing.py"
TIMING_SHA = "e6ce77b778a38ee95bd905b44a034d10923ed1c6fe97f0e8e8d23d513739d89c"
TIMING_SCOPE_SHA = "5088a952653ccd349edb109bd68e038cace200c911ec7707cef1d958897d8032"
DEPS = {"fes_build_common.py": "6c8f73431c84949a5c8486145a2f5f64067a38534460539b4bb6435ce3425f9a",
        "source_repository.py": "29ab5ad573767ebe32c171a391e675852b968a4c570365ad3a2ec9637c0ca003",
        "lockfile.py": "742d5b39c3780b4bb2b6b8b212cb90b1c617b8db285dd51624dbe8c694d2976a"}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path, expected, name, frozen=None):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure module hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    if frozen is not None:
        def local_import(key, globals=None, locals=None, fromlist=(), level=0):
            return frozen if key == "freeze" and level == 0 else builtins.__import__(key, globals, locals, fromlist, level)
        module.__dict__["__builtins__"] = {**vars(builtins), "__import__": local_import}
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure module pathname differs")
    return module


def comparison(args):
    require(not (HERE / "comparison.json").exists(), "comparison output already exists")
    native = load(PURE, PURE_SHA, "additive_full_native_parser")
    audit = native.Audit()
    for path, expected in ((PURE, PURE_SHA), (Path(__file__), args.self_sha256), (HERE / "scope.md", args.scope_sha256),
            (HERE / "native_scope.py", args.native_sha256), (HERE / "physical.py", args.physical_sha256),
            (HERE / "physical-scope.md", args.physical_scope_sha256), (ROUTE / "source-identity.json", PROFILE_SHA),
            (ROUTE / "run_route.py", RUNNER_SHA), (ROUTE / "scope.md", RUNNER_SCOPE_SHA),
            (ROUTE / "route-c0/run.json", args.run_sha256), (PREFIX / "baseline/comparison-prefix.json", PREFIX_SHA),
            (PREFIX / "source-identity.json", PREFIX_PROFILE_SHA), (PREFIX / "baseline/run.json", PREFIX_RUN_SHA),
            (ACCEPTED, ACCEPTED_SHA), (PARENT / "run.json", PARENT_RUN_SHA), (LOCAL, LOCAL_SHA),
            (SELECTED, SELECTED_SHA), (FREEZE, FREEZE_SHA), (TIMING, TIMING_SHA),
            (TIMING.parent / "timing-scope.md", TIMING_SCOPE_SHA)):
        audit.bind(path, expected)
    profile, record = native.read(ROUTE / "source-identity.json"), native.read(ROUTE / "route-c0/run.json")
    prefix, parent = native.read(PREFIX / "baseline/comparison-prefix.json"), native.read(ACCEPTED)
    for manifest in (prefix, parent):
        for name, expected in manifest["artifact_sha256"].items():
            require(not Path(name).is_absolute() and ".." not in Path(name).parts, "flat artifact escapes ROOT")
            audit.bind(ROOT / name, expected)
        for name, expected in manifest["execution_file_sha256"].items():
            require(Path(name).is_absolute(), "flat execution pathname is not absolute")
            audit.bind(Path(name), expected, execution=True)
    require(prefix["structural_rejection"] is None and parent["structural_rejection"] is None and
            prefix["native_graph_proof_available"] is True and parent["candidate_accepted_under_confirmed_target_clock_rule"] is True and
            prefix["compiler_commit"] == COMMIT and prefix["source_identity_sha256"] == PREFIX_PROFILE_SHA and
            profile["prefix_proof_sha256"] == PREFIX_SHA and profile["prefix_baseline_run_sha256"] == PREFIX_RUN_SHA and
            profile["control_proof_sha256"] == CONTROL_SHA and profile["host_validation_sha256"] == HOST_SHA and
            profile["accepted_full_proof_sha256"] == ACCEPTED_SHA and profile["accepted_full_run_sha256"] == PARENT_RUN_SHA and
            profile["compiler_commit"] == COMMIT and profile["delta_base_commit"] == BASE and
            profile["binary_sha256"] == BINARY_SHA and profile["source_archive_sha256"] == ARCHIVE_SHA and
            profile["helper_sha256"] == RUNNER_SHA and profile["scope_sha256"] == RUNNER_SCOPE_SHA,
            "closed prefix/accepted/profile/compiler roles differ")
    for name, expected in profile["input_sha256"].items():
        require(Path(name).is_absolute(), "profile input pathname is not absolute")
        audit.bind(Path(name), expected, execution=not Path(name).resolve().is_relative_to(ROOT))
    for key, value in profile.items():
        if key != "input_sha256":
            require(native.canonical(record[key]) == native.canonical(value), "record frozen profile field differs: " + key)
    require(record["source_identity_sha256"] == PROFILE_SHA and record["completed"] is True and record["exit_code"] == 0 and
            record["compiler_read_audit_passed"] is True and record["final_original_input_output_runtime_hashes_stable"] is True and
            not any(key in record for key in ("failure", "partial_outputs_only", "exit_code_is_adapter_sentinel", "final_rehash_failure")) and
            record["input_sha256"] == {**profile["input_sha256"], str(ROUTE / "source-identity.json"): PROFILE_SHA} and
            record["execution"] == profile["baseline_execution"] and record["actual_live_gpu_backend"] == "hip",
            "actual closed run/profile union/runtime differs")
    for name, expected in record["execution"]["files"].items():
        require(profile["input_sha256"].get(name) == expected, "actual runtime is not in frozen input closure")
        audit.bind(Path(name), expected, execution=True)
    outputs = {str(ROUTE / "route-c0" / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf")}
    require(set(record["output_sha256"]) == outputs, "actual complete output set differs")
    for name, expected in record["output_sha256"].items():
        require(Path(name).stat().st_size > 0, "actual output is empty")
        audit.bind(Path(name), expected)
    for name, expected in DEPS.items():
        audit.bind(ROOT / "sources/misteross/scripts" / name, expected)
    runner = load(ROUTE / "run_route.py", RUNNER_SHA, "additive_full_record_definitions")
    local = load(LOCAL, LOCAL_SHA, "additive_full_local_log_parser")
    baseline, accepted_run = native.read(PREFIX / "baseline/run.json"), native.read(PARENT / "run.json")
    require(record["command"] == runner.command(baseline, accepted_run) and
            baseline["execution"] == record["execution"] and baseline["compiler_commit"] == COMMIT and
            record["cwd"] == baseline["cwd"] == accepted_run["cwd"] and
            record["diagnostic_environment"] == baseline["diagnostic_environment"] == accepted_run["diagnostic_environment"],
            "actual command/runtime/environment differs")
    log = (ROUTE / "route-c0/route.log").read_text()
    trial = runner.qualification(log)
    models = local.local_qualification(log)
    require(native.canonical(trial) == native.canonical(record["actual_fresh_driver_qualification"]) and
            native.canonical(models) == native.canonical(record["actual_selected_local_qualification"]) ==
            native.canonical(profile["prefix_fresh_local_models"]), "fresh driver/local guarded log models differ")
    require(native.PLACEMENT_METRICS.findall(log) == native.PLACEMENT_METRICS.findall((PREFIX / "baseline/phase.log").read_text()),
            "original placement metric sequence differs")
    before = native.read_netlist(PARENT / "routed.json")
    after = native.read_netlist(ROUTE / "route-c0/routed.json")
    predicted = native.read_netlist(PREFIX / "baseline/placed.json")
    require(after["creator"] == predicted["creator"], "current routed creator differs from current predicted compiler")
    report, parent_report = native.read(ROUTE / "route-c0/timing.json"), native.read(PARENT / "timing.json")
    predicted_report = native.read(PREFIX / "baseline/timing.json")
    timing = load(TIMING, TIMING_SHA, "additive_full_reported_timing")
    timing_result = timing.evaluate(after, report, parent_report, predicted_report, log, record)
    require(record["last_signoff_hold_warning_lines"] == timing_result["raw_timing"]["last_signoff_hold_warning_lines"],
            "recorder broad LAST hold scan differs")
    for name, expected in timing_result["evidence"]["pinned_pure_module_sha256"].items():
        require(audit.paths.get(Path(name)) == expected, "timing imported dependency is not authenticated")
    frozen = load(FREEZE, FREEZE_SHA, "additive_full_freeze_definitions")
    selected = load(SELECTED, SELECTED_SHA, "additive_full_native_topology", frozen)
    proof = load(HERE / "native_scope.py", args.native_sha256, "additive_full_named_slot_proof")
    physical = load(HERE / "physical.py", args.physical_sha256, "additive_full_physical_proof")
    graph, physical_evidence, rejection = None, None, None
    try:
        graph = proof.prove(native, selected, before, after, prefix["native_graph_evidence"], profile, trial)
        physical_ledger = {key: graph[key] for key in ("ready", "driver", "buffer_rows", "private_output_rows")}
        physical_evidence = physical.evaluate(before, after, physical_ledger, profile, trial)
        require(physical_evidence["physical_scope_proved"] is True, "independent physical scope did not pass")
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        rejection = str(error)
    audit.finish()
    passed = rejection is None and timing_result["passes_practical_timing_gate"]
    return {"schema": 1, "phase": "local-multicopy-ready1-additive-full-route-inspection",
        "compiler_commit": COMMIT, "delta_base_commit": BASE, "source_identity_sha256": PROFILE_SHA,
        "current_full_run_sha256": args.run_sha256, "prefix_proof_sha256": PREFIX_SHA,
        "accepted_full_proof_sha256": ACCEPTED_SHA, "generator_sha256": args.self_sha256,
        "scope_sha256": args.scope_sha256, "native_helper_sha256": args.native_sha256,
        "physical_helper_sha256": args.physical_sha256, "physical_scope_sha256": args.physical_scope_sha256,
        "candidate_completed": True, "structural_rejection": rejection,
        "native_graph_proof_available": graph is not None, "physical_scope_proved": physical_evidence is not None and rejection is None,
        "native_graph_evidence": graph, "physical_evidence": physical_evidence, "timing": timing_result,
        "routed_gain_accepted_under_confirmed_target_clock_rule": passed,
        "old_two_user_ready_copy_retained": graph is not None and graph["evidence"]["retained_first_copy_two_users_exact"],
        "actual_fresh_driver_qualification": trial, "fresh_local_models": models,
        "compiler_read_audit_passed": True, "artifact_sha256": dict(sorted(audit.artifacts.items())),
        "execution_file_sha256": dict(sorted(audit.execution.items())),
        "final_original_path_metadata_and_runtime_hashes_stable": True,
        "independent_numerical_sta_proved": False, "rbf_decoded_or_hardware_tested": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("self-sha256", "scope-sha256", "native-sha256", "physical-sha256", "physical-scope-sha256", "run-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    result = comparison(args)
    import json
    with (HERE / "comparison.json").open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in ("candidate_completed", "structural_rejection",
          "native_graph_proof_available", "physical_scope_proved", "routed_gain_accepted_under_confirmed_target_clock_rule")}, indent=2))


if __name__ == "__main__":
    main()
