Repeated local-remap stages previously skipped an outer LUT once its first copy existed. Allocate the first free paired cell/net name across cells, nets and aliases so a later FF-enable cohort can receive another copy while earlier copies and consumers remain intact.

The first copy keeps its legacy names and ID allocation order. Rejected suffix probes do not intern IDs, the search is bounded with overflow checks, and existing Boolean, placement, timing and rollback guards remain unchanged. The production change has no RTL names or design-specific locations.

On the fixed-input RAM-test profile, two additional stages retain the original three stages and the accepted driver copy:

| Clock | Accepted reference MHz | New route MHz | Required MHz |
| --- | ---: | ---: | ---: |
| Memory | 117.343346 | **117.771759** | 130.005203 |
| Pixel | 93.492897 | 93.650490 | 74.250069 |
| Capture | 378.582397 | 259.491394 | 130.005203 |

The memory gain is 0.428413 MHz. All six non-target clock-pair windows retain positive headroom, and final holds pass. Capture's 5 ns window loses 0.788 ns of headroom (3.283 to 2.495 ns); all-clock Fmax nonregression is false. Memory still misses its target by 0.799 ns.

Validation: fresh HIP Mistral build and 51 focused backend/CLI cases pass, including repeated-root selection, collision handling, exact rollback, Boolean truth, fixed FF placement and routed-report refresh. The full GPU/RBF route and independent native/exported-physical checks pass across 15,290 paths, seven clock pairs and 5,232 existing buffers. The four-stage trial that regressed to 116.523 MHz remains recorded as rejected; the fifth stage stacks on it.

Measurement used frozen source `81243a13`; this branch carries identical allocator/test bytes on merged #104 (`3f4acc0e`). The later non-RBF report refresh was absent from the measured checkout; the measured RBF signoff branch is unchanged. The publication checkout was rebuilt and tested, without claiming another full RAM-test route. See `docs/mistral-local-multicopy.md` and its machine-readable validation record for hashes, scope and margins.

Host-side timing evidence only; no hardware acceptance, independent delay calibration, default recipe or FES compiler-pin change. Related: DeanoC/fes#264.

