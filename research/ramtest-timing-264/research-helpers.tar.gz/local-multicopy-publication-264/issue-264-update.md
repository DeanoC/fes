Latest qualified fixed-input diagnostic result: **117.771759 MHz memory** (previous accepted **117.343346 MHz**, gain **0.428413 MHz**). The compiler change and experiment evidence are published in [nextpnr PR #105](https://github.com/DeanoC/nextpnr/pull/105), based on merged #104.

The generic change permits later local-remap stages to create another copy of an already-remapped control root while retaining its earlier copies. This profile stacks two additional stages on the previous three and retains the accepted LUT driver copy. Production code contains no RAM-test cell names or locations.

| Clock | Previous MHz | New MHz | Required MHz |
| --- | ---: | ---: | ---: |
| Memory | 117.343346 | **117.771759** | 130.005203 |
| Pixel | 93.492897 | 93.650490 | 74.250069 |
| Capture | 378.582397 | 259.491394 | 130.005203 |

The full HIP GPU/RBF route completed, and independent native/exported-physical scope checks passed. All 15,290 reported paths across seven actual clock pairs were checked; all six non-target windows retain positive headroom, with no final hold violations. Capture headroom in its 5 ns window decreases from 3.283 to **2.495 ns**; memory half-cycle headroom decreases from 2.091 to **2.070 ns**. The separate all-clock Fmax nonregression diagnostic is false, as disclosed under the agreed target-clock acceptance rule.

**130 MHz remains unresolved:** memory's modeled delay is 8.491 ns against a 7.692 ns window, missing by **0.799 ns**. This is an experimental diagnostic profile; FES default recipes and compiler pins have not changed, and hardware acceptance or independent physical delay calibration is not claimed.

Fresh publication build and **51 focused backend/CLI cases pass**. The measured source was `81243a13`; its allocator/test bytes match the publication branch on merged main. Full proof SHA256: `6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65`. [Measurement and provenance](https://github.com/DeanoC/nextpnr/blob/experiment/mistral-local-multicopy-264-pr/docs/mistral-local-multicopy.md), [machine-readable evidence](https://github.com/DeanoC/nextpnr/blob/experiment/mistral-local-multicopy-264-pr/docs/validation/ramtest-local-multicopy-2026-10-01.json).

The current worst path is now HPS ready0 through the port-0 control cone to a burst-count FF enable. That is the next isolated target; the previously rejected four-stage route remains preserved as a rejection.

