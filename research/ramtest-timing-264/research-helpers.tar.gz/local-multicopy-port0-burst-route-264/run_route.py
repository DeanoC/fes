"""Record fresh driver candidate0/full routing after a proved sixth-stage prefix."""
import argparse
import copy
import hashlib
import importlib.util
import math
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT, RAW = HERE.parents[2], HERE.parent
MODULE = ROOT / "sources/misteross"
BASELINE = RAW / "local-multicopy-port0-burst-stage-264"
PROOF = BASELINE / "baseline/comparison-prefix.json"
PROFILE, FOLDER = HERE / "source-identity.json", HERE / "route-c0"
PREFIX_PROFILE_SHA = "65406398d115457e974639a99e1a962e932853935856166575f2fb250074ea1c"
BASELINE_RUN_SHA = "26f920e8275d28644be63be03bb24cc32c0c76be1ffb5764783ba4cc3525fb23"
PLAN_SHA = "84cc31c72c16834659bc9490b03a226d9877b55bcd7acf2e80916bcc709e5598"
SIXTH_SHA = "57ec4a9c788d3fbf59f1a5123ee1f197bb967f4390fb4daf9642345aee6b0362"
SIXTH_SCOPE_SHA = "405b30eb0fe6a5af663832195047f2ca93dd4d1a5d0fb1fec0d878c1589d27e0"
PREVIOUS_PREFIX_SHA = "a7e83fc3c117c614f289a0697e7ee30858d7812704e6324877b56105ab2bc3c9"
ACCEPTED = RAW / "local-multicopy-ready1-address-route-proof-264/comparison.json"
ACCEPTED_SHA = "6dcf8c4bb6b4b20811334ab4a87d52163756085428fdc3dbb67b84a29c795e65"
ACCEPTED_FOLDER = RAW / "local-multicopy-ready1-address-route-264"
ACCEPTED_RUN = ACCEPTED_FOLDER / "route-c0/run.json"
ACCEPTED_RUN_SHA = "5ed3c077a6beee28c651f6b8638969160abad05d1965f55fb4ae6b373abde8dd"
ACCEPTED_PROFILE_SHA = "d32305c1cf99c1f3ead93fe11ba7e7539b3c88ae2b2b1b44b93346da3ddb5f64"
MINIMUM_MEMORY_MHZ = 117.77175903320312
OLD = RAW / "local-multicopy-ready1-route-264/run_route.py"
OLD_SHA = "3e81198bb1c9c89c8c63144b0354138514c5c10ba5b0ef5ecd82d15e3956ccf3"
OLD_SCOPE_SHA = "6f98611a39b498b329909bff3b0d764dab10f94214ae85039528812ecdf8f414"


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path, expected, name):
    data = Path(path).read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected and name not in sys.modules, "pure definition hash/name differs")
    module = importlib.util.module_from_spec(importlib.util.spec_from_file_location(name, path))
    sys.modules[name] = module
    exec(compile(data, str(path), "exec"), module.__dict__)
    require(Path(module.__file__).resolve() == Path(path).resolve(), "pure definition pathname differs")
    return module


def old_definitions():
    return load(OLD, OLD_SHA, "port0_route_frozen_definitions")


def adopt(old, inputs, proof):
    for name, expected in proof["artifact_sha256"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "artifact escapes ROOT")
        old.bind(inputs, ROOT / name, expected)
    for name, expected in proof["execution_file_sha256"].items():
        require(Path(name).is_absolute(), "execution pathname is not absolute")
        old.bind(inputs, name, expected)


def command(baseline, accepted, old):
    result, predicted = list(accepted["command"]), list(baseline["command"])
    require(result[0] == predicted[0] == str(old.COMPILER / "nextpnr-mistral") and "--no-route" not in result and
            "--compress-rbf" not in result and result.count("--router") == result.count("--gpu-device") ==
            result.count("--remap-lut-driver-candidate") == 1 and result[result.index("--router") + 1] == "gpu" and
            result[result.index("--gpu-device") + 1] == "1" and result[result.index("--remap-lut-driver-candidate") + 1] == "0",
            "accepted same-compiler full selectors differ")
    require(predicted.count("--no-route") == 1 and not any(flag in predicted for flag in
            ("--rbf", "--compress-rbf", "--remap-lut-driver-critical", "--remap-lut-driver-candidate")), "proved predicted selectors differ")
    for flag, path in (("--remap-plan", BASELINE / "local-plan.json"),
            ("--remap-lut-driver-critical", BASELINE / "baseline/timing.json"),
            ("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json"), ("--rbf", FOLDER / "core.rbf")):
        require(result.count(flag) == 1, "ambiguous accepted selector")
        result[result.index(flag) + 1] = str(path)
    predicted.remove("--no-route")
    for flag, path in (("--write", FOLDER / "routed.json"), ("--report", FOLDER / "timing.json")):
        require(predicted.count(flag) == 1, "ambiguous predicted output selector")
        predicted[predicted.index(flag) + 1] = str(path)
    predicted += ["--remap-lut-driver-critical", str(BASELINE / "baseline/timing.json"),
                  "--remap-lut-driver-candidate", "0", "--rbf", str(FOLDER / "core.rbf")]
    require(result == predicted, "full command differs outside six-plan/current guide/fresh outputs")
    return result


def local_definitions(old, label):
    sixth = load(BASELINE / "run_baseline.py", SIXTH_SHA, label + "_sixth")
    fifth = load(sixth.PREVIOUS / "run_baseline.py", sixth.LOCAL_SHA, label + "_fifth")
    four = load(old.LOCAL, old.LOCAL_SHA, label + "_four")
    return sixth, fifth, four


def scalar(cell, port):
    bits = cell["connections"][port]
    require(len(bits) == 1 and type(bits[0]) is int, "actual port is not a native scalar")
    return bits[0]


def users(top, bit):
    return sorted((name, port, index, 0) for name, cell in top["cells"].items()
        for port, bits in cell["connections"].items() if cell["port_directions"][port] == "input"
        for index, value in enumerate(bits) if value == bit)


def prepare(prefix_sha, run_sha, self_sha, scope_sha):
    old = old_definitions()
    require(run_sha == BASELINE_RUN_SHA and not PROFILE.exists() and not FOLDER.exists(), "actual closed run pin/exclusive outputs required")
    inputs = {}
    for path, expected in ((PROOF, prefix_sha), (BASELINE / "baseline/run.json", run_sha), (Path(__file__).resolve(), self_sha),
            (HERE / "scope.md", scope_sha), (OLD, OLD_SHA), (OLD.parent / "scope.md", OLD_SCOPE_SHA),
            (BASELINE / "source-identity.json", PREFIX_PROFILE_SHA), (BASELINE / "local-plan.json", PLAN_SHA),
            (BASELINE / "run_baseline.py", SIXTH_SHA), (BASELINE / "scope.md", SIXTH_SCOPE_SHA),
            (ACCEPTED, ACCEPTED_SHA), (ACCEPTED_RUN, ACCEPTED_RUN_SHA),
            (ACCEPTED_FOLDER / "source-identity.json", ACCEPTED_PROFILE_SHA)):
        old.bind(inputs, path, expected)
    proof, accepted_proof = old.read(PROOF), old.read(ACCEPTED)
    require(proof["schema"] == 1 and proof["phase"] == "local-multicopy-port0-burst-sixth-stage-bounded-native-prefix" and
            proof["compiler_commit"] == old.COMMIT and proof["delta_base_commit"] == old.BASE and
            proof["source_identity_sha256"] == PREFIX_PROFILE_SHA and proof["current_baseline_run_sha256"] == run_sha and
            proof["previous_prefix_proof_sha256"] == PREVIOUS_PREFIX_SHA and proof["structural_rejection"] is None and
            all(proof[key] is True for key in ("candidate_completed", "native_graph_proof_available",
                "fresh_driver_guide_available_after_conditional_prefix_proof", "final_original_path_metadata_and_runtime_hashes_stable")),
            "actual sixth prefix is not independently positive")
    require(accepted_proof["source_identity_sha256"] == ACCEPTED_PROFILE_SHA and accepted_proof["current_full_run_sha256"] == ACCEPTED_RUN_SHA and
            accepted_proof["structural_rejection"] is None and all(accepted_proof[key] is True for key in
            ("native_graph_proof_available", "physical_scope_proved", "routed_gain_accepted_under_confirmed_target_clock_rule")), "current accepted full anchor differs")
    adopt(old, inputs, proof); adopt(old, inputs, accepted_proof)
    require(inputs.get(str(BASELINE / "compare_prefix.py")) == proof["generator_sha256"] and
            inputs.get(str(BASELINE / "comparison-scope.md")) == proof["scope_sha256"] and
            inputs.get(str(old.CONTROL)) == old.CONTROL_SHA and inputs.get(str(old.HOST)) == old.HOST_SHA,
            "prefix/helper/control/host anchors absent from flat closure")
    identity, baseline, accepted = old.read(BASELINE / "source-identity.json"), old.read(BASELINE / "baseline/run.json"), old.read(ACCEPTED_RUN)
    require(identity["phase"] == "local-multicopy-port0-burst-sixth-stage-predicted-baseline" and
            identity["helper_sha256"] == SIXTH_SHA and identity["scope_sha256"] == SIXTH_SCOPE_SHA and
            identity["previous_prefix_proof_sha256"] == PREVIOUS_PREFIX_SHA and identity["local_plan_sha256"] == PLAN_SHA and
            baseline["source_identity_sha256"] == PREFIX_PROFILE_SHA and baseline["original_five_selected_models_exact"] is True,
            "actual sixth profile/run role differs")
    require(all(old.canonical(baseline[key]) == old.canonical(value) for key, value in identity.items() if key != "input_sha256") and
            baseline["input_sha256"] == {**identity["input_sha256"], str(BASELINE / "source-identity.json"): PREFIX_PROFILE_SHA}, "current record/profile union differs")
    for record in (baseline, accepted):
        require(record["completed"] is True and record["exit_code"] == 0 and record["compiler_read_audit_passed"] is True and
                record["compiler_commit"] == old.COMMIT and record["delta_base_commit"] == old.BASE and
                record["binary_sha256"] == old.BINARY_SHA and record["source_archive_sha256"] == old.ARCHIVE_SHA and
                record["final_original_input_output_runtime_hashes_stable"] is True and not any(key in record for key in
                    ("failure", "partial_outputs_only", "final_rehash_failure", "exit_code_is_adapter_sentinel")) and
                all(inputs.get(path) == expected for path, expected in {**record["input_sha256"], **record["output_sha256"],
                    **record["execution"]["files"]}.items()), "closed same-compiler run/output/runtime closure differs")
    require(accepted["source_identity_sha256"] == ACCEPTED_PROFILE_SHA and accepted["execution"] == baseline["execution"] == identity["baseline_execution"] and
            accepted["diagnostic_environment"] == baseline["diagnostic_environment"] and accepted["cwd"] == baseline["cwd"] == str(MODULE) and
            baseline["execution"]["gpu_device"] == 1, "same current hardware/runtime/environment differs")
    for name, expected in old.SCRIPTS.items(): old.bind(inputs, MODULE / "scripts" / name, expected)
    old.bind(inputs, old.PURE, old.PURE_SHA); old.bind(inputs, old.LOCAL, old.LOCAL_SHA)
    sixth, fifth, four = local_definitions(old, "port0_prepare")
    models = sixth.qualification((BASELINE / "baseline/phase.log").read_text(), fifth, four)
    require(old.canonical(models) == old.canonical(baseline["actual_selected_local_qualification"]) == old.canonical(proof["fresh_local_models"]) and
            old.canonical(models[:5]) == old.canonical(proof["previous_local_models"]) == old.canonical(identity["retained_local_models"]) ==
            old.canonical(accepted["actual_selected_local_qualification"]) and len(models) == 6 and
            old.read(BASELINE / "local-plan.json")["steps"] == identity["local_plan_steps"], "fresh six models/exact retained five descriptors differ")
    native = load(old.PURE, old.PURE_SHA, "port0_route_native")
    top = native.read_netlist(BASELINE / "baseline/placed.json")["modules"]["top"]
    graph = proof["native_graph_evidence"]
    require(graph["serialized_native_scope_proved"] is graph["all_original_ff_placements_and_nonprivate_raw_slots_exact"] is True and
            graph["new_clone"] == identity["expected_additional_copy_name"] == models[5]["outer"] + "$local_remap$1" and
            graph["declared_ena_redirect_count"] == len(graph["declared_ena_redirects"]) == models[5]["ena_users"] == 1 and
            graph["assignments_checked"] == 16 and graph["original_root_users_before"] == 172 and graph["original_root_users_after"] == 171 and
            old.canonical(graph["retained_copy_cohorts"]) == old.canonical(identity["retained_copy_cohorts"]) and
            top["cells"][graph["new_clone"]]["attributes"]["NEXTPNR_BEL"] == models[5]["bel"], "proved sixth clone/one-ENA/retained-copy scope differs")
    rows, frames = graph["retained_copy_cohorts"], graph["actual_retained_copy_output_rows"]
    require(len(rows) == len(frames) == 5 and {row["cell"] for row in rows} == {row["cell"] for row in frames}, "five retained output/cohort rows differ")
    cohort, owners, labs = set(), {graph["new_clone"], old.SOURCE, old.SINK}, {tuple(model["primary_lab"]) for model in models}
    for row, frame, model in zip(rows, frames, models[:5]):
        name = row["cell"]; cell = top["cells"][name]; expected = copy.deepcopy(row["record"])
        require(frame["cell"] == name and scalar(expected, "Q") == frame["before_raw_bit"] and scalar(cell, "Q") == frame["after_raw_bit"] and
                frame["consumer_slots"] == row["consumer_slots"] and users(top, frame["after_raw_bit"]) == [tuple(slot) for slot in row["consumer_slots"]] and
                len(row["consumer_slots"]) == model["ena_users"] and cell["attributes"]["NEXTPNR_BEL"] == model["bel"], "actual retained named owner/output/consumers differ")
        expected["connections"]["Q"] = [frame["after_raw_bit"]]
        require(old.canonical(expected) == old.canonical(cell), "retained copy differs outside its explicitly proved Q frame")
        cohort.update(slot[0] for slot in row["consumer_slots"]); owners.add(name)
    new_q = scalar(top["cells"][graph["new_clone"]], "Q")
    require(users(top, new_q) == [("hps_ddr.port0.skid_burstcount_MISTRAL_FF_Q_6", "ENA", 0, 0)] and
            graph["retained_port0_copy_consumers"] == next(row["consumer_slots"] for row in rows if row["cell"] == graph["retained_port0_copy"]) and
            len(graph["retained_port0_copy_consumers"]) == 10, "new FF6 slot/retained port0 ten-user cohort differs")
    cohort.update(row["cell"] for row in graph["declared_ena_redirects"])
    source, sink = top["cells"][old.SOURCE], top["cells"][old.SINK]
    q = scalar(source, "Q"); source_users = users(top, q)
    lut = source["parameters"].get("LUT")
    require(source["type"] == "MISTRAL_ALUT3" and sink["type"] == "MISTRAL_ALUT_ARITH" and scalar(sink, "A") == q and
            type(lut) is str and len(lut) == 8 and set(lut) <= {"0", "1"} and int(lut, 2) == 0x20 and
            len({scalar(source, port) for port in ("A", "B", "C")}) == 3 and len(source_users) == 49 and
            (old.SINK, "A", 0, 0) in source_users and all(q not in port["bits"] for port in top["ports"].values()), "actual ordinary eight-row/source49-to-carry edge differs")
    carry = scalar(sink, "CO")
    successors = [(name, cell) for name, cell in top["cells"].items() if name != old.SINK and cell["type"] == "MISTRAL_ALUT_ARITH" and cell["connections"].get("CI") == [carry]]
    require(len(successors) == 1, "actual immediate CO-to-CI successor is not unique")
    owners.add(successors[0][0])
    for model in models: owners.update((model["inner"], model["outer"]))
    for name in owners | cohort:
        match = re.fullmatch(r"[^.]+\.(\d+)\.(\d+)\.\d+", top["cells"][name]["attributes"]["NEXTPNR_BEL"])
        require(match is not None, "declared owner/cohort lacks a placed BEL")
        labs.add(tuple(map(int, match.groups())))
    ff_rows = []
    for name, cell in top["cells"].items():
        if cell["type"] != "MISTRAL_FF": continue
        match = re.fullmatch(r"MISTRAL_FF\.(\d+)\.(\d+)\.\d+", cell["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None, "original FF lacks a placed BEL")
        if tuple(map(int, match.groups())) in labs: ff_rows.append({"cell": name, "record": cell})
    require(cohort <= {row["cell"] for row in ff_rows} and all(top["cells"][name]["connections"]["CLK"] == [3549] for name in cohort), "whole-LAB/common-clock FF closure misses a cohort")
    report, parent_report = old.read(BASELINE / "baseline/timing.json"), old.read(ACCEPTED_FOLDER / "route-c0/timing.json")
    require(parent_report["fmax"]["ram_clock.clocks[0]"]["achieved"] == MINIMUM_MEMORY_MHZ, "current accepted memory threshold differs")
    relevant = set()
    for path in report["critical_paths"]:
        if math.fsum(segment["delay"] for segment in path["path"]) <= path["max_delay"]: continue
        for segment in path["path"]:
            if segment["type"] != "routing": continue
            launch, capture = segment["from"], segment["to"]
            if (top["cells"][launch["cell"]]["type"] in {"MISTRAL_ALUT" + str(width) for width in range(2, 7)} and
                    top["cells"][capture["cell"]]["type"] == "MISTRAL_ALUT_ARITH" and capture["port"] in {"A", "B", "C", "D0", "D1"}):
                relevant.add((launch["cell"], capture["cell"], capture["port"]))
    require(relevant == {(old.SOURCE, old.SINK, "A")} and report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290,
            "fresh current driver report relevant edge/cap/count differs")
    result = {"schema": 1, "phase": "local-multicopy-port0-burst-sixth-stage-fresh-driver-full-route", "compiler_commit": old.COMMIT,
        "delta_base_commit": old.BASE, "binary_sha256": old.BINARY_SHA, "source_archive_sha256": old.ARCHIVE_SHA,
        "prefix_proof_sha256": prefix_sha, "prefix_source_identity_sha256": PREFIX_PROFILE_SHA, "prefix_baseline_run_sha256": run_sha,
        "prefix_generator_sha256": proof["generator_sha256"], "prefix_scope_sha256": proof["scope_sha256"],
        "local_plan_sha256": PLAN_SHA, "helper_sha256": self_sha, "scope_sha256": scope_sha, "host_validation_sha256": old.HOST_SHA,
        "control_proof_sha256": old.CONTROL_SHA, "accepted_full_proof_sha256": ACCEPTED_SHA, "accepted_full_run_sha256": ACCEPTED_RUN_SHA,
        "command": command(baseline, accepted, old), "cwd": baseline["cwd"], "diagnostic_environment": baseline["diagnostic_environment"],
        "baseline_execution": baseline["execution"], "input_sha256": dict(sorted(inputs.items())), "prefix_fresh_local_models": models,
        "declared_driver_edge": [old.SOURCE, old.SINK, "A"], "driver_candidate": 0, "driver_site_must_qualify_freshly": True,
        "declared_ena_redirects": graph["declared_ena_redirects"], "new_ready_clone": graph["new_clone"], "new_ready_clone_bel": models[5]["bel"],
        "retained_copy_cohorts": rows, "actual_retained_copy_output_rows": frames,
        "prefix_private_output_owner_bijections": graph["explicit_private_output_owners"],
        "driver_current_source_record": source, "driver_current_source_consumer_slots": [list(slot) for slot in source_users],
        "driver_source_conditional_truth_rows": [{"assignment": i, "Q": (int(lut, 2) >> i) & 1} for i in range(8)],
        "driver_current_sink_record": sink, "driver_current_immediate_carry_successor": {"cell": successors[0][0], "record": successors[0][1]},
        "declared_original_local_driver_and_carry_cells": sorted(owners), "affected_whole_labs": sorted(map(list, labs)),
        "all_original_ff_members_in_affected_labs": sorted(ff_rows, key=lambda row: row["cell"]),
        "actual_fresh_driver_site_neighborhood_requires_independent_full_proof": True,
        "minimum_accepted_memory_mhz": MINIMUM_MEMORY_MHZ, "accepted_fmax": parent_report["fmax"],
        "routed_graph_proof_available": False, "physical_equivalence_independently_proved": False, "routed_gain_accepted": False, "hardware_tested": False}
    old.finish(inputs); old.clean_source()
    with PROFILE.open("x") as stream: stream.write(old.canonical(result) + "\n")
    print(old.canonical({"profile_sha256": old.sha(PROFILE), "inputs": len(inputs), "whole_labs": len(labs), "original_ffs": len(ff_rows)}))


def route(profile_sha):
    old = old_definitions(); inputs = {}
    old.bind(inputs, PROFILE, profile_sha); profile = old.read(PROFILE)
    for path, expected in profile["input_sha256"].items(): old.bind(inputs, path, expected)
    baseline, accepted = old.read(BASELINE / "baseline/run.json"), old.read(ACCEPTED_RUN)
    require(not FOLDER.exists() and profile["compiler_commit"] == old.COMMIT and profile["command"] == command(baseline, accepted, old) and
            profile["baseline_execution"] == baseline["execution"] and profile["diagnostic_environment"] == baseline["diagnostic_environment"] and
            profile["prefix_baseline_run_sha256"] == BASELINE_RUN_SHA and profile["minimum_accepted_memory_mhz"] == MINIMUM_MEMORY_MHZ and
            inputs[str(Path(__file__).resolve())] == profile["helper_sha256"] and inputs[str(HERE / "scope.md")] == profile["scope_sha256"], "frozen exclusive full-route role differs")
    old.clean_source(); sixth, fifth, four = local_definitions(old, "port0_full")
    sys.path.insert(0, str(MODULE))
    from scripts import fes_build_common as board
    from scripts.compiler_read_audit import audited_run
    from scripts.functional_execution import FunctionalInvocation
    for name, expected in old.SCRIPTS.items():
        loaded = sys.modules["scripts." + name[:-3]]
        require(inputs.get(str(MODULE / "scripts" / name)) == expected and Path(loaded.__file__).resolve() == (MODULE / "scripts" / name).resolve() and
                old.sha(loaded.__file__) == expected, "executed project dependency differs")
    invocation = FunctionalInvocation({"nextpnr-mistral": board.AuthenticatedTool(Path(profile["command"][0]),
        f"base_commit={old.BASE}; experimental_source_sha256={old.ARCHIVE_SHA}; sha256={old.BINARY_SHA}")}, 1)
    record = {**profile, "source_identity_sha256": profile_sha, "execution": invocation.inputs, "input_sha256": dict(sorted(inputs.items())), "completed": False}
    started = time.monotonic()
    try:
        require(invocation.inputs == profile["baseline_execution"] and not any(key.startswith("NEXTPNR_MISTRAL_") for key in invocation.env), "actual hardware/runtime/ambient diagnostics changed")
        FOLDER.mkdir()
        with (FOLDER / "run.json").open("x") as stream: stream.write(old.canonical(record) + "\n")
        with (FOLDER / "route.log").open("x") as output:
            result = audited_run(profile["command"], source_root=MODULE, cwd=profile["cwd"], env={**invocation.env, **profile["diagnostic_environment"]},
                stdout=output, stderr=subprocess.STDOUT, check=False, timeout=3600)
        record["exit_code"], record["compiler_read_audit_passed"] = result.returncode, True
        invocation.verify(); require(result.returncode == 0, "actual sixth-stage full compiler failed")
        log = (FOLDER / "route.log").read_text()
        require("Info: Program finished normally." in log and not any(line.startswith("ERROR:") for line in log.splitlines()) and
                "Running the GPU router" in log and "Running signoff timing analysis..." in log and "Running predicted placed timing analysis for --report" not in log,
                "actual GPU/RBF signoff provenance absent")
        models = sixth.qualification(log, fifth, four)
        require(old.canonical(models) == old.canonical(profile["prefix_fresh_local_models"]), "actual six fresh local models differ from positive prefix")
        record["actual_selected_local_qualification"], record["actual_fresh_driver_qualification"] = models, old.qualification(log)
        report = old.read(FOLDER / "timing.json")
        require(report["timing_report_paths"] == 16384 and len(report["critical_paths"]) == 15290 and
                all(type(value) in (int, float) and math.isfinite(value) and value > 0 for row in report["fmax"].values() for value in row.values()), "actual full timing cap/count/Fmax differs")
        record["fmax"], record["actual_live_gpu_backend"] = report["fmax"], board._require_gpu_backend(log)
        require(record["actual_live_gpu_backend"] == "hip" and re.search(r"GPU router time [^\n]+backend hip:", log), "actual HIP completion absent")
        last = log.rsplit("Running signoff timing analysis...", 1)[1]
        record["final_reported_hold_violations"] = "Hold/min time violation" in last
        record["last_signoff_hold_warning_lines"] = [line for line in last.splitlines() if re.search(r"\b(?:hold|min(?:imum)?)\b", line, re.I) and re.search(r"warning|violation|negative", line, re.I)]
        require(not record["final_reported_hold_violations"] and not record["last_signoff_hold_warning_lines"], "LAST signoff hold/min violation")
        record["output_sha256"] = {}
        for name in ("route.log", "routed.json", "timing.json", "core.rbf"):
            path = FOLDER / name
            require(path.is_file() and path.stat().st_size > 0, "actual full output absent")
            record["output_sha256"][str(path)] = old.sha(path)
        old.finish({**inputs, **record["output_sha256"]}); old.clean_source(); record["completed"] = True
        print(old.canonical({"completed": True, "fmax": record["fmax"], "driver": record["actual_fresh_driver_qualification"], "routed_gain_accepted": False}))
    except BaseException as error:
        record["failure"] = repr(error)
        if "exit_code" not in record:
            record["exit_code"] = 124 if isinstance(error, subprocess.TimeoutExpired) else 1
            record["exit_code_is_adapter_sentinel"] = True
        raise
    finally:
        try:
            record["elapsed_seconds"] = time.monotonic() - started
            if FOLDER.exists():
                if not record["completed"]:
                    record["partial_outputs_only"] = True
                    record["output_sha256"] = {str(FOLDER / name): old.sha(FOLDER / name) for name in ("route.log", "routed.json", "timing.json", "core.rbf") if (FOLDER / name).is_file()}
                try:
                    invocation.verify(); old.finish({**inputs, **record.get("output_sha256", {})}); old.clean_source()
                    record["final_original_input_output_runtime_hashes_stable"] = True
                except BaseException as error:
                    record["completed"] = False; record["final_original_input_output_runtime_hashes_stable"] = False; record["final_rehash_failure"] = repr(error)
                    raise
                finally:
                    (FOLDER / "run.json").write_text(old.canonical(record) + "\n")
        finally:
            invocation.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "route"))
    for name in ("prefix-sha256", "run-sha256", "self-sha256", "scope-sha256", "profile-sha256"): parser.add_argument("--" + name)
    args = parser.parse_args()
    if args.phase == "prepare":
        require(args.prefix_sha256 and args.run_sha256 and args.self_sha256 and args.scope_sha256, "actual positive prefix/closed run/helper/scope pins required")
        prepare(args.prefix_sha256, args.run_sha256, args.self_sha256, args.scope_sha256)
    else:
        require(args.profile_sha256, "before-run profile activation pin required")
        route(args.profile_sha256)


if __name__ == "__main__":
    main()
