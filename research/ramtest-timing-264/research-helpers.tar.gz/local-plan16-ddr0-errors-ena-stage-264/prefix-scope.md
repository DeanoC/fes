# Strict alternative eleventh DDR0 errors prefix

This verifier owns only the exclusive new `baseline/comparison-prefix.json`.
ROOT alone reviews and executes it. Its actual completed-run constant is absent
until ROOT supplies a closed alternative record; every activation requires
explicit self/scope, runner/scope, profile, run, guide and derivation hashes.
The draft therefore cannot activate during placement or on the failed ready0
attempt.

The actual alternative preparation is profile
`9a1a1d201d2d0d8ca2ffb825d80547abaeb7419d52dd0730e29df136ef9c398c`, plan
`eab79bbade3633b9487c553e9fb12839fe0598b512dc4ad4b7dd5f5c118689a6`,
runner 61dcdfbd and scope eb8351ad. Its command and native predecessor remain
the positive ten-stage prefix bf9d312c, closed run 3d69a28a, profile 77fd5636 and
plan 00bf9b8c. All first ten descriptor values/order and complete fresh trial
dictionaries must be exact. The sole appended step is the errors guide,
candidate0/group1/pinsfalse/fixedFF. Eleven requests remain within cap16.

Guide a9813f90 and derivation 3af38679, helper 640bb575/scope 6310761b, select
the exact current tenth full path at source index 2975 to errors FF11 ENA in
LAB 33.14. The current full native/physical construction is cd8ad7ff,
run 1a6d4f7b and profile ea033985, preserving immutable strict rejection fffb82ee.
Its routed gain remains false. The accepted fifth-stage 6dcf8c4b at
117.77175903320312 MHz is a separate timing reference; this prefix proves no
routed gain. Failed ready0 run f87673b6 remains rejected provenance only,
never a stacked stage or a positive command/graph source.

The compiler is frozen d7e5c61f on ec0a8d0c, ELF 41c2afe1, archive 4fbebd5e,
host 0f3c11a5 and positive eight-step compiler control 1cff85d6. The current
profile/input union, literal executable/runtime/PATH, diagnostic environment,
cwd and three actual no-route outputs must agree with the closed recorder.
Their flat source, build, runtime, input/output, guide and predecessor proof
maps are rehashed at original paths. No historical generator or authenticator
is replayed; old comparison/runner main, prepare and execute functions are
never invoked.

The strict native check requires the same complete module, top metadata,
settings, public ports, ordered original cell/net owners, paired duplicate PLL
records and creator. Population must be 14,907→14,908 cells and
16,645→16,646 net owners, with exactly one new ALUT6 and private alias. Every
original alias/raw-bit record is exact. Any generated private-Q renumbering
fails closed and is recorded; there is no per-owner alignment, global offset,
numeric-ID normalization or buffer collapse in this version.

The existing inner ALUT2 mask 0xd has Q4973 and literal inputs 4242/15932. The
outer ALUT5 mask 0x7fff0000 has Q4300, inputs 4969/4970/4971/4972 and inner Q
on E. The actual additional ALUT6 must have mask 0x0ddddddddddddddd and ABCDEF
input order `[4242,15932,4969,4970,4971,4972]`, each with one unchanged ordinary
native driver. All 64 assignments independently compare the original two-LUT
composition with the actual new mask. These are conditional logical-SIG rows;
missing exported pin snapshots do not become physical truth evidence.

The new cell/private-Q names must be absent before the pass in both namespaces.
Its actual Q, alias and BEL come from the completed graph/model. The new cell
must have complete ALUT6 ports/table and the same nonfunctional metadata as an
existing compiler-created copy, except its new BEL and optional site-specific
pin snapshot. The private alias metadata must match the existing copy alias
schema. An absent new snapshot is explicitly unproved. A present one must cover
all seven native ports as plain SIG, identify COMBOUT and six distinct
ALUT6 inputs A/B/C/D and E0/F0 or E1/F1 for its actual combinational half BEL.
This follows the two supported native input frames; the membership check
does not prove shared-bank allocation or physical Boolean equivalence. Every
original full pin attribute remains exact.

All ten retained copy records, literal Qs and complete cohorts
21/2/10/1/6/1/1/3/2/8 are unchanged and disjoint. The exact whole original-root
LAB33.14 cohort is eight errors FFs 5/4/3/28/23/16/12/11, each scalar ENA on
CLK3549. Only those eight named ENA slots may change to the unique new Q;
outer-root users become 32→24. The inner Q's 160 status-ENA users and original
outer E connection remain exact. Each six-leaf input gains exactly one new
native load slot; the complete driver and user tables are independently rebuilt.
No other original connections, parameters, attributes, directions, BELs or
exported order may change.

All 8,221 original FF BELs and predeclared whole-LAB records are checked. The
actual chosen clone LAB's complete original FF controls/records and available
before/after pin snapshots are emitted, even if that LAB was not known at
preparation. This is serialized graph evidence, not hidden physical state.
All 71 ordinary placement metric rows must match the preceding ten-stage run.

Pinned lower definitions are parser 32fd10eb, tables/topology 72131acf with a
locally isolated 8601df44 dependency, and 0a52299e scalar/LUT/LAB functions.
The current runner's pure command/log-definition functions bind actual fresh
eleven models and source/runtime prerequisites; no old proof function is used.
Structural failures are preserved with their exception type/reason. The
current complete document/report is separately checked for all 15,290 native
paths and seven actual domain pairs/windows, finite terms, current topology and
reported Fmax. Report equality is disclosed but not required after the new ENAs.
These checks still run on a structural rejection, and final closure hashes are
rechecked before the exclusive result is written.

There is no inherited physical acceptance, independent numerical STA,
calibration, full route/RBF decode, unexported LAB/cache/GPU-state proof,
hardware result or fresh routed-gain claim. A later full route and independent
native/physical/timing proof require a positive completed prefix.
