# Alternative eleventh DDR0 errors-enable placed qualification

This recorder owns only new source-identity.json, local-plan.json and baseline/
outputs in this directory. Prepare and execute are explicit ROOT-only activations.
The helper has not inherited candidate qualification, graph equivalence, physical
truth, routed timing or hardware acceptance.

The structural and command parent is the positive ten-stage predicted prefix:
profile77fd5636, run3d69a28a, explicit-private-owner proofbf9d312c, literal plan00bf9b8c
and recorder7a00db6a/scope0ee7db61. Its full construction has native and exported
physical proofcd8ad7ff, run1a6d4f7b/profileea033985, and remains timing-rejected.
The immutable original strict full rejectionfffb82ee is retained in that proof.

The failed ready0 eleventh attempt f87673b6 and its sole log3bed3c71 are bound as
rejected provenance only. They supply no command, graph, model or qualification.
The new alternative starts from the positive ten-stage prefix, not the failed
attempt. No old helper, generator, authentication function or entrypoint is run.

Prepare requires actual self/scope and completed errors-guide/derivation SHA
arguments. The closed guide is a9813f90 and derivation3af38679, produced by
guide640bb575/scope6310761b; any other activation pins fail closed. The guide is
derived from the current ten-stage native/physical-positive full result. It keeps
the exact source-index2975 path and every original report field, changing only
the critical-path selection. No clock term, delay, window, source or location
is rewritten.

The accepted numerical reference remains the fifth full proof6dcf8c4b at
117.77175903320312 MHz. cd8ad7ff has no accepted gain. This predicted experiment
does not compare routed Fmax or claim progress against that accepted number.

The sole plan change appends index10 to the exact first ten descriptor values
and order: candidate0, groups1, optimize_pins=false, preserve_ff_placement=true.
Eleven steps fit the current compiler's16-step limit. No prior report descriptor,
seed, timing option, source input, BUILD_ID, diagnostic environment or device
selection changes. The command swaps only plan/write/report output paths.

The current compiler is clean d7e5c61f on ec0a8d0c, ELF41c2afe1, archive4fbebd5e,
host0f3c11a5, with fresh eight-step prerequisite1cff85d6. Current compiled sources,
host dependency files, original input/output path hashes and actual loaded
compiler runtime are flat-bound and rehashed before and after ROOT activation.
The current execution must exactly equal the closed tenth execution, including
literal compiler path and PATH. Historical host build-runtime authentication
and compiler qualification are not inferred from current byte hashes.

The actual errors cone has inner ALUT2 mask0xd at24.22, Q4973 and161 users,
outer ALUT5 mask0x7fff0000 at10.22, Q4300 and32 original FF.ENA users. The target
group is exactly eight errors FFs in LAB33.14: indices5,4,3,28,23,16,12,11.
Each has CLK3549; the guide target is FF11. The six distinct boundary raw bits
are4242,15932,4969,4970,4971,4972. The expected composed ALUT6 mask is
0x0ddddddddddddddd, and the guide's64 existing-function rows are search provenance.
Both the new cell name outer+'$local_remap' and its '$Q' pair must be unused
across existing cells and native net names.

Prepare records all ten retained copy/cohort manifests and their counts
21/2/10/1/6/1/1/3/2/8, with original8221 FF BELs and complete known original
FF neighborhoods. A fresh chosen clone LAB may extend the later prefix-proof
scope. No future clone BEL, Q identifier, gain or guard result is guessed.

Execute requires the actual prepared profile SHA and exclusive baseline outputs.
It performs fresh pack/place only. The first ten complete guarded models must
equal the closed tenth models. The new candidate must have a final guarded trial,
candidate0/application, group1/eight ENAs, zero FF shift, minimum250ps gain, and
compiled clock/hold/boundary guards all1. Earlier rejected trials remain recorded.

A bounded postrun observation checks the actual new ALUT6 table, ABCDEF input
bits, chosen BEL, unique Q driver, eight named ENA consumers and original Q4300
user partition32→24. It does not prove the complete graph, conditional Boolean
equivalence, physical pins/LAB state, clock-pair STA or final route. A separate
independent prefix proof is required before any full driver/GPU/RBF route.

The predicted report must have cap16384 and15290 paths. Raw logs and all actual
outputs are hashed, and failure preserves a completed=false partial record.
No GPU router, driver copy, RBF generation, analogue signoff or hardware action
is authorized by this recorder.
