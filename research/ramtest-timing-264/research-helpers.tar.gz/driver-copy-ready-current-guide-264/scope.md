# Exact current ready-path diagnostic guide

Root alone freezes and executes this new standalone derivation. It neither
imports nor executes old generators, authenticators, compilers, tests, routes
or STA. The running same-old-guide groups8 control remains unchanged. No new
freeze/run profile or production compiler change is authored here.

The only parent is completed positive proofa4a91235, current5dd compiler,
fullreportb0bdb497 and fullnative47a166b4. The helper binds its own reviewed
bytes/scope and that exact proof, rehashes all526 artifact and281 historical
execution-file paths in its closed flat closure before and after derivation,
and requires completed authenticated full and same-binary driver-disabled
baseline runs with unchanged board/clock constraint inputs. It does not rerun
the parent proof. These historic runtime hashes do not constitute a loaded
library trace for this new Python invocation.

The output ready-guide.json has one top-level field, critical_paths. It holds
all109 actual original HPS cmd_ready_1→slot_free ALUT2→slot_free ALUT3→skid
FF.ENA objects in their original full-report order:91 violate their reported
window and21 LABs are covered. Every object is retained exactly, including
the full clock-domain strings, clock skew, clock-to-Q, all logic/routing/setup
segments, original locations/net names/source strings/window and numeric
delays. No clock term is stripped, no window/arc/delay is manufactured, and
no full fmax/detailed_net_timings section or private postdriver path leaks
into the guide. Its separate derivation.json records each original source
index, canonical path digest, exact registered endpoint and current native
logical port/bit/XY ledger; the guide file and original report are hashed.

The independent duplicate-safe native reader preserves both ordered scalar
altera_pll outclk entries. It rejects other duplicate keys and preserves their
actual ordered bits112724 and112726. The actual memory clock bit3549 is driven
by ram_clock.clocks_MISTRAL_CLKBUF_Q_1.Q. Its A input bit112726 has the lossless
PLL driver outclk occurrence1; that raw occurrence is not assumed to equal a
logical output_clock_frequency/phase_shift parameter channel. The explicit
CLKBUF has identical complete metadata, parameters, BEL, ports and connections
in both images, excluding only the old absent FES_PINMAP snapshot. Actual full
CLKBUF A/Q pins are separately verified as ordinary SIG; the old unexported
pin states remain unproved. Both PLL outputs and the buffered clock retain
their complete native alias identities and alias metadata, except for the
different observed ROUTING fields. No clock BUF is collapsed or removed.
The HPS launch-clock port and every selected FF capture CLK share the actual
buffered memory bit/alias, and its entire native user list is identical in
both frames. Whole PLL parameters and authenticated constraints match the
old disabled-driver baseline; frequency and windows remain reported values.
It checks known primitive types, ordinary full-image SIG pin
states, directions, exact routing driver/user/alias identities, original
source tables and endpoint metadata/BELs. Every selected report port/XY/edge
must also exist identically in the old driver-domains baseline. Final late
BUF DATAIN identities are not selected report ports and are never normalized
or used as a waiver. The old baseline has no physical pin snapshot: its
unexported pin states are expressly unproved, while actual full-image pin
states are separately checked. This diagnostic does not recompute frequency,
clock windows, STA or physical route delays.

The current root has exactly109 ENA users matching the guide endpoints; the
current existing local clone separately has two ENA users in LAB29.12. The
helper records their exact disjoint current111-user union. Neither available
image is a serialized snapshot immediately before local stage1, so the
helper does not claim to reconstruct or independently prove a pre-step
111-user graph. Replacing the old stage would need fresh live qualification,
whole-LAB/clock/polarity checks and an independent selected-prefix graph and
function proof. Candidate ordinal, site, modeled gain, downstream guide
validity and driver qualification cannot be inherited.

The unchanged routed path numbers provide search provenance only. A future
isolated plan may replace zero-based local stage1's report while retaining
groups8, fixed FF placement and pinsfalse, and then must produce a new actual
prefix report before fresh driver listing/selection/full routing. This
derivation performs no candidate qualification, LUT composition/equivalence
proof, new timing acceptance, RBF/CRAM decoding, cache/GPU proof or hardware
test. It cannot inherit the accepted117.343MHz gain or close130MHz.
