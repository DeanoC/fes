"""Derive an exact diagnostic ready-path subset; never run a compiler or STA."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RAW = HERE.parent
PROOF = RAW / "driver-copy-route-proof-v2-264/comparison.json"
PROOF_SHA = "a4a91235f652af541265daa5a3b6e12e658dc6f01089ce16ecad622b95b2b304"
REPORT = RAW / "driver-copy-route-264/route-c0/timing.json"
REPORT_SHA = "b0bdb4971c777d9f4567f03926bc26aabaca391bd89374b543b8df414f961ff7"
FULL = RAW / "driver-copy-route-264/route-c0/routed.json"
FULL_SHA = "47a166b4f8ec5bd6bc21f4760ea25809b9ff0e7c6102f640968390f1c93b01fd"
FULL_RUN = RAW / "driver-copy-route-264/route-c0/run.json"
FULL_RUN_SHA = "71b2575f309d2fdfe9d23ad356f6c19c361a228477a85c446e442b0c75ff3bb2"
BASELINE = RAW / "driver-domains-264/baseline/placed.json"
BASELINE_SHA = "f6282f1cac8f063e96288d28ae35bbfc399a65390c291b3d9dea585280e684eb"
BASELINE_RUN = RAW / "driver-domains-264/baseline/run.json"
BASELINE_RUN_SHA = "d2afc1e34789d2974748cc86587bf62780b2441a186e05276ee8e9df8ba88156"
COMMIT = "5dd69a8ddece6280d576816d2277c73f80607f52"
BINARY_SHA = "2ebe29caf7ca46b3c68afd23d26efda1426c94bc6f1b214d22f810bb5c48351c"
ARCHIVE_SHA = "840e7a4445038ea7d17bfbc19215c257078686df66d11aa56c422899631feaee"
GENERATOR_SHA = "7e6257279931ff36008134b7c1a7c60edaecd2f26207aeb414247a37f5286477"
FULL_ID_SHA = "d56a1207bcf255c6e39bcab6bd322ece712f48cefd9ad65280c2fd29d51beee2"
HPS = "hps_ddr.f2sdram"
INNER = "hps_ddr.port1.slot_free_MISTRAL_ALUT2_Q"
OUTER = "hps_ddr.port1.slot_free_MISTRAL_ALUT3_B"
EXISTING_CLONE = OUTER + "$local_remap"
CLOCK = "ram_clock.clocks[0]"
DOMAIN = "posedge " + CLOCK
PLL = "ram_clock.pll"
CLOCKBUF = "ram_clock.clocks_MISTRAL_CLKBUF_Q_1"
GUIDE = HERE / "ready-guide.json"
MANIFEST = HERE / "derivation.json"
DIGEST = re.compile(r"[0-9a-f]{64}")
BEL = re.compile(r".+\.(\d+)\.(\d+)\.(\d+)")


def require(condition, message):
    if not condition:
        raise ValueError("ready-guide derivation: " + message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def nonfinite(value):
    raise ValueError("nonfinite JSON value: " + value)


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=nonfinite)


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False, separators=(",", ":"))


def object_sha(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


class Audit:
    def __init__(self):
        self.paths = {}
        self.memo = {}
        self.artifacts = {}
        self.runtime = {}

    def bind(self, path, expected, runtime=False):
        path = Path(path)
        require(path.is_absolute() and type(expected) is str and DIGEST.fullmatch(expected), "invalid input binding")
        resolved = path.resolve()
        require(runtime or resolved.is_relative_to(ROOT), "artifact escaped workspace")
        if resolved not in self.memo:
            self.memo[resolved] = sha(path)
        require(self.memo[resolved] == expected, "input hash changed: " + str(path))
        require(path not in self.paths or self.paths[path] == expected, "conflicting original input identity")
        self.paths[path] = expected
        if runtime:
            self.runtime[str(path)] = expected
        else:
            self.artifacts[str(path.relative_to(ROOT))] = expected

    def finish(self):
        require(all(sha(path) == digest for path, digest in self.paths.items()), "original evidence/runtime changed during derivation")


class Pairs(list):
    pass


def read_native(path):
    """Retain the actual paired scalar PLL ports; reject all other duplicates."""
    raw = json.loads(Path(path).read_text(), object_pairs_hook=Pairs, parse_constant=nonfinite)
    repeated_fields = {}

    def convert(value, location=(), pll_parent=False):
        if isinstance(value, Pairs):
            counts = Counter(key for key, _ in value)
            repeated = {key for key, count in counts.items() if count > 1}
            allowed = (pll_parent and len(location) == 5 and location[:1] == ("modules",) and
                       location[2] == "cells" and location[4] in {"connections", "port_directions"})
            require(not repeated or allowed and repeated == {"outclk"} and counts["outclk"] == 2,
                    "unpermitted duplicate native key at " + repr(location))
            is_cell = len(location) == 4 and location[0] == "modules" and location[2] == "cells"
            pll = is_cell and dict(value).get("type") == "altera_pll"
            converted = [(key, convert(item, (*location, key), pll)) for key, item in value]
            if repeated:
                repeated_fields[location] = converted
            return dict(converted)
        if isinstance(value, list):
            return [convert(item, (*location, index)) for index, item in enumerate(value)]
        return value

    result = convert(raw)
    require(type(result) is dict and set(result) == {"creator", "modules"} and
            type(result["creator"]) is str and set(result["modules"]) == {"top"}, "native root/schema changed")
    top = result["modules"]["top"]
    require(set(top) == {"settings", "attributes", "ports", "cells", "netnames"}, "native top schema changed")
    pll_fields = defaultdict(dict)
    for location, values in repeated_fields.items():
        require(location[1] == "top", "unexpected native module")
        pll_fields[location[3]][location[4]] = values
    for name, fields in pll_fields.items():
        require(set(fields) == {"connections", "port_directions"}, "unpaired PLL duplicate fields")
        directions, connections = fields["port_directions"], fields["connections"]
        require([key for key, _ in directions] == [key for key, _ in connections], "PLL ordered ports differ")
        require([value for key, value in directions if key == "outclk"] == ["output", "output"], "PLL output directions changed")
        outputs = [value for key, value in connections if key == "outclk"]
        require(len(outputs) == 2 and all(type(bits) is list and len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0
                for bits in outputs) and outputs[0] != outputs[1], "PLL outputs are not two distinct scalar bits")
        require(top["cells"][name]["type"] == "altera_pll" and
                int(top["cells"][name]["parameters"]["number_of_clocks"], 2) == 2, "PLL output count changed")
    return result, dict(pll_fields)


class Native:
    def __init__(self, path):
        self.image, self.pll = read_native(path)
        self.top = self.image["modules"]["top"]
        self.cells, self.nets = self.top["cells"], self.top["netnames"]
        self.drivers, self.users, self.aliases = {}, defaultdict(list), defaultdict(list)
        for name, cell in self.cells.items():
            require(type(name) is str and type(cell) is dict and
                    set(cell["connections"]) == set(cell["port_directions"]), "native cell ports changed")
            if name in self.pll:
                fields = self.pll[name]
                entries = [(port, direction, bits) for (port, direction), (_, bits) in
                           zip(fields["port_directions"], fields["connections"])]
            else:
                entries = [(port, cell["port_directions"][port], bits) for port, bits in cell["connections"].items()]
            occurrence = Counter()
            for port, direction, bits in entries:
                require(direction in {"input", "output", "inout"} and type(bits) is list, "unsupported native port")
                current = occurrence[port]
                occurrence[port] += 1
                for index, bit in enumerate(bits):
                    require(type(bit) is int and bit >= 0 or type(bit) is str and bit in {"0", "1", "x", "z"}, "unsupported native bit")
                    slot = current if name in self.pll and port == "outclk" else index
                    if direction == "output":
                        require(type(bit) is int and bit not in self.drivers, "ambiguous native driver")
                        self.drivers[bit] = (name, port, slot)
                    if direction in {"input", "inout"}:
                        self.users[bit].append((name, port, slot))
        for name, port in self.top["ports"].items():
            require(port["direction"] in {"input", "output", "inout"}, "unexpected top direction")
            for index, bit in enumerate(port["bits"]):
                if port["direction"] == "input":
                    require(type(bit) is int and bit not in self.drivers, "ambiguous top driver")
                    self.drivers[bit] = ("<top>", name, index)
                else:
                    self.users[bit].append(("<top>", name, index))
        for name, net in self.nets.items():
            require(type(name) is str and type(net["bits"]) is list, "native alias changed")
            for index, bit in enumerate(net["bits"]):
                self.aliases[bit].append((name, index))
        for values in self.users.values():
            values.sort()

    def xy(self, name):
        match = BEL.fullmatch(self.cells[name]["attributes"].get("NEXTPNR_BEL", ""))
        require(match is not None, "missing native BEL for " + name)
        return [int(match[1]), int(match[2])]

    def scalar(self, name, port, direction):
        require(name in self.cells and port in self.cells[name]["connections"] and
                self.cells[name]["port_directions"][port] == direction, "missing/misdirected scalar port")
        bits = self.cells[name]["connections"][port]
        require(len(bits) == 1 and type(bits[0]) is int and bits[0] >= 0, "non-signal scalar endpoint")
        return bits[0]

    def endpoint(self, value, direction=None):
        require(type(value) is dict and set(value) == {"cell", "port", "loc"} and
                type(value["cell"]) is str and "$" not in value["cell"] and type(value["port"]) is str and
                type(value["loc"]) is list and len(value["loc"]) == 2 and all(type(x) is int for x in value["loc"]),
                "unexpected or private report endpoint")
        name, port = value["cell"], value["port"]
        require(name in self.cells and self.xy(name) == value["loc"], "stale report cell/XY")
        actual = self.cells[name]["port_directions"].get(port)
        require(direction is None or actual == direction, "report endpoint direction changed")
        return self.scalar(name, port, actual)

    def pins(self, name):
        raw = self.cells[name]["attributes"].get("FES_PINMAP_V1")
        require(type(raw) is str, "actual full native pin snapshot missing")
        value = json.loads(bytes.fromhex(raw).decode(), object_pairs_hook=unique, parse_constant=nonfinite)
        require(set(value) == {"count", "pins"} and type(value["count"]) is int and
                type(value["pins"]) is dict and value["count"] == len(value["pins"]), "invalid actual pin snapshot")
        return value["pins"]


def cell_metadata(cell):
    return {key: ({k: v for k, v in value.items() if k != "FES_PINMAP_V1"} if key == "attributes" else value)
            for key, value in cell.items() if key != "connections"}


def authenticate(audit, generator_sha, scope_sha, parent_sha):
    require(parent_sha == PROOF_SHA, "different accepted parent proof")
    audit.bind(HERE / "derive_ready_guide.py", generator_sha)
    audit.bind(HERE / "scope.md", scope_sha)
    audit.bind(PROOF, PROOF_SHA)
    proof = read(PROOF)
    require(proof["schema"] == 1 and proof["phase"] == "explicit-private-buffer-ledger-lut-driver-copy-full" and
            proof["compiler_commit"] == COMMIT and proof["generator_sha256"] == GENERATOR_SHA and
            proof["source_identity_sha256"] == FULL_ID_SHA and proof["structural_rejection"] is None and
            all(proof[field] is True for field in ("candidate_completed", "graph_proof_available", "full_graph_and_pin_equivalence_proved",
                "candidate_accepted_under_confirmed_target_clock_rule", "passes_practical_timing_gate",
                "passes_strict_all_clock_diagnostic_gate", "final_original_path_metadata_and_runtime_hashes_stable")) and
            all(proof[field] is False for field in ("global_id_normalization_or_buf_collapse_used", "old_comparison_generators_or_main_executed",
                "hardware_tested", "rbf_byte_equivalence_or_cram_decode_claimed")), "parent proof classification changed")
    artifacts, runtime = proof["artifact_sha256"], proof["execution_file_sha256"]
    require(type(artifacts) is dict and len(artifacts) == 526 and type(runtime) is dict and len(runtime) == 281,
            "accepted flat closure changed")
    for name, digest in artifacts.items():
        path = Path(name)
        require(not path.is_absolute() and ".." not in path.parts and str(path) == name, "noncanonical artifact closure path")
        audit.bind(ROOT / path, digest)
    for name, digest in runtime.items():
        audit.bind(name, digest, runtime=True)
    for path, digest in ((REPORT, REPORT_SHA), (FULL, FULL_SHA), (FULL_RUN, FULL_RUN_SHA),
                         (BASELINE, BASELINE_SHA), (BASELINE_RUN, BASELINE_RUN_SHA)):
        require(artifacts.get(str(path.relative_to(ROOT))) == digest, "required input absent from accepted closure")
        audit.bind(path, digest)
    runs = [read(FULL_RUN), read(BASELINE_RUN)]
    for run in runs:
        require(run["schema"] == 1 and run["completed"] is True and run["exit_code"] == 0 and
                run["compiler_read_audit_passed"] is True and run["compiler_commit"] == COMMIT and
                run["binary_sha256"] == BINARY_SHA and run["source_archive_sha256"] == ARCHIVE_SHA and
                run["timing_report_paths"] == 16384, "closed current-source run identity changed")
        for name, digest in run["output_sha256"].items():
            require(artifacts.get(str(Path(name).relative_to(ROOT))) == digest, "run output not bound by accepted closure")
    for suffix in ("boards/de10nano/clocks.sdc", "cores/fes-ramtest/constraints.qsf"):
        matches = [[(name, digest) for name, digest in run["input_sha256"].items() if name.endswith("/" + suffix)] for run in runs]
        require(len(matches[0]) == len(matches[1]) == 1 and matches[0] == matches[1], "native frames use different clock/board constraints")
        audit.bind(*matches[0][0])
    require(runs[0]["source_identity_sha256"] == FULL_ID_SHA and runs[0]["phase"] == "route-c0" and
            runs[1]["phase"] == "baseline" and runs[1]["driver_candidate"] is None and
            "--no-route" in runs[1]["command"] and "--remap-lut-driver-critical" not in runs[1]["command"],
            "native frame roles changed")
    return proof


def select(report):
    require(set(report) == {"critical_paths", "detailed_net_timings", "fmax", "timing_report_paths", "utilization"} and
            report["timing_report_paths"] == 16384 and type(report["critical_paths"]) is list and
            len(report["critical_paths"]) == 15290, "accepted expanded report shape changed")
    selected = []
    for index, path in enumerate(report["critical_paths"]):
        segments = path.get("path", [])
        edges = [segment for segment in segments if segment.get("type") == "routing"]
        if len(edges) < 2:
            continue
        a, b = edges[-2:]
        if (a.get("from", {}).get("cell") == INNER and a.get("to", {}).get("cell") == OUTER and
                b.get("from", {}).get("cell") == OUTER and b.get("to", {}).get("port") == "ENA"):
            selected.append((index, path))
    require(len(selected) == 109, "actual original two-LUT ready subset no longer has109 paths")
    return selected


def validate(selected, full, baseline, report):
    require(full.image["creator"] == baseline.image["creator"], "native creator mismatch")
    require(full.cells[HPS]["type"] == "cyclonev_hps_interface_fpga2sdram" and
            full.cells[INNER]["type"] == "MISTRAL_ALUT2" and full.cells[OUTER]["type"] == "MISTRAL_ALUT3" and
            full.cells[INNER]["parameters"] == {"LUT": "1011"} and full.cells[OUTER]["parameters"] == {"LUT": "00110010"},
            "actual original cone primitive/table changed")
    clock = full.scalar(HPS, "cmd_port_clk_1", "input")
    require(full.nets[CLOCK]["bits"] == [clock] and baseline.nets[CLOCK]["bits"] == [clock] and
            clock == 3549 and full.drivers[clock] == baseline.drivers[clock] == (CLOCKBUF, "Q", 0) and
            PLL in full.pll and PLL in baseline.pll, "clock alias/actual buffered native driver mismatch")
    require(full.pll[PLL] == baseline.pll[PLL] and cell_metadata(full.cells[PLL]) == cell_metadata(baseline.cells[PLL]) and
            full.cells[PLL]["parameters"]["output_clock_frequency0"] == "130.0 MHz" and
            full.cells[PLL]["parameters"]["phase_shift0"] == "0 ps", "original registered-clock source changed")
    pll_outputs = [bits for port, bits in full.pll[PLL]["connections"] if port == "outclk"]
    require(pll_outputs == [[112724], [112726]], "ordered paired PLL native outputs changed")
    require(full.cells[CLOCKBUF]["type"] == baseline.cells[CLOCKBUF]["type"] == "MISTRAL_CLKBUF" and
            full.cells[CLOCKBUF]["parameters"] == baseline.cells[CLOCKBUF]["parameters"] == {} and
            full.cells[CLOCKBUF]["port_directions"] == baseline.cells[CLOCKBUF]["port_directions"] == {"A": "input", "Q": "output"} and
            cell_metadata(full.cells[CLOCKBUF]) == cell_metadata(baseline.cells[CLOCKBUF]) and
            full.cells[CLOCKBUF]["connections"] == baseline.cells[CLOCKBUF]["connections"] == {"A": [112726], "Q": [clock]} and
            full.cells[CLOCKBUF]["attributes"]["NEXTPNR_BEL"] == "MISTRAL_CLKENA.0.35.0" and
            full.pins(CLOCKBUF) == {"A": [0, "A"], "Q": [0, "Q"]} and
            "FES_PINMAP_V1" not in baseline.cells[CLOCKBUF]["attributes"],
            "original CLKBUF metadata, exact input/output or actual full SIG pins changed")
    pll_input = full.scalar(CLOCKBUF, "A", "input")
    require(baseline.scalar(CLOCKBUF, "A", "input") == pll_input and
            full.drivers[pll_input] == baseline.drivers[pll_input] == (PLL, "outclk", 1) and
            full.users[pll_input] == baseline.users[pll_input] == [(CLOCKBUF, "A", 0)] and
            full.users[clock] == baseline.users[clock], "buffered clock native driver/user chain changed")
    clock_aliases = []
    for bit, expected_alias in ((clock, CLOCK), (112724, "ram_clock.pll_outclk_1"), (pll_input, "ram_clock.pll_outclk")):
        require(full.aliases[bit] == baseline.aliases[bit] == [(expected_alias, 0)], "complete original clock aliases changed")
        def alias_metadata(native):
            net = native.nets[expected_alias]
            return {key: ({name: value for name, value in item.items() if name != "ROUTING"} if key == "attributes" else item)
                    for key, item in net.items()}
        require(alias_metadata(full) == alias_metadata(baseline), "original clock alias metadata changed")
        clock_aliases.append({"alias": expected_alias, "index": 0, "native_bit": bit,
                              "metadata_excluding_actual_routing": alias_metadata(full)})
    fmax = report["fmax"][CLOCK]
    require(set(fmax) == {"achieved", "constraint"} and all(type(value) in (int, float) and math.isfinite(value) and value > 0
            for value in fmax.values()), "known clock report is unconstrained/nonfinite")
    refs, endpoints, membership = set(), set(), []
    labs, violations = Counter(), 0
    for index, path in selected:
        require(set(path) == {"from", "to", "max_delay", "path"} and path["from"] == path["to"] == DOMAIN and
                type(path["max_delay"]) in (int, float) and math.isfinite(path["max_delay"]) and path["max_delay"] > 0,
                "ready path clock/window changed")
        parts = path["path"]
        require([segment["type"] for segment in parts] == ["clk-skew", "clk-to-q", "routing", "logic", "routing", "logic", "routing", "setup"],
                "ready path term sequence changed")
        sink = parts[-1]["to"]["cell"]
        require(sink.startswith("hps_ddr.port1.skid_") and full.cells[sink]["type"] == "MISTRAL_FF" and sink not in endpoints,
                "unexpected or duplicate original registered endpoint")
        endpoints.add(sink)
        expected = [(HPS, "cmd_port_clk_1", sink, "CLK"), (HPS, "cmd_ready_1", HPS, "cmd_ready_1"),
                    (HPS, "cmd_ready_1", INNER, "A"), (INNER, "A", INNER, "Q"), (INNER, "Q", OUTER, "B"),
                    (OUTER, "B", OUTER, "Q"), (OUTER, "Q", sink, "ENA"), (sink, "ENA", sink, "ENA")]
        for segment, row in zip(parts, expected):
            require(set(segment) == ({"type", "from", "to", "delay", "net", "sources"} if segment["type"] == "routing" else
                                    {"type", "from", "to", "delay"}) and
                    (segment["from"]["cell"], segment["from"]["port"], segment["to"]["cell"], segment["to"]["port"]) == row and
                    type(segment["delay"]) in (int, float) and math.isfinite(segment["delay"]), "ready path arc/schema changed")
            for side in ("from", "to"):
                value = segment[side]
                bit = full.endpoint(value)
                require(baseline.endpoint(value) == bit, "original scalar report endpoint differs in old driver-disabled baseline")
                name, port = value["cell"], value["port"]
                refs.add((name, port))
                require(cell_metadata(full.cells[name]) == cell_metadata(baseline.cells[name]), "original endpoint metadata differs")
                pin = full.pins(name).get(port)
                require(type(pin) is list and len(pin) >= 2 and pin[0] == 0 and all(type(value) is str for value in pin[1:]),
                        "actual full-image selected signal/clock pin is not ordinary SIG")
            if segment["type"] == "routing":
                require(type(segment["net"]) is str and "$" not in segment["net"] and type(segment["sources"]) is list and
                        all(type(source) is str for source in segment["sources"]), "private or malformed routing provenance")
                for native in (full, baseline):
                    bit = native.endpoint(segment["from"], "output")
                    require(native.endpoint(segment["to"], "input") == bit and
                            native.drivers.get(bit) == (row[0], row[1], 0) and native.nets[segment["net"]]["bits"] == [bit] and
                            (segment["net"], 0) in native.aliases[bit] and (row[2], row[3], 0) in native.users[bit],
                            "native routing edge/driver/user/alias mismatch")
        require(full.scalar(sink, "CLK", "input") == baseline.scalar(sink, "CLK", "input") == clock,
                "registered ENA endpoint has different actual clock")
        total = math.fsum(segment["delay"] for segment in parts)
        require(math.isfinite(total), "nonfinite untouched native report sum")
        violated = total > path["max_delay"]
        violations += int(violated)
        labs[tuple(parts[-1]["to"]["loc"])] += 1
        membership.append({"source_index": index, "canonical_path_sha256": object_sha(path), "endpoint": sink,
                           "port": "ENA", "loc": parts[-1]["to"]["loc"], "reported_sum_ns": total,
                           "reported_window_ns": path["max_delay"], "reported_window_violated": violated})
    require(violations == 91 and len(labs) == 21, "actual109-path/91-violation/21-LAB profile changed")
    old_bit = full.scalar(OUTER, "Q", "output")
    original_users = [(name, "ENA", 0) for name in sorted(endpoints)]
    require(full.users[old_bit] == baseline.users[old_bit] == original_users, "original109-user report coverage is incomplete")
    require(EXISTING_CLONE in full.cells and EXISTING_CLONE in baseline.cells and
            full.cells[EXISTING_CLONE]["type"] == "MISTRAL_ALUT4" and
            full.cells[EXISTING_CLONE]["parameters"] == {"LUT": "0100010001000000"} and
            cell_metadata(full.cells[EXISTING_CLONE]) == cell_metadata(baseline.cells[EXISTING_CLONE]) and
            full.cells[EXISTING_CLONE]["connections"] == baseline.cells[EXISTING_CLONE]["connections"], "existing local clone changed")
    clone_bit = full.scalar(EXISTING_CLONE, "Q", "output")
    copied_users = full.users[clone_bit]
    require(copied_users == baseline.users[clone_bit] and len(copied_users) == 2 and
            all(name not in endpoints and port == "ENA" and slot == 0 and full.cells[name]["type"] == "MISTRAL_FF" and
                full.xy(name) == baseline.xy(name) == [29, 12] and full.scalar(name, "CLK", "input") ==
                baseline.scalar(name, "CLK", "input") == clock for name, port, slot in copied_users), "existing two-user29.12clone ledger changed")
    return {"membership": membership, "registered_clock": {"domain": DOMAIN, "native_bit": clock, "alias": CLOCK,
                "actual_launch_clock_port": [HPS, "cmd_port_clk_1"], "native_driver": list(full.drivers[clock]),
                "explicit_clockbuf": {"cell": CLOCKBUF, "input_port": "A", "input_native_bit": pll_input,
                    "input_native_driver": list(full.drivers[pll_input]), "output_port": "Q", "output_native_bit": clock,
                    "bel": full.cells[CLOCKBUF]["attributes"]["NEXTPNR_BEL"], "actual_full_pins": full.pins(CLOCKBUF),
                    "old_baseline_pin_snapshot_absent_and_unproved": True,
                    "all_other_metadata_ports_parameters_and_connections_exact": True},
                "ordered_paired_pll_native_outputs": pll_outputs, "complete_clock_aliases": clock_aliases,
                "raw_pll_port_occurrence_assumed_equal_to_logical_parameter_channel": False,
                "clockbuf_collapsed_or_removed": False,
                "constrained_by_authenticated_report": True, "clock_frequency_or_window_recomputed": False},
            "endpoint_port_ledger": [{"cell": name, "port": port, "native_bit": full.scalar(name, port, full.cells[name]["port_directions"][port]),
                "direction": full.cells[name]["port_directions"][port], "xy": full.xy(name), "actual_full_pin": full.pins(name)[port],
                "old_baseline_has_pin_snapshot": "FES_PINMAP_V1" in baseline.cells[name]["attributes"]} for name, port in sorted(refs)],
            "lab_counts": [{"loc": list(loc), "paths": count} for loc, count in sorted(labs.items())],
            "actual_original_root_ena_users": [list(user) for user in original_users], "actual_existing_clone_ena_users": [list(user) for user in copied_users],
            "observed_original_and_clone_union_users": 111, "pre_step111_user_snapshot_serialized_or_independently_proved": False,
            "fresh_live111_user_qualification_required_if_existing_stage_is_replaced": True,
            "actual_full_pin_states_verified_separately": True, "old_baseline_unexported_pin_states_proved": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--generator-sha256", required=True)
    parser.add_argument("--scope-sha256", required=True)
    parser.add_argument("--parent-proof-sha256", required=True)
    args = parser.parse_args()
    require(not GUIDE.exists() and not MANIFEST.exists(), "exclusive diagnostic outputs already exist")
    audit = Audit()
    authenticate(audit, args.generator_sha256, args.scope_sha256, args.parent_proof_sha256)
    report = read(REPORT)
    selected = select(report)
    full, baseline = Native(FULL), Native(BASELINE)
    result = validate(selected, full, baseline, report)
    guide = {"critical_paths": [path for _, path in selected]}
    require(set(guide) == {"critical_paths"} and all(path == report["critical_paths"][index] for (index, _), path in zip(selected, guide["critical_paths"])),
            "guide modified an actual parent path object")
    audit.finish()
    text = json.dumps(guide, indent=2, sort_keys=True, allow_nan=False) + "\n"
    with GUIDE.open("x") as stream:
        stream.write(text)
    require(read(GUIDE) == guide, "serialized guide changed exact path membership")
    manifest = {"schema": 1, "kind": "authenticated exact original ready-path subset for diagnostic search provenance",
                "completed": True, "parent_proof_sha256": PROOF_SHA, "source_report_sha256": REPORT_SHA,
                "accepted_full_native_sha256": FULL_SHA, "old_driver_disabled_baseline_native_sha256": BASELINE_SHA,
                "generator_sha256": args.generator_sha256, "scope_sha256": args.scope_sha256,
                "guide_path": str(GUIDE), "guide_sha256": sha(GUIDE), "guide_top_level_fields": ["critical_paths"],
                "paths": 109, "reported_window_violations": 91, "labs": 21,
                "exact_path_objects_and_original_source_order_preserved": True, "postdriver_private_path_references_exported": False,
                "clock_terms_locations_nets_sources_windows_or_segment_delays_modified": False,
                "native_original_clock_and_routing_edges_checked_in_both_serialized_frames": True,
                "pre_step_snapshot_or_physical_equivalence_proved": False, "new_modeled_sta_or_lut_composition_equivalence_proved": False,
                "new_local_or_driver_candidate_qualified": False, "routed_gain_accepted": False, "hardware_tested": False,
                "old_generators_authenticators_compilers_or_tests_executed": False,
                "artifact_sha256": audit.artifacts, "historical_execution_file_sha256_rehashed": audit.runtime,
                "current_python_executable": str(Path(sys.executable).resolve()),
                "diagnostic_python_loaded_library_execution_trace_claimed": False, **result}
    audit.finish()
    with MANIFEST.open("x") as stream:
        stream.write(json.dumps(manifest, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(read(MANIFEST) == manifest and sha(GUIDE) == manifest["guide_sha256"], "new diagnostic output changed")
    audit.finish()
    print(json.dumps({"completed": True, "guide_sha256": manifest["guide_sha256"], "manifest_sha256": sha(MANIFEST),
                      "paths": 109, "reported_window_violations": 91, "labs": 21, "routed_gain_accepted": False}, indent=2))


if __name__ == "__main__":
    main()
