# RAM-test reduction experiment: consumer-order fix validated

2026-09-29. Frozen BUILD_ID `7168b508ab424b70f1c0f87b2035d821`,
synth SHA256 `61ee68c657e49364425dd4ba4880a679e0759992f2750e284e256d1e4139de28`,
GPU1, seed2, timingweight10, critexp2, enable-replication budget4.

| Route | Memory MHz | Pixel MHz | Capture MHz |
| --- | ---: | ---: | ---: |
| Merged diagnostic baseline | 106.157112 | 94.500099 | 347.793488 |
| Pre-load balanced scratch | 108.944328 | 95.229019 | 378.582397 |
| Original in-process candidate (rejected) | 100.030014 | 95.029938 | 312.963898 |
| Slot-preserving in-process compiler | 108.944328 | 95.229019 | 378.582397 |

The original rewrite disconnected and reconnected cone inputs sequentially.
Eight of its 19 selected input consumers moved from slot2 to slot4 because a
new connection was added before the old consumer was removed. HeAP iterates
these indexed consumer lists. A pre-load rewrite did not move those slots.
Preserving each original slot and replacing its PortRef in place recovers all
71 placement metrics and all213 GPU iteration metrics; all20115 common routed
cells have identical BEL attributes, and the compressed RBF is byte-identical
to the successful pre-load control. Numeric input-ID and port-order controls
alone did not change the packed scratch circuit. This identifies the cause of
this candidate regression; it does not explain the entire Quartus/OSS gap.

The final audited route finished in716.51s with no final reported hold
violations. All three clock domains improve over the frozen baseline, memory
by2.787216MHz (2.625558%). The complete available compiler CTest suite passes
3/3 targets in250.83s. A focused consumer-slot regression failed before the
fix and passes afterward, including exhaustive normal/mixed-polarity Boolean
checks. Independent review found root-output protection, undefined/malformed
LUT tables and unconstrained clock consumers needed guards; all were fixed
with real failing/passing tests and the final review has no findings.

Generic compiler commit `b95ac420` on base `24f9a1db` adds the opt-in
`--balance-reduction-root CELL` pass. It recognizes a four-LUT conjunction of
16 distinct literals, validates truth tables/pin polarities, excludes protected,
placed, special and shared intermediate nets, and retains cells/root output.
Source snapshot and hashes: `nextpnr-slots-fixed-source.tar.gz` and
`slot-fixed-source-hashes.json`. The tested binary was built from these source
bytes before the commit; its base-plus-binary-hash identity is in the audited
`route-slots-final/run.json`. The archived original rejection is retained in
`experiment-summary-before-slot-fix.md`.

Reproduce the verified comparison with `python3 compare_slot_routes.py` from
this directory; the generated `slot-route-comparison.json` verifies input,
source and artifact hashes and records all-clock results.

Quartus saved-fit hint for the next physical experiment: exact HPS
`rd_data_0[48]`→`port0.returned_data[48]` has data delay3.192ns and setup
slack+3.254ns at130MHz; its FF is X25/Y56 and HPS output HIO buffer X51/Y62.
The OSS candidate's critical path ends at the same RTL bit at X25/Y23;
read-data routing costs7.704ns and complete memory path9.179ns. Query script,
log and detailed path reports are adjacent. This saved Quartus fit has
BUILD_ID52991ce2 rather than frozen7168b508, so use it as a locality hint,
not equivalent physical-route timing-model calibration. TimeQuest completed
with0 errors and2 existing unmatched secondary-clock SDC warnings; the queried
memory clock is constrained at7.692ns.

FES tracked sources, RTL, compiler locks, recipes and shared contracts remain
unchanged at7ce99269. No hardware programming or hardware acceptance. This is
a validated opt-in compiler candidate, not selection by the existing FES
recipe.130MHz and recovery of the historical116.918MHz remain unresolved.
Next: a bounded local-placement experiment for HPS read-data capture registers,
using actual physical output endpoints and setup/hold/control-set guards.
