import sys,os,subprocess,json,hashlib,time,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
runner=Path('/home/deano/harnesses/worktrees/fes/silver-delta/out/dev/pcxt-board/sources/misteross')
sys.path[:0]=[str(runner),str(runner/'scripts')]
from fes_build_common import _run_command
binary=root/'nextpnr-mistral'
shutil.copy2('/tmp/pcxt-routed-waveform-20261022/inputs/nextpnr-mistral',binary)
src=root/'source/sources/misteross'
remaining=1474.3926381732292
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label in ['baseline','candidate']:
 out=root/label
 while label+' synthesized' not in Path('/tmp/pcxt-commit-synth.log').read_text():
  time.sleep(2)
 assert (out/'synth.json').exists() and not (out/'receipt.json').exists()
 cmd=[str(binary),'--device','5CSEBA6U23I7','--json','synth.json','--qsf',str(src/'cores/fes-ramtest/constraints.qsf'),'--sdc',str(src/'boards/de10nano/clocks.sdc'),'--seed','1','--freq','100','--router','gpu','--placer-heap-timingweight','2000','--placer-heap-critexp','5','--rbf','diagnostic.rbf','--compress-rbf','--write','routed.json','--report','timing.json','--detailed-timing-report','--timing-report-paths','1024','--routed-endpoints','endpoints.json']
 env=dict(os.environ,FES_GPU_LEASE_OWNER='pcxt-agent',GPU_LEASE_MAX_PER_OWNER='2',NEXTPNR_REQUIRE_GPU='1')
 receipt=dict(label=label,argv=cmd,binary_sha256=sha(binary),synth_sha256=sha(out/'synth.json'),remaining_before=remaining,timeout_active_seconds=450,environment={k:v for k,v in env.items() if k.startswith(('NEXTPNR_','FES_GPU_','GPU_LEASE_'))},hardware=False)
 (out/'invocation.json').write_text(json.dumps(receipt,indent=2)+'\n')
 start=time.monotonic()
 try:
  with (out/'nextpnr.log').open('w') as log:
   result=_run_command(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450,gpu_label='pcxt-commit-'+label)
  receipt['returncode']=result.returncode
 except Exception as e:receipt['exception']=repr(e)
 receipt['elapsed_wall_seconds']=time.monotonic()-start
 remaining-=receipt['elapsed_wall_seconds'];receipt['remaining_after']=remaining
 receipt['artifacts']={p.name:sha(p) for p in out.iterdir() if p.is_file()}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
