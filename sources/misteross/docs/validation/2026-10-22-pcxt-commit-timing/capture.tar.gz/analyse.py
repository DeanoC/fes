import json,collections
from pathlib import Path
root=Path(__file__).resolve().parent
result={}
for label in ['baseline','candidate']:
 out=root/label
 if not (out/'timing.json').exists():continue
 t=json.loads((out/'timing.json').read_text())
 paths=[]
 for p in t['critical_paths']:
  delays=collections.defaultdict(float)
  for a in p['path']:delays[a['type']]+=a['delay']
  paths.append(dict(launch=p['path'][0]['from'],capture=p['path'][-1]['to'],clock_from=p['from'],clock_to=p['to'],slack_ns=p['max_delay']-sum(delays.values()),delay_by_type_ns=dict(delays)))
 paths.sort(key=lambda p:p['slack_ns'])
 result[label]=dict(fmax=t['fmax'],timing_summary=t.get('timing_summary'),worst=paths[:5],worst_vram=next((p for p in paths if '.vram.' in p['capture']['cell']),None),receipt=json.loads((out/'receipt.json').read_text()))
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
