import json,functools
from pathlib import Path
root=Path(__file__).resolve().parent
result={}
for label in ['baseline','candidate']:
 f=root/label/'synth.json'
 if not f.exists():continue
 m=json.loads(f.read_text())['modules']['top'];drivers={}
 for n,c in m['cells'].items():
  for p,bits in c['connections'].items():
   if c['port_directions'][p]=='output':
    for bit in bits:drivers[bit]=(n,c)
 @functools.lru_cache(None)
 def cone(bit):
  if bit not in drivers:return (0,[])
  n,c=drivers[bit]
  if not c['type'].startswith(('MISTRAL_ALUT','MISTRAL_NOT')):return (0,[n])
  ins=[b for p,bits in c['connections'].items() if c['port_directions'][p]=='input' for b in bits]
  d,path=max((cone(b) for b in ins),default=(0,[]))
  return (d+1,path+[n])
 result[label]={n:cone(c['connections']['A1EN'][0]) for n,c in m['cells'].items() if c['type']=='MISTRAL_M10K' and '.cga.' in n and 'vram' in n}
(root/'cones.json').write_text(json.dumps(result,indent=2)+'\n')
for label,items in result.items():
 n,(d,path)=max(items.items(),key=lambda x:x[1][0]);print(label,d,n);print('\n'.join(path))
