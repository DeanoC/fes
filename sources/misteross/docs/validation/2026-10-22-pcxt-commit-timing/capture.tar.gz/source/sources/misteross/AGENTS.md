# misteross working policy

Development lives only in the [FES repository](https://github.com/DeanoC/fes),
under `sources/misteross/`. The former standalone repository is archived.
Use a FES worktree and open PRs against FES; do not clone or update the old repository.

## Start here

There are two jobs. Read the one you are doing before editing.

- OSS place-and-route testing (experiments, primitive proofs, freeze-scaffold):
  `docs/oss-pnr.md`.
- Core update or new core (described packages and the splash bitstream):
  `docs/cores.md`.

nextpnr routing on HIP, CUDA and CPU gives bit-identical route outcomes. HIP and CUDA
timing and route evidence are interchangeable: references, pins, seed results and
replays from either backend remain valid on the other. This is route-result
equivalence only; production builds, promotion and seal evidence still require an
authenticated live HIP or CUDA backend as producer validators require. Registered
producers reject CPU-reference fallback (`NEXTPNR_REQUIRE_GPU=1`), so CPU replays
can inform experiments only. HIP and CUDA builds keep distinct `BUILD_ID`s and
artifact identities because backend is part of functional execution identity, even
though their timing and route evidence is interchangeable. Among current core
package producers, Apple II, Atari ST, C64, Coleco socket-v2, SG-1000, SMS,
Spectrum and ZX81 accept `--gpu-router {HIP,CUDA}`. Catch, Menu, Pong, RAM Tester
and RISC-V accept only `--gpu-device`; their authenticated toolchain determines
the backend. On a CUDA host, select CUDA and its matching toolchain for a
router-selectable producer; a device-only producer can use CUDA only with an
authenticated CUDA-built toolchain. `gpu-run` leases a device, not a backend;
record the backend in the build record. Never require a separate HIP run or
discount CUDA evidence. Never set `GPU_LEASE_IDS` per job (it is a box inventory
override).

Apple II evidence note: the producer's statement that a CUDA seal is not HIP closure refers to backend-specific `BUILD_ID` and artifact identity, not route outcomes. The CUDA result was exploratory as seal evidence only and is not a recorded seal; HIP and CUDA route outcomes remain interchangeable. See the Apple II row in `docs/core-status.md` for the current seal boundary.

Then read `docs/architecture.md` for the build contract you are about to
change. It is not a task list. Per-experiment results are
`docs/oss-experiments.md`. Files under `docs/validation/` are dated records.
The user's current request defines the scope. Do not follow the other job's
guide, and do not treat a gap ladder as the schedule for this tree.

## Clarity is part of correctness

1. A fresh clone must state what builds now, the output RBF paths, the current
   experiments, and the boundary with FogCast.
2. Documentation describes present code in present tense. Proposed or
   experimental work is labelled as such.
3. A commit changing a build lane or artifact path updates the README or
   architecture document in the same commit.
4. Git history is the archive. Delete superseded code and documents instead of
   retaining duplicate, deprecated, or compatibility implementations.
5. `docs/architecture.md` is the one canonical current architecture
   description. `docs/oss-pnr.md` and `docs/cores.md` are the operator guides
   for the two jobs. Do not create a third architecture, competing roadmap,
   status report, evidence handoff, or task-plan archive.
6. Extend a working build lane with the smallest useful change.
7. If documentation, scripts, produced artifacts, and hardware observations
   disagree, resolve the discrepancy before unrelated development continues.
8. Do not add deployment coordinators, supervisors, ownership databases,
   attestation, rollback systems, security frameworks, failover, or recovery
   machinery without a demonstrated current need and explicit user approval.
9. Tests must be proportional and exercise the real build or simulation path.
10. Commits are coherent and describe the working result, not a chain of
    status or evidence documents.

## Source of truth

FES `sources/misteross` is the source of truth. Do **not** open day-to-day
PRs against standalone `https://github.com/DeanoC/misteross`. That URL in
`config/source-imports.toml` is historical import provenance only.

## Repository boundary

- This repository ends at the RBF artifact boundary. FogCast owns host
  selection, network transfer, target lifecycle, and UI-driven launch.
- `sim` uses Verilator.
- `oss` uses the pinned Yosys/nextpnr-mistral/Mistral flow and must not depend
  on Quartus.
- `oracle` uses only an explicitly configured Quartus 17.0.2 installation.
- No build command programs hardware automatically. FogCast
  `POST /api/v1/session/development-rbf` is the designated native-kit load
  path. `make program` is a separate JTAG maintenance diagnostic.

## Disposable hardware

The designated MiSTer Pi is disposable local hobby-development hardware.
SSH, `root`/`1`, changing host keys, rebooting, reflashing, and rebuilding are
normal. Keep private target addresses and credentials out of tracked files.

## Working practices

- Preserve unrelated user changes and upstream licensing.
- Use a branch or worktree for substantial changes.
- Prefer `rg` for source discovery.
- Run the affected unit tests, build or simulate the affected experiment, and
  run `git diff --check`.
- Commit, push, and open PRs as needed for the requested work without additional
  approval. Only merging a PR requires review by Deano or by another agent or
  model reviewer (for example a Codex review or a domain-reviewer agent). Agents
  never merge on their own authority.
