// SPDX-License-Identifier: GPL-2.0-or-later
// Dual-port RAM. Simulation infers unregistered reads; Quartus uses altsyncram.

module coleco_dpram #(
    parameter DATAWIDTH = 8,
    parameter ADDRWIDTH = 8,
    parameter NUMWORDS = 1 << ADDRWIDTH,
    parameter MEM_INIT_FILE = ""
) (
    input  wire                  clock,
    input  wire [ADDRWIDTH-1:0]  address_a,
    input  wire [DATAWIDTH-1:0]  data_a,
    input  wire                  wren_a,
    output wire [DATAWIDTH-1:0]  q_a,
    input  wire [ADDRWIDTH-1:0]  address_b,
    input  wire [DATAWIDTH-1:0]  data_b,
    input  wire                  wren_b,
    output wire [DATAWIDTH-1:0]  q_b
);
`ifdef QUARTUS
    altsyncram altsyncram_component (
        .address_a(address_a),
        .address_b(address_b),
        .clock0(clock),
        .data_a(data_a),
        .data_b(data_b),
        .wren_a(wren_a),
        .wren_b(wren_b),
        .q_a(q_a),
        .q_b(q_b),
        .aclr0(1'b0),
        .aclr1(1'b0),
        .addressstall_a(1'b0),
        .addressstall_b(1'b0),
        .byteena_a(1'b1),
        .byteena_b(1'b1),
        .clock1(1'b1),
        .clocken0(1'b1),
        .clocken1(1'b1),
        .clocken2(1'b1),
        .clocken3(1'b1),
        .eccstatus(),
        .rden_a(1'b1),
        .rden_b(1'b1)
    );
    defparam
        altsyncram_component.wrcontrol_wraddress_reg_b = "CLOCK0",
        altsyncram_component.address_reg_b = "CLOCK0",
        altsyncram_component.indata_reg_b = "CLOCK0",
        altsyncram_component.numwords_a = NUMWORDS,
        altsyncram_component.numwords_b = NUMWORDS,
        altsyncram_component.widthad_a = ADDRWIDTH,
        altsyncram_component.widthad_b = ADDRWIDTH,
        altsyncram_component.width_a = DATAWIDTH,
        altsyncram_component.width_b = DATAWIDTH,
        altsyncram_component.width_byteena_a = 1,
        altsyncram_component.width_byteena_b = 1,
        altsyncram_component.init_file = MEM_INIT_FILE,
        altsyncram_component.clock_enable_input_a = "BYPASS",
        altsyncram_component.clock_enable_input_b = "BYPASS",
        altsyncram_component.clock_enable_output_a = "BYPASS",
        altsyncram_component.clock_enable_output_b = "BYPASS",
        altsyncram_component.intended_device_family = "Cyclone V",
        altsyncram_component.lpm_type = "altsyncram",
        altsyncram_component.ram_block_type = "M10K",
        altsyncram_component.operation_mode = "BIDIR_DUAL_PORT",
        altsyncram_component.outdata_aclr_a = "NONE",
        altsyncram_component.outdata_aclr_b = "NONE",
        altsyncram_component.outdata_reg_a = "UNREGISTERED",
        altsyncram_component.outdata_reg_b = "UNREGISTERED",
        altsyncram_component.power_up_uninitialized = "FALSE",
        altsyncram_component.read_during_write_mode_mixed_ports = "DONT_CARE",
        altsyncram_component.read_during_write_mode_port_a = "NEW_DATA_NO_NBE_READ",
        altsyncram_component.read_during_write_mode_port_b = "NEW_DATA_NO_NBE_READ";
`else
`ifdef FES_COLECO_OSS
    // Registered true dual-port M10K. Combo-read 16 KB tables explode ABC.
    (* ram_style = "m10k_tdp" *) reg [DATAWIDTH-1:0] ram [0:NUMWORDS-1];
    reg [DATAWIDTH-1:0] q_a_r;
    reg [DATAWIDTH-1:0] q_b_r;

    initial begin
        if (MEM_INIT_FILE != "")
            $readmemh(MEM_INIT_FILE, ram);
    end

    always @(posedge clock) begin
        if (wren_a) begin
            ram[address_a] <= data_a;
            q_a_r <= data_a;
        end else
            q_a_r <= ram[address_a];
    end

    always @(posedge clock) begin
        if (wren_b) begin
            ram[address_b] <= data_b;
            q_b_r <= data_b;
        end else
            q_b_r <= ram[address_b];
    end

    assign q_a = q_a_r;
    assign q_b = q_b_r;
`else
    (* ramstyle = "M10K" *) reg [DATAWIDTH-1:0] ram [0:NUMWORDS-1];

    initial begin
        if (MEM_INIT_FILE != "")
            $readmemh(MEM_INIT_FILE, ram);
    end

    always @(posedge clock) begin
        if (wren_a)
            ram[address_a] <= data_a;
        if (wren_b)
            ram[address_b] <= data_b;
    end

    assign q_a = ram[address_a];
    assign q_b = ram[address_b];
`endif
`endif
endmodule
