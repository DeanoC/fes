// SPDX-License-Identifier: GPL-3.0-or-later
// Boot stock EmuTOS through physical SDRAM commands while the native line
// cache scans that same RAM with an independent 74.25 MHz pixel clock.
#include "st_audio_capture.hpp"
#include "st_keyboard_stimulus.hpp"
#include "st_rendered_capture.hpp"
#include "st_ram_write_trace.hpp"
#include "Vst_boot_memory_sim_top.h"
#include "verilated.h"
#ifdef ST_RAM_BUS_PROBE
#include "Vst_boot_memory_sim_top___024root.h"
#endif
#include <array>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <set>
#include <string>
#include <vector>

static void require(bool value, const char *what, uint64_t cycle = 0) {
    if (!value) {
        std::cerr << "FAIL: " << what << " at system cycle " << cycle << '\n';
        std::exit(1);
    }
}

// Same digital SDRAM command checks as memory_tb.cpp: packed addresses, CAS2,
// single-word bursts, auto-precharge, byte masks, initialization and refresh.
// ISSI IS42S16320D conservative whole-cycle limits at 52.224 MHz; this model
// does not establish analog pad setup/hold, electrical behavior or routing.
// https://www.issi.com/WW/pdf/42-45R-S_86400D-16320D-32160D.pdf
class Sdram {
public:
    std::vector<uint16_t> words = std::vector<uint16_t>(0xa6800, 0);
    uint64_t cycle = 0, reads = 0, writes = 0, refreshes = 0, mode_sets = 0;
    uint64_t last_refresh = 0, read_due = 0, max_refresh_gap = 0;
    uint16_t pending_read = 0;
    std::array<unsigned, 4> row{};
    std::array<bool, 4> open{};
    std::array<uint64_t, 4> activated{}, available{};
    bool precharged = false, initialized = false;
    unsigned write_address = UINT32_MAX;
    uint16_t write_data = 0;
    uint8_t write_lanes = 0;

    uint16_t tick(const Vst_boot_memory_sim_top &dut) {
        ++cycle;
        write_address = UINT32_MAX;
        const uint16_t sample = read_due == cycle ? pending_read : 0xf13d;
        if (!dut.sdram_cke || dut.sdram_ncs) return sample;
        const unsigned command = (dut.sdram_nras << 2) | (dut.sdram_ncas << 1) | dut.sdram_nwe;
        const unsigned bank = dut.sdram_ba;
        const unsigned address = ((dut.sdram_a & 0x3fc) << 15) |
            (row[bank] << 4) | (bank << 2) | (dut.sdram_a & 3);
        if (command != 7)
            require(cycle - last_refresh >= 5 || refreshes == 0, "SDRAM tRFC violated", cycle);
        switch (command) {
        case 3:
            require(initialized, "ACTIVATE before mode initialization", cycle);
            require(!open[bank] && cycle >= available[bank], "ACTIVATE before bank recovery", cycle);
            open[bank] = true;
            row[bank] = dut.sdram_a;
            activated[bank] = cycle;
            break;
        case 4:
        case 5:
            require(open[bank], "column command without open row", cycle);
            require(cycle - activated[bank] >= 2, "SDRAM tRCD violated", cycle);
            require(address < words.size(), "physical memory address escaped RAM/media bounds", cycle);
            require(dut.sdram_a & 0x400, "column command lacks auto-precharge", cycle);
            open[bank] = false;
            available[bank] = cycle + (command == 4 ? 2 : 3);
            if (command == 4) {
                require(dut.dq_oe, "WRITE without driven data", cycle);
                if (!(dut.sdram_a & 0x800)) words[address] = (words[address] & 0xff00) | (dut.dq_out & 0xff);
                if (!(dut.sdram_a & 0x1000)) words[address] = (words[address] & 0xff) | (dut.dq_out & 0xff00);
                ++writes;
                write_address = address * 2;
                write_data = dut.dq_out;
                write_lanes = ((dut.sdram_a & 0x1000) ? 0 : 2) | ((dut.sdram_a & 0x800) ? 0 : 1);
            } else {
                require(!dut.dq_oe, "READ has output data contention", cycle);
                require(!(dut.sdram_a & 0x1800), "READ unexpectedly masked", cycle);
                read_due = cycle + 2;
                pending_read = words[address];
                ++reads;
            }
            break;
        case 2:
            require(dut.sdram_a & 0x400, "PRECHARGE is not all-bank", cycle);
            require(cycle >= 5223, "SDRAM initialization power delay too short", cycle);
            for (unsigned b = 0; b < 4; ++b) {
                require(!open[b] || cycle - activated[b] >= 2, "SDRAM tRAS violated", cycle);
                require(cycle >= available[b], "PRECHARGE before write/read recovery", cycle);
                open[b] = false;
                available[b] = cycle + 1;
            }
            precharged = true;
            break;
        case 1:
            require(precharged, "refresh before initial precharge", cycle);
            for (unsigned b = 0; b < 4; ++b)
                require(!open[b] && cycle >= available[b], "refresh with active/recovering bank", cycle);
            if (initialized) {
                const auto gap = cycle - last_refresh;
                if (gap > max_refresh_gap) max_refresh_gap = gap;
                require(gap <= 408, "private refresh interval exceeds 7.8 us", cycle);
            }
            last_refresh = cycle;
            ++refreshes;
            break;
        case 0:
            require(refreshes >= 2, "mode set before two initialization refreshes", cycle);
            require(dut.sdram_a == 0x20, "SDRAM requires burst one, CAS two", cycle);
            initialized = true;
            ++mode_sets;
            break;
        case 7: break;
        default: require(false, "unexpected SDRAM command", cycle);
        }
        return sample;
    }
};

struct Pending {
    bool active = false, complete = false;
    unsigned wait = 0;
    uint32_t address = 0;
    uint16_t data = 0;
    uint8_t lanes = 0;
    bool write = false;
};

class Boot {
    static constexpr uint64_t SystemHz = 52224000;
    static constexpr unsigned Width = 1650, Height = 750, Frame = Width * Height;
    static constexpr uint32_t DE = 1u << 24, HS = 1u << 25, VS = 1u << 26;
    static constexpr uint32_t CE = 1u << 27, SOF = 1u << 28, EOL = 1u << 29, HOLD = 1u << 30;
    Vst_boot_memory_sim_top dut;
    Sdram sdram;
    StAudioCapture audio;
    StRamWriteTrace ram_write_trace;
    st_keyboard_stimulus::Stimulus keys;
    std::vector<uint8_t> rom;
    std::vector<uint8_t> picture = std::vector<uint8_t>(1280 * 720 * 3);
    std::vector<uint8_t> complete_picture;
    Pending rom_transfer, cpu_transfer, video_transfer;
    uint64_t next_sys = 0, next_pixel = 9871, system_cycles = 0, pixel_cycles = 0, boot_start = 0;
    uint64_t faults = 0, mfp = 0, vbl = 0, cpu_reads = 0, cpu_writes = 0, video_reads = 0;
    uint64_t concurrent_cycles = 0, complete_frames = 0;
#ifdef ST_RAM_BUS_PROBE
    uint64_t cpu_ticks = 0, tas_reads = 0, tas_writes = 0;
    std::vector<std::pair<bool, uint64_t>> ram_bus_starts;
    std::vector<uint64_t> movem_word_ticks;
    std::vector<unsigned> movem_word_lines;
    uint64_t movem_video_reads = 0;
    std::vector<uint64_t> raster_write_ticks;
    std::vector<unsigned> raster_write_phases, palette_read_phases;
    std::vector<uint64_t> palette_read_ticks;
#endif
    unsigned max_cpu_latency = 0, max_video_latency = 0;
    bool last_fault = false, last_ack = false, picture_started = false;
    uint32_t previous_request = 0;
    unsigned position = 0, previous_position = 0;
    bool demo_mode = false;
    unsigned trace_start = 6, trace_end = 7;
    uint64_t native_epoch = 0, palette_writes = 0, frame_palette_writes = 0;
    unsigned observed_frames = 0, frame_cpu_max = 0, frame_video_max = 0, last_sync = 0;
    uint64_t frame_video_reads = 0;
    std::vector<uint8_t> native_picture = std::vector<uint8_t>(320*247*3);
    std::ofstream raster_trace, logo_trace, ym_trace, rendered_trace, ram_snapshot_trace;
    std::set<uint64_t> saved_ram_cycles;
    uint32_t rendered_sequence = 0;
    unsigned rendered_height = 200;
    bool rendered_valid = false, rendered_pal = true, rendered_tracing = false;
    uint64_t rendered_start_cycle = 0;
    std::set<uint32_t> saved_rendered_sequences;
    std::set<uint64_t> saved_logo_hashes;
    std::string trace_prefix;
    bool tracing() const { return system_cycles >= boot_start + trace_start*SystemHz &&
                                 system_cycles < boot_start + trace_end*SystemHz; }

    uint16_t word(unsigned address) const {
        require(!(address & 1) && address < 524288, "RAM observation outside 512 KiB", system_cycles);
        return sdram.words[address / 2];
    }
    uint32_t longword(unsigned address) const {
        return (uint32_t(word(address)) << 16) | word(address + 2);
    }

    void rom_before_edge() {
        if (dut.reset_sys || !dut.rom_req) {
            require(dut.reset_sys || !rom_transfer.active || rom_transfer.complete,
                    "ROM request abandoned before ready", system_cycles);
            rom_transfer = {};
            dut.rom_ready = 0;
            return;
        }
        const unsigned address = dut.rom_addr * 2;
        require(address + 1 < rom.size(), "ROM request escaped exact 192 KiB", system_cycles);
        if (!rom_transfer.active) {
            rom_transfer.active = true;
            rom_transfer.address = address;
            rom_transfer.wait = 2 + (address % 3);
        }
        require(rom_transfer.address == address, "ROM address changed before ready", system_cycles);
        dut.rom_rdata = (uint16_t(rom[address]) << 8) | rom[address + 1];
        if (rom_transfer.wait) {
            --rom_transfer.wait;
            dut.rom_ready = 0;
        } else {
            dut.rom_ready = 1;
            rom_transfer.complete = true;
        }
    }

    void track_before(Pending& pending, bool req, unsigned address, uint16_t data,
                      uint8_t lanes, bool writing, const char *message) {
        if (dut.reset_sys || !req) {
            require(dut.reset_sys || !pending.active || pending.complete,
                    "memory client abandoned request before ready", system_cycles);
            pending = {};
        } else if (!pending.active) {
            pending.active = true;
            pending.address = address;
            pending.data = data;
            pending.lanes = lanes;
            pending.write = writing;
        } else {
            require(pending.address == address && pending.data == data &&
                    pending.lanes == lanes && pending.write == writing, message, system_cycles);
        }
        if (req) ++pending.wait;
    }

    void system_edge() {
        keys.apply(dut.keyboard,system_cycles,boot_start,demo_mode && !dut.reset_sys);
        if(!dut.reset_sys && dut.audio_valid) audio.sample(dut.audio_pcm,system_cycles-boot_start);
#ifdef ST_RAM_BUS_PROBE
        if (dut.reset_sys) require(!dut.debug_cpu_tick, "CPU phase-2 suppressed during reset", system_cycles);
        if (!dut.reset_sys) {
            const uint64_t elapsed = system_cycles - boot_start;
            const bool expected_tick = (elapsed + 1) * 8021247 / SystemHz != elapsed * 8021247 / SystemHz;
            require(bool(dut.debug_cpu_tick) == expected_tick,
                    "PAL CPU phase-2 rate and reset origin", system_cycles);
            if (dut.debug_cpu_tick) ++cpu_ticks;
        }
        if (!dut.reset_sys && dut.cpu_req && !cpu_transfer.active && dut.cpu_addr == 0x300)
            ram_bus_starts.emplace_back(bool(dut.cpu_write), cpu_ticks);
#endif
#ifdef ST_RAM_BUS_PROBE
        if (!dut.reset_sys && dut.cpu_req && !cpu_transfer.active && dut.cpu_addr == 0x310) {
            if (dut.cpu_write) ++tas_writes; else ++tas_reads;
        }
#endif
#ifdef ST_RAM_BUS_PROBE
        if (!dut.reset_sys && dut.cpu_req && !cpu_transfer.active && dut.cpu_write &&
            dut.cpu_addr >= 0x37b00 && dut.cpu_addr < 0x38000) {
            require(dut.cpu_byte_enable == 3 && dut.cpu_wdata == 0x1234,
                    "MOVEM word payload/lanes", system_cycles);
        }
        // S6/PHI2 is the CPU's completed word transfer. Request-start gaps
        // also include the first word's legitimate two-cycle RAM alignment.
        auto *root = dut.rootp;
        if (!dut.reset_sys && dut.debug_cpu_tick &&
            root->st_boot_memory_sim_top__DOT__system__DOT__machine__DOT__cpu__DOT__cpu__DOT__busControl__DOT__busPhase == 5 &&
            root->st_boot_memory_sim_top__DOT__system__DOT__machine__DOT__target == 1 &&
            root->st_boot_memory_sim_top__DOT__system__DOT__machine__DOT__writing &&
            root->st_boot_memory_sim_top__DOT__system__DOT__machine__DOT__address >= 0x6f600 &&
            root->st_boot_memory_sim_top__DOT__system__DOT__machine__DOT__address < 0x70000) {
            movem_word_ticks.push_back(cpu_ticks);
            movem_word_lines.push_back(dut.debug_native_line);
        }
#endif
        rom_before_edge();
        track_before(cpu_transfer, dut.cpu_req, dut.cpu_addr, dut.cpu_wdata,
                     dut.cpu_byte_enable, dut.cpu_write, "CPU SDRAM request changed before completion");
        track_before(video_transfer, dut.video_req, dut.video_addr, 0, 3, false,
                     "video SDRAM request changed before completion");
        dut.dq_sample = sdram.tick(dut);
        if (ram_write_trace.enabled() && demo_mode && !dut.reset_sys && tracing() &&
            sdram.write_address != UINT32_MAX)
            ram_write_trace.observe(system_cycles-boot_start,sdram.cycle,sdram.write_address,
                                    sdram.write_data,sdram.write_lanes,dut.debug_pc);
        dut.eval();
        const unsigned line = dut.debug_native_line, phase = dut.debug_horizontal_phase;
        const bool native_vblank = !dut.reset_sys && dut.vblank;
        const bool palette_write = !dut.reset_sys && dut.debug_palette_write;
        if (demo_mode && dut.debug_ym_write)
            ym_trace << "{\"system_cycle\":" << system_cycles-boot_start
                << ",\"register\":" << unsigned(dut.debug_ym_register)
                << ",\"value\":" << unsigned(dut.debug_ym_data)
                << ",\"pc\":" << dut.debug_pc << "}\n";
#ifdef ST_RAM_BUS_PROBE
        if (!dut.reset_sys && dut.debug_palette_read && dut.debug_palette_address == 0xff8240) {
            palette_read_ticks.push_back(cpu_ticks);
            palette_read_phases.push_back(phase);
        }
        if (palette_write && dut.debug_palette_address == 0xff8240) {
            raster_write_ticks.push_back(cpu_ticks);
            raster_write_phases.push_back(phase);
        }
#endif
        if (demo_mode && palette_write) {
            ++palette_writes; ++frame_palette_writes;
            if (tracing()) raster_trace << "{\"kind\":\"palette_write\",\"cycle\":" << system_cycles
                << ",\"frame\":" << native_epoch << ",\"line\":" << line << ",\"horizontal_phase\":" << phase
                << ",\"address\":" << dut.debug_palette_address << ",\"data\":" << dut.debug_palette_data
                << ",\"color\":" << dut.debug_palette_color
                << ",\"lanes\":" << unsigned(dut.debug_palette_lanes) << "}\n";
        }
        if (demo_mode && dut.capture_pixel) {
            require(dut.capture_x < 320 && dut.capture_y < 247, "native capture coordinate bounds", system_cycles);
            const unsigned offset = (dut.capture_y*320 + dut.capture_x)*3, rgb = dut.capture_rgb;
            for (unsigned c=0;c<3;++c) {
                const unsigned v=(rgb >> (6-c*3)) & 7;
                native_picture[offset+c]=(v<<5)|(v<<2)|(v>>1);
            }
        }
        dut.clk_sys = 1;
        dut.eval();
        ++system_cycles;
        if (demo_mode && tracing() && dut.sync_mode != last_sync) {
            raster_trace << "{\"kind\":\"sync\",\"cycle\":" << system_cycles-1
                << ",\"frame\":" << native_epoch << ",\"line\":" << line << ",\"horizontal_phase\":" << phase
                << ",\"sync_mode\":" << unsigned(dut.sync_mode) << "}\n";
        }
        last_sync=dut.sync_mode;
        if (dut.cpu_ready) {
            require(cpu_transfer.active && !cpu_transfer.complete,
                    "CPU SDRAM completion duplicated or unrequested", system_cycles);
            cpu_transfer.complete = true;
            if (cpu_transfer.write) ++cpu_writes; else ++cpu_reads;
            if (cpu_transfer.wait > frame_cpu_max) frame_cpu_max = cpu_transfer.wait;
            if (cpu_transfer.wait > max_cpu_latency) max_cpu_latency = cpu_transfer.wait;
        }
        if (dut.video_ready) {
            require(video_transfer.active && !video_transfer.complete,
                    "video SDRAM completion duplicated or unrequested", system_cycles);
            video_transfer.complete = true;
            ++video_reads; ++frame_video_reads;
#ifdef ST_RAM_BUS_PROBE
            if (!movem_word_ticks.empty() && movem_word_ticks.size() < 1280) ++movem_video_reads;
#endif
            if (video_transfer.wait > frame_video_max) frame_video_max = video_transfer.wait;
            if (video_transfer.wait > max_video_latency) max_video_latency = video_transfer.wait;
        }
        if (demo_mode && dut.native_frames != observed_frames) {
            observed_frames = dut.native_frames;
            const unsigned height=dut.capture_height;
            require(height==200||height==226||height==247,"published native height",system_cycles);
            if (tracing()) {
                uint64_t hash=UINT64_C(14695981039346656037);
                std::array<uint64_t,64> row_hashes;
                for (unsigned y=0;y<64;++y) {
                    row_hashes[y]=UINT64_C(14695981039346656037);
                    for (unsigned x=65;x<245;++x) for (unsigned c=0;c<3;++c) {
                        const auto value=native_picture[(y*320+x)*3+c];
                        hash^=value; hash*=UINT64_C(1099511628211);
                        row_hashes[y]^=value; row_hashes[y]*=UINT64_C(1099511628211);
                    }
                }
                logo_trace << "{\"cycle\":" << system_cycles << ",\"frame\":" << native_epoch
                    << ",\"capture\":" << observed_frames << ",\"logo_fnv1a64\":\"" << std::hex << hash << std::dec
                    << "\",\"palette_writes_so_far\":" << frame_palette_writes << ",\"fetches\":" << frame_video_reads
                    << ",\"max_fetch_wait\":" << frame_video_max << ",\"max_cpu_ram_wait\":" << frame_cpu_max
                    << ",\"underruns\":" << dut.native_underruns << ",\"row_fnv1a64\":[";
                for (unsigned y=0;y<64;++y) { if(y) logo_trace << ','; logo_trace << '"' << std::hex << row_hashes[y] << std::dec << '"'; }
                logo_trace << "]}\n";
                if (saved_logo_hashes.size()<8 && saved_logo_hashes.insert(hash).second) {
                    std::ofstream image(trace_prefix+"-trace-logo-"+std::to_string(native_epoch)+"-native.ppm", std::ios::binary);
                    require(image.good(),"trace logo image unavailable");
                    image << "P6\n320 " << height << "\n255\n";
                    image.write(reinterpret_cast<const char*>(native_picture.data()),320*height*3);
                }
            }
        }
        if (native_vblank) { ++native_epoch; frame_palette_writes=0; frame_cpu_max=frame_video_max=0; frame_video_reads=0; }
        concurrent_cycles += dut.cpu_req && dut.video_req;
        if (!dut.reset_sys) {
            if (dut.debug_bus_error && !last_fault) ++faults;
            if (dut.irq_ack && !last_ack) {
                if (demo_mode && tracing()) raster_trace << "{\"cycle\":" << system_cycles
                    << ",\"frame\":" << native_epoch << ",\"line\":" << line << ",\"horizontal_phase\":" << phase
                    << ",\"iack\":" << unsigned(dut.irq_level) << ",\"mfp_vector\":"
                    << (dut.irq_level==6 ? unsigned(dut.debug_irq_vector) : 0) << "}\n";
                if (dut.irq_level == 6) ++mfp;
                if (dut.irq_level == 4) ++vbl;
            }
            require(system_cycles - boot_start < 1000 || !dut.debug_halted,
                    "CPU double-fault HALT during assembled SDRAM boot", system_cycles);
        }
        last_fault = dut.debug_bus_error;
        last_ack = dut.irq_ack;
        dut.clk_sys = 0;
        dut.eval();
    }

    void save_rendered_frame() {
        const auto reduced = st_rendered_capture::canvas(complete_picture, rendered_pal);
        std::string full_file, native_file;
        if (rendered_valid && saved_rendered_sequences.size()<8 &&
                saved_rendered_sequences.insert(rendered_sequence).second) {
            const auto stem = trace_prefix + "-rendered-" + std::to_string(complete_frames) +
                              "-frame-" + std::to_string(rendered_sequence);
            full_file = stem + "-hdmi.ppm";
            std::ofstream full(full_file, std::ios::binary);
            require(full.good(), "rendered HDMI image unavailable");
            full << "P6\n1280 720\n255\n";
            full.write(reinterpret_cast<const char*>(complete_picture.data()), complete_picture.size());
            if (reduced.repeated) {
                native_file = stem + "-canvas.ppm";
                std::ofstream native(native_file, std::ios::binary);
                require(native.good(), "rendered canvas image unavailable");
                native << "P6\n416 " << reduced.height << "\n255\n";
                native.write(reinterpret_cast<const char*>(reduced.rgb.data()), reduced.rgb.size());
            }
        }
        // Basenames let sealed evidence remain valid after directory relocation.
        auto basename = [](const std::string& p) { return p.substr(p.find_last_of('/')+1); };
        rendered_trace << "{\"hdmi_frame\":" << complete_frames << ",\"native_frame\":" << rendered_sequence
            << ",\"start_cycle\":" << rendered_start_cycle << ",\"end_cycle\":" << system_cycles
            << ",\"valid\":" << (rendered_valid ? "true" : "false")
            << ",\"pal\":" << (rendered_pal ? "true" : "false")
            << ",\"active_height\":" << rendered_height
            << ",\"canvas_xywh\":[224," << reduced.top << ",832," << reduced.height*2 << "]"
            << ",\"repeat_2x2\":" << (reduced.repeated ? "true" : "false")
            << ",\"hdmi_file\":\"" << basename(full_file) << "\",\"canvas_file\":\""
            << basename(native_file) << "\"}\n";
    }

    void pixel_edge() {
        const uint32_t current = dut.video_request;
        if (!dut.reset_pixel) {
            const unsigned x = position % Width, y = position / Width;
            uint32_t timing = CE;
            if (x < 1280 && y < 720) timing |= DE;
            if (x >= 1390 && x < 1430) timing |= HS;
            if (y >= 725 && y < 730) timing |= VS;
            if (!position) timing |= SOF;
            if (x == 1649) timing |= EOL;
            require((current & ~(0xffffff | HOLD)) == timing,
                    "assembled scanout lost fixed raster timing", system_cycles);
        }
        dut.clk_pixel = 1;
        dut.eval();
        if (dut.reset_pixel) {
            position = previous_position = 0;
            previous_request = 0;
        } else {
            const uint32_t timing = previous_request & (CE | DE | HS | VS);
            const uint32_t rgb = (previous_request & DE) && !(previous_request & HOLD)
                ? previous_request & 0xffffff : 0;
            require(dut.video_response == (timing | rgb),
                    "assembled direct video part/boundaries misaligned", system_cycles);
            if (previous_request & SOF) {
                if (picture_started) {
                    complete_picture = picture;
                    ++complete_frames;
                    if (demo_mode && rendered_tracing) save_rendered_frame();
                }
                picture_started = true;
                rendered_sequence = dut.rendered_sequence;
                rendered_height = dut.rendered_height;
                rendered_valid = dut.rendered_valid;
                rendered_pal = dut.rendered_pal;
                rendered_tracing = tracing();
                rendered_start_cycle = system_cycles;
            }
            if (previous_request & DE) {
                require(dut.rendered_sequence == rendered_sequence &&
                        dut.rendered_height == rendered_height && dut.rendered_pal == rendered_pal &&
                        dut.rendered_valid == rendered_valid,
                        "displayed native identity changed during HDMI active frame", system_cycles);
                const unsigned x = previous_position % Width, y = previous_position / Width;
                const unsigned offset = (y * 1280 + x) * 3;
                picture[offset] = rgb >> 16;
                picture[offset + 1] = rgb >> 8;
                picture[offset + 2] = rgb;
            }
            previous_request = current;
            previous_position = position;
            position = (position + 1) % Frame;
        }
        dut.clk_pixel = 0;
        dut.eval();
        ++pixel_cycles;
    }

    void event() {
        // Exact frequency ratio, with unrelated phase. Units are arbitrary
        // integer event ticks, not analog timing or an HDL delay model.
        if (next_sys < next_pixel) {
            system_edge();
            next_sys += 74250;
        } else {
            pixel_edge();
            next_pixel += 52224;
        }
    }

    void save_ram(const std::string& path) const {
        std::ofstream raw(path, std::ios::binary);
        require(raw.good(), "cannot write physical RAM snapshot", system_cycles);
        for (unsigned i = 0; i < 0x40000; ++i) {
            raw.put(sdram.words[i] >> 8);
            raw.put(sdram.words[i]);
        }
        raw.flush();
        require(raw.good(), "physical RAM snapshot write failed", system_cycles);
    }

    void status() {
        std::cout << "assembled seconds=" << std::dec << (system_cycles - boot_start) / SystemHz
                  << " pc=" << std::hex << dut.debug_pc << " bus=" << dut.debug_addr
                  << " phystop=" << longword(0x42e) << " screen=" << longword(0x44e)
                  << " memvalid=" << longword(0x420) << " hz200=" << std::dec << longword(0x4ba)
                  << " frclock=" << longword(0x466) << " CPU R/W=" << cpu_reads << '/' << cpu_writes
                  << " video R=" << video_reads << " refreshes=" << sdram.refreshes
                  << " faults=" << faults << " MFP/VBL=" << mfp << '/' << vbl
                  << " native frames/skipped/underruns=" << dut.native_frames << '/'
                  << dut.native_skipped << '/' << dut.native_underruns
                  << " indexed underruns=" << dut.debug_underruns << '\n' << std::flush;
        const auto elapsed = system_cycles - boot_start;
        if (demo_mode && saved_ram_cycles.insert(elapsed).second) {
            // Observe the command-model RAM between events; no DUT clocks,
            // input state or memory contents change while copying it.
            save_ram(trace_prefix + "-ram-cycle-" + std::to_string(elapsed) + ".bin");
            ram_snapshot_trace << "{\"system_cycle\":" << elapsed
                               << ",\"bytes\":524288}\n" << std::flush;
            require(ram_snapshot_trace.good(), "RAM snapshot index write failed", system_cycles);
        }
    }

public:
    void open_ram_write_trace(const char *ranges, const char *prefix) {
        ram_write_trace.open(ranges,std::string(prefix)+"-ram-writes.jsonl");
    }
    explicit Boot(const char *path, const char *disk_path = nullptr, bool raster_probe = false, bool palette_probe = false) {
#ifdef ST_RAM_BUS_PROBE
        if (!path) {
            // Original firmware: bank config, repeated byte instructions on
            // both lanes, physical completion marker, STOP. No external ROM.
            rom.resize(196608);
            unsigned at = 0;
            auto word = [&](unsigned value) { rom.at(at++) = value >> 8; rom.at(at++) = value; };
            auto longword = [&](unsigned value) { word(value >> 16); word(value); };
            longword(0x7fff0); longword(0xfc0100);
            at = 0x100;
            word(0x13fc); word(4); longword(0xff8001);
            if (palette_probe) {
                // Authored ROM-fed writes. Terminal DBF takes 14 cycles and
                // exercises both two-cycle alignments of the CPU bus.
                word(0x43f9); longword(0xff8240);
                for (unsigned i=1;i<=16;++i) {
                    word(0x7000 | i); word(0x3280);
                    word(0x7200); word(0x51c9); word(2);
                }
                word(0x33fc); word(0x0753); longword(0xff8240);
                // Byte writes mirror first, then mask: these readbacks are
                // independent of the prior register value or selected lane.
                for (const auto &[byte, address, result] :
                     std::array<std::array<unsigned,3>,4>{{
                         {{0x02,0xff8240,0x404}}, {{0x16,0xff8241,0x402}},
                         {{0x71,0xff8240,0x406}}, {{0x55,0xff8241,0x408}}
                     }}) {
                    word(0x13fc); word(byte); longword(address);
                    word(0x3239); longword(0xff8240);
                    word(0x33c1); longword(result);
                }
                for (unsigned i=0;i<16;++i) {
                    word(0x4e71); word(0x3011);
                    word(0x7200); word(0x51c9); word(2);
                }
                word(0x33fc); word(0xc0de); longword(0x400);
                word(0x4e72); word(0x2700);
            } else if (raster_probe) {
                // Authored RAM-resident NOP/DBF workload. Its 29 iterations
                // require the ST's two-cycle RAM alignment to make 512 cycles.
                word(0x13fc); word(2); longword(0xff8201);
                word(0x41f9); longword(0x10000);
                word(0x43f9); longword(0xff8240);
                word(0x4ef9); longword(0x2000);
                unsigned code = 0x1000;
                for (unsigned block = 0; block < 300; ++block) {
                    const unsigned header[] = {0x3298, 0x323c, 28, 0x4e71,
                        0x51c9, 0xfffc, 0x4e71, 0x2679, 0x0001, 0x8000, 0x329b};
                    for (unsigned value : header) sdram.words[code++] = uint16_t(value);
                    for (unsigned i = 0; i < 40; ++i) sdram.words[code++] = 0x3298;
                }
                const unsigned marker[] = {0x33fc, 0xc0de, 0, 0x0400, 0x4e72, 0x2700};
                for (unsigned value : marker) sdram.words[code++] = uint16_t(value);
                for (unsigned i = 0; i < 12600; ++i) sdram.words[0x8000+i] = uint16_t(i);
                sdram.words[0xc000] = 1; sdram.words[0xc001] = 0;
            } else {
                word(0x13fc); word(2); longword(0xff8201); // screen base $20000
                word(0x13fc); word(2); longword(0xff820a); // PAL raster
                word(0x705a);
                for (unsigned i = 0; i < 512; ++i) { word(0x1239); longword(0x600 + (i & 1)); }
                for (unsigned i = 0; i < 512; ++i) { word(0x13c0); longword(0x600 + (i & 1)); }
                sdram.words[0x310] = 0x1234;
                for (unsigned i = 0; i < 128; ++i) {
                    word(0x4af9); longword(0x620);
                    word(0x4af9); longword(0x621);
                }
                // The menu's ten-register MOVEM.L predecrement operation:
                // 20 physical word writes. An authored DBF delay moves the
                // saves after the first capture-bank handoff and into active
                // video. Measured crossings/reads verify actual contention.
                word(0x323c); word(19000); // MOVE.W #19000,D1
                word(0x51c9); word(0xfffe); // DBF D1,self
                for (unsigned reg = 0; reg < 8; ++reg) {
                    word(0x203c | (reg << 9)); longword(0x12341234);
                }
                word(0x267c); longword(0x12341234);
                word(0x287c); longword(0x12341234);
                word(0x2e7c); longword(0x70000);
                for (unsigned burst = 0; burst < 64; ++burst) {
                    word(0x48e7); word(0xff18); // D0-D7/A3-A4,-(A7)
                }
                word(0x4e70); // RESET must not suspend SDRAM refresh or lose RAM.
                word(0x33fc); word(0xc0de); longword(0x400);
                word(0x4e72); word(0x2700);
            }
        } else
#endif
        {
        std::ifstream input(path, std::ios::binary);
        require(input.good(), "stock ROM unavailable");
        rom.assign(std::istreambuf_iterator<char>(input), {});
        require(rom.size() == 196608, "stock ROM must be exactly 192 KiB");
        }
        dut.media_ready=0; dut.media_size=737280;
        if (disk_path) {
            std::ifstream disk_input(disk_path, std::ios::binary);
            require(disk_input.good(), "demo disk unavailable");
            std::vector<uint8_t> disk{std::istreambuf_iterator<char>(disk_input), {}};
            require(disk.size() >= 368640 && disk.size() <= 839680 && !(disk.size()&1), "demo disk bounds");
            for (unsigned i=0;i<disk.size();i+=2) sdram.words[0x40000+i/2]=(uint16_t(disk[i])<<8)|disk[i+1];
            dut.media_size=disk.size(); dut.media_ready=1; demo_mode=true;
        }
        dut.clk_sys = dut.clk_pixel = 0;
        dut.reset_sys = dut.reset_pixel = dut.cold_reset = 1;
        dut.rom_ready = 0;
        dut.rom_rdata = 0xffff;
        dut.dq_sample = 0;
        dut.eval();
        while (system_cycles < 64) event();
        dut.cold_reset = 0;
        dut.eval();
        while (!dut.initialized) {
            event();
            require(system_cycles < 20000, "physical SDRAM initialization timed out", system_cycles);
        }
        require(sdram.initialized && sdram.mode_sets == 1,
                "controller initialized without physical mode-register sequence", system_cycles);
        dut.reset_sys = dut.reset_pixel = 0;
        boot_start = system_cycles;
        dut.eval();
        std::cout << "physical SDRAM initialized after " << system_cycles << " clocks\n" << std::flush;
    }

#ifdef ST_RAM_BUS_PROBE
    void ram_bus_probe() {
        while (word(0x400) != 0xc0de) {
            require(system_cycles - boot_start < 2000000, "RAM timing firmware did not complete", system_cycles);
            event();
        }
        require(faults == 0 && !dut.debug_halted, "RAM timing firmware faulted", system_cycles);
        require(word(0x600) == 0x5a5a, "RAM timing byte lanes did not reach physical memory", system_cycles);
        require(word(0x620) == 0x92b4, "TAS byte lanes lost physical RAM data", system_cycles);
        require(tas_reads == 256 && tas_writes == 256, "TAS did not complete each read/write exactly once", system_cycles);
        require(movem_word_ticks.size() == 1280, "MOVEM physical word count", system_cycles);
        unsigned movem_line_crossings = 0;
        for (unsigned i = 0; i < 1280; ++i) {
            require(word(0x6f600 + 2*i) == 0x1234, "MOVEM physical RAM payload/location", system_cycles);
#if ST_EARLY_COMPLETION
            if (i % 20) require(movem_word_ticks[i] - movem_word_ticks[i-1] == 4,
                                "MOVEM added a four-cycle word-write slot", system_cycles);
#endif
            if (i % 20 && movem_word_lines[i] != movem_word_lines[i-1]) ++movem_line_crossings;
        }
        std::cout << "MOVEM lines " << movem_word_lines.front() << ".." << movem_word_lines.back()
                  << ", crossings " << movem_line_crossings << ", concurrent VIDEO reads " << movem_video_reads << '\n';
        require(movem_line_crossings >= 4 && movem_video_reads > 500,
                "MOVEM did not cross active shifter line starts", system_cycles);
        std::cout << "RAM CPU MOVEM PASS: 64 ten-register bursts, 1280 physical word writes";
        if (ST_EARLY_COMPLETION) std::cout << ", all 1216 within-burst intervals four CPU clocks";
        std::cout << ", " << movem_line_crossings << " active scanline crossings\n";
        require(ram_bus_starts.size() == 1024, "RAM timing transaction count", system_cycles);
        std::array<std::map<unsigned, unsigned>, 2> histograms;
        for (unsigned i = 1; i < ram_bus_starts.size(); ++i) {
            if (ram_bus_starts[i].first != ram_bus_starts[i-1].first) continue;
            const auto ticks = unsigned(ram_bus_starts[i].second - ram_bus_starts[i-1].second);
            require(ticks >= 16 && ticks <= 40, "RAM instruction timing outside bounded range", system_cycles);
            ++histograms[ram_bus_starts[i].first][ticks];
        }
        for (unsigned writing = 0; writing < 2; ++writing) {
            unsigned intervals = 0, total = 0;
            std::cout << "RAM CPU " << (writing ? "write" : "read") << " histogram:";
            for (const auto &[ticks, count] : histograms[writing]) {
                intervals += count; total += ticks * count;
                std::cout << ' ' << ticks << ':' << count;
            }
            require(intervals == 511, "RAM instruction interval count", system_cycles);
            require(total <= (writing ? (ST_EARLY_COMPLETION ? 8176u : 9500u) : (ST_EARLY_COMPLETION ? 8250u : 9000u)),
                    "RAM instruction timing regressed", system_cycles);
            std::cout << "; total " << total << " CPU cycles for " << intervals << " intervals\n";
        }
        std::cout << "RAM CPU TAS/RESET PASS: " << tas_reads << " reads, " << tas_writes
                  << " writes, maximum refresh gap " << sdram.max_refresh_gap << " clocks\n";
        require(sdram.max_refresh_gap <= 408, "RAM probe refresh interval exceeded 7.8 us", system_cycles);
        std::cout << "RAM CPU physical bus PASS: 1024 byte transactions, zero faults, physical byte lanes and marker\n";
    }
    void rom_palette_probe() {
        while (word(0x400) != 0xc0de) {
            require(system_cycles-boot_start < 100000, "ROM palette firmware did not complete", system_cycles);
            event();
        }
        require(faults == 0 && !dut.debug_halted, "ROM palette firmware faulted", system_cycles);
        require(raster_write_ticks.size() == 21, "palette accesses committed more than once", system_cycles);
        for (unsigned i=1;i<16;++i)
            require(raster_write_ticks[i]-raster_write_ticks[i-1] == 32,
                    "ROM-fed palette access missed four-cycle bus alignment", system_cycles);
        for (unsigned phase : raster_write_phases)
            require((phase & 3) == 1, "palette commit escaped its native bus phase", system_cycles);
        require(palette_read_ticks.size() == 20, "palette reads completed more than once", system_cycles);
        for (unsigned i=5;i<20;++i)
            require(palette_read_ticks[i]-palette_read_ticks[i-1] == 32,
                    "ROM-fed palette read missed four-cycle bus alignment", system_cycles);
        for (unsigned phase : palette_read_phases)
            require((phase & 3) == 1, "palette read escaped its native bus phase", system_cycles);
        require(word(0x404) == 0x0202 && word(0x402) == 0x0616 &&
                word(0x406) == 0x0171 && word(0x408) == 0x0555,
                "palette byte write did not mirror before the RGB mask", system_cycles);
        std::cout << "ROM palette bus PASS: 15 read and 15 write intervals of 32 CPU cycles, 21 writes and 20 reads exactly once, byte mirroring before RGB mask\n";
    }

    void ram_raster_probe() {
        while (word(0x400) != 0xc0de) {
            require(system_cycles - boot_start < 4000000, "RAM raster firmware did not complete", system_cycles);
            event();
        }
        require(faults == 0 && !dut.debug_halted, "RAM raster firmware faulted", system_cycles);
        require(raster_write_ticks.size() == 12600, "RAM raster palette transaction count", system_cycles);
        unsigned short_gaps = 0, long_gaps = 0;
        for (unsigned i = 1; i < raster_write_ticks.size(); ++i) {
            const auto gap = raster_write_ticks[i] - raster_write_ticks[i-1];
            require(gap == 12 || gap == 512, "RAM alignment changed the raster interval", system_cycles);
            if (gap == 12) ++short_gaps; else ++long_gaps;
        }
        require(short_gaps == 12299 && long_gaps == 300, "RAM raster interval counts", system_cycles);
        require(video_reads > 18000 && dut.native_underruns == 0,
                "RAM raster did not retain concurrent video deadlines", system_cycles);
        require(sdram.max_refresh_gap <= 408, "RAM raster refresh interval exceeded 7.8 us", system_cycles);
        std::cout << "RAM raster PASS: " << short_gaps << " intervals of 12 cycles, "
                  << long_gaps << " intervals of 512; video reads " << video_reads
                  << "; maximum refresh gap " << sdram.max_refresh_gap << "; no underruns\n";
    }

#endif

    void run(unsigned seconds, const char *prefix, unsigned start=6, unsigned end=7, unsigned press_at=0, unsigned usage=5, const char* schedule_path=nullptr) {
        keys.configure(schedule_path ? st_keyboard_stimulus::load(schedule_path,SystemHz*seconds) :
                       st_keyboard_stimulus::legacy(press_at,usage),prefix);
        audio.open(std::string(prefix)+"-audio.wav");
        trace_start=start; trace_end=end;
        if (demo_mode) {
            trace_prefix=prefix;
            raster_trace.open(std::string(prefix)+"-raster.jsonl");
            logo_trace.open(std::string(prefix)+"-logo.jsonl");
            ym_trace.open(std::string(prefix)+"-ym.jsonl");
            rendered_trace.open(std::string(prefix)+"-rendered.jsonl");
            ram_snapshot_trace.open(std::string(prefix)+"-ram-snapshots.jsonl");
            require(raster_trace.good() && logo_trace.good() && ym_trace.good() && rendered_trace.good() && ram_snapshot_trace.good(), "demo trace output unavailable");
        }
        uint64_t next_status = boot_start + SystemHz;
        const uint64_t limit = boot_start + SystemHz * seconds;
        while (system_cycles < limit) {
            event();
            if (system_cycles >= next_status) {
                status();
                next_status += SystemHz;
            }
        }
        status();
        require(dut.native_frames > 100 && dut.native_underruns == 0,
                "native low-resolution capture missed frames/rows under SDRAM contention", system_cycles);
        if (!demo_mode) {
        require(longword(0x420) == 0x752019f3, "EmuTOS did not validate physical RAM", system_cycles);
        require(longword(0x42e) == 0x80000, "EmuTOS did not size physical RAM at 512 KiB", system_cycles);
        require(longword(0x44e) == 0x78000 && dut.screen_base == 0x78000,
                "EmuTOS framebuffer base is incorrect", system_cycles);
        require(longword(0x4ba) > 1000 && mfp > 1000, "200 Hz timer did not continue during contention", system_cycles);
        require(longword(0x466) > 100 && vbl > 100, "VBL processing stopped during contention", system_cycles);
        }
        require(cpu_writes > 100000 && video_reads > 100000 && concurrent_cycles > 100000,
                "CPU and video did not exercise simultaneous shared SDRAM traffic", system_cycles);
        require(complete_frames > 100 && complete_picture.size() == 1280 * 720 * 3,
                "no complete fixed-raster output frame captured", system_cycles);
        std::set<uint32_t> colors;
        for (unsigned i = 0; i < complete_picture.size(); i += 3)
            colors.insert((uint32_t(complete_picture[i]) << 16) |
                          (uint32_t(complete_picture[i + 1]) << 8) | complete_picture[i + 2]);
        require(colors.size() >= 3, "rendered EmuTOS screen lacks meaningful color content", system_cycles);
        std::ofstream ppm(std::string(prefix) + ".ppm", std::ios::binary);
        require(ppm.good(), "cannot write rendered PPM", system_cycles);
        ppm << "P6\n1280 720\n255\n";
        ppm.write(reinterpret_cast<const char *>(complete_picture.data()), complete_picture.size());
        save_ram(std::string(prefix) + "-ram.bin");
        if (demo_mode) {
            std::ofstream metrics(std::string(prefix)+"-metrics.json");
            metrics << "{\"cycle\":" << system_cycles-boot_start << ",\"bus_faults\":" << faults
                << ",\"halted\":false,\"native_rgb_frames\":" << dut.native_frames
                << ",\"native_rgb_underruns\":" << dut.native_underruns << ",\"indexed_underruns\":" << dut.debug_underruns
                << ",\"committed_palette_writes\":" << palette_writes
                << ",\"cpu_reads\":" << cpu_reads << ",\"cpu_writes\":" << cpu_writes
                << ",\"video_reads\":" << video_reads << ",\"max_cpu_latency\":" << max_cpu_latency
                << ",\"max_video_latency\":" << max_video_latency << ",\"sdram_refreshes\":" << sdram.refreshes << "}\n";
            require(metrics.good(), "demo metrics output unavailable");
        }
        std::cout << (demo_mode ? "Demo diagnostic" : "Stock EmuTOS") << " assembled SDRAM/video boot PASS: " << system_cycles - boot_start
                  << " system clocks, " << pixel_cycles << " independent pixel clocks, "
                  << complete_frames << " complete frames, " << colors.size() << " RGB colors; max CPU/video latency "
                  << max_cpu_latency << '/' << max_video_latency << " clocks; output " << prefix << ".ppm\n";
        ram_write_trace.finish();
        audio.finish(std::string(prefix)+"-audio.json");
        if (demo_mode) {
            ym_trace.flush();
            require(ym_trace.good(), "YM trace write failed");
        }
        dut.final();
    }
};

int main(int argc, char **argv) {
    Verilated::commandArgs(argc, argv);
    try {
#ifdef ST_RAM_BUS_PROBE
    require(argc == 1, "RAM timing firmware takes no external ROM");
    {
        Boot boot(nullptr);
        boot.ram_bus_probe();
    }
#if ST_EARLY_COMPLETION
    Boot palette(nullptr, nullptr, false, true);
    palette.rom_palette_probe();
    Boot raster(nullptr, nullptr, true);
    raster.ram_raster_probe();
#endif
#else
    require((argc >= 2 && argc <= 4) || argc==7 || argc==9 || argc==10 || argc==11, "usage: boot_memory_tb STOCK_192K_ROM [SECONDS=8] [OUTPUT_PREFIX=emutos-sdram]");
    const unsigned seconds = argc >= 3 ? unsigned(std::strtoul(argv[2], nullptr, 10)) : 8;
    require(seconds >= 6 && seconds <= 120, "boot duration must be 6..120 emulated seconds");
    Boot boot(argv[1], argc>=7 ? argv[4] : nullptr);
    if (argc==11) boot.open_ram_write_trace(argv[10],argv[3]);
    boot.run(seconds, argc >= 4 ? argv[3] : "emutos-sdram", argc>=7 ? unsigned(std::strtoul(argv[5],nullptr,10)) : 6,
             argc>=7 ? unsigned(std::strtoul(argv[6],nullptr,10)) : 7,
             argc>=9 ? unsigned(std::strtoul(argv[7],nullptr,10)) : 0,
             argc>=9 ? unsigned(std::strtoul(argv[8],nullptr,10)) : 5, argc>=10 ? argv[9] : nullptr);
#endif
    } catch (const std::exception& error) {
        std::cerr << "FAIL " << error.what() << '\n';
        return 1;
    }
    return 0;
}
