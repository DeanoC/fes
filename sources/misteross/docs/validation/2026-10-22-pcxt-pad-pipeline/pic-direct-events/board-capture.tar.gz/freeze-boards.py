#!/usr/bin/env python3
"""Freeze both diagnostic board captures after complete source/receipt checks."""
from pathlib import Path
import hashlib,json,tarfile
R=Path(__file__).resolve().parent;B=R.parent/'add-op0-20261022/baseline'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
for name in ['standalone','subsets']:
 rec=read(R/(name+'-evidence.json'))
 for n,h in rec['files_sha256'].items():assert sha(R/n)==h,(name,n)
 archive=R/(name+'-capture.tar.gz')
 expected=rec['capture_sha256'] if name=='standalone' else rec['archive_sha256'];assert sha(archive)==expected
 with tarfile.open(archive) as t:
  assert {n:hashlib.sha256(t.extractfile(n).read()).hexdigest() for n in rec['files_sha256']}==rec['files_sha256']
for name in ['board','board-AP']:
 f=R/name;rec=read(f/'receipt.json');assert rec['returncode']==0
 for n,h in rec['artifacts'].items():assert sha(f/'synthesis'/n)==h
 snap=read(f/'snapshot.json')
 assert sha(f/'derived-source.tar.gz')==snap['derived_archive_sha256']
 with tarfile.open(f/'derived-source.tar.gz') as t:
  actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()};assert actual==snap['files_sha256']
 assert {str(p.relative_to(f/'source')):sha(p) for p in sorted((f/'source').rglob('*')) if p.is_file()}==actual
 comp=read(f/'comparison.json');assert comp['candidate']['synth_sha256']==sha(f/'synthesis/synth.json') and comp['candidate']['receipt_sha256']==sha(f/'receipt.json')
 assert comp['baseline']['synth_sha256']==sha(B/'synthesis/synth.json') and comp['baseline']['receipt_sha256']==sha(B/'receipt.json')
files={}
for dirname in ['board','board-AP','subset-supplement']:
 for p in sorted((R/dirname).rglob('*')):
  if p.is_file() and 'source' not in p.relative_to(R).parts and '__pycache__' not in p.parts:files[str(p.relative_to(R))]=sha(p)
for n in ['standalone-capture.tar.gz','standalone-evidence.json','standalone-readback.json','subsets-capture.tar.gz','subsets-evidence.json','subsets-readback.json','board-synthesize.py','board-synthesize.log','board-AP-synthesize.py','board-AP-synthesize.log','board-compare.py','board-compare.log','board-AP-compare.log','subset-supplement.py','subset-supplement.log','BOARD-ANALYSIS.md','freeze-boards.py','readback-boards.py']:files[n]=sha(R/n)
archive=R/'board-capture.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n in sorted(files):t.add(R/n,arcname=n)
with tarfile.open(archive) as t:
 assert {n:hashlib.sha256(t.extractfile(n).read()).hexdigest() for n in files}==files
external={str(B/n):sha(B/n) for n in ['receipt.json','inputs.json','snapshot.json','synthesis/synth.json','synthesis/synth.ys','synthesis/constraints.qsf','synthesis/clocks.sdc']}
rec={'scope':'Complete two diagnostic board synthesis captures, source archives, standalone proofs/mappings and subset/negative supplements. Existing paired baseline is external and already archived in ADD evidence. No route/hardware or complete mapped-board equivalence.','files_sha256':files,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'external_frozen_baseline_sha256':external,'all_member_readback_verified':len(files),'synthesis_seconds':{n:read(R/n/'receipt.json')['elapsed_seconds'] for n in ['board','board-AP']},'route_charge_seconds':0}
write(R/'board-evidence.json',rec);write(R/'board-readback.json',{'status':'PASS','receipt_sha256':sha(R/'board-evidence.json'),'archive_sha256':sha(archive),'files_verified':len(files),'source_archive_files_each':[len(read(R/n/'snapshot.json')['files_sha256']) for n in ['board','board-AP']]});print(sha(R/'board-evidence.json'),len(files),archive.stat().st_size)
