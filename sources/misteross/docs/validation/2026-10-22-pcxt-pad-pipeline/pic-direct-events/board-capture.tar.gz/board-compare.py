#!/usr/bin/env python3
"""Complete eight-bit service-cone inventories for immutable board syntheses."""
from pathlib import Path
from collections import Counter,defaultdict
from functools import lru_cache
import argparse,hashlib,json,sys
sys.setrecursionlimit(20000)
R=Path(__file__).resolve().parent;BASE=R.parent/'add-op0-20261022/baseline'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
class Graph:
 def __init__(self,folder):
  self.folder=folder;self.file=folder/'synthesis/synth.json';self.m=read(self.file)['modules']['top'];self.cells=self.m['cells'];self.drivers={};self.users=defaultdict(list);self.aliases=defaultdict(list)
  for n,c in self.cells.items():
   for p,bs in c['connections'].items():
    for i,b in enumerate(bs):
     if type(b) is int:
      if c['port_directions'][p]=='output':assert b not in self.drivers;self.drivers[b]=(n,p,i)
      else:self.users[b].append((n,p,i))
  for n,v in self.m['netnames'].items():
   for i,b in enumerate(v['bits']):
    if type(b) is int:self.aliases[b].append((n,i))
  self.inputs={b for p in self.m['ports'].values() if p['direction']=='input' for b in p['bits']}
  reset=[(n,c) for n,c in self.cells.items() if c['type']=='MISTRAL_FF' and 'pcxt_system.sv:45.' in c['attributes'].get('src','')];assert len(reset)==1
  self.reset_name,self.reset=reset[0];self.reset_q=self.reset['connections']['Q'][0]
 def id(self,b):
  if type(b) is str:return ['constant',b]
  return {'bit':b,'driver':self.drivers.get(b),'RTL_aliases':[x for x in self.aliases[b] if '_MISTRAL_' not in x[0] and not x[0].startswith('$')]}
 @lru_cache(None)
 def support(self,n,p):
  c=self.cells[n];typ=c['type'];co=c['connections']
  if typ in ['MISTRAL_NOT','MISTRAL_BUF','MISTRAL_CLKBUF']:return tuple(co['A'])
  if typ=='MISTRAL_OB':return tuple(co['I'])
  if typ=='MISTRAL_IB':return tuple(co['PAD'])
  if typ=='MISTRAL_ALUT_ARITH':
   pins=[co[k][0] for k in ['A','B','C','D0','D1','CI']]
   def value(vals):
    a,b,c,d0,d1,ci=vals;q0=(int(self.cells[n]['parameters']['LUT0'],2)>>(a+2*b+4*c+8*d0))&1;q1=(int(self.cells[n]['parameters']['LUT1'],2)>>(a+2*b+4*c+8*d1))&1;s=q0+(1-q1)+ci
    assert p in ['SO','CO'];return (s>>(p=='CO'))&1
  else:
   assert typ in ['MISTRAL_ALUT'+str(w) for w in range(2,7)],(n,p,typ)
   pins=[co[k][0] for k in 'ABCDEF'[:int(typ[-1])]];mask=int(c['parameters']['LUT'],2)
   def value(vals):return (mask>>sum(v<<i for i,v in enumerate(vals)))&1
  assert set(x for x in pins if type(x) is str)<={'0','1'},(n,pins)
  ids=sorted({x for x in pins if type(x) is int});table=[]
  for row in range(1<<len(ids)):
   vals={b:(row>>i)&1 for i,b in enumerate(ids)};table.append(value([int(b) if type(b) is str else vals[b] for b in pins]))
  return tuple(b for i,b in enumerate(ids) if any(table[row]!=table[row^(1<<i)] for row in range(len(table))))
 @lru_cache(None)
 def path(self,b,mode):
  if type(b) is str:return None
  if mode=='reset' and b==self.reset_q:return {'depth':0,'launch':self.id(b),'cells':[]}
  if b in self.inputs:return {'depth':0,'launch':self.id(b),'cells':[]} if mode=='all' else None
  assert b in self.drivers,('undriven',b,self.aliases[b]);n,p,i=self.drivers[b];c=self.cells[n];typ=c['type']
  if typ in ['MISTRAL_FF','MISTRAL_M10K','altera_pll','cyclonev_hps_interface_peripheral_i2c','MISTRAL_IO','altiobuf_bidir']:
   return {'depth':0,'launch':self.id(b),'cells':[]} if mode=='all' else None
  candidates=[v for x in self.support(n,p) if (v:=self.path(x,mode)) is not None]
  if not candidates:return None
  best=max(candidates,key=lambda x:(x['depth'],repr(x['launch'])))
  cost=int(typ.startswith('MISTRAL_ALUT'))
  return {'depth':best['depth']+cost,'launch':best['launch'],'cells':best['cells']+[{'cell':n,'type':typ,'output':p,'logic_cost':cost,'actual_support':[self.id(x) for x in self.support(n,p)],'output_fanout':len(self.users[b]),'parameters':c['parameters']}]}
 def service(self):
  vector='system.machine.board.pic_device.u_In_Service.next_highest_level_in_service';bits=self.m['netnames'][vector]['bits'];assert len(bits)==8
  ffs={n:c for n,c in self.cells.items() if c['type']=='MISTRAL_FF' and 'KF8259_In_Service.sv:49.' in c['attributes'].get('src','')};assert len(ffs)==8
  result=[]
  for i,b in enumerate(bits):
   found=[(n,c) for n,c in ffs.items() if c['connections']['DATAIN']==[b]];assert len(found)==1
   n,c=found[0];assert c['connections']['CLK']==[self.m['netnames']['clocks']['bits'][0]]
   result.append({'RTL_bit':i,'native_FF':n,'actual_FF':c,'D_identity':self.id(b),'Q_identity':self.id(c['connections']['Q'][0]),'reset_path':self.path(b,'reset'),'any_launch_path':self.path(b,'all')})
  assert len({r['native_FF'] for r in result})==8
  return result
 def overview(self):
  counts=Counter(c['type'] for c in self.cells.values());rows=self.service();prefix='system.machine.board.pic_device.'
  pic={n:c for n,c in self.cells.items() if n.startswith(prefix) or 'KF8259_' in c['attributes'].get('src','')}
  ff_inputs=[]
  for n,c in pic.items():
   if c['type']!='MISTRAL_FF' or 'KF8259_' not in c['attributes'].get('src',''):continue
   for pin,bs in c['connections'].items():
    if pin in ['Q','CLK','ACLR'] or not bs:continue
    assert len(bs)==1
    ff_inputs.append({'cell':n,'pin':pin,'Q_identity':self.id(c['connections']['Q'][0]),'any_launch_path':self.path(bs[0],'all'),'reset_path':self.path(bs[0],'reset')})
  return {'all_PIC_source_FF_input_cones':ff_inputs,'PIC_source_FF_input_depth_histogram':dict(Counter(x['any_launch_path']['depth'] for x in ff_inputs if x['any_launch_path'])), 'synth_sha256':sha(self.file),'receipt_sha256':sha(self.folder/'receipt.json'),'whole_board_cell_types':dict(counts),'PIC_name_or_source_cell_types':dict(Counter(c['type'] for c in pic.values())),'PIC_name_or_source_cells':sorted(pic),'service_bits':rows,'service_all_depths':[r['any_launch_path']['depth'] for r in rows],'service_reset_depths':[r['reset_path']['depth'] if r['reset_path'] else None for r in rows],'machine_reset_FF':{'name':self.reset_name,'cell':self.reset,'Q_identity':self.id(self.reset_q)}}
 def aliases(self,b):return self.aliases[b]
def verify(folder):
 rec=read(folder/'receipt.json');assert rec['returncode']==0
 for n,h in rec['artifacts'].items():assert sha(folder/'synthesis'/n)==h
 return rec
parser=argparse.ArgumentParser();parser.add_argument('case',choices=['board','board-AP']);args=parser.parse_args();folder=R/args.case
verify(BASE);verify(folder)
snapshot=read(folder/'snapshot.json');source=folder/'source'
assert {str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file()}==snapshot['files_sha256']
old=Graph(BASE);new=Graph(folder);x,y=old.overview(),new.overview()
# Retain complete generated-cell union, never imply that equal names are a whole-board equivalence proof.
union=sorted(set(old.cells)|set(new.cells));changes={'removed':[],'added':[],'same_name_type_or_parameter_changes':[]}
for n in union:
 if n not in old.cells:changes['added'].append(n)
 elif n not in new.cells:changes['removed'].append(n)
 elif (old.cells[n]['type'],old.cells[n]['parameters'])!=(new.cells[n]['type'],new.cells[n]['parameters']):changes['same_name_type_or_parameter_changes'].append({'cell':n,'old_type':old.cells[n]['type'],'new_type':new.cells[n]['type'],'old_parameters':old.cells[n]['parameters'],'new_parameters':new.cells[n]['parameters']})
# Full RAM and PLL inventories: all parameters/INIT, connected clock identities, output alias observations.
def named_aliases(g,b):return sorted(g.aliases[b]) if type(b) is int else [['constant',b]]
mems=[]
for typ in ['MISTRAL_M10K','altera_pll']:
 a={n:c for n,c in old.cells.items() if c['type']==typ};b={n:c for n,c in new.cells.items() if c['type']==typ};assert a.keys()==b.keys(),typ
 for n,c in a.items():
  q=b[n];assert c['parameters']==q['parameters'] and c['port_directions']==q['port_directions']
  clocks={}
  for p in c['connections']:
   if typ=='altera_pll' or 'clk' in p.lower() or 'clock' in p.lower():
    aa=c['connections'][p];bb=q['connections'][p];assert len(aa)==len(bb)
    # Exact complete alias classes, including generated names, must bind the same clock roles.
    assert [named_aliases(old,z) for z in aa]==[named_aliases(new,z) for z in bb],(n,p)
    clocks[p]={'old':[old.id(z) for z in aa],'new':[new.id(z) for z in bb]}
  mems.append({'cell':n,'type':typ,'parameters_sha256':hashlib.sha256(json.dumps(c['parameters'],sort_keys=True).encode()).hexdigest(),'all_parameters_exact':True,'clock_ports_and_all_PLL_ports':clocks,'all_actual_old_ports':{p:[old.id(z) for z in bs] for p,bs in c['connections'].items()},'all_actual_new_ports':{p:[new.id(z) for z in bs] for p,bs in q['connections'].items()}})
for n in ['constraints.qsf','clocks.sdc','diagnostic.bin','diagnostic.o','mcl86_facts.vh','mcl86_ucode.mem','mcl86_ucode_byte0.mem','mcl86_ucode_byte1.mem','mcl86_ucode_byte2.mem','mcl86_ucode_byte3.mem','pcxt_diagnostic.hex']:assert sha(BASE/'synthesis'/n)==sha(folder/'synthesis'/n)
res={'scope':'Raw full-board mapping diagnostic of all eight source-bound highest-service bits. Structural LUT-depth witnesses, not mapped functional equivalence or native timing.','baseline':x,'candidate':y,'complete_cell_union':changes,'all_RAM_PLL_parameters_and_clock_roles':mems,'source_proof':read(folder/'inputs.json'),'limits':['LUT support is evaluated with actual masks, constants and duplicate inputs; paths need not be sensitizable across reconvergence.','All FF and hard-output launches have depth zero; this is not their native clock-to-Q delay.','All eight selected endpoints are explicitly bound to source bit coordinates. Other generated cells are fully inventoried but are not paired by name for equivalence.','Only RTL source composition is proven by the whole-PIC equal-state relation; no whole mapped-board equivalence, placement, route or hardware claim.']}
(folder/'comparison.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({'baseline':{k:x[k] for k in ['whole_board_cell_types','service_all_depths','service_reset_depths']},'candidate':{k:y[k] for k in ['whole_board_cell_types','service_all_depths','service_reset_depths']},'all_RAM_PLL_records':len(mems),'complete_cell_union_counts':{k:len(v) for k,v in changes.items()}},indent=2))
