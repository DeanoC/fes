#!/usr/bin/env python3
"""Separate AP-only board diagnostic; preserve the running all-three-event capture."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tarfile,time
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;FES=R.parent.parent;BASE='2a1cedf48efe68ccc92c0f7c7bfed52f0dc35dbd'
Y=Path('/home/deano/fes/out/cache/misteross-toolchains/slots/8e7eeca0616bb73be28b6f12b17c33a19dd11c12dc9fdb56d964e086621867a2/install/bin/yosys')
B=R.parent/'add-op0-20261022/baseline'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=FES,text=True).strip()
stand=read(R/'subsets-evidence.json')
assert sha(R/'subsets-evidence.json')=='5bb666ea8bad8690cf06abfffb517ed6e2f6590172f8587da75eb7b9f8bcb632'
for n,h in stand['files_sha256'].items():assert sha(R/n)==h
assert sha(Y)=='71eb21e86017064c141bca25e0ecd7fd39dcb3671f3d560fbc467eb880b2a650'
run=R/'board-AP';run.mkdir(exist_ok=False);source=run/'source';source.mkdir();archive=run/'base-source.tar.gz'
cmd=['git','archive','--format=tar.gz','--output',str(archive),BASE,'sources/misteross'];subprocess.run(cmd,cwd=FES,check=True)
with tarfile.open(archive) as t:t.extractall(source,filter='data')
component=source/'sources/misteross'
basefiles={str(p.relative_to(source)):sha(p) for p in sorted(component.rglob('*')) if p.is_file()}
bs=read(B/'snapshot.json');assert bs['commit']==BASE and basefiles==bs['files_sha256']
sub='sources/misteross/cores/fes-pcxt/vendor/kf8259/'
for n in ['KF8259_Control_Logic.sv','source.json']:
 assert sha(source/sub/n)==read(R/'snapshot.json')['files']['original'][n]
 shutil.copyfile(R/'subsets/AP'/n,source/sub/n)
files={str(p.relative_to(source)):sha(p) for p in sorted(component.rglob('*')) if p.is_file()}
changes=[n for n in files if files[n]!=basefiles[n]];assert changes==[sub+'KF8259_Control_Logic.sv',sub+'source.json']
derived=run/'derived-source.tar.gz'
with tarfile.open(derived,'w:gz') as t:
 for n in files:t.add(source/n,arcname=n)
with tarfile.open(derived) as t:
 assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}==files
write(run/'snapshot.json',{'scope':'Diagnostic derived source; not an authenticated committed candidate.','base_commit':BASE,'base_tree':git('rev-parse',BASE+'^{tree}'),'base_archive_sha256':sha(archive),'derived_archive_sha256':sha(derived),'base_files_sha256':basefiles,'files_sha256':files,'exact_changed_files':changes,'standalone_evidence_sha256':sha(R/'subsets-evidence.json'),'base_snapshot_sha256':sha(B/'snapshot.json')})
sys.path[0:0]=[str(component/'scripts'),str(component)]
import build_fes_pcxt as board
assert board.ROOT==component
for vendor in ('kf8259','kf8253','kf8255'):board.verify_vendor(vendor)
out=run/'synthesis';out.mkdir();board.board_inputs(out)
maps=tuple(board.CPU_MUX_MAPS) if hasattr(board,'CPU_MUX_MAPS') else (board.CPU_MUX_MAP,)
selected=sorted(set(board.RTL)|set(maps)|{board.QSF,board.SDC,board.ROM_CLOCK_MAP,board.TOOLCHAIN_LOCK,'scripts/build_fes_pcxt.py','scripts/sim_fes_pcxt.py','cores/fes-pcxt/firmware/diagnostic.S'}|{str(p.relative_to(component)) for p in (component/'cores/fes-common/generated').glob('*.vh')}|{str(p.relative_to(component)) for p in (component/'cores/fes-pcxt/vendor').rglob('*') if p.suffix in ('.svh','.mem','.json')})
hashes={s:sha(component/s) for s in selected};bi=read(B/'inputs.json');assert hashes.keys()==bi['source_sha256'].keys()
assert [n for n in hashes if hashes[n]!=bi['source_sha256'][n]]==[n.removeprefix('sources/misteross/') for n in changes]
program=board.yosys_program(out,False,False,board.synthesis_command());(out/'synth.ys').write_text(program+'\n')
shutil.copyfile(component/board.QSF,out/'constraints.qsf');shutil.copyfile(component/board.SDC,out/'clocks.sdc')
generated={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()};assert generated.keys()==bi['generated_sha256'].keys()
assert [n for n in generated if generated[n]!=bi['generated_sha256'][n]]==['synth.ys']
baseprogram=(B/'synthesis/synth.ys').read_text();assert (program+'\n').replace(str(source),str(B/'source')).replace(str(out),str(B/'synthesis'))==baseprogram
share=Y.parent.parent/'share/yosys';tool={'path':str(Y),'sha256':sha(Y),'version':subprocess.check_output([str(Y),'-V'],text=True).strip(),'share_files_sha256':{str(p.relative_to(share)):sha(p) for p in sorted(share.rglob('*')) if p.is_file()}}
assert tool==bi['yosys']
ancillary={n:{'path':shutil.which(n),'sha256':sha(Path(shutil.which(n)))} for n in ('as','ld')};assert ancillary==bi['assembler_linker']
write(run/'inputs.json',{'base_commit':BASE,'source_sha256':hashes,'generated_sha256':generated,'yosys':tool,'assembler_linker':ancillary,'configuration':bi['configuration'],'baseline_inputs_sha256':sha(B/'inputs.json'),'recipe_identical_apart_snapshot_and_output_paths':True,'scope':'Derived host diagnostic; producer authentication not invoked; no full route, timing acceptance or hardware claim.'})
command=[str(Y),'-Q','-s','synth.ys'];start=time.monotonic()
with (out/'yosys.log').open('w') as log:rc=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT).returncode
elapsed=time.monotonic()-start
assert hashes=={s:sha(component/s) for s in selected};assert tool['sha256']==sha(Y)
assert tool['share_files_sha256']=={str(p.relative_to(share)):sha(p) for p in sorted(share.rglob('*')) if p.is_file()}
for n,h in stand['files_sha256'].items():assert sha(R/n)==h
receipt={'base_commit':BASE,'command':command,'cwd':str(out),'returncode':rc,'elapsed_seconds':elapsed,'yosys_sha256':sha(Y),'source_snapshot_sha256':sha(derived),'inputs_manifest_sha256':sha(run/'inputs.json'),'standalone_evidence_sha256':sha(R/'subsets-evidence.json'),'artifacts':{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()},'evidence':'Host board synthesis diagnostic; no placement, route, seal or hardware acceptance.'}
write(run/'receipt.json',receipt);print(json.dumps({'returncode':rc,'elapsed_seconds':elapsed,'synth_sha256':receipt['artifacts'].get('synth.json')},indent=2),flush=True);assert rc==0
