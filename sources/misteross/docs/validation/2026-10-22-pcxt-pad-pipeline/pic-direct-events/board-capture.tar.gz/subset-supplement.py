#!/usr/bin/env python3
"""Extra cleanup inventories for all subsets and AP-specific negative mutations."""
from pathlib import Path
import ast,hashlib,json,shutil
import preprocess
R=Path(__file__).resolve().parent;S=R/'subset-supplement';S.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
ns={'__file__':str(R/'prove.py'),'__name__':'subset_supplement'}
t=ast.parse((R/'prove.py').read_text());exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[]),str(R/'prove.py'),'exec'),ns)
cleanup={n:ns['cleanup_proof'](R/'subsets'/n) for n in ['P','A','AP','L','LP','LA']}
ns['R']=S;ns['gold'],ns['keys'],ns['gs'],ns['gcells']=ns['state_cut'](R/'original/process.json','gold');write(S/'gold-cut.json',ns['gold']);preprocess.R=S
original=R/'subsets/AP';text=(original/'KF8259_Control_Logic.sv').read_text();files=json.loads((R/'snapshot.json').read_text())['files']['original'];results={}
for label,(a,b) in {'missing_invalid_state':(' || invalid_control_state;',';'),'wrong_poll_edge':('&& nedge_read_signal;','&& !nedge_read_signal;'),'wrong_reset_state':('control_state <= CTL_READY;','control_state <= ACK1;')}.items():
 assert text.count(a)==1
 dst=S/('negative-'+label);dst.mkdir()
 for n in files:shutil.copyfile(original/n,dst/n)
 (dst/'KF8259_Control_Logic.sv').write_text(text.replace(a,b));preprocess.run('negative-'+label,dst)
 results[label]=ns['prove'](label,dst/'process.json',False)
write(S/'proof.json',{'scope':'Complete dead-cone removal inventory for each proper event subset; actual AP-source mutations must produce counterexamples. Existing positive AP proof is frozen separately.','positive_AP_receipt_sha256':sha(R/'subsets/proof-AP/receipt.json'),'subset_evidence_sha256':sha(R/'subsets-evidence.json'),'cleanup':cleanup,'negative_results':{k:{n:v for n,v in x.items() if n not in ['equal_state_binding','actual_state_cells']} for k,x in results.items()}})
print('PASS: six closed cleanup cones, three actual AP negative source mutations rejected')
