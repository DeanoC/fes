import json,subprocess,time,pathlib
p=pathlib.Path(__file__).resolve().parent
t=time.monotonic()
with (p/"placement.log").open("w") as f:
 r=subprocess.run(json.loads((p/"host-command.json").read_text()),cwd=p,stdout=f,stderr=subprocess.STDOUT,timeout=300)
(p/"host-result.json").write_text(json.dumps(dict(returncode=r.returncode,elapsed=time.monotonic()-t,gpu_route_seconds=0),indent=2))
