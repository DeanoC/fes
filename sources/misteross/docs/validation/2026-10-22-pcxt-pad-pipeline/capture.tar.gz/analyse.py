import json,collections
from pathlib import Path
r=Path(__file__).resolve().parent
baseline=Path('/tmp/pcxt-commit-timing-20261022/candidate')
checks=json.loads((r/'candidate/pack-check.json').read_text())['pads']
result={}
for label,out in [('baseline',baseline),('candidate',r/'candidate')]:
 t=json.loads((out/'timing.json').read_text());e=json.loads((out/'endpoints.json').read_text())
 rows=[v for a in e['endpoints'].values() for v in a]
 pads={}
 for port,c in checks.items():
  rs=[v for k,a in e['endpoints'].items() if json.loads(k)[0]==c['cell'] for v in a]
  ss=[v['setup'] for v in rs if v.get('setup_timed')];hs=[v['hold'] for v in rs if v.get('hold_related')]
  pads[port]=dict(setup_ps=min(ss) if ss else None,hold_ps=min(hs) if hs else None,rows=len(rs))
 paths=[]
 for p in t['critical_paths']:
  ds=collections.defaultdict(float)
  for a in p['path']:ds[a['type']]+=a['delay']
  paths.append(dict(launch=p['path'][0]['from'],capture=p['path'][-1]['to'],setup_ns=p['max_delay']-sum(ds.values()),delays_ns=dict(ds)))
 paths.sort(key=lambda p:p['setup_ns'])
 result[label]=dict(fmax=t['fmax'],timing_summary=t['timing_summary'],complete=e['complete'],unsupported=len(e['unsupported']),endpoint_keys=len(e['endpoints']),failing_setup_rows=sum(v.get('setup_timed',False) and v['setup']<0 for v in rows),failing_related_hold_rows=sum(v.get('hold_related',False) and v['hold']<0 for v in rows),pads=pads,worst_paths=paths[:5],worst_cpu=next(p for p in paths if '.cpu.' in p['capture']['cell']),receipt=json.loads((out/'receipt.json').read_text()))
(r/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
for label,v in result.items():
 print(label,v['fmax']);print('failed setup/hold',v['failing_setup_rows'],v['failing_related_hold_rows']);print('worst pad',min((x['setup_ps'],k) for k,x in v['pads'].items() if x['setup_ps'] is not None));print('worst',v['worst_paths'][0]);print('cpu',v['worst_cpu'])
