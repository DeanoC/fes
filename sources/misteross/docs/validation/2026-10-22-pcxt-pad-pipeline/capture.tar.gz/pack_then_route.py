import sys,time,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
end=time.monotonic()+600
while 'candidate synthesized' not in Path('/tmp/pcxt-pad-synth.log').read_text():
 if time.monotonic()>end:raise RuntimeError('synthesis did not complete; no route launched')
 time.sleep(2)
out=root/'candidate';src=root/'source/sources/misteross'
binary='/tmp/pcxt-routed-waveform-20261022/inputs/nextpnr-mistral'
cmd=[binary,'--json','synth.json','--device','5CSEBA6U23I7','--qsf',str(src/'cores/fes-ramtest/constraints.qsf'),'--sdc',str(src/'boards/de10nano/clocks.sdc'),'--pack-only','--write','packed-check.json']
with (out/'pack-check.log').open('w') as log:
 subprocess.run(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True)
m=json.loads((out/'packed-check.json').read_text())['modules']['top']
checks={}
for port in ['SDRAM_A','SDRAM_BA','SDRAM_CKE','SDRAM_nCS','SDRAM_nRAS','SDRAM_nCAS','SDRAM_nWE']:
 for i,bit in enumerate(m['ports'][port]['bits']):
  matches=[(n,c) for n,c in m['cells'].items() if c['connections'].get('PAD')==[bit]]
  assert len(matches)==1,(port,i,matches)
  n,c=matches[0]
  assert c['type']=='MISTRAL_SDROUT',(port,i,c['type'])
  assert 'CEOUT' not in c['connections'] and 'ACLR' not in c['connections'],(port,i,c['connections'])
  checks[f'{port}[{i}]']={'cell':n,'type':c['type'],'parameters':c['parameters'],'clock':c['connections']['CLK']}
assert len(checks)==20
(out/'pack-check.json').write_text(json.dumps({'argv':cmd,'pads':checks},indent=2)+'\n')
print('Verified 20 plain output pad registers; starting bounded route',flush=True)
subprocess.run([sys.executable,str(root/'route.py')],check=True)
