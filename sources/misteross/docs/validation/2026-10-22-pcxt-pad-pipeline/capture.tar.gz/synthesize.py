import sys,subprocess,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
src=root/'source/sources/misteross'
sys.path[:0]=[str(src/'scripts'),str(src)]
import build_fes_pcxt as b
yosys=Path('/home/deano/fes/out/cache/misteross-toolchains/slots/8e7eeca0616bb73be28b6f12b17c33a19dd11c12dc9fdb56d964e086621867a2/install/bin/yosys')
for label in ['candidate']:
 out=root/label;out.mkdir()
 b.board_inputs(out)
 program=b.yosys_program(out,False,False,b.synthesis_command())
 if label=='baseline':
  gold=root/'baseline-endpoint.sv'
  gold.write_bytes(Path('/tmp/pcxt-endpoint-reference.sv').read_bytes())
  program=program.replace(str(src/'cores/fes-pcxt/rtl/pcxt_isa_endpoint.sv'),str(gold))
 (out/'synth.ys').write_text(program)
 with (out/'yosys.log').open('w') as log:
  subprocess.run([str(yosys),'-s','synth.ys'],cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(label,'synthesized',flush=True)
(root/'sources.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file()},indent=2)+'\n')
